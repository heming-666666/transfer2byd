# AGENTS.md：云端执行 agent 的入口

> **Quickstart (English)**: You run on-policy distillation (OPD) systems experiments on one node with 8× H800 and 2 TiB host RAM. Read this file, `docs/01`, `docs/02`–`04` and `docs/05`, then the route card of your task in `routes/`. Never fabricate numbers. Results go to `$OPD_RUNTIME/results/<TASK-ID>/`; compact results for the researcher go to `.../return/` as described in `docs/06`–`07`, and are packed into text parts (≤ 4500 characters each) with `scripts/make-return-text.py`. Transfer back is text-only. Do not change drivers, system packages, network or proxy settings, or global environment variables; never write credentials into files. The docs are in Chinese.

## 1. 你的角色

- 执行 `docs/05` 和 `state/tasks.yaml` 里的实验，记录可复现的信息，按 `docs/06`、`docs/07` 回传；
- 可以写测量和分析代码：给 verl、slime 加计时日志、写解析脚本、写 R2 的原型。代码放 `$OPD_RUNTIME/code/`，并在回传里说明；
- **不替研究者做研究决策**。路线卡里写了“决策规则”的，按规则走；规则没覆盖的情况（结果和预期差很多、要改方案、要额外下载、要更多时间），先记录，然后在回传里提出。

## 2. 必须遵守的规则

1. **不编造**。没测的写 `not measured`；估算标明“估算”；文档或论文里的数字不能当作实测值。
2. **记录可复现信息**：git commit 与本地改动、关键包版本、完整启动命令、配置文件、随机种子、GPU 编号、开始和结束时间（北京时间）、原始日志路径。每个任务都跑一次 `scripts/env-snapshot.sh`。
3. **GPU 分区**：A = GPU 0–3，B = GPU 4–7，用 `CUDA_VISIBLE_DEVICES` 隔离。两个分区可以同时跑不同任务；标为 `both` 的任务要等两个分区都空闲。R3（主机流式）测量时另一个分区必须空闲，并在回传里注明。
4. **不改全局配置**：驱动、系统包、内核参数、网络与代理设置、全局环境变量都不改。需要时停下来，在回传里说明原因。
5. **不碰凭据**：API key、token、密码不写进任何文件、日志或回传。
6. **下载要克制**：只下载 `docs/04` 列出的模型和数据，记录来源和版本；其他下载先问。
7. **遵守所在单位的规定**：回传里只放实验数据和自己写的代码摘要，不放单位的内部资料。
8. **长任务能续跑**：网格实验每完成一个配置写一行结果，中断后跳过已完成的配置。
9. **进度记录**：在 `$OPD_RUNTIME/state/progress.yaml` 记录每个任务的状态（`todo`、`running`、`done`、`partial`、`blocked`）、开始和结束时间、结果目录。
10. **预算**：某个任务超过预计时间 2 倍还没有结果，就停下来回传现状。
11. **编程代理写的代码要声明**：在 `return.yaml` 的 `code_by_agent` 里写 `yes` 并列出文件，投稿时需要声明。

## 3. 阅读顺序

| 你要做的 | 先读 | 再读 |
|---|---|---|
| 第一次接手 | 本文件、`README.md`、`docs/01` | `docs/02`–`05`、`docs/12` |
| 某条路线的任务 | `routes/` 中对应的实验卡 | `docs/08`、`09` 中对应的知识和文献 |
| 回传 | `docs/06`、`07` | `templates/task-return.yaml` |
| 出错 | `docs/11` | 路线卡的“已知问题” |

## 4. 任务协议

1. 按 `docs/05` 的顺序选任务：依赖已完成、优先级最高。A、B 两个分区可以各跑一个。
2. 按路线卡执行。原始输出放 `$OPD_RUNTIME/results/<TASK-ID>/`，要回传的精简结果放 `.../<TASK-ID>/return/`。
3. 复制 `templates/task-return.yaml` 到 `results/<TASK-ID>/return.yaml`，逐项填写。
4. 更新 `progress.yaml`。
5. 到路线卡写的“回传点”，或者距离上次回传已经 1–2 天，就运行
   `python3 scripts/make-return-text.py --tasks <任务…> --note "<一句话>"`，然后告诉研究者分段目录在哪里、一共几段。
6. 收到新版本（`VERSION` 变了）时，先运行 `scripts/verify-package.py`，再读 `CHANGELOG.md`，按新的任务清单继续；已完成的任务不用重做，除非 CHANGELOG 要求重跑。

## 5. 什么时候停下来

- 同一配置反复 OOM 或崩溃 3 次以上；
- 结果和路线卡里的“预期”差了一个数量级；
- 需要 sudo、改全局配置，或者下载清单以外超过 50 GB 的文件；
- 需要改 verl、slime、SGLang 的核心逻辑（只加日志不算；R2-2 的原型按其实验卡执行）；
- 机器或网络出问题：只记录报错和受影响的步骤，不去改网络或代理设置。

## 6. 编号约定

- 任务编号写成“路线-任务”，例如 `R0-P0`、`R1-E0-S`、`R2-P3`；
- T = 基础任务，P = 测量与最小实验，E = OPD 实验；
- 此前部署实验包（llm-serving-lab）的实验编号是 E01–E24、AR-01–AR-10，引用时写全称，不要和本包的编号混用。
