# CLAUDE.md

本目录是给云端 8×H800 机器的 OPD 实验与学习包。动手之前先读 `AGENTS.md`（规则、阅读顺序、任务协议），再读 `README.md`、`docs/01` 和 `state/tasks.yaml`。

@AGENTS.md
