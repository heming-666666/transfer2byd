"""P3 policies: simulate one OPD step under a teacher-scoring policy (see routes/R2-1).
Policies: sync, complete, stream_all, tail_k, i8 (priority = current length), oracle (true remaining)."""
from p3_model import Capacity


def simulate(rollouts, policy, P, k=None):
    B, budget, chunk, total = P["kv_bytes_per_token"], P["kv_budget_gb"] * 1e9, P["chunk"], len(rollouts)
    events = []
    for r in rollouts.values():
        events += [(r.t_at(n), 0, r.rid, n) for n in range(chunk, r.final, chunk)]
        events.append((r.ts[-1], 1, r.rid, r.final))
    events.sort()
    gen_end = max(r.ts[-1] for r in rollouts.values())
    C = Capacity(rollouts, P)
    st = {"free": 0.0, "tokens": 0, "kv": 0.0, "peak": 0.0, "dem": 0, "over": 0.0}
    streamed, demoted, inflight = {}, {}, set(rollouts)

    def busy(t, cost):
        st["free"] = C.inv(C.cap(max(t, st["free"])) + cost)

    def submit(t, ntok, prefix):
        busy(t, P["t_req"] + ntok * (P["s_tok"] + P["s_attn"] * prefix / 1000.0)); st["tokens"] += ntok

    def full(r, n):
        return n if P["prompt_cached"] else r.prompt + n

    def kv_add(x):
        st["kv"] += x; st["peak"] = max(st["peak"], st["kv"])
        if st["kv"] > budget:
            st["over"] = max(st["over"], st["kv"] - budget)

    def prio(r, n):
        return (r.final - n) if policy == "oracle" else n

    def xfer(r, done):
        return (r.prompt + done) * B / (P["offload_gbps"] * 1e9) + P["offload_fixed_s"]

    def demote_one(t):
        if not streamed:
            return False
        _, x = min((prio(rollouts[x], d), x) for x, d in streamed.items())
        done = streamed.pop(x); r = rollouts[x]
        st["kv"] -= (r.prompt + done) * B; st["dem"] += 1; demoted[x] = done
        if P["demote"] == "offload":
            busy(t, xfer(r, done))
        return True

    def start(t, r, n):
        submit(t, full(r, n), 0); streamed[r.rid] = n; kv_add((r.prompt + n) * B)

    for t, kind, rid, n in events:
        r = rollouts[rid]
        if kind == 1:                                   # rollout finished
            inflight.discard(rid)
            if policy == "sync":
                continue
            if rid in streamed:
                done = streamed.pop(rid); submit(t, n - done, r.prompt + done); st["kv"] -= (r.prompt + done) * B
            elif rid in demoted:
                done = demoted.pop(rid)
                if P["demote"] == "offload":
                    busy(t, xfer(r, done)); submit(t, n - done, r.prompt + done)
                else:
                    submit(t, full(r, n), 0)
            else:
                submit(t, full(r, n), 0)
            continue
        if rid in streamed:                             # chunk boundary of a streamed rollout
            grow = (n - streamed[rid]) * B
            if policy in ("i8", "oracle"):
                while st["kv"] + grow > budget and demote_one(t):
                    pass
                if rid not in streamed:
                    continue
            submit(t, n - streamed[rid], r.prompt + streamed[rid]); kv_add(grow); streamed[rid] = n
        elif policy == "stream_all":
            start(t, r, n)
        elif policy == "tail_k" and len(inflight) <= k and rid not in demoted:
            if st["kv"] + (r.prompt + n) * B <= budget:
                start(t, r, n)
        elif policy in ("i8", "oracle") and rid not in demoted and len(inflight) <= P["i8_start_frac"] * total:
            need = (r.prompt + n) * B
            while st["kv"] + need > budget and streamed:
                if min(prio(rollouts[x], d) for x, d in streamed.items()) >= prio(r, n) or not demote_one(t):
                    break
            if st["kv"] + need <= budget:
                start(t, r, n)
    if policy == "sync":
        for r in rollouts.values():
            submit(gen_end, full(r, r.final), 0)
    end = max(gen_end, st["free"])
    return {"end_s": round(end, 3), "gen_end_s": round(gen_end, 3), "after_gen_s": round(end - gen_end, 3),
            "teacher_tokens": st["tokens"], "peak_kv_gb": round(st["peak"] / 1e9, 2), "demotions": st["dem"],
            "kv_overflow_gb": round(st["over"] / 1e9, 2), "feasible": st["over"] == 0}
