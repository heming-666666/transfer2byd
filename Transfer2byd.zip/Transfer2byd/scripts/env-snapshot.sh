#!/usr/bin/env bash
# Save a read-only snapshot of the machine and software for a task's return record.
# Usage: scripts/env-snapshot.sh <out_dir> [python ...]   e.g. scripts/env-snapshot.sh $OPD_RUNTIME/results/R0-P0/env $OPD_RUNTIME/envs/sglang/bin/python
# Writes: nvidia-smi (query, topo, nvlink), CPU/NUMA/memory, disk, OS, and `pip freeze` for each python given,
# plus git commit and dirty state of repos under $OPD_RUNTIME/code and $OPD_RUNTIME/repos (if present).
# It never dumps environment variables (they may hold credentials or proxy settings).
set -uo pipefail
out="${1:?out_dir}"; shift
RT="${OPD_RUNTIME:-$HOME/opd-runtime}"
mkdir -p "$out"
run() { local f="$1"; shift; { echo "\$ $*"; "$@"; } > "$out/$f" 2>&1 || echo "(command failed: $*)" >> "$out/$f"; }
date '+%Y-%m-%d %H:%M:%S %z' > "$out/date.txt"
run nvidia-smi.txt nvidia-smi
run nvidia-smi-q.txt nvidia-smi -q
run nvidia-smi-topo.txt nvidia-smi topo -m
run nvidia-smi-nvlink.txt nvidia-smi nvlink -s
run lscpu.txt lscpu
run numactl.txt numactl -H
run free.txt free -g
run df.txt df -h "$RT"
run os-release.txt cat /etc/os-release
run uname.txt uname -a
i=0
for py in "$@"; do
  i=$((i + 1))
  run "pip-freeze-$i.txt" "$py" -m pip freeze
  echo "$py" >> "$out/pip-freeze-$i.txt"
done
for root in "$RT/code" "$RT/repos"; do
  [[ -d "$root" ]] || continue
  for d in "$root"/*/; do
    [[ -d "$d/.git" ]] || continue
    { echo "== $d"; git -C "$d" rev-parse HEAD; git -C "$d" status --porcelain | head -50; } >> "$out/git-repos.txt" 2>&1
  done
done
echo "snapshot written to $out"
