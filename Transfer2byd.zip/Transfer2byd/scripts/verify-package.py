#!/usr/bin/env python3
"""Check that every file of Transfer2byd arrived intact (after copy-paste or unzip).
Usage: python scripts/verify-package.py   (run inside the Transfer2byd directory)
Compares each file listed in 00-传输清单*.md with its normalized sha12 (CRLF->LF, trailing spaces and
trailing blank lines removed), so harmless whitespace changes from pasting do not count as errors."""
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ROW = re.compile(r"^\|\s*`([^`]+)`\s*\|\s*(\d+)\s*\|\s*`?([0-9a-f]{12})`?\s*\|")


def norm_hash(text):
    body = "\n".join(l.rstrip() for l in text.replace("\r\n", "\n").split("\n")).strip("\n")
    return hashlib.sha256(body.encode()).hexdigest()[:12]


def main() -> int:
    rows = []
    for m in sorted(ROOT.glob("00-传输清单*.md")):
        for line in m.read_text(encoding="utf-8").splitlines():
            r = ROW.match(line)
            if r:
                rows.append((r.group(1), int(r.group(2)), r.group(3)))
    if not rows:
        print("no manifest rows found (00-传输清单*.md)"); return 1
    bad = 0
    for path, chars, h in rows:
        p = ROOT / path
        if not p.exists():
            print(f"MISSING  {path}"); bad += 1; continue
        got = norm_hash(p.read_text(encoding="utf-8", errors="replace"))
        if got != h:
            print(f"CHANGED  {path}  expected {h} got {got}"); bad += 1
    print(f"{len(rows) - bad}/{len(rows)} files OK")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
