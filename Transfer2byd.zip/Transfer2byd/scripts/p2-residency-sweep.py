#!/usr/bin/env python3
"""P2 (R3): scoring throughput vs tokens per pass on one SGLang server; `compare` finds the break-even.
Usage: routes/R3. Random token ids are used so the prefix cache cannot help."""
import argparse
import concurrent.futures as cf
import json
import os
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sglang_api import flush, score, write_json  # noqa: E402


def run(a):
    base, rng, rows = a.url.rstrip("/"), random.Random(a.seed), []
    for c in a.pass_tokens:
        n_req = max(1, -(-c // a.seq_len)); reps = []
        for _ in range(a.repeats):
            seqs = [[rng.randint(a.min_id, a.max_id) for _ in range(a.seq_len)] for _ in range(n_req)]
            flush(base)
            t0 = time.perf_counter()
            with cf.ThreadPoolExecutor(max_workers=min(n_req, a.max_workers)) as ex:
                res = list(ex.map(lambda s: score(base, s, 0), seqs))
            wall = time.perf_counter() - t0
            reps.append({"wall_s": round(wall, 3), "tokens_per_s": round(n_req * a.seq_len / wall, 1),
                         "max_req_s": round(max(r["sec"] for r in res), 3)})
        best = max(r["tokens_per_s"] for r in reps)
        rows.append({"pass_tokens": n_req * a.seq_len, "requests": n_req, "best_tokens_per_s": best, "repeats": reps})
        print(f"pass {n_req * a.seq_len:>8} tokens: {best} tok/s", file=sys.stderr)
    write_json(a.out, {"task": "R3-P2", "label": a.label, "url": base, "seq_len": a.seq_len, "rows": rows})


def compare(a):
    x, y = json.loads(Path(a.baseline).read_text()), json.loads(Path(a.other).read_text())
    base = {r["pass_tokens"]: r["best_tokens_per_s"] for r in x["rows"]}
    rows, be = [], None
    for r in y["rows"]:
        if r["pass_tokens"] in base:
            ratio = r["best_tokens_per_s"] / base[r["pass_tokens"]]
            rows.append({"pass_tokens": r["pass_tokens"], "baseline_tok_s": base[r["pass_tokens"]],
                         "other_tok_s": r["best_tokens_per_s"], "ratio": round(ratio, 3)})
            if be is None and ratio >= a.threshold:
                be = r["pass_tokens"]
    out = {"task": "R3-P2", "baseline": x["label"], "other": y["label"], "threshold": a.threshold,
           "break_even_pass_tokens": be, "rows": rows}
    write_json(a.out, out)
    print(json.dumps(out, indent=1))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--url", required=True); r.add_argument("--label", required=True)
    r.add_argument("--pass-tokens", type=int, nargs="+", default=[4096, 16384, 65536, 262144])
    r.add_argument("--seq-len", type=int, default=4096); r.add_argument("--repeats", type=int, default=2)
    r.add_argument("--max-workers", type=int, default=256); r.add_argument("--seed", type=int, default=0)
    r.add_argument("--min-id", type=int, default=1000); r.add_argument("--max-id", type=int, default=30000)
    r.add_argument("--out", required=True)
    c = sub.add_parser("compare")
    c.add_argument("--baseline", required=True); c.add_argument("--other", required=True)
    c.add_argument("--threshold", type=float, default=0.8); c.add_argument("--out", required=True)
    a = ap.parse_args()
    (run if a.cmd == "run" else compare)(a)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
