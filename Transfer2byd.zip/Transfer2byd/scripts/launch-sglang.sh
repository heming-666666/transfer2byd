#!/usr/bin/env bash
# Start / stop SGLang servers for the experiments; logs and command lines go to $OPD_RUNTIME/logs.
# Usage:
#   scripts/launch-sglang.sh start <name> <model_path> <gpus, e.g. 0,1,2,3> <port> [extra sglang args...]
#   scripts/launch-sglang.sh wait <port> [timeout_s]      # wait until /health answers
#   scripts/launch-sglang.sh stop <name>
#   scripts/launch-sglang.sh status
# Env: SGLANG_PY = python that has sglang installed (default python3); OPD_RUNTIME (default $HOME/opd-runtime).
# The server binds to 127.0.0.1 only. Example (Qwen3-32B teacher, TP4 on partition A, 16 GB/GPU offloaded):
#   scripts/launch-sglang.sh start t32-off16 $OPD_RUNTIME/models/Qwen3-32B 0,1,2,3 30000 --tp-size 4 --cpu-offload-gb 16
set -euo pipefail
RT="${OPD_RUNTIME:-$HOME/opd-runtime}"
PY="${SGLANG_PY:-python3}"
mkdir -p "$RT/logs" "$RT/state/pids"
alive() {  # pid exists and is not a zombie (orphans can stay zombies in containers without an init)
  local s; s="$(sed -n 's/^.*) \(.\).*$/\1/p' "/proc/$1/stat" 2> /dev/null)"
  [[ -n "$s" && "$s" != Z ]]
}
cmd="${1:-}"; [[ $# -gt 0 ]] && shift
case "$cmd" in
  start)
    [[ $# -ge 4 ]] || { sed -n '2,10p' "$0"; exit 1; }
    name="$1"; model="$2"; gpus="$3"; port="$4"; shift 4
    pidf="$RT/state/pids/$name.pid"
    if [[ -f "$pidf" ]] && alive "$(cat "$pidf")"; then echo "already running: $name"; exit 1; fi
    log="$RT/logs/sglang-$name-$(date +%Y%m%d-%H%M%S).log"
    printf 'CUDA_VISIBLE_DEVICES=%s %s -m sglang.launch_server --model-path %s --port %s --host 127.0.0.1 %s\n' \
      "$gpus" "$PY" "$model" "$port" "$*" > "$log.cmd"
    CUDA_VISIBLE_DEVICES="$gpus" setsid nohup "$PY" -m sglang.launch_server --model-path "$model" \
      --port "$port" --host 127.0.0.1 "$@" > "$log" 2>&1 &
    echo $! > "$pidf"; echo "$port" > "$RT/state/pids/$name.port"
    echo "started $name pid=$! log=$log (command saved to $log.cmd)"
    ;;
  wait)
    port="${1:?port}"; to="${2:-1800}"
    for ((i = 0; i < to; i += 5)); do
      if curl -sf "http://127.0.0.1:$port/health" > /dev/null 2>&1; then echo "ready :$port"; exit 0; fi
      for f in "$RT"/state/pids/*.port; do   # give up early if the server on this port has exited
        [[ -e "$f" && "$(cat "$f")" == "$port" ]] || continue
        p="$(cat "${f%.port}.pid" 2> /dev/null || true)"
        [[ -n "$p" ]] && ! alive "$p" && { echo "server $(basename "$f" .port) exited; see its log"; exit 1; }
      done
      sleep 5
    done
    echo "timeout waiting for :$port"; exit 1
    ;;
  stop)
    name="${1:?name}"; pidf="$RT/state/pids/$name.pid"
    [[ -f "$pidf" ]] || { echo "no pid file for $name"; exit 1; }
    pid="$(cat "$pidf")"
    kill -- "-$pid" 2> /dev/null || kill "$pid" 2> /dev/null || true   # whole process group (server + workers)
    for ((i = 0; i < 60; i++)); do alive "$pid" || break; sleep 1; done   # wait for the server to exit
    kill -9 -- "-$pid" 2> /dev/null || true; sleep 2                     # then remove leftover workers
    rm -f "$pidf" "$RT/state/pids/$name.port"; echo "stopped $name"
    ;;
  status)
    for f in "$RT"/state/pids/*.pid; do
      [[ -e "$f" ]] || continue
      n="$(basename "$f" .pid)"; p="$(cat "$f")"
      if alive "$p"; then echo "$n running pid=$p"; else echo "$n not running (stale pid $p)"; fi
    done
    ;;
  *) sed -n '2,10p' "$0"; exit 1 ;;
esac
