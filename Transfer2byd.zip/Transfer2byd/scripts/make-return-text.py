#!/usr/bin/env python3
"""Pack results into text-only return parts (<= --max-chars each) for copy-paste transfer. Rules: docs/06, docs/07.
Returns $OPD_RUNTIME/results/<TASK>/return.yaml and every text file under results/<TASK>/return/.
Writes $OPD_RUNTIME/returns/<return-id>/part-NN.md; paste each part as one file into Transfer2me/<return-id>/."""
import argparse
import datetime as dt
import hashlib
import json
import os
import re
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent
TEXT_EXT = {".md", ".yaml", ".yml", ".json", ".csv", ".txt", ".log", ".tsv"}
SECRET = re.compile(r"(^\.env$|\.pem$|^id_rsa|credential|secret|apikey|api_key|hf_token|\.token$)", re.I)


def norm_hash(text):
    body = "\n".join(l.rstrip() for l in text.replace("\r\n", "\n").split("\n")).strip("\n")
    return hashlib.sha256(body.encode()).hexdigest()[:12]


def blocks(rt, tasks, max_lines):
    for t in tasks:
        d = rt / "results" / t
        files = ([d / "return.yaml"] if (d / "return.yaml").exists() else []) + sorted(
            p for p in (d / "return").rglob("*") if p.is_file()) if d.exists() else []
        for p in files:
            rel = p.relative_to(rt / "results").as_posix()
            if SECRET.search(p.name) or p.suffix.lower() not in TEXT_EXT:
                yield rel, [f"(not included: {'credential-like name' if SECRET.search(p.name) else 'not a text file'})"]
                continue
            lines = p.read_text(errors="replace").splitlines()
            if p.suffix.lower() in (".csv", ".tsv", ".log") and len(lines) > max_lines:
                lines = lines[:max_lines - 20] + [f"... ({len(lines) - max_lines} lines omitted; downsample per docs/07) ..."] + lines[-19:]
            yield rel, lines


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--tasks", nargs="+", required=True)
    ap.add_argument("--note", default="")
    ap.add_argument("--max-chars", type=int, default=4500)
    ap.add_argument("--max-lines", type=int, default=300, help="CSV/log files longer than this are cut")
    a = ap.parse_args()
    rt = Path(os.environ.get("OPD_RUNTIME", Path.home() / "opd-runtime"))
    day = dt.datetime.now().strftime("%Y%m%d"); n = 1
    while (rt / "returns" / f"return-{day}-{n:02d}").exists():
        n += 1
    rid = f"return-{day}-{n:02d}"
    ver = (PKG / "VERSION").read_text().strip() if (PKG / "VERSION").exists() else "unknown"
    budget = a.max_chars - 200                   # room for BEGIN/END markers
    head = [f"# 回传 {rid}", f"包版本：{ver}；生成：{dt.datetime.now().astimezone().isoformat(timespec='minutes')}",
            f"任务：{', '.join(a.tasks)}", f"说明：{a.note}", ""]
    parts, cur = [], list(head)

    def size(ls):
        return sum(len(x) + 1 for x in ls)

    for rel, lines in blocks(rt, a.tasks, a.max_lines):
        i, first = 0, True
        while i < len(lines) or first:
            hdr = f"=== FILE {rel} (lines {i + 1}-) ===" if first else f"=== FILE {rel} (continued, lines {i + 1}-) ==="
            if size(cur) + len(hdr) + 40 > budget:
                parts.append(cur); cur = []
            cur.append(hdr); start = i
            while i < len(lines):
                line = lines[i] if len(lines[i]) < budget // 2 else lines[i][: budget // 2] + " ...(cut)"
                if size(cur) + len(line) + 20 > budget:
                    break
                cur.append(line); i += 1
            cur.append(f"=== END FILE {rel} (lines {start + 1}-{i}) ===")
            first = False
            if i < len(lines):
                parts.append(cur); cur = []
    if cur:
        parts.append(cur)
    out = rt / "returns" / rid; out.mkdir(parents=True)
    for k, ls in enumerate(parts, 1):
        body = "\n".join(ls)
        tag = f"{rid} PART {k:02d}/{len(parts):02d}"
        text = f"<<<BEGIN RETURN {tag}>>>\n{body}\n<<<END RETURN {tag} sha12={norm_hash(body)}>>>\n"
        assert len(text) <= a.max_chars, (k, len(text))
        (out / f"part-{k:02d}.md").write_text(text)
    (out / "INDEX.json").write_text(json.dumps({"return": rid, "parts": len(parts), "tasks": a.tasks}, ensure_ascii=False) + "\n")
    print(f"{len(parts)} parts in {out} (each <= {a.max_chars} chars).")
    print(f"Paste each part-NN.md as its own file into the researcher's paper/Transfer2me/{rid}/ (same names).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
