#!/usr/bin/env python3
"""P4 (R4): teacher log-prob differences for the same sequences on two SGLang servers. Usage: routes/R4.
make-seqs: fixed sequences from the reference server; compare: |delta logprob| stats, top-1 agreement,
mean KL on the returned top-k support (a lower bound of the true KL)."""
import argparse
import json
import math
import os
import statistics
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sglang_api import PROMPTS, generate, pct, score, write_json  # noqa: E402


def make_seqs(a):
    prompts = PROMPTS
    if a.prompts_file:
        prompts = [json.loads(l)["prompt"] for l in Path(a.prompts_file).read_text().splitlines() if l.strip()]
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w") as f:
        for i in range(a.n):
            p, o = generate(a.url.rstrip("/"), prompts[i % len(prompts)], a.max_new_tokens, a.temperature, seed=i)
            f.write(json.dumps({"prompt_ids": p, "response_ids": o}) + "\n")
    print(f"wrote {a.n} sequences -> {out}")


def compare(a):
    seqs = [json.loads(l) for l in Path(a.seqs).read_text().splitlines() if l.strip()]
    diffs, same, total, kls = [], 0, 0, []
    for s in seqs:
        ids, start = s["prompt_ids"] + s["response_ids"], len(s["prompt_ids"])
        x, y = score(a.ref.rstrip("/"), ids, start, a.top_k), score(a.test.rstrip("/"), ids, start, a.top_k)
        n = min(len(x["lps"]), len(y["lps"]), len(s["response_ids"]))
        diffs += [abs(u - v) for u, v in zip(x["lps"][:n], y["lps"][:n]) if u is not None and v is not None]
        if x["tops"] and y["tops"]:
            kl = []
            for pa, pb in zip(x["tops"][:n], y["tops"][:n]):
                if not pa or not pb:
                    continue
                total += 1; same += int(pa[0][1] == pb[0][1])
                qb = {e[1]: e[0] for e in pb}
                kl.append(sum(math.exp(lp) * (lp - qb[t]) for lp, t, *_ in pa if t in qb and None not in (lp, qb[t])))
            if kl:
                kls.append(statistics.fmean(kl))
    res = {"task": "R4-P4", "label": a.label, "n_seqs": len(seqs), "n_tokens": len(diffs),
           "abs_diff": {"p50": pct(diffs, .5), "p90": pct(diffs, .9), "p99": pct(diffs, .99),
                        "max": max(diffs) if diffs else None, "mean": statistics.fmean(diffs) if diffs else None},
           "top1_agreement": round(same / total, 4) if total else None,
           "mean_kl_on_topk_support": statistics.fmean(kls) if kls else None}
    write_json(a.out, res)
    print(json.dumps(res, indent=1))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("make-seqs")
    m.add_argument("--url", required=True); m.add_argument("--n", type=int, default=64)
    m.add_argument("--max-new-tokens", type=int, default=2048); m.add_argument("--temperature", type=float, default=0.7)
    m.add_argument("--prompts-file"); m.add_argument("--out", required=True)
    c = sub.add_parser("compare")
    c.add_argument("--ref", required=True); c.add_argument("--test", required=True); c.add_argument("--seqs", required=True)
    c.add_argument("--label", required=True); c.add_argument("--top-k", type=int, default=0); c.add_argument("--out", required=True)
    a = ap.parse_args()
    (make_seqs if a.cmd == "make-seqs" else compare)(a)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
