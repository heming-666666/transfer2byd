#!/usr/bin/env python3
"""P0: measure host->GPU, GPU->host and GPU<->GPU copy bandwidth on one node and save JSON.

Why (routes/R0): llm-serving-lab E15 reported 339.8 GB/s unidirectional NVLink, above the H800
spec, so this re-measures one direction at a time. It also measures concurrent H2D from pinned host
memory on all GPUs, which R3 (host-streamed teacher) depends on.

Usage (any Python env with PyTorch + CUDA, e.g. the SGLang env):
  python p0-bandwidth-check.py --size-gb 1 --iters 10 --peer 0 1 --out .../return/bandwidth.json
Run it when no other job uses the GPUs. It allocates about size-gb per GPU (device and pinned host)
and frees it on exit; it changes no system setting. Not yet run on real hardware: report errors verbatim.
"""
import argparse
import json
import time
from pathlib import Path

import torch


def gbps(nbytes, seconds):
    return round(nbytes / seconds / 1e9, 2)


def timed_copies(pairs, iters):
    """pairs: list of (dst, src, stream). Queue `iters` copies on each stream, then wait for all.
    Returns (per-pair GB/s from CUDA events, aggregate GB/s from wall time)."""
    events = []
    for dst, src, stream in pairs:  # warm-up
        with torch.cuda.stream(stream):
            dst.copy_(src, non_blocking=True)
    for _, _, stream in pairs:
        stream.synchronize()
    t0 = time.perf_counter()
    for dst, src, stream in pairs:
        with torch.cuda.stream(stream):
            start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            start.record(stream)
            for _ in range(iters):
                dst.copy_(src, non_blocking=True)
            end.record(stream)
            events.append((start, end, dst.numel() * dst.element_size() * iters))
    for _, _, stream in pairs:
        stream.synchronize()
    wall = time.perf_counter() - t0
    per = [gbps(nbytes, s.elapsed_time(e) / 1e3) for s, e, nbytes in events]
    total = sum(nbytes for _, _, nbytes in events)
    return per, gbps(total, wall)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--size-gb", type=float, default=1.0, help="buffer size per copy")
    ap.add_argument("--iters", type=int, default=10)
    ap.add_argument("--peer", type=int, nargs=2, default=[0, 1], help="GPU pair for the NVLink test")
    ap.add_argument("--out", required=True, help="output JSON path")
    args = ap.parse_args()

    n = torch.cuda.device_count()
    size = int(args.size_gb * (1 << 30))
    res = {"torch": torch.__version__, "cuda": torch.version.cuda,
           "gpus": [torch.cuda.get_device_name(i) for i in range(n)], "size_bytes": size, "iters": args.iters}

    host = [torch.empty(size, dtype=torch.uint8, pin_memory=True) for _ in range(n)]
    dev = [torch.empty(size, dtype=torch.uint8, device=f"cuda:{i}") for i in range(n)]
    streams = [torch.cuda.Stream(device=i) for i in range(n)]

    single = []
    for i in range(n):
        per, _ = timed_copies([(dev[i], host[i], streams[i])], args.iters)
        single.append(per[0])
    res["h2d_single_gpu_GBps"] = single
    per, agg = timed_copies([(dev[i], host[i], streams[i]) for i in range(n)], args.iters)
    res["h2d_all_gpus_concurrent_GBps"] = {"per_gpu": per, "aggregate": agg}
    per, agg = timed_copies([(host[i], dev[i], streams[i]) for i in range(n)], args.iters)
    res["d2h_all_gpus_concurrent_GBps"] = {"per_gpu": per, "aggregate": agg}

    a, b = args.peer
    if n > max(a, b):
        res["peer_access"] = {f"{a}->{b}": torch.cuda.can_device_access_peer(a, b),
                              f"{b}->{a}": torch.cuda.can_device_access_peer(b, a)}
        per, _ = timed_copies([(dev[b], dev[a], streams[a])], args.iters)
        res[f"p2p_unidirectional_{a}to{b}_GBps"] = per[0]
        per, agg = timed_copies([(dev[b], dev[a], streams[a]), (dev[a], dev[b], streams[b])], args.iters)
        res[f"p2p_bidirectional_{a}and{b}_GBps"] = {"per_direction": per, "aggregate": agg}

    res["note"] = ("h2d concurrent per_gpu far below h2d_single_gpu = shared PCIe uplinks or host-memory "
                   "bandwidth (matters for R3); compare p2p_unidirectional with llm-serving-lab E15 (339.8 GB/s)")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=1) + "\n")
    print(json.dumps(res, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
