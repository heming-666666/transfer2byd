#!/usr/bin/env python3
"""P1 (R2): one-shot vs chunked incremental teacher scoring on one SGLang server. Usage: routes/R2-1."""
import argparse
import json
import os
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sglang_api import PROMPTS, flush, generate, pct, score, write_json  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--url", required=True)
    ap.add_argument("--chunk", type=int, default=256)
    ap.add_argument("--max-new-tokens", type=int, default=2048)
    ap.add_argument("--n-prompts", type=int, default=8)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--top-k", type=int, default=0)
    ap.add_argument("--prompts-file")
    ap.add_argument("--no-flush", action="store_true")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    base = a.url.rstrip("/")
    prompts = PROMPTS
    if a.prompts_file:
        prompts = [json.loads(l)["prompt"] for l in Path(a.prompts_file).read_text().splitlines() if l.strip()]
    seqs = [generate(base, p, a.max_new_tokens, a.temperature) for p in prompts[: a.n_prompts]]

    flush(base, not a.no_flush)                       # one-shot
    one = [score(base, p + o, len(p), a.top_k) for p, o in seqs]

    flush(base, not a.no_flush)                       # incremental
    inc = []
    for p, o in seqs:
        lps, ids, cached, sec = [], [], [], 0.0
        for s in range(0, len(o), a.chunk):
            e = min(s + a.chunk, len(o))
            r = score(base, p + o[:e], len(p) + s, a.top_k)
            lps += r["lps"][: e - s]; ids += r["ids"][: e - s]; cached.append(r["cached"]); sec += r["sec"]
        inc.append({"lps": lps, "ids": ids, "cached": cached, "sec": sec})

    diffs, bad, per = [], 0, []
    for (p, o), x, y in zip(seqs, one, inc):
        n = min(len(x["lps"]), len(y["lps"]))
        if len(x["lps"]) != len(y["lps"]) or x["ids"][:n] != y["ids"][:n]:
            bad += 1
        d = [abs(u - v) for u, v in zip(x["lps"][:n], y["lps"][:n]) if u is not None and v is not None]
        diffs += d
        per.append({"prompt_tokens": len(p), "response_tokens": len(o), "max_abs_diff": max(d) if d else None,
                    "one_shot_s": round(x["sec"], 3), "incremental_s": round(y["sec"], 3),
                    "one_shot_cached": x["cached"], "incremental_cached_per_chunk": y["cached"]})
    res = {"task": "R2-P1", "url": base, "chunk": a.chunk, "n_seqs": len(seqs),
           "abs_diff": {"p50": pct(diffs, .5), "p99": pct(diffs, .99), "max": max(diffs) if diffs else None,
                        "mean": statistics.fmean(diffs) if diffs else None, "count": len(diffs)},
           "seqs_with_length_or_id_mismatch": bad,
           "total_s": {"one_shot": round(sum(x["sec"] for x in one), 3), "incremental": round(sum(y["sec"] for y in inc), 3)},
           "per_sequence": per}
    write_json(a.out, res)
    print(json.dumps({k: v for k, v in res.items() if k != "per_sequence"}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
