"""P3 synthetic rollout timelines, used to smoke-test the simulator before real R1-E0 logs exist.
Output columns follow templates/log-schemas.md (rollout_timeline.csv)."""
import csv
import math
import random
from pathlib import Path


def synth(out, steps=2, rollouts=256, group_size=8, prompt_len=256, median_len=4000, sigma=0.8,
          max_len=16384, checkpoint=64, iter_base=0.012, iter_per_seq=3e-5, seed=0):
    """Lognormal response lengths capped at max_len; all in-flight rollouts decode one token per
    iteration, and one iteration takes iter_base + iter_per_seq * in_flight seconds."""
    rng, rows = random.Random(seed), []
    for s in range(steps):
        lens = [min(max_len, max(64, int(rng.lognormvariate(math.log(median_len), sigma)))) for _ in range(rollouts)]
        cnt = [0] * (max(lens) + 2)
        for L in lens:
            cnt[L] += 1
        left, T = len(lens), [0.0] * (max(lens) + 1)
        for i in range(1, max(lens) + 1):
            T[i] = T[i - 1] + iter_base + iter_per_seq * left
            left -= cnt[i]
        for j, L in enumerate(lens):
            for n in list(range(checkpoint, L, checkpoint)) + [L]:
                rows.append((s, f"r{j}", f"g{j // group_size}", prompt_len, n, round(T[n], 4)))
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["step", "rollout_id", "group_id", "prompt_len", "n_tokens", "t_s"]); w.writerows(rows)
    return len(rows)
