"""Shared helpers for the measurement scripts: SGLang native /generate API, stdlib only.

Response fields used (SGLang 0.5.23 native API): meta_info.input_token_logprobs / output_token_logprobs
(lists of [logprob, token_id, text_or_None]), meta_info.input_top_logprobs (with top_logprobs_num),
meta_info.cached_tokens. If a field is missing the scripts stop and print the keys they received.
"""
import json
import sys
import time
import urllib.request

PROMPTS = [
    "Solve step by step: a train travels 180 km in 2.5 hours, then 120 km in 1.5 hours. What is its average speed?",
    "Prove that the sum of the first n odd numbers equals n squared. Show your reasoning.",
    "How many positive integers less than 1000 are divisible by 7 but not by 11? Explain.",
    "Find all real x such that x^2 - 5x + 6 = 0 and explain each step.",
    "A box has 3 red, 4 blue and 5 green balls. Two are drawn without replacement. What is the probability both are blue?",
    "Compute the derivative of f(x) = x^3 * ln(x) and simplify.",
    "What is the remainder when 2^100 is divided by 7? Reason carefully.",
    "A rectangle has perimeter 40 and area 96. Find its side lengths.",
]


def post(url, payload, timeout=3600):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def flush(base, enabled=True):
    """POST /flush_cache (clears the whole server cache). Failures are reported, not fatal."""
    if not enabled:
        return
    try:
        urllib.request.urlopen(urllib.request.Request(base + "/flush_cache", data=b"", method="POST"), timeout=120).read()
    except Exception as e:
        print(f"warning: /flush_cache failed: {e}", file=sys.stderr)


def field(meta, key):
    if key not in meta:
        sys.exit(f"meta_info has no '{key}'. Keys returned: {sorted(meta)}; adapt sglang_api.py to this SGLang version.")
    return meta[key]


def generate(base, prompt, max_new_tokens, temperature=0.7, seed=None):
    """Generate a response; return (prompt_ids, response_ids)."""
    sp = {"max_new_tokens": max_new_tokens, "temperature": temperature}
    if seed is not None:
        sp["seed"] = seed
    meta = post(base + "/generate", {"text": prompt, "sampling_params": sp, "return_logprob": True,
                                     "logprob_start_len": 0}).get("meta_info", {})
    return [e[1] for e in field(meta, "input_token_logprobs")], [e[1] for e in field(meta, "output_token_logprobs")]


def score(base, ids, start, top_k=0):
    """Score input_ids from position `start`; return dict(lps, ids, tops, cached, sec)."""
    payload = {"input_ids": ids, "sampling_params": {"max_new_tokens": 1, "temperature": 0},
               "return_logprob": True, "logprob_start_len": start}
    if top_k:
        payload["top_logprobs_num"] = top_k
    t = time.perf_counter()
    meta = post(base + "/generate", payload).get("meta_info", {})
    sec = time.perf_counter() - t
    lp = field(meta, "input_token_logprobs")
    return {"lps": [e[0] for e in lp], "ids": [e[1] for e in lp], "tops": meta.get("input_top_logprobs"),
            "cached": meta.get("cached_tokens"), "sec": sec}


def pct(values, f):
    v = sorted(values)
    return v[min(len(v) - 1, int(f * len(v)))] if v else None


def write_json(path, obj):
    from pathlib import Path
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, ensure_ascii=False) + "\n")
