#!/usr/bin/env python3
"""P7 (R2): cost of recompute vs GPU-cache hit vs restore-after-eviction (HiCache) for one SGLang server.
Usage: routes/R2-2. For each length L: cold (cache flushed -> prefix recomputed), gpu_hit (immediately
again), after_eviction (other sequences flood the cache; with HiCache the prefix comes back from host).
cached_tokens in each row shows which path the server took."""
import argparse
import concurrent.futures as cf
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sglang_api import flush, score, write_json  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--url", required=True)
    ap.add_argument("--lengths", type=int, nargs="+", default=[4096, 8192, 16384, 32768])
    ap.add_argument("--tail", type=int, default=256, help="new tokens scored in each measurement")
    ap.add_argument("--flood-tokens", type=int, default=2_000_000, help="about 1.5x the GPU KV pool size")
    ap.add_argument("--flood-seq-len", type=int, default=8192)
    ap.add_argument("--repeats", type=int, default=2)
    ap.add_argument("--label", default="")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    base, rng, rows = a.url.rstrip("/"), random.Random(a.seed), []
    for L in a.lengths:
        for rep in range(a.repeats):
            ids = [rng.randint(1000, 30000) for _ in range(L)]
            start = L - a.tail
            flush(base)
            cold = score(base, ids, start)
            hit = score(base, ids, start)
            n_flood = max(1, a.flood_tokens // a.flood_seq_len)
            flood = [[rng.randint(1000, 30000) for _ in range(a.flood_seq_len)] for _ in range(n_flood)]
            with cf.ThreadPoolExecutor(max_workers=32) as ex:
                list(ex.map(lambda s: score(base, s, len(s) - 1), flood))
            back = score(base, ids, start)
            rows.append({"L": L, "repeat": rep,
                         "cold_s": round(cold["sec"], 4), "cold_cached": cold["cached"],
                         "gpu_hit_s": round(hit["sec"], 4), "gpu_hit_cached": hit["cached"],
                         "after_eviction_s": round(back["sec"], 4), "after_eviction_cached": back["cached"]})
            print(rows[-1], file=sys.stderr)
    write_json(a.out, {"task": "R2-P7", "label": a.label, "tail": a.tail, "flood_tokens": a.flood_tokens, "rows": rows})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
