"""P3 model parts: default parameters, rollout timelines, teacher capacity (synthetic data: p3_synth.py).
See routes/R2-1 for the meaning of every parameter and how to fill it from P1/P2/P7/AR-01."""
import bisect
import csv
from collections import defaultdict

DEFAULTS = {
    "t_req": 0.002,                # s per scoring request
    "s_tok": 4e-5,                 # s per scored token (replace with P1 / P2 measurements)
    "s_attn": 0.0,                 # extra s per token per 1k cached prefix tokens
    "kv_bytes_per_token": 262144,  # teacher KV bytes per token (Qwen3-32B BF16 ~256 KiB; AR-01)
    "kv_budget_gb": 60.0,          # teacher HBM left for KV
    "chunk": 256,                  # streaming granularity in tokens
    "prompt_cached": True,         # group prompts scored once (prefix cache)
    "demote": "offload",           # offload | recompute
    "offload_gbps": 25.0,          # host<->GPU GB/s for KV (P0 / P7)
    "offload_fixed_s": 0.01,       # fixed cost per offload or restore (P7)
    "tail_k": [8, 16, 32, 64],
    "i8_start_frac": 0.5,          # i8 / oracle start once in-flight fraction <= this
    "placement": "dedicated",      # dedicated | colocated
    "n_sat": 64,                   # colocated: in-flight rollouts that saturate the GPUs
    "s_min": 0.05,                 # colocated: minimum GPU share of the teacher during decoding
}


class Rollout:
    def __init__(self, rid, group, prompt):
        self.rid, self.group, self.prompt = rid, group, prompt
        self.ns, self.ts = [0], [0.0]

    @property
    def final(self):
        return self.ns[-1]

    def t_at(self, n):
        """time when n tokens were generated (linear between checkpoints)"""
        i = bisect.bisect_left(self.ns, n)
        if i < len(self.ns) and self.ns[i] == n:
            return self.ts[i]
        n0, n1, t0, t1 = self.ns[i - 1], self.ns[i], self.ts[i - 1], self.ts[i]
        return t0 + (t1 - t0) * (n - n0) / (n1 - n0)


def load_timeline(path):
    steps = defaultdict(dict)
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            s, rid = int(row["step"]), row["rollout_id"]
            r = steps[s].get(rid) or steps[s].setdefault(rid, Rollout(rid, row.get("group_id", ""), int(row["prompt_len"])))
            r.ns.append(int(row["n_tokens"])); r.ts.append(float(row["t_s"]))
    for s in steps.values():
        for r in s.values():
            pts = sorted(set(zip(r.ns, r.ts)))
            r.ns, r.ts = [a for a, _ in pts], [b for _, b in pts]
    return steps


class Capacity:
    """C(t): GPU-seconds available to the teacher by time t (piecewise linear), and its inverse."""

    def __init__(self, rollouts, P):
        gen_end = max(r.ts[-1] for r in rollouts.values())
        if P["placement"] == "colocated":
            self.bt, self.bc, c, prev, left = [0.0], [0.0], 0.0, 0.0, len(rollouts)
            for f in sorted(r.ts[-1] for r in rollouts.values()):
                c += (f - prev) * max(P["s_min"], 1.0 - min(1.0, left / P["n_sat"]))
                self.bt.append(f); self.bc.append(c); prev = f; left -= 1
        else:
            self.bt, self.bc = [0.0, gen_end], [0.0, gen_end]

    def cap(self, t):
        bt, bc = self.bt, self.bc
        if t >= bt[-1]:
            return bc[-1] + (t - bt[-1])
        i = bisect.bisect_right(bt, t) - 1
        rate = (bc[i + 1] - bc[i]) / (bt[i + 1] - bt[i]) if bt[i + 1] > bt[i] else 1.0
        return bc[i] + (t - bt[i]) * rate

    def inv(self, cv):
        bt, bc = self.bt, self.bc
        if cv >= bc[-1]:
            return bt[-1] + (cv - bc[-1])
        i = bisect.bisect_right(bc, cv) - 1
        while i + 1 < len(bc) and bc[i + 1] == bc[i]:
            i += 1
        return bt[i] + (cv - bc[i]) * (bt[i + 1] - bt[i]) / (bc[i + 1] - bc[i])
