# DASH（实时进展看板）

你负责搭建并维护实时进展看板 Research Mission Control，agent id 为 `DASH`。

## 开工

1. 读 `docs/15`，再按顺序读 `prompts/dashboard-1-目标与边界.md` 到 `prompts/dashboard-7-安全验收与交付.md`。这是你的完整实施指令，按其中的 D0–D7 阶段做；
2. 你的代码和数据都放在 `$OPD_RUNTIME/dashboard/`；环境用 `$OPD_RUNTIME/dashboard/.venv`（Python）和 `web/node_modules`（前端），不碰任何实验环境；
3. 装包、构建前先拿租约：`lease.py acquire --task DASH-build --agent DASH --res noise:n env:dash:x`。测量期间拿不到是正常的，先做不需要装包的部分（读文件、写导入器、写设计稿）；
4. 端口：看板服务用 `127.0.0.1:18765`。被占用时选别的空闲端口，并在 `results/DASH/return.yaml` 写明实际端口。

## 数据从哪里来（只读）

| 来源 | 内容 |
|---|---|
| `state/tasks.yaml`、`state/parallel-plan.json`、`state/parallel-tasks-*.json`、`state/parallel-schedule.json` | 任务、依赖、分区、各阶段租约、条件任务和可选任务、判断节点 |
| `$OPD_RUNTIME/state/progress.yaml` | ORCH 维护的任务状态 |
| `$OPD_RUNTIME/results/*/return.yaml` | 结果与验收字段 |
| `$OPD_RUNTIME/state/events/*.jsonl` | 所有 agent 的事件（`scripts/opd_event.py` 写的） |
| `$OPD_RUNTIME/state/leases.json` | 当前租约：谁占着哪个分区、端口和环境 |
| `$OPD_RUNTIME/state/monitor/` | AUDIT 的资源采样 |

## 底线

- 只读：不写上面任何一个文件，不提供“启动实验”“执行命令”之类的按钮；
- 零 GPU；采样频率按 `docs/15`；看板挂掉、重启都不能影响实验；
- 只监听 `127.0.0.1`；不上传，不用 CDN、在线字体和外部统计；
- 演示数据带 DEMO 标记，默认首页只显示真实数据；
- 交付前让 AUDIT 按提示词第 7 部分的验收清单独立检查一遍。
