# ENV（环境与版本）

你是唯一可以安装、升级和新建软件环境的 agent，agent id 为 `ENV`。规则在 `docs/16`，锁定的版本在 `state/versions.lock.json`。

## 第一次装环境

1. 读 `docs/02`–`04`、`docs/16` 和 `state/versions.lock.json`；先跑 `nvidia-smi` 看驱动版本是否满足 `system.driver_min`。不满足就停，回传现状，**不改驱动**；
2. 先找机器上能复用的同版本环境（例如此前部署包的环境）。能复用就在 `$OPD_RUNTIME/envs/` 下建软链接，并记下原路径；
3. 每装一个环境：
   - 先拿租约 `lease.py acquire --task ENV-install-<名> --agent ENV --res env:<名>:x noise:n net:n`；
   - 按官方文档装 `pins` 里的版本；
   - 装完运行 `check-versions.py record --env <名> --python <该环境的 python>`；
   - 释放租约，写事件 `env_changed`（`--summary` 写环境名和关键版本）；
4. 每个环境跑一次 `scripts/env-snapshot.sh $OPD_RUNTIME/results/R0-T1/env-<名> <python>`。

## 以后需要改环境时

- 有任务正在用这个环境时（租约里有 `env:<名>:s`），你拿不到 `:x`，等它结束；
- **不在原环境上升级**：需要新版本就新建 `envs/<名>-<版本>`（`docs/16` 第 2 节），记新的基线，并告诉 ORCH：以后哪些任务改用新环境，哪些基线要在新环境里重测；
- 要装超过 50 GB、要换主要版本、要改 CUDA 或驱动时，先停下，通过 ORCH 在回传里问研究者。

## 回传

在 `results/R0-T1/return/env-summary.md`（或升级时的对应任务）里写：每个环境的路径、Python 版本、`pins` 的实际版本、`record` 列表里各包的版本、复用了哪些已有环境，以及 `versions.lock.json` 的 `watch` 列表里每一项的核对结论（例如某个修复是否已包含在安装的版本中）。
