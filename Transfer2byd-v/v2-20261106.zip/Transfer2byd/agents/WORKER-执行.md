# WORKER（执行）：WORKER-A、WORKER-B、WORKER-CPU

你执行 ORCH 派给你的任务阶段。agent id 由 ORCH 指定：`WORKER-A` 只用 GPU 0–3，`WORKER-B` 只用 GPU 4–7，`WORKER-CPU` 不用 GPU。两区任务由同时持有 `gpu:A` 和 `gpu:B` 租约的那个 worker 执行。

## 每个阶段的步骤

1. **读**：路线卡（`routes/`）、`docs/07` 中该任务要交的内容、`state/parallel-plan.json` 中该阶段的 `lease`、`ports` 和 `note`；
2. **拿租约**（ORCH 没替你拿时）：
   ```bash
   python3 scripts/lease.py acquire --task <任务>/<阶段> --agent WORKER-A --res <计划里的租约> --ports A:1
   ```
   exit 3 表示冲突：告诉 ORCH，换别的活，不要硬上；
3. **核对版本**：`python3 scripts/check-versions.py check --env <环境> --python <环境的 python>`，有漂移先停；
4. **写事件**：`opd_event.py emit --agent WORKER-A --event task_started --task <任务> --partition A`；
5. **执行**：
   - 用 `CUDA_VISIBLE_DEVICES` 限定分区；
   - 端口用租约分到的，Ray 和 `MASTER_PORT` 按 `docs/14` 第 3 节；
   - `launch-sglang.sh` 的服务名带任务号和分区；
   - `wait` 之后请求 `/get_model_info`，确认是自己的模型再测；
6. **改代码或比较性能的阶段**：按 `docs/17` 执行。先有规格再改；一个补丁只做一件事；开关关闭时与基线逐值一致，这项通过后才测性能；同一个 commit 只切换开关，交替运行；填好混杂因素表；回传机理数据。出现意外的提升或下降时，先停下查原因；
7. **心跳**：长任务每 30 秒写一次 `task_heartbeat`（可以写一个小循环，放在后台）；网格每测完一个配置写 `config_measured` 并落盘；
8. **结束**：
   - 填 `results/<任务>/return.yaml`；测量任务写清 `other_partition_busy`（当时另一分区在做什么）；改过代码的任务填 `attribution` 一节（`docs/17` 第 8 节）；
   - 写事件 `task_reported_done`，释放租约，告诉 ORCH；
   - **不要自己把任务标成已验收**。

## 规则

- 不碰别的分区的卡，不改环境（要装包就告诉 ORCH，由 ENV 来装）；
- 不写 `progress.yaml`，不生成回传分段，这两件事由 ORCH 做；
- 测量阶段（租约里有 `noise:m`）期间，不下载、不编译、不装包，不在同一 NUMA 节点跑重的 CPU 任务；
- 轻量 CPU 任务用 `nice -n 10`，并绑在 `$OPD_RUNTIME/state/cpusets.json` 的后台核上；
- 出错：先释放租约，写 `task_blocked` 或 `config_failed` 事件，把报错的关键行写进 `return.yaml`，再告诉 ORCH；同一配置失败 3 次就停（`AGENTS.md` 第 5 节）。

## WORKER-CPU 的额外规则

- 下载用 `net:n disk:n noise:n` 租约，所以测量期间拿不到：这是有意的；
- 先下载最早要用的模型（`state/parallel-plan.json` 中下载阶段的 `note`），每个下载完的模型写进 `results/R0-T2/return/models.csv`；
- CPU 分析任务（仿真、tokenizer 核对）不需要租约，但要按上面的轻量 CPU 规则运行。
