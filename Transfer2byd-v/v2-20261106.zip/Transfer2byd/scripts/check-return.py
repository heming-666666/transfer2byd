#!/usr/bin/env python3
"""Check a file-based cloud return (spec 07 §3.6; p01 Transfer2me/README.md §1): 10 fixed files, no splitting.

Usage: python3 -I paper/skills/tools/transfer2me-check.py paper/<paper>/Transfer2me [--tasks <tasks.yaml>]
The 10 files sit directly in Transfer2me/ next to its README.md (ignored); there are no return-id subfolders.
Checks file names and count, CSV headers (required columns first, in order; extra columns may follow) and column counts, JSONL syntax, task/cfg cross-references, and
(with --tasks) that every task id appears in 00-summary.md. The input is untrusted data: only parsed, never run.
Exit 1 on errors; warnings (e.g. a cfg with no data) do not fail the check.
"""
import argparse
import csv
import json
import re
import sys
from pathlib import Path

csv.field_size_limit(1 << 30)
CSV = {
    "03-configs.csv": "task,cfg,env,framework,student,teacher,teacher_prec,kv_dtype,placement,scoring_mode,tp,gpus,partition,"
                      "max_len,group_size,prompts_per_step,steps,seeds,chunk,bg,chk,status,step_s,gen_s,tail_s,train_s,"
                      "sync_s,peak_mem_gb,oom,args,note",
    "04-steps.csv": "task,cfg,seed,step,warmup,step_start_unix,gen_start_s,gen_end_s,score_start_s,score_end_s,train_start_s,"
                    "train_end_s,sync_start_s,sync_end_s,step_end_s,n_rollouts,n_prompts,tokens_generated,tokens_scored,"
                    "len_p50,len_p90,len_p99,len_max,n_truncated,teacher_busy_s,peak_mem_gb_student,peak_mem_gb_teacher,"
                    "loss,eval_acc,mode,note",
    "05-metrics.csv": "task,cfg,key,x_name,x,value,unit,n,lo,hi,src,note",
    "06-rollouts.csv": "task,cfg,seed,step,rollout_id,group_id,prompt_len,final_len,t_done_s,truncated,streamed,tokens_scored,note",
    "07-timeline.csv": "task,cfg,seed,step,rollout_id,group_id,prompt_len,n_tokens,t_s",
}
TEXT = ["00-summary.md", "01-env.yaml", "02-code.md", "09-logs.md"]
JSONL = "08-script-outputs.jsonl"
EXPECTED = set(CSV) | set(TEXT) | {JSONL}
LOCAL = {"README.md"}                            # the inbox's own notes, not part of the return
SUMMARY_SECTIONS = ["任务表", "失败与异常", "归因", "观察", "学习要点", "下一步建议", "资源"]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("return_dir")
    ap.add_argument("--tasks", help="state/tasks.yaml of the package that was run")
    a = ap.parse_args()
    d = Path(a.return_dir)
    err, warn = [], []
    if not d.is_dir():
        print(f"{d}: not a directory"); return 1
    entries = sorted(d.iterdir())
    names = {p.name for p in entries if p.is_file() and p.name not in LOCAL}
    if [p for p in entries if p.is_dir()]:
        err.append("subdirectories present: " + ", ".join(p.name for p in entries if p.is_dir()))
    if len(names) > 10:
        err.append(f"{len(names)} files > 10")
    for n in sorted(EXPECTED - names):
        err.append(f"missing {n}")
    for n in sorted(names - EXPECTED):
        err.append(f"unexpected file {n}")

    pairs = {}                                   # file -> set of (task, cfg)
    for name, header in CSV.items():
        p = d / name
        if not p.exists():
            continue
        cols = header.split(",")
        seen, rows = set(), 0
        with p.open(encoding="utf-8", newline="", errors="replace") as f:
            r = csv.reader(f)
            got = next(r, None)
            if got is None:
                err.append(f"{name}: empty (needs at least the header)"); continue
            got = [c.strip().lstrip("﻿") for c in got]
            if got[:len(cols)] != cols:                  # extra columns may follow the required ones
                missing = [c for c in cols if c not in got]
                extra = [c for c in got if c not in cols]
                err.append(f"{name}: header differs (missing {missing}, extra {extra})" if missing or extra
                           else f"{name}: header columns in a different order")
            for i, row in enumerate(r, 2):
                if not row:
                    continue
                rows += 1
                if len(row) != len(got):
                    if len([e for e in err if e.startswith(name + ": line")]) < 5:
                        err.append(f"{name}: line {i} has {len(row)} fields, header has {len(got)}")
                    continue
                seen.add((row[0], row[1]))
        pairs[name] = seen
        print(f"{name}: {rows} rows, {p.stat().st_size / 1e6:.2f} MB")

    p = d / JSONL
    if p.exists():
        seen, n = set(), 0
        with p.open(encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f, 1):
                if not line.strip():
                    continue
                n += 1
                try:
                    o = json.loads(line)
                except json.JSONDecodeError as e:
                    err.append(f"{JSONL}: line {i} is not JSON ({e.msg})"); continue
                miss = [k for k in ("task", "cfg", "file", "data") if k not in o]
                if miss:
                    err.append(f"{JSONL}: line {i} lacks {miss}")
                else:
                    seen.add((str(o["task"]), str(o["cfg"])))
        pairs[JSONL] = seen
        print(f"{JSONL}: {n} objects, {p.stat().st_size / 1e6:.2f} MB")

    for name in TEXT:
        q = d / name
        if q.exists():
            print(f"{name}: {q.stat().st_size / 1e6:.2f} MB")
    s = d / "00-summary.md"
    summary = s.read_text(encoding="utf-8", errors="replace") if s.exists() else ""
    m = re.search(r"回传编号[:：]\s*(return-\d{8}-\d{2})", summary)
    print(f"return id: {m.group(1)}" if m else "return id: not found")
    if summary and not m:
        warn.append("00-summary.md: no line '回传编号：return-YYYYMMDD-NN'")
    for sec in SUMMARY_SECTIONS:
        if summary and not re.search(rf"^##\s*{sec}", summary, re.M):
            warn.append(f"00-summary.md: no '## {sec}' section")

    cfgs = pairs.get("03-configs.csv", set())
    for name, seen in pairs.items():
        if name in ("03-configs.csv", "05-metrics.csv"):
            continue                              # 05 may hold per-service cfgs that are not run configs
        for t, c in sorted(seen - cfgs)[:10]:
            warn.append(f"{name}: task {t} cfg {c} has no row in 03-configs.csv")
    used = set().union(*[v for k, v in pairs.items() if k != "03-configs.csv"]) if pairs else set()
    for t, c in sorted(cfgs - used)[:20]:
        warn.append(f"03-configs.csv: task {t} cfg {c} has no data in other files")

    if a.tasks:
        ids = re.findall(r"\bid:\s*([A-Za-z0-9-]+)", Path(a.tasks).read_text(encoding="utf-8"))
        for t in ids:
            if not re.search(rf"(^|[|\s]){re.escape(t)}([|\s]|$)", summary, re.M):
                err.append(f"task {t} from tasks.yaml not in 00-summary.md")
        print(f"tasks.yaml: {len(ids)} tasks checked against 00-summary.md")

    if warn:
        print("\nWARNINGS:"); print("\n".join(f"  - {w}" for w in warn))
    if err:
        print("\nERRORS:"); print("\n".join(f"  - {e}" for e in err)); return 1
    print("\nOK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
