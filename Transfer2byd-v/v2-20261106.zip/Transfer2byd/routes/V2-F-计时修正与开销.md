# V2-F 计时补丁的修正与开销（B 分区，约 5 小时，V2-A 之前必须完成）

## 1. 要修的 bug（研究者已从 v1 回传的代码里定位）

**文件**：verl 提交 `5201401` 里的 `verl/utils/opd_timing.py`，即 v1 R1-T4 的补丁。

**现象**：R1-E1 有 95 行 `score_start_s` 是负数，而且以步长为单位往前偏。例如 c00 第 4–9 步依次是 -162、-131、-100、-69、-38、-8 s，每一步约 31 s，正好等于这个配置的步时间。

**原因**：
- `update_step_score_timing(step, score_start_unix, score_end_unix, ...)` 用 `_, t0 = _resolve_step_context()` 取起点；
- 这个上下文是**调用它的进程里最新一步**的起点（来自 `set_step_context()` 或环境变量 `OPD_TIMING_STEP_T0`），不是参数 `step` 那一步的起点；
- 打分是异步写回的，写回时 trainer 往往已经开始了后面的步，于是用错了起点。

**修法**：
1. `update_step_score_timing()` 不再调 `_resolve_step_context()`。
   - 先从 `step_breakdown.csv` 里读出 `step` 那一行的 `step_start_unix`，再换算；
   - 可以加一个 `_step_start_of(step)`，读 CSV 找到那一行；找不到就把绝对时间暂存进 `teacher_requests.csv`，等那一行写出时再补算。
   - 换算：`score_start_s = score_start_unix - step_start_unix_of_that_step`。
2. `merge_teacher_requests(step)` 已经按 step 过滤，保持不变。它返回的 min(start)、max(end) 交给上一条的新逻辑换算。
3. `_teacher_busy_s()` 和 `merge_teacher_requests()` 的 docstring 改正：并集包含排队时间，是忙碌时间的**上界**。原注释写成了 lower bound，是错的。
4. 新增 3 列，加在 `step_breakdown.csv` 末尾，不改已有列：
   - `teacher_busy_sum_s`：本步各请求 (end - start) 之和；
   - `n_teacher_requests`；
   - `score_after_gen_s` = max(0, 最后一个请求结束 − 本步 gen_end 的绝对时间)。
5. **记录方式**：一个补丁只做这一件事，单独提交，提交信息写 `V2-F: anchor score timestamps to their own step`。diff 原文放进回传的 02。

## 2. 验证（先过，再测开销）

**配置**：用 v1 的 c00（1.7B ← 8B，8K，每步 6 条，教师 1 张卡），环境 `envs/verl`，跑 2 步预热加 10 步。

**每一步都要满足**：
- `0 ≤ score_start_s ≤ score_end_s ≤ step_end_s`；
- `teacher_busy_sum_s ≥ teacher_busy_s`；
- `n_teacher_requests ≥ n_rollouts`：verl 里一条回答至少一次请求；
- 06 里每条回答的完成时刻 ≤ `gen_end_s`。

可以直接把这次运行写成临时的 04 和 06，然后运行 `scripts/sanity-check.py`。

**不满足时**：
- 有负值：看 `_step_start_of()` 读到的是不是本步那一行；
- `n_teacher_requests` 是 0：教师请求的钩子没挂上，查 agent loop 里调用 `record_teacher_request` 的位置。

## 3. 测开销

- **对照**：同一 commit、同一配置、同一种子。`OPD_TIMING=0` 和 `OPD_TIMING=1` 交替运行，顺序是 on、off、on、off，每次 2 步预热加 10 步测量。
- **计时**：`OPD_TIMING=0` 时没有 CSV，用 verl 日志里每步的 `timing_s/step`（或进度条的 s/it）。为了公平，`OPD_TIMING=1` 的运行也用同一种日志计时，CSV 只作参考。
- **结果**：`timing_overhead` = mean(on) / mean(off) − 1，两对各一个值，再给均值。差异在 ±1% 以内是正常的，照实写。

## 4. 回传

- **02**：补丁的 diff 原文。
- **03**：4 行，cfg 写 `f-on-1`、`f-off-1`、`f-on-2`、`f-off-2`。
- **04**：全部步，末尾加 3 列。
- **05**：`timing_overhead`（每对一个，再加均值）；每次运行的 `step_s`。
- **00 的归因**：
  - 只切换了 `OPD_TIMING`；
  - 交替运行了 2 对；
  - 两次同设置之间的差，可以作为噪声参考。
