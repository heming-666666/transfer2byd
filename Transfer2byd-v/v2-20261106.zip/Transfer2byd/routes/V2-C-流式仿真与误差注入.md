# V2-C 选择性流式的仿真与预测误差注入（CPU，约 2 小时）

## 要回答什么

v1 的 R2-P3 结论是“流式没用”。但那次的输入每步只有 6 条或 2 条回答，而且全部截断、同时结束，这个检验本身无效。本任务用 V2-A 的大批量时间线重新做（对应论文的 RQ3、H5-sim），回答三个问题：
1. 模式 A 里，选择性流式比“完成即打分”和 Tail-k 快多少；
2. 长度预测出错时，代价有多大；
3. 回答全部截断、同时结束时，“完成即打分”会不会退化成生成后整批打分。

## 做法

0. **最重要的输入**：`a-s-480-nothink`，它有真实的长度分布。思考模式的配置几乎全部截断，用来验证“回答同时结束时，完成即打分退化成整批打分”这一条。
1. **转时间线**：把每个 V2-A 配置的 rollout 时间线（verl 计时补丁的 `rollout_timeline.csv`，用原始粒度，不是回传用的 512 粒度）转成 `p3-i8-offline-sim.py` 读的格式（`templates/log-schemas.md` 第 2 节）。
2. **写参数**：每个配置一份参数文件，每个值写明来源：

   | 参数 | 来源 |
   |---|---|
   | `s_tok`、`t_req` | V2-A 本配置的 `teacher_tok_s`；`t_req` 用 v1 R2-P1 的 6.4 ms |
   | `kv_bytes_per_token` | 8B：147456；14B：163840；32B：262144（按模型结构算） |
   | `kv_budget_gb` | 教师服务日志里的 KV 池大小（V2-A 的 `kv_pool_tok` × 每 token 字节数） |
   | `offload_gbps`、`offload_fixed_s` | 23 和 0.08（v1 实测） |
   | `chunk` | 256 |

3. **运行**：
   ```bash
   python3 scripts/p3-i8-offline-sim.py run --timeline <tl.csv> --params <params.json> \
       --out $OPD_RUNTIME/results/V2-C/p3-<cfg>.json --noise 0 0.25 0.5
   ```
   每个配置再跑一次 `kv_budget_gb` 加倍的版本，cfg 写 `<cfg>-kv2`。

## 回传

- **02**：每个参数文件的原文和每个值的来源。
- **05**（cfg 写 V2-A 的配置名）：
  - `gain_vs_complete`、`gain_vs_best`、`oracle_gain_vs_best`；
  - 每档误差的 `noisy_gain`，x 写 0、0.25、0.5、random；
  - `worse_than_complete`：0 或 1；
  - `after_gen_s`：x 写策略名。
- **08**：每个完整 JSON 原样放入，包括 `per_step`。
