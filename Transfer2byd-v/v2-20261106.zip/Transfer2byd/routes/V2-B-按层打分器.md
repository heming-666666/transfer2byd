# V2-B 按层打分器：正确性门槛、吞吐扫描、保真度

## 要回答什么

v1 的 R3-P2 测得：SGLang 的权重卸载每次前向（最多 8,192 token）都把卸载的权重重新传一遍，传输不与计算重叠，吞吐只剩常驻的 13–45%，而且单次打分的 token 再多也不变。研究者据此提出：把一步的打分按层执行，权重从主机内存流入、每层只传一次，并预取下一层。

按命题 1 和 v1 的实测常数（有效带宽约 23 GB/s/卡），持平点预测为：Qwen3-32B 每卡每次约 **1.9 万 token**，Qwen3-30B-A3B 约 **5.5 万 token**。

本任务实测三件事：
1. 自写的按层打分器 `scripts/lm_scorer.py` 算得对不对；
2. 吞吐随单次 token 数怎样变化，持平点是多少；
3. 1/4/8 张卡同时从主机读权重时，带宽怎样分摊。

## 环境

`envs/verl-torch214-test`（torch 2.14.1，transformers 5.19.0），记作 `$PY`。权重已经由 V2-0 打包在 `/dev/shm/proctor/<模型>/`。

## B1 正确性门槛（先过，再计时）

```bash
for M in qwen3-8b qwen3-32b qwen3-30b-a3b; do
  $PY scripts/lm_scorer.py selftest --packed /dev/shm/proctor/$M --model $OPD_RUNTIME/models/<对应目录> --gpu 0 \
      --n 4 --seq-len 2048 --out $OPD_RUNTIME/results/V2-B/selftest-$M-synth.json
  $PY scripts/lm_scorer.py selftest --packed /dev/shm/proctor/$M --model $OPD_RUNTIME/models/<对应目录> --gpu 0 \
      --seqs $OPD_RUNTIME/results/R4-P4/seqs.jsonl --limit 16 --out $OPD_RUNTIME/results/V2-B/selftest-$M-real.json
done
```

- **G1**：`stream` 与 `resident` 逐值相同（max = 0）。两者只差“权重在主机还是在 GPU”，计算完全一样。
- **G2**：`stream-noprefetch` 与 `stream` 逐值相同。
- **G3**：与 Hugging Face 自己的整模型前向相比，p99 |Δ| ≤ 0.02。预期接近 0；只是 kernel 的选择可能不同。
- **不过时**：
  - G1、G2 不过：说明是打分器的 bug。可以改 `lm_scorer.py`，diff 写进 02-code，重跑全部门槛；
  - G3 不过而 G1、G2 过：先试 `--attn eager`，记录两种 attention 实现各自的结果；
  - 30B-A3B 用 HF 的 MoE 实现可能很慢，这只影响绝对吞吐，不影响门槛。在 00-summary 写明 HF MoE 相对 SGLang 常驻的吞吐比。
- 32B 的 `resident` 要把整个模型放进一张卡（65.5 GB）。selftest 用的序列短，放得下；放不下就记录 OOM，G1 改用 14B 验证。
- 权重驻留方式：`host_pinned` 必须为 true。cudaHostRegister 失败时加 `--private-pinned`，每个进程各拷一份锁页内存。

## B2 吞吐扫描

每组都跑 `resident`、`stream`、`stream-noprefetch` 三种模式，单次每卡 token 数 T 取 8192 16384 32768 65536 131072 262144 524288，每档重复 3 次：

| 组 | 模型 | 卡 | seq-len | 说明 |
|---|---|---|---|---|
| 1 | qwen3-8b、qwen3-14b、qwen3-32b、qwen3-30b-a3b | 1（GPU 0） | 4096 | B 区可以跑别的任务，在 bg 列写清 |
| 2 | qwen3-32b | 1 | 8192 | 看 attention 对持平点的影响 |
| 3 | qwen3-32b、qwen3-30b-a3b | 4（GPU 0–3） | 4096 | **整机安静**，用 hostbw 租约 |
| 4 | qwen3-32b、qwen3-30b-a3b | 8（GPU 0–7） | 4096 | 同上；只跑 `stream`，以及 32B 的 `resident`（每卡一份完整模型） |

```bash
$PY scripts/lm_scorer.py bench --packed /dev/shm/proctor/qwen3-32b --gpus 0 --mode stream \
    --tokens-per-gpu 8192 16384 32768 65536 131072 262144 524288 --seq-len 4096 --repeats 3 \
    --out $OPD_RUNTIME/results/V2-B/bench-qwen3-32b-g1-stream-s4096.json
```

- `resident` 放不下的 T（OOM）在 03 写一行，status 写 oom，然后继续下一档。
- 每个 JSON 原样放进 08。`per_gpu` 里有每卡的耗时、层计算时间、拷贝耗时（`copy_s_mean`）和有效带宽（`copy_GBps_mean`）。
- **B1 的性能门槛**：32B 在 T ≥ 65536 时，1 卡和 8 卡的 `stream` 吞吐都 ≥ 同 T 下 `resident` 的 0.8 倍。不过的话 V2-D 照样跑基线，模式 B 照样跑并如实回传，同时在 00-summary 写出瓶颈在哪里：拷贝、kernel 发射，还是 attention。

## B3 保真度

用 v1 R4-P4 的固定序列（`results/R4-P4/seqs.jsonl` 和 `seqs32b.jsonl`）做两个对比：
1. **与 SGLang 比**：
   - 用 `lm_scorer.py score --mode stream` 打分；
   - 用 SGLang TP1 常驻服务（`scripts/launch-sglang.sh`，端口按 docs/14）打同一批序列，取 `input_token_logprobs`，写法同 `p4-fidelity-compare.py`；
   - 算逐 token 的 |Δ| 统计。噪声底线是 v1 的 ref-vs-ref：8B 的 p99 为 0.111，max 为 0.806。
2. **与自身比**：`lm_scorer.py score` 的 `resident` 和 `stream` 逐值相同。

## 回传

- **03**：每组每个模式一行；cfg 写 `<模型>-g<卡数>-<模式>-s<seq-len>`。
- **05**：
  - `tok_s`：x 写每卡 T，每档一行，n、lo、hi 取 3 次重复；
  - `ratio_vs_resident`；
  - `copy_GBps`：每卡均值；
  - `peak_mem_gb`；
  - `T_star_measured`：stream ≥ 0.9 × resident 的最小 T；
  - `G1_max`、`G2_max`、`G3_p99`；
  - 保真度：`fid_p50`、`fid_p99`、`fid_max`、`fid_mean`。
- **08**：全部 selftest 和 bench 的 JSON 原样放入。
- **09**：报错、OOM、`cudaHostRegister` 的返回值。
- **00 的归因**：
  - 对照是同一份代码，只切换 `--mode`；
  - G1 证明了开关等价；
  - 机理数据：每层拷贝时间与计算时间。

## 预期（估算，用来判断结果离不离谱）

- **1 卡**：32B 的 resident 约 6,800 token/s（SGLang TP4 每卡的水平；HF 实现可能低一些）。stream 在 T ≥ 约 2 万时接近 resident；没有预取时，每次 pass 多出约 65.5 GB ÷ 55 GB/s ≈ 1.2 s。
- **8 卡同时**：每卡带宽降到 22–31 GB/s，持平点相应升到约 4–5 万 token。

## 可能的问题

| 情况 | 处理 |
|---|---|
| `pack` 时内存不够（32B 要约 65 GB 内存） | 一次只打包一个模型；关掉其他占内存的进程；记录 `free -g` 的输出 |
| `/dev/shm` 太小（`df -h /dev/shm` 小于 200 GB） | 改放本地 SSD 上的目录（`--out /data/.../proctor/<模型>`）。这时 `cudaHostRegister` 可能失败，`host_pinned` 会是 false；加 `--private-pinned`，每个进程各拷一份锁页内存（8 卡 × 65 GB = 520 GB，2 TiB 放得下），写进 00 |
| selftest 报 `TypeError`（层的调用参数） | transformers 版本差异：按报错改 `Scorer._apply` 的参数，例如去掉 `position_ids` 或 `use_cache`；diff 写进 02，再重跑 G1–G3 |
| selftest 报 `rotary_emb` 构造出错 | 改为 `type(skel.model.rotary_emb)(config=cfg)` 后再 `.to(dev)`；同上记录 |
| G1 不是 0 | 先确认 `_bind` 覆盖了全部参数和 buffer（`meta.json` 的 spec 数量等于 `len(list(layer.named_parameters())) + buffer 数`），再查两个缓冲区的事件顺序（`load()` 里先 `wait_event(free[k])`） |
| G3 的 p99 很大（> 0.1） | 用 `--attn eager` 再跑一次；仍然大，就把一条序列的逐 token 差值打印到 09，看是集中在开头、结尾还是均匀分布 |
| bench 时某档 OOM | 记 oom，继续下一档；resident 模式 32B 在单卡上本来就只能跑较小的 T |
| 吞吐随 T 不涨、stream 远低于 resident | 看 `per_gpu` 里的 `copy_s_mean` 和 `layers_s`：拷贝占大头说明带宽不够或者没 pinned；都很小但 wall 很大，说明 kernel 发射（Python）是瓶颈，把 `--micro-tokens` 调大到 65536 |
| 30B-A3B 的 resident 远慢于 SGLang | HF 的 MoE 是逐个专家循环，慢是预期的。照实写比值；时间够就试 transformers 的 grouped MoE 实现（若安装版本有），记录 |
