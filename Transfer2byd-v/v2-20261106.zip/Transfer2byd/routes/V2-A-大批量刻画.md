# V2-A 大批量刻画（A 和 B 两个分区并行，约 1–2 天；必须在 V2-F 之后）

## 1. 要回答什么

v1 的 R1-E1 每步只有 6 条回答，学生解码受延迟限制，教师最多只忙 8% 的时间。OPD 实际训练常用每步几百条回答：
- 教师的工作量随条数线性增长；
- 学生解码在大批量下变成吞吐受限。

本任务测每步 48、240、480 条回答时时间花在哪里，看教师在哪里从空闲变成瓶颈（论文第 3 节的 Takeaway 2）。同时给 V2-D 的基线挑选 GPU 划分，给 V2-C 提供有长尾的时间线。

## 2. 为什么是 48、240、480

verl 要求每步回答数能被学生的数据并行数整除（v1 的 R0-T1 撞过这个限制）。48、240、480 能被 2、3、4、8 整除，所以 2、3、4 张学生卡都能用。**回答数和长度不能自行缩小**（`docs/18` 第 1 节第 4 条）。

## 3. 配置（14 个，每个 2 步预热加 5 步测量）

| cfg | 模型对 | 每步提示数 × 每提示回答数 | 最大长度 | 教师 | 学生 | 分区 | 环境 |
|---|---|---|---|---|---|---|---|
| a-s-48 / a-s-240 / a-s-480 | 1.7B-tie-fixed ← 8B | 6 / 30 / 60 × 8 | 8192 | 1 卡，TP1 | 3 卡 | A | envs/verl |
| a-s-480-t2 | 同上 | 60 × 8 | 8192 | 2 卡（2 个 TP1 副本） | 2 卡 | A | envs/verl |
| a-s-240-16k | 同上 | 30 × 8 | 16384 | 1 卡 | 3 卡 | A | envs/verl |
| a-s-240-coloc | 同上 | 30 × 8 | 8192 | 与学生同卡（同 v1 c08） | 4 卡 | A | envs/verl |
| a-s-480-nothink | 同上，关闭思考模式 | 60 × 8 | 8192 | 1 卡 | 3 卡 | A | envs/verl |
| a-m-48 / a-m-240 / a-m-480 | 4B-tie-fixed ← 14B | 6 / 30 / 60 × 8 | 8192 | 2 卡（2 个 TP1 副本，同 v1 c09） | 2 卡 | B | envs/verl |
| a-l-48 / a-l-240 / a-l-480 | 4B-tie-fixed ← 32B | 6 / 30 / 60 × 8 | 8192 | 2 卡，TP2（1 个副本） | 2 卡 | B | envs/verl-torch214-test |
| a-l-480-tp1x2 | 同上 | 60 × 8 | 8192 | 2 卡（2 个 TP1 副本，同 v1 c05） | 2 卡 | B | envs/verl-torch214-test |

**为什么加 a-s-480-nothink**：Qwen3 开思考模式时，数学题的回答几乎全部写到上限（v1 全部截断），没有长度分布。关掉思考模式的回答有长尾，给 V2-C 和论文提供真实的长度分布。

## 4. 怎么跑：在 v1 的 `code/r1e1/grid_run.py` 基础上改

v1 的命令模板见回传 02 的 R1-E1 一节（`verl.trainer.main_ppo` 加上 Hydra 参数）。在它的 BASE 和 CONFIGS 上做下面这些改动，其余参数保持 v1 的取值：

| 参数 | 取值 | 说明 |
|---|---|---|
| `data.train_batch_size` | 6 / 30 / 60 | 每步提示数 |
| `actor_rollout_ref.rollout.n` | 8 | v1 是 1；`group_size` 列写 8 |
| `actor_rollout_ref.actor.ppo_mini_batch_size` | 等于 train_batch_size | 每步一次更新 |
| `data.max_response_length` | 8192（16k 配置用 16384） | `rollout.max_model_len` 和教师的 `max_model_len` 取 1024 + 长度 + 1 |
| `trainer.n_gpus_per_node`、`distillation.n_gpus_per_node` | 按上表 | 学生卡数、教师卡数 |
| `distillation.teacher_models.teacher_model.inference.tensor_model_parallel_size` | 1 或 2 | 按上表 |
| `distillation.teacher_models.teacher_model.inference.name` | 8B、14B 用 vllm；32B 用 sglang | 与 v1 相同 |
| rollout 显存比例 | 0.45 | 与 v1 相同；OOM 时按 `docs/18` 第 4 节的顺序调 |
| 教师显存比例 | 8B、14B 用 0.75；32B 的 TP1 用 0.90、TP2 用 0.85 | 写进 args |
| `distillation.distillation_loss.topk` | 64 | 与 v1 相同（verl 的教师给 top-64 分布） |
| 种子 | 1 | 以安装版本的配置项为准（例如 `data.seed`、`actor_rollout_ref.rollout.seed`），`data.shuffle` 保持 True，用同一个 seed 让各配置取到同样的提示顺序；写进 args |
| 思考模式（只用于 nothink） | 关闭 | verl 新版有 `data.apply_chat_template_kwargs`，传 `enable_thinking=False`。没有这个配置项，就预处理一份提示数据：用 `tokenizer.apply_chat_template(..., enable_thinking=False)` 生成，作为 train_files；做法写进 02 |
| 单次运行超时 | 4 小时 | v1 的 5400 s 不够 |

- **计时**：用 V2-F 修好的补丁，`OPD_TIMING=1`。
- **续跑**：网格脚本要支持续跑。每跑完一个配置写一行；中断后跳过已完成的配置。
- **两个分区并行**：
  - A、B 两个 worker 各跑自己那一半；
  - Ray 端口、`MASTER_PORT`、`--temp-dir` 按 `docs/14` 分开；
  - 租约名写 `V2-A/<cfg>`。

## 5. 每个配置要记的数据

- **04**：全部步，包括预热步，末尾加上 V2-F 的 3 列。
- **06**：测量步的全部回答（预热步不要），每条一行：最终长度、完成时刻、是否截断、打分 token 数。
- **07**：只取 a-s-480、a-l-480、a-s-480-nothink 三个配置的最后一个测量步，每 512 token 记一点，完成时再记一点（约 2.5 万行）。原始粒度的时间线留在云端，给 V2-C 用。
- **05**（cfg 同上）：
  - `step_s`、`gen_s`、`train_s`、`sync_s`；
  - `score_after_gen_s`，即打分尾巴；
  - `teacher_busy_frac`：用 `teacher_busy_sum_s` 和 `teacher_busy_s`（并集）各算一个，key 分别写 `teacher_busy_frac_sum`、`teacher_busy_frac_union`；
  - `teacher_tok_s` = tokens_scored ÷ teacher_busy_sum_s；
  - `student_gen_tok_s`；
  - `trunc_frac`；
  - `len_p50`、`len_p90`、`len_p99`、`len_max`；
  - `kv_pool_tok`：教师服务的启动日志里读；
  - `gpu_util_student`、`gpu_util_teacher`：最后一个测量步，用 `nvidia-smi dmon -s u -d 1` 或 pynvml 每秒采一次，x 写 t_s。
- **09**：每个配置的教师服务启动日志里关于 KV 池和显存的几行；所有 OOM 和报错。

## 6. 可能的问题

| 情况 | 处理 |
|---|---|
| 启动时报 batch 不能整除 | 检查 `train_batch_size × n` 能否被学生卡数整除，`ppo_mini_batch_size` 是否等于 train_batch_size |
| 32B 教师在 `envs/verl` 下报 undefined symbol | 用 `envs/verl-torch214-test`（v1 的 D2） |
| a-s-240-coloc 时教师和学生抢显存，OOM | 教师显存比例降到 0.35、rollout 降到 0.35；还不行就记 oom |
| 480 条的配置一步超过 20 分钟 | 正常，不要缩小；只有按前 2 步外推超过 3 小时，才测 3 步后停下 |
| nothink 的回答仍然全部截断 | 说明思考模式没关掉。查提示里是否还有 `<think>`，以及模板参数是否生效 |
| 教师忙碌时间超过步时间 | 按请求窗口算的并集重叠出错。以 `teacher_busy_sum_s ÷ 教师卡数` 为准，并在 note 里写明 |

## 7. 00 里要写的结论

- 教师从“闲”到“忙”（`teacher_busy_frac_sum` > 0.5，或打分尾巴 > 步时间的 15%）发生在哪个模型对、多少条回答；
- 480 条时，S 对 1 卡和 2 卡教师哪个快，L 对 TP2 和 2 个 TP1 副本哪个快，给 V2-D 的基线作参考；
- nothink 配置的长度分布：p50、p90、p99、截断比例。

## 8. 预期（估算，用来判断离不离谱）

- **a-l-480**：教师要打约 390 万 token。32B 每卡约 6,800 token/s，TP2 合计约 1.4 万 token/s，打完约 4.6 分钟，可能比学生生成还长。
- **a-s-48**：与 v1 接近，教师很闲。
