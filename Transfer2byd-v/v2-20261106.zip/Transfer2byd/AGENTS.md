# AGENTS.md：云端执行 agent 的入口

> **Quickstart (English)**: You run on-policy distillation (OPD) systems experiments on one node with 8× H800 and 2 TiB host RAM. Read this file, `docs/01`, `docs/02`–`04` and `docs/05`, then the route card of your task in `routes/`. Never fabricate numbers. Results go to `$OPD_RUNTIME/results/<TASK-ID>/`. When every task of this version is done, write the 10 fixed return files into `$OPD_RUNTIME/Transfer2me/` as described in `docs/06`–`07` (one return per version, no splitting, no length limit) check them with `scripts/check-return.py` and `scripts/sanity-check.py`, then convert them with `scripts/make-copysafe.py` (the researcher can only copy text by hand; docs/06 §5, docs/18). Decision rules in `docs/05` §2 let you proceed without asking. Do not change drivers, system packages, network or proxy settings, or global environment variables; never write credentials into files. The docs are in Chinese.

## 1. 你的角色

- 执行 `docs/05` 和 `state/tasks.yaml` 里的全部实验，记录可复现的信息，全部做完后按 `docs/06`、`docs/07` 一次回传；
- 可以写测量和分析代码：计时补丁、解析脚本、`lm_scorer.py` 的修正、V2-D 的接入代码。代码放 `$OPD_RUNTIME/code/`，改动写进回传的 02；
- **按判断规则推进**：`docs/05` 第 2 节和路线卡写了判断规则的，按规则走，不用等研究者；规则没覆盖的情况，先按最稳妥的办法继续，在 00-summary 写清楚你怎样处理、为什么。

## 2. 必须遵守的规则

1. **不编造**。没测的写 `not measured`；估算标明“估算”；文档或论文里的数字不能当作实测值。
2. **记录可复现信息**：git commit 与本地改动、关键包版本、完整启动命令、配置文件、随机种子、GPU 编号、开始和结束时间（北京时间）、原始日志路径。每个任务都跑一次 `scripts/env-snapshot.sh`。
3. **GPU 分区**：A = GPU 0–3，B = GPU 4–7，用 `CUDA_VISIBLE_DEVICES` 隔离。两个分区可以同时跑不同任务；标为 `both` 的任务要等两个分区都空闲。用主机带宽的测量（V2-B 的多卡扫描、V2-D、V2-E）要整机安静，在 03 的 bg 列注明。
4. **不改全局配置**：驱动、系统包、内核参数、网络与代理设置、全局环境变量都不改。需要时停下来，在回传里说明原因。
5. **不碰凭据**：API key、token、密码不写进任何文件、日志或回传。
6. **下载要克制**：只下载 `docs/04` 列出的模型和数据，记录来源和版本；其他下载先问。
7. **遵守所在单位的规定**：回传里只放实验数据和自己写的代码摘要，不放单位的内部资料。
8. **长任务能续跑**：网格实验每完成一个配置写一行结果，中断后跳过已完成的配置。
9. **进度记录**：在 `$OPD_RUNTIME/state/progress.yaml` 记录每个任务的状态（`todo`、`running`、`done`、`partial`、`blocked`）、开始和结束时间、结果目录。
10. **预算**：某个任务超过预计时间 2 倍还没有结果，就停下这个任务，记录现状，继续别的任务，在 00-summary 写清楚。
11. **编程代理写的代码要声明**：在 01-env 的 code 一节和 02 里写清哪些代码由 agent 编写，投稿时需要声明。

## 3. 阅读顺序

| 你要做的 | 先读 | 再读 |
|---|---|---|
| 第一次接手 | 本文件、`README.md`、`docs/01`、`docs/18`（v1 的数据问题，必读） | `docs/02`–`05`、`docs/12` |
| 某条路线的任务 | `routes/` 中对应的实验卡 | `docs/08`、`09` 中对应的知识和文献 |
| 回传 | `docs/06`、`07`、`18` | `scripts/check-return.py`、`sanity-check.py`、`make-copysafe.py`、`show-lines.py` |
| 出错 | `docs/11` | 路线卡的“已知问题” |

## 4. 任务协议

1. 按 `docs/05` 的顺序选任务：依赖已完成、优先级最高。A、B 两个分区可以各跑一个。
2. 按路线卡执行。原始输出放 `$OPD_RUNTIME/results/<TASK-ID>/`。
3. 复制 `templates/task-return.yaml` 到 `results/<TASK-ID>/return.yaml`，逐项填写。这份任务记录留在云端，供 AUDIT 和汇总回传用。
4. 更新 `progress.yaml`。
5. 不分批回传。全部任务做完（可选的 V2-E 视时间而定）后，按 `docs/18` 第 3 节的顺序交付：写出 `$OPD_RUNTIME/Transfer2me/` 下的 10 个文件 → `check-return.py` OK → `sanity-check.py` OK（解释不了的例外写进 00）→ `make-copysafe.py` 转成 10 个 `.txt` → 告诉研究者回传编号和每个 `.txt` 的行数、字数。研究者在纯文本界面里复制；要补抄时用 `show-lines.py` 显示指定的行（`docs/06` 第 5 节）。
6. 收到新版本（`VERSION` 变了）时，先运行 `scripts/verify-package.py`，再读 `CHANGELOG.md`，按新的任务清单继续；已完成的任务不用重做，除非 CHANGELOG 要求重跑。

## 5. 什么时候停下来

- 同一配置反复 OOM 或崩溃 3 次以上；
- 结果和路线卡里的“预期”差了一个数量级；
- 需要 sudo、改全局配置，或者下载清单以外超过 50 GB 的文件；
- 需要改 verl、slime、SGLang 的核心逻辑（只加日志不算；V2-D 的接入只改教师 URL 与配置，按其实验卡执行）；
- 机器或网络出问题：只记录报错和受影响的步骤，不去改网络或代理设置。

## 6. 编号约定

- v2 的任务编号是 `V2-0`、`V2-A` … `V2-F`；v1 的编号（`R0-P0`、`R1-E1` 等）只在引用 v1 结果时用；
- T = 基础任务，P = 测量与最小实验，E = OPD 实验；
- 此前部署实验包（llm-serving-lab）的实验编号是 E01–E24、AR-01–AR-10，引用时写全称，不要和本包的编号混用。
