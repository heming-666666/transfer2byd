#!/usr/bin/env python3
"""dash: v4 的实时看板。只用 Python 3.10 标准库，不装任何包，不需要构建。

    dash.py collect [--interval 2]      # 后台采集：合并各运行的 progress.json、任务状态、GPU，写 dashboard/state.json
    dash.py serve [--port 30390]        # 只监听 127.0.0.1，提供 dashboard/index.html 和 state.json
    dash.py tui [--interval 2]          # 终端版（tmux 窗口里直接看）
    dash.py once                        # 采集一次并打印终端版（离线快照）

数据都来自 $OPD_RUNTIME：results/v4/<任务>/<run_id>/progress.json（启动器写）、run.json、
state/tasks-status.json（可选，主窗写）、包里的 state/manifest.json（任务清单）。
超过 --stale 秒（默认 90）没有更新的运行标“可能卡住”。性能测量期间 GPU 采样放慢到 --gpu-interval 秒。
"""
from __future__ import annotations

import argparse
import http.server
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
SMI = os.environ.get("OPD_NVIDIA_SMI", "nvidia-smi")


def rt():
    r = os.environ.get("OPD_RUNTIME", "")
    if not r:
        sys.exit("没有设置 OPD_RUNTIME")
    return r


def load(path, default=None):
    try:
        with open(path, encoding="utf-8") as h:
            return json.load(h)
    except (OSError, ValueError):
        return default


def atomic(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp.{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as h:
        h.write(text)
    os.replace(tmp, path)


def gpus():
    try:
        r = subprocess.run([SMI, "--query-gpu=index,utilization.gpu,memory.used,memory.total,power.draw",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=15)
        out = []
        for line in r.stdout.strip().splitlines():
            c = [x.strip() for x in line.split(",")]
            if len(c) >= 5:
                out.append({"gpu": c[0], "util": c[1], "mem_mb": c[2], "mem_total_mb": c[3], "power_w": c[4]})
        return out
    except (OSError, subprocess.SubprocessError):
        return []


def collect_once(stale=90.0, gpu_cache=None):
    root = os.path.join(rt(), "results", "v4")
    now = time.time()
    runs = []
    if os.path.isdir(root):
        for task in sorted(os.listdir(root)):
            tdir = os.path.join(root, task)
            if not os.path.isdir(tdir):
                continue
            for rid in sorted(os.listdir(tdir)):
                p = load(os.path.join(tdir, rid, "progress.json"))
                if not p:
                    continue
                age = now - float(p.get("t", 0))
                live = p.get("phase") in ("starting", "pre_idle", "running")
                step, total = p.get("step"), p.get("steps_total")
                eta = None
                if live and step and total and p.get("last_step_s"):
                    eta = round((total - step) * p["last_step_s"])
                runs.append({"task": task, "run_id": rid, "cfg": p.get("cfg"), "phase": p.get("phase"), "step": step,
                             "steps_total": total, "last_step_s": p.get("last_step_s"), "age_s": round(age, 1),
                             "elapsed_s": round(now - float(p.get("t_start", now))) if live else None,
                             "eta_s": eta, "gpus": p.get("gpus", []), "live": live,
                             "stuck": bool(live and age > stale), "note": p.get("note", "")})
    man = load(os.path.join(PKG, "state", "manifest.json"), {}) or {}
    status = load(os.path.join(rt(), "state", "tasks-status.json"), {}) or {}
    tasks = []
    for t in man.get("tasks", []):
        mine = [r for r in runs if r["task"] == t["id"]]
        st = status.get(t["id"], {}).get("status") or ("running" if any(r["live"] for r in mine) else
                                                        ("has-runs" if mine else "todo"))
        tasks.append({"id": t["id"], "title": t.get("title", ""), "tier": t.get("tier", ""), "status": st,
                      "runs": len(mine), "ok": sum(1 for r in mine if r["phase"] == "done"),
                      "bad": sum(1 for r in mine if r["phase"] in ("fail", "oom", "killed"))})
    owner = {}
    for r in runs:
        if r["live"]:
            for g in r["gpus"]:
                owner[str(g)] = f"{r['task']}/{r['cfg']}"
    g = gpu_cache if gpu_cache is not None else gpus()
    for x in g:
        x["owner"] = owner.get(x["gpu"], "")
        try:
            x["idle_held"] = bool(x["owner"] and float(x["util"]) < 5 and float(x["mem_mb"]) > 1500)
        except ValueError:
            x["idle_held"] = False
    measuring = any(r["live"] for r in runs)
    research = load(os.path.join(PKG, "state", "research-status.json"), {}) or {}
    return {"research": research, "t": now, "t_text": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now)), "runs": runs, "tasks": tasks,
            "gpus": g, "measuring": measuring, "stale_s": stale}


def render(state):
    out = [f"OPD v4 看板  {state['t_text']}  （运行中 {sum(1 for r in state['runs'] if r['live'])}）", ""]
    rs = state.get("research") or {}
    if rs.get("core_claim"):
        c = rs["core_claim"]
        out.append(f"核心创新点：{c.get('title', '')}（{c.get('status', '')}）")
        nxt = [m for m in rs.get("milestones", []) if m.get("state") != "done"][:3]
        if nxt:
            out.append("接下来的节点：" + "；".join(f"{m['date']} {m['what']}" for m in nxt))
        out.append("")
    if state["tasks"]:
        out.append("任务：" + "  ".join(f"{t['id']}[{t['status']} {t['ok']}/{t['runs']}]" for t in state["tasks"]))
        out.append("")
    live = [r for r in state["runs"] if r["live"]]
    for r in live:
        step, total = r["step"] or 0, r["steps_total"] or 0
        frac = min(1.0, step / total) if total else 0.0
        bar = "#" * int(frac * 30) + "." * (30 - int(frac * 30))
        eta = f" 剩约 {r['eta_s'] // 60} 分" if r["eta_s"] is not None else ""
        flag = "  !! 可能卡住（%d 秒没更新）" % r["age_s"] if r["stuck"] else ""
        out.append(f"{r['task']:<8}{(r['cfg'] or ''):<22}[{bar}] {step}/{total or '?'} {r['phase']}"
                   f" 卡 {','.join(map(str, r['gpus'])) or '-'}{eta}{flag}")
    if not live:
        out.append("（没有正在运行的实验）")
    done = [r for r in state["runs"] if not r["live"]][-8:]
    if done:
        out += ["", "最近结束：" + "  ".join(f"{r['task']}/{r['cfg']}={r['phase']}" for r in done)]
    if state["gpus"]:
        out += ["", "GPU  利用率  显存MB   功率W  归属"]
        for g in state["gpus"]:
            warn = "  !! 占着显存但空转" if g.get("idle_held") else ""
            out.append(f"{g['gpu']:>3}  {g['util']:>5}%  {g['mem_mb']:>6}  {g['power_w']:>6}  {g['owner']}{warn}")
    return "\n".join(out)


def cmd_collect(a):
    path = os.path.join(rt(), "dashboard", "state.json")
    cache, t_gpu = [], 0.0
    while True:
        st = collect_once(a.stale, cache)
        gi = a.gpu_interval if st["measuring"] else min(a.gpu_interval, 15)
        if time.time() - t_gpu >= gi:
            cache, t_gpu = gpus(), time.time()
            st = collect_once(a.stale, cache)
        atomic(path, json.dumps(st, ensure_ascii=False))
        if a.once:
            return 0
        time.sleep(a.interval)


def cmd_serve(a):
    state_path = os.path.join(rt(), "dashboard", "state.json")
    page = os.path.join(PKG, "dashboard", "index.html")

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            path = self.path.split("?")[0]
            if path in ("/", "/index.html"):
                body, ctype = open(page, "rb").read(), "text/html; charset=utf-8"
            elif path == "/state.json":
                try:
                    body = open(state_path, "rb").read()
                except OSError:
                    body = b'{"runs":[],"tasks":[],"gpus":[],"t_text":"collector not running"}'
                ctype = "application/json; charset=utf-8"
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", a.port), H)
    print(f"看板：http://127.0.0.1:{a.port}/ （只监听本机；远程查看用 ssh -L 转发）", flush=True)
    srv.serve_forever()


def cmd_tui(a):
    while True:
        st = collect_once(a.stale)
        sys.stdout.write("\x1b[2J\x1b[H" + render(st) + "\n")
        sys.stdout.flush()
        time.sleep(a.interval)


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("collect", "serve", "tui", "once"):
        p = sub.add_parser(name)
        p.add_argument("--interval", type=float, default=2.0)
        p.add_argument("--gpu-interval", type=float, default=30.0)
        p.add_argument("--stale", type=float, default=90.0)
        p.add_argument("--port", type=int, default=30390)
        p.add_argument("--once", action="store_true")
    a = ap.parse_args(argv)
    if a.cmd == "collect":
        return cmd_collect(a)
    if a.cmd == "serve":
        return cmd_serve(a)
    if a.cmd == "tui":
        return cmd_tui(a)
    print(render(collect_once(a.stale)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
