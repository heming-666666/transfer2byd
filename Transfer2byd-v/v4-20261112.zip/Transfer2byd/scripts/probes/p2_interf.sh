#!/usr/bin/env bash
# V4-P2 一格：同卡打分对学生生成的干扰。四种情形：满载/尾部 × 打分关/开（打分 = 32B 教师按层流式，循环打同一批序列）。
# 用法（经 opd_run.py，--gpus 1）：bash p2_interf.sh <满载并发，默认 240> <学生引擎显存占比，默认 0.40> <教师，默认 qwen3-32b>
source "$(dirname "$0")/common.sh"
FULL="${1:-240}"; MEM="${2:-0.40}"; TEA="${3:-qwen3-32b}"; TAIL=$((FULL / 4))
trap 'kill $(jobs -p) 2>/dev/null || true; stop_engine' EXIT
start_engine "$MEM"; M="$(model_name)"
gb() { "$OPD_PY" "$PKG/scripts/gen_bench.py" --url "http://127.0.0.1:$PORT" --model "$M" --prompts "$OPD_PROMPTS" \
        --concurrency "$1" --n "$2" --max-tokens 8192 --temperature "$OPD_TEMP" --top-p "$OPD_TOPP" --out "$RUN/gen-$3.json"; }
score_loop() {   # 一直打分直到被杀；每次一行时间统计进 score-loop.jsonl
  while true; do "$OPD_PY" "$OPD_SCORER" score --packed "$OPD_PACKED/$TEA" --gpus 0 --mode stream --seqs "$OPD_SEQS" --limit 64 \
      --out "$RUN/score-tmp.jsonl" 2>>"$RUN/score-loop.err" | tr -d '\n' >> "$RUN/score-loop.jsonl"; echo >> "$RUN/score-loop.jsonl"; done
}
echo "step 1/4"; gb "$FULL" "$FULL" full-off
echo "step 2/4"; gb "$TAIL" "$TAIL" tail-off
score_loop & SL=$!; sleep 60     # 等打分进入稳态（第一次要映射主机内存、登记 pinned）
echo "step 3/4"; gb "$FULL" "$FULL" full-on
echo "step 4/4"; gb "$TAIL" "$TAIL" tail-on
kill $SL 2>/dev/null || true
