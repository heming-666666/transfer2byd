#!/usr/bin/env bash
# v4 包自测：只写一个临时目录，不碰 GPU、tmux、凭证。用法：bash tests/selftest.sh
# 全部通过时最后一行是 "SELFTEST OK n/n"，退出码 0。
set -u
PKG="$(cd "$(dirname "$0")/.." && pwd)"
S="$PKG/scripts"
T="$(mktemp -d)"
PASS=0; FAIL=0
ok() { PASS=$((PASS+1)); echo "  ok   $1"; }
bad() { FAIL=$((FAIL+1)); echo "  FAIL $1"; }
chk() { if eval "$2" >/dev/null 2>&1; then ok "$1"; else bad "$1"; fi; }

echo "[1] 语法"
for f in opd_run gpu_sampler dash preflight snapshot gen_bench engine_scan swap_bench ret_extra ret_md pool_bench; do
  chk "py_compile $f.py" "python3 -I -m py_compile '$S/$f.py'"
done

echo "[2] 启动器（替身 nvidia-smi）"
mkdir -p "$T/bin" "$T/rt"
cat > "$T/bin/smi" <<'PY'
#!/usr/bin/env python3
import sys
q=[a for a in sys.argv if a.startswith('--query-gpu=')]
f=q[0].split('=')[1].split(',') if q else []
for i in range(4):
    v={'index':str(i),'uuid':'GPU-t%d'%i,'power.draw':'90.5','utilization.gpu':'0','memory.used':'10','memory.total':'81559','temperature.gpu':'40','power.limit':'400.00'}
    print(', '.join(v[x] for x in f))
PY
chmod +x "$T/bin/smi"
export OPD_NVIDIA_SMI="$T/bin/smi" OPD_NO_NVML=1 OPD_RUNTIME="$T/rt"
unset OPD_GPU_LEASE
python3 -I "$S/opd_run.py" --task V4-0 --cfg st-a --run-id st-a --role smoke --gpus 1 --steps-total 3 --pre-idle 0.6 --min-free-gb 0.1 \
  --gpu-roles 'student=0' -- bash -c 'for i in 1 2 3; do echo "step $i/3"; sleep 0.3; done' >"$T/a.out" 2>&1
chk "运行成功" "grep -q 'status=ok' '$T/a.out'"
R="$T/rt/results/v4/V4-0/st-a"
for f in run.json run.log gpu.csv progress.json step_marks.jsonl SHA256SUMS; do chk "产生 $f" "test -s '$R/$f'"; done
chk "步号识别到 3" "grep -q '\"steps_seen\": 3' '$R/run.json'"
chk "进度为 done" "grep -q '\"phase\": \"done\"' '$R/progress.json'"
chk "索引追加" "grep -q 'st-a' '$T/rt/results/v4/results-index.jsonl'"
python3 -I "$S/opd_run.py" --task V4-0 --cfg st-a --run-id st-a --gpus 1 --min-free-gb 0.1 -- true >"$T/b.out" 2>&1
chk "拒绝覆盖已有目录（退出码 94）" "test $? -eq 94"
OPD_GPU_LEASE=external CUDA_VISIBLE_DEVICES=2 python3 -I "$S/opd_run.py" --task V4-0 --cfg st-c --run-id st-c --gpus 2 --min-free-gb 0.1 -- true >"$T/c.out" 2>&1
chk "外部卡锁下卡不够时报错（退出码 91）" "test $? -eq 91"
OPD_GPU_LEASE=external CUDA_VISIBLE_DEVICES=2,3 python3 -I "$S/opd_run.py" --task V4-0 --cfg st-d --run-id st-d --gpus 2 --pre-idle 0 --min-free-gb 0.1 -- bash -c 'echo "CUDA out of memory"; exit 1' >"$T/d.out" 2>&1
chk "OOM 判定" "grep -q '\"status\": \"oom\"' '$T/rt/results/v4/V4-0/st-d/run.json'"
chk "外部卡锁记录" "grep -q '\"lease\": \"external\"' '$T/rt/results/v4/V4-0/st-d/run.json'"
( python3 -I "$S/opd_run.py" --task V4-0 --cfg par-a --run-id par-a --gpus 1 --pre-idle 0 --min-free-gb 0.1 -- bash -c 'echo a > $OPD_RUN_DIR/out.txt; sleep 0.5' >/dev/null 2>&1 &
  python3 -I "$S/opd_run.py" --task V4-0 --cfg par-b --run-id par-b --gpus 1 --pre-idle 0 --min-free-gb 0.1 -- bash -c 'echo b > $OPD_RUN_DIR/out.txt; sleep 0.5' >/dev/null 2>&1 & wait )
chk "并行两个运行互不覆盖" "test \"\$(cat '$T/rt/results/v4/V4-0/par-a/out.txt')\" = a -a \"\$(cat '$T/rt/results/v4/V4-0/par-b/out.txt')\" = b"
chk "并行两个运行分到不同的卡" "test \"\$(grep -A2 gpu_ids '$T/rt/results/v4/V4-0/par-a/run.json' | tr -d ' \n')\" != \"\$(grep -A2 gpu_ids '$T/rt/results/v4/V4-0/par-b/run.json' | tr -d ' \n')\""

echo "[3] 看板、预检、回传表"
chk "看板 once" "python3 -I '$S/dash.py' once | grep -q 'OPD v4'"
chk "预检通过" "python3 -I '$S/preflight.py' --task V4-0 --need-gpus 1 --need-free-gb 0.1 --need-module json"
chk "预检发现缺路径" "! python3 -I '$S/preflight.py' --task V4-0 --need-free-gb 0.1 --need-path /no/such/path"
mkdir -p "$T/ret"
chk "ret_extra 生成两张表" "python3 -I '$S/ret_extra.py' --results '$T/rt/results/v4' --out '$T/ret' && test -s '$T/ret/10-runs.csv' -a -s '$T/ret/11-energy.csv'"
chk "10-runs 含失败的运行" "grep -q ',oom,' '$T/ret/10-runs.csv'"
chk "11-energy 有空闲窗口" "grep -q ',pre_idle,' '$T/ret/11-energy.csv'"
printf '[2026-11-10 17:40:01] Decode batch. #running-req: 23, #token: 187232, token usage: 0.61, gen throughput (token/s): 5123.4, #queue-req: 217\n' > "$T/sg.log"
chk "engine_scan 认出样例行" "python3 -I '$S/engine_scan.py' --log '$T/sg.log' --out '$T/eng.csv' | grep -q 'running_mean=23.0'"
chk "engine_scan 无引擎行时退出码 3" "echo x > '$T/no.log'; python3 -I '$S/engine_scan.py' --log '$T/no.log' --out '$T/e2.csv'; test \$? -eq 3"

echo "[3b] 教师池探针（假打分器）"
mkdir -p "$T/pool"
for t in a:16:36 b:30:40 c:66:64; do n=${t%%:*}; r=${t#*:}; gb=${r%%:*}; L=${r#*:}; mkdir -p "$T/pool/$n"
  echo "{\"n_layers\": $L, \"host_gb\": $gb, \"layer_bytes\": $((gb * 1000000000 / L))}" > "$T/pool/$n/meta.json"; done
python3 -I -c "
import json,random
random.seed(0)
with open('$T/pool/seqs.jsonl','w') as h:
    for i in range(12): h.write(json.dumps({'ids':[random.randint(1,999) for _ in range(random.randint(50,300))],'start':20})+'\n')"
chk "pool_bench 两个教师三臂都放得下、分数一致" "OPD_POOL_FAKE=1 python3 -I '$S/pool_bench.py' --gpu 0 --seqs '$T/pool/seqs.jsonl' --teachers '$T/pool/a,$T/pool/b' --repeats 1 --out '$T/pool/o2.json' && python3 -I -c \"import json;r=json.load(open('$T/pool/o2.json'))['repeats'][0];assert all(v['status']=='ok' for v in r['arms'].values()) and r['maxdiff_M_vs_R']==0\""
chk "pool_bench 三个教师时常驻放不下、教师池放得下" "OPD_POOL_FAKE=1 python3 -I '$S/pool_bench.py' --gpu 0 --seqs '$T/pool/seqs.jsonl' --teachers '$T/pool/a,$T/pool/b,$T/pool/c' --repeats 1 --out '$T/pool/o3.json' && python3 -I -c \"import json;a=json.load(open('$T/pool/o3.json'))['repeats'][0]['arms'];assert a['R']['status']=='oom' and a['M']['status']=='ok'\""
for f in "$S"/probes/*.sh; do chk "bash -n $(basename "$f")" "bash -n '$f'"; done
chk "manifest 是 orch-manifest/1，任务与 tasks.yaml 一致" "python3 -I -c \"
import json,re
m=json.load(open('$PKG/state/manifest.json')); assert m['schema']=='orch-manifest/1'
ids={i['id'] for i in m['items'] if i['kind']=='task'}
y=set(re.findall(r'- \\{id: (V4-[A-Z0-9]+),', open('$PKG/state/tasks.yaml').read()))
assert ids==y, (ids^y)
assert {'DASH','AUDIT','RTRN','ENV','SNAP'} <= {i['id'] for i in m['items'] if i['kind']=='role'}\""
chk "看板读到研究进展" "python3 -I '$S/dash.py' once | grep -q '核心创新点'"

echo "[4] 回传容器"
printf '# 标题\n\n```diff\n-a\n+b\n```\n行尾空格  \n\ttab\n“弯引号”\n' > "$T/ret/02-code.md"
python3 -I -c "open('$T/ret/08-x.jsonl','w').write('{\"k\":\"'+'y'*70000+'\"}\n')"
chk "pack（含回读核对）" "python3 -I '$S/ret_md.py' pack --in '$T/ret' --out '$T/md' --ret-id st-20261112-01"
chk "每块不超过 30000 字" "python3 -I -c \"
import re,glob
m=max(len(b) for f in glob.glob('$T/md/*.md') for b in re.findall(r'\x60\x60\x60\x60text\n(.*?)\n\x60\x60\x60\x60',open(f,encoding='utf-8').read(),flags=re.S))
assert m<=30000\""
cat "$T"/md/*.md | grep -v '^README' > "$T/all.txt"
chk "unpack 还原" "python3 -I '$S/ret_md.py' unpack '$T/all.txt' --out '$T/un'"
chk "还原逐字节相同" "for f in '$T'/ret/*; do cmp -s \"\$f\" '$T/un/'\$(basename \"\$f\") || exit 1; done"
python3 -I -c "
t=open('$T/all.txt',encoding='utf-8').read(); i=t.index('yyyyyyyy')+100; open('$T/bad.txt','w',encoding='utf-8').write(t[:i]+'Z'+t[i+1:])"
chk "改一个字被发现（退出码 1）" "python3 -I '$S/ret_md.py' unpack '$T/bad.txt' --out '$T/un2'; test \$? -eq 1"

echo "SELFTEST $([ $FAIL -eq 0 ] && echo OK || echo FAILED) $PASS/$((PASS+FAIL))"
[ $FAIL -eq 0 ]
