# OPD 实验包 v4（2026-11-12）

给云端 8×H800 机器的第四版实验包。依据 v3 的回传（return-20261111-01）设计。

## 这一版的核心

**多教师在线策略蒸馏的主机内存教师池**：所有教师留在主机内存，按层流过学生自己的卡打分，把教师占的卡还给学生。V4-P1–P4 先验证它会不会不成立，V4-F、F8 是它在单教师时的端到端情形。

## 先读

1. `AGENTS.md`：入口和规则；
2. `docs/00-v4先读这一篇.md`：这一版要回答什么、代码规则、统一启动器、并行、文件安全、看板、回传；
3. `docs/05-实验步骤总览.md`、`state/tasks.yaml`：任务、卡数、能否并行、依赖；
4. 你的任务的路线卡 `routes/V4-*.md`；
5. 回传时读 `docs/06`、`07`、`20`。
6. 想知道为什么这样安排：`docs/21`（从 v1 到 v4 的过程）、`22`（候选想法）、`23`（基础概念）、`24`（架构）。

## 这一版和 v3 的不同

- **代码由研究者写，云端只执行**。包里的脚本不要改；v3 时云端写的运行脚本先冻结再用，只改路线卡点名的参数（`docs/00` 第 2 节）。
- **每个实验都通过 `scripts/opd_run.py` 启动**：`--gpus N` 选卡数，结果各写各的目录，自动记能耗和进度。
- **看板随包带来**，不用安装和构建，进度由实验进程自己报（`docs/15`）。
- **回传容器换成带校验的 markdown 代码块**，每块不超过 3 万字（`scripts/ret_md.py`，`docs/06`）；内容仍是 v3 的 10 个文件，加 4 个新文件。
- **每条判据先写理论上界**。

## 目录

| 路径 | 内容 |
|---|---|
| `docs/` | 00 是 v4 的总规则；05–07、13、15、18、20 已按 v4 更新；21–24 是新增的说明；其余沿用 |
| `routes/` | v4 的 11 张路线卡（`V4-P` 是核心探针）；`v3-参考/` 是 v3 的卡，只在查判据原文时用 |
| `state/` | `tasks.yaml`、`manifest.json`（任务与角色清单）、`parallel-plan.json`、`versions.lock.json`、`assets-manifest.json` |
| `scripts/` | 新增：`opd_run.py`、`gpu_sampler.py`、`dash.py`、`preflight.py`、`snapshot.py`、`gen_bench.py`、`engine_scan.py`、`swap_bench.py`、`ret_extra.py`、`ret_md.py`；沿用：`lm_scorer.py`、`lm_server.py`、`eval_metrics.py`、`check-return.py`、`lease.py` 等 |
| `dashboard/index.html` | 看板页面（单个文件） |
| `tests/selftest.sh` | 包自测，V4-0 第 1 步运行 |
| `agents/`、`prompts/`、`templates/` | 沿用。`prompts/dashboard-*` 已不需要（看板不用再搭），保留只为对照 |

不再使用的脚本：`make-copysafe.py`、`show-lines.py`（被 `ret_md.py` 代替）。
