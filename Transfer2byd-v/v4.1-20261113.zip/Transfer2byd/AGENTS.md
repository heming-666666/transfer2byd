# AGENTS.md：云端执行 agent 的入口（v4.1）

> **Quickstart (English)**: You run on-policy distillation (OPD) systems experiments on one node with 8× H800 and 2 TiB host RAM. This is package v4.1, a completion package for v4: tasks finished in v4 are detected from their result files and skipped; the rest follow the v4 route cards. Before anything else, check that the cloud orchestration skill is version 2.0.0 (`skill/README.md`); GPUs are allocated **only** by the skill's `orchd` daemon from `state/manifest.json` (orch-manifest/2) — never pick GPUs or set `CUDA_VISIBLE_DEVICES` yourself, run GPU commands of agent tasks through `orchd.py exec`, and stop processes only with `orchd.py kill` / `own_cleanup`. Results go to `$OPD_RUNTIME/results/v4/` (major version). Read `docs/00-v4.1先读这一篇.md` first, then `routes/V41-总览与门控.md` and the route card of your task. Returns: small return v4a (`docs/25`, 12 files) and full return (`docs/06`, 17 files), both packed with `scripts/ret_md.py`. Never fabricate numbers (`NA:reason`); do not change drivers, system packages, network or proxy settings, or global environment variables; never write credentials into files. The docs are in Chinese.

## 1. 你的角色

- 你是某个任务的执行者（子窗），或主窗（只掌控全局）。
  - 主窗照云端 skill 2.0.0 的 `SKILL.md`、`references/main-loop.md` 与 `references/manual.md` 做；
  - 子窗照 orchd 自动生成的任务书（skill 的 `brief.py`：执行、修复、验收、判断四种）和本包的路线卡做。
- 卡、启动、修复窗、验收窗、关窗都由 orchd 自动做；出了状况怎么办见 skill 的 `references/manual.md` 第 6 节与本包 `routes/V41-总览与门控.md` 第 9 节。
- 一个任务一扇窗；做完交报告、写 `report` 事实，窗会被关掉。进展逐步追加到上下文卡 `notes/ctx/<窗>.md`。

## 2. 必须遵守的规则

1. **不编造**。没测的写 `NA:原因`；估算标明“估算”；文档或论文里的数字不能当作实测值。
2. **卡只由 orchd 分**。agent 任务的 GPU 命令一律 `python3 -I $ORCH_BIN exec --td $ORCH_TD <任务> -- <命令>`；租到的卡与端口段看 `orchd.py env`。
3. **只动自己的进程**：停进程只用 `orchd.py kill <自己的任务>` 或 `own_cleanup`；不用 `ray stop`、`pkill`；看见不是自己启动的进程写进报告，不碰。
4. **端口**：从 `scripts/v41/env.sh` 的端口段取（`ray_head_start`、`port`），不写死端口（`docs/26` 第 2 节）。
5. **记录可复现信息**：完整启动命令、配置、种子、GPU 编号、开始结束时间（北京时间）、原始日志路径；每个实验经 `scripts/opd_run.py` 启动（`docs/00` 第 4 节）。
6. **不改全局配置**：驱动、系统包、内核参数、网络与代理设置、全局环境变量都不改；需要的环境变量只设在本运行里（`scripts/v41/env.sh`）。
7. **不碰凭据**：API key、token、密码不写进任何文件、日志或回传。
8. **包里的脚本不改**；冻结的运行脚本只许改路线卡点名的参数与“CLI 语法、环境变量”（版本适配、端口段），改动写进 02 的 diff。
9. **长任务能续跑、能并行**：网格每完成一格写一行结果；`scripts/v41/tasks/*.sh` 会跳过已完成的格。一组独立的格用 skill 的 `cellrun.py` 按租到的卡并行跑（1/2/4/8 卡都能跑，skill R35）。
10. **弯路与 skill 问题都要记**：花了 10 分钟以上的非实验问题写进报告的“给后来者的经验”（汇总成 14-detours.md）；skill 本身的问题用 `skill_feedback.py add`（skill R29）。
11. **编程代理写的代码要声明**：在 01-env 的 code 一节和 02 里写清哪些代码由 agent 编写。

## 3. 阅读顺序

| 你要做的 | 先读 | 再读 |
|---|---|---|
| 第一次接手（主窗） | `skill/README.md`（skill 版本）、`docs/00-v4.1先读这一篇.md`、`routes/V41-总览与门控.md` | `docs/13`、`docs/26`、skill 的 `references/main-loop.md` |
| 某个任务（子窗） | 任务书、`routes/` 中对应的实验卡、`routes/V41-总览与门控.md` 第 7 节 | `docs/26`、`docs/08`、`09` 中对应的知识和文献 |
| 回传 | `docs/25`（小回传）、`docs/06`、`07`、`20`（完整回传） | `scripts/mini_return.py`、`check-return.py`、`ret_md.py` |
| 出错 | `docs/26`、`docs/11` | 路线卡的“已知问题” |

## 4. 什么时候停下来（报告主窗，写清现象与证据）

- 同一配置反复 OOM 或崩溃 3 次以上；结果和路线卡里的“预期”差了一个数量级；
- 需要 sudo、改全局配置，或者下载清单以外超过 50 GB 的文件；
- 需要改 verl、slime、SGLang 的核心逻辑（只加日志和计时不算）；
- V41-Q0 的负对照没过（lr=0 时参数变了）：训练正确性有问题，先停 V4-Q；
- 机器或网络出问题：只记录报错和受影响的步骤，不去改网络或代理设置。

## 5. 编号约定

- v4.1 的新任务编号 `V41-*`；沿用 v4 的任务编号 `V4-*`（结果目录同名）；同一实验的串行变体在编号后加 `s`（如 `V4-P2s`），结果仍写 `V4-P2/`。
- 回传编号：小回传 `p01v4a-YYYYMMDD-NN`，完整回传 `p01v41-YYYYMMDD-NN`。
- 此前部署实验包（llm-serving-lab）的实验编号是 E01–E24、AR-01–AR-10，引用时写全称。
