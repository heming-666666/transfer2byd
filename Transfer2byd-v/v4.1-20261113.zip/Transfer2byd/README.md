# OPD 实验包 v4.1（2026-11-13）：v4 的补完包

给云端 8×H800 机器。依据 v4 的部分回传（V4-0、P1、NT、G1、E、R 已完成；skill 层面 7 个问题）和研究者 2026-11-13 的要求（多卡用满、主窗只做分发与合并、每次派发核实真用卡、看板多页签与论文完成度、skill 自己会变好）。

## 先读

1. `skill/README.md`：**先确认云端编排 skill 是 2.0.0**；不是就照 `skill/skill-upgrade-2.0.0/` 升级（它带安装器、测试、回滚）；
2. `AGENTS.md`：入口和规则；
3. `docs/00-v4.1先读这一篇.md`：这一版要回答什么、与 skill 2.0.0 的对接、代码规则、启动器、看板、回传；
4. `routes/V41-总览与门控.md`：任务总表、新任务的做法与判据、所有 agent 任务的通用做法；
5. 你的任务的路线卡 `routes/V4-*.md`（v4 的，照旧有效）；
6. `docs/13`（并行与资源：令牌、变体、模拟排程）、`docs/26`（云端环境经验与弯路记录）；
7. 回传：小回传 `docs/25`，完整回传 `docs/06`、`07`。

## 这一版和 v4 的不同

- **v4 已完成的任务不重跑**：manifest 里写了 `done_if`，证据文件在就直接判完成；结果继续写 `results/v4/`。
- **卡只由 skill 2.0.0 的 orchd 分**：
  - `state/manifest.json` 是 `orch-manifest/2`（31 个任务、5 个角色）；
  - 按优先级与强制依赖动态调度，不写预计时长；
  - 全脚本化的探针由 orchd 自己启动；要判断的任务由 orchd 自动生成任务书、开窗承接；子窗的 GPU 命令走 `orchd.py exec`；
  - orchd 确认每个任务真开始，每 3 秒核查每张卡是不是真在算；
  - 主窗只掌控全局。
- **环境任务 V41-ENV**：现有环境满足就几秒内自动完成；不满足才开窗新建隔离环境，绝不改现有环境。
- **能并行的写成多档**：P2 的两格用 skill 的 `cellrun.py` 按租到的卡并行；Fp、R1b 的路线卡写了用法。
- **异常预案写好了**：探针与补测修不好照实交，可选任务放弃，核心任务交主窗与研究者（`routes/V41` 第 9 节）。
- **计时探针按门 BW 决定能否并行**：P3 先测多卡同时拷贝的主机带宽，8 卡每卡 ≥ 单卡的 0.90 就让 P2、P4、P5 同时跑，否则一个一个跑（两个变体都写好了，orchd 自动选）。
- **新任务**：V41-0 接手检查、V41-S1 ray 端口冒烟、V41-GBW 门 BW、V41-Q0 正确性门、V41-R1b R1-a 第 4 条补测；V4-F 拆成 Fp（预检，可同机）与 Ft（计时臂）。
- **端口与进程隔离**：每个任务一个端口段，ray 用独立临时目录，进程带标签、只停自己的（`scripts/v41/env.sh`、`docs/26`）——v4 里 4 卡任务被迫整机独占的问题不再需要。
- **看板重做**：七个页签（总览、GPU 与调度、任务、运行与探针、研究与论文、投稿节点、告警与事件），论文完成度、5–20 秒刷新、读 orchd 的状态（`docs/15`）。
- **回传多 3 个文件**：`14-detours.md`（弯路）、`15-gpu-util.csv`（卡时账）、`16-skill-issues.md`（skill 问题）；回传编号统一为 `p01v4a-…`（小）与 `p01v41-…`（完整）。
- **包里带 skill 的全部材料**（`skill/`）：本包的主窗调用 Prompt、需要的 skill 版本、本轮 skill 优化记录、2.0.0 升级包。以后每个实验包都这样带（skill 的 `references/evolution.md` 第 6 节）。

## 目录

| 目录 | 内容 |
|---|---|
| `skill/` | 主窗调用 Prompt、skill 版本要求、优化记录、`skill-upgrade-2.0.0/`（安装器、文件、测试、升级任务书） |
| `state/` | `manifest.json`（orch-manifest/2，权威清单）、`tasks.yaml`、`parallel-plan.json`（三者由 `scripts/v41/make_manifest.py` 生成）、`research-status.json`（看板的研究进展与论文完成度）、`assets-manifest.json`、`versions.lock.json` |
| `routes/` | `V41-总览与门控.md`（新）与 v4 的路线卡 |
| `scripts/` | v4 的脚本（`opd_run.py` 按大版本写结果目录、`dash.py` 重做、`mini_return.py` 与 `check-return.py` 按 v4.1 的文件集）；`scripts/v41/`：`env.sh`（端口段、ray 起停、只停自己的进程）、`tasks/*.sh`（探针与冒烟的 job 脚本）、`gate_bw.py`、`util_report.py`、`own_procs.py`、`make_manifest.py` |
| `dashboard/` | 看板页面（单文件，不连外网） |
| `docs/` | `00`（v4.1 先读）、`13`、`15`、`25`、`26`（新）与沿用的说明 |
| `tests/selftest.sh` | 包自测（74 项） |
