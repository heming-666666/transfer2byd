# 实时进展看板实施指令（第 7/7 部分：安全验收与交付）

> 给 DASH 子 agent。按 1–7 的顺序读完再动手，七个部分合起来是一份完整指令。与 `AGENTS.md`、`docs/14` 冲突时以它们为准。

## 11. 安全与兼容底线（不符合即验收失败）

- 不碰宿主机驱动、内核、系统 Python 包、全局 CUDA、网络/代理/防火墙配置；不能要 sudo；优先复用已能运行的本地 Node 22 / Python 3.10，确需新依赖在隔离 venv 或 `web/node_modules` 里安装，不改现有推理框架环境。
- 禁止主动安装大模型、重新下载原有模型、破坏软链接、复制大量模型权重、停止/杀死正在工作的实验进程。
- 不默认联网；所有 UI 图标/字体/构建 JS 依赖本地，禁止 Google Fonts/CDN/analytics/Sentry/远程日志等外部数据流。
- Dashboard 必须能在断外网环境运行。若构建所需依赖尚不存在，生成离线依赖清单、可复用缓存和校验方式；**不自行绕过网络隔离策略**。
- `127.0.0.1` 默认服务；跨机器用 SSH 端口转发。脱敏 API，不加载用户浏览器上传的外部脚本。明确本地访问控制边界。
- 所有数据来自实际状态/事件；**UI 不能用于直接修改实验结果或掩盖失败**；审计的原始证据不可变更。
- 看板即使出现异常，也必须对原训练/推理进程零强制依赖；服务启动、停止、异常退出均不改变 GPU 任务状态。
- 回传按 `docs/06`：一个目录，最多 10 个固定文件。看板不占回传文件，HTML 和截图留在云端；看板的访问方式和验收结果写进 `00-summary.md`。

## 12. 必须通过的功能/正确性/视觉验收

### A. 数据真实性

- [ ] 从真实 `tasks.yaml` 提取任务定义，保留原 ID、dependence、partition、optional 与 gates；没有硬编码伪造新 task。
- [ ] 真实导入已有 `progress.yaml`、`return.yaml` 与结果文件；有导入报告，每一条已验证结果可查看来源与审计依据。
- [ ] 遇到 `progress=done` / `return=blocked` 冲突时标记冲突待审，绝不静默标记验证通过。
- [ ] 新导入的任务若 `steps_measured=0` 或结果不完整，不显示为测量成功。
- [ ] 条件任务未批准时不能出现在 Ready to Run；可选任务不计入必选完成率；gates 里的占位需求不算真实任务。
- [ ] 对同一批文件运行 import 两次，任务、配置和事件计数不变；旧 package 升级后历史仍可查。

### B. 实时与容错

- [ ] 两个模拟执行者并发发状态事件，Browser 在目标 2 秒内更新；事件按照 server_seq 排序而不是本机时钟推断。
- [ ] 断开 SSE → 恢复连接 → 通过事件游标补齐，不能丢事件；同一 `event_id` 重发无重复。
- [ ] 服务重启后 SQLite 历史、任务状态和在途配置仍在；spool 数据幂等补传。
- [ ] 心跳失联产生 STALE，并在真实 PID 存活时避免误报失败。
- [ ] 模拟有损 YAML、缺失 return 文件、意外非 UTF-8 日志、时钟时间异常时 UI 正常呈现数据质量告警。

### C. 资源与科研可信度

- [ ] A/B 同时并行可见；两区独占、`hostbw` 测量期间的冲突能够提示；错误的 GPU 占用可以被审计识别。
- [ ] 性能测量已有外部负载时标记可能受污染并说明证据；不自动判定性能数据有效。
- [ ] 网格部分配置成功、部分失败、部分未测能够正确计算完成度。
- [ ] 只读页面、脱敏检查通过，测试输入中含 token/密钥/绝对路径不暴露；模拟恶意文件路径不允许目录穿越。
- [ ] 在同一机器上停止 Dashboard 后，原有实验继续运行；Dashboard 自身 GPU 使用为 0。

### D. 页面体验

- [ ] Overview、任务列表、依赖 DAG、GPU/Agent 泳道、实验结果、问题里程碑视图可用。
- [ ] 1440×900 首屏 3 秒内找到“谁在做什么/哪里阻塞/下个节点缺什么”；移动端基本可读不溢出。
- [ ] 有 loading、empty、offline、stale、error、data conflict 视觉态；深浅主题可读，文字对比度符合目标；键盘可达。
- [ ] 图表标注单位与真实来源；数字与任务详情/CSV 一致；没有使用未经证实的演示值。
- [ ] 一次独立截图 QA 后修复所有 P0/P1 问题，留下 `reports/ui-review.md` 与截图路径。
- [ ] `dashboard-snapshot.html` 可在断网/无本地服务下双击打开，同时明确标记快照非实时。

### E. 可执行交付

- [ ] `./scripts/start.sh` 在既有环境启动，不修改系统配置；打印真实监听端口和本地 URL；支持重复调用不重复实例。
- [ ] `./scripts/status.sh` 显示 PID/地址/API/数据新鲜度，`./scripts/stop.sh` 只停 Dashboard 自己的 PID。
- [ ] `python cli/dashctl.py reconcile` 或等价命令可手工恢复文件同步；`snapshot` 可生成离线 HTML。
- [ ] `README.md` 包含 Linux 本机打开方法、Windows→Linux SSH 转发、离线依赖安装、启动停止、故障恢复、数据结构、只读/写入安全界限。
- [ ] `reports/acceptance.md` 列出**测试命令、真实 stdout/stderr 摘要、通过/失败、未完成项**；不把未执行的测试说成 PASS。

## 13. 推荐的开发验证命令接口（自行按环境实现）

```bash
# 确认当前项目路径、避免拿错目录
pwd
cat VERSION
sed -n '1,120p' AGENTS.md
sed -n '1,120p' state/tasks.yaml

# 真实项目状态发现 / 导入（不做实验）
python3 "$OPD_RUNTIME/dashboard/cli/dashctl.py" discover
python3 "$OPD_RUNTIME/dashboard/cli/dashctl.py" reconcile --dry-run
python3 "$OPD_RUNTIME/dashboard/cli/dashctl.py" reconcile

# 启动 Dashboard（零 GPU 任务）
cd "$OPD_RUNTIME/dashboard"
./scripts/start.sh
./scripts/status.sh

# 原有项目仍独立执行；Dashboard 数据会自动/事件驱动更新
# 浏览器访问 scripts/start.sh 打印的 http://127.0.0.1:<PORT>/

# 验收 + 离线快照
python3 -m pytest -q tests  # 若使用 pytest；没有则用等价 unittest
python3 cli/dashctl.py snapshot
./scripts/stop.sh
```

> **提示**：上面是 Agent 要实现的目标命令接口，当前压缩包**没有**这些 Dashboard 代码。不能把示意命令理解成已有可用工具。

## 14. 交付报告模板（最终必须填写；不可用空话代替）

在 `dashboard/reports/acceptance.md` 生成：

```markdown
# Transfer2byd Mission Control 交付审计

- 包版本 / 原任务定义 SHA / 新增代码 Git commit：
- Dashboard 工作目录与启动命令：
- 实际访问 URL / 绑定地址 / 跨机打开办法：
- 当前真实任务数 / 已存在证据任务 / 活动执行者 / 无法判断的任务：
- 可用页面：
- 可用事件类型及其数据来源：
- 实时更新测得的 p50 / p95 / 最大延迟（毫秒，写测试方法）：
- GPU/CPU 采样策略与是否干扰基准：
- 数据同步/幂等/断线恢复验证：
- 通过的测试（命令、实际输出、证据路径）：
- 未通过或未测试的项目及原因：
- 试运行时原有实验进程前后状态：
- 使用的 Skills（仓库、SHA、许可、用途）：
- 浏览器截图与 UI Review：
- 离线 HTML 快照路径 / 生成时间 / 非实时标识：
- 已知限制 / 后续可选增强：
```

**完成标准**：所有 P0 验收项通过，页面实时显示**已存在的真实实验进展**；任意新实验的 Worker 发事件后浏览器更新；审计窗口能识别“正在运行但无有效数据”“已报告完成但未验收”“已验证成功”的区别。若发现原状态缺失/不确定，诚实显示 UNKNOWN 并保留证据，不得伪造进展。


## 给 DASH 的最终执行命令（直接按此开始）

**立刻按 D0→D7 实施。** 先找到当前工作目录内现有 Transfer2byd 包及 `$OPD_RUNTIME`，完整读取原始约束和真实状态；并行派发只读发现/数据契约/前端设计，避免资源和文件冲突；按本文件选取并审查 GitHub Skills，构建本地 React + SSE + SQLite 的实时科研任务指挥看板。让每个实验 Worker 使用事件协议自动同步进展，保持原有 YAML/回传流程不变，且所有完成必须有独立证据和审计。最终**实际启动 HTML 实时页面、导入历史真实结果、完成截图与测试、生成离线快照**，交付可执行启动命令、本地访问地址和 `reports/acceptance.md`。不允许仅给出设计建议或模拟成功截图就结束。
