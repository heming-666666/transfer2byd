# 实时进展看板实施指令（第 1/7 部分：目标与边界）

> 给 DASH 子 agent。按 1–7 的顺序读完再动手，七个部分合起来是一份完整指令。与 `AGENTS.md`、`docs/14` 冲突时以它们为准。

> **用途**：交给 DASH 子 agent（角色卡 `agents/DASH-看板.md`），让它在现有 Transfer2byd OPD 实验项目上增加一个好看、可靠、实时更新的浏览器看板。**这是实施 Prompt，不是已经实现的看板**。
>
> **依据**：本包的 `state/tasks.yaml`、`state/parallel-plan.json`（及 `state/parallel-tasks-*.json`、`state/parallel-schedule.json`）、`docs/13`–`16` 和 `agents/` 角色卡。本指令由研究者 2026-11-05 提供的原稿改写：去掉了只适用于某一版包的细节和外部仓库地址，事件写入改为与 `scripts/opd_event.py` 一致。
>
> **范围**：只在运行机器上的现有项目中**增量开发** Dashboard，不修改既有实验目标、运行策略、测量口径、驱动和环境；不替研究者修改路线选择。无需先向研究者询问明明可以从现有文件查明的事实；若确实遇到会改变实验或安全边界的选择，标记为待批准并继续无冲突工作。


## 0. 最高优先级指令：成功标准

你不是只做静态展示图、README 或一个一次性 HTML 截图；你要交付 **Transfer2byd Research Mission Control**，一个**打开浏览器即可查看**的实时项目进展界面，真实读取已经发生的实验记录，并让后续主窗口、多个子窗口和审计窗口的行动持续同步到页面。

最终必须实现：

1. **正确恢复历史**：根据现有 `$OPD_RUNTIME/state/progress.yaml`、`$OPD_RUNTIME/results/<TASK-ID>/return.yaml`、实际结果文件、既有日志和已有任务/问题记录，按证据恢复当前真实进度；**绝对不能把演示数据当真实数据，绝不能把未测、失败、仅开始过的任务当已完成**。
2. **实时刷新**：浏览器持续打开时，无需手动刷新即可看到任务派发、开始、心跳、配置完成、异常、结束和审计结果；正常情况下端到端更新目标 **≤ 2 秒**，以实测报告确认。
3. **全貌可见**：展示已完成、运行中、排队中、待开始、阻塞、失败待修、待验收、通过验收、条件未启用、可选任务等；对同一任务的不同 `run_id`、不同 `config_id` 和重试分别记录。
4. **并行可见**：展示 ORCH、所有 WORKER、AUDIT 和 DASH；按 plan 的分区显示 A、B、两区独占和 CPU-only 任务，以及租约冲突（`resource_conflict_detected`）预警；展示调度原因、依赖阻塞和时间线。
5. **有科研价值**：完成证据、结果文件、关键指标与质量校验、实验配置、环境版本、复现实验命令（必须脱敏）、G1/G2/G3 里程碑、出错归档、缺失结果一目了然。
6. **漂亮且可用**：专业科研基础设施指挥台风格，信息层级清晰；图、表、看板、依赖 DAG、时间线协同，支持筛选/搜索/详情；加载、空状态、断线、长任务、错误状态完善，响应式、可访问。
7. **稳定低干扰**：界面挂掉、后端重启、断网、误关闭浏览器均不影响原实验；监控不与性能基准冲突；不要启动新的 GPU 任务来测试前端。
8. **真实交付**：有可启动的本地 HTTP 地址、使用说明、离线 HTML 快照、可复现的测试与截图验收、真实状态导入报告。**不能仅输出一个 Markdown 自称完成。**

## 1. 原包文件与约束：必须先读取、再实施

本包解压后就是 `Transfer2byd/` 目录，按下列顺序读取：

- `CLAUDE.md`、`AGENTS.md`、`README.md`、`VERSION`、`CHANGELOG.md`
- `state/tasks.yaml`、`state/parallel-plan.json` 与 `state/parallel-tasks-*.json`、`state/parallel-schedule.json`、`docs/05-实验步骤总览.md`、`docs/13`–`16`、`agents/`
- `docs/02-环境配置-1-硬件目录与引擎.md`、`docs/06-结果格式与回传-1-规则.md`、`docs/07-结果格式与回传-2-各任务要交的内容.md`、`docs/10-安全与数据规定.md`
- `templates/task-return.yaml`、`templates/log-schemas.md`
- `routes/` 中对应路线卡；检查 `$OPD_RUNTIME/state/`、`$OPD_RUNTIME/results/`、`$OPD_RUNTIME/logs/`、已有问题档案与所有历史执行记录。

**权威数据边界**：

| 来源 | 用途 | 修改政策 |
|---|---|---|
| `state/tasks.yaml` | 任务 ID、路线、依赖、原定 GPU 分区、`gpu_h`、返回文件、可选条件、G1/G2/G3 | **只读**；原包升级时重新解析，不擅自重写 |
| `docs/05` / `routes/` / `CHANGELOG.md` | 任务顺序、阶段和条件开关、科研审批依据 | **只读**，只有原方案的授权升级改变实验安排 |
| `$OPD_RUNTIME/state/progress.yaml` | 原执行体系的任务状态 | 原有执行流程继续负责维护；新系统以兼容适配器只读同步为默认，禁止并发覆写造成丢失 |
| `$OPD_RUNTIME/results/<TASK-ID>/return.yaml` | 返回状态、指标、配置、证据、验收检查字段 | 实验 Agent 原有职责不变；Dashboard 只读 |
| `$OPD_RUNTIME/state/events/*.jsonl` | 各 agent 用 `scripts/opd_event.py` 写的事件（格式见第 5 节） | 只读导入，不改不删 |
| `$OPD_RUNTIME/state/leases.json` | 当前资源租约（`scripts/lease.py`） | 只读 |
| 原始日志 / CSV / JSON / env | 证据文件、实际完成情况和数据来源 | 只读，不因展示而重跑或篡改 |
| `$OPD_RUNTIME/dashboard/` | 本次新增代码、持久化事件、视图缓存、快照、测试、报表 | 允许创建和修改；不要覆盖别的目录 |

**准确理解包内原始约定**：

- 机器和分区以 `state/parallel-plan.json` 的 `partitions` 为准（目前是 8× H800 80GB + 2 TiB RAM，A=GPU 0–3，B=GPU 4–7，AB=两区）。`partition: both` 是两区独占；`A+B` 表示多个单分区配置分给两区并行，两者不能混为一谈。遇到歧义在界面标注“需核对实际调度”，不自作主张。
- 租了 `hostbw` 的测量（主机流式、卸载、换入）会争用 PCIe 和主机内存带宽，**即使显卡不同也不能据此认定无冲突**；以租约和 plan 的 `tolerates_other_partition_busy` 为准。
- 结果路径和原始日志留云端；回传按 `docs/06`：10 个固定文件，不限字数，看板不占回传文件。Dashboard 仅在本机/经 SSH 安全隧道访问，**不能自动上传 HTML、原始数据、内部路径或原始日志到外部服务**。
- plan 中标了 `conditional` 的任务（例如要研究者在 CHANGELOG 确认后才能做）未批准前不得显示为可派发；标了 `optional` 的任务单列，不计入必选进度。
- `gates` 的 `needs` 里出现的占位文字（例如 “defined in a later version”）**不是已定义的 task ID**，显示为“待补充定义/待版本更新”，不能创建虚假的任务。
- 原包 `state/tasks.yaml` 是**任务定义而非实时进度文件**。不能因为看到任务定义就把项目进度设为 0%，也不能因为任务目录存在就设为 100%。
- 原包已有 `AGENTS.md` 指明最多超时、原始日志、版本与结果回传规则。**新增 Dashboard 协议从属于这些规则**。

### 里程碑（北京时间 Asia/Shanghai）

以 `state/tasks.yaml` 的 `gates` 和 `docs/05` 为准。显示日期时给出实际时间、剩余时间、逾期状态；禁止无依据地延长 deadline。若当前日期已过，正确显示 overdue。
