# 实时进展看板实施指令（第 6/7 部分：目录与阶段）

> 给 DASH 子 agent。按 1–7 的顺序读完再动手，七个部分合起来是一份完整指令。与 `AGENTS.md`、`docs/14` 冲突时以它们为准。

## 9. 目录结构（建议，适配既有 $OPD_RUNTIME）

```text
$OPD_RUNTIME/dashboard/
├── README.md                         # 启动、离线、端口转发、架构、安全
├── AGENTS-DASHBOARD.md               # 原 AGENTS.md 的增量事件协议，不覆盖原文
├── pyproject.toml / requirements.txt # 固定依赖，注明版本/离线安装办法
├── server/
│   ├── app.py                        # localhost API + SSE
│   ├── models.py                     # 事件和任务视图 Schema
│   ├── repository.py                 # SQLite WAL + 去重/事务
│   ├── reconcile.py                  # 原 YAML/return/log 适配器
│   ├── resource_probe.py             # 低扰动资源读取
│   └── security.py                   # 只读鉴权/路径校验/脱敏
├── cli/dashctl.py                    # emit/status/reconcile/snapshot/check
├── web/
│   ├── src/pages/                   # Overview/Tasks/DAG/Timeline/Agents/Results/Issues
│   ├── src/components/              # KPI/TaskCard/RunPanel/ResourceLane/EventFeed
│   ├── src/lib/                     # typed API, SSE client, state selectors
│   ├── package.json + lockfile
│   └── dist/index.html               # 构建产物；本地 HTTP 服务托管
├── data/mission-control.sqlite      # 自动创建；WAL；不要写进 Git
├── data/spool/                      # 服务不可用时的本地事件缓冲
├── snapshots/dashboard-snapshot.html# 离线只读快照
├── reports/initial-discovery.md
├── reports/import-audit.md
├── reports/acceptance.md
├── docs/SKILL_SOURCES.md
├── tests/                             # 单元/集成/SSE/浏览器/历史导入测试
└── scripts/start.sh stop.sh status.sh build.sh
```

允许按实际环境微调目录名和实现语言，但要解释理由并保持同等安全/功能/测试保证。配置和服务/程序日志放到 Dashboard 自己的目录；**绝不在 `results/` 写前端代码、在原 `state/tasks.yaml` 塞实时字段或重置 `progress.yaml`**。

### API 最小契约

```text
GET  /api/health         -> service health, last_reconcile, source_errors, package_version
GET  /api/state          -> snapshot + server_seq + actual timestamps
GET  /api/tasks          -> task definitions + derived status + evidence summary
GET  /api/tasks/{id}     -> detail, dependency chain, runs/configs, sanitized artifacts
GET  /api/runs           -> active/historical run metadata
GET  /api/resources      -> sampled GPU/CPU/RAM + timestamp + provenance
GET  /api/milestones     -> gates + missing/blocked needs
GET  /api/events         -> SSE with Last-Event-ID replay; avoid sensitive payload
POST /api/events:ingest  -> local `dashctl`-only structured ingest; not browser controls
GET  /                  -> static React HTML dashboard
```

**默认浏览器只读**；本地写 API 需要限制来源、验证 schema、不可由普通网页跨站调用，至少使用操作系统权限+仅 Unix domain socket 写入，或严格的本地 CLI token / Unix socket 机制，令牌不得出现在 HTML、URL、日志里。尤其防止恶意网页诱使 localhost API 发送写请求；在 HTTP 写接口方案下，必须校验 Origin 与 Content-Type，并拒绝默认跨域访问。浏览器实时状态读取接口默认不返回敏感内容。

## 10. 分阶段实施任务与串并行安排

> 主窗口必须先进行资源发现，再派发；**优先让纯代码开发与现有 GPU 实验并行，不占用 GPU**。前端、后端和审计如共享同一文件，则用独立 Git worktree 或独立输出目录，合并后再集成；不要多个 Agent 同时改一个文件。

| 阶段 | 负责人 | 工作内容 | 前置 | 可并行情况与资源 |
|---|---|---|---|---|
| **D0 发现与备份** | 主 Agent + 审计 Agent | 阅读原包、发现真实状态、建立导入审计、冻结约束 | 无 | 只读 IO；可和设计草稿并行，但审计需独立 |
| **D1 数据契约** | 后端 Agent | YAML/schema、事件协议、状态机、SQLite、旧状态导入 | D0 | 与视觉设计并行；CPU-only |
| **D2 视觉与交互** | 前端设计 Agent | 信息架构、视觉规范、桌面/移动原型、空错误状态 | D0 | 与 D1 并行，设计 Demo 数据标记 |
| **D3 数据服务** | 后端 Agent | 只读 API、SSE/replay、CLI/spool、资源采样、文件监听 | D1 | 与 D4 前端开发并行，契约冻结后开始 |
| **D4 页面实现** | 前端 Agent | Overview/Kanban/DAG/Timeline/Agents/Results/Issues | D1、D2 | 独立代码目录，不触 GPU |
| **D5 接线与真实导入** | 集成 Agent | 从真实文件导入进度，接 API 和 SSE，修复数据冲突 | D3、D4 | 避免与同一目录写入并行 |
| **D6 双重验收** | 审计 Agent | 真实性、资源隔离、安全、实时性、UI 截图、压力与恢复测试 | D5 | 独立验收；发现问题退回对应窗口 |
| **D7 文档与交付** | 主 Agent | 使用说明、启动停止、报告、离线快照、对现有任务协议的兼容补丁 | D6 | CPU-only，保留所有历史数据 |

**辅助子 agent 示例**（平台允许时由 ORCH 派发；不允许时 DASH 分阶段自己完成，D6 的验收交给 AUDIT）：

```text
子窗口 UI-DESIGN：只负责设计系统、页面线框、交互规范、独立静态原型；读官方 frontend-design 和 ui-ux-pro-max；不要碰实验进程或 GPU。
子窗口 BACKEND：只负责事件模型、SQLite、import/reconcile、SSE/API/CLI、安全；只读原始实验输入；不要代替 Worker 改 return.yaml。
子窗口 FRONTEND：按冻结 API 契约实现 React 页面与可视化图表，不能私自伪造实际状态；引用 UI 规范，完成浏览器 build。
子窗口 AUDITOR：独立检查所有状态口径、历史导入、对原包兼容性、敏感信息、性能干扰和前端交互；不能仅信开发子窗口结果。
主窗口：负责分配文件所有权、实时资源检查、冲突解决、独立窗口收尾、集成与交付。实验运行原有调度不得被此项目替代。
```

**状态汇报**：延续原项目“简短进度语句”习惯，主窗口对用户只汇报可核查的“已完成 / 正在做 / 阻塞原因 / 下一项”四类事实；详细过程进入代码、审计报告和 Dashboard。
