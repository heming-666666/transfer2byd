# 实时进展看板实施指令（第 3/7 部分：架构与状态）

> 给 DASH 子 agent。按 1–7 的顺序读完再动手，七个部分合起来是一份完整指令。与 `AGENTS.md`、`docs/14` 冲突时以它们为准。

## 3. 最小侵入技术架构（默认方案）

**推荐技术选型**：

- 前端：**React + TypeScript + Vite**（生产构建为本地静态 HTML/JS/CSS），组件按需使用 React Flow、ECharts、shadcn/ui；不必引入 Next.js、云端账户和复杂云服务。
- 后端：**Python 3.10+ 本地轻量服务**。优先复用已有可用环境；如已有 FastAPI/Uvicorn 可安全复用，否则在 `$OPD_RUNTIME/dashboard/.venv` 创建隔离环境，或采用 Python 标准库实现 SSE/API。不得修改原 verl / slime / SGLang 环境。
- 持久化：**SQLite（WAL）** 的追加式事件表、任务视图和运行记录；`tasks.yaml`、`progress.yaml`、`return.yaml` 仍然是原实验系统的权威输入，不能被 SQLite 替代。数据库放 `$OPD_RUNTIME/dashboard/data/`。
- 事件推送：**Server-Sent Events（SSE）** 为首选，自动重连、游标补拉与版本号；失败时回退到只读轮询（建议 3–5 秒），绝不漏事件。
- 事件接入：所有执行者一律先用包里的 `scripts/opd_event.py` 把事件写进**各自的本地 spool 文件** `$OPD_RUNTIME/state/events/<agent>.jsonl`（格式见第 5 节）；看板的 `dashctl`（或等价 CLI）把 spool 幂等导入 SQLite，也可以另外提供本地写入 API。看板不在时事件照样留在 spool 里，不能因为展示失败阻塞实验。
- 兼容器：文件 watcher 或周期扫描已有 `progress.yaml`、`results/`、`return.yaml`；与手工/历史记录融合。Watcher 必须有遗漏事件后的定期全量 reconcile。
- 运行端口：例如 `127.0.0.1:18765`，端口冲突时选择空闲端口并记录真实地址。**不监听 0.0.0.0**，不打开防火墙，不修改代理。

### 3.1 数据流（只向 Dashboard 复制元数据）

```text
Transfer2byd/state/tasks.yaml ----> 任务定义解析器 -----------+
Transfer2byd/routes/ + docs/05 --> 条件/里程碑读取器 -----+
$OPD_RUNTIME/state/progress.yaml -> 兼容导入适配器 ---------+---> Reconciler ---> SQLite WAL
$OPD_RUNTIME/results/*/return.yaml -> 证据/结果解析器 ------+          |
已有日志 / 配置结果 -> 只读索引、文件存在性校验 ------------+          +--> SSE /api/events
各 agent -> opd_event.py -> state/events/*.jsonl -> dashctl import ----+--> GET /api/state
                                                                |
                                                        React/Vite 浏览器页面
                                                                |
                                                  dashboard-snapshot.html (只读离线)
```

**不能把完整日志、密钥、原始样本、内部服务地址、绝对 home 路径公开进 Web 响应**。只暴露必要、经过脱敏的元数据；文件详情使用经校验的任务 ID 与受控路径映射，不支持任意路径读取；防止目录穿越、XSS、超大日志渲染卡死。

### 3.2 关于“HTML 直接打开”与真正实时的兼容要求（非常重要）

- **真正实时版本**：用户用浏览器打开 `http://127.0.0.1:18765/`，实际就是由本地服务提供的 HTML 页面，动态获取 SSE；启动后刷新不丢进度。
- **离线双击版本**：生成 `dashboard-snapshot.html`，嵌入最后一次汇总的已脱敏数据、内联所需 CSS/JS，**即使 `file://` 打开也能看完整只读快照**，顶部标明“离线快照/生成时间/非实时”。此文件不试图访问本机任意路径。
- 禁止声称 `file://index.html` 无后端即可跨浏览器可靠监听磁盘文件变化或实时 SSE。不要通过对 `Origin: null` 放开宽泛跨域权限来绕过安全模型。
- 如果用户从 Windows 查看远程 Linux 的实验服务，给出明确的 **SSH 本地端口转发** 说明，而非将服务绑定公网：

```bash
# 在查看页面的电脑终端执行，地址/账号由用户自己填写
ssh -N -L 18765:127.0.0.1:18765 <login>@<remote-host>
# 浏览器在本机打开 http://127.0.0.1:18765/
```

如果端口冲突，文档使用实际启动端口，不强行占用已有实验服务端口。

## 4. 状态模型：严禁混淆“做过”“成功”“验收通过”

### 4.1 原有状态兼容

原 `progress.yaml` 的 `todo/running/done/partial/blocked` 原样保留。Dashboard 内部额外计算：

- 调度状态：`not_started`、`ready`、`queued`、`dispatched`、`running`、`waiting_dependency`、`waiting_resource`、`waiting_approval`、`stale_heartbeat`、`blocked`、`partial`、`reported_done`、`cancelled`。
- 验收状态（**正交字段**）：`unreviewed`、`needs_review`、`verified`、`rejected`、`invalidated`、`not_applicable`。**不得把 `reported_done` 当成 `verified`**。
- 每次执行尝试：`run_id` + `attempt_no`；网格子配置：`config_id` + `seed`；支持一个任务多次失败、复跑和局部成功。
- 进度来源：`source = progress_yaml | return_yaml | log | dashctl | auditor | inferred`，并带 evidence path、时间和置信层级。`inferred` 不能自动升级为 `verified`。

### 4.2 任务状态优先级（示例）

1. **已验证的有效结果**：`return.yaml` + 指定产物存在 + 路线卡验收通过 + 独立审计通过 ⇒ `verified`，并记录审计者、验证命令和时间。
2. `progress.yaml: done` 但未审计 ⇒ `reported_done / needs_review`；如果只见旧 `return.yaml: done`，以旧记录的证据时间显示，不谎称刚刚完成。
3. 若 `running` 但心跳超时：先验证 PID、进程启动时间和实际任务绑定是否仍一致；无法证明存活则标注 `stale_heartbeat/unknown`，**不得自动判定失败并重派发**。
4. 曾失败但重试中：保留历史失败事件，当前 attempt 展示运行中，不要覆盖事故记录。
5. 缺失/损坏状态文件：显示 `unknown / data_quality_warning`，给出来源和异常详情，不回退成 `todo` 或 `done`。
6. 看板显示 `blocked` 必须列出原因、依赖或 `problem_id`；等待审批不等于实验失败。
7. 网格任务（plan 中 `grid: true`）：每个配置独立记 `planned/started/measured/validated/failed/skipped`；`steps_measured=0` 必须显示为 **not measured/failed**，不能“配置已经运行过 => 进度 100%”。

### 4.3 汇总百分比必须可解释

- **定义任务覆盖率**：存在“完成证据”的、已激活的必选任务 / 已激活的必选任务数；显示口径和分母。
- **定义已验证率**：独立审计通过且有效的必选任务 / 已激活的必选任务数。
- **定义配置完成率**：某一网格实验中 `validated_config_count / planned_config_count`；只在计划明确时计算。
- **未激活条件任务和 optional 任务**：不进入必选主进度分母，单列展示数量与条件。
- 各路线单独显示有效结果率、受阻数量、回传完成数量；任务数不等价于 GPU 小时，若按权重统计必须标注 `gpu_h` 是**估算**。
- 至少为任务数、已验证数、当前活跃运行数、阻塞数、下一个里程碑的缺口设置 KPI，且每个数字都可以通过任务筛选列表核对。
