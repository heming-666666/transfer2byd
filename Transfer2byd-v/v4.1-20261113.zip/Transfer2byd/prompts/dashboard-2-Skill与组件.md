# 实时进展看板实施指令（第 2/7 部分：Skill与组件）

> 给 DASH 子 agent。按 1–7 的顺序读完再动手，七个部分合起来是一份完整指令。与 `AGENTS.md`、`docs/14` 冲突时以它们为准。

## 2. GitHub Skill / 开源组件研究与使用策略（已核实来源）

### 2.1 Skill 候选：按使用优先级，而不是只按 Star 排名

以下 Star 与仓库活跃度是 **2026-11-05 查询的快照**，会变化；Star 是仓库级别而不是某一个 Skill 的安装量。源文件和许可证应以实际安装时所固定的 commit 为准。

| 优先级 | 项目/Skill | GitHub / 具体 Skill | 仓库 Stars（约） | 角色及选择理由 | 安全/许可说明 |
|---|---|---|---:|---|---|
| **P0** | **Anthropic `frontend-design`** | <https://github.com/anthropics/skills/tree/main/skills/frontend-design> | **187,544** | Anthropic 官方，建立有辨识度的信息架构、排版、视觉语言，避免模板化“AI 仪表盘” | Skill 附单独 `LICENSE.txt`，**不是默认认定 MIT**；只阅读/按许可使用 |
| **P0** | **Vercel `vercel-react-best-practices`** | <https://github.com/vercel-labs/agent-skills/tree/main/skills/react-best-practices> | **33,566** | Vercel 官方；React 渲染、bundle、数据读取、异步与性能；适合实时 UI | Skill 标示 MIT；固定版本 |
| **P0** | **Vercel `web-design-guidelines`** | <https://github.com/vercel-labs/agent-skills/tree/main/skills/web-design-guidelines> | **33,566** | 官方网页设计与可访问性审查；开发结束做 UI 复核 | 它会要求获取最新外部规则；**离线环境改为提前核验并本地保存固定规则**，不得悄悄外联 |
| **P0** | **Obra Superpowers 的 `dispatching-parallel-agents`、`verification-before-completion`** | <https://github.com/obra/superpowers/tree/main/skills> | **312,643** | 并行任务隔离、完成之前验证证据；用于主/子/审计窗口协作与看板完成态审查 | MIT；只读取所需 Skill，**不把整个框架接管实验调度** |
| **P1** | **UI/UX Pro Max `ui-ux-pro-max`** | <https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/tree/main/.claude/skills/ui-ux-pro-max> | **145,411** | 视觉规范与图表类型、字体、交互、可访问性数据库；提升设计的专业感 | MIT；作为设计资料，不要同时让多个 Skill 对同一 CSS 冲突改写 |
| **P1** | **`dashboard-design`** | <https://github.com/abdiraimov-otabek/dashboard-design-skill/tree/main/skills/dashboard-design> | **291** | 专门针对 KPI、热图、空状态、正确量纲、截图 QA 的短而具体的 Skill | MIT；成立较新，Star 较少，作为专门质量检查而非可信执行引擎 |
| **P2（需核验许可）** | **`dataviz`** | <https://github.com/JimLiu/baoyu-design/tree/main/skills/dataviz> | **6,115** | 图形编码选择、状态颜色、色盲安全、数据来源清晰；很适合实际实验图 | 该 Skill 明确不是通用 MIT；要查看 `NOTICE.md`，只作设计参考或按许可使用 |
| **P2（参考，不依赖）** | **`claude-dashboard`** | <https://github.com/JimLiu/baoyu-design/tree/main/skills/claude-dashboard> | **6,115** | 可借鉴数据来源可追溯和 HTML 数据面板编排 | 含 mixed license、特殊编辑器与储存范式，**不应直接承担本项目多 Agent 实时事件通道** |

**选择结论**：最低必备 **Anthropic frontend-design + Vercel 两个 Skill + Superpowers 的两项协作/验收 Skill**；对图形和 UI 额外选用 **UI/UX Pro Max**，再用 **dashboard-design** 做一次界面审查。`dataviz` 可择需读设计方法。避免安装过多同名 `frontend-design` Skill，发生命名覆盖。若某 Skill 不可安装或许可证/网络不符合规定，保留来源引用并在设计阶段人工落实相同的质量目标，不得强行联网。

### 2.2 技术库 / 设计参照：它们**不是** Agent Skill

| 推荐 | 源码 | Stars（约） | 用法 | 是否整套照搬 |
|---|---|---:|---|---|
| **React Flow / xyflow** | <https://github.com/xyflow/xyflow> | **38,906** | 任务依赖 DAG、节点状态、可展开依赖链；仅渲染真实依赖 | 否，局部组件 |
| **Apache ECharts** | <https://github.com/apache/echarts> | **67,683** | 任务趋势、配置完成进度、资源时序、里程碑进度等；Apache-2.0 | 否，局部组件 |
| **shadcn/ui** | <https://github.com/shadcn-ui/ui> | **127,401** | 可访问的表格、弹窗、过滤器、Sheet、标签页等；MIT | 否，仅复制/按许可使用所需组件 |
| **vis-timeline** | <https://github.com/visjs/vis-timeline> | **2,576** | 可选：Agent/GPU 泳道、Gantt 时间区间；须审查其依赖/许可细节 | 可先自行用 CSS/SVG 简化实现 |
| **atc-claude-kanban** | <https://github.com/atc-net/atc-claude-kanban> | **12** | 借鉴 Claude Code 任务/子代理文件的读取、实时看板与会话关联设计 | **仅参考，不依赖**；项目较小，代码审计后才可复用 |
| **teambox** | <https://github.com/TheSmokeDev/teambox> | **1** | 借鉴监听 Agent Teams 文件/Hook 和事件流的设计 | **仅参考，不依赖**；适用性由运行环境验证 |

**特别注意**：GitHub 仓库 GitHub Stars 不代表安全审计结论；版本、License、依赖树、可执行脚本、Hooks、网络访问必须审查。以上已标明哪些是官方 Skill、社区 Skill、以及普通前端组件，不可混称。

### 2.3 Skill 接入顺序与隔离

1. 先检查现有 Agent 支持何种 Skill 格式/安装目录；**优先复用现有安装**。不要盲目运行 `curl | bash`、无审查的 `npx` 安装命令或自动注册不明 Hook。
2. 能联网的准备机上核对官方 repo、具体 Skill 路径、LICENSE、最后提交、依赖；记录 exact commit SHA。若云端无法联网，通过现有合规软件包渠道传入**经审查**的 Skill 文本和源码；不得突破网络限制。
3. 让 **设计子 Agent** 阅读 `frontend-design` + `ui-ux-pro-max`；让 **前端实现子 Agent** 阅读 `vercel-react-best-practices`；让 **审计子 Agent** 阅读 `web-design-guidelines` + `dashboard-design`；让 **主控调度子 Agent** 阅读 Superpowers 两项。各窗口只接触必要文件，避免互相污染结论。
4. 明确不同 Skill 的边界：**实验事实由现有日志和 YAML 决定；Skill 只能指导可视化与代码方法，不能推断实验成功**。
5. 将已使用 Skill 的仓库、路径、commit、许可、具体用途写入 `dashboard/docs/SKILL_SOURCES.md`；若实际未安装、仅参考，标记 `reference_only`。
