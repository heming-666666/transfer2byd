# 实时进展看板实施指令（第 4/7 部分：事件与采样）

> 给 DASH 子 agent。按 1–7 的顺序读完再动手，七个部分合起来是一份完整指令。与 `AGENTS.md`、`docs/14` 冲突时以它们为准。

## 5. 事件协议：主窗口/子窗口/审计窗口必须共同使用

包里的 `scripts/opd_event.py emit` 已经实现了写入（`dashctl emit` 可以作为它的包装），参数允许 `--task`、`--event`、`--run-id`、`--agent-id`、`--config-id`、`--artifact`、`--summary`、`--resource-partition`、`--reason` 等；向事件服务提交**结构化 JSON** 而非全文聊天日志。

**示例事件（只是协议示例，严禁当作真实实验历史导入）**：

```json
{
  "schema_version": 1,
  "event_id": "uuid-v4",
  "event_type": "task_started",
  "event_time_utc": "2026-11-05T09:00:00Z",
  "producer_id": "worker-B-01",
  "producer_seq": 12,
  "task_id": "R1-E0-L",
  "run_id": "run-uuid-v4",
  "attempt_no": 2,
  "config_id": "teacher-tp2-fp8",
  "partition": "B",
  "status": "running",
  "summary": "教师 warmup 阶段",
  "evidence_refs": ["results/R1-E0-L/return.yaml"],
  "is_demo": true
}
```

**数据库事件唯一键**：`event_id`；每个 Producer 的 `(producer_id, producer_seq)` 也要去重或检查乱序。提交时服务分配单调 `server_seq`；客户端 SSE 断开重连带 `Last-Event-ID` 补拉。时间统一存带偏移的 ISO8601 UTC，页面可切换但默认显示北京时间。对乱序/延迟导入的旧日志，保留 `observed_at` 与 `event_time`，不能造成当前状态回退。

**事件类型至少覆盖**：`project_reconciled`、`task_dispatched`、`task_queued`、`task_started`、`task_heartbeat`、`config_started`、`config_measured`、`config_failed`、`task_partial`、`task_reported_done`、`audit_started`、`audit_verified`、`audit_rejected`、`task_blocked`、`task_resumed`、`resource_reservation_created`、`resource_conflict_detected`、`resource_reservation_released`、`problem_opened`、`problem_resolved`、`milestone_updated`、`package_version_changed`、`source_error`。

**事件写入必须**：同一事务写 journal 与视图更新；失败留待重放；绝不能吞错误后回传“成功”；批量导入幂等；事件不可删除修改，视图可从日志重建；可配置归档/保留期。**安全限制**：Web 界面默认只读、不提供启动 GPU 实验、执行任意 shell 或读取任意文件的按钮。若未来增加控制台写入，必须另行授权且带明确审计。

### 5.1 三类执行窗口协议

**主控窗口（ORCH，角色卡 `agents/ORCH-主控.md`）**：

1. 启动时做一次文件发现和状态同步，报告 `tasks.yaml` 版本、任务数、已有有效进度数、无法识别的记录数；检查是否存在同名旧服务，复用而不重复启动。
2. 解析 DAG，逐个评估 dependency、条件审批、资源分区、CPU/内存/网络/存储、当前服务、性能隔离约束。
3. 为独立且资源不冲突的实验尽早并行分发；分发前先拿租约（`scripts/lease.py acquire` 会自动写 `resource_reservation_created`），避免双重占用；子窗口启动后校验进程/GPU 与计划一致。
4. 对 `both`、R3/PCIe/主机内存竞争、基准性能测试采取独占/高等级隔离；不能因为另一半 GPU 显示空闲就宣布安全。
5. 新任务分发、被依赖阻塞、正在等待审批或资源、预计耗时与实际耗时偏差，均发送事件。
6. 调度轮询休眠在 **10–180 秒** 范围内按阶段自适应；Dashboard 实时更新周期与调度轮询是不同概念，不要混用。

**执行子窗口（WORKER-A、WORKER-B、WORKER-CPU）**：

1. 接任务时 `task_dispatched`，预检后 `task_started`；持续轻量心跳（推荐 30 秒，允许可配置），阶段/配置变化立即发事件。
2. 每个实验严格保留原本的 `return.yaml`、env snapshot、命令、完整日志；Dashboard 只发链接元数据和脱敏摘要，不替代正式科学记录。
3. 网格每个配置测完立刻落盘和发 `config_measured`，保证中断续跑；失败发 `config_failed` 与原因、日志索引，不清零之前成功的数据。
4. 任务结束发 `task_reported_done`，**不自行发 `audit_verified`**；需独立审计核对后才显示“已验收”。
5. 事件通道不可用不阻塞实验，使用本地 spool；重连时先补发，必须防重。

**监控审计窗口（AUDIT）**：

1. **独立核查**运行进程和预计 GPU/CPU/主机内存/共享存储占用，识别意外争用、配置错误、心跳断开及超时；附实际观测证据，不能只相信主窗口自述。
2. 对宣称完成的任务检查 `return.yaml`、每个 `returns` 指定的必需文件、指标的有效性、`validity_checks`、warmup 排除与完整复现信息；不满足即 `audit_rejected` 或 `needs_review`，注明原因。
3. 性能基准期间采用低扰动采样，必要时暂停独立 GPU profiling；若发现资源竞争，给受影响结果标 `possibly_contaminated`，启动重新审计，**不得默认为有效**。
4. 对“真正难解”的问题按现有编号体系归档 `problem.md` 和预留的 `guide.md`，Dashboard 显示 problem ID、影响任务、问题状态、解决证据；收到外部 guide 后由主窗口分析，再指派改进。禁止让仪表盘自行“修复”系统。
5. 在 Dashboard 展示“最后观测时间、采样来源、置信/完整性”，避免截图中显示看似实时的过期数值。

## 7. 数据采集与实验干扰限制

**采样优先级**：原实验日志/`return.yaml`/`progress.yaml` > Agent 显式事件 > 独立轻量监控 > 未经证实的推断。

- 资源采样优先 `nvidia-smi` 或现有 DCGM，获取 GPU index、显存占用、利用率、可见进程 PID；可用时加 CPU、RAM、磁盘空间、I/O，但不得为了看板强制安装系统级守护进程。
- 典型采样建议：空闲 15–30 秒一次；严格性能基准进行时 **30–60 秒或暂缓高代价采样**，只看原已有实验 telemetry；两者可配置。**不要 1 秒执行一次 nvidia-smi**。
- `PID` 必须关联 `/proc` 进程启动时间/命令摘要和原任务 claim，防止 PID 重用或误认别人的服务；无法确认归属则标记 `unattributed_process`，不得杀死。
- 任务开始前执行资源预检：GPU 显存/SM 利用率、其他服务、CPU/内存、NUMA、Lustre/共享存储状态；子窗口可能独立但资源并不独立，须以实际检查为准。
- 对 CPU-only 任务同样检查 I/O/CPU 资源冲突；依赖链独立且资源充分隔离时允许并行，包括空闲 GPU 上的 grid 配置；但**性能基准绝对不能带干扰运行且默认有效**。
- 监控超时与轮询参数均可配置并写入 UI Settings。建议 Worker heartbeat=30s；心跳 90s 未见时变 `stale`，**不能直接 cancel 或重跑**，先核对 OS 真实进程。
- 看板后台 CPU/GPU 开销必须有基准比较记录；正常状态下看板不主动占 GPU；可通过前后性能对照验证低扰动要求（对照实验需在不干扰正在进行的真实测量时执行）。
