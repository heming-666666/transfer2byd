#!/usr/bin/env python3
"""Layer-major teacher scorer (PROCTOR mode B). Spec: routes/V2-B-按层打分器.md; method: paper Sec. 4.4.

A step's scoring is one batch job: apply layer 0 to every token, then layer 1, ...; each layer's weights live in
pinned host memory and are copied to the GPU once per pass, double-buffered so that the copy of layer j+1 overlaps
the computation of layer j. With --mode resident the same code keeps every layer on the GPU (the switch-off baseline:
only weight residency changes). One worker process per GPU, data-parallel over sequences; all workers read the same
host copy of the weights (files in /dev/shm mapped with torch.from_file and pinned with cudaHostRegister).

Subcommands (run with the python of an env that has torch + transformers, e.g. envs/verl-torch214-test):
  pack     --model DIR --out /dev/shm/proctor/NAME           write per-layer flat buffers + head.pt + meta.json
  selftest --packed DIR --model DIR --gpu 0                   correctness gates G1-G3 (see the route card)
  bench    --packed DIR --gpus 0,1,2,3 --mode stream --tokens-per-gpu 8192 16384 ... --seq-len 4096 --out F.json
  score    --packed DIR --gpus 0,1 --seqs seqs.jsonl --out lp.jsonl [--mode stream]
  compare  --a lp1.jsonl --b lp2.jsonl                        per-token |difference| statistics
Sequences (jsonl): {"prompt_ids": [...], "response_ids": [...]} (same format as R4-P4 seqs.jsonl). Scores are the
log-probabilities of every response token; position k scores token k given tokens < k.
Only standard PyTorch / Hugging Face APIs are used; if a signature differs in the installed version, fix it here,
record the diff in 02-code.md, and re-run selftest (gates must pass before any timing).
"""
import argparse
import copy
import json
import math
import os
import random
import statistics
import sys
import time
from pathlib import Path


def _dtype(name):
    import torch
    return {"torch.bfloat16": torch.bfloat16, "torch.float16": torch.float16, "torch.float32": torch.float32,
            "torch.float8_e4m3fn": getattr(torch, "float8_e4m3fn", None), "torch.uint8": torch.uint8,
            "torch.int64": torch.int64, "torch.int32": torch.int32, "torch.bool": torch.bool}[name]


def _load_hf(model_dir, device_map):
    import torch
    from transformers import AutoModelForCausalLM
    kw = dict(device_map=device_map, low_cpu_mem_usage=True)
    try:
        return AutoModelForCausalLM.from_pretrained(model_dir, dtype=torch.bfloat16, **kw).eval()
    except TypeError:
        return AutoModelForCausalLM.from_pretrained(model_dir, torch_dtype=torch.bfloat16, **kw).eval()


def _tensors(layer):
    return [(n, "param", p) for n, p in layer.named_parameters()] + [(n, "buffer", b) for n, b in layer.named_buffers()]


# ------------------------------------------------------------------------------------------------ pack
def cmd_pack(a):
    import torch
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    model = _load_hf(a.model, "cpu")
    base, cfg = model.model, model.config
    types = getattr(cfg, "layer_types", None)
    if types and len(set(types)) != 1:
        sys.exit(f"layers differ in type {sorted(set(types))}: this scorer needs one layer structure (route card V2-E)")
    layers = base.layers
    spec, off = [], 0
    for n, kind, t in _tensors(layers[0]):
        nb = t.numel() * t.element_size()
        spec.append({"name": n, "kind": kind, "shape": list(t.shape), "dtype": str(t.dtype), "offset": off, "nbytes": nb})
        off += (nb + 255) // 256 * 256
    layer_bytes = (off + 4095) // 4096 * 4096          # page-aligned files for cudaHostRegister
    for j, layer in enumerate(layers):
        ts = _tensors(layer)
        got = [(n, k, list(t.shape), str(t.dtype)) for n, k, t in ts]
        want = [(s["name"], s["kind"], s["shape"], s["dtype"]) for s in spec]
        if got != want:
            sys.exit(f"layer {j} differs from layer 0; mixed dense/MoE stacks are not supported")
        buf = torch.zeros(layer_bytes, dtype=torch.uint8)
        for s, (_, _, t) in zip(spec, ts):
            buf[s["offset"]:s["offset"] + s["nbytes"]].copy_(t.detach().contiguous().reshape(-1).view(torch.uint8))
        (out / f"layer_{j:03d}.bin").write_bytes(buf.numpy().tobytes())
    tied = bool(getattr(cfg, "tie_word_embeddings", False))
    torch.save({"embed": base.embed_tokens.weight.detach().clone(), "norm": base.norm.weight.detach().clone(),
                "lm_head": None if tied else model.lm_head.weight.detach().clone()}, out / "head.pt")
    cfg.save_pretrained(out)
    meta = {"model_dir": str(a.model), "n_layers": len(layers), "layer_bytes": layer_bytes, "spec": spec,
            "tied": tied, "hidden": cfg.hidden_size, "vocab": cfg.vocab_size, "model_type": cfg.model_type,
            "layer_class": type(layers[0]).__name__, "pack_s": round(time.time() - t0, 1),
            "host_gb": round(layer_bytes * len(layers) / 1e9, 3)}
    (out / "meta.json").write_text(json.dumps(meta, indent=1))
    print(json.dumps({k: v for k, v in meta.items() if k != "spec"}, indent=1))


# ------------------------------------------------------------------------------------------------ engine
class Scorer:
    """Per-GPU layer-major scorer. mode: stream | stream-noprefetch | resident."""

    def __init__(self, packed, gpu, mode="stream", attn="sdpa", private_pinned=False):
        import torch
        from transformers import AutoConfig, AutoModelForCausalLM
        self.torch, self.mode = torch, mode
        self.packed = Path(packed)
        self.meta = json.loads((self.packed / "meta.json").read_text())
        torch.cuda.set_device(gpu)
        self.dev = torch.device("cuda", gpu)
        cfg = AutoConfig.from_pretrained(self.packed)
        with torch.device("meta"):
            try:
                skel = AutoModelForCausalLM.from_config(cfg, attn_implementation=attn, dtype=torch.bfloat16)
            except TypeError:
                skel = AutoModelForCausalLM.from_config(cfg, attn_implementation=attn, torch_dtype=torch.bfloat16)
        self.cfg = cfg
        n, lb = self.meta["n_layers"], self.meta["layer_bytes"]
        # host weights: one mapping of the shared files per process, pinned in place if possible
        self.host, self.pinned = [], True
        for j in range(n):
            t = torch.from_file(str(self.packed / f"layer_{j:03d}.bin"), shared=True, size=lb, dtype=torch.uint8)
            if private_pinned:
                p = torch.empty(lb, dtype=torch.uint8, pin_memory=True)
                p.copy_(t)
                t = p
            else:
                rc = torch.cuda.cudart().cudaHostRegister(t.data_ptr(), lb, 0)
                if int(rc) != 0:
                    self.pinned = False
            self.host.append(t)
        self.pinned = self.pinned and self.host[0].is_pinned()
        head = torch.load(self.packed / "head.pt", map_location=self.dev)
        self.embed = head["embed"]
        self.lm_head = self.embed if head["lm_head"] is None else head["lm_head"]
        self.norm = copy.deepcopy(skel.model.norm).to_empty(device=self.dev)
        self.norm.weight.data.copy_(head["norm"])
        self.rot = type(skel.model.rotary_emb)(config=cfg, device=self.dev)
        tmpl = skel.model.layers[0]
        nbuf = n if mode == "resident" else 2
        self.bufs = [torch.empty(lb, dtype=torch.uint8, device=self.dev) for _ in range(nbuf)]
        if mode == "resident":                         # one module per layer, bound once (views, no extra memory)
            self.mods = []
            for j in range(n):
                self.bufs[j].copy_(self.host[j])
                m = self._layer(tmpl)
                self._bind(m, self.bufs[j])
                self.mods.append(m)
        else:
            self.mods = [self._layer(tmpl) for _ in range(2)]
            for k in range(2):
                self._bind(self.mods[k], self.bufs[k])
        self.copy_stream = torch.cuda.Stream(self.dev)
        torch.cuda.synchronize(self.dev)

    def _layer(self, tmpl):
        m = copy.deepcopy(tmpl).to_empty(device=self.dev)
        m.eval()
        m.requires_grad_(False)
        return m

    def _bind(self, mod, flat):
        torch = self.torch
        for s in self.meta["spec"]:
            path, _, attr = s["name"].rpartition(".")
            sub = mod.get_submodule(path) if path else mod
            v = flat[s["offset"]:s["offset"] + s["nbytes"]].view(_dtype(s["dtype"])).view(s["shape"])
            if s["kind"] == "param":
                sub._parameters[attr] = torch.nn.Parameter(v, requires_grad=False)
            else:
                sub._buffers[attr] = v

    def _apply(self, mod, h, pe, pos):
        out = mod(h, attention_mask=None, position_ids=pos, position_embeddings=pe, use_cache=False)
        return out[0] if isinstance(out, (tuple, list)) else out

    def score(self, seqs, micro_tokens=32768, timing=None):
        """seqs: list of (ids list, start) -> list of lists: log p(ids[k] | ids[<k]) for k in [start, len)."""
        torch = self.torch
        F = torch.nn.functional
        ev = lambda: torch.cuda.Event(enable_timing=True)
        torch.cuda.reset_peak_memory_stats(self.dev)
        with torch.inference_mode():
            t_begin = ev(); t_begin.record()
            # group equal-length sequences into micro-batches; unequal lengths run one by one (no padding)
            groups, by_len = [], {}
            for i, (ids, _) in enumerate(seqs):
                by_len.setdefault(len(ids), []).append(i)
            for L, idx in by_len.items():
                per = max(1, micro_tokens // L)
                for s in range(0, len(idx), per):
                    groups.append(idx[s:s + per])
            hs, pes, poss = [], [], []
            for g in groups:
                ids = torch.tensor([seqs[i][0] for i in g], dtype=torch.long, device=self.dev)
                h = F.embedding(ids, self.embed)
                pos = torch.arange(ids.shape[1], device=self.dev).unsqueeze(0).expand(ids.shape[0], -1)
                hs.append(h); poss.append(pos); pes.append(self.rot(h, pos))
            n = self.meta["n_layers"]
            cur = torch.cuda.current_stream(self.dev)
            ready = [torch.cuda.Event() for _ in range(2)]
            free = [torch.cuda.Event() for _ in range(2)]
            copy_ev = []

            def load(j, k):
                with torch.cuda.stream(self.copy_stream):
                    self.copy_stream.wait_event(free[k])
                    s, e = ev(), ev()
                    s.record(self.copy_stream)
                    self.bufs[k].copy_(self.host[j], non_blocking=True)
                    e.record(self.copy_stream)
                    ready[k].record(self.copy_stream)
                    copy_ev.append((s, e))

            t_layers = ev(); t_layers.record()
            if self.mode == "resident":
                for j in range(n):
                    for gi in range(len(groups)):
                        hs[gi] = self._apply(self.mods[j], hs[gi], pes[gi], poss[gi])
            else:
                load(0, 0)
                for j in range(n):
                    k = j % 2
                    if self.mode == "stream" and j + 1 < n:
                        load(j + 1, 1 - k)
                    cur.wait_event(ready[k])
                    for gi in range(len(groups)):
                        hs[gi] = self._apply(self.mods[k], hs[gi], pes[gi], poss[gi])
                    free[k].record(cur)
                    if self.mode == "stream-noprefetch" and j + 1 < n:
                        cur.synchronize()
                        load(j + 1, 1 - k)
            t_head = ev(); t_head.record()
            out = [None] * len(seqs)
            for gi, g in enumerate(groups):
                for r, i in enumerate(g):
                    ids, start = seqs[i]
                    start = max(1, start)
                    x = self.norm(hs[gi][r, start - 1:len(ids) - 1])
                    tgt = torch.tensor(ids[start:], dtype=torch.long, device=self.dev)
                    lps = []
                    for c in range(0, x.shape[0], 1024):       # 1024 x vocab x 4 B ~ 0.6 GB of logits at a time
                        logits = (x[c:c + 1024] @ self.lm_head.t()).float()
                        lp = logits.gather(1, tgt[c:c + 1024, None]).squeeze(1) - torch.logsumexp(logits, dim=1)
                        lps.append(lp)
                    out[i] = torch.cat(lps).tolist()
            t_end = ev(); t_end.record()
            torch.cuda.synchronize(self.dev)
            if timing is not None:
                cs = [s.elapsed_time(e) / 1000 for s, e in copy_ev]
                timing.update({"wall_s": t_begin.elapsed_time(t_end) / 1000,
                               "embed_s": t_begin.elapsed_time(t_layers) / 1000,
                               "layers_s": t_layers.elapsed_time(t_head) / 1000,
                               "head_s": t_head.elapsed_time(t_end) / 1000,
                               "copy_s_sum": sum(cs), "copy_s_mean": statistics.mean(cs) if cs else 0.0,
                               "copy_GBps_mean": (self.meta["layer_bytes"] / 1e9) / statistics.mean(cs) if cs else None,
                               "peak_mem_gb": torch.cuda.max_memory_allocated(self.dev) / 1e9})
            return out


# ------------------------------------------------------------------------------------------------ helpers
def read_seqs(path, limit=None):
    seqs = []
    for line in open(path, encoding="utf-8"):
        if not line.strip():
            continue
        o = json.loads(line)
        if o.get("corrupt"):
            continue
        p, r = list(o["prompt_ids"]), list(o["response_ids"])
        seqs.append((p + r, len(p)))
        if limit and len(seqs) >= limit:
            break
    return seqs


def synth_seqs(n, seq_len, prompt_len, vocab, seed=0):
    rng = random.Random(seed)
    return [([rng.randrange(100, vocab - 100) for _ in range(seq_len)], prompt_len) for _ in range(n)]


def diff_stats(a, b):
    d = [abs(x - y) for xs, ys in zip(a, b) for x, y in zip(xs, ys)]
    if not d:
        return {"count": 0}
    d.sort()
    q = lambda p: d[min(len(d) - 1, int(p * (len(d) - 1)))]
    return {"count": len(d), "p50": q(0.5), "p90": q(0.9), "p99": q(0.99), "max": d[-1], "mean": sum(d) / len(d),
            "exact_equal_frac": sum(1 for x in d if x == 0.0) / len(d)}


def _worker(rank, gpu, packed, mode, attn, private_pinned, jobs, results, barrier):
    try:
        sc = Scorer(packed, gpu, mode=mode, attn=attn, private_pinned=private_pinned)
        results.put(("ready", rank, {"pinned": sc.pinned, "gpu": gpu}))
        while True:
            job = jobs.get()
            if job is None:
                break
            tag, seqs, micro = job
            barrier.wait()
            timing = {}
            t0 = time.time()
            lps = sc.score(seqs, micro_tokens=micro, timing=timing)
            timing["host_wall_s"] = time.time() - t0
            timing["tokens"] = sum(len(s[0]) for s in seqs)
            results.put((tag, rank, {"timing": timing, "lps": lps}))
    except Exception as e:  # report instead of hanging the parent
        import traceback
        results.put(("error", rank, {"error": repr(e), "traceback": traceback.format_exc()}))


class Pool:
    """One persistent worker process per GPU; used by bench, score and lm_server.py."""

    def __init__(self, packed, gpus, mode="stream", attn="sdpa", private_pinned=False):
        import multiprocessing as mp
        ctx = mp.get_context("spawn")
        self.gpus = gpus
        self.barrier = ctx.Barrier(len(gpus))
        self.jobs = [ctx.Queue() for _ in gpus]
        self.results = ctx.Queue()
        self.procs = [ctx.Process(target=_worker, args=(r, g, packed, mode, attn, private_pinned, self.jobs[r],
                                                        self.results, self.barrier), daemon=True)
                      for r, g in enumerate(gpus)]
        for p in self.procs:
            p.start()
        self.info = {}
        for _ in gpus:
            tag, rank, payload = self.results.get()
            if tag == "error":
                raise RuntimeError(f"worker {rank} failed to start:\n{payload['traceback']}")
            self.info[rank] = payload

    def run(self, shards, micro=32768, tag="pass"):
        """shards: one list of sequences per GPU (may be empty). Returns per-rank (timing, lps)."""
        for r, s in enumerate(shards):
            self.jobs[r].put((tag, s, micro))
        out = {}
        for _ in shards:
            t, rank, payload = self.results.get()
            if t == "error":
                raise RuntimeError(f"worker {rank} failed:\n{payload['traceback']}")
            out[rank] = payload
        return out

    def close(self):
        for q in self.jobs:
            q.put(None)
        for p in self.procs:
            p.join(timeout=60)


def shard(seqs, n):
    """Split sequences over n GPUs, balancing tokens (longest first)."""
    order = sorted(range(len(seqs)), key=lambda i: -len(seqs[i][0]))
    load, parts = [0] * n, [[] for _ in range(n)]
    idx = [[] for _ in range(n)]
    for i in order:
        r = min(range(n), key=lambda x: load[x])
        parts[r].append(seqs[i]); idx[r].append(i); load[r] += len(seqs[i][0])
    return parts, idx


# ------------------------------------------------------------------------------------------------ commands
def cmd_selftest(a):
    """G1: stream == resident bit for bit; G2: stream-noprefetch == stream; G3: vs Hugging Face's own forward."""
    import torch
    meta = json.loads((Path(a.packed) / "meta.json").read_text())
    seqs = read_seqs(a.seqs, a.limit) if a.seqs else synth_seqs(a.n, a.seq_len, a.prompt_len, meta["vocab"], 1)
    res = {"seqs": len(seqs), "tokens": sum(len(s[0]) for s in seqs)}
    lp = {}
    for mode in ("stream", "stream-noprefetch", "resident"):
        sc = Scorer(a.packed, a.gpu, mode=mode, attn=a.attn)
        t = {}
        lp[mode] = sc.score(seqs, timing=t)
        res[f"timing_{mode}"] = t
        res["host_pinned"] = sc.pinned
        del sc
        torch.cuda.empty_cache()
    res["G1_stream_vs_resident"] = diff_stats(lp["stream"], lp["resident"])
    res["G2_noprefetch_vs_stream"] = diff_stats(lp["stream-noprefetch"], lp["stream"])
    if not a.skip_hf:
        model = _load_hf(a.model, {"": a.gpu})
        ref = []
        with torch.inference_mode():
            for ids, start in seqs:
                x = torch.tensor([ids], device=f"cuda:{a.gpu}")
                logits = model(input_ids=x).logits[0].float()
                lps = torch.log_softmax(logits[max(1, start) - 1:len(ids) - 1], dim=-1)
                ref.append(lps.gather(1, x[0, max(1, start):, None]).squeeze(1).tolist())
        res["G3_stream_vs_hf_forward"] = diff_stats(lp["stream"], ref)
        del model
    g1 = res["G1_stream_vs_resident"].get("max", 1) == 0.0
    g2 = res["G2_noprefetch_vs_stream"].get("max", 1) == 0.0
    g3 = a.skip_hf or res["G3_stream_vs_hf_forward"].get("p99", 1) <= a.g3_p99
    res["pass"] = {"G1": g1, "G2": g2, "G3": g3}
    Path(a.out).write_text(json.dumps(res, indent=1))
    print(json.dumps(res["pass"]), "->", a.out)
    return 0 if (g1 and g2 and g3) else 1


def cmd_bench(a):
    meta = json.loads((Path(a.packed) / "meta.json").read_text())
    gpus = [int(x) for x in a.gpus.split(",")]
    pool = Pool(a.packed, gpus, mode=a.mode, attn=a.attn, private_pinned=a.private_pinned)
    rows = []
    try:
        warm = synth_seqs(len(gpus), a.seq_len, a.prompt_len, meta["vocab"], 99)
        pool.run([[s] for s in warm], micro=a.micro_tokens, tag="warmup")
        for T in a.tokens_per_gpu:
            per = max(1, T // a.seq_len)
            reps = []
            for rep in range(a.repeats):
                seqs = synth_seqs(per * len(gpus), a.seq_len, a.prompt_len, meta["vocab"], 1000 * rep + T % 997)
                parts = [seqs[r * per:(r + 1) * per] for r in range(len(gpus))]
                out = pool.run(parts, micro=a.micro_tokens, tag=f"T{T}r{rep}")
                tim = [out[r]["timing"] for r in range(len(gpus))]
                wall = max(t["wall_s"] for t in tim)
                toks = sum(t["tokens"] for t in tim)
                reps.append({"wall_s": wall, "tokens": toks, "tok_s": toks / wall,
                             "per_gpu": [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in t.items()}
                                         for t in tim]})
            best = max(reps, key=lambda x: x["tok_s"])
            rows.append({"tokens_per_gpu": per * a.seq_len, "gpus": len(gpus), "best_tok_s": round(best["tok_s"], 1),
                         "tok_s_all": [round(r["tok_s"], 1) for r in reps], "repeats": reps})
            print(f"T/GPU={per * a.seq_len:>8} gpus={len(gpus)} mode={a.mode}: {best['tok_s']:.0f} tok/s", flush=True)
    finally:
        pool.close()
    res = {"task": "V2-B", "mode": a.mode, "packed": str(a.packed), "model_dir": meta["model_dir"],
           "host_gb": meta["host_gb"], "layer_bytes": meta["layer_bytes"], "n_layers": meta["n_layers"],
           "gpus": gpus, "seq_len": a.seq_len, "prompt_len": a.prompt_len, "micro_tokens": a.micro_tokens,
           "attn": a.attn, "worker_info": pool.info, "rows": rows}
    Path(a.out).write_text(json.dumps(res, indent=1))
    print("->", a.out)


def cmd_score(a):
    gpus = [int(x) for x in a.gpus.split(",")]
    seqs = read_seqs(a.seqs, a.limit)
    parts, idx = shard(seqs, len(gpus))
    pool = Pool(a.packed, gpus, mode=a.mode, attn=a.attn, private_pinned=a.private_pinned)
    try:
        out = pool.run(parts, micro=a.micro_tokens)
    finally:
        pool.close()
    lps = [None] * len(seqs)
    for r in range(len(gpus)):
        for j, i in enumerate(idx[r]):
            lps[i] = out[r]["lps"][j]
    with open(a.out, "w", encoding="utf-8") as f:
        for i, lp in enumerate(lps):
            f.write(json.dumps({"i": i, "logprobs": lp}) + "\n")
    print(json.dumps({r: out[r]["timing"] for r in out}, indent=1))


def cmd_compare(a):
    la = [json.loads(x)["logprobs"] for x in open(a.a) if x.strip()]
    lb = [json.loads(x)["logprobs"] for x in open(a.b) if x.strip()]
    print(json.dumps(diff_stats(la, lb), indent=1))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("pack"); p.add_argument("--model", required=True); p.add_argument("--out", required=True)
    for name in ("selftest", "bench", "score"):
        s = sub.add_parser(name)
        s.add_argument("--packed", required=True)
        s.add_argument("--attn", default="sdpa")
        s.add_argument("--micro-tokens", type=int, default=32768)
        if name == "selftest":
            s.add_argument("--model", required=True); s.add_argument("--gpu", type=int, default=0)
            s.add_argument("--seqs"); s.add_argument("--limit", type=int, default=16)
            s.add_argument("--n", type=int, default=4); s.add_argument("--seq-len", type=int, default=2048)
            s.add_argument("--prompt-len", type=int, default=128)
            s.add_argument("--g3-p99", type=float, default=0.02, help="allowed p99 |diff| vs HF forward")
            s.add_argument("--skip-hf", action="store_true"); s.add_argument("--out", required=True)
        else:
            s.add_argument("--gpus", required=True)
            s.add_argument("--mode", default="stream", choices=["stream", "stream-noprefetch", "resident"])
            s.add_argument("--private-pinned", action="store_true",
                           help="copy weights into per-process pinned memory if cudaHostRegister fails")
            s.add_argument("--out", required=True)
        if name == "bench":
            s.add_argument("--tokens-per-gpu", type=int, nargs="+", required=True)
            s.add_argument("--seq-len", type=int, default=4096); s.add_argument("--prompt-len", type=int, default=256)
            s.add_argument("--repeats", type=int, default=3)
        if name == "score":
            s.add_argument("--seqs", required=True); s.add_argument("--limit", type=int)
    c = sub.add_parser("compare"); c.add_argument("--a", required=True); c.add_argument("--b", required=True)
    a = ap.parse_args()
    return {"pack": cmd_pack, "selftest": cmd_selftest, "bench": cmd_bench, "score": cmd_score,
            "compare": cmd_compare}[a.cmd](a) or 0


if __name__ == "__main__":
    sys.exit(main())
