#!/usr/bin/env python3
"""opd_run: v4 的统一启动器。只用 Python 3.10 标准库。

    python3 -I scripts/opd_run.py --task V4-G1 --cfg g1-c64 --gpus 1 [--role formal] \
        [--timing-sensitive] [--steps-total 8] [--step-regex '...'] -- <要运行的命令 ...>

它做的事（实验命令本身不用改）：
1. 选卡：`--gpus N` 要 N 张卡。环境变量 OPD_GPU_LEASE=external（云端编排 skill 已经分好卡）时，
   从 CUDA_VISIBLE_DEVICES 取前 N 张；否则用包里的 lease.py 申请。`--gpu-ids 0,1` 可直接指定。
2. 建独立目录 results/<任务>/<run_id>/（已存在就拒绝，绝不覆盖），所有文件先写临时文件再改名。
3. 写 run.json（任务、配置、卡、角色、开始时间、命令、环境指纹）。
4. 后台采样 GPU（gpu.csv：功率、累计能耗、显存、利用率、温度；见 gpu_sampler.py），
   开跑前先采 --pre-idle 秒的空闲功率。
5. 运行命令，输出写 run.log；按 --step-regex 从输出里认步号，每次变化原子写 progress.json
   （看板读它）；命令自己也可以写 $OPD_RUN_DIR/progress.json。
6. 结束后补全 run.json（状态、退出码、时长），写 SHA256SUMS，向 results/results-index.jsonl 追加一行
   （加锁），释放自己申请的租约。
退出码与被运行的命令相同；启动器自身出错返回 90–99。
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROLES = ("smoke", "formal", "repro", "tune", "probe", "bench", "sim")
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
DEFAULT_STEP_RE = r"(?:^|[^A-Za-z])(?:step|rollout|iter(?:ation)?)[ =:#]*(\d+)(?:\s*/\s*(\d+))?"


def _pkg_ver():
    """结果目录名 = 包版本的大版本（VERSION 第一个词去掉小版本：v4.1 -> v4）；环境变量 OPD_PKG_VER 可覆盖。
    补完包（v4.1）与原包（v4）的结果放同一个目录，每次运行新建 run 目录，不会覆盖。"""
    if os.environ.get("OPD_PKG_VER"):
        return os.environ["OPD_PKG_VER"]
    try:
        return open(os.path.join(os.path.dirname(HERE), "VERSION"), encoding="utf-8").read().split()[0].split(".")[0]
    except (OSError, IndexError):
        return "v4"


PKG_VER = _pkg_ver()


def now():
    return time.time()


def utc(ts):
    return time.strftime("%Y%m%dT%H%M%SZ", time.gmtime(ts))


def atomic_write(path, text):
    tmp = f"{path}.tmp.{os.getpid()}"
    with open(tmp, "w", encoding="utf-8", newline="\n") as h:
        h.write(text)
        h.flush()
        os.fsync(h.fileno())
    os.replace(tmp, path)


def append_locked(path, line):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as h:
        fcntl.flock(h, fcntl.LOCK_EX)
        h.write(line.rstrip("\n") + "\n")
        h.flush()
        os.fsync(h.fileno())
        fcntl.flock(h, fcntl.LOCK_UN)


def sha256_file(path):
    d = hashlib.sha256()
    with open(path, "rb") as h:
        for b in iter(lambda: h.read(1 << 20), b""):
            d.update(b)
    return d.hexdigest()


def die(msg, code=90):
    print(f"[opd_run] 错误：{msg}", file=sys.stderr)
    sys.exit(code)


def disk_free_gb(path):
    u = shutil.disk_usage(path)
    return u.free / 2 ** 30


def pick_gpus(a, runtime):
    """返回 (卡号列表, 租约方式, 租约句柄)。"""
    if a.gpu_ids:
        ids = [x.strip() for x in a.gpu_ids.split(",") if x.strip()]
        return ids, "explicit", None
    n = a.gpus
    if n == 0:
        return [], "none", None
    if os.environ.get("OPD_GPU_LEASE", "") == "external":
        vis = [x.strip() for x in os.environ.get("CUDA_VISIBLE_DEVICES", "").split(",") if x.strip()]
        if len(vis) < n:
            die(f"OPD_GPU_LEASE=external，但 CUDA_VISIBLE_DEVICES 只有 {len(vis)} 张卡，任务要 {n} 张。"
                f"请让主窗按本任务的卡数重新分卡", 91)
        return vis[:n], "external", None
    # 包内租约：逐张试“当前空闲”的卡，用 lease.py 以 gpu<i> 为名登记，登记成功才算拿到
    r = subprocess.run([sys.executable, "-I", os.path.join(HERE, "gpu_sampler.py"), "--list-free"],
                       capture_output=True, text=True)
    free = [x for x in r.stdout.strip().split(",") if x.strip()] if r.returncode == 0 else []
    if len(free) < n:
        die(f"当前空闲的卡只有 {len(free)} 张（{','.join(free) or '无'}），任务要 {n} 张", 92)
    env = dict(os.environ, OPD_RUNTIME=runtime)
    for start in range(0, len(free) - n + 1):
        cand = free[start:start + n]
        q = subprocess.run([sys.executable, "-I", os.path.join(HERE, "lease.py"), "acquire", "--task", a.task,
                            "--agent", os.environ.get("OPD_AGENT", "WORKER-RUN"), "--res", *[f"gpu{g}" for g in cand], "--pid", str(os.getpid())],
                           capture_output=True, text=True, env=env)
        try:
            info = json.loads(q.stdout.strip().splitlines()[-1])
        except (ValueError, IndexError):
            die(f"lease.py 的输出认不出：{(q.stdout + q.stderr)[:200]}", 92)
        if info.get("ok"):
            return cand, "package", info.get("id")
    die(f"空闲的卡都已被包内租约登记，申请不到 {n} 张", 92)


def release(lease_id, runtime):
    if lease_id:
        subprocess.run([sys.executable, "-I", os.path.join(HERE, "lease.py"), "release", "--lease", str(lease_id)],
                       capture_output=True, text=True, env=dict(os.environ, OPD_RUNTIME=runtime))


def main(argv=None):
    ap = argparse.ArgumentParser(description="v4 统一启动器", usage="opd_run.py [选项] -- 命令 ...")
    ap.add_argument("--task", required=True)
    ap.add_argument("--cfg", required=True, help="配置名（03-configs 的 cfg 列）")
    ap.add_argument("--run-id", help="默认 <cfg>-<UTC 时间>")
    ap.add_argument("--role", default="formal", choices=ROLES)
    ap.add_argument("--arm", default="-")
    ap.add_argument("--pair", default="-", help="配对键，如 s1（同一对的两臂相同）")
    ap.add_argument("--seed", default="-")
    ap.add_argument("--gpus", type=int, default=0, help="需要的卡数")
    ap.add_argument("--gpu-ids", help="直接指定卡号（逗号分隔），覆盖 --gpus")
    ap.add_argument("--gpu-roles", default="", help="如 teacher=0,1;student=2,3,4,5（按分到的卡的序号）；不写则全部 shared")
    ap.add_argument("--timing-sensitive", action="store_true", help="性能测量：开跑前检查所选卡是否空闲")
    ap.add_argument("--steps-total", type=int, default=0)
    ap.add_argument("--warmup-steps", type=int, default=0)
    ap.add_argument("--step-regex", default=DEFAULT_STEP_RE, help="从输出里认步号的正则，第 1 组是步号")
    ap.add_argument("--sample-interval", type=float, default=0.5)
    ap.add_argument("--pre-idle", type=float, default=10.0, help="开跑前采多少秒空闲功率（0 = 不采）")
    ap.add_argument("--min-free-gb", type=float, default=50.0, help="结果盘余量低于它就不开跑")
    ap.add_argument("--param", action="append", default=[], help="k=v，记进 run.json 的 cfg（可多次）")
    ap.add_argument("--tunable", action="append", default=[], help="改过的可调参数 名=旧值->新值:理由（可多次）")
    ap.add_argument("--runtime", default=os.environ.get("OPD_RUNTIME", ""), help="运行根目录，默认 $OPD_RUNTIME")
    ap.add_argument("--dry-run", action="store_true", help="只打印将要做什么，不建目录、不运行")
    ap.add_argument("cmd", nargs=argparse.REMAINDER)
    a = ap.parse_args(argv)
    cmd = a.cmd[1:] if a.cmd and a.cmd[0] == "--" else a.cmd
    if not cmd:
        die("没有给要运行的命令（写在 -- 后面）")
    if not a.runtime:
        die("没有设置 OPD_RUNTIME，也没有给 --runtime")
    for k, v in (("task", a.task), ("cfg", a.cfg)):
        if not ID_RE.match(v):
            die(f"--{k} 只能用字母、数字、点、下划线、连字符")
    t0 = now()
    run_id = a.run_id or f"{a.cfg}-{utc(t0)}"
    if not ID_RE.match(run_id):
        die("--run-id 只能用字母、数字、点、下划线、连字符")
    results = os.path.join(a.runtime, "results", PKG_VER)
    run_dir = os.path.join(results, a.task, run_id)
    try:
        step_re = re.compile(a.step_regex, re.I)
    except re.error as e:
        die(f"--step-regex 不是合法正则：{e}")
    params = {}
    for kv in a.param:
        if "=" not in kv:
            die(f"--param 要写成 k=v：{kv}")
        k, v = kv.split("=", 1)
        params[k] = v
    tun = []
    for t in a.tunable:
        m = re.match(r"^([^=]+)=(.*?)->(.*?):(.+)$", t)
        if not m:
            die(f"--tunable 要写成 名=旧值->新值:理由：{t}")
        tun.append({"param": m.group(1), "old": m.group(2), "new": m.group(3), "reason": m.group(4)})

    if a.dry_run:
        print(json.dumps({"would_create": run_dir, "gpus": a.gpus, "gpu_ids": a.gpu_ids, "cmd": cmd,
                          "lease": os.environ.get("OPD_GPU_LEASE", "package")}, ensure_ascii=False, indent=1))
        return 0
    os.makedirs(results, exist_ok=True)
    free = disk_free_gb(results)
    if free < a.min_free_gb:
        die(f"结果盘只剩 {free:.1f} GB（阈值 {a.min_free_gb} GB），不开新任务；不要删别人的文件，报告主窗", 93)
    if os.path.exists(run_dir):
        die(f"运行目录已存在，拒绝覆盖：{run_dir}（换一个 --run-id）", 94)
    gpu_ids, lease_kind, lease_id = pick_gpus(a, a.runtime)
    os.makedirs(run_dir)

    roles = {g: "shared" for g in gpu_ids}
    if a.gpu_roles:
        for part in a.gpu_roles.split(";"):
            if not part.strip():
                continue
            name, idx = part.split("=", 1)
            for i in idx.split(","):
                i = i.strip()
                if i:
                    if int(i) >= len(gpu_ids):
                        release(lease_id, a.runtime)
                        die(f"--gpu-roles 的序号 {i} 超出分到的 {len(gpu_ids)} 张卡", 95)
                    roles[gpu_ids[int(i)]] = name.strip()

    run = {"fmt": "opd-run-1", "task": a.task, "run_id": run_id, "role": a.role, "cfg_name": a.cfg, "arm": a.arm,
           "pair": a.pair, "seed": a.seed, "cfg": params, "warmup_steps": a.warmup_steps, "steps_total": a.steps_total,
           "gpu_ids": gpu_ids, "gpu_roles": roles, "timing_sensitive": bool(a.timing_sensitive),
           "lease": lease_kind, "status": "running", "exit_code": None, "t_start": t0, "t_start_utc": utc(t0),
           "t_end": None, "cmd": cmd, "tunable_changes": tun, "package": PKG_VER, "host_pid": os.getpid(),
           "orch": {k: os.environ.get(k, "") for k in ("ORCH_TASK", "ORCH_RUN", "ORCH_SLOT", "ORCH_PORT_BASE", "ORCH_GPUS")},
           "env_python": os.environ.get("OPD_PY", sys.executable),
           "code_commit": os.environ.get("OPD_CODE_COMMIT", "-"), "env_id": os.environ.get("OPD_ENV_ID", "-")}
    atomic_write(os.path.join(run_dir, "run.json"), json.dumps(run, ensure_ascii=False, indent=1) + "\n")

    orch_prog, orch_started = os.environ.get("ORCH_PROGRESS", ""), os.environ.get("ORCH_STARTED", "")

    def progress(phase, step=None, total=None, last_step_s=None, note=""):
        body = json.dumps(
            {"task": a.task, "run_id": run_id, "cfg": a.cfg, "phase": phase, "step": step,
             "steps_total": total if total else (a.steps_total or None), "last_step_s": last_step_s,
             "t": now(), "t_start": t0, "gpus": gpu_ids, "note": note, "src": "launcher"}, ensure_ascii=False) + "\n"
        atomic_write(os.path.join(run_dir, "progress.json"), body)
        # 编排 skill 2.0 的通用约定：进度同时写 $ORCH_PROGRESS；第一次认出步号时 touch $ORCH_STARTED（orchd 据此确认“实验真开始”）
        if orch_prog:
            try:
                atomic_write(orch_prog, body)
            except OSError:
                pass
        if orch_started and phase == "running" and step and not os.path.exists(orch_started):
            try:
                with open(orch_started, "w", encoding="utf-8") as h:
                    h.write("opd_run %s：认出第 %s 步\n" % (a.cfg, step))
            except OSError:
                pass

    progress("starting")
    # GPU 采样
    sampler = None
    if gpu_ids:
        sampler = subprocess.Popen([sys.executable, "-I", os.path.join(HERE, "gpu_sampler.py"), "--out",
                                    os.path.join(run_dir, "gpu.csv"), "--gpus", ",".join(gpu_ids),
                                    "--interval", str(a.sample_interval)],
                                   stdout=open(os.path.join(run_dir, "gpu_sampler.log"), "w"), stderr=subprocess.STDOUT)
        if a.timing_sensitive:
            busy = subprocess.run([sys.executable, "-I", os.path.join(HERE, "gpu_sampler.py"), "--check-idle",
                                   "--gpus", ",".join(gpu_ids)], capture_output=True, text=True)
            run["idle_check"] = (busy.stdout + busy.stderr).strip()[:500]
            if busy.returncode != 0:
                run["qc_note"] = "所选卡在开跑前不空闲，性能数字可能受干扰"
                print(f"[opd_run] 警告：{run['qc_note']}：{run['idle_check']}", file=sys.stderr)
        if a.pre_idle > 0:
            progress("pre_idle")
            run["pre_idle"] = [now(), None]
            time.sleep(a.pre_idle)
            run["pre_idle"][1] = now()

    env = dict(os.environ)
    env.update({"OPD_RUN_DIR": run_dir, "OPD_TASK": a.task, "OPD_RUN_ID": run_id, "OPD_CFG": a.cfg,
                "OPD_NGPU": str(len(gpu_ids)), "PYTHONUNBUFFERED": "1"})
    if gpu_ids:
        env["CUDA_VISIBLE_DEVICES"] = ",".join(gpu_ids)
        env["OPD_GPU_IDS"] = ",".join(gpu_ids)
    run["t_cmd_start"] = now()
    atomic_write(os.path.join(run_dir, "run.json"), json.dumps(run, ensure_ascii=False, indent=1) + "\n")
    log_path = os.path.join(run_dir, "run.log")
    stop = {"sig": None}
    try:
        proc = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                start_new_session=True, bufsize=0)
    except OSError as e:
        proc = None
        run["fail_reason"] = f"命令启动失败：{e}"

    def on_sig(signum, _frame):
        stop["sig"] = signum
        if proc and proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass

    signal.signal(signal.SIGTERM, on_sig)
    signal.signal(signal.SIGINT, on_sig)

    state = {"step": None, "total": a.steps_total or None, "t_last": None, "last_step_s": None}
    steps_log = open(os.path.join(run_dir, "step_marks.jsonl"), "w", encoding="utf-8")

    def pump():
        with open(log_path, "wb") as lf:
            buf = b""
            while True:
                chunk = proc.stdout.read(65536)
                if not chunk:
                    break
                lf.write(chunk)
                lf.flush()
                buf += chunk
                *lines, buf = re.split(rb"[\r\n]", buf)
                for raw in lines:
                    m = step_re.search(raw.decode("utf-8", "replace"))
                    if not m:
                        continue
                    s = int(m.group(1))
                    if state["step"] is not None and s <= state["step"]:
                        continue
                    t = now()
                    if state["t_last"] is not None:
                        state["last_step_s"] = round(t - state["t_last"], 3)
                    state["step"], state["t_last"] = s, t
                    if m.lastindex and m.lastindex >= 2 and m.group(2):
                        state["total"] = int(m.group(2))
                    steps_log.write(json.dumps({"step": s, "t": t}) + "\n")
                    steps_log.flush()
                    progress("running", s, state["total"], state["last_step_s"])

    rc = 97
    if proc:
        progress("running", None, state["total"])
        th = threading.Thread(target=pump, daemon=True)
        th.start()
        rc = proc.wait()
        th.join(timeout=10)
    steps_log.close()
    t1 = now()
    if sampler:
        sampler.send_signal(signal.SIGTERM)
        try:
            sampler.wait(timeout=10)
        except subprocess.TimeoutExpired:
            sampler.kill()
    tail = b""
    if os.path.exists(log_path):
        with open(log_path, "rb") as lf:
            lf.seek(max(0, os.path.getsize(log_path) - 20000))
            tail = lf.read()
    low = tail.decode("utf-8", "replace").lower()
    if stop["sig"]:
        status = "killed"
    elif rc == 0:
        status = "ok"
    elif "out of memory" in low or "outofmemoryerror" in low:
        status = "oom"
    else:
        status = "fail"
    run.update({"status": status, "exit_code": rc, "t_end": t1, "t_end_utc": utc(t1), "wall_s": round(t1 - t0, 3),
                "steps_seen": state["step"]})
    atomic_write(os.path.join(run_dir, "run.json"), json.dumps(run, ensure_ascii=False, indent=1) + "\n")
    progress("done" if status == "ok" else status, state["step"], state["total"], state["last_step_s"])
    sums = []
    for root, _dirs, files in os.walk(run_dir):
        for f in sorted(files):
            if f == "SHA256SUMS" or ".tmp." in f:
                continue
            p = os.path.join(root, f)
            sums.append(f"{sha256_file(p)}  {os.path.relpath(p, run_dir)}")
    atomic_write(os.path.join(run_dir, "SHA256SUMS"), "\n".join(sorted(sums, key=lambda x: x.split("  ", 1)[1])) + "\n")
    append_locked(os.path.join(results, "results-index.jsonl"), json.dumps(
        {"task": a.task, "run_id": run_id, "cfg": a.cfg, "role": a.role, "arm": a.arm, "pair": a.pair, "seed": a.seed,
         "status": status, "exit_code": rc, "t_start_utc": utc(t0), "wall_s": round(t1 - t0, 3),
         "gpus": gpu_ids, "dir": os.path.relpath(run_dir, results)}, ensure_ascii=False))
    release(lease_id, a.runtime)
    print(f"[opd_run] {a.task}/{run_id} 结束：status={status} exit={rc} wall={t1 - t0:.1f}s -> {run_dir}")
    return rc if 0 <= rc < 256 else 1


if __name__ == "__main__":
    sys.exit(main())
