#!/usr/bin/env python3
"""Resource leases for parallel agents: nothing starts on GPUs, ports or envs that another task holds (docs/14).

  lease.py acquire --task R2-P1 --agent WORKER-A --res gpu:A noise:m env:sglang:s [--ports A:1]
                   [--pid PID] [--ttl-h H] [--wait-min M]
  lease.py release (--lease ID | --task T)     lease.py renew --lease ID --ttl-h H
  lease.py list                                lease.py reap   # drop leases whose --pid died or TTL expired
Token rules and port ranges: scripts/lease_core.py. Exit 3 = conflict (nothing was reserved).
"""
import argparse
import datetime as dt
import json
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import lease_core as C  # noqa: E402
import opd_event  # noqa: E402


def acquire(a):
    deadline = time.time() + 60 * a.wait_min
    while True:
        with C.table() as d:
            t = C.now()
            d["leases"] = [l for l in d["leases"] if not C.stale(l, t)]
            bad = [(l["task"], l["agent"], x) for l in d["leases"] for x in l["res"] for r in a.res if C.clash(r, x)]
            used = {p for l in d["leases"] for p in l.get("ports", [])}
            ports, short = C.pick_ports(a.ports, used)
            if not bad and not short:
                lease = {"id": "L-" + uuid.uuid4().hex[:8], "task": a.task, "agent": a.agent, "res": a.res,
                         "ports": ports, "pid": a.pid, "pid_start": C.start_time(a.pid) if a.pid else None,
                         "created": t.isoformat(timespec="seconds"),
                         "expires": (t + dt.timedelta(hours=a.ttl_h)).isoformat() if a.ttl_h else None}
                d["leases"].append(lease)
                break
        if time.time() >= deadline:
            why = "; ".join(f"{x} held by {k} ({g})" for k, g, x in bad) or f"no free port for {short}"
            opd_event.emit(a.agent, "resource_conflict_detected", task_id=a.task, reason=why)
            print(json.dumps({"ok": False, "conflicts": why}, ensure_ascii=False))
            return 3
        time.sleep(30)
    opd_event.emit(a.agent, "resource_reservation_created", task_id=a.task,
                   summary=" ".join(a.res + [str(p) for p in ports]))
    print(json.dumps({"ok": True, **lease}, ensure_ascii=False))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    q = sub.add_parser("acquire")
    q.add_argument("--task", required=True); q.add_argument("--agent", required=True)
    q.add_argument("--res", nargs="+", required=True); q.add_argument("--ports", nargs="*", default=[])
    q.add_argument("--pid", type=int); q.add_argument("--ttl-h", type=float, default=0)
    q.add_argument("--wait-min", type=float, default=0)
    r = sub.add_parser("release"); r.add_argument("--lease"); r.add_argument("--task")
    n = sub.add_parser("renew"); n.add_argument("--lease", required=True); n.add_argument("--ttl-h", type=float, required=True)
    sub.add_parser("list"); sub.add_parser("reap")
    a = ap.parse_args()
    if a.cmd == "acquire":
        return acquire(a)
    gone = []
    with C.table() as d:
        t = C.now()
        if a.cmd == "release":
            gone = [l for l in d["leases"] if l["id"] == a.lease or (a.task and l["task"] == a.task)]
        elif a.cmd == "reap":
            gone = [l for l in d["leases"] if C.stale(l, t)]
        elif a.cmd == "renew":
            for l in d["leases"]:
                if l["id"] == a.lease:
                    l["expires"] = (t + dt.timedelta(hours=a.ttl_h)).isoformat()
                    print("renewed", l["id"], "until", l["expires"][:16])
        else:
            for l in d["leases"]:
                print(l["id"], l["task"], l["agent"], " ".join(l["res"]), l.get("ports") or "-", l["created"][:16])
        d["leases"] = [l for l in d["leases"] if l not in gone]
    for l in gone:
        opd_event.emit(l["agent"], "resource_reservation_released", task_id=l["task"], summary=f"{a.cmd} {l['id']}")
        print("released", l["id"], l["task"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
