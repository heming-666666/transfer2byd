#!/usr/bin/env python3
"""engine_scan: 从 SGLang 的日志里取生成引擎的并发、排队、KV 用量和吞吐的时间序列。只用标准库。

    engine_scan.py --log <含 SGLang 输出的日志> [更多日志 ...] --out $OPD_RUN_DIR/engine.csv [--bucket 5]

SGLang 运行时会周期性打印形如
    ... Decode batch. #running-req: 23, #token: 187232, token usage: 0.61, gen throughput (token/s): 5123.4, #queue-req: 217
的行（不同版本字段略有出入）。本脚本取行首的时间戳和所有“名字: 数值”，按 --bucket 秒分桶，
输出每桶的均值与最大值；并打印整段的汇总（并发均值、排队均值、token usage 最大值、吞吐均值）。
认不出时间戳的行按出现顺序编号，t 列留空。找不到任何 Decode batch 行时退出码 3（说明日志里没有引擎输出，
在回传里写 NA:no-engine-log，不要编数字）。
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
import time

TS = re.compile(r"(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})")
KV = re.compile(r"(#?[A-Za-z][A-Za-z _\-/()#]*?):\s*(-?\d+(?:\.\d+)?)")
NAMES = {"#running-req": "running", "#queue-req": "queue", "token usage": "token_usage", "#token": "tokens",
         "gen throughput (token/s)": "gen_tok_s", "#new-seq": "new_seq", "#new-token": "new_tokens",
         "#cached-token": "cached_tokens"}


def parse_line(line):
    if "batch" not in line or "#running-req" not in line:
        return None
    kind = "decode" if "Decode batch" in line else ("prefill" if "Prefill batch" in line else "other")
    m = TS.search(line)
    t = time.mktime(tuple(int(x) for x in m.groups()) + (0, 0, -1)) if m else None
    vals = {}
    for k, v in KV.findall(line.split("batch", 1)[1]):
        k = k.strip().lstrip(",. ").strip()
        if k in NAMES:
            vals[NAMES[k]] = float(v)
    return (t, kind, vals) if vals else None


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--bucket", type=float, default=5.0)
    a = ap.parse_args(argv)
    rows = []
    for p in a.log:
        with open(p, encoding="utf-8", errors="replace") as h:
            for line in h:
                r = parse_line(line)
                if r and r[1] == "decode":
                    rows.append(r)
    if not rows:
        print("[engine_scan] 没有找到 Decode batch 行", file=sys.stderr)
        return 3
    cols = ["running", "queue", "token_usage", "gen_tok_s", "tokens"]
    buckets = {}
    for i, (t, _k, v) in enumerate(rows):
        key = int(t // a.bucket * a.bucket) if t is not None else None
        buckets.setdefault(key, []).append(v)
    with open(a.out, "w", encoding="utf-8", newline="") as h:
        w = csv.writer(h, lineterminator="\n")
        w.writerow(["t", "n_lines"] + [f"{c}_mean" for c in cols] + [f"{c}_max" for c in cols])
        for key in sorted(buckets, key=lambda x: (x is None, x)):
            vs = buckets[key]
            mean = [round(sum(v[c] for v in vs if c in v) / max(1, sum(1 for v in vs if c in v)), 3)
                    if any(c in v for v in vs) else "" for c in cols]
            mx = [max(v[c] for v in vs if c in v) if any(c in v for v in vs) else "" for c in cols]
            w.writerow([key if key is not None else "", len(vs)] + mean + mx)

    def agg(c, fn):
        xs = [v[c] for _, _, v in rows if c in v]
        return round(fn(xs), 3) if xs else "NA"
    avg = lambda xs: sum(xs) / len(xs)
    print(f"lines={len(rows)} running_mean={agg('running', avg)} running_max={agg('running', max)} "
          f"queue_mean={agg('queue', avg)} token_usage_max={agg('token_usage', max)} gen_tok_s_mean={agg('gen_tok_s', avg)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
