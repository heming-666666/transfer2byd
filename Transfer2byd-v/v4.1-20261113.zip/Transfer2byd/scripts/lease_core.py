"""Shared helpers for scripts/lease.py (docs/14): token rules, the locked lease table, liveness and port checks.

Token = name[:mode]; mode x=exclusive (default), s=shared, m=measuring, n=noisy. For the same name, x clashes with
everything; s/s, m/m and n/n coexist; different modes clash (so no download, install or build runs during a
measurement). Port ranges per partition are fixed here so that two agents never pick the same port.
"""
import datetime as dt
import fcntl
import json
import os
import socket
from contextlib import contextmanager
from pathlib import Path

RANGES = {"A": (30000, 30099), "B": (30100, 30199), "AB": (30200, 30299), "CPU": (30300, 30399)}
RT = Path(os.environ.get("OPD_RUNTIME", Path.home() / "opd-runtime"))
ST = RT / "state"


def tok(t):
    name, _, mode = t.rpartition(":")
    return (name, mode) if name and len(mode) == 1 and mode in "xsmn" else (t, "x")


def clash(a, b):
    (n1, m1), (n2, m2) = tok(a), tok(b)
    return n1 == n2 and (m1 == "x" or m2 == "x" or m1 != m2)


def start_time(pid):
    """Kernel start time of a process (guards against PID reuse); None if it is gone."""
    try:
        return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
    except (OSError, IndexError):
        return None


def port_free(port):
    with socket.socket() as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def now():
    return dt.datetime.now(dt.timezone.utc)


def stale(lease, t=None):
    """A lease is stale when its process died (pid given) or its TTL expired."""
    if lease.get("pid") and start_time(lease["pid"]) != lease.get("pid_start"):
        return True
    exp = lease.get("expires")
    return bool(exp) and dt.datetime.fromisoformat(exp) < (t or now())


@contextmanager
def table():
    """Exclusive access to $OPD_RUNTIME/state/leases.json; written atomically on exit."""
    ST.mkdir(parents=True, exist_ok=True)
    with open(ST / "leases.lock", "a") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        f = ST / "leases.json"
        data = json.loads(f.read_text()) if f.exists() else {"leases": []}
        yield data
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False))
        tmp.replace(f)


def pick_ports(spec_list, used):
    """spec 'A:2' -> two free ports from partition A's range. Returns (ports, unmet_specs)."""
    ports, short = [], []
    for spec in spec_list:
        part, _, n = spec.partition(":")
        n = int(n or 1)
        lo, hi = RANGES[part]
        got = [p for p in range(lo, hi + 1) if p not in used and p not in ports and port_free(p)][:n]
        ports += got
        if len(got) < n:
            short.append(spec)
    return ports, short
