# scripts/pkg/：任务包通用的脚本库（v4.1 起；v5 及以后直接复用）

研究者 2026-11-13：把相关的经验和脚本做成通用格式，v5 设置时直接复用。这个目录与包的内容无关，只装“每个包都要的”东西。包自己的东西放 `scripts/v<版本>/`。

| 文件 | 做什么 | 怎么复用 |
|---|---|---|
| `manifest_lib.py` | 一张任务表生成 `state/manifest.json`、`tasks.yaml`、`parallel-plan.json`（三者一致）；提供 `milestone()`（谁要这些结果）、`gate_variants()`（门控两支）；`priority_table()`/`check_order()` 用随包的 skill orchd 算优先级、核对研究顺序 | 新包写 `scripts/v5/make_manifest.py`：`from manifest_lib import Plan`，每个任务一次 `add`，最后 `write(pkg, meta)`；p01 v4.1 的 `scripts/v41/make_manifest.py` 是完整范例 |
| `orch_env.sh` | 运行环境函数：端口段（`port`）、ray 起停与就绪判定、HTTP 就绪等待、跳过已完成的格（`cell_done`）、只停本运行的进程（`own_cleanup`） | 包的 env.sh 先设 `PKG`、`PKG_RESULTS`（结果根）和自己的变量，再 `. "$PKG/scripts/pkg/orch_env.sh"` |
| `own_procs.py` | 列出或停止本运行（同一个 `ORCH_RUN`）的进程，不碰别人的 | `own_cleanup` 调它；运行号带编排实例，不会误杀另一套编排 |
| `env_ok.py` | 环境任务的现状检查（manifest 的 `skip_if_cmd`）：环境文件里的变量都在、解释器能导入要的包、与版本基线一致；满足就几秒内自动判完成 | `--env-file`、`--need`、`--import 变量:模块`、`--baselines` 改成本包的 |

和这些脚本配套、在云端 skill 里的东西：
- `orchd.py`（调度与核查）、`cellrun.py`（一组独立的格按租到的卡并行跑）、`brief.py`（任务书）；
- 写包的规矩：`references/package-contract.md`；
- 出包前的模拟：研究者一侧的 `experiments/orch-skill/tools/plan_sim.py --real <真实时长表>`。

经验（为什么这样写）在 `docs/26`（云端环境经验与弯路）、规范 07 §3.22–3.26，以及 skill 的 `references/manual.md` 第 6 节（异常与变更）。

## 新包的五步

1. 复制上一版包（`transfer2byd-build.py --new`），保留 `scripts/pkg/`，不改它；要改就改模板里的那份，再同步到各包。
2. 写 `scripts/v<N>/make_manifest.py`。规则：
   - 只写真依赖；
   - 能并行的写全档位，用 cellrun；
   - 计时的写令牌；
   - 研究者在等的写 `milestone(..., waiting_human=True)`；
   - 先验证再正式的写 `after`；
   - 每个任务写 `if_fail`；
   - 环境任务用 `env_ok.py`。
3. 写 `scripts/v<N>/env.sh`：包自己的变量，再 source `orch_env.sh`。
4. 包自测加一条 `check_order()`：研究顺序与算出的优先级一致。
5. 研究者一侧跑 `plan_sim.py` 的两种情形（门控两支、注入失败），结果写进 `docs/13`。
