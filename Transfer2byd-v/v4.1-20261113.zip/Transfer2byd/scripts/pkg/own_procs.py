#!/usr/bin/env python3
"""列出或停止“本运行”的进程：/proc/<pid>/environ 里 ORCH_RUN 等于给定值（只读这一个键）。

用法：own_procs.py --run <ORCH_RUN> [--spare <pid>] [--kill] [--grace 20]
  --spare  这个 pid 及其祖先不动（调用脚本自己）
为什么：ray stop、pkill python 会停掉同机别的任务的进程（v4 问题 2、4）；按标签停只动自己的。
退出码：0；2 没给 --run。
"""
import argparse
import os
import signal
import sys
import time


def tag(pid):
    try:
        raw = open("/proc/%d/environ" % pid, "rb").read()
    except OSError:
        return None
    for kv in raw.split(b"\0"):
        if kv.startswith(b"ORCH_RUN="):
            return kv[9:].decode("utf-8", "replace")
    return None


def ppid(pid):
    try:
        s = open("/proc/%d/stat" % pid).read()
        return int(s[s.rfind(")") + 2:].split()[1])
    except (OSError, ValueError, IndexError):
        return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="")
    ap.add_argument("--spare", type=int, default=0)
    ap.add_argument("--kill", action="store_true")
    ap.add_argument("--grace", type=float, default=20)
    a = ap.parse_args()
    if not a.run:
        print("没有 --run（不在 orchd 运行里？）：不停任何进程", file=sys.stderr)
        return 2
    spare, p = {os.getpid()}, a.spare
    while p > 1:
        spare.add(p)
        p = ppid(p)
    p = os.getpid()
    while p > 1:
        spare.add(p)
        p = ppid(p)
    mine = [int(d) for d in os.listdir("/proc") if d.isdigit() and int(d) not in spare and tag(int(d)) == a.run]
    print("本运行的进程 %d 个：%s" % (len(mine), mine[:30]))
    if not a.kill or not mine:
        return 0
    for pid in mine:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    t0 = time.time()
    while time.time() - t0 < a.grace and any(os.path.exists("/proc/%d" % x) and tag(x) == a.run for x in mine):
        time.sleep(0.5)
    left = [x for x in mine if os.path.exists("/proc/%d" % x) and tag(x) == a.run]
    for pid in left:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    print("已停：TERM %d 个，宽限后 KILL %d 个" % (len(mine), len(left)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
