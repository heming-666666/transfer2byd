#!/usr/bin/env bash
# orch_env.sh —— 任务包通用的运行环境函数（v4.1 起；v5 及以后直接 source 复用）。source 它，不要直接执行。
#   先设好 PKG（包根）与 PKG_RESULTS（结果根），再 . "$PKG/scripts/pkg/orch_env.sh"。
#   端口与临时目录从云端 skill 的 orchd 给的 ORCH_PORT_BASE / ORCH_TMP 派生：并发的 ray/SGLang 不抢端口（v4 问题 4）。
#   函数：port <偏移>、cell_done <任务> <cfg>、wait_http <url> <秒> [pid]、ray_head_start <卡数> [<集群号 0|1>]、
#         ray_job_ready [<秒>] [<集群号>]、ray_dash_url [<集群号>]、own_cleanup（只停本运行的进程）
# 端口排法（每个任务一段 ORCH_PORT_SPAN=200 个端口，B = ORCH_PORT_BASE）：
#   ray 集群 0：B+0…+8，worker +100…+149；集群 1：+10…+18，worker +150…+199；推理服务 B+20…+59；其他自用 B+60…+99
: "${PKG:?PKG 没设（orchd 启动的任务自带；手工跑时 export PKG=<包根>）}"
export ORCH_PORT_BASE="${ORCH_PORT_BASE:-21000}" ORCH_PORT_SPAN="${ORCH_PORT_SPAN:-200}"
export ORCH_TMP="${ORCH_TMP:-/tmp/orch-$(id -un)/manual}"
export RAY_TMPDIR="${RAY_TMPDIR:-$ORCH_TMP/ray}"
mkdir -p "$ORCH_TMP" "$RAY_TMPDIR"
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export PYTHONUNBUFFERED=1

port() { echo $((ORCH_PORT_BASE + $1)); }

cell_done() {   # cell_done <任务> <cfg>：$PKG_RESULTS/<任务>/<cfg>-*/run.json 里有 status=ok 就返回 0（已做完，跳过）
  python3 - "${PKG_RESULTS:?先设 PKG_RESULTS=<结果根，如 \$OPD_RUNTIME/results/v5>}/$1" "$2" <<'PY'
import glob, json, os, sys
d, cfg = sys.argv[1], sys.argv[2]
for p in glob.glob(os.path.join(d, cfg + "-*", "run.json")):
    try:
        if json.load(open(p)).get("status") == "ok":
            sys.exit(0)
    except (OSError, ValueError):
        pass
sys.exit(1)
PY
}

wait_http() {   # wait_http <url> <最长秒> [<进程 pid>]：返回 200 才算好；给了 pid 而进程死了就立即失败
  local url=$1 lim=$2 pid=${3:-} t=0
  while [ "$t" -lt "$lim" ]; do
    if curl -sf -o /dev/null "$url"; then return 0; fi
    if [ -n "$pid" ] && ! kill -0 "$pid" 2>/dev/null; then echo "进程 $pid 已退出，$url 起不来" >&2; return 1; fi
    sleep 3; t=$((t + 3))
  done
  echo "等 $url 超时（$lim s）" >&2; return 1
}

ray_head_start() {   # ray_head_start <卡数> [<集群号 0|1>]：在本运行的端口段与临时目录里起一个独立的 ray head
  local n=$1 k=${2:-0} o w
  o=$((k * 10)); w=$((100 + k * 50))
  : "${RAY_BIN:?v41-env.sh 缺 RAY_BIN（V41-0 第 3 步）}"
  "$RAY_BIN" start --head --node-ip-address 127.0.0.1 --num-gpus "$n" --disable-usage-stats \
    --port "$(port $((o + 0)))" --dashboard-host 127.0.0.1 --dashboard-port "$(port $((o + 1)))" \
    --dashboard-agent-listen-port "$(port $((o + 2)))" --dashboard-agent-grpc-port "$(port $((o + 3)))" \
    --metrics-export-port "$(port $((o + 4)))" --ray-client-server-port "$(port $((o + 5)))" \
    --node-manager-port "$(port $((o + 6)))" --object-manager-port "$(port $((o + 7)))" \
    --runtime-env-agent-port "$(port $((o + 8)))" --min-worker-port "$(port $w)" --max-worker-port "$(port $((w + 49)))" \
    --temp-dir "$RAY_TMPDIR/c$k" ${RAY_START_EXTRA:-}
}

ray_dash_url() { echo "http://127.0.0.1:$(port $(( ${1:-0} * 10 + 1 )))"; }

ray_job_ready() {    # ray_job_ready [<秒>] [<集群号>]：空 body POST /api/jobs/ 返回任何非 000 状态码 = agent 已注册（v4 问题 4 的经验）
  local lim=${1:-300} k=${2:-0} t=0 code
  while [ "$t" -lt "$lim" ]; do
    code=$(curl -s -o /dev/null -w '%{http_code}' -X POST -H 'Content-Type: application/json' -d '{}' \
           "$(ray_dash_url "$k")/api/jobs/" || true)
    if [ -n "$code" ] && [ "$code" != "000" ]; then return 0; fi
    sleep 3; t=$((t + 3))
  done
  echo "ray job agent $lim s 没就绪（$(ray_dash_url "$k")）" >&2; return 1
}

own_cleanup() {      # 只停本运行（ORCH_RUN 标签相同）的进程；不要用 ray stop / pkill（会误杀别的任务，v4 问题 2）
  python3 -I "$PKG/scripts/pkg/own_procs.py" --run "${ORCH_RUN:-}" --spare $$ --kill
}
