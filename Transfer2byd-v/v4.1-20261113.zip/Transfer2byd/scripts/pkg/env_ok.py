#!/usr/bin/env python3
"""环境任务的现状检查（orchd 的 skip_if_cmd；只读，不装、不改任何东西）。v4.1 的 V41-ENV 用它；v5 起直接复用，参数改成本包的。

研究者 2026-11-13：实验按云端现有的版本设计；确实要别的版本时，专门的环境任务优先执行、只新建不改旧（skill R32）。
v4.1 的实验沿用 v4 在这台机器上跑通的环境，所以正常情况下这里退 0，V41-ENV 直接判完成，不开窗，后面的任务马上就绪。

检查：
  1. $OPD_RUNTIME/state/probe-env.sh 在，必需变量都有（V4-0 第 2 步写的）；
  2. OPD_PY 能 import torch，SGLANG_PY 能 import sglang（打印版本，留作记录）；
  3. $OPD_RUNTIME/state/versions/*.json 里有基线的环境（v4 记录的），逐个包对比现状：变了就是漂移。
     没有基线的只记一行“无基线”，不算失败。versions.lock 里的 pin 是更早的包写的，不作判据。
  环境被 V41-ENV 换过（v41-env-override.sh 里写了新解释器）时，检查新解释器。

退出码：0 全部满足；1 有不满足的（orchd 开 V41-ENV 的环境窗，照 routes/V41-总览与门控.md 第 8 节新建隔离环境）。
用法：python3 -I env_ok.py [--runtime $OPD_RUNTIME] [--env-file state/probe-env.sh] [--override state/v41-env-override.sh]
            [--need VAR1,VAR2] [--import OPD_PY:torch --import SGLANG_PY:sglang] [--baselines state/versions]
      （相对路径都相对 --runtime；不写就是 v4.1 的默认值）
"""
import argparse
import glob
import json
import os
import re
import subprocess
import sys

NEED = ("OPD_PY", "SGLANG_PY", "OPD_SCORER", "OPD_STUDENT", "OPD_PACKED", "OPD_SEQS", "OPD_PROMPTS")
PROBE = ("import importlib.metadata as m, json, platform; print(json.dumps({'python': platform.python_version(), "
         "'packages': {(d.metadata['Name'] or '').lower(): d.version for d in m.distributions()}}))")


def read_sh(path):
    """读 bash 的 KEY=VALUE 行（不执行；只认简单赋值，引号去掉）。"""
    out = {}
    try:
        for line in open(path, encoding="utf-8"):
            for part in line.strip().split(";"):
                m = re.match(r"\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)=(.*)$", part)
                if m and not part.strip().startswith("#"):
                    out[m.group(1)] = m.group(2).split(" #")[0].strip().strip('"').strip("'")
    except OSError:
        pass
    return out


def run(py, code, timeout=120):
    try:
        r = subprocess.run([py, "-c", code], capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr).strip()
    except (OSError, subprocess.TimeoutExpired) as e:
        return 127, repr(e)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runtime", default=os.environ.get("OPD_RUNTIME", ""))
    ap.add_argument("--env-file", default="state/probe-env.sh")
    ap.add_argument("--override", default="state/v41-env-override.sh")
    ap.add_argument("--need", default=",".join(NEED))
    ap.add_argument("--import", dest="imports", action="append", default=[], help="变量名:模块，例如 OPD_PY:torch（可多次）")
    ap.add_argument("--baselines", default="state/versions")
    a = ap.parse_args()
    rt = lambda x: x if os.path.isabs(x) else os.path.join(a.runtime, x)
    imports = [tuple(x.split(":", 1)) for x in a.imports] or [("OPD_PY", "torch"), ("SGLANG_PY", "sglang")]
    bad = []
    pe = rt(a.env_file)
    if not os.path.isfile(pe):
        print("缺 %s（V4-0 第 2 步写的）" % pe)
        return 1
    env = read_sh(pe)
    env.update(read_sh(rt(a.override)))
    for v in [x for x in a.need.split(",") if x]:
        if not env.get(v):
            bad.append("probe-env.sh 缺 %s" % v)
    for var, mod in imports:
        py = env.get(var, "")
        if not py or not os.access(py, os.X_OK):
            bad.append("%s 不可执行：%s" % (var, py or "（空）"))
            continue
        rc, out = run(py, "import %s; print('%s', %s.__version__)" % (mod, mod, mod))
        print("%s %s：%s" % (var, py, out.splitlines()[-1] if out else ""))
        if rc != 0:
            bad.append("%s 导不进 %s：%s" % (var, mod, out[-200:]))
    for f in sorted(glob.glob(os.path.join(rt(a.baselines), "*.json"))):
        try:
            base = json.load(open(f, encoding="utf-8"))
        except (OSError, ValueError):
            bad.append("基线读不出：%s" % f)
            continue
        py = base.get("python_path", "")
        for var, _ in imports:                      # 环境被环境任务换过：对比新解释器（它有自己的新基线）
            if env.get(var) and read_sh(pe).get(var) == py and env[var] != py:
                py = ""
        if not py:
            print("基线 %s：环境已换成新建的隔离环境，跳过" % os.path.basename(f))
            continue
        if not os.access(py, os.X_OK):
            bad.append("基线 %s 记的解释器不在了：%s" % (os.path.basename(f), py))
            continue
        rc, out = run(py, PROBE)
        if rc != 0:
            bad.append("基线 %s 的解释器跑不起来：%s" % (os.path.basename(f), out[-200:]))
            continue
        cur = json.loads(out.splitlines()[-1]).get("packages", {})
        old = base.get("all_packages", {})
        diff = ["%s %s -> %s" % (p, v, cur.get(p, "removed")) for p, v in old.items() if cur.get(p) != v]
        diff += ["%s 新增 %s" % (p, v) for p, v in cur.items() if p not in old]
        if diff:
            bad.append("环境 %s 自 v4 的基线以来变了 %d 处：%s" % (base.get("env", f), len(diff), "；".join(diff[:8])))
        else:
            print("环境 %s：与 v4 的基线一致（%d 个包）" % (base.get("env", f), len(cur)))
    if not glob.glob(os.path.join(rt(a.baselines), "*.json")):
        print("无基线（v4 没记录 versions/*.json）：只做可用性检查")
    if bad:
        print("不满足 %d 项：" % len(bad))
        for x in bad:
            print("  - " + x)
        return 1
    print("OK：本包要用的环境都在、能用、没漂移")
    return 0


if __name__ == "__main__":
    sys.exit(main())
