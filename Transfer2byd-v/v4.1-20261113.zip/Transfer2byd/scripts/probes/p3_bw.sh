#!/usr/bin/env bash
# V4-P3 一格：N 张卡同时从主机内存按层流式（32B 教师），看每卡拷贝带宽随卡数的变化。整机安静时跑。
# 用法（经 opd_run.py --gpus N --timing-sensitive）：bash p3_bw.sh [教师，默认 qwen3-32b]
source "$(dirname "$0")/common.sh"
TEA="${1:-qwen3-32b}"; N="$(echo "$OPD_GPU_IDS" | tr ',' '\n' | wc -l)"
GL="$(seq -s, 0 $((N - 1)))"
echo "step 1/1 gpus=$N"
"$OPD_PY" "$OPD_SCORER" bench --packed "$OPD_PACKED/$TEA" --gpus "$GL" --mode stream --tokens-per-gpu 32768 \
  --seq-len 4096 --repeats 3 --out "$RUN/bench-bw-n$N.json"
numactl --hardware > "$RUN/numa.txt" 2>&1 || true
nvidia-smi topo -m > "$RUN/topo.txt" 2>&1 || true
