#!/usr/bin/env bash
# V4-P4 一格：稠密教师的流式持平点，以及真实异长序列上每层实际拷贝几次（O004 的“形状/摊销”问题）。
# 用法（经 opd_run.py，--gpus 1）：bash p4_breakeven.sh <教师，如 qwen3-8b 或 qwen3-32b>
source "$(dirname "$0")/common.sh"
TEA="$1"
i=0
for mode in stream resident; do
  i=$((i + 1)); echo "step $i/3 $mode"
  "$OPD_PY" "$OPD_SCORER" bench --packed "$OPD_PACKED/$TEA" --gpus 0 --mode "$mode" --tokens-per-gpu 8192 32768 131072 \
    --seq-len 4096 --repeats 3 --out "$RUN/bench-$mode.json" || echo "{\"mode\":\"$mode\",\"status\":\"failed\"}" > "$RUN/bench-$mode.failed"
done
echo "step 3/3 real-shape"
# 真实一步的 240 条（长度各不相同）：打分器打印每张卡的 timing；n_copies = copy_s_sum / copy_s_mean，应等于层数
"$OPD_PY" "$OPD_SCORER" score --packed "$OPD_PACKED/$TEA" --gpus 0 --mode stream --seqs "$OPD_SEQS" --limit 240 \
  --out "$RUN/score-real.jsonl" > "$RUN/score-real-timing.json"
"$OPD_PY" - "$RUN/score-real-timing.json" "$OPD_PACKED/$TEA/meta.json" > "$RUN/real-shape.json" <<'PY'
import json, sys
t = json.load(open(sys.argv[1])); meta = json.load(open(sys.argv[2]))
out = {}
for r, x in t.items():
    n = x["copy_s_sum"] / x["copy_s_mean"] if x.get("copy_s_mean") else None
    out[r] = {"n_copies": n, "n_layers": meta["n_layers"], "copies_per_layer": n / meta["n_layers"] if n else None,
              "wall_s": x["wall_s"], "copy_s_sum": x["copy_s_sum"], "tokens": x.get("tokens")}
print(json.dumps(out))
PY
rm -f "$RUN/score-real.jsonl"
