#!/usr/bin/env bash
# 探针脚本共用：环境变量检查、起停学生引擎。由 opd_run.py 启动时 OPD_RUN_DIR、OPD_GPU_IDS 已设好。
# 必须设置（V4-0 第 2 步写进 $OPD_RUNTIME/state/probe-env.sh，每个探针开头 source 它）：
#   PKG        包目录          OPD_PY      有 torch 的 python（v3 跑 lm_scorer 用的那个）
#   OPD_SCORER v3 通过自测的 lm_scorer.py 冻结副本     SGLANG_PY  有 sglang 的 python
#   OPD_STUDENT 学生 Qwen3-4B 的目录                    OPD_PACKED  打包教师的根目录（如 /dev/shm/proctor）
#   OPD_SEQS   一步的真实序列 seqs.jsonl（V3-2 cap 那一步）  OPD_PROMPTS  渲染好的 240 条提示 prompts-v32.jsonl
#   OPD_TEMP、OPD_TOPP  与 V3-2 相同的采样参数
set -euo pipefail
[[ -f "${OPD_RUNTIME:?}/state/probe-env.sh" ]] && source "$OPD_RUNTIME/state/probe-env.sh"
for v in PKG OPD_PY OPD_SCORER SGLANG_PY OPD_STUDENT OPD_PACKED OPD_SEQS OPD_PROMPTS; do
  [[ -n "${!v:-}" ]] || { echo "[probe] 缺环境变量 $v（见 scripts/probes/common.sh 开头）" >&2; exit 2; }
done
OPD_TEMP="${OPD_TEMP:-1.0}"; OPD_TOPP="${OPD_TOPP:-1.0}"
RUN="${OPD_RUN_DIR:?必须经 opd_run.py 启动}"
G0="$(echo "${OPD_GPU_IDS:?}" | cut -d, -f1)"
PORT="${OPD_PORT:-$((30050 + 10 * G0))}"
ENGINE_NAME="probe-$(basename "$RUN")"
export SGLANG_HOST_SKIP_DEEPGEMM=1     # v3 V3-R1：本机 nvcc 12.4，DeepGEMM JIT 起不来；两臂同一开关
start_engine() {   # $1 = 显存占比；学生引擎占这张卡的一部分显存，模拟“与学生同卡”
  SGLANG_PY="$SGLANG_PY" bash "$PKG/scripts/launch-sglang.sh" start "$ENGINE_NAME" "$OPD_STUDENT" "$CUDA_VISIBLE_DEVICES" "$PORT" \
    --tp-size 1 --mem-fraction-static "$1" --context-length 9216 > "$RUN/engine-start.txt"
  bash "$PKG/scripts/launch-sglang.sh" wait "$PORT" 1800
  ls -t "$OPD_RUNTIME"/logs/sglang-"$ENGINE_NAME"-*.log | head -1 > "$RUN/engine-log-path.txt"
}
stop_engine() { bash "$PKG/scripts/launch-sglang.sh" stop "$ENGINE_NAME" || true; }
engine_log() { cat "$RUN/engine-log-path.txt" 2>/dev/null; }
model_name() { curl -sf "http://127.0.0.1:$PORT/v1/models" | "$OPD_PY" -c 'import json,sys;print(json.load(sys.stdin)["data"][0]["id"])'; }
