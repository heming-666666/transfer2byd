#!/usr/bin/env bash
# V4-P5 一格：学生生成的尾部是不是吞吐问题。同一批题两种发法：wave（每批 C 条，写完才发下一批 = 同步 OPD 一步）
# 与 refill（始终 C 条在跑）。用法（经 opd_run.py，--gpus 1）：bash p5_refill.sh <C，默认 240> <总条数，默认 960> <显存占比，默认 0.60>
source "$(dirname "$0")/common.sh"
C="${1:-240}"; N="${2:-960}"; MEM="${3:-0.60}"
trap stop_engine EXIT
start_engine "$MEM"; M="$(model_name)"
"$OPD_PY" "$PKG/scripts/gen_bench.py" --url "http://127.0.0.1:$PORT" --model "$M" --prompts "$OPD_PROMPTS" \
  --concurrency "$C" --n "$N" --max-tokens 8192 --temperature "$OPD_TEMP" --top-p "$OPD_TOPP" --mode both --out "$RUN/gen_bench.json"
python3 -I "$PKG/scripts/engine_scan.py" --log "$(engine_log)" --out "$RUN/engine.csv" || true
