#!/usr/bin/env bash
# V4-P2 一格：同卡打分对学生生成的干扰。四种情形：满载/尾部 × 打分关/开（打分 = 32B 教师按层流式，循环打同一批序列）。
# 用法（经 opd_run.py，--gpus 1）：bash p2_interf.sh <满载并发，默认 240> <学生引擎显存占比，默认 0.40> <教师，默认 qwen3-32b>
source "$(dirname "$0")/common.sh"
FULL="${1:-240}"; MEM="${2:-0.40}"; TEA="${3:-qwen3-32b}"; TAIL=$((FULL / 4))
trap 'kill $(jobs -p) 2>/dev/null || true; stop_engine' EXIT
start_engine "$MEM"; M="$(model_name)"
gb() { "$OPD_PY" "$PKG/scripts/gen_bench.py" --url "http://127.0.0.1:$PORT" --model "$M" --prompts "$OPD_PROMPTS" \
        --concurrency "$1" --n "$2" --max-tokens 8192 --temperature "$OPD_TEMP" --top-p "$OPD_TOPP" --out "$RUN/gen-$3.json"; }
source "$(dirname "$0")/score_loop.sh"   # score_loop / score_ok（v4.1：打分失败不再空转、不交假结果）
echo "step 1/4"; gb "$FULL" "$FULL" full-off
echo "step 2/4"; gb "$TAIL" "$TAIL" tail-off
score_loop & SL=$!; sleep 60     # 等打分进入稳态（第一次要映射主机内存、登记 pinned）
score_ok "$SL" "开始 full-on 之前" || exit 3
echo "step 3/4"; gb "$FULL" "$FULL" full-on
score_ok "$SL" "full-on 之后" || exit 3
echo "step 4/4"; gb "$TAIL" "$TAIL" tail-on
score_ok "$SL" "tail-on 之后" || exit 3
kill $SL 2>/dev/null || true
