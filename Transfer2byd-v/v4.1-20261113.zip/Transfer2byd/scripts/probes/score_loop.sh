#!/usr/bin/env bash
# P2 用的“一直打分”循环（由 p2_interf.sh source）。v4.1 加了保护：v4 的写法是 while true，打分器一启动就失败时
# 会空转刷错误，而“打分开”的两格照样量出来，其实没在打分（v4 问题 7 的同类）。现在：
#   每次打分成功写一行进 $RUN/score-loop.jsonl；连续 3 次失败就写 $RUN/score-loop.failed 并退出（失败间隔 5 秒，不空转）；
#   p2_interf.sh 在“打分开”的两格前后检查这个标记与循环是否还活着，不对就整格判失败（exit 3），不交假结果。
# 打分成功时的行为与 v4 完全相同（同一条命令、同一输出），所以不影响与 v4 已有运行的可比性。
score_loop() {
  local fails=0
  while true; do
    if "$OPD_PY" "$OPD_SCORER" score --packed "$OPD_PACKED/$TEA" --gpus 0 --mode stream --seqs "$OPD_SEQS" --limit 64 \
        --out "$RUN/score-tmp.jsonl" 2>>"$RUN/score-loop.err" > "$RUN/score-one.json"; then
      tr -d '\n' < "$RUN/score-one.json" >> "$RUN/score-loop.jsonl"; echo >> "$RUN/score-loop.jsonl"
      fails=0
    else
      fails=$((fails + 1))
      echo "{\"error\": \"scorer exit != 0\", \"consecutive\": $fails, \"t\": $(date +%s)}" >> "$RUN/score-loop.jsonl"
      if [ "$fails" -ge 3 ]; then
        echo "打分连续 $fails 次失败（看 $RUN/score-loop.err）" > "$RUN/score-loop.failed"
        return 1
      fi
      sleep "${SCORE_RETRY_SLEEP:-5}"
    fi
  done
}
score_ok() {   # score_ok <循环的 pid> <阶段>：循环还活着、没写失败标记才算“打分开”有效
  if [ -f "$RUN/score-loop.failed" ] || ! kill -0 "$1" 2>/dev/null; then
    echo "[P2] $2：打分循环没在跑（$(cat "$RUN/score-loop.failed" 2>/dev/null || echo 进程已退出)）；“打分开”的格作废" >&2
    return 1
  fi
}
