#!/usr/bin/env bash
# V4-P1 一格：同一张卡上先起学生引擎（占比 $2），再比较 K 个教师的三种放法。
# 用法（经 opd_run.py，--gpus 1）：bash p1_pool.sh <教师列表，如 qwen3-8b,qwen3-14b> <学生引擎显存占比，默认 0.40>
source "$(dirname "$0")/common.sh"
T="$1"; MEM="${2:-0.40}"
list=""; for t in ${T//,/ }; do list="$list,$OPD_PACKED/$t"; done; list="${list#,}"
trap stop_engine EXIT
start_engine "$MEM"
echo "step 1/2 engine ready"
"$OPD_PY" "$PKG/scripts/pool_bench.py" --scorer "$OPD_SCORER" --gpu 0 --seqs "$OPD_SEQS" --limit 240 \
  --teachers "$list" --arms R,S,M --repeats 2 --out "$RUN/pool_bench.json"
echo "step 2/2 done"
