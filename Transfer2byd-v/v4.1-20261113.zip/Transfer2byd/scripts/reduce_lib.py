#!/usr/bin/env python3
"""Cloud-side data reduction with a measured, bounded distortion (Transfer2byd template, spec 07 §3.10.1).

Why: the researcher never reads raw data directly; they reduce it first. Doing the same reduction on the cloud,
with the script shipped in the package, keeps the return small enough to copy by hand. Every reduction
reports how much it changed the statistics that analysis depends on, so a reduction that distorts the
data is caught on the cloud, not after the return.

Standard library only. Import it from task scripts, or use the CLI:
    python3 -I scripts/reduce_lib.py selftest
    python3 -I scripts/reduce_lib.py timeline IN.csv OUT.csv --eps-tokens 64 [--group task,cfg,seed,step,rollout_id]
        (columns n_tokens and t_s are required; prints one manifest JSON line for 08-script-outputs.jsonl)
    python3 -I scripts/reduce_lib.py summary IN.csv --col final_len [--group cfg]
        (prints quantile summaries as 05-metrics rows on stdout)

Rules the functions enforce (docs/20 of each package states which data may be reduced at all):
- quantile summaries always include n, min, max and p99/p99.9, so tails are never lost;
- timeline reduction keeps the first point, the last point (completion) and every point needed to stay
  within eps tokens of the raw curve under linear interpolation; it reports the max error it measured;
- `check` recomputes the key statistics on raw and reduced data; any difference above tolerance means
  "do not reduce this item, return it raw" and is written to the manifest.
"""
import csv
import hashlib
import json
import math
import random
import sys
from pathlib import Path

QS = (0.0, 0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 0.999, 1.0)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def quantile(sorted_vals, q):
    """Linear interpolation between closest ranks (same as numpy's default 'linear')."""
    n = len(sorted_vals)
    if n == 0:
        return float("nan")
    pos = q * (n - 1)
    lo = math.floor(pos)
    hi = min(lo + 1, n - 1)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (pos - lo)


def summarize(values, qs=QS):
    """Exact summary: n, mean, every quantile in qs (min and max included). Never drops the tail."""
    v = sorted(float(x) for x in values)
    out = {"n": len(v), "mean": (sum(v) / len(v)) if v else float("nan")}
    for q in qs:
        out[f"p{q * 100:g}"] = quantile(v, q)
    return out


def histogram(values, edges):
    """Fixed-bin counts; values outside the edges go to under/over so nothing is silently dropped."""
    counts = [0] * (len(edges) - 1)
    under = over = 0
    for x in values:
        x = float(x)
        if x < edges[0]:
            under += 1
        elif x >= edges[-1]:
            over += 1
        else:
            lo, hi = 0, len(edges) - 1
            while hi - lo > 1:
                mid = (lo + hi) // 2
                if x >= edges[mid]:
                    lo = mid
                else:
                    hi = mid
            counts[lo] += 1
    return {"edges": list(edges), "counts": counts, "under": under, "over": over}


def _interp(ts, ys, t):
    for i in range(1, len(ts)):
        if t <= ts[i]:
            if ts[i] == ts[i - 1]:
                return ys[i]
            return ys[i - 1] + (ys[i] - ys[i - 1]) * (t - ts[i - 1]) / (ts[i] - ts[i - 1])
    return ys[-1]


def reduce_curve(points, eps):
    """Ramer-Douglas-Peucker on (t, y) with a vertical error bound eps (in y units, e.g. tokens).

    points: list of (t, y) sorted by t. Keeps first and last. Returns (kept_indices, max_vertical_error)."""
    n = len(points)
    if n <= 2:
        return list(range(n)), 0.0
    keep = {0, n - 1}
    stack = [(0, n - 1)]
    while stack:
        a, b = stack.pop()
        ta, ya = points[a]
        tb, yb = points[b]
        worst, wi = -1.0, None
        for i in range(a + 1, b):
            t, y = points[i]
            yi = ya if tb == ta else ya + (yb - ya) * (t - ta) / (tb - ta)
            d = abs(y - yi)
            if d > worst:
                worst, wi = d, i
        if wi is not None and worst > eps:
            keep.add(wi)
            stack += [(a, wi), (wi, b)]
    idx = sorted(keep)
    ts = [points[i][0] for i in idx]
    ys = [points[i][1] for i in idx]
    err = max(abs(y - _interp(ts, ys, t)) for t, y in points)
    return idx, err


def check(raw_stats, red_stats, tol):
    """Compare statistics computed on raw vs reduced data. tol: {key: (abs_tol, rel_tol)}. Returns list of failures."""
    bad = []
    for k, (at, rt) in tol.items():
        a, b = raw_stats.get(k), red_stats.get(k)
        if a is None or b is None:
            bad.append({"key": k, "raw": a, "reduced": b, "why": "missing"})
            continue
        if abs(a - b) > max(at, rt * abs(a)):
            bad.append({"key": k, "raw": a, "reduced": b, "why": "outside tolerance"})
    return bad


def manifest(task, script, inputs, params, rows_in, rows_out, checks, extra=None):
    """One JSON line for 08-script-outputs.jsonl describing a reduction (kind=reduce)."""
    rec = {
        "kind": "reduce", "task": task, "script": str(script),
        "script_sha256": sha256_file(script) if Path(script).exists() else None,
        "inputs": [{"path": str(p), "sha256": sha256_file(p)} for p in inputs if Path(p).exists()],
        "params": params, "rows_in": rows_in, "rows_out": rows_out,
        "ratio": round(rows_out / rows_in, 6) if rows_in else None,
        "checks": checks, "ok": not any(c.get("failures") for c in checks),
    }
    if extra:
        rec.update(extra)
    return rec


def reduce_timeline_csv(src, dst, eps_tokens, group_cols):
    with open(src, encoding="utf-8", newline="") as f:
        rd = csv.DictReader(f)
        cols = rd.fieldnames
        rows = list(rd)
    groups = {}
    for r in rows:
        groups.setdefault(tuple(r.get(c, "") for c in group_cols), []).append(r)
    out, max_err = [], 0.0
    for g in groups.values():
        g.sort(key=lambda r: float(r["t_s"]))
        pts = [(float(r["t_s"]), float(r["n_tokens"])) for r in g]
        idx, err = reduce_curve(pts, eps_tokens)
        max_err = max(max_err, err)
        out += [g[i] for i in idx]
    with open(dst, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(out)
    # Double calculation: the quantities analysis uses (completion time and final length per curve) must be exact.
    def finals(rs):
        last = {}
        for r in rs:
            k = tuple(r.get(c, "") for c in group_cols)
            if k not in last or float(r["t_s"]) >= float(last[k]["t_s"]):
                last[k] = r
        return summarize([float(r["t_s"]) for r in last.values()]), summarize([float(r["n_tokens"]) for r in last.values()])
    (rt, rn), (dt, dn) = finals(rows), finals(out)
    tol = {k: (1e-9, 0.0) for k in ("n", "p0", "p50", "p99", "p100")}
    checks = [{"name": "completion_time", "failures": check(rt, dt, tol)},
              {"name": "final_tokens", "failures": check(rn, dn, tol)},
              {"name": "max_interp_error_tokens", "value": max_err, "bound": eps_tokens,
               "failures": [] if max_err <= eps_tokens + 1e-9 else [{"why": "bound exceeded"}]}]
    return manifest("", __file__, [src], {"eps_tokens": eps_tokens, "group": group_cols},
                    len(rows), len(out), checks)


def selftest():
    rnd = random.Random(1)
    vals = [rnd.lognormvariate(7, 0.8) for _ in range(10000)]
    s = summarize(vals)
    assert s["n"] == 10000 and s["p0"] == min(vals) and s["p100"] == max(vals)
    assert abs(s["p50"] - sorted(vals)[4999] ) < 50
    h = histogram(vals, [0, 1000, 2000, 4000, 8000])
    assert sum(h["counts"]) + h["under"] + h["over"] == 10000
    # a curve with a stall and a burst: reduction must keep the corners and respect the bound
    pts, y = [], 0
    for i in range(2000):
        y += 0 if 800 <= i < 1000 else (5 if i < 1500 else 20)
        pts.append((i * 0.01, y))
    idx, err = reduce_curve(pts, 8)
    assert err <= 8 and 0 in idx and len(pts) - 1 in idx and len(idx) < 50, (len(idx), err)
    assert check({"p99": 1.0}, {"p99": 1.2}, {"p99": (0.0, 0.1)})
    assert not check({"p99": 1.0}, {"p99": 1.05}, {"p99": (0.0, 0.1)})
    print(json.dumps({"selftest": "ok", "curve_points_kept": len(idx), "curve_max_err": err}))


def main(argv):
    if not argv or argv[0] == "selftest":
        return selftest()
    if argv[0] == "timeline":
        src, dst = argv[1], argv[2]
        eps = float(argv[argv.index("--eps-tokens") + 1]) if "--eps-tokens" in argv else 64.0
        group = (argv[argv.index("--group") + 1].split(",") if "--group" in argv
                 else ["task", "cfg", "seed", "step", "rollout_id"])
        print(json.dumps(reduce_timeline_csv(src, dst, eps, group), ensure_ascii=False))
        return
    if argv[0] == "summary":
        src = argv[1]
        col = argv[argv.index("--col") + 1]
        group = argv[argv.index("--group") + 1].split(",") if "--group" in argv else []
        with open(src, encoding="utf-8", newline="") as f:
            rows = [r for r in csv.DictReader(f) if r.get(col) not in ("", None)]
        groups = {}
        for r in rows:
            groups.setdefault(tuple(r[c] for c in group), []).append(float(r[col]))
        w = csv.writer(sys.stdout, lineterminator="\n")
        w.writerow(["group", "key", "value", "n"])
        for g, v in sorted(groups.items()):
            s = summarize(v)
            for k, val in s.items():
                if k != "n":
                    w.writerow(["/".join(g), f"{col}_{k}", f"{val:.6g}", s["n"]])
        return
    sys.exit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
