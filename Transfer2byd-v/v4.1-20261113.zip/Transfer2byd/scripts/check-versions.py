#!/usr/bin/env python3
"""Keep software versions consistent with the package guidance (docs/16, state/versions.lock.json). stdlib only.

  check-versions.py record --env sglang --python $OPD_RUNTIME/envs/sglang/bin/python   # once, right after install
  check-versions.py check  --env sglang --python $OPD_RUNTIME/envs/sglang/bin/python   # before every task
  check-versions.py show   --env sglang
record: writes the baseline $OPD_RUNTIME/state/versions/<env>.json (refuses to overwrite without --force; a new
version means a NEW env, see docs/16). check: compares installed packages with the pins in versions.lock.json and
with the baseline; exit 0 = consistent, 1 = drift (write it into return.yaml and emit version_drift_detected).
"""
import argparse
import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent
RT = Path(os.environ.get("OPD_RUNTIME", Path.home() / "opd-runtime"))
PROBE = ("import importlib.metadata as m, json, platform, sys; print(json.dumps({'python': platform.python_version(), "
         "'packages': {(d.metadata['Name'] or '').lower(): d.version for d in m.distributions()}}))")


def norm(name):
    return name.lower().replace("_", "-")


def installed(py):
    out = subprocess.run([py, "-c", PROBE], capture_output=True, text=True, timeout=300)
    if out.returncode:
        raise SystemExit(f"cannot query {py}: {out.stderr.strip()[-300:]}")
    d = json.loads(out.stdout)
    d["packages"] = {norm(k): v for k, v in d["packages"].items() if k}
    return d


def lock():
    f = PKG / "state" / "versions.lock.json"
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {"envs": {}}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("cmd", choices=["record", "check", "show"])
    ap.add_argument("--env", required=True); ap.add_argument("--python"); ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    base_f = RT / "state" / "versions" / f"{a.env}.json"
    spec = lock().get("envs", {}).get(a.env)
    if spec is None:
        print(f"env {a.env!r} is not in state/versions.lock.json; add it there first (docs/16)"); return 2
    if a.cmd == "show":
        print(json.dumps({"lock": spec, "baseline": json.loads(base_f.read_text()) if base_f.exists() else None},
                         ensure_ascii=False, indent=1)); return 0
    if not a.python:
        print("--python is required"); return 2
    cur = installed(a.python)
    if a.cmd == "record":
        if base_f.exists() and not a.force:
            print(f"baseline exists: {base_f}. Changing versions means a new env (docs/16), not a new baseline."); return 1
        base_f.parent.mkdir(parents=True, exist_ok=True)
        keep = [norm(p) for p in list(spec.get("pins", {})) + spec.get("record", [])]
        snap = {"env": a.env, "python_path": a.python, "python": cur["python"],
                "recorded": dt.datetime.now().astimezone().isoformat(timespec="minutes"),
                "key_packages": {p: cur["packages"].get(p, "missing") for p in keep}, "all_packages": cur["packages"]}
        base_f.write_text(json.dumps(snap, ensure_ascii=False, indent=1))
        print(json.dumps(snap["key_packages"], ensure_ascii=False)); return 0
    problems = []
    for p, want in spec.get("pins", {}).items():
        got = cur["packages"].get(norm(p), "missing")
        if got != want:
            problems.append(f"pin {p}: lock {want}, installed {got}")
    if base_f.exists():
        base = json.loads(base_f.read_text())
        for p, v in base["all_packages"].items():
            if cur["packages"].get(p) != v:
                problems.append(f"changed since baseline {p}: {v} -> {cur['packages'].get(p, 'removed')}")
        problems += [f"added since baseline {p}=={v}" for p, v in cur["packages"].items() if p not in base["all_packages"]]
    else:
        problems.append(f"no baseline yet: run `record` for env {a.env} right after installing it")
    if problems:
        print(f"DRIFT in env {a.env} ({len(problems)}):"); print("\n".join("  " + x for x in problems[:60])); return 1
    print(f"env {a.env}: consistent with lock and baseline ({len(cur['packages'])} packages)"); return 0


if __name__ == "__main__":
    sys.exit(main())
