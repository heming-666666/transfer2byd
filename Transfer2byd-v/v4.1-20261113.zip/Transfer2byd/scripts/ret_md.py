#!/usr/bin/env python3
"""ret_md: 回传的 markdown 代码块容器（mdb1）。只用 Python 3.10 标准库。

云端：  python3 -I ret_md.py pack   --in <回传文件目录> --out <md 目录> --ret-id <回传号>
本机：  python3 -I ret_md.py unpack <docx|txt|md ...> --out <还原目录>
        python3 -I ret_md.py list   <docx|txt|md ...>          # 只看收到了哪些块

格式（每个源文件一个 .md；每个代码块连同块头块尾不超过 --block 字，默认 30000）：

    ### 05-metrics.csv 块 3/18            <- 代码块外，给人看的，丢了不影响还原
    ````text
    #mdb1 B ret=<回传号> file=<文件名> blk=3/18 lines=<行数> nl=<0|1> crc=<8 位十六进制>
    <内容行> ...
    #mdb1 E ret=<回传号> file=<文件名> blk=3/18
    ````

- 块头、块尾在代码块里面，复制代码块时一起带走；还原只认 `#mdb1 B … #mdb1 E`，
  与代码块外的文字、围栏是否还在、一个 docx 里放了几块、docx 在哪里断开都无关。
- crc 是这一块原始内容（UTF-8 字节）的 CRC32；nl=0 表示这一块的末尾不是换行
  （长行被切开，下一块接着同一行）。
- 内容行的转写（还原时逆转）：
    空行                              -> `\\0`
    以 `\\` 或 `#mdb1` 开头、以代码围栏（``` 或 ~~~）开头、行尾有空白、
    含制表符或其他控制字符、含不间断空格或零宽字符、含弯引号的行
                                      -> `\\j` + JSON 字符串转义的内容 + `\\e`
    其余                              -> 原样
  所以内容里不会出现能提前关闭代码块的围栏，块的首尾也不会是空行。
- `00-INDEX` 这个文件列出每个文件的字节数、行数、块数和 sha256，还原后逐个核对。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import zipfile
import zlib
from html import unescape

FMT = "mdb1"
INDEX_NAME = "00-INDEX.tsv"
NAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,80}$")
RETID_RE = re.compile(r"^[A-Za-z0-9-]{4,40}$")
HDR_RE = re.compile(r"^#mdb1 B ret=([A-Za-z0-9-]{4,40}) file=([A-Za-z0-9._-]{1,80}) blk=(\d+)/(\d+) "
                    r"lines=(\d+) nl=([01]) crc=([0-9a-f]{8})$")
END_RE = re.compile(r"^#mdb1 E ret=([A-Za-z0-9-]{4,40}) file=([A-Za-z0-9._-]{1,80}) blk=(\d+)/(\d+)$")
FENCE_RE = re.compile(r"^\s*(`{3,}|~{3,})")
RISKY_RE = re.compile("[\x00-\x1f\x7f\u0085\u00a0\u1680\u2000-\u200f\u2028-\u202f\u205f-\u2064\u3000\ufeff]")
QUOTE_RE = re.compile("[\u2018\u2019\u201c\u201d\u2032\u2033]")   # 弯引号：原文里有就转写，收到的弯引号一定是粘贴造成的
JOIN = "\x00"          # 两个输入文件之间的接缝（可能落在一行中间）
OVERHEAD = 220         # 块头 + 块尾的字数上限


# ---------------------------------------------------------------- 行转写

def enc_line(s: str) -> str:
    if s == "":
        return "\\0"
    if (s[0] == "\\" or s.startswith("#mdb1") or FENCE_RE.match(s) or s[-1] in " \t"
            or RISKY_RE.search(s) or QUOTE_RE.search(s)):
        body = json.dumps(s, ensure_ascii=False)[1:-1]
        body = RISKY_RE.sub(lambda m: "\\u%04x" % ord(m.group()), body)
        body = QUOTE_RE.sub(lambda m: "\\u%04x" % ord(m.group()), body)
        if body.endswith(" "):
            body = body[:-1] + "\\u0020"
        if FENCE_RE.match(body):          # 不会发生（前面有 \j），保险起见
            body = "\\u%04x" % ord(body[0]) + body[1:]
        return "\\j" + body + "\\e"
    return s


def dec_line(s: str) -> str:
    if s == "\\0":
        return ""
    if s.startswith("\\j"):
        if not s.endswith("\\e"):
            raise ValueError("转写行缺少结束标记")
        return json.loads('"' + s[2:-2] + '"')
    return s


# ---------------------------------------------------------------- 打包

def split_chunks(text: str, limit: int):
    """把文本切成块：每块转写后的字数不超过 limit；优先在行边界切。"""
    lines = text.split("\n")
    tail_nl = text.endswith("\n")
    if tail_nl:
        lines.pop()
    chunks, cur, cur_len = [], [], 0
    # 每个元素：(原始片段, 片段后是否有换行)
    items = []
    for i, ln in enumerate(lines):
        has_nl = tail_nl or i < len(lines) - 1
        # 超长行硬切（按原始字符切；转写可能变长，所以保守地按 limit//7 切含转义的行）
        step = limit if enc_line(ln) == ln or ln == "" else max(64, limit // 7)
        if len(enc_line(ln)) <= limit:
            items.append((ln, has_nl))
        else:
            for k in range(0, len(ln), step):
                seg = ln[k:k + step]
                items.append((seg, has_nl and k + step >= len(ln)))
    for seg, has_nl in items:
        n = len(enc_line(seg)) + 1
        if cur and (cur_len + n > limit or not cur[-1][1]):
            # 上一段没有换行（长行的一段）时必须单独成块，保证“只有块尾可能缺换行”
            chunks.append(cur)
            cur, cur_len = [], 0
        cur.append((seg, has_nl))
        cur_len += n
    if cur:
        chunks.append(cur)
    return chunks


def pack_text(name: str, text: str, ret_id: str, block: int):
    limit = block - OVERHEAD
    chunks = split_chunks(text, limit)
    if not chunks:
        chunks = [[]]
    n = len(chunks)
    out, blocks = [], []
    for i, ch in enumerate(chunks, 1):
        raw = "".join(seg + ("\n" if nl else "") for seg, nl in ch)
        nl = 1 if (not ch or ch[-1][1]) else 0
        crc = "%08x" % (zlib.crc32(raw.encode("utf-8")) & 0xFFFFFFFF)
        body = [f"#mdb1 B ret={ret_id} file={name} blk={i}/{n} lines={len(ch)} nl={nl} crc={crc}"]
        body += [enc_line(seg) for seg, _ in ch]
        body.append(f"#mdb1 E ret={ret_id} file={name} blk={i}/{n}")
        btxt = "\n".join(body)
        if len(btxt) > block:
            raise SystemExit(f"内部错误：{name} 块 {i} 有 {len(btxt)} 字，超过 {block}")
        blocks.append(btxt)
        out.append(f"### {name} 块 {i}/{n}（{len(btxt)} 字）\n\n````text\n{btxt}\n````\n")
    head = (f"# {name}\n\n回传号 {ret_id}；格式 {FMT}；共 {n} 个代码块，每块不超过 {block} 字。"
            f"逐块复制代码块里的全部内容（含第一行 `#mdb1 B` 和最后一行 `#mdb1 E`）。\n\n")
    return head + "\n".join(out), blocks


def cmd_pack(a):
    if not RETID_RE.match(a.ret_id):
        raise SystemExit("回传号只能用字母、数字和连字符，4–40 位")
    if a.block < 2000:
        raise SystemExit("--block 不能小于 2000")
    names = sorted(f for f in os.listdir(a.inp) if os.path.isfile(os.path.join(a.inp, f)))
    if not names:
        raise SystemExit("输入目录是空的")
    if INDEX_NAME in names:
        raise SystemExit(f"输入目录里不能有 {INDEX_NAME}（由本工具生成）")
    os.makedirs(a.out, exist_ok=True)
    if os.listdir(a.out):
        raise SystemExit("输出目录必须是空的")
    index = ["file\tbytes\tlines\tblocks\tsha256"]
    packed, total_chars, total_blocks = {}, 0, 0
    for nm in names:
        if not NAME_RE.match(nm):
            raise SystemExit(f"文件名只能用字母、数字、点、下划线、连字符：{nm}")
        data = open(os.path.join(a.inp, nm), "rb").read()
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            raise SystemExit(f"{nm} 不是 UTF-8 文本，不能回传")
        if "\r" in text:
            raise SystemExit(f"{nm} 含回车符（\\r），先转成 \\n 换行")
        md, blocks = pack_text(nm, text, a.ret_id, a.block)
        packed[nm] = (md, blocks, data)
        index.append(f"{nm}\t{len(data)}\t{text.count(chr(10))}\t{len(blocks)}\t{hashlib.sha256(data).hexdigest()}")
    idx_text = "\n".join(index) + "\n"
    md, blocks = pack_text(INDEX_NAME, idx_text, a.ret_id, a.block)
    packed[INDEX_NAME] = (md, blocks, idx_text.encode("utf-8"))
    listing = [f"# 回传 {a.ret_id}（{FMT}）", "",
               "按下表逐个文件、逐个代码块复制。全部复制完后研究者用 `ret_md.py unpack` 还原并核对。", "",
               "| md 文件 | 源文件 | 字节 | 代码块数 | 字数 |", "|---|---|---|---|---|"]
    for nm in [INDEX_NAME] + names:
        md, blocks, data = packed[nm]
        mdname = nm + ".md"
        with open(os.path.join(a.out, mdname), "w", encoding="utf-8", newline="\n") as h:
            h.write(md)
        chars = sum(len(b) for b in blocks)
        total_chars += chars
        total_blocks += len(blocks)
        listing.append(f"| `{mdname}` | `{nm}` | {len(data)} | {len(blocks)} | {chars} |")
    listing += ["", f"合计 {total_blocks} 个代码块、{total_chars} 字。"]
    with open(os.path.join(a.out, "README.md"), "w", encoding="utf-8", newline="\n") as h:
        h.write("\n".join(listing) + "\n")
    if a.max_chars and total_chars > a.max_chars:
        raise SystemExit(f"合计 {total_chars} 字，超过上限 {a.max_chars}；按任务书的简化顺序减少内容后重做")
    # 回读核对：用生成的 md 还原，必须与输入逐字节相同
    texts = [open(os.path.join(a.out, f), encoding="utf-8").read() for f in sorted(os.listdir(a.out)) if f != "README.md"]
    files, report = restore(texts)
    bad = [nm for nm in names if files.get(nm) != packed[nm][2]]
    if bad or report["problems"]:
        raise SystemExit(f"回读核对失败：{bad} {report['problems'][:3]}")
    print(f"OK pack: {len(names)} 个文件，{total_blocks} 个代码块，{total_chars} 字；回读核对通过 -> {a.out}")


# ---------------------------------------------------------------- 读输入

def read_any(path: str) -> str:
    if path.lower().endswith(".docx"):
        with zipfile.ZipFile(path) as z:
            x = z.read("word/document.xml").decode("utf-8")
        paras = re.findall(r"<w:p[ >].*?</w:p>|<w:p/>", x, flags=re.S)
        out = []
        for p in paras:
            parts = re.findall(r"<w:t(?: [^>]*)?>.*?</w:t>|<w:tab/>|<w:br[^>]*/>|<w:cr/>", p, flags=re.S)
            s = ""
            for q in parts:
                if q.startswith("<w:tab"):
                    s += "\t"
                elif q.startswith("<w:br") or q.startswith("<w:cr"):
                    s += "\n"
                else:
                    s += unescape(re.sub(r"<[^>]+>", "", q))
            out.append(s)
        return "\n".join(out)
    return open(path, encoding="utf-8", errors="replace").read()


# ---------------------------------------------------------------- 还原

def _repairs():
    def rstrip_lines(t):
        return "\n".join(x.rstrip() for x in t.split("\n"))

    def quotes(t):
        return t.translate({0x201C: '"', 0x201D: '"', 0x2018: "'", 0x2019: "'", 0x2032: "'", 0x2033: '"'})

    def spaces(t):
        return RISKY_RE.sub(lambda m: "" if ord(m.group()) in (0x200B, 0x200C, 0x200D, 0x2060, 0xFEFF) else
                            (m.group() if m.group() in "\n" else " "), t)

    base = [("行尾空白", rstrip_lines), ("弯引号", quotes), ("特殊空白", spaces)]
    combos = [[]] + [[r] for r in base] + [base[:2], [base[0], base[2]], base[1:], base]
    return combos


def _decode_block(payload_lines, nl):
    dec = [dec_line(x) for x in payload_lines]
    return "\n".join(dec) + ("\n" if nl and dec else "")


def _try_block(lines, nlines, nl, crc):
    """lines：块头块尾之间的行。返回 (原始文本或 None, 用了哪些修复)。"""
    for combo in _repairs():
        cand = "\n".join(lines)
        for _, fn in combo:
            cand = fn(cand)
        ls = cand.split("\n") if cand != "" or nlines else []
        for variant in (ls, [x for x in ls if x != ""]):   # 第二种：复制时多出来的空行
            if len(variant) != nlines:
                continue
            try:
                raw = _decode_block(variant, nl)
            except (ValueError, json.JSONDecodeError):
                continue
            if "%08x" % (zlib.crc32(raw.encode("utf-8")) & 0xFFFFFFFF) == crc:
                return raw, [n for n, _ in combo]
    return None, []


def restore(texts):
    """texts：按顺序给出的输入文本。返回 ({文件名: bytes}, 报告)。"""
    stream = JOIN.join(t.replace("\r\n", "\n").replace("\r", "\n").replace("\x00", "") for t in texts)
    # 接缝落在块头或块尾这一行中间时，直接相接
    def fix_seam(m):
        line = m.group(0)
        joined = line.replace(JOIN, "")
        if HDR_RE.match(joined.strip()) or END_RE.match(joined.strip()):
            return joined
        # 接缝后面紧跟一个新的块头或块尾：两份输入是分开复制的，按换行处理
        parts = line.split(JOIN)
        out = parts[0]
        for nxt in parts[1:]:
            out += ("\n" if nxt.lstrip().startswith("#mdb1 ") or END_RE.match(out.split("\n")[-1].strip()) else JOIN) + nxt
        return out
    stream = re.sub(r"[^\n]*\x00[^\n]*", fix_seam, stream)
    lines = stream.split("\n")
    got = {}       # (file, blk) -> (ntotal, raw, repairs)
    problems, notes, ret_ids, blockprob = [], [], set(), {}
    i = 0
    while i < len(lines):
        probe = lines[i].replace(JOIN, "").strip()
        m = HDR_RE.match(probe)
        if not m:
            i += 1
            continue
        ret, name, blk, ntot, nlines, nl, crc = m.group(1), m.group(2), int(m.group(3)), int(m.group(4)), int(m.group(5)), int(m.group(6)), m.group(7)
        j = i + 1
        end = None
        while j < len(lines):
            p2 = lines[j].replace(JOIN, "").strip()
            if END_RE.match(p2):
                end = j
                break
            if HDR_RE.match(p2):
                break
            j += 1
        if end is None:
            blockprob.setdefault((name, blk), f"{name} 块 {blk}/{ntot}：没有找到块尾（复制不完整），请重抄这一块")
            i = j
            continue
        e = END_RE.match(lines[end].replace(JOIN, "").strip())
        if (e.group(1), e.group(2), int(e.group(3))) != (ret, name, blk):
            blockprob.setdefault((name, blk), f"{name} 块 {blk}/{ntot}：块尾属于 {e.group(2)} 块 {e.group(3)}，中间有内容丢失，请重抄这一块")
            i = end + 1
            continue
        body = lines[i + 1:end]
        # 接缝在内容中间：试“直接相接”和“换行相接”
        seams = [k for k, x in enumerate(body) if JOIN in x]
        cands = [body]
        if seams:
            cands = []
            for mask in range(1 << min(len(seams), 4)):
                b2 = []
                for k, x in enumerate(body):
                    if JOIN in x:
                        bit = (mask >> min(seams.index(k), 3)) & 1
                        if bit:
                            b2.extend(x.split(JOIN))
                        else:
                            b2.append(x.replace(JOIN, ""))
                    else:
                        b2.append(x)
                cands.append(b2)
        raw, rep = None, []
        for b2 in cands:
            raw, rep = _try_block(b2, nlines, nl, crc)
            if raw is not None:
                break
        key = (name, blk)
        if raw is None:
            blockprob.setdefault(key, f"{name} 块 {blk}/{ntot}：校验不过（内容被改动或缺行），请重抄这一块")
        else:
            if key in got and got[key][1] != raw:
                problems.append(f"{name} 块 {blk}/{ntot}：收到两份不同的内容")
            got[key] = (ntot, raw, rep)
            ret_ids.add(ret)
            if rep:
                notes.append(f"{name} 块 {blk}/{ntot}：自动修复了 {'、'.join(rep)}")
        i = end + 1
    problems += [msg for key, msg in blockprob.items() if key not in got]
    if len(ret_ids) > 1:
        problems.append(f"混进了不同回传的块：{sorted(ret_ids)}")
    files = {}
    byfile = {}
    for (name, blk), (ntot, raw, _) in got.items():
        byfile.setdefault(name, {})[blk] = (ntot, raw)
    for name, bl in sorted(byfile.items()):
        ntot = max(v[0] for v in bl.values())
        miss = [k for k in range(1, ntot + 1) if k not in bl]
        if miss:
            problems.append(f"{name}：缺块 {','.join(map(str, miss))}（共 {ntot} 块）")
            continue
        files[name] = "".join(bl[k][1] for k in range(1, ntot + 1)).encode("utf-8")
    # 与索引核对
    if INDEX_NAME in files:
        rows = files[INDEX_NAME].decode("utf-8").strip().split("\n")[1:]
        for r in rows:
            nm, nbytes, _nl, nblk, sha = r.split("\t")
            if nm not in files:
                if not any(p.startswith(nm + "：") or p.startswith(nm + " ") for p in problems):
                    problems.append(f"{nm}：一块都没收到（共 {nblk} 块）")
                continue
            if hashlib.sha256(files[nm]).hexdigest() != sha or len(files[nm]) != int(nbytes):
                problems.append(f"{nm}：各块校验都通过，但整文件的 sha256 与索引不符")
        extra = sorted(set(files) - {r.split("\t")[0] for r in rows} - {INDEX_NAME})
        if extra:
            problems.append(f"索引里没有的文件：{extra}")
    else:
        problems.append(f"没有收到 {INDEX_NAME}，无法核对文件是否齐全")
    return files, {"problems": problems, "notes": notes, "ret_ids": sorted(ret_ids),
                   "blocks": {n: sorted(b) for n, b in byfile.items()}}


def cmd_unpack(a):
    texts = [read_any(p) for p in a.inputs]
    files, rep = restore(texts)
    if not a.list_only:
        os.makedirs(a.out, exist_ok=True)
        if os.listdir(a.out):
            raise SystemExit("输出目录必须是空的")
        for nm, data in files.items():
            with open(os.path.join(a.out, nm), "wb") as h:
                h.write(data)
    print(f"回传号：{', '.join(rep['ret_ids']) or '未知'}")
    for nm, b in sorted(rep["blocks"].items()):
        print(f"  {nm}: 收到 {len(b)} 块" + ("" if nm in files else "（不完整，未还原）"))
    for n in rep["notes"]:
        print("  提示：" + n)
    for p in rep["problems"]:
        print("  问题：" + p)
    if rep["problems"]:
        print(f"还原不完整：{len(rep['problems'])} 个问题。只需重抄上面点名的块，再把新旧输入一起交给 unpack。")
        return 1
    print(f"OK unpack: {len(files) - (1 if INDEX_NAME in files else 0)} 个文件全部还原，sha256 与索引一致" +
          ("" if a.list_only else f" -> {a.out}"))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("pack")
    p.add_argument("--in", dest="inp", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--ret-id", required=True)
    p.add_argument("--block", type=int, default=30000, help="每个代码块的最大字数，默认 30000")
    p.add_argument("--max-chars", type=int, default=2200000, help="总字数上限，默认 220 万；0 = 不限")
    u = sub.add_parser("unpack")
    u.add_argument("inputs", nargs="+")
    u.add_argument("--out", required=True)
    u.set_defaults(list_only=False)
    l = sub.add_parser("list")
    l.add_argument("inputs", nargs="+")
    l.set_defaults(list_only=True, out=None)
    a = ap.parse_args(argv)
    if a.cmd == "pack":
        cmd_pack(a)
        return 0
    return cmd_unpack(a)


if __name__ == "__main__":
    sys.exit(main())
