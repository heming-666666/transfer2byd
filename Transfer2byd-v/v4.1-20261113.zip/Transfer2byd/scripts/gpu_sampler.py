#!/usr/bin/env python3
"""gpu_sampler: 按固定间隔记录 GPU 的功率、累计能耗、显存、利用率、温度。只用标准库。

    gpu_sampler.py --out gpu.csv --gpus 0,1 [--interval 0.5]     # 一直采到收到 SIGTERM
    gpu_sampler.py --check-idle --gpus 0,1                        # 所选卡是否空闲（退出码 0 = 空闲）
    gpu_sampler.py --list-free                                    # 打印当前空闲的卡号（逗号分隔）
    gpu_sampler.py --selfcheck --gpus 0 [--seconds 60]            # 核对能耗计数器与功率积分是否一致

数据来源，按顺序尝试：
1. 用 ctypes 直接调 libnvidia-ml.so.1（NVML）：能读累计能耗计数器 energy_mj（毫焦）；
2. 读不到时退回 nvidia-smi 的查询（没有能耗计数器，energy_mj 留空，由分析脚本对 power_mw 积分）。
列：t（Unix 秒，与 run.json、step_marks.jsonl 同一时钟）, gpu, energy_mj, power_mw, util_pct, mem_used_mb,
    temp_c, power_limit_mw, src（nvml / smi）。
gpu 可以写序号或 UUID（GPU-…），输出里原样写回。测试时可用环境变量 OPD_NVIDIA_SMI 指定替身程序，
OPD_NO_NVML=1 跳过 NVML。
"""
from __future__ import annotations

import argparse
import ctypes
import os
import signal
import subprocess
import sys
import time

SMI = os.environ.get("OPD_NVIDIA_SMI", "nvidia-smi")
FIELDS = "index,uuid,power.draw,utilization.gpu,memory.used,temperature.gpu,power.limit"
IDLE_MEM_MB, IDLE_UTIL = 1500, 5


class Mem(ctypes.Structure):
    _fields_ = [("total", ctypes.c_ulonglong), ("free", ctypes.c_ulonglong), ("used", ctypes.c_ulonglong)]


class Util(ctypes.Structure):
    _fields_ = [("gpu", ctypes.c_uint), ("memory", ctypes.c_uint)]


class Nvml:
    def __init__(self):
        if os.environ.get("OPD_NO_NVML") == "1":
            raise OSError("NVML disabled by OPD_NO_NVML")
        self.lib = ctypes.CDLL("libnvidia-ml.so.1")
        if self.lib.nvmlInit_v2() != 0:
            raise OSError("nvmlInit_v2 failed")
        self.handles = {}

    def handle(self, gpu):
        if gpu not in self.handles:
            h = ctypes.c_void_p()
            if gpu.startswith("GPU-"):
                rc = self.lib.nvmlDeviceGetHandleByUUID(gpu.encode(), ctypes.byref(h))
            else:
                rc = self.lib.nvmlDeviceGetHandleByIndex_v2(ctypes.c_uint(int(gpu)), ctypes.byref(h))
            if rc != 0:
                raise OSError(f"no handle for gpu {gpu} (rc={rc})")
            self.handles[gpu] = h
        return self.handles[gpu]

    def read(self, gpu):
        h = self.handle(gpu)
        e, p, t, lim = ctypes.c_ulonglong(), ctypes.c_uint(), ctypes.c_uint(), ctypes.c_uint()
        m, u = Mem(), Util()
        energy = e.value if self.lib.nvmlDeviceGetTotalEnergyConsumption(h, ctypes.byref(e)) == 0 else ""
        if energy != "":
            energy = e.value
        power = p.value if self.lib.nvmlDeviceGetPowerUsage(h, ctypes.byref(p)) == 0 else ""
        mem = m.used // (1 << 20) if self.lib.nvmlDeviceGetMemoryInfo(h, ctypes.byref(m)) == 0 else ""
        util = u.gpu if self.lib.nvmlDeviceGetUtilizationRates(h, ctypes.byref(u)) == 0 else ""
        temp = t.value if self.lib.nvmlDeviceGetTemperature(h, 0, ctypes.byref(t)) == 0 else ""
        limit = lim.value if self.lib.nvmlDeviceGetEnforcedPowerLimit(h, ctypes.byref(lim)) == 0 else ""
        return [energy, power, util, mem, temp, limit, "nvml"]


def smi_all():
    """返回 {序号: 行, UUID: 行}；行 = [energy(空), power_mw, util, mem_mb, temp, limit_mw, 'smi']。"""
    r = subprocess.run([SMI, f"--query-gpu={FIELDS}", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=20)
    if r.returncode != 0:
        raise OSError(f"nvidia-smi rc={r.returncode}: {r.stderr.strip()[:200]}")
    out = {}

    def num(x, scale=1.0):
        try:
            return int(round(float(x) * scale))
        except ValueError:
            return ""
    for line in r.stdout.strip().splitlines():
        c = [x.strip() for x in line.split(",")]
        if len(c) < 7:
            continue
        row = ["", num(c[2], 1000), num(c[3]), num(c[4]), num(c[5]), num(c[6], 1000), "smi"]
        out[c[0]] = row
        out[c[1]] = row
    return out


def make_reader(gpus):
    try:
        nv = Nvml()
        for g in gpus:
            nv.read(g)
        return (lambda: {g: nv.read(g) for g in gpus}), "nvml"
    except (OSError, AttributeError, ValueError) as e:
        print(f"[gpu_sampler] NVML 不可用（{e}），退回 nvidia-smi", file=sys.stderr, flush=True)

        def rd():
            d = smi_all()
            return {g: d.get(g, ["", "", "", "", "", "", "smi-missing"]) for g in gpus}
        return rd, "smi"


def all_gpus():
    d = subprocess.run([SMI, "--query-gpu=index", "--format=csv,noheader"], capture_output=True, text=True, timeout=20)
    return [x.strip() for x in d.stdout.strip().splitlines() if x.strip()]


def idle_report(gpus):
    d = smi_all()
    busy = []
    for g in gpus:
        row = d.get(g)
        if row is None:
            busy.append(f"{g}:missing")
        elif (row[3] != "" and row[3] > IDLE_MEM_MB) or (row[2] != "" and row[2] > IDLE_UTIL):
            busy.append(f"{g}:mem={row[3]}MB,util={row[2]}%")
    return busy


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out")
    ap.add_argument("--gpus", default="")
    ap.add_argument("--interval", type=float, default=0.5)
    ap.add_argument("--check-idle", action="store_true")
    ap.add_argument("--list-free", action="store_true")
    ap.add_argument("--selfcheck", action="store_true")
    ap.add_argument("--seconds", type=float, default=60)
    a = ap.parse_args(argv)
    gpus = [g.strip() for g in a.gpus.split(",") if g.strip()]
    if a.list_free:
        print(",".join(g for g in all_gpus() if not idle_report([g])))
        return 0
    if a.check_idle:
        busy = idle_report(gpus)
        print("idle" if not busy else "busy " + " ".join(busy))
        return 1 if busy else 0
    if not gpus:
        ap.error("--gpus 不能为空")
    read, src = make_reader(gpus)
    if a.selfcheck:
        t0, first = time.time(), read()
        integ = {g: 0.0 for g in gpus}
        prev_t, prev = t0, first
        while time.time() - t0 < a.seconds:
            time.sleep(a.interval)
            t, cur = time.time(), read()
            for g in gpus:
                if prev[g][1] != "" and cur[g][1] != "":
                    integ[g] += (prev[g][1] + cur[g][1]) / 2 / 1000 * (t - prev_t)
            prev_t, prev = t, cur
        ok = True
        for g in gpus:
            if first[g][0] == "" or prev[g][0] == "":
                print(f"gpu {g}: src={src} 没有能耗计数器；功率积分 {integ[g]:.1f} J（{a.seconds:.0f} s）-> 用功率积分")
                ok = False
                continue
            cnt = (prev[g][0] - first[g][0]) / 1000
            rel = abs(cnt - integ[g]) / max(cnt, 1e-9)
            print(f"gpu {g}: 计数器 {cnt:.1f} J，功率积分 {integ[g]:.1f} J，相对差 {rel:.3f}"
                  f"{'（一致）' if rel <= 0.05 else '（相差超过 5%，回传时注明）'}")
        return 0 if ok else 2
    stop = {"v": False}
    signal.signal(signal.SIGTERM, lambda *_: stop.__setitem__("v", True))
    signal.signal(signal.SIGINT, lambda *_: stop.__setitem__("v", True))
    with open(a.out, "w", encoding="utf-8", newline="\n") as h:
        h.write("t,gpu,energy_mj,power_mw,util_pct,mem_used_mb,temp_c,power_limit_mw,src\n")
        nxt = time.time()
        while True:
            t = time.time()
            try:
                rows = read()
            except (OSError, subprocess.SubprocessError) as e:
                rows = {g: ["", "", "", "", "", "", f"err"] for g in gpus}
                print(f"[gpu_sampler] 读数失败：{e}", file=sys.stderr, flush=True)
            for g in gpus:
                h.write(f"{t:.3f},{g}," + ",".join(str(x) for x in rows[g]) + "\n")
            h.flush()
            if stop["v"]:
                break
            nxt += a.interval
            delay = nxt - time.time()
            if delay < 0:
                nxt = time.time()
            else:
                # 分段睡眠，收到信号后最多再等 0.1 s，然后补采最后一次
                while delay > 0 and not stop["v"]:
                    time.sleep(min(0.1, delay))
                    delay = nxt - time.time()
    return 0


if __name__ == "__main__":
    sys.exit(main())
