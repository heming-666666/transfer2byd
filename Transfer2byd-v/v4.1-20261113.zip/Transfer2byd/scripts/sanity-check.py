#!/usr/bin/env python3
"""Sanity checks on the 10 return files before they are encoded and copied (docs/18 §3).

Usage: python3 scripts/sanity-check.py $OPD_RUNTIME/Transfer2me [--tasks state/tasks.yaml]
Checks that numbers are physically possible and consistent across files; prints every violation with file, line and
reason. Fix the data (or explain the row in its note column and 00-summary) and run again until it prints OK.
It does not replace scripts/check-return.py (format) - run both.
"""
import argparse
import csv
import json
import math
import re
import sys
from pathlib import Path


def num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def rows(p):
    with open(p, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dir")
    ap.add_argument("--tasks")
    a = ap.parse_args()
    d = Path(a.dir)
    bad = []

    def err(where, why):
        bad.append(f"{where}: {why}")

    cfg = rows(d / "03-configs.csv")
    cfgs = {(r["task"], r["cfg"]) for r in cfg}
    for i, r in enumerate(cfg, 2):
        where = f"03-configs.csv:{i} {r['task']}/{r['cfg']}"
        if r["status"] not in ("ok", "failed", "oom", "skipped", "partial"):
            err(where, f"status {r['status']!r} is not ok/failed/oom/skipped/partial")
        if r["status"] != "ok" and not r.get("note"):
            err(where, "a failed/oom/skipped row needs a note with the reason")
        if r["bg"] in ("", "unknown") and r["status"] == "ok" and r.get("step_s"):
            err(where, "bg must say what the other partition was doing (idle or a task id)")
        for k in ("step_s", "gen_s", "train_s", "sync_s"):
            v = num(r.get(k))
            if r.get(k) not in ("", "NA", None) and (v is None or v < 0):
                err(where, f"{k}={r.get(k)!r} is not a non-negative number")
        name = r["cfg"].lower()
        if "fp8" in name and "fp8" not in (r.get("teacher_prec", "") + r.get("args", "")).lower():
            err(where, "cfg name says fp8 but neither teacher_prec nor args do; names must match the real settings")

    steps = rows(d / "04-steps.csv")
    for i, r in enumerate(steps, 2):
        where = f"04-steps.csv:{i} {r['task']}/{r['cfg']}/step{r['step']}"
        if (r["task"], r["cfg"]) not in cfgs:
            err(where, "cfg has no row in 03-configs.csv")
        t = {k: num(r.get(k)) for k in ("gen_start_s", "gen_end_s", "score_start_s", "score_end_s", "train_start_s",
                                        "train_end_s", "sync_start_s", "sync_end_s", "step_end_s")}
        if r.get("mode") == "eval":
            continue
        seq = [t["gen_start_s"], t["gen_end_s"], t["train_start_s"], t["train_end_s"], t["sync_start_s"],
               t["sync_end_s"], t["step_end_s"]]
        known = [x for x in seq if x is not None]
        if known and any(x < -1e-6 for x in known):
            err(where, "negative time; all times are seconds after this step's generation start")
        if any(b is not None and a_ is not None and b < a_ - 1e-3 for a_, b in zip(seq, seq[1:])):
            err(where, "phases out of order (gen_start <= gen_end <= train_start <= train_end <= sync_start <= sync_end <= step_end)")
        if t["score_start_s"] is not None and (t["score_start_s"] < -1e-3 or
                                               (t["step_end_s"] is not None and t["score_start_s"] > t["step_end_s"] + 1e-3)):
            err(where, "score_start_s outside [0, step_end_s]: the timestamp anchor is wrong (see routes/V2-F)")
        if t["score_end_s"] is not None and t["score_start_s"] is not None and t["score_end_s"] < t["score_start_s"]:
            err(where, "score_end_s < score_start_s")
        n, tr = num(r.get("n_rollouts")), num(r.get("n_truncated"))
        if n is not None and tr is not None and tr > n:
            err(where, "n_truncated > n_rollouts")
        g, sc = num(r.get("tokens_generated")), num(r.get("tokens_scored"))
        if g and sc is not None and sc < g * 0.99:
            err(where, "tokens_scored < tokens_generated: the teacher must score every generated token")
        busy, bsum = num(r.get("teacher_busy_s")), num(r.get("teacher_busy_sum_s"))
        if busy is not None and t["step_end_s"] and busy > t["step_end_s"] * 1.01:
            err(where, "teacher_busy_s longer than the step")
        if busy is not None and bsum is not None and bsum + 1e-3 < busy:
            err(where, "teacher_busy_sum_s < teacher_busy_s (the sum of request times cannot be smaller than their union)")

    ro = rows(d / "06-rollouts.csv")
    gen_end = {(r["task"], r["cfg"], r["seed"], r["step"]): num(r["gen_end_s"]) for r in steps}
    for i, r in enumerate(ro, 2):
        where = f"06-rollouts.csv:{i} {r['task']}/{r['cfg']}/step{r['step']}"
        fl, td = num(r.get("final_len")), num(r.get("t_done_s"))
        ge = gen_end.get((r["task"], r["cfg"], r["seed"], r["step"]))
        if td is not None and ge is not None and td > ge + 0.5:
            err(where, f"t_done_s {td} after gen_end_s {ge}")
        if fl is not None and fl < 0:
            err(where, "negative final_len")

    met = rows(d / "05-metrics.csv")
    for i, r in enumerate(met, 2):
        where = f"05-metrics.csv:{i} {r['task']}/{r['cfg']}/{r['key']}"
        v = r.get("value", "")
        if v == "" :
            err(where, "empty value; write NA:<reason> if not measured")
        elif v.startswith("NA") and ":" not in v and not r.get("note"):
            err(where, "NA needs a reason (NA:<reason> or the note column)")
        if r["key"].endswith("_frac") and num(v) is not None and not (0 <= num(v) <= 1):
            err(where, "a fraction outside [0, 1]")
        lo, hi = num(r.get("lo")), num(r.get("hi"))
        if lo is not None and hi is not None and num(v) is not None and not (lo - 1e-9 <= num(v) <= hi + 1e-9):
            err(where, "value outside [lo, hi]")

    for i, line in enumerate(open(d / "08-script-outputs.jsonl", encoding="utf-8"), 1):
        if line.strip():
            try:
                o = json.loads(line)
            except json.JSONDecodeError:
                err(f"08-script-outputs.jsonl:{i}", "not valid JSON")
                continue
            if isinstance(o.get("data"), dict) and o["data"].get("truncated"):
                err(f"08-script-outputs.jsonl:{i}", "data marked truncated; write the whole output")

    summ = (d / "00-summary.md").read_text(encoding="utf-8")
    if not re.match(r"回传编号[:：]\s*return-\d{8}-\d{2}", summ):
        err("00-summary.md:1", "first line must be 回传编号：return-YYYYMMDD-NN")
    if a.tasks:
        for tid in re.findall(r"\bid:\s*([A-Za-z0-9-]+)", Path(a.tasks).read_text(encoding="utf-8")):
            if tid not in summ:
                err("00-summary.md", f"task {tid} has no row in the task table")

    if bad:
        print(f"{len(bad)} problem(s):")
        print("\n".join("  - " + b for b in bad))
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
