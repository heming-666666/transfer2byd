#!/usr/bin/env python3
"""Pick the best usable model/dataset for every slot, verify it, and record what was used.

Only the standard library. Run with `python3 -I`.

The manifest (state/assets-manifest.json in a package) lists, per slot, candidates in
priority order. Each candidate has a Hugging Face repo, a pinned revision, and every file
with its size and sha256 (LFS files) or git blob sha1 (small files). A candidate counts as
usable only if every essential file is present with the right size and hash. The first
usable candidate wins. Its two grades (quality / system comparability) must be carried
into every result row that uses it (column `asset_grade`).

Subcommands
  plan      MANIFEST [--tiers P0,P1]                 list slots, candidates, sizes, download commands
  select    MANIFEST --root DIR [--root DIR ...] [--map REPO=PATH ...] [--tiers P0,P1]
            [--full-hash] [--out state/assets-selected.json] [--md out.md]
  tokcheck  DIR_A DIR_B                              compare tokenizer.json vocab and added tokens
            (exit 0 identical, 1 same ids but different added tokens, 2 incompatible)
  selftest

Exit codes for `select`: 0 every required slot at grade A/B on both axes; 1 some slot fell
back to grade C; 2 some required slot has no usable candidate.
"""
import argparse, hashlib, json, os, sys, tempfile

NON_ESSENTIAL_SUFFIX = (".md", ".png", ".jpg", ".jpeg", ".gif", ".svg", ".pdf")
NON_ESSENTIAL_NAMES = {".gitattributes", "LICENSE", "LICENSE.txt", "NOTICE", "USE_POLICY.md"}
SMALL = 64 * 1024 * 1024  # files up to this size are always hashed


def essential(path):
    base = os.path.basename(path)
    return not (base in NON_ESSENTIAL_NAMES or base.lower().endswith(NON_ESSENTIAL_SUFFIX))


def sha256_file(p, bufsize=8 * 1024 * 1024):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(bufsize), b""):
            h.update(b)
    return h.hexdigest()


def git_blob_sha1(p):
    with open(p, "rb") as f:
        data = f.read()
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def candidate_dirs(cand, roots, mapping):
    """Possible local directories for a candidate, most specific first."""
    repo, rev, kind = cand["repo"], cand["revision"], cand["kind"]
    org, name = repo.split("/", 1)
    out = []
    if repo in mapping:
        out.append(mapping[repo])
    for r in roots:
        cache = os.path.join(r, f"{kind}s--{org}--{name}", "snapshots")
        if os.path.isdir(cache):
            snaps = sorted(os.listdir(cache))
            out += [os.path.join(cache, s) for s in snaps if s == rev]
            out += [os.path.join(cache, s) for s in snaps if s != rev]
        for sub in (os.path.join(org, name), name, f"{org}--{name}", f"{org}__{name}", f"{org}_{name}"):
            out.append(os.path.join(r, sub))
    seen, res = set(), []
    for d in out:
        d = os.path.abspath(d)
        if d not in seen and os.path.isdir(d):
            seen.add(d)
            res.append(d)
    return res


def verify_dir(cand, d, full_hash):
    """Return (ok, problems, n_hashed). Essential files must match; others only warn."""
    problems, warn, hashed = [], [], 0
    for f in cand["files"]:
        p = os.path.join(d, f["path"])
        ess = essential(f["path"])
        bucket = problems if ess else warn
        if not os.path.isfile(p):
            bucket.append(f"missing {f['path']}")
            continue
        size = os.path.getsize(p)
        if f.get("size") is not None and size != f["size"]:
            bucket.append(f"size {f['path']} {size}!={f['size']}")
            continue
        if not ess:
            continue
        bad = quick_check(p)                      # cheap, always: catches zero-filled mirror files
        if bad:
            problems.append(f"{bad} {f['path']}")
            continue
        must_hash = full_hash or cand["kind"] == "dataset" or size <= SMALL
        if must_hash:
            hashed += 1
            if f.get("sha256"):
                if sha256_file(p) != f["sha256"]:
                    problems.append(f"sha256 {f['path']}")
            elif f.get("git_blob_sha1"):
                if git_blob_sha1(p) != f["git_blob_sha1"]:
                    problems.append(f"blob-sha1 {f['path']}")
    return (not problems), problems + [f"(warn) {w}" for w in warn], hashed


def quick_check(p):
    """Cheap poison check without hashing (mirrors may serve zero-filled files of the right size).
    safetensors: the 8-byte header length must be sane and the JSON header must parse;
    any file > 1 MB: the first and last 64 KB must not be all zero."""
    size = os.path.getsize(p)
    with open(p, "rb") as f:
        head = f.read(65536)
        if size > 1 << 20:
            f.seek(max(0, size - 65536))
            tail = f.read(65536)
            if not head.strip(b"\0") or not tail.strip(b"\0"):
                return "zero-filled head or tail"
        if p.endswith(".safetensors"):
            if len(head) < 8:
                return "safetensors too short"
            n = int.from_bytes(head[:8], "little")
            if n <= 0 or n > min(size - 8, 100 << 20):
                return f"safetensors bad header length {n}"
            f.seek(8)
            try:
                json.loads(f.read(n).decode("utf-8"))
            except Exception:
                return "safetensors header is not JSON"
    return None


def worst(g1, g2):
    order = "ABCX"
    return max(g1, g2, key=order.index)


def cmd_plan(a):
    m = json.load(open(a.manifest, encoding="utf-8"))
    tiers = set(a.tiers.split(","))
    tot = 0
    for s in m["slots"]:
        if s["tier"] not in tiers:
            continue
        print(f"[{s['tier']}] {s['slot']} — {s['role']}")
        for i, c in enumerate(s["candidates"]):
            gb = c["bytes"] / 1e9
            flag = "--repo-type dataset " if c["kind"] == "dataset" else ""
            print(f"   {i}. {c['repo']}@{c['revision'][:12]} Q={c['grade_quality']} S={c['grade_system']} {gb:.2f} GB  {c['note']}")
            print(f"      huggingface-cli download {flag}{c['repo']} --revision {c['revision']} --local-dir <ROOT>/{c['repo']}")
            if i == 0:
                tot += gb
    print(f"first-choice total for tiers {sorted(tiers)}: {tot:.1f} GB")


def select(m, roots, mapping, tiers, full_hash):
    res = {"schema": "assets-selected/1", "manifest_created": m.get("created"), "roots": roots,
           "full_hash": full_hash, "slots": []}
    for s in m["slots"]:
        if s["tier"] not in tiers:
            continue
        rec = {"slot": s["slot"], "tier": s["tier"], "role": s["role"], "tried": [], "chosen": None}
        for i, c in enumerate(s["candidates"]):
            dirs = candidate_dirs(c, roots, mapping)
            if not dirs:
                rec["tried"].append({"rank": i, "repo": c["repo"], "result": "not found"})
                continue
            done = False
            for d in dirs:
                ok, probs, nh = verify_dir(c, d, full_hash)
                rec["tried"].append({"rank": i, "repo": c["repo"], "path": d, "result": "ok" if ok else "bad",
                                     "hashed_files": nh, "problems": probs[:12]})
                if ok:
                    rec["chosen"] = {"rank": i, "repo": c["repo"], "revision": c["revision"], "path": d,
                                     "grade_quality": c["grade_quality"], "grade_system": c["grade_system"],
                                     "asset_grade": f"Q{c['grade_quality']}S{c['grade_system']}",
                                     "use": c.get("use"), "expect_rows": c.get("expect_rows"), "note": c["note"]}
                    done = True
                    break
            if done:
                break
        res["slots"].append(rec)
    return res


def exit_code(res):
    code = 0
    for r in res["slots"]:
        if r["chosen"] is None:
            return 2
        if worst(r["chosen"]["grade_quality"], r["chosen"]["grade_system"]) == "C":
            code = 1
    return code


def to_md(res):
    lines = ["| 槽位 | 层级 | 用了什么 | 名次 | 等级（质量/系统） | 没用上的候选与原因 |", "|---|---|---|---|---|---|"]
    for r in res["slots"]:
        c = r["chosen"]
        miss = "; ".join(f"{t['repo']}: {t['result']}" + (f" ({t['problems'][0]})" if t.get("problems") else "")
                         for t in r["tried"] if not c or t["rank"] < c["rank"])
        if c:
            lines.append(f"| {r['slot']} | {r['tier']} | {c['repo']}@{c['revision'][:12]} | {c['rank']} | {c['grade_quality']}/{c['grade_system']} | {miss or '—'} |")
        else:
            lines.append(f"| {r['slot']} | {r['tier']} | **无可用** | — | X/X | {miss} |")
    return "\n".join(lines) + "\n"


def cmd_select(a):
    m = json.load(open(a.manifest, encoding="utf-8"))
    mapping = dict(x.split("=", 1) for x in a.map)
    res = select(m, a.root, mapping, set(a.tiers.split(",")), a.full_hash)
    code = exit_code(res)
    res["exit_code"] = code
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        json.dump(res, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    md = to_md(res)
    if a.md:
        open(a.md, "w", encoding="utf-8").write(md)
    print(md)
    print({0: "all slots A/B", 1: "some slots fell back to grade C", 2: "some required slot has no usable candidate"}[code])
    return code


def load_tok(d):
    t = json.load(open(os.path.join(d, "tokenizer.json"), encoding="utf-8"))
    vocab = t.get("model", {}).get("vocab", {})
    added = {a["id"]: a["content"] for a in t.get("added_tokens", [])}
    return vocab, added


def tokcheck(da, db):
    """identical: same vocab and same added tokens. compatible: no id means two different things.
    A compatible-but-not-identical pair (e.g. Qwen3-*-Base vs post-trained: the Base tokenizer does
    not register <think>, </think>, <tool_response>, </tool_response> as added tokens) still splits the
    same text differently, so student and teacher must both use the superset tokenizer."""
    va, aa = load_tok(da)
    vb, ab = load_tok(db)
    diff_v = [k for k in set(va) | set(vb) if va.get(k) != vb.get(k)]
    conflict = sorted(i for i in set(aa) & set(ab) if aa[i] != ab[i])
    only_a = {i: aa[i] for i in sorted(set(aa) - set(ab))}
    only_b = {i: ab[i] for i in sorted(set(ab) - set(aa))}
    compatible = not diff_v and not conflict
    identical = compatible and not only_a and not only_b
    advice = ("same tokenizer" if identical else
              "ids agree but added tokens differ: tokenize BOTH sides with the tokenizer that has the extra tokens" if compatible else
              "different vocabularies: cannot pair at token level")
    return {"vocab_a": len(va), "vocab_b": len(vb), "vocab_mismatch": len(diff_v),
            "added_a": len(aa), "added_b": len(ab), "conflicting_ids": conflict[:50],
            "only_in_a": only_a, "only_in_b": only_b, "identical": identical,
            "id_compatible": compatible, "advice": advice}


def cmd_tokcheck(a):
    rep = tokcheck(a.dir_a, a.dir_b)
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0 if rep["identical"] else (1 if rep["id_compatible"] else 2)


def selftest():
    with tempfile.TemporaryDirectory() as td:
        root = os.path.join(td, "models")
        def mk(rel, data):
            p = os.path.join(root, rel)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "wb").write(data)
            return p
        _h = json.dumps({"w": {"dtype": "U8", "shape": [1000], "data_offsets": [0, 1000]}}).encode()
        w = len(_h).to_bytes(8, "little") + _h + b"W" * 1000   # a valid safetensors file
        cfg = b'{"a":1}'
        mk("Org/good/model.safetensors", w); mk("Org/good/config.json", cfg)
        mk("Org/bad/model.safetensors", w[:-1] + b"X"); mk("Org/bad/config.json", cfg)
        snap = "models--Org--cache/snapshots/abc123"
        mk(snap + "/model.safetensors", w); mk(snap + "/config.json", cfg)
        files = [{"path": "model.safetensors", "size": len(w), "sha256": hashlib.sha256(w).hexdigest()},
                 {"path": "config.json", "size": len(cfg), "git_blob_sha1": hashlib.sha1(b"blob %d\0" % len(cfg) + cfg).hexdigest()},
                 {"path": "README.md", "size": 5, "git_blob_sha1": "0" * 40}]
        def cand(repo, gq, gs):
            return {"repo": repo, "kind": "model", "revision": "abc123", "grade_quality": gq, "grade_system": gs,
                    "note": "", "bytes": len(w), "files": files}
        m = {"created": "test", "slots": [
            {"slot": "s1", "tier": "P0", "role": "", "candidates": [cand("Org/bad", "A", "A"), cand("Org/good", "C", "B")]},
            {"slot": "s2", "tier": "P0", "role": "", "candidates": [cand("Org/cache", "A", "A")]},
            {"slot": "s3", "tier": "P0", "role": "", "candidates": [cand("Org/absent", "A", "A")]},
            {"slot": "s4", "tier": "P2", "role": "", "candidates": [cand("Org/absent", "A", "A")]}]}
        r = select(m, [root], {}, {"P0"}, False)
        s = {x["slot"]: x for x in r["slots"]}
        assert s["s1"]["chosen"]["repo"] == "Org/good" and s["s1"]["tried"][0]["problems"] == ["sha256 model.safetensors", "(warn) missing README.md"], s["s1"]
        assert s["s2"]["chosen"]["path"].endswith("abc123"), s["s2"]
        assert s["s3"]["chosen"] is None and "s4" not in s
        assert exit_code(r) == 2
        r2 = select(m, [root], {}, {"P0"}, True)
        assert r2["slots"][0]["chosen"]["repo"] == "Org/good"
        m["slots"] = m["slots"][:2]
        assert exit_code(select(m, [root], {}, {"P0"}, False)) == 1
        # zero-filled large file of the right size is caught without hashing
        big = b"\0" * (2 << 20)
        mk("Org/zero/model.safetensors", big); mk("Org/zero/config.json", cfg)
        zc = cand("Org/zero", "A", "A"); zc = {**zc, "files": [{"path": "model.safetensors", "size": len(big), "sha256": "0" * 64}, files[1]]}
        ok, probs, _ = verify_dir(zc, os.path.join(root, "Org/zero"), False)
        assert not ok and "zero-filled" in probs[0], probs
        hdr = json.dumps({"w": {"dtype": "F32", "shape": [1], "data_offsets": [0, 4]}}).encode()
        good = len(hdr).to_bytes(8, "little") + hdr + b"\1" * (2 << 20)
        mk("Org/st/model.safetensors", good); mk("Org/st/config.json", cfg)
        sc = {**zc, "repo": "Org/st", "files": [{"path": "model.safetensors", "size": len(good), "sha256": hashlib.sha256(good).hexdigest()}, files[1]]}
        ok, probs, _ = verify_dir(sc, os.path.join(root, "Org/st"), False)
        assert ok, probs
        # size mismatch is caught before hashing
        mk("Org/short/model.safetensors", w[:-10]); mk("Org/short/config.json", cfg)
        ok, probs, _ = verify_dir(cand("Org/short", "A", "A"), os.path.join(root, "Org/short"), False)
        assert not ok and probs[0].startswith("size"), probs
        # tokenizer check
        ta = {"model": {"vocab": {"a": 0, "b": 1}}, "added_tokens": [{"id": 2, "content": "<x>"}]}
        tb = {"model": {"vocab": {"a": 0, "b": 1}}, "added_tokens": [{"id": 2, "content": "<x>"}, {"id": 3, "content": "<y>"}]}
        tc = {"model": {"vocab": {"a": 1, "b": 0}}, "added_tokens": []}
        for n, t in (("ta", ta), ("tb", tb), ("tc", tc)):
            os.makedirs(os.path.join(td, n)); json.dump(t, open(os.path.join(td, n, "tokenizer.json"), "w"))
        rab = tokcheck(os.path.join(td, "ta"), os.path.join(td, "tb"))
        assert rab["id_compatible"] is True and rab["identical"] is False and rab["only_in_b"] == {3: "<y>"}, rab
        assert tokcheck(os.path.join(td, "ta"), os.path.join(td, "ta"))["identical"] is True
        assert tokcheck(os.path.join(td, "ta"), os.path.join(td, "tc"))["id_compatible"] is False
        print(to_md(r))
    print("selftest ok")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("plan"); p.add_argument("manifest"); p.add_argument("--tiers", default="P0,P1,P2")
    p = sp.add_parser("select"); p.add_argument("manifest"); p.add_argument("--root", action="append", default=[])
    p.add_argument("--map", action="append", default=[]); p.add_argument("--tiers", default="P0,P1")
    p.add_argument("--full-hash", action="store_true"); p.add_argument("--out"); p.add_argument("--md")
    p = sp.add_parser("tokcheck"); p.add_argument("dir_a"); p.add_argument("dir_b")
    sp.add_parser("selftest")
    a = ap.parse_args()
    return {"plan": lambda: cmd_plan(a) or 0, "select": lambda: cmd_select(a), "tokcheck": lambda: cmd_tokcheck(a),
            "selftest": selftest}[a.cmd]()


if __name__ == "__main__":
    sys.exit(main())
