#!/usr/bin/env python3
"""Print selected lines of the copy-safe return so the researcher can copy them again (docs/06 §5).

Usage: python3 scripts/show-lines.py $OPD_RUNTIME/Transfer2me-text F05L000417-F05L000420 F02L001020 ...
Each argument is one record prefix or a range of two prefixes from the researcher's re-copy list. The header line of
the file is printed too, so the restore tool can check the result. Output goes to the terminal; copy it as plain text.
"""
import re
import sys
from pathlib import Path

REC = re.compile(r"F(\d{2})L(\d{6})")


def main():
    if len(sys.argv) < 3:
        print(__doc__); return 2
    d = Path(sys.argv[1])
    files = {int(p.name[:2]): p for p in d.glob("*.txt")}
    for arg in sys.argv[2:]:
        ends = REC.findall(arg)
        if not ends:
            print(f"# skipped {arg!r}: not a record prefix", file=sys.stderr); continue
        fi = int(ends[0][0]); a = int(ends[0][1]); b = int(ends[-1][1])
        p = files.get(fi)
        if p is None:
            print(f"# no file F{fi:02d} in {d}", file=sys.stderr); continue
        lines = p.read_text(encoding="utf-8").split("\n")
        print(lines[0])                                   # @FNN BEGIN ... header
        for line in lines:
            m = REC.match(line)
            if m and int(m.group(1)) == fi and a <= int(m.group(2)) <= b:
                print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main())
