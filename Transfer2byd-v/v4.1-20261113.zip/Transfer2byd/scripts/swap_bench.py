#!/usr/bin/env python3
"""swap_bench: “整模型按阶段换入换出”这一朴素对照的微基准（V4-F 的 S 臂）。需要 torch 和 GPU，只在云端运行。

    $PY scripts/swap_bench.py --scorer <云端在用的 lm_scorer.py 路径> --packed /dev/shm/proctor/qwen3-32b \
        --gpu 0 --seqs <一步的序列 seqs.jsonl> --limit 240 --repeats 3 --out $OPD_RUN_DIR/swap_bench.json

每次重复按顺序计时三件事（每件事前后都 torch.cuda.synchronize）：
  S 臂（整模型换入换出）：构造常驻打分器（把全部层从主机内存拷上这张卡）→ 打完这批序列 → 释放显存；
  M 臂（模式 B，按层流式）：构造流式打分器（只放两层的缓冲）→ 打完同一批序列 → 释放。
输出每次重复的 init_s、score_s、free_s、峰值显存 peak_gb、token 数，以及两臂分数的最大差
（应为 0；不为 0 时退出码 5）。S 臂的 init_s 包含主机内存映射与登记，是“换入”时间的上界。
放不下（OOM）时该臂记 status=oom 和报错原文前 300 字，不算脚本失败：这正是可行性图要的结果。
本脚本没有在研究者本机运行过（本机没有 GPU），只通过了语法检查；云端先用 --limit 8 --repeats 1 冒烟。
"""
from __future__ import annotations

import argparse
import gc
import importlib.util
import json
import os
import sys
import time


def load_scorer(path):
    spec = importlib.util.spec_from_file_location("lm_scorer_cloud", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["lm_scorer_cloud"] = mod
    spec.loader.exec_module(mod)
    return mod


def arm(mod, torch, packed, gpu, mode, attn, seqs, micro):
    dev = torch.device("cuda", gpu)
    rec = {"mode": mode, "status": "ok"}
    sc = None
    try:
        torch.cuda.synchronize(dev)
        torch.cuda.reset_peak_memory_stats(dev)
        t0 = time.monotonic()
        sc = mod.Scorer(packed, gpu, mode=mode, attn=attn)
        torch.cuda.synchronize(dev)
        t1 = time.monotonic()
        out = sc.score(seqs, micro_tokens=micro)
        torch.cuda.synchronize(dev)
        t2 = time.monotonic()
        rec.update({"init_s": round(t1 - t0, 4), "score_s": round(t2 - t1, 4),
                    "peak_gb": round(torch.cuda.max_memory_allocated(dev) / 2 ** 30, 3),
                    "tokens": sum(len(x) for x in out)})
    except Exception as e:  # noqa: BLE001  OOM 等都要记下来
        rec.update({"status": "oom" if "out of memory" in str(e).lower() else "error", "error": str(e)[:300]})
        out = None
    t3 = time.monotonic()
    del sc
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.synchronize(dev)
    rec["free_s"] = round(time.monotonic() - t3, 4)
    return rec, out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--scorer", required=True, help="云端在用的 lm_scorer.py（v3 里通过自测的那一份）")
    ap.add_argument("--packed", required=True)
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--seqs", required=True)
    ap.add_argument("--limit", type=int, default=240)
    ap.add_argument("--micro-tokens", type=int, default=32768)
    ap.add_argument("--attn", default="sdpa")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    import torch
    mod = load_scorer(a.scorer)
    seqs = mod.read_seqs(a.seqs, a.limit)
    reps, maxdiff = [], 0.0
    for r in range(a.repeats):
        print(f"[swap_bench] step {r + 1}/{a.repeats}", flush=True)
        s_rec, s_out = arm(mod, torch, a.packed, a.gpu, "resident", a.attn, seqs, a.micro_tokens)
        m_rec, m_out = arm(mod, torch, a.packed, a.gpu, "stream", a.attn, seqs, a.micro_tokens)
        if s_out is not None and m_out is not None:
            for x, y in zip(s_out, m_out):
                for p, q in zip(x, y):
                    maxdiff = max(maxdiff, abs(float(p) - float(q)))
        reps.append({"rep": r, "S": s_rec, "M": m_rec})
        tmp = a.out + ".tmp"
        with open(tmp, "w", encoding="utf-8") as h:
            json.dump({"packed": a.packed, "gpu": a.gpu, "n_seqs": len(seqs), "micro_tokens": a.micro_tokens,
                       "attn": a.attn, "scorer_path": a.scorer, "max_abs_diff_S_vs_M": maxdiff, "repeats": reps},
                      h, ensure_ascii=False, indent=1)
        os.replace(tmp, a.out)
    print(f"[swap_bench] max_abs_diff_S_vs_M={maxdiff}")
    return 5 if maxdiff > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
