#!/usr/bin/env python3
"""preflight: 每个任务开跑前的预检。只用标准库。不通过就停下报告，不现场升级、不改代码。

    python3 -I scripts/preflight.py --task V4-G2 [--py $OPD_PY] [--need-gpus 8] [--need-path <文件或目录> ...]
        [--need-module torch --need-module sglang] [--need-free-gb 50] [--frozen <云端脚本路径> ...]

检查：OPD_RUNTIME 存在可写；结果盘余量；所需卡数与当前空闲卡；路径存在；指定解释器里模块能导入并打印版本；
--frozen 的云端脚本存在，并与 state/frozen-adapters.json 里登记的 sha256 一致（第一次登记时写入）；
包的 SHA256SUMS（有的话）抽查本脚本目录没有被改动。
输出一行 JSON（ok、逐项结果），退出码 0 = 通过，1 = 不通过。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def sha(path):
    d = hashlib.sha256()
    with open(path, "rb") as h:
        for b in iter(lambda: h.read(1 << 20), b""):
            d.update(b)
    return d.hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=True)
    ap.add_argument("--py", default=os.environ.get("OPD_PY", sys.executable))
    ap.add_argument("--need-gpus", type=int, default=0)
    ap.add_argument("--need-path", action="append", default=[])
    ap.add_argument("--need-module", action="append", default=[])
    ap.add_argument("--need-free-gb", type=float, default=50.0)
    ap.add_argument("--frozen", action="append", default=[])
    ap.add_argument("--register", action="store_true", help="把 --frozen 的文件登记进 state/frozen-adapters.json（只在 V4-0 用）")
    a = ap.parse_args(argv)
    items, ok = [], True

    def add(name, good, detail=""):
        nonlocal ok
        ok = ok and good
        items.append({"check": name, "ok": bool(good), "detail": str(detail)[:300]})

    rt = os.environ.get("OPD_RUNTIME", "")
    add("OPD_RUNTIME", bool(rt) and os.path.isdir(rt) and os.access(rt, os.W_OK), rt or "未设置")
    if rt and os.path.isdir(rt):
        free = shutil.disk_usage(rt).free / 2 ** 30
        add("disk_free_gb", free >= a.need_free_gb, f"{free:.1f} GB（阈值 {a.need_free_gb}）")
    if a.need_gpus:
        r = subprocess.run([sys.executable, "-I", os.path.join(HERE, "gpu_sampler.py"), "--list-free"],
                           capture_output=True, text=True)
        free_g = [x for x in r.stdout.strip().split(",") if x]
        if os.environ.get("OPD_GPU_LEASE") == "external":
            vis = [x for x in os.environ.get("CUDA_VISIBLE_DEVICES", "").split(",") if x]
            add("gpus_assigned", len(vis) >= a.need_gpus, f"主窗分到 {len(vis)} 张，任务要 {a.need_gpus} 张")
        else:
            add("gpus_free", len(free_g) >= a.need_gpus, f"空闲 {','.join(free_g) or '无'}，任务要 {a.need_gpus} 张")
    for p in a.need_path:
        add(f"path:{p}", os.path.exists(os.path.expandvars(p)))
    for m in a.need_module:
        r = subprocess.run([a.py, "-c", f"import {m} as x; print(getattr(x, '__version__', 'unknown'))"],
                           capture_output=True, text=True)
        add(f"module:{m}", r.returncode == 0, (r.stdout or r.stderr).strip().splitlines()[-1] if (r.stdout or r.stderr).strip() else "")
    if a.frozen and rt:
        reg_path = os.path.join(rt, "state", "frozen-adapters.json")
        try:
            reg = json.load(open(reg_path, encoding="utf-8"))
        except (OSError, ValueError):
            reg = {}
        changed = False
        for p in a.frozen:
            p = os.path.expandvars(p)
            if not os.path.isfile(p):
                add(f"frozen:{p}", False, "文件不存在")
                continue
            h = sha(p)
            if p not in reg:
                if a.register:
                    reg[p] = h
                    changed = True
                    add(f"frozen:{p}", True, f"已登记 {h[:12]}")
                else:
                    add(f"frozen:{p}", False, "还没有登记（先做 V4-0 的登记步骤）")
            else:
                add(f"frozen:{p}", reg[p] == h, f"登记 {reg[p][:12]}，现在 {h[:12]}" + ("" if reg[p] == h else "：脚本被改过，停下并在回传里交 diff"))
        if changed:
            os.makedirs(os.path.dirname(reg_path), exist_ok=True)
            tmp = reg_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as hh:
                json.dump(reg, hh, ensure_ascii=False, indent=1)
            os.replace(tmp, reg_path)
    print(json.dumps({"task": a.task, "ok": ok, "items": items}, ensure_ascii=False))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
