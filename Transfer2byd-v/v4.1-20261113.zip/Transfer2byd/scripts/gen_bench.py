#!/usr/bin/env python3
"""gen_bench: 测一个已经起好的学生推理服务在不同并发下的生成吞吐上限（V4-G1）。只用标准库。

    gen_bench.py --url http://127.0.0.1:30100 --model <服务里的模型名> --prompts prompts.jsonl \
        --concurrency 16 32 64 128 --n 240 --max-tokens 8192 --out $OPD_RUN_DIR/gen_bench.json

- 服务要提供 OpenAI 兼容的 /v1/completions（vLLM、SGLang 都有）。
- prompts.jsonl 每行 {"prompt": "..."}（已经套好对话模板的文本），不够 --n 条时循环使用。
- 每个并发档：同时最多 C 个请求在跑，一共发 N 条，记录每条的完成时刻、生成 token 数、是否截断；
  吞吐 = 全部生成 token ÷ 这一档的墙钟时间（总量除以总时间，不取各请求的平均）。
- 输出 JSON：每档一条 {concurrency, n, wall_s, tokens, tok_s, trunc, errors, len_q{…}, done_q{…},
  occupancy（各请求在跑时间之和 ÷ (C × wall)，看并发槽位有没有被用满）}。
- 采样参数与训练时一致才有可比性：--temperature、--top-p 按路线卡给的值传。
"""
from __future__ import annotations

import argparse
import json
import sys
import threading
import time
import urllib.error
import urllib.request


def quant(xs, ps=(0, 10, 25, 50, 75, 90, 99, 100)):
    if not xs:
        return {}
    s = sorted(xs)
    out = {}
    for p in ps:
        k = max(0, min(len(s) - 1, -(-p * len(s) // 100) - 1))
        out[f"p{p}"] = s[k]
    return out


def one(url, model, prompt, a, rec):
    body = json.dumps({"model": model, "prompt": prompt, "max_tokens": a.max_tokens, "temperature": a.temperature,
                       "top_p": a.top_p, "stream": False}).encode()
    req = urllib.request.Request(url.rstrip("/") + "/v1/completions", data=body,
                                 headers={"Content-Type": "application/json"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=a.timeout) as r:
            d = json.loads(r.read())
        ch = d["choices"][0]
        rec.update({"ok": True, "tokens": int(d.get("usage", {}).get("completion_tokens", 0)),
                    "trunc": ch.get("finish_reason") == "length"})
    except (urllib.error.URLError, OSError, ValueError, KeyError, IndexError) as e:
        rec.update({"ok": False, "tokens": 0, "trunc": False, "err": str(e)[:200]})
    rec["t0"], rec["t1"] = t0, time.time()


def run_level(a, prompts, c, mode="refill"):
    """refill：始终有 c 个请求在跑，完成一条立即补一条；wave：每批 c 条，整批写完才发下一批（同步 OPD 一步的样子）。"""
    recs = [{} for _ in range(a.n)]
    idx = {"i": 0}
    lock = threading.Lock()

    def worker(limit):
        while True:
            with lock:
                i = idx["i"]
                if i >= limit:
                    return
                idx["i"] += 1
            one(a.url, a.model, prompts[i % len(prompts)], a, recs[i])

    t0 = time.time()
    waves = [a.n] if mode == "refill" else list(range(c, a.n, c)) + [a.n]
    for limit in waves:
        ths = [threading.Thread(target=worker, args=(limit,), daemon=True) for _ in range(c)]
        for t in ths:
            t.start()
        for t in ths:
            t.join()
    wall = time.time() - t0
    ok = [r for r in recs if r.get("ok")]
    toks = sum(r["tokens"] for r in ok)
    busy = sum(r["t1"] - r["t0"] for r in recs if "t1" in r)
    return {"concurrency": c, "mode": mode, "n": a.n, "wall_s": round(wall, 3), "tokens": toks,
            "tok_s": round(toks / wall, 1) if wall > 0 else None, "trunc": sum(1 for r in ok if r["trunc"]),
            "errors": len(recs) - len(ok), "first_error": next((r.get("err") for r in recs if not r.get("ok")), None),
            "len_q": quant([r["tokens"] for r in ok]),
            "done_q": {k: round(v, 2) for k, v in quant([r["t1"] - t0 for r in ok]).items()},
            "occupancy": round(busy / (c * wall), 3) if wall > 0 else None}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--prompts", required=True)
    ap.add_argument("--concurrency", type=int, nargs="+", required=True)
    ap.add_argument("--n", type=int, default=240)
    ap.add_argument("--max-tokens", type=int, default=8192)
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top-p", type=float, default=1.0)
    ap.add_argument("--timeout", type=float, default=3600)
    ap.add_argument("--warmup", type=int, default=4, help="正式计时前先发几条预热（不计入）")
    ap.add_argument("--mode", default="refill", choices=["refill", "wave", "both"],
                    help="refill = 持续补位；wave = 整批写完才发下一批；both = 每档并发两种各测一次（先 wave）")
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    prompts = []
    with open(a.prompts, encoding="utf-8") as h:
        for line in h:
            if line.strip():
                prompts.append(json.loads(line)["prompt"])
    if not prompts:
        sys.exit("prompts 文件是空的")
    if a.warmup:
        saved = a.n
        a.n = a.warmup
        w = run_level(a, prompts, min(a.warmup, 4))
        a.n = saved
        if w["errors"] == a.warmup:
            sys.exit(f"预热请求全部失败，服务不可用：{w['first_error']}")
    levels = []
    plan = [(c, m) for c in a.concurrency for m in (["wave", "refill"] if a.mode == "both" else [a.mode])]
    for c, m in plan:
        print(f"[gen_bench] step {len(levels) + 1}/{len(plan)} concurrency={c} mode={m}", flush=True)
        lv = run_level(a, prompts, c, m)
        levels.append(lv)
        print(f"[gen_bench]   mode={m} tok/s={lv['tok_s']} wall={lv['wall_s']} trunc={lv['trunc']}/{a.n} errors={lv['errors']}", flush=True)
        tmp = a.out + ".tmp"
        with open(tmp, "w", encoding="utf-8") as h:
            json.dump({"url": a.url, "model": a.model, "max_tokens": a.max_tokens, "temperature": a.temperature,
                       "top_p": a.top_p, "n_prompts_file": len(prompts), "levels": levels}, h, ensure_ascii=False, indent=1)
        import os
        os.replace(tmp, a.out)
    return 0 if all(l["errors"] == 0 for l in levels) else 4


if __name__ == "__main__":
    sys.exit(main())
