#!/usr/bin/env python3
"""dash（v4.1）：实时看板。只用 Python 标准库，不装任何包、不需要构建、不连外网。

    dash.py collect [--td <任务目录>] [--interval 5]    后台采集，写 $OPD_RUNTIME/dashboard/state.json
    dash.py serve   [--port 30390]                     只监听 127.0.0.1：页面 + state.json
    dash.py tui     [--td <任务目录>] [--interval 5]    终端版（tmux 窗里直接看）
    dash.py once    [--td <任务目录>]                   采集一次并打印终端版

数据来源（都只读）：
  * orchd 的状态 <任务目录>/notes/sched/state.json：每张卡租给谁、核查判定、空卡原因、任务状态与原因、告警、卡时账
    （--td 或环境变量 ORCH_TD；没有 orchd 时退回 nvidia-smi 与 results 里的 progress.json）
  * <任务目录>/notes/events/orchd.jsonl 最近的事件；notes/skill-feedback.jsonl 的条数
  * $OPD_RUNTIME/results/<大版本>/<任务>/<run>/progress.json、run.json（启动器写）
  * 研究进展 state/research-status.json（包里那份；$OPD_RUNTIME/state/research-status.json 存在时以它为准）
  * 包里的 state/manifest.json（任务标题、种类）
页面每 5–20 秒刷新一次（页面右上角可选，默认 10 秒）；采集默认每 5 秒一次。
论文完成度：research-status.json 的 paper_progress.items 加权求和；auto 项按任务完成比例自动算（见 docs/15）。
"""
from __future__ import annotations

import argparse
import glob
import http.server
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
SMI = os.environ.get("OPD_NVIDIA_SMI", "nvidia-smi")


def _ver():
    """结果目录名 = 包版本的大版本（v4.1 -> v4）；环境变量 OPD_PKG_VER 可覆盖。"""
    if os.environ.get("OPD_PKG_VER"):
        return os.environ["OPD_PKG_VER"]
    try:
        v = open(os.path.join(PKG, "VERSION"), encoding="utf-8").read().split()[0]
    except (OSError, IndexError):
        return "v4"
    return v.split(".")[0]


def rt():
    r = os.environ.get("OPD_RUNTIME", "")
    if not r:
        sys.exit("没有设置 OPD_RUNTIME")
    return r


def load(path, default=None):
    try:
        with open(path, encoding="utf-8") as h:
            return json.load(h)
    except (OSError, ValueError):
        return default


def atomic(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp.{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as h:
        h.write(text)
    os.replace(tmp, path)


def smi():
    try:
        r = subprocess.run([SMI, "--query-gpu=index,utilization.gpu,memory.used,memory.total,power.draw,temperature.gpu",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=15)
        out = []
        for line in r.stdout.strip().splitlines():
            c = [x.strip() for x in line.split(",")]
            if len(c) >= 6:
                out.append({"idx": c[0], "util": c[1], "used": c[2], "total": c[3], "power_w": c[4], "temp": c[5]})
        return out
    except (OSError, subprocess.SubprocessError):
        return []


def tail_jsonl(path, n):
    try:
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()[-n:]
    except OSError:
        return []
    out = []
    for line in lines:
        try:
            out.append(json.loads(line))
        except ValueError:
            pass
    return out


def runs_of(now, stale):
    root = os.path.join(rt(), "results", _ver())
    runs = []
    for p in sorted(glob.glob(os.path.join(root, "*", "*", "progress.json"))):
        d = os.path.dirname(p)
        task, rid = os.path.basename(os.path.dirname(d)), os.path.basename(d)
        g = load(p) or {}
        age = now - float(g.get("t", 0) or 0)
        live = g.get("phase") in ("starting", "pre_idle", "running")
        step, total = g.get("step"), g.get("steps_total")
        eta = None
        if live and step and total and g.get("last_step_s"):
            eta = round((total - step) * g["last_step_s"])
        runs.append({"task": task, "run_id": rid, "cfg": g.get("cfg"), "phase": g.get("phase"), "step": step,
                     "steps_total": total, "last_step_s": g.get("last_step_s"), "age_s": round(age, 1),
                     "elapsed_s": round(now - float(g.get("t_start", now))) if live else None, "eta_s": eta,
                     "gpus": g.get("gpus", []), "live": live, "stuck": bool(live and age > stale), "note": g.get("note", ""),
                     "t_end": g.get("t") if not live else None})
    return runs


def paper_progress(research, task_status):
    """加权完成度。item: {name, weight, done: 0..1} 或 {name, weight, auto: [任务号或 "A|B"], base: 0..1}。"""
    pp = (research or {}).get("paper_progress") or {}
    items, tot, got = [], 0.0, 0.0
    for it in pp.get("items", []):
        w = float(it.get("weight", 0))
        if "auto" in it:
            ids = it["auto"]
            done = 0
            for x in ids:
                alts = x.split("|")
                if any(task_status.get(a) == "done" for a in alts):
                    done += 1
            frac_tasks = done / len(ids) if ids else 0.0
            base = float(it.get("base", 0))
            frac = base + (1 - base) * frac_tasks
            detail = "%d/%d 个任务完成" % (done, len(ids))
        else:
            frac = float(it.get("done", 0))
            detail = it.get("note", "")
        frac = max(0.0, min(1.0, frac))
        tot += w
        got += w * frac
        items.append({"name": it.get("name", ""), "weight": w, "frac": round(frac, 3), "detail": detail,
                      "stage": it.get("stage", "")})
    return {"percent": round(100 * got / tot, 1) if tot else None, "items": items, "note": pp.get("note", "")}


def collect_once(td="", stale=90.0):
    now = time.time()
    man = load(os.path.join(PKG, "state", "manifest.json"), {}) or {}
    titles = {it["id"]: it for it in man.get("items", [])}
    research = load(os.path.join(rt(), "state", "research-status.json")) or load(
        os.path.join(PKG, "state", "research-status.json"), {}) or {}
    orch = {}
    td = td or os.environ.get("ORCH_TD", "")
    if td:
        st = load(os.path.join(td, "notes", "sched", "state.json"), {}) or {}
        snap = st.get("snapshot") or {}
        tasks = []
        for tid, t in (st.get("tasks") or {}).items():
            it = titles.get(tid, {})
            tasks.append({"id": tid, "title": it.get("title", ""), "kind": it.get("kind", ""), "status": t.get("status"),
                          "verdict": t.get("verdict", ""), "gpus": t.get("gpus", []), "why": t.get("why", "") or t.get("reason", ""),
                          "window": t.get("window", ""), "started": t.get("started", ""), "ended": t.get("ended", ""),
                          "startup_s": t.get("startup_s"), "start_stage": t.get("start_stage", ""),
                          "start_t": t.get("start_t"), "end_t": t.get("end_t"), "attempt": t.get("attempt", 0),
                          "gpu_options": it.get("gpu_options"), "res": it.get("res"), "optional": bool(it.get("optional"))})
        acc = st.get("acct") or {}
        orch = {"heartbeat": st.get("heartbeat"), "heartbeat_age_s": round(now - st["heartbeat"], 1) if st.get("heartbeat") else None,
                "gpus": snap.get("gpus", []), "reservation": snap.get("reservation"), "foreign": snap.get("foreign_mem", []),
                "tasks": tasks, "alerts": sorted([a for a in (st.get("alerts") or {}).values()], key=lambda a: -a.get("no", 0)),
                "acct_h": {k: round(v / 3600, 3) for k, v in acc.items()}, "gates": st.get("gates", {}),
                "events": tail_jsonl(os.path.join(td, "notes", "events", "orchd.jsonl"), 40),
                "skill_feedback": len(tail_jsonl(os.path.join(td, "notes", "skill-feedback.jsonl"), 100000)),
                "util_hist": tail_jsonl(os.path.join(td, "notes", "sched", "gpu.jsonl"), 240)}
    runs = runs_of(now, stale)
    gpus = orch.get("gpus") or []
    raw = smi()
    by = {g["idx"]: g for g in raw}
    if gpus:
        for g in gpus:
            r = by.get(g["idx"], {})
            g["power_w"], g["temp"] = r.get("power_w", ""), r.get("temp", "")
    else:
        gpus = [{"idx": g["idx"], "used": g["used"], "total": g["total"], "util": g["util"], "power_w": g["power_w"],
                 "temp": g["temp"], "lease": "", "lock": "", "procs": [], "idle_why": "（orchd 没在跑：只显示 nvidia-smi）"}
                for g in raw]
    status = {t["id"]: t["status"] for t in orch.get("tasks", [])}
    if not status:                                  # 没有 orchd：按 results 里有没有成功的运行粗判
        for r in runs:
            if r["phase"] == "done":
                status[r["task"]] = "done"
    return {"t": now, "t_text": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now)), "version": _ver(),
            "package": (open(os.path.join(PKG, "VERSION"), encoding="utf-8").read().strip() if os.path.exists(os.path.join(PKG, "VERSION")) else "?"),
            "research": research, "paper": paper_progress(research, status), "orch": orch, "gpus": gpus, "runs": runs,
            "stale_s": stale}


def render(s):
    o = s.get("orch") or {}
    pp = s.get("paper") or {}
    out = ["OPD 实验看板 %s  %s  论文完成度 %s%%" % (s.get("package"), s["t_text"], pp.get("percent")), ""]
    if o:
        out.append("orchd 心跳 %s 秒前；告警 %d 条；skill 问题 %d 条" % (o.get("heartbeat_age_s"), len(o.get("alerts", [])),
                                                              o.get("skill_feedback", 0)))
    out.append("GPU  利用率  显存MiB   归属/空因")
    for g in s["gpus"]:
        who = g.get("lease") or g.get("lock") or g.get("idle_why", "")
        out.append("%3s  %5s%%  %7s   %s" % (g["idx"], g["util"], g["used"], who))
    for t in o.get("tasks", []):
        if t["status"] in ("running", "reserved", "failed", "ready"):
            out.append("  %-9s %-8s %-10s %s" % (t["id"], t["status"], t.get("verdict", ""), (t.get("why") or "")[:80]))
    live = [r for r in s["runs"] if r["live"]]
    for r in live:
        out.append("运行 %s/%s 步 %s/%s %s" % (r["task"], r["cfg"], r["step"], r["steps_total"], "（可能卡住）" if r["stuck"] else ""))
    return "\n".join(out)


def cmd_collect(a):
    path = os.path.join(rt(), "dashboard", "state.json")
    while True:
        atomic(path, json.dumps(collect_once(a.td, a.stale), ensure_ascii=False))
        if a.once:
            return 0
        time.sleep(a.interval)


def cmd_serve(a):
    state_path = os.path.join(rt(), "dashboard", "state.json")
    page = os.path.join(PKG, "dashboard", "index.html")

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            path = self.path.split("?")[0]
            if path in ("/", "/index.html"):
                body, ctype = open(page, "rb").read(), "text/html; charset=utf-8"
            elif path == "/state.json":
                try:
                    body = open(state_path, "rb").read()
                except OSError:
                    body = b'{"gpus":[],"runs":[],"t_text":"collector not running"}'
                ctype = "application/json; charset=utf-8"
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", a.port), H)
    print(f"看板：http://127.0.0.1:{a.port}/ （只监听本机；远程查看用 ssh -L 转发）", flush=True)
    srv.serve_forever()


def cmd_tui(a):
    while True:
        sys.stdout.write("\x1b[2J\x1b[H" + render(collect_once(a.td, a.stale)) + "\n")
        sys.stdout.flush()
        time.sleep(a.interval)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("collect", "serve", "tui", "once"):
        p = sub.add_parser(name)
        p.add_argument("--td", default=os.environ.get("ORCH_TD", ""), help="orchd 的任务目录（默认 $ORCH_TD）")
        p.add_argument("--interval", type=float, default=5.0)
        p.add_argument("--stale", type=float, default=90.0)
        p.add_argument("--port", type=int, default=30390)
        p.add_argument("--once", action="store_true")
    a = ap.parse_args(argv)
    if a.cmd == "collect":
        return cmd_collect(a)
    if a.cmd == "serve":
        return cmd_serve(a)
    if a.cmd == "tui":
        return cmd_tui(a)
    print(render(collect_once(a.td, a.stale)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
