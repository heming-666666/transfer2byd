#!/usr/bin/env python3
"""Evaluation protocols that follow published papers, metric computation, calibration, decontamination.

Only the standard library (the optional `grade` subcommand imports math_verify on the cloud).
Run with `python3 -I`. The same script runs on the cloud (raw data) and locally (returned data);
paper numbers come only from the local run.

Subcommands
  profiles                         print the protocol table (sources included) as JSON
  grade    GEN.jsonl OUT.jsonl     cloud only: grade generations with math_verify (pinned version)
           input rows: {benchmark, problem_id, sample_idx, gold, response, response_tokens, finish_reason}
           output rows: input minus `response`, plus {correct, pred, grader}
  reduce   GRADED.jsonl OUT.jsonl  per-problem rows {benchmark, problem_id, n, c, tokens_mean, n_truncated}; lossless
           for Avg@n, Pass@k, the sampling SE and the paired bootstrap (all of them only use n and c per problem)
  score    GRADED.jsonl --profile P [--ks 1,8,32]    per-benchmark Avg@n, Pass@k (unbiased), sampling SE
  calib    GRADED.jsonl --anchor NAME                compare with the published numbers of a checkpoint
  compare  BASE.jsonl NEW.jsonl [--iters 10000] [--seed 0]   paired bootstrap over problems (per benchmark):
           difference NEW-BASE in points, 95% CI, two-sided p; rows may carry `seed`, all seeds pooled per problem
  decontam TRAIN.jsonl --train-field F EVAL.jsonl --eval-field G [--n 8]   n-gram overlap report
  selftest
"""
import argparse, collections, json, math, random, re, sys, unicodedata

MATH_SUFFIX = "Please reason step by step, and put your final answer within \\boxed{}."
# prefix produced by the official Qwen3 chat template with enable_thinking=False; EOPD uses it for Base students too
QWEN3_NOTHINK_TEMPLATE = "<|im_start|>user\n{query}<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"

# Each profile copies a published protocol. "source" says where; keep it when quoting numbers.
PROFILES = {
    "eopd": {  # main quality protocol: the closest published OPD setup
        "source": "EOPD (ICML 2026, arXiv 2603.07079) Sec.5 and App.: Qwen3-Base students <- Qwen3-8B non-thinking",
        "benchmarks": ["math500", "amc23", "minerva", "olympiadbench", "aime24", "aime25"],
        "temperature": 1.0, "top_p": 0.8, "top_k": -1, "max_new_tokens": 8192, "n": 8,
        "report": ["avg@8", "pass@8"], "prompt_suffix": MATH_SUFFIX, "chat_template": QWEN3_NOTHINK_TEMPLATE,
    },
    "rlad32": {  # long-context protocol, also matches DAPO/AReaL 32-sample reporting on AIME
        "source": "RLAD (ICML 2026, arXiv 2602.22495) Sec.5: Mean@32 and Pass@32, temperature 0.6, top-p 0.95; "
                  "DAPO (NeurIPS 2025) and AReaL (NeurIPS 2025) also report 32-sample averages on AIME",
        "benchmarks": ["aime24", "aime25", "amc23", "math500"],
        "temperature": 0.6, "top_p": 0.95, "top_k": -1, "max_new_tokens": 8192, "n": 32,
        "report": ["mean@32", "pass@32"], "prompt_suffix": MATH_SUFFIX,
        "note": "max_new_tokens follows the training length (RLAD: 8K or 30K)",
    },
    "qwen3-nothink": {  # calibration against the Qwen3 technical report, Table 18
        "source": "Qwen3 Technical Report (arXiv 2505.09388), evaluation setup of the post-trained models: non-thinking temperature 0.7, top-p 0.8, top-k 20, "
                  "presence penalty 1.5, max 32,768 tokens (AIME 38,912), AIME 64 samples averaged; the report does not give the MATH-500 sample count, 4 is our choice",
        "benchmarks": ["math500", "aime24", "aime25"],
        "temperature": 0.7, "top_p": 0.8, "top_k": 20, "presence_penalty": 1.5,
        "max_new_tokens": 32768, "max_new_tokens_aime": 38912, "n": {"aime24": 64, "aime25": 64, "math500": 4},
        "report": ["avg@n"], "prompt_suffix": MATH_SUFFIX, "chat_template": QWEN3_NOTHINK_TEMPLATE,
    },
    "qwen3-think": {
        "source": "Qwen3 Technical Report, same section: thinking temperature 0.6, top-p 0.95, top-k 20, max 32,768 (AIME 38,912), "
                  "AIME 64 samples, GPQA-Diamond 10 samples; MATH-500 sample count not given, 4 is our choice",
        "benchmarks": ["math500", "aime24", "aime25", "gpqa_diamond"],
        "temperature": 0.6, "top_p": 0.95, "top_k": 20, "max_new_tokens": 32768, "max_new_tokens_aime": 38912,
        "n": {"aime24": 64, "aime25": 64, "math500": 4, "gpqa_diamond": 10}, "report": ["avg@n"], "prompt_suffix": MATH_SUFFIX,
    },
    "r1": {  # calibration against DeepSeek-R1 distilled checkpoints
        "source": "DeepSeek-R1 (Nature 2025, arXiv 2501.12948) Supp. D.1: temperature 0.6, top-p 0.95, max 32,768, "
                  "pass@1 averaged over k samples, k=64 for AIME and GPQA, k=16 for MATH",
        "benchmarks": ["aime24", "math500", "gpqa_diamond"],
        "temperature": 0.6, "top_p": 0.95, "top_k": -1, "max_new_tokens": 32768,
        "n": {"aime24": 64, "gpqa_diamond": 64, "math500": 16}, "report": ["avg@n"], "prompt_suffix": MATH_SUFFIX,
    },
}

# Published numbers used to check that the evaluation pipeline reproduces official results.
# tol: allowed |ours - published| in points; about 3x the sampling standard error at the given n.
ANCHORS = {
    "qwen3-8b-nothink": {"profile": "qwen3-nothink", "source": "Qwen3 Technical Report Table 18 (Qwen3-8B, non-thinking)",
                         "values": {"math500": 87.4, "aime24": 29.1, "aime25": 20.9},
                         "tol": {"math500": 2.0, "aime24": 4.0, "aime25": 4.0}},
    "qwen3-4b-nothink": {"profile": "qwen3-nothink", "source": "Qwen3 Technical Report Table 18 (Qwen3-4B, non-thinking)",
                         "values": {"math500": 84.8, "aime24": 25.0, "aime25": 19.1},
                         "tol": {"math500": 2.0, "aime24": 4.0, "aime25": 4.0}},
    "qwen3-8b-think": {"profile": "qwen3-think", "source": "Qwen3 Technical Report Table 17 (Qwen3-8B, thinking)",
                       "values": {"math500": 97.4, "aime24": 76.0, "aime25": 67.3, "gpqa_diamond": 62.0},
                       "tol": {"math500": 1.5, "aime24": 4.0, "aime25": 4.0, "gpqa_diamond": 3.0}},
    "r1-distill-qwen-1.5b": {"profile": "r1", "source": "DeepSeek-R1 distilled-model table (DeepSeek-R1-Distill-Qwen-1.5B)",
                             "values": {"aime24": 28.9, "math500": 83.9, "gpqa_diamond": 33.8},
                             "tol": {"aime24": 4.0, "math500": 2.0, "gpqa_diamond": 3.0}},
}


def pass_at_k(n, c, k):
    """Unbiased estimator 1 - C(n-c,k)/C(n,k) (Chen et al., 2021, HumanEval/Codex paper)."""
    if k > n:
        raise ValueError(f"k={k} > n={n}")
    if n - c < k:
        return 1.0
    return 1.0 - math.comb(n - c, k) / math.comb(n, k)


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def expand(rows):
    """Accept per-sample rows ({correct}) or per-problem rows ({n, c}); yield per-sample rows."""
    for r in rows:
        if "correct" in r:
            yield r
        else:
            for i in range(int(r["n"])):
                yield {**r, "sample_idx": i, "correct": int(i < int(r["c"]))}


def reduce_rows(rows):
    acc = collections.OrderedDict()
    for r in expand(rows):
        k = (r["benchmark"], str(r["problem_id"]))
        a = acc.setdefault(k, {"benchmark": k[0], "problem_id": k[1], "n": 0, "c": 0, "_tok": [], "n_truncated": 0})
        for f in ("profile", "grader", "asset_grade", "model", "step", "seed"):
            if f in r and f not in a:
                a[f] = r[f]
        a["n"] += 1
        a["c"] += int(bool(r["correct"]))
        if r.get("response_tokens") is not None:
            a["_tok"].append(r["response_tokens"])
        if r.get("finish_reason") == "length":
            a["n_truncated"] += 1
    out = []
    for a in acc.values():
        t = a.pop("_tok")
        a["tokens_mean"] = round(sum(t) / len(t), 1) if t else None
        out.append(a)
    return out


def cmd_reduce(a):
    out = reduce_rows(read_jsonl(a.graded))
    with open(a.out, "w", encoding="utf-8") as f:
        for r in out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"{len(out)} problems")
    return 0


def score_rows(rows, ks):
    by = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in expand(rows):
        by[r["benchmark"]][str(r["problem_id"])].append(int(bool(r["correct"])))
    out = {}
    for b, probs in sorted(by.items()):
        ns = [len(v) for v in probs.values()]
        n_min = min(ns)
        per = [sum(v) / len(v) for v in probs.values()]
        avg = 100.0 * sum(per) / len(per)
        # sampling SE of the mean of per-problem means (problem set fixed, only sampling noise)
        var = sum(p * (1 - p) / len(v) for p, v in zip(per, probs.values())) / len(per) ** 2
        rec = {"problems": len(probs), "samples_min": n_min, "samples_max": max(ns),
               f"avg@{n_min}": round(avg, 2), "se_sampling": round(100 * math.sqrt(var), 2)}
        for k in ks:
            if k <= n_min:
                rec[f"pass@{k}"] = round(100.0 * sum(pass_at_k(len(v), sum(v), k) for v in probs.values()) / len(probs), 2)
        out[b] = rec
    return out


def cmd_score(a):
    rows = read_jsonl(a.graded)
    ks = [int(x) for x in a.ks.split(",")]
    res = {"profile": a.profile, "source": PROFILES.get(a.profile, {}).get("source"), "benchmarks": score_rows(rows, ks)}
    print(json.dumps(res, ensure_ascii=False, indent=1))
    return 0


def calib(rows, anchor):
    an = ANCHORS[anchor]
    sc = score_rows(rows, [1])
    rep = {"anchor": anchor, "source": an["source"], "profile": an["profile"], "items": {}, "pass": True}
    for b, pub in an["values"].items():
        if b not in sc:
            rep["items"][b] = {"published": pub, "ours": None, "ok": False}
            rep["pass"] = False
            continue
        ours = next(v for k, v in sc[b].items() if k.startswith("avg@"))
        ok = abs(ours - pub) <= an["tol"][b]
        rep["items"][b] = {"published": pub, "ours": ours, "diff": round(ours - pub, 2), "tol": an["tol"][b],
                           "se_sampling": sc[b]["se_sampling"], "samples": sc[b]["samples_min"], "ok": ok}
        rep["pass"] &= ok
    return rep


def cmd_calib(a):
    rep = calib(read_jsonl(a.graded), a.anchor)
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0 if rep["pass"] else 1


def per_problem(rows):
    by = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in expand(rows):
        by[r["benchmark"]][str(r["problem_id"])].append(int(bool(r["correct"])))
    return {b: {p: sum(v) / len(v) for p, v in d.items()} for b, d in by.items()}


def compare(base, new, iters=10000, seed=0):
    """Paired bootstrap over problems: resample problems with replacement, keep the pairing."""
    pa, pb = per_problem(base), per_problem(new)
    rng = random.Random(seed)
    out = {}
    for b in sorted(set(pa) & set(pb)):
        ids = sorted(set(pa[b]) & set(pb[b]))
        d = [pb[b][i] - pa[b][i] for i in ids]
        obs = 100.0 * sum(d) / len(d)
        boots = []
        for _ in range(iters):
            boots.append(100.0 * sum(d[rng.randrange(len(d))] for _ in d) / len(d))
        boots.sort()
        lo, hi = boots[int(0.025 * iters)], boots[int(0.975 * iters) - 1]
        p = min(1.0, 2 * min(sum(x <= 0 for x in boots), sum(x >= 0 for x in boots)) / iters)
        out[b] = {"paired_problems": len(ids), "only_in_base": len(set(pa[b]) - set(ids)), "only_in_new": len(set(pb[b]) - set(ids)),
                  "diff": round(obs, 2), "ci95": [round(lo, 2), round(hi, 2)], "p_two_sided": round(p, 4), "iters": iters, "seed": seed}
    return out


def cmd_compare(a):
    print(json.dumps(compare(read_jsonl(a.base), read_jsonl(a.new), a.iters, a.seed), ensure_ascii=False, indent=1))
    return 0


def norm_words(s):
    s = unicodedata.normalize("NFKC", s).lower()
    return re.findall(r"[a-z0-9]+|[^\sa-z0-9]", s)


def ngrams(ws, n):
    return {" ".join(ws[i:i + n]) for i in range(len(ws) - n + 1)}


def field(r, f):
    v = r
    for part in f.split("."):
        v = v[int(part)] if isinstance(v, list) else v[part]
    return v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)


def decontam(train, tf, evals, ef, n):
    bank = {}
    for i, r in enumerate(train):
        for g in ngrams(norm_words(field(r, tf)), n):
            bank.setdefault(g, i)
    hits = []
    for j, r in enumerate(evals):
        gs = ngrams(norm_words(field(r, ef)), n)
        shared = [g for g in gs if g in bank]
        if shared:
            hits.append({"eval_idx": j, "train_idx": bank[shared[0]], "shared": len(shared), "of": len(gs),
                         "example": shared[0]})
    return {"n": n, "train_rows": len(train), "eval_rows": len(evals), "eval_hit": len(hits),
            "eval_hit_full": sum(1 for h in hits if h["shared"] == h["of"]), "hits": hits[:50]}


def cmd_decontam(a):
    rep = decontam(read_jsonl(a.train), a.train_field, read_jsonl(a.eval), a.eval_field, a.n)
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0 if rep["eval_hit"] == 0 else 1


def cmd_grade(a):
    try:
        from math_verify import parse, verify  # cloud: pip install math-verify==0.9.0
        import importlib.metadata as md
        ver = md.version("math-verify")
    except Exception as e:  # pragma: no cover - cloud only
        print(f"math_verify not available: {e}", file=sys.stderr)
        return 2
    out = open(a.out, "w", encoding="utf-8")
    for r in read_jsonl(a.gen):
        gold = parse("$" + str(r["gold"]) + "$")
        pred = parse(r["response"])
        ok = bool(verify(gold, pred))
        rr = {k: v for k, v in r.items() if k != "response"}
        rr.update({"correct": int(ok), "pred": str(pred[0]) if pred else None, "grader": f"math-verify=={ver}"})
        out.write(json.dumps(rr, ensure_ascii=False) + "\n")
    out.close()
    return 0


def selftest():
    assert pass_at_k(8, 0, 1) == 0.0 and pass_at_k(8, 8, 8) == 1.0
    assert abs(pass_at_k(8, 2, 1) - 0.25) < 1e-12
    assert abs(pass_at_k(4, 1, 2) - 0.5) < 1e-12  # 1 - C(3,2)/C(4,2) = 1 - 3/6
    rows = []
    for pid in range(10):
        for s in range(8):
            rows.append({"benchmark": "aime24", "problem_id": pid, "sample_idx": s, "correct": int(pid < 3 or (pid == 3 and s < 4))})
    red = reduce_rows(rows)
    assert len(red) == 10 and red[3]["n"] == 8 and red[3]["c"] == 4
    assert score_rows(red, [1, 8]) == score_rows(rows, [1, 8])   # per-problem rows are lossless
    sc = score_rows(rows, [1, 8])["aime24"]
    assert sc["avg@8"] == 35.0 and sc["pass@1"] == 35.0 and sc["pass@8"] == 40.0, sc
    assert sc["se_sampling"] == round(100 * math.sqrt(0.25 / 8) / 10, 2)
    rows_c = [{"benchmark": b, "problem_id": i, "correct": int(i < v)} for b, v in (("aime24", 29), ("aime25", 21), ("math500", 87)) for i in range(100)]
    rep = calib(rows_c, "qwen3-8b-nothink")
    assert rep["pass"] and rep["items"]["math500"]["diff"] == -0.4, rep
    rows_c = [r for r in rows_c if r["benchmark"] != "aime25"]
    assert not calib(rows_c, "qwen3-8b-nothink")["pass"]
    tr = [{"prompt": [{"content": "Find the number of ordered pairs (x, y) of integers such that x^2 + y^2 = 25."}]}]
    ev = [{"problem": "Find the number of ordered pairs (x,y) of integers such that x^2+y^2=25."}, {"problem": "Compute 2+2."}]
    d = decontam(tr, "prompt.0.content", ev, "problem", 8)
    assert d["eval_hit"] == 1 and d["hits"][0]["eval_idx"] == 0, d
    ba = [{"benchmark": "x", "problem_id": i, "correct": int(i < 50)} for i in range(100)]
    nb = [{"benchmark": "x", "problem_id": i, "correct": int(i < 60)} for i in range(100)]
    c = compare(ba, nb, 2000, 1)["x"]
    assert c["diff"] == 10.0 and c["ci95"][0] > 0 and c["p_two_sided"] < 0.01, c
    c0 = compare(ba, ba, 500, 1)["x"]
    assert c0["diff"] == 0.0 and c0["p_two_sided"] == 1.0, c0
    assert set(PROFILES) >= {"eopd", "rlad32", "qwen3-nothink", "qwen3-think", "r1"}
    for an in ANCHORS.values():
        assert an["profile"] in PROFILES and set(an["tol"]) == set(an["values"])
    print("selftest ok")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("profiles")
    p = sp.add_parser("grade"); p.add_argument("gen"); p.add_argument("out")
    p = sp.add_parser("reduce"); p.add_argument("graded"); p.add_argument("out")
    p = sp.add_parser("score"); p.add_argument("graded"); p.add_argument("--profile", required=True); p.add_argument("--ks", default="1,8")
    p = sp.add_parser("calib"); p.add_argument("graded"); p.add_argument("--anchor", required=True, choices=sorted(ANCHORS))
    p = sp.add_parser("compare"); p.add_argument("base"); p.add_argument("new")
    p.add_argument("--iters", type=int, default=10000); p.add_argument("--seed", type=int, default=0)
    p = sp.add_parser("decontam"); p.add_argument("train"); p.add_argument("--train-field", required=True)
    p.add_argument("eval"); p.add_argument("--eval-field", required=True); p.add_argument("--n", type=int, default=8)
    sp.add_parser("selftest")
    a = ap.parse_args()
    if a.cmd == "profiles":
        print(json.dumps({"profiles": PROFILES, "anchors": ANCHORS}, ensure_ascii=False, indent=1))
        return 0
    return {"grade": cmd_grade, "reduce": cmd_reduce, "score": cmd_score, "calib": cmd_calib, "compare": cmd_compare, "decontam": cmd_decontam,
            "selftest": lambda a: selftest()}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
