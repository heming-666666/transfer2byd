#!/usr/bin/env bash
# V4-P2 的一格（由 p2.sh 经 cellrun.py 调用）：p2_cell.sh <cfg> <满载并发>
# 这一格的卡（CUDA_VISIBLE_DEVICES）与端口小段（ORCH_PORT_BASE → env.sh 的 OPD_PORT）由 cellrun 给，同时跑的格互不冲突。
set -euo pipefail
. "$PKG/scripts/v41/env.sh"
if cell_done V4-P2 "$1"; then echo "$1 已完成，跳过"; exit 0; fi
python3 -I "$PKG/scripts/opd_run.py" --task V4-P2 --cfg "$1" --role probe --gpus 1 --timing-sensitive --steps-total 4 \
  --param "concurrency=$2" -- bash "$PKG/scripts/probes/p2_interf.sh" "$2" 0.40 qwen3-32b
