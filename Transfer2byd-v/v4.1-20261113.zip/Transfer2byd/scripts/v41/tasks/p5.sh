#!/usr/bin/env bash
# V4-P5（v4.1，补跑）：p5-c240；命令与 routes/V4-P 的 P5 节相同。v4 的两次运行不完整（partial），新建一次完整运行。
set -euo pipefail
. "$PKG/scripts/v41/env.sh"
if cell_done V4-P5 p5-c240; then echo "p5-c240 已有完整运行，跳过"; exit 0; fi
python3 -I "$PKG/scripts/opd_run.py" --task V4-P5 --cfg p5-c240 --role probe --gpus 1 --timing-sensitive --steps-total 8 \
  -- bash "$PKG/scripts/probes/p5_refill.sh" 240 960 0.60
