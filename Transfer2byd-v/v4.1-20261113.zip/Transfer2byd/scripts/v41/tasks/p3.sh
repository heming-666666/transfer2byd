#!/usr/bin/env bash
# V4-P3（v4.1）：orchd 租到 8 张卡（machine:x）后，依次 N = 1、2、4、8 跑 p3_bw.sh；命令与 routes/V4-P 的 P3 节相同。已做完的格跳过。
set -euo pipefail
. "$PKG/scripts/v41/env.sh"
for N in 1 2 4 8; do
  if cell_done V4-P3 "p3-n$N"; then echo "p3-n$N 已完成，跳过"; continue; fi
  python3 -I "$PKG/scripts/opd_run.py" --task V4-P3 --cfg "p3-n$N" --role bench --gpus "$N" --timing-sensitive \
    --steps-total 1 -- bash "$PKG/scripts/probes/p3_bw.sh" qwen3-32b
done
