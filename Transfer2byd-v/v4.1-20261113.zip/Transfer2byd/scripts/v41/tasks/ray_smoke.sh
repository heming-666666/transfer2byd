#!/usr/bin/env bash
# V41-S1：同一租约里起两个 ray 集群（端口段内的集群 0 与集群 1），各自提交一个 job、各自停掉，证明端口隔离生效。
# 不占 GPU（--num-gpus 0）；结果写 orchd 给的运行目录 $ORCH_RUN_DIR 里的 ray_smoke.json（manifest 的 done_check 查它）。
set -uo pipefail
. "$PKG/scripts/v41/env.sh"
OUT="${ORCH_RUN_DIR:-$(pwd)}"
mkdir -p "$OUT"
res=()
for k in 0 1; do
  ray_head_start 0 "$k" > "$OUT/ray-start-$k.log" 2>&1 || { echo "集群 $k 起不来：$(tail -5 "$OUT/ray-start-$k.log")"; res+=("$k:start-fail"); continue; }
done
for k in 0 1; do
  if ray_job_ready 180 "$k"; then
    "$RAY_BIN" job submit --address "$(ray_dash_url "$k")" -- python3 -c "print('ray-smoke-ok-$k')" > "$OUT/job-$k.log" 2>&1 \
      && grep -q "ray-smoke-ok-$k" "$OUT/job-$k.log" && res+=("$k:ok") || res+=("$k:submit-fail")
  else
    res+=("$k:agent-not-ready")
  fi
done
own_cleanup > "$OUT/cleanup.log" 2>&1 || true
python3 - "$OUT/ray_smoke.json" "${res[@]}" <<'PY'
import json, sys
out, rs = sys.argv[1], sys.argv[2:]
ok = len(rs) == 2 and all(r.endswith(":ok") for r in rs)
json.dump({"ok": ok, "clusters": rs}, open(out, "w"))
print(json.dumps({"ok": ok, "clusters": rs}))
sys.exit(0 if ok else 1)
PY
