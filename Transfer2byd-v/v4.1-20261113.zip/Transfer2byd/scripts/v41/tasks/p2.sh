#!/usr/bin/env bash
# V4-P2（v4.1）：两格，每格 1 张卡：
#   p2-c240：满载并发 240；
#   p2-cbest：V4-G1 最好并发 P2_CBEST（V41-0 写进 v41-env.sh）；没有、或等于 240 时只跑 c240。
# 研究者 2026-11-13：能并行的实验写成多卡数都能跑。这里用 skill 的 cellrun.py 按租到的卡并行：
#   并行变体（门 BW pass，manifest 档位 2/1）：租到 2 张卡两格同时跑；租到 1 张一格接一格；
#   串行变体（门 BW fail，只有 1 卡档）：一格接一格。
# 每格有自己的卡与端口小段（cellrun 改写 CUDA_VISIBLE_DEVICES、ORCH_PORT_BASE）。已完成的格跳过；剩下的格用不满租约时自动还卡。
set -euo pipefail
. "$PKG/scripts/v41/env.sh"
CELLS='[{"id":"p2-c240","conc":240}'
if [ -n "${P2_CBEST:-}" ] && [ "${P2_CBEST}" != 240 ]; then
  CELLS="$CELLS"',{"id":"p2-cbest","conc":'"$P2_CBEST"'}'
else
  echo "没有 P2_CBEST（或等于 240）：只跑 p2-c240"
fi
CELLS="$CELLS]"
exec python3 -I "$(dirname "${ORCH_BIN:?要经 orchd 启动（ORCH_BIN 没设）}")/cellrun.py" --cells-json "$CELLS" --gpus-per-cell 1 \
  --done-cmd '. "$PKG/scripts/v41/env.sh" >/dev/null && cell_done V4-P2 {cell}' \
  -- bash "$PKG/scripts/v41/tasks/p2_cell.sh" {cell} {conc}
