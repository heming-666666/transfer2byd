#!/usr/bin/env bash
# V4-P4（v4.1）：一个教师一格（p4-qwen3-8b 或 p4-qwen3-32b）；命令与 routes/V4-P 的 P4 节相同。
set -euo pipefail
T="${1:?用法：p4.sh <qwen3-8b|qwen3-32b>}"
. "$PKG/scripts/v41/env.sh"
if cell_done V4-P4 "p4-$T"; then echo "p4-$T 已完成，跳过"; exit 0; fi
python3 -I "$PKG/scripts/opd_run.py" --task V4-P4 --cfg "p4-$T" --role bench --gpus 1 --timing-sensitive --steps-total 3 \
  -- bash "$PKG/scripts/probes/p4_breakeven.sh" "$T"
