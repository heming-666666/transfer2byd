#!/usr/bin/env bash
# v4.1 任务脚本与 agent 窗的公共环境：source 它，不要直接执行。
#   1. 读 V4-0 写的 $OPD_RUNTIME/state/probe-env.sh（必须有）、V41-0 写的 $OPD_RUNTIME/state/v41-env.sh（起 ray/slime 的任务要）、
#      V41-ENV 在现有环境不满足时写的 v41-env-override.sh（新建的隔离环境的解释器路径；没有就不读）
#   2. 端口与临时目录从 orchd 给的 ORCH_PORT_BASE / ORCH_TMP 派生：并发的 ray/SGLang 不抢端口（v4 问题 4）
#   3. 函数在通用的 scripts/pkg/orch_env.sh：port、cell_done、wait_http、ray_head_start、ray_job_ready、ray_dash_url、own_cleanup
# 端口排法（每个任务一段 ORCH_PORT_SPAN=200 个端口，B = ORCH_PORT_BASE；docs/26 第 3 节）：
#   ray 集群 0：B+0 GCS、+1 dashboard、+2 agent listen、+3 agent grpc、+4 metrics、+5 client、+6 node manager、+7 object manager、
#               +8 runtime-env agent；worker +100…+149        集群 1（同一租约里要两个集群时）：+10…+18；worker +150…+199
#   探针的学生引擎 OPD_PORT = B+20；SGLang/教师服务 B+20…+59；其他自用 B+60…+99
: "${OPD_RUNTIME:?OPD_RUNTIME 没设}"
: "${PKG:?PKG 没设（orchd 启动的任务自带；手工跑时 export PKG=<包根>）}"
if [ ! -f "$OPD_RUNTIME/state/probe-env.sh" ]; then echo "缺 $OPD_RUNTIME/state/probe-env.sh（V4-0 第 2 步写的）" >&2; return 64 2>/dev/null || exit 64; fi
# shellcheck disable=SC1091
. "$OPD_RUNTIME/state/probe-env.sh"
# shellcheck disable=SC1091
[ -f "$OPD_RUNTIME/state/v41-env.sh" ] && . "$OPD_RUNTIME/state/v41-env.sh"
# shellcheck disable=SC1091
[ -f "$OPD_RUNTIME/state/v41-env-override.sh" ] && . "$OPD_RUNTIME/state/v41-env-override.sh"   # V41-ENV 新建的隔离环境（只有现有环境不满足时才有）
export PKG OPD_RUNTIME PKG_RESULTS="$OPD_RUNTIME/results/v4"
export OPD_PORT="$(( ${ORCH_PORT_BASE:-21000} + 20 ))"
# docs/26 的环境修正（V41-0 在 v41-env.sh 里确认或覆盖；只在本运行的环境里设，不改全局）
export SGLANG_ENABLE_JIT_DEEPGEMM="${SGLANG_ENABLE_JIT_DEEPGEMM:-false}"
export SGLANG_HOST_SKIP_DEEPGEMM="${SGLANG_HOST_SKIP_DEEPGEMM:-1}"
export RAY_AUTH_MODE="${RAY_AUTH_MODE:-disabled}"
[ -n "${CUDA_HOME_FIX:-}" ] && export CUDA_HOME="$CUDA_HOME_FIX"
# 通用部分（端口段、ray 起停、跳过已完成的格、只停本运行的进程）在 scripts/pkg/orch_env.sh，v5 起直接复用
# shellcheck disable=SC1091
. "$PKG/scripts/pkg/orch_env.sh"
