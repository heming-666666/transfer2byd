#!/usr/bin/env python3
"""由一张任务表生成 v4.1 的 state/manifest.json（orch-manifest/2）、state/tasks.yaml、state/parallel-plan.json。

三个文件必须一致（依赖、卡数、令牌），所以只从这里生成，不手改。研究者一侧写包时运行：
  python3 -I scripts/v41/make_manifest.py --pkg <包根>
云端不需要运行它（生成好的三个文件随包发）。
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pkg"))
from manifest_lib import Plan  # noqa: E402  通用的清单生成库（v5 起直接复用，见 scripts/pkg/README.md）

R = "{RUNTIME}/results/v4"
P = "{PKG}"

# 字段：id, kind, title, source, deps, gpu_options, res, extra（其余 manifest 字段）, why（放在这里的理由）
# 调度只看优先级与强制依赖（skill 2.0.0 R15）：gpu_options 的值是“偏好”（null = 卡多的优先），不写预计时长。
# 优先级由依赖结构算出（谁直接或间接需要它的结果，含下面的里程碑），不再给探针手填 prio_boost：
#   M-GATEP 是“有人在等”的决定点（研究者拿 v4a 判门 P、写 v5 代码），喂给它的任务排在一切之前；
#   G2 after Q0：Q0 先验证 slime 链路与计时口径，G2 的步时间对比用同一条链路（规范 07 §3.14 先验证再正式）。
PLAN = Plan(version="v4.1", date="2026-11-13", generator="scripts/v41/make_manifest.py")
T = PLAN.T
add = PLAN.add


ENV = "V41-ENV"            # 环境任务：所有 GPU 任务都依赖它（现有环境满足就几秒内自动判完成）
PROBES_FOR_P = ["V4-P3", "V4-P2|V4-P2s", "V4-P4a|V4-P4as", "V4-P4b|V4-P4bs", "V4-P5|V4-P5s"]
ACCEPT_PROBE = {"action": "accept", "note": "探针修复两次仍失败：照实写进 v4a 与完整回传（docs/25、06），不挡别的任务"}
VARIANT_NOTE = ("门 BW 判主机带宽够不够几个计时探针同时跑：pass 走并行变体（hostbw:s），fail 走串行变体（hostbw:x）；另一支被 orchd 自动跳过，"
                "两支写同一个结果目录。研究者在等它们的结果判门 P（里程碑 M-GATEP），所以排在其余实验之前")

# ---- v4 已完成（done_if：证据都在就直接判完成；不在就报告研究者，不重跑）
# 只有这六个写 done_if。v4 没做完的任务（F 只做了预检的一部分、P5 不完整，G2、G3、F8、Q 没做）一律不写 done_if：
# v4 已经留下了 V4-F/00-summary.md 这类“部分结果”的总结，用它判完成会把没做的任务直接跳过（2026-11-13 复查发现）
for tid, title, ev, src in [
    ("V4-0", "环境清点、自测、云端脚本冻结与回收（v4 已完成）", [R + "/V4-0/00-summary.md"], "routes/V4-0-环境清点与云端脚本回收.md"),
    ("V4-P1", "教师池探针 P1：K 个教师三种放法（v4 已完成）", [R + "/V4-P1/00-summary.md"], "routes/V4-P-教师池探针.md"),
    ("V4-NT", "真正关掉思考（v4 已完成）", [R + "/V4-NT/00-summary.md"], "routes/V4-NT-真正关掉思考.md"),
    ("V4-G1", "学生引擎的单卡上限（v4 已完成）", [R + "/V4-G1/00-summary.md"], "routes/V4-G1-学生引擎的单卡上限.md"),
    ("V4-E", "三方等价（v4 已完成）", [R + "/V4-E/three-way-*"], "routes/V4-X-可选任务.md"),
    ("V4-R", "基线复现欠账：R1-a、R2-a 第二次、R2-c（v4 已完成；Q0 与 R1-a 第 4 条在 V41-Q0、V41-R1b）",
     [R + "/V4-R/r2a-s2-*", R + "/V4-R/r2c-aA-*", R + "/V4-R/r2c-aB-*"], "routes/V4-R-基线复现欠账.md"),
]:
    add(tid, "cpu-agent", title, src, [], "v4 已完成：done_if 的证据都在就直接判完成；证据不在时子窗报告研究者（attention），不重跑",
        done_if=ev)

# ---- 环境（skill R32：实验按云端现有版本设计；现有环境满足 → 几秒内自动判完成，不开窗）
add(ENV, "cpu-agent", "环境核对：现有环境满足本包就直接完成；不满足才新建隔离环境（绝不改现有环境）", "routes/V41-总览与门控.md", [],
    "所有 GPU 任务都依赖它（skill R32 环境任务优先）；skip_if_cmd 在后台跑 env_ok.py：probe-env 齐全、torch/sglang 能导入、"
    "与 v4 的版本基线一致 → 直接完成。不满足时开环境窗照第 8 节新建隔离环境；环境窗用 T 档（1.7.0 选档表：安装、编译排障最强）",
    skip_if_cmd="python3 -I {PKG}/scripts/pkg/env_ok.py --runtime {RUNTIME}", skip_if_timeout_s=300, tier="T")

# ---- v4.1 接手与冒烟
add("V41-0", "cpu-agent", "v4.1 接手检查：包核对、自测、v4 证据清点、写 v41-env.sh", "routes/V41-总览与门控.md", [],
    "纯 CPU；最先做；它写的 v41-env.sh 给所有起 ray/slime 的任务用")
add("V41-S1", "cpu-job", "ray 端口隔离冒烟：同机两个 ray 集群同时起、各自提交 job", "routes/V41-总览与门控.md", ["V41-0", ENV],
    "验证 v4 问题 4 的修法（每个任务一个端口段）；不占卡；后面所有 ray 任务依赖它",
    cmd="bash {PKG}/scripts/v41/tasks/ray_smoke.sh", done_check=["{RUN_DIR}/ray_smoke.json"], retries=1)

# ---- 教师池探针（小回传 v4a 的主体）
add("V4-P3", "gpu-job", "教师池探针 P3：1、2、4、8 张卡同时从主机拷贝的带宽", "routes/V4-P-教师池探针.md", ["V4-0", ENV],
    "要整机安静（machine:x）、8 张卡（N=8 那一格就是 8 卡同时拷），strict_tier；它的结果决定 P2/P4/P5 能否并行（门 BW），所以排最前",
    gpu={"8": None}, res={"machine": "x", "hostbw": "x"}, strict_tier=True, cmd="bash {PKG}/scripts/v41/tasks/p3.sh",
    done_check=[R + "/V4-P3/*/bench-bw-n8.json"], progress=[R + "/V4-P3/*/progress.json"], warmup_s=900,
    if_fail={"action": "accept", "note": "P3 没数据时门 BW 判 fail（串行），P2–P5 照常跑"})
add("V41-GBW", "cpu-job", "门 BW：P3 的 8 卡每卡带宽 ≥ 单卡的 0.90 → 计时探针可以并行", "routes/V41-总览与门控.md", [],
    "纯 CPU，几秒；写门 BW（orchd.py gate）。用 after：P3 失败也照样判（没数据判 fail = 保守地串行）；"
    "gate_bw.py 本身出错时命令里的后备直接写 BW=fail，不会让 P2–P5 永远等",
    after=["V4-P3"], cmd='python3 -I {PKG}/scripts/v41/gate_bw.py --write-gate || python3 -I "$ORCH_BIN" gate --td "$ORCH_TD" BW fail '
                         '--evidence "gate_bw.py 出错：保守判串行（看本运行的 console.log）"')
for base, title, cmd, done, par_gpu in [
    ("V4-P2", "教师池探针 P2：同卡打分对生成的干扰（p2-c240、p2-cbest；cellrun 按租到的卡并行跑格）", "bash {PKG}/scripts/v41/tasks/p2.sh",
     [R + "/V4-P2/*/gen-full-on.json"], {"2": None, "1": None}),
    ("V4-P4a", "教师池探针 P4：持平点与真实形状（qwen3-8b）", "bash {PKG}/scripts/v41/tasks/p4.sh qwen3-8b",
     [R + "/V4-P4/p4-qwen3-8b-*/real-shape.json"], {"1": None}),
    ("V4-P4b", "教师池探针 P4：持平点与真实形状（qwen3-32b）", "bash {PKG}/scripts/v41/tasks/p4.sh qwen3-32b",
     [R + "/V4-P4/p4-qwen3-32b-*/real-shape.json"], {"1": None}),
    ("V4-P5", "探针 P5：生成尾部是不是吞吐问题（p5-c240，补跑）", "bash {PKG}/scripts/v41/tasks/p5.sh",
     [R + "/V4-P5/*/gen_bench.json"], {"1": None}),
]:
    common = dict(cmd=cmd, done_check=done, progress=[R + "/%s/*/progress.json" % ("V4-P4" if base.startswith("V4-P4") else base)],
                  warmup_s=1200, after=["V41-GBW"], if_fail=ACCEPT_PROBE)
    add(base, "gpu-job", title + "（并行变体）", "routes/V4-P-教师池探针.md", ["V4-0", ENV], VARIANT_NOTE,
        gpu=par_gpu, res={"hostbw": "s"}, gate={"BW": "pass"}, **common)
    add(base + "s", "gpu-job", title + "（串行变体）", "routes/V4-P-教师池探针.md", ["V4-0", ENV], VARIANT_NOTE + "；串行：一次一格",
        gpu={"1": None}, res={"hostbw": "x"}, gate={"BW": "fail"}, **common)
VARIANTS = [x for p in ("V4-P2", "V4-P4a", "V4-P4b", "V4-P5") for x in (p, p + "s")]
add("V4-A", "cpu-agent", "小回传 v4a：V4-0、P1–P5（docs/25）", "docs/25-小回传v4a.md", [],
    "P2–P5 一结束（成功、失败、跳过都算）就交，不等其他任务；纯 CPU；交好了叫醒主窗告诉研究者（notify）",
    after=["V4-0", "V4-P1", "V4-P3"] + VARIANTS, notify=True)

# ---- 基线正确性门与欠账（R2 已过，补 Q0 与 R1-a 第 4 条）
add("V41-Q0", "gpu-agent", "正确性门 Q0：学习率 0 的负对照、权重版本证明、评测截断检查、gen_last_token_s", "routes/V41-总览与门控.md",
    ["V4-R", "V41-S1", ENV], "R2-a 的配置要 8 卡（strict_tier）；短；Q 依赖它（先证明权重真的在更新）；结论叫醒主窗（notify）",
    gpu={"8": None}, res={"hostbw": "s"}, strict_tier=True, warmup_s=1500,
    notify=True)
add("V41-R1b", "gpu-agent", "R1-a 第 4 条补测：关掉思考、8192 token 上限下的 GSM8K", "routes/V41-总览与门控.md",
    ["V4-R", "V4-NT", "V41-S1", ENV], "只用学生引擎评测，不碰主机带宽；2 卡时评测数据分两片并行（cellrun），1 卡也能跑，回填空卡",
    gpu={"2": None, "1": None}, warmup_s=1200,
    if_fail={"action": "accept", "note": "补测修两次仍不过：照实交（R1-a 第 4 条记为未过，附截断率）"})

# ---- 探索与确认层（v4 的 G2、G3、F、F8、Q）
add("V4-G2", "gpu-agent", "slime 租户扫描（最强基线）", "routes/V4-G2-slime租户扫描.md", ["V4-R", "V41-S1", ENV],
    "计时：整机独占（machine:x + hostbw:x）、8 卡（strict_tier）；下游 G3、F8、Ft、L 都等它；after Q0：Q0 先验证 slime 链路"
    "（权重确实同步、计时口径 gen_last_token_s），G2 的步时间对比用同一条链路（规范 07 §3.14 先验证再正式），Q0 没过也照跑、00 里注明；"
    "失败要研究者决定（不写预案）",
    gpu={"8": None}, res={"machine": "x", "hostbw": "x"}, strict_tier=True, warmup_s=1500,
    after=["V41-Q0"])
add("V4-G3", "cpu-agent", "尾部掉队（不占卡）", "routes/V4-G3-尾部掉队.md", ["V4-G1", "V4-G2"], "纯 CPU 分析", if_fail={"action": "accept", "note": "分析修两次仍不成：照实交"})
add("V4-F8", "gpu-agent", "八卡同卡补测（教师池 K = 1）", "routes/V4-F8-八卡同卡补测.md", ["V4-G2", ENV],
    "计时：整机独占、8 卡（strict_tier）", gpu={"8": None}, res={"machine": "x", "hostbw": "x"}, strict_tier=True, warmup_s=1500, if_fail={"action": "accept", "note": "补测修两次仍失败：照实交"})
add("V4-Fp", "gpu-agent", "少卡可行性图：预检（不计时，N = 1、2、4）", "routes/V4-F-少卡可行性图.md", ["V4-G1", "V41-S1", ENV],
    "不计时：可以与别的任务同机；N=1、2、4 的格用 cellrun 按租到的卡并行（allow_partial：格要的卡数不同）",
    gpu={"4": None, "2": None, "1": None}, res={"hostbw": "s"}, allow_partial=True,
    warmup_s=1500, if_fail={"action": "accept", "note": "预检修两次仍失败：照实交（计时臂会跳过）"})
add("V4-Ft", "gpu-agent", "少卡可行性图：计时臂", "routes/V4-F-少卡可行性图.md", ["V4-Fp", "V4-G2", ENV],
    "计时，只怕主机带宽争用：hostbw:x（不流式的任务可以同机）；一次一格", gpu={"1": None}, res={"hostbw": "x"}, warmup_s=1500, if_fail={"action": "accept", "note": "计时臂修两次仍失败：照实交"})
add("V4-Q", "gpu-agent", "“看得出在学”的配置", "routes/V4-Q-看得出在学的配置.md", ["V4-R", "V41-Q0", ENV],
    "不计时；训练用 CPU 优化器卸载（hostbw:s）；偏好 4 卡（4 卡与 8 卡一样快，另 4 张给别的任务），没有 4 张空卡时才用 8 卡；"
    "失败要研究者决定（不写预案）",
    gpu={"4": 1, "8": 2}, res={"hostbw": "s"}, warmup_s=1800)

# ---- 可选（只回填空卡）
add("V4-L", "gpu-agent", "长度预算（可选）", "routes/V4-X-可选任务.md", ["V4-NT", "V4-G2", "V4-Q", ENV], "可选；整机独占；优先级最低；修不好就放弃",
    gpu={"8": None}, res={"machine": "x", "hostbw": "x"}, strict_tier=True, prio_boost=-3, optional=True, if_fail={"action": "drop", "note": "可选任务：修两次仍失败就放弃"})
add("V4-T", "gpu-agent", "超大教师（可选）", "routes/V4-X-可选任务.md", ["V41-S1", ENV], "可选；2 卡；只回填空卡；修不好就放弃",
    gpu={"2": None}, res={"hostbw": "s"}, prio_boost=-3, optional=True,
    if_fail={"action": "drop", "note": "可选任务：修两次仍失败就放弃"})

# ---- 里程碑：谁需要这些结果（不执行；依赖满足就自动记完成）。它们让任务图之外的需求进入优先级（skill R15）
add("M-GATEP", "milestone", "研究者判门 P（教师池是否成立）、开始写 v5 的代码", "docs/25-小回传v4a.md", PROBES_FOR_P + ["V4-A"],
    "有人在等的决定点（waiting_human）：研究者要靠小回传 v4a 尽早写 v5 的代码（docs/25），喂给它的任务排在其余一切之前",
    waiting_human=True)
add("M-PREMISE", "milestone", "全部比较的前提：基线按官方示例复现、训练与计时口径正确", "docs/12-实验与论文的对应.md",
    ["V4-R", "V41-R1b", "V41-Q0"], "docs/12：基线复现（R1、R2）是全部比较的前提；Q0 验证训练确实在学、计时口径对")
add("M-V5DESIGN", "milestone", "v5（教师池端到端）的设计", "docs/00-v4.1先读这一篇.md", ["M-GATEP", "M-PREMISE", "V4-G2", "V4-Q"],
    "v5 的端到端实验要：门 P 的结论、比较前提、最强基线的配置（G2）、看得出在学的训练配置（Q）")
add("M-PAPER-BASELINE", "milestone", "论文：最强基线（slime 只调已有开关能拿回多少）与尾部掉队", "routes/V4-G2-slime租户扫描.md",
    ["V4-G2", "V4-G3"], "论文的基线一节要这两个结果")
add("M-PAPER-FEWCARD", "milestone", "论文：教师池 K = 1 的少卡可行性图与八卡同卡", "routes/V4-F-少卡可行性图.md",
    ["V4-Fp", "V4-Ft", "V4-F8"], "论文的主结果之一要这三个结果")

OPTIONAL = ["V4-L", "V4-T"]
ALL_RUN = [t["id"] for t in T]
add("V4-RT", "cpu-agent", "完整回传（docs/06、07）", "docs/06-结果格式与回传-1-规则.md", [],
    "最后做；纯 CPU；所有任务结束（成功、失败、跳过）后交，失败照实写；交好了叫醒主窗（notify）", after=ALL_RUN, notify=True)

RUN_ENV = {"PKG": "{PKG}", "OPD_RUNTIME": "{RUNTIME}", "OPD_GPU_LEASE": "external", "OPD_AGENT": "orchd:{ID}"}
BRIEF = {
    "read_first": ["docs/00-v4.1先读这一篇.md", "routes/V41-总览与门控.md"],
    "results_hint": " `$OPD_RUNTIME/results/v4/{ID}/`（v4.1 的结果继续写 v4 的目录；00-summary.md 写判据、结果、证据路径） ",
    "rules": [
        "每个实验都经 `python3 -I $PKG/scripts/opd_run.py` 启动（docs/00 第 4 节）：它记 run.json、gpu.csv、progress.json，"
        "并按 skill 的约定写 $ORCH_PROGRESS、在认出第一步时 touch $ORCH_STARTED（orchd 据此确认实验真开始）",
        "GPU 命令一律 `python3 -I $ORCH_BIN exec --td $ORCH_TD <任务> -- <命令>`；端口与 ray 用 `. $PKG/scripts/v41/env.sh` 的 "
        "`port`、`ray_head_start`、`ray_job_ready`、`ray_dash_url`，不写死端口（routes/V41 第 7 节）",
        "一组互相独立的格（配置、种子、分片）用 skill 的 cellrun.py 按租到的卡并行跑（`python3 -I $(dirname $ORCH_BIN)/cellrun.py --help`）",
        "停进程只用 `orchd.py kill` 或 env.sh 的 `own_cleanup`；不用 `ray stop`、`pkill`（v4 问题 2）",
        "冻结的 v4 运行脚本只许改路线卡点名的参数与 CLI 语法、环境变量（版本适配、端口段），改动写进 02 的 diff 与上下文卡",
        "环境问题先看 docs/26（云端环境经验与弯路记录）；不改驱动、系统包、全局环境变量、网络与代理设置",
        "不编造：没测的写 NA:原因；花了 10 分钟以上的非实验问题写进报告的“给后来者的经验”（汇总成 14-detours.md）",
    ],
}


ROLES = [("DASH", "实时看板（多页：总览、GPU 与调度、任务、探针、研究与论文、节点）"), ("AUDIT", "独立验收"),
         ("RTRN", "回传承办"), ("ENV", "环境（只读核对，不安装）"), ("SNAP", "快照（每 30 分钟与每个任务结束）")]


for _rid, _title in ROLES:
    PLAN.role(_rid, _title)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pkg", required=True)
    a = ap.parse_args()
    PLAN.write(a.pkg, {
        "results_root": "results/v4（v4.1 是 v4 的补完包，结果继续写 v4 目录）",
        "partitions": {"A": [0, 1, 2, 3], "B": [4, 5, 6, 7]},
        "sched_defaults": {"warmup_s": 1200, "stall_s": 900, "util_min": 5, "port_base": 21000, "port_span": 200,
                           "reserve_ttl_s": 900, "agent_idle_s": 1800, "start_hold_s": 30, "lost_s": 120,
                           "disk_min_gb": 200, "max_windows": 6, "max_fix": 2, "tier_by_kind": {"judge": "M"}},
        "run_env": RUN_ENV, "brief": BRIEF, "read_first": BRIEF["read_first"],
        "gates": {"BW": "V41-GBW：P3 的 8 卡每卡拷贝带宽 ≥ 单卡的 0.90 → pass（计时探针并行）；否则 fail（串行）",
                  "P": "研究者在 v4a 回传上判（P1′ 在 v5 的 T0；本包不写门 P）"}})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
