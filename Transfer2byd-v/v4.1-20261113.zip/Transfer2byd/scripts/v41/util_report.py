#!/usr/bin/env python3
"""卡时账 15-gpu-util.csv：从 orchd 的 notes/sched/（state.json 的累计账、gpu.jsonl 的逐轮采样）生成，回传窗用。

用法：python3 -I util_report.py --td <任务目录> --out <回传目录>/15-gpu-util.csv
表的三段（同一个 CSV，section 列区分）：
  total   各类卡时（GPU·小时）与占比：真在用 / 租而未用 / 空卡（预留、令牌等待、余卡不够、无就绪、可避免）/ 别人占用 / 采样失败
  hourly  每小时每张卡：平均利用率、租给了谁（最多的那个）、空着的采样占比
  task    每个任务：租到的卡时（逐轮采样里该任务出现的卡·秒）
退出码：0；2 没有 orchd 的状态文件。
"""
import argparse
import csv
import json
import os
import sys
import time
from collections import Counter, defaultdict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--td", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    sd = os.path.join(a.td, "notes", "sched")
    st = json.load(open(os.path.join(sd, "state.json"), encoding="utf-8")) if os.path.exists(os.path.join(sd, "state.json")) else None
    if not st:
        print("没有 %s/state.json（orchd 没在这个任务目录跑过？）" % sd, file=sys.stderr)
        return 2
    rows = []
    acc = st.get("acct", {})
    tot = sum(v for k, v in acc.items() if k != "alloc_s") or 1.0
    names = [("used_s", "真在用"), ("alloc_idle_s", "租而未用"), ("idle_reserved_s", "空卡：为大任务凑卡（预留）"),
             ("idle_token_s", "空卡：计时任务要安静窗口（令牌互斥）"), ("idle_fit_s", "空卡：余卡不够任何就绪任务"),
             ("idle_noready_s", "空卡：没有就绪任务"), ("idle_avoidable_s", "空卡：可避免"), ("idle_other_s", "空卡：其他"),
             ("other_s", "别人占用"), ("unknown_s", "采样失败")]
    for k, name in names:
        rows.append(["total", "", "", name, round(acc.get(k, 0) / 3600, 3), round(acc.get(k, 0) / tot, 4), "GPU·h / 占比"])
    hourly = defaultdict(lambda: {"u": [], "lease": Counter(), "idle": 0, "n": 0})
    per_task = Counter()
    last_t = None
    gl = os.path.join(sd, "gpu.jsonl")
    if os.path.exists(gl):
        for line in open(gl, encoding="utf-8"):
            try:
                r = json.loads(line)
            except ValueError:
                continue
            dt = min(max(r["t"] - last_t, 0), 60) if last_t else 0
            last_t = r["t"]
            hour = time.strftime("%Y-%m-%d %H:00", time.localtime(r["t"]))
            for i, (u, lease) in enumerate(zip(r.get("u", []), r.get("l", []))):
                h = hourly[(hour, i)]
                h["u"].append(u)
                h["n"] += 1
                if lease:
                    h["lease"][lease] += 1
                    per_task[lease] += dt
                else:
                    h["idle"] += 1
    for (hour, i), h in sorted(hourly.items()):
        top = h["lease"].most_common(1)
        rows.append(["hourly", hour, i, top[0][0] if top else "", round(sum(h["u"]) / len(h["u"]), 1) if h["u"] else "",
                     round(h["idle"] / h["n"], 3) if h["n"] else "", "平均利用率% / 空着的采样占比"])
    for task, s in per_task.most_common():
        rows.append(["task", "", "", task, round(s / 3600, 3), "", "租到的卡时（GPU·h）"])
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["section", "hour", "gpu", "name", "value", "share", "unit"])
        w.writerows(rows)
    print("写出 %s：%d 行（真在用 %.1f%%）" % (a.out, len(rows), 100 * acc.get("used_s", 0) / tot))
    return 0


if __name__ == "__main__":
    sys.exit(main())
