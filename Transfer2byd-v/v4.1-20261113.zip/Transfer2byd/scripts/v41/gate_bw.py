#!/usr/bin/env python3
"""门 BW（v4.1）：P3 的 8 卡每卡主机拷贝带宽 ≥ 单卡的 0.90 → pass（计时探针 P2/P4/P5 可以同时跑，hostbw:s）；
否则 fail（串行，hostbw:x）。阈值写包时定（routes/V41-总览与门控.md 第 3 节），数据出来前不改。

为什么是 0.90：P3 量的就是“几张卡同时从主机拷贝时每卡还剩多少带宽”。8 张卡同时拷时每卡还有单卡的 90% 以上，
说明主机内存与 PCIe 不是瓶颈，几个各占一张卡的计时探针同时跑，相互干扰 ≤ 10%（且每个探针的开/关对照在同一条件下配对）。
P3 没有数据（失败、没跑）时判 fail：保守地串行，不会让 P2–P5 永远等。

用法：python3 -I gate_bw.py [--runtime $OPD_RUNTIME] [--write-gate]
  --write-gate：同时调用 $ORCH_BIN gate --td $ORCH_TD BW pass|fail（orchd 据此放行一支、跳过另一支）
写 $OPD_RUNTIME/results/v4/gates/BW.json。退出码：0。
"""
import argparse
import glob
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import mini_return as MR  # noqa: E402  与 v4a 的 P3 判定同一段代码

THRESH = 0.90


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runtime", default=os.environ.get("OPD_RUNTIME", ""))
    ap.add_argument("--write-gate", action="store_true")
    a = ap.parse_args()
    root = os.path.join(a.runtime, "results", "v4")
    per = {}
    for run in MR.runs_of(root, "V4-P3"):
        for p in glob.glob(os.path.join(run["_dir"], "bench-bw-n*.json")):
            b = MR.load(p)
            if b:
                per[len(b.get("gpus", []))] = MR.best_gbps(b)
    if per.get(1) and per.get(8):
        q = per[8] / per[1]
        verdict = "pass" if q >= THRESH else "fail"
        basis = "8 卡每卡 %.2f GB/s ÷ 单卡 %.2f GB/s = %.3f（阈值 %.2f）" % (per[8], per[1], q, THRESH)
    else:
        q, verdict = None, "fail"
        basis = "P3 没有 N=1 与 N=8 的数据（%s）：保守地判 fail，计时探针串行" % sorted(per)
    out = {"gate": "BW", "verdict": verdict, "ratio_n8_over_n1": q, "per_gpu_GBps": per, "threshold": THRESH, "basis": basis}
    os.makedirs(os.path.join(root, "gates"), exist_ok=True)
    p = os.path.join(root, "gates", "BW.json")
    json.dump(out, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps(out, ensure_ascii=False))
    if a.write_gate:
        ob, td = os.environ.get("ORCH_BIN"), os.environ.get("ORCH_TD")
        if ob and td:
            subprocess.run([sys.executable, "-I", ob, "gate", "--td", td, "BW", verdict, "--evidence", p], check=True)
        else:
            print("没有 ORCH_BIN/ORCH_TD：门 BW 只写了文件，请主窗手工 orchd.py gate --td <TD> BW %s" % verdict, file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
