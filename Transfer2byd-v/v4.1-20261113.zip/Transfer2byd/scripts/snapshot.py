#!/usr/bin/env python3
"""Snapshots for ledgers and results, so an accidental delete or truncate can be undone quickly.

Usage:
  snapshot.py take    --dest BACKUP_DIR [--keep N] [--copy-max-mb M] [--min-free-gb G] SRC [SRC ...]
  snapshot.py list    --dest BACKUP_DIR
  snapshot.py find    --dest BACKUP_DIR PATH_SUBSTRING          # which snapshots contain a file
  snapshot.py restore --dest BACKUP_DIR --snap NAME --path ORIGINAL_ABS_PATH [--to TARGET] [--force]
  snapshot.py help

How files are stored (why it protects against both rm and "> file" truncation):
  * small files (<= --copy-max-mb, default 64 MB: ledgers, CSV, JSON, notes) are real copies,
    so truncating or rewriting the live file does not touch the snapshot;
  * a file unchanged since the previous snapshot (same size and mtime) is hard-linked to the
    previous snapshot's copy (no extra space);
  * big files (weights, checkpoints, raw traces) are hard-linked to the live file. This survives rm,
    but not in-place edits, so big result files must be write-once (write tmp, then rename).
Each snapshot has MANIFEST.json (path, size, mtime, mode=copy|link-prev|link-live).
restore never overwrites: by default it writes <path>.restored-<snap>; --force replaces the file
after keeping the current one as <path>.before-restore-<time>.
Exit codes: 0 ok; 1 refused (low disk, nothing found, target exists); 2 usage error.
"""
import argparse
import json
import os
import shutil
import sys
import time

def free_gb(path):
    u = shutil.disk_usage(path)
    return u.free / 1e9


def snaps(dest):
    if not os.path.isdir(dest):
        return []
    return sorted(d for d in os.listdir(dest) if d.startswith("snap-") and
                  os.path.isfile(os.path.join(dest, d, "MANIFEST.json")))


def load_manifest(dest, name):
    with open(os.path.join(dest, name, "MANIFEST.json"), encoding="utf-8") as f:
        return json.load(f)


def take(a):
    os.makedirs(a.dest, exist_ok=True)
    fg = free_gb(a.dest)
    if fg < a.min_free_gb:
        print(f"拒绝：{a.dest} 只剩 {fg:.1f} GB，低于 {a.min_free_gb} GB。先报告，不删别人的文件。")
        return 1
    prev = snaps(a.dest)
    prev_name = prev[-1] if prev else None
    prev_files = {}
    if prev_name:
        for r in load_manifest(a.dest, prev_name)["files"]:
            prev_files[r["path"]] = r
    name = "snap-" + time.strftime("%Y%m%d-%H%M%S")
    k = 1
    while os.path.exists(os.path.join(a.dest, name)):
        name = name.split("~")[0] + f"~{k}"
        k += 1
    root = os.path.join(a.dest, name + ".partial")
    rows, nbytes = [], 0
    dest_abs = os.path.abspath(a.dest)
    for src in a.srcs:
        src = os.path.abspath(src)
        if not os.path.exists(src):
            print(f"跳过（不存在）：{src}")
            continue
        walk = [(os.path.dirname(src), [], [os.path.basename(src)])] if os.path.isfile(src) else os.walk(src)
        for d, dirs, fns in walk:
            if os.path.abspath(d).startswith(dest_abs):
                dirs[:] = []
                continue
            dirs[:] = [x for x in dirs if not os.path.abspath(os.path.join(d, x)).startswith(dest_abs)]
            for fn in fns:
                p = os.path.join(d, fn)
                if os.path.islink(p) or not os.path.isfile(p):
                    continue
                st = os.stat(p)
                out = os.path.join(root, p.lstrip("/"))
                os.makedirs(os.path.dirname(out), exist_ok=True)
                old = prev_files.get(p)
                if old and old["size"] == st.st_size and old["mtime_ns"] == st.st_mtime_ns and old["mode"] != "link-live":
                    os.link(os.path.join(a.dest, prev_name, p.lstrip("/")), out)
                    mode = "link-prev"
                elif st.st_size <= a.copy_max_mb * 1e6:
                    shutil.copy2(p, out)
                    mode = "copy"
                    nbytes += st.st_size
                else:
                    try:
                        os.link(p, out)
                        mode = "link-live"
                    except OSError:
                        shutil.copy2(p, out)
                        mode = "copy"
                        nbytes += st.st_size
                rows.append({"path": p, "size": st.st_size, "mtime_ns": st.st_mtime_ns, "mode": mode})
    os.makedirs(root, exist_ok=True)
    with open(os.path.join(root, "MANIFEST.json"), "w", encoding="utf-8") as f:
        json.dump({"name": name, "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "sources": a.srcs,
                   "files": rows}, f, ensure_ascii=False, indent=1)
    os.rename(root, os.path.join(a.dest, name))
    removed = []
    allsn = snaps(a.dest)
    for old in allsn[:-a.keep] if a.keep > 0 else []:
        shutil.rmtree(os.path.join(a.dest, old))
        removed.append(old)
    n_copy = sum(r["mode"] == "copy" for r in rows)
    print(f"快照 {name}：{len(rows)} 个文件（新复制 {n_copy} 个，{nbytes/1e6:.1f} MB），"
          f"删除最旧的 {len(removed)} 份；剩余空间 {free_gb(a.dest):.1f} GB")
    return 0


def cmd_list(a):
    for s in snaps(a.dest):
        m = load_manifest(a.dest, s)
        print(f"{s}\t{len(m['files'])} 个文件\t{m['created']}")
    return 0


def cmd_find(a):
    found = 0
    for s in snaps(a.dest):
        for r in load_manifest(a.dest, s)["files"]:
            if a.substr in r["path"]:
                print(f"{s}\t{r['path']}\t{r['size']} B\t{r['mode']}")
                found += 1
    if not found:
        print("没有快照包含这个路径")
    return 0 if found else 1


def cmd_restore(a):
    if a.snap not in snaps(a.dest):
        print(f"没有这个快照：{a.snap}")
        return 1
    rows = {r["path"]: r for r in load_manifest(a.dest, a.snap)["files"]}
    src_abs = os.path.abspath(a.path)
    if src_abs not in rows:
        print(f"快照 {a.snap} 里没有 {src_abs}；用 find 查哪个快照有")
        return 1
    stored = os.path.join(a.dest, a.snap, src_abs.lstrip("/"))
    if rows[src_abs]["mode"] == "link-live" and os.path.exists(src_abs) and \
            os.stat(src_abs).st_ino == os.stat(stored).st_ino:
        print("提示：这是大文件的硬链接，内容与当前文件相同（大文件应只写一次）")
    if a.force:
        target = src_abs
        if os.path.exists(target):
            keep = f"{target}.before-restore-{time.strftime('%Y%m%d-%H%M%S')}"
            os.rename(target, keep)
            print(f"当前文件已保留为 {keep}")
    else:
        target = a.to or f"{src_abs}.restored-{a.snap}"
        if os.path.exists(target):
            print(f"目标已存在，不覆盖：{target}")
            return 1
    os.makedirs(os.path.dirname(target), exist_ok=True)
    shutil.copy2(stored, target)
    print(f"已恢复到 {target}")
    return 0


def main(argv):
    if not argv or argv[0] in ("help", "-h", "--help"):
        print(__doc__)
        return 0 if argv else 2
    p = argparse.ArgumentParser(prog="snapshot.py")
    sub = p.add_subparsers(dest="cmd")
    t = sub.add_parser("take")
    t.add_argument("--dest", required=True)
    t.add_argument("--keep", type=int, default=48)
    t.add_argument("--copy-max-mb", type=float, default=64)
    t.add_argument("--min-free-gb", type=float, default=50)
    t.add_argument("srcs", nargs="+")
    l = sub.add_parser("list")
    l.add_argument("--dest", required=True)
    f = sub.add_parser("find")
    f.add_argument("--dest", required=True)
    f.add_argument("substr")
    r = sub.add_parser("restore")
    r.add_argument("--dest", required=True)
    r.add_argument("--snap", required=True)
    r.add_argument("--path", required=True)
    r.add_argument("--to")
    r.add_argument("--force", action="store_true")
    try:
        a = p.parse_args(argv)
    except SystemExit:
        return 2
    return {"take": take, "list": cmd_list, "find": cmd_find, "restore": cmd_restore}.get(a.cmd, lambda _: 2)(a)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
