#!/usr/bin/env python3
"""ret_extra: 从启动器留下的运行目录生成两张回传表。只用标准库。

    ret_extra.py --results $OPD_RUNTIME/results/v4 --out <回传文件目录>

写出：
- 10-runs.csv   每次运行一行（包括失败、被杀、冒烟的），数据全部来自 run.json 与 SHA256SUMS：
    task,cfg,run_id,role,arm,pair,seed,status,exit,gpus,gpu_roles,lease,ts,t_start_utc,wall_s,steps_seen,
    steps_total,warmup,params,tunable,files,sha_ok,qc
- 11-energy.csv 每次运行 × 每个窗口 × 每种角色一行，来自 gpu.csv：
    task,cfg,run_id,window,role,ngpu,t_s,energy_j,energy_src,mean_w,util_mean,util_p10,mem_peak_mb_max,
    mem_peak_mb_min,temp_max,err_j
  window：pre_idle（开跑前的空闲窗口）、run（命令运行期间）、step<k>（启动器认出的第 k 步到下一步）。
  energy_src：counter = 累计能耗计数器之差；integral = 对功率做梯形积分（计数器读不到时）。
  err_j：窗口两端到最近采样点的时间差 × 该处功率，是能耗的误差上界。
  只给总量（焦耳、秒、卡数）；平均功率 = energy_j ÷ t_s ÷ ngpu 另列方便看，比值由本机算。
"""
from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import os
import sys


def load(p, d=None):
    try:
        with open(p, encoding="utf-8") as h:
            return json.load(h)
    except (OSError, ValueError):
        return d


def sha_ok(run_dir):
    p = os.path.join(run_dir, "SHA256SUMS")
    if not os.path.exists(p):
        return "missing", 0
    n, bad = 0, 0
    for line in open(p, encoding="utf-8"):
        if "  " not in line:
            continue
        want, rel = line.rstrip("\n").split("  ", 1)
        n += 1
        fp = os.path.join(run_dir, rel)
        try:
            d = hashlib.sha256()
            with open(fp, "rb") as h:
                for b in iter(lambda: h.read(1 << 20), b""):
                    d.update(b)
            if d.hexdigest() != want:
                bad += 1
        except OSError:
            bad += 1
    return ("ok" if bad == 0 else f"bad:{bad}"), n


def read_gpu(path):
    """返回 {gpu: [(t, energy_mj|None, power_mw|None, util|None, mem|None, temp|None)]}"""
    out = {}
    if not os.path.exists(path):
        return out

    def num(x):
        try:
            return float(x)
        except ValueError:
            return None
    with open(path, encoding="utf-8", newline="") as h:
        for r in csv.DictReader(h):
            t = num(r["t"])
            if t is None:
                continue
            out.setdefault(r["gpu"], []).append((t, num(r["energy_mj"]), num(r["power_mw"]), num(r["util_pct"]),
                                                 num(r["mem_used_mb"]), num(r["temp_c"])))
    return out


def window(samples, t0, t1):
    """一张卡在 [t0, t1] 的能耗等。返回 dict 或 None（窗口内没有样本）。"""
    ts = [s[0] for s in samples]
    i0, i1 = bisect.bisect_left(ts, t0), bisect.bisect_right(ts, t1) - 1
    # 取窗口两端最近的样本（允许落在窗口外一点），用来读计数器
    a = min(range(len(ts)), key=lambda i: abs(ts[i] - t0)) if ts else None
    b = min(range(len(ts)), key=lambda i: abs(ts[i] - t1)) if ts else None
    if a is None or b is None or b <= a:
        return None
    inner = samples[i0:i1 + 1] if i1 >= i0 else samples[a:b + 1]
    pw = [s[2] for s in samples[a:b + 1]]
    if samples[a][1] is not None and samples[b][1] is not None and samples[b][1] >= samples[a][1]:
        e, src = (samples[b][1] - samples[a][1]) / 1000.0, "counter"
    elif all(p is not None for p in pw):
        e = sum((samples[i][2] + samples[i + 1][2]) / 2 / 1000.0 * (ts[i + 1] - ts[i]) for i in range(a, b))
        src = "integral"
    else:
        return None
    pa = samples[a][2] or 0
    pb = samples[b][2] or 0
    err = (abs(ts[a] - t0) * pa + abs(ts[b] - t1) * pb) / 1000.0
    util = sorted(s[3] for s in inner if s[3] is not None)
    mem = [s[4] for s in inner if s[4] is not None]
    temp = [s[5] for s in inner if s[5] is not None]
    return {"e": e, "src": src, "err": err, "t": ts[b] - ts[a], "util": util, "mem": max(mem) if mem else None,
            "temp": max(temp) if temp else None}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-step-rows", type=int, default=60, help="每次运行最多输出多少个逐步窗口")
    ap.add_argument("--tasks", help="只要这些任务（逗号分隔，如 V4-0,V4-P1）；默认全部")
    a = ap.parse_args(argv)
    os.makedirs(a.out, exist_ok=True)
    runs, energy = [], []
    want = set(x.strip() for x in a.tasks.split(",")) if a.tasks else None
    for task in sorted(os.listdir(a.results)):
        if want is not None and task not in want:
            continue
        tdir = os.path.join(a.results, task)
        if not os.path.isdir(tdir):
            continue
        for rid in sorted(os.listdir(tdir)):
            rd = os.path.join(tdir, rid)
            run = load(os.path.join(rd, "run.json"))
            if not run:
                continue
            ok, nfiles = sha_ok(rd)
            qc = []
            if run.get("status") == "running":
                qc.append("unfinished")
            if run.get("qc_note"):
                qc.append("not_idle_at_start")
            g = read_gpu(os.path.join(rd, "gpu.csv"))
            if run.get("gpu_ids") and not g:
                qc.append("no_gpu_csv")
            roles = run.get("gpu_roles", {})
            runs.append([run.get("task"), run.get("cfg_name"), rid, run.get("role"), run.get("arm"), run.get("pair"),
                         run.get("seed"), run.get("status"), run.get("exit_code"), len(run.get("gpu_ids", [])),
                         ";".join(f"{k}={v}" for k, v in sorted(roles.items())), run.get("lease"),
                         int(bool(run.get("timing_sensitive"))), run.get("t_start_utc"), run.get("wall_s"),
                         run.get("steps_seen"), run.get("steps_total"), run.get("warmup_steps"),
                         ";".join(f"{k}={v}" for k, v in sorted(run.get("cfg", {}).items())),
                         ";".join(f"{t['param']}:{t['old']}->{t['new']}({t['reason']})" for t in run.get("tunable_changes", [])),
                         nfiles, ok, ";".join(qc) or "ok"])
            if not g:
                continue
            wins = []
            if run.get("pre_idle") and run["pre_idle"][1]:
                wins.append(("pre_idle", run["pre_idle"][0], run["pre_idle"][1]))
            if run.get("t_cmd_start") and run.get("t_end"):
                wins.append(("run", run["t_cmd_start"], run["t_end"]))
            marks = []
            mp = os.path.join(rd, "step_marks.jsonl")
            if os.path.exists(mp):
                for line in open(mp, encoding="utf-8"):
                    try:
                        marks.append(json.loads(line))
                    except ValueError:
                        pass
            for i in range(len(marks) - 1):
                if i < a.max_step_rows:
                    wins.append((f"step{marks[i]['step']}", marks[i]["t"], marks[i + 1]["t"]))
            by_role = {}
            for gpu in g:
                by_role.setdefault(roles.get(gpu, "shared"), []).append(gpu)
            for name, t0, t1 in wins:
                for role, gl in sorted(by_role.items()):
                    ws = [window(g[x], t0, t1) for x in gl]
                    if any(w is None for w in ws):
                        energy.append([run.get("task"), run.get("cfg_name"), rid, name, role, len(gl), round(t1 - t0, 3),
                                       "NA:no-samples", "", "", "", "", "", "", "", ""])
                        continue
                    e = sum(w["e"] for w in ws)
                    util = sorted(u for w in ws for u in w["util"])
                    mems = [w["mem"] for w in ws if w["mem"] is not None]
                    temps = [w["temp"] for w in ws if w["temp"] is not None]
                    t = t1 - t0
                    energy.append([run.get("task"), run.get("cfg_name"), rid, name, role, len(gl), round(t, 3),
                                   round(e, 1), "+".join(sorted({w["src"] for w in ws})),
                                   round(e / t / len(gl), 1) if t > 0 else "",
                                   round(sum(util) / len(util), 1) if util else "",
                                   util[max(0, len(util) // 10 - 1)] if util else "",
                                   max(mems) if mems else "", min(mems) if mems else "", max(temps) if temps else "",
                                   round(sum(w["err"] for w in ws), 1)])
    for name, header, rows in (
        ("10-runs.csv", "task,cfg,run_id,role,arm,pair,seed,status,exit,gpus,gpu_roles,lease,ts,t_start_utc,wall_s,"
                        "steps_seen,steps_total,warmup,params,tunable,files,sha_ok,qc", runs),
        ("11-energy.csv", "task,cfg,run_id,window,role,ngpu,t_s,energy_j,energy_src,mean_w,util_mean,util_p10,"
                          "mem_peak_mb_max,mem_peak_mb_min,temp_max,err_j", energy)):
        tmp = os.path.join(a.out, name + ".tmp")
        with open(tmp, "w", encoding="utf-8", newline="") as h:
            w = csv.writer(h, lineterminator="\n")
            w.writerow(header.split(","))
            w.writerows([["" if x is None else x for x in r] for r in rows])
        os.replace(tmp, os.path.join(a.out, name))
        print(f"{name}: {len(rows)} 行")
    return 0


if __name__ == "__main__":
    sys.exit(main())
