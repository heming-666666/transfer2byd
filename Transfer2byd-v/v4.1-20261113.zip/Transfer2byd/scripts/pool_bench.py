#!/usr/bin/env python3
"""pool_bench: 多教师 OPD 的三种教师放法在同一张卡上的对比（V4-P1 的核心）。需要 torch 与 GPU，只在云端运行。

    $PY scripts/pool_bench.py --scorer $OPD_SCORER --gpu 0 --seqs <一步的 seqs.jsonl> --limit 240 \
        --teachers /dev/shm/proctor/qwen3-8b,/dev/shm/proctor/qwen3-14b --arms R,S,M --repeats 2 \
        --out $OPD_RUN_DIR/pool_bench.json

一步的序列按顺序轮流分给 K 个教师（模拟按领域路由：第 i 条给教师 i mod K）。三种放法只改“教师放在哪里”：
  R 常驻：先把 K 个教师都构造成常驻打分器（全部层留在这张卡上），再依次给各自的那份打分；
          放不下时记 oom 和是第几个教师放不下（这就是“专用卡常驻”在这张卡剩余显存下的可行性）。
  S 整模型换入换出：对每个教师依次 构造常驻打分器（换入）→ 打分 → 释放；时间 = Σ(换入 + 打分 + 释放)。
  M 教师池（按层流式）：K 个流式打分器同时存在（每个只占两层的缓冲），依次打分；时间 = Σ 打分。
每个臂记：状态、每个教师的 init_s / score_s / free_s / tokens / 拷贝统计、整臂的墙钟、这张卡的峰值显存；
三臂的分数逐值比较（M 对 R、M 对 S 的最大差，应为 0）。
这张卡上应当已经有学生推理引擎占着显存（路线卡先起引擎），这样测的才是“和学生同卡”的情形。

本机没有 GPU：设 OPD_POOL_FAKE=1 时用内置的假打分器跑通全部流程（只用于研究者的自测）。
"""
from __future__ import annotations

import argparse
import gc
import importlib.util
import json
import os
import sys
import time


# ---------------------------------------------------------------- 后端（真 torch 或自测用的假实现）

class FakeBackend:
    """自测用：假装每个常驻教师占 meta['host_gb'] GB，流式占 2 层；超过 cap_gb 就抛 OOM。"""

    def __init__(self, cap_gb=80.0, used_gb=30.0):
        self.cap, self.used, self.peak = cap_gb, used_gb, used_gb

    class _Scorer:
        def __init__(self, be, packed, gpu, mode="stream", attn="sdpa"):
            meta = json.load(open(os.path.join(packed, "meta.json")))
            self.be, self.mode = be, mode
            self.n = meta["n_layers"]
            self.gb = meta["host_gb"] if mode == "resident" else 2 * meta["layer_bytes"] / 1e9
            if be.used + self.gb > be.cap:
                raise RuntimeError("CUDA out of memory. Tried to allocate (fake)")
            be.used += self.gb
            be.peak = max(be.peak, be.used)
            self.alive = True
            self.copy = meta["layer_bytes"] / 55e9

        def score(self, seqs, micro_tokens=32768, timing=None):
            out = [[-(1.0 + (t % 7) / 10.0) for t in ids[start:]] for ids, start in seqs]
            if timing is not None:
                n = self.n if self.mode != "resident" else 0
                timing.update({"wall_s": 0.001 * len(seqs), "copy_s_sum": n * self.copy,
                               "copy_s_mean": self.copy if n else 0.0, "n_copies": n})
            return out

        def release(self):
            if self.alive:
                self.be.used -= self.gb
                self.alive = False

    def scorer(self, mod, packed, gpu, mode, attn):
        return FakeBackend._Scorer(self, packed, gpu, mode, attn)

    def sync(self):
        pass

    def reset_peak(self):
        self.peak = self.used

    def peak_gb(self):
        return round(self.peak, 3)

    def free(self, sc):
        if sc is not None:
            sc.release()


class TorchBackend:
    def __init__(self, gpu):
        import torch
        self.torch, self.dev = torch, torch.device("cuda", gpu)

    def scorer(self, mod, packed, gpu, mode, attn):
        return mod.Scorer(packed, gpu, mode=mode, attn=attn)

    def sync(self):
        self.torch.cuda.synchronize(self.dev)

    def reset_peak(self):
        self.torch.cuda.reset_peak_memory_stats(self.dev)

    def peak_gb(self):
        # 本进程的峰值；同卡的学生引擎占用另由 gpu.csv（nvidia-smi）给出
        return round(self.torch.cuda.max_memory_allocated(self.dev) / 1e9, 3)

    def free(self, sc):
        del sc
        gc.collect()
        self.torch.cuda.empty_cache()
        self.sync()


def load_module(path):
    spec = importlib.util.spec_from_file_location("lm_scorer_cloud", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["lm_scorer_cloud"] = mod
    spec.loader.exec_module(mod)
    return mod


def read_seqs(path, limit):
    seqs = []
    with open(path, encoding="utf-8") as h:
        for line in h:
            if not line.strip():
                continue
            d = json.loads(line)
            ids = d.get("ids") or d.get("input_ids") or d.get("token_ids")
            start = d.get("start", d.get("prompt_len", 0))
            seqs.append((list(ids), int(start)))
            if limit and len(seqs) >= limit:
                break
    return seqs


def is_oom(e):
    return "out of memory" in str(e).lower()


# ---------------------------------------------------------------- 三个臂

def arm_R(be, mod, teachers, shares, gpu, attn, micro):
    rec = {"arm": "R", "status": "ok", "per_teacher": []}
    be.sync()
    be.reset_peak()
    t0 = time.monotonic()
    scs, outs, phase = [], [], "init"
    try:
        for k, p in enumerate(teachers):
            a = time.monotonic()
            scs.append(be.scorer(mod, p, gpu, "resident", attn))
            be.sync()
            rec["per_teacher"].append({"teacher": p, "init_s": round(time.monotonic() - a, 4)})
        phase = "score"
        for k, sc in enumerate(scs):
            a, tim = time.monotonic(), {}
            outs.append(sc.score(shares[k], micro_tokens=micro, timing=tim))
            be.sync()
            rec["per_teacher"][k].update({"score_s": round(time.monotonic() - a, 4),
                                          "tokens": sum(len(s[0]) - s[1] for s in shares[k]),
                                          "timing": tim})
    except Exception as e:  # noqa: BLE001
        rec.update({"status": "oom" if is_oom(e) else "error", "error": str(e)[:300], "failed_phase": phase,
                    "failed_at_teacher": len(scs) if phase == "init" else len(outs)})
        outs = None
    rec["wall_s"] = round(time.monotonic() - t0, 4)
    rec["peak_gb"] = be.peak_gb()
    for sc in scs:
        be.free(sc)
    return rec, outs


def arm_S(be, mod, teachers, shares, gpu, attn, micro):
    rec = {"arm": "S", "status": "ok", "per_teacher": []}
    be.sync()
    be.reset_peak()
    t0 = time.monotonic()
    outs = []
    for k, p in enumerate(teachers):
        r = {"teacher": p}
        sc = None
        try:
            a = time.monotonic()
            sc = be.scorer(mod, p, gpu, "resident", attn)
            be.sync()
            b = time.monotonic()
            tim = {}
            outs.append(sc.score(shares[k], micro_tokens=micro, timing=tim))
            be.sync()
            c = time.monotonic()
            r.update({"init_s": round(b - a, 4), "score_s": round(c - b, 4),
                      "tokens": sum(len(s[0]) - s[1] for s in shares[k]), "timing": tim})
        except Exception as e:  # noqa: BLE001
            r.update({"status": "oom" if is_oom(e) else "error", "error": str(e)[:300]})
            rec["status"] = r["status"]
            outs = None
        d = time.monotonic()
        be.free(sc)
        r["free_s"] = round(time.monotonic() - d, 4)
        rec["per_teacher"].append(r)
        if outs is None:
            break
    rec["wall_s"] = round(time.monotonic() - t0, 4)
    rec["peak_gb"] = be.peak_gb()
    return rec, outs


def arm_M(be, mod, teachers, shares, gpu, attn, micro):
    rec = {"arm": "M", "status": "ok", "per_teacher": []}
    be.sync()
    be.reset_peak()
    t0 = time.monotonic()
    scs, outs = [], []
    try:
        for p in teachers:
            a = time.monotonic()
            scs.append(be.scorer(mod, p, gpu, "stream", attn))
            be.sync()
            rec["per_teacher"].append({"teacher": p, "init_s": round(time.monotonic() - a, 4)})
        t_ready = time.monotonic()
        for k, sc in enumerate(scs):
            a, tim = time.monotonic(), {}
            outs.append(sc.score(shares[k], micro_tokens=micro, timing=tim))
            be.sync()
            rec["per_teacher"][k].update({"score_s": round(time.monotonic() - a, 4),
                                          "tokens": sum(len(s[0]) - s[1] for s in shares[k]),
                                          "timing": tim})
        rec["score_wall_s"] = round(time.monotonic() - t_ready, 4)
    except Exception as e:  # noqa: BLE001
        rec.update({"status": "oom" if is_oom(e) else "error", "error": str(e)[:300]})
        outs = None
    rec["wall_s"] = round(time.monotonic() - t0, 4)
    rec["peak_gb"] = be.peak_gb()
    for sc in scs:
        be.free(sc)
    return rec, outs


def maxdiff(a, b):
    if a is None or b is None:
        return None
    m = 0.0
    for xa, xb in zip(a, b):
        for sa, sb in zip(xa, xb):
            for p, q in zip(sa, sb):
                m = max(m, abs(float(p) - float(q)))
    return m


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--scorer", help="云端通过自测的 lm_scorer.py（一般是 $OPD_SCORER）")
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--seqs", required=True)
    ap.add_argument("--limit", type=int, default=240)
    ap.add_argument("--teachers", required=True, help="逗号分隔的打包目录，顺序即教师编号")
    ap.add_argument("--arms", default="R,S,M")
    ap.add_argument("--repeats", type=int, default=2)
    ap.add_argument("--micro-tokens", type=int, default=32768)
    ap.add_argument("--attn", default="sdpa")
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    teachers = [t.strip() for t in a.teachers.split(",") if t.strip()]
    arms = [x.strip().upper() for x in a.arms.split(",") if x.strip()]
    if any(x not in ("R", "S", "M") for x in arms):
        ap.error("--arms 只能是 R、S、M")
    seqs = read_seqs(a.seqs, a.limit)
    if not seqs:
        sys.exit("seqs 文件里没有序列")
    K = len(teachers)
    shares = [[s for i, s in enumerate(seqs) if i % K == k] for k in range(K)]
    if os.environ.get("OPD_POOL_FAKE") == "1":
        be, mod = FakeBackend(float(os.environ.get("OPD_POOL_FAKE_CAP", "80")),
                              float(os.environ.get("OPD_POOL_FAKE_USED", "30"))), None
    else:
        if not a.scorer:
            ap.error("需要 --scorer")
        be, mod = TorchBackend(a.gpu), load_module(a.scorer)
    fns = {"R": arm_R, "S": arm_S, "M": arm_M}
    reps = []
    for r in range(a.repeats):
        print(f"[pool_bench] step {r + 1}/{a.repeats} K={K}", flush=True)
        recs, outs = {}, {}
        for x in arms:
            recs[x], outs[x] = fns[x](be, mod, teachers, shares, a.gpu, a.attn, a.micro_tokens)
            print(f"[pool_bench]   {x}: {recs[x]['status']} wall={recs[x]['wall_s']}s peak={recs[x]['peak_gb']}GB", flush=True)
        reps.append({"rep": r, "arms": recs,
                     "maxdiff_M_vs_R": maxdiff(outs.get("M"), outs.get("R")),
                     "maxdiff_M_vs_S": maxdiff(outs.get("M"), outs.get("S"))})
        tmp = a.out + ".tmp"
        with open(tmp, "w", encoding="utf-8") as h:
            json.dump({"K": K, "teachers": teachers, "n_seqs": len(seqs),
                       "tokens_per_teacher": [sum(len(s[0]) - s[1] for s in sh) for sh in shares],
                       "gpu": a.gpu, "micro_tokens": a.micro_tokens, "scorer": a.scorer, "repeats": reps},
                      h, ensure_ascii=False, indent=1)
        os.replace(tmp, a.out)
    bad = [x for rep in reps for x in ("maxdiff_M_vs_R", "maxdiff_M_vs_S") if rep[x] not in (None, 0.0)]
    return 5 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
