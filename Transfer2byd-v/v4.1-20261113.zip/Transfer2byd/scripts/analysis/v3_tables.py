#!/usr/bin/env python3
"""Key numbers of the v3 return, computed the same way on the cloud and by the researcher (docs/20 §4).

Usage: python3 -I scripts/analysis/v3_tables.py <return dir with the 10 files> --out <dir>
       python3 -I scripts/analysis/v3_tables.py selftest
Standard library only (imports ../eval_metrics.py by path). Reads 03, 04, 05 and 08; writes
v3-key-numbers.json plus v3-phases.csv, v3-speedup.csv, v3-eval.csv. Every ratio is recomputed from
the per-step rows; the preset decision rules of the route cards are applied and reported, never tuned here.
"""
import csv, importlib.util, json, math, os, statistics as st, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("eval_metrics", os.path.join(HERE, "..", "eval_metrics.py"))
EM = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(EM)
csv.field_size_limit(1 << 30)


def f(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def mean(xs):
    xs = [x for x in xs if x is not None]
    return st.mean(xs) if xs else None


def rd(x, n=4):
    return None if x is None else round(x, n)


def read_csv(path):
    if not os.path.exists(path):
        return []
    return list(csv.DictReader(open(path, encoding="utf-8")))


def read_jsonl(path):
    if not os.path.exists(path):
        return []
    out = []
    for line in open(path, encoding="utf-8"):
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return out


def measured(rows):
    return [r for r in rows if r.get("warmup") == "0" and f(r.get("step_end_s")) is not None]


def phases_v31(steps):
    """V3-1: share of every verl phase and of the teacher in the step (denominator step_s)."""
    by = {}
    for r in steps:
        if r["task"] == "V3-1":
            by.setdefault(r["cfg"], []).append(r)
    out = []
    for cfg, rs in sorted(by.items()):
        ms = measured(rs)
        if not ms:
            continue
        step = mean([f(r["step_end_s"]) for r in ms])
        rec = {"cfg": cfg, "measured_steps": len(ms), "step_s": rd(step, 3)}
        tcols = sorted({k for r in ms for k in r if k.startswith("t_") and k != "t_step"})
        for k in tcols:
            v = mean([f(r.get(k)) for r in ms])
            rec[f"{k}_s"] = rd(v, 3)
            rec[f"{k}_frac"] = rd(v / step) if v is not None and step else None
        comp = mean([f(r.get("teacher_compute_union_s")) for r in ms])
        after = mean([f(r.get("teacher_after_gen_s")) for r in ms])
        wait = mean([f(r.get("teacher_wait_s")) for r in ms])
        rec["teacher_compute_frac"] = rd(comp / step) if comp is not None and step else None
        rec["teacher_exposed_frac"] = rd(((after or 0) + (wait or 0)) / step) if (after is not None or wait is not None) and step else None
        sums = [abs(sum(f(r.get(k)) or 0 for k in tcols) - (f(r.get("t_step")) or 0)) for r in ms if f(r.get("t_step")) is not None]
        rec["phase_sum_max_err_s"] = rd(max(sums), 3) if sums else None
        out.append(rec)
    return out


def judge_p1(phases):
    """Route card V3-1: C-PH revived if exposed >= 0.10 or compute >= 0.15 in any L config."""
    l = [p for p in phases if "-l-" in p["cfg"]]
    if not l:
        return {"verdict": "NA:no L config", "rule": "exposed>=0.10 or compute>=0.15 in any L cfg"}
    hit = [p["cfg"] for p in l if (p["teacher_exposed_frac"] or 0) >= 0.10 or (p["teacher_compute_frac"] or 0) >= 0.15]
    return {"verdict": "revived (doubtful)" if hit else "stays invalid", "configs": hit,
            "rule": "exposed>=0.10 or compute>=0.15 in any L cfg"}


def speedup(steps, configs, task="V3-2"):
    """Paired speed-up per seed: baseline mean step / mode-B mean step (cfg prefixes b- and m-)."""
    arms = {}
    for r in steps:
        if r["task"] != task:
            continue
        kind = "base" if r["cfg"].startswith("b-") else ("modeb" if r["cfg"].startswith("m-") else None)
        if kind:
            arms.setdefault((kind, r.get("seed")), []).append(r)
    rows = []
    for (kind, seed), rs in arms.items():
        ms = measured(rs)
        xs = sorted(f(r["step_end_s"]) for r in ms)
        q = lambda p: xs[min(len(xs) - 1, int(round(p * (len(xs) - 1))))] if xs else None
        rows.append({"arm": kind, "seed": seed, "cfg": rs[0]["cfg"], "measured_steps": len(ms),
                     "step_s": rd(mean(xs), 3), "step_s_median": rd(q(0.5), 3), "step_s_p25": rd(q(0.25), 3),
                     "step_s_p75": rd(q(0.75), 3),
                     "step_cv": rd(st.stdev(xs) / st.mean(xs)) if len(xs) > 1 else None,
                     "train_s": rd(mean([f(r["train_end_s"]) - f(r["train_start_s"]) for r in ms if f(r.get("train_end_s")) is not None and f(r.get("train_start_s")) is not None]), 3),
                     "peak_mem_gb_student": max([f(r.get("peak_mem_gb_student")) or 0 for r in rs] or [0]),
                     "teacher_wall_s": rd(mean([f(r.get("teacher_wall_s")) for r in ms]), 3),
                     "teacher_tok_s": rd(sum(f(r.get("teacher_tokens")) or 0 for r in ms) / sum(f(r.get("teacher_wall_s")) or 0 for r in ms), 1)
                     if sum(f(r.get("teacher_wall_s")) or 0 for r in ms) else None})
    pairs = []
    seeds = sorted({s for _, s in arms})
    for s in seeds:
        b = next((r for r in rows if r["arm"] == "base" and r["seed"] == s), None)
        m = next((r for r in rows if r["arm"] == "modeb" and r["seed"] == s), None)
        if b and m and b["step_s"] and m["step_s"]:
            pairs.append({"seed": s, "num_base_step_s": b["step_s"], "den_modeb_step_s": m["step_s"],
                          "paired_speedup": rd(b["step_s"] / m["step_s"]),
                          "paired_speedup_median": rd(b["step_s_median"] / m["step_s_median"]) if m["step_s_median"] else None,
                          "noisy": bool((b["step_cv"] or 0) > 0.05 or (m["step_cv"] or 0) > 0.05)})
    base_cfgs = [c for c in configs if c["task"] == task and c["cfg"].startswith("b-")]
    feasible = [c["cfg"] for c in base_cfgs if c.get("status") == "ok"]
    return rows, pairs, {"baseline_layouts_tried": len(base_cfgs), "baseline_layouts_ok": feasible}


def judge_fits(pairs, feas, rows):
    """Route card V3-2 (speed part; quality is judged with the eval table)."""
    m = [r for r in rows if r["arm"] == "modeb"]
    m_ok = bool(m) and all(r["measured_steps"] >= 8 and (r["peak_mem_gb_student"] or 0) <= 80 for r in m)
    if not feas["baseline_layouts_ok"]:
        return {"verdict": "valid (a): baseline infeasible" if m_ok else "NA: mode B incomplete", "basis": "03 status"}
    sp = [p["paired_speedup"] for p in pairs]
    if len(sp) < 2:
        return {"verdict": "NA: fewer than 2 seeds", "speedups": sp}
    if all(x >= 1.15 for x in sp):
        v = "valid (b)"
    elif all(x < 0.97 for x in sp):
        v = "invalid"
    else:
        v = "doubtful"
    return {"verdict": v, "speedups": sp, "rule": ">=1.15 both seeds valid; <0.97 both invalid; else doubtful"}


def eval_table(L):
    """Score every eval_per_problem record; pair base/mode-B at the same step, seed and benchmark."""
    recs = [d for d in L if d.get("kind") == "eval_per_problem"]
    table, by = [], {}
    for d in recs:
        x = d["data"]
        rows = [{"benchmark": x["benchmark"], **r} for r in x.get("rows", [])]
        sc = EM.score_rows(rows, [1, 8])[x["benchmark"]] if rows else {}
        avg = next((v for k, v in sc.items() if k.startswith("avg@")), None)
        table.append({"task": d.get("task"), "cfg": d.get("cfg"), "profile": x.get("profile"), "benchmark": x["benchmark"],
                      "step": x.get("step"), "seed": x.get("seed"), "problems": sc.get("problems"),
                      "samples": sc.get("samples_min"), "avg": avg, "pass@8": sc.get("pass@8"), "se_sampling": sc.get("se_sampling")})
        by[(d.get("cfg"), x["benchmark"], x.get("profile"), str(x.get("step")))] = rows
    cmp = []
    for (cfg, bench, prof, step), rows in by.items():
        if cfg and cfg.startswith("m-"):
            base_cfg = "b-" + cfg[2:]
            # the best baseline layout keeps the seed suffix: b-<layout>-s1 vs m-s1 also accepted
            cands = [k for k in by if k[0] and k[0].startswith("b-") and k[0].endswith(cfg[cfg.rfind("-"):]) and k[1:] == (bench, prof, step)]
            key = (base_cfg, bench, prof, step) if (base_cfg, bench, prof, step) in by else (cands[0] if cands else None)
            if key:
                c = EM.compare(by[key], rows, 5000, 0).get(bench)
                if c:
                    cmp.append({"base": key[0], "modeb": cfg, "benchmark": bench, "profile": prof, "step": step, **c})
    calib = [d["data"] for d in L if d.get("kind") == "calib"]
    return table, cmp, calib


def write_csv(path, rows):
    if not rows:
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def run(src, out):
    os.makedirs(out, exist_ok=True)
    configs = read_csv(os.path.join(src, "03-configs.csv"))
    steps = read_csv(os.path.join(src, "04-steps.csv"))
    L = read_jsonl(os.path.join(src, "08-script-outputs.jsonl"))
    ph = phases_v31(steps)
    rows, pairs, feas = speedup(steps, configs)
    table, cmp, calib = eval_table(L)
    key = {
        "schema": "v3-key-numbers/1",
        "V3-1": {"phases": ph, "P1": judge_p1(ph)},
        "V3-2": {"arms": rows, "pairs": pairs, "feasibility": feas, "fits_speed": judge_fits(pairs, feas, rows),
                 "quality_pairs": cmp},
        "V3-4": {"calib": calib, "C1": ("pass" if calib and all(c.get("pass") for c in calib) else ("fail" if calib else "NA"))},
        "eval": table,
    }
    write_csv(os.path.join(out, "v3-phases.csv"), ph)
    write_csv(os.path.join(out, "v3-speedup.csv"), rows + pairs)
    write_csv(os.path.join(out, "v3-eval.csv"), table)
    json.dump(key, open(os.path.join(out, "v3-key-numbers.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return key


def selftest():
    with tempfile.TemporaryDirectory() as td:
        hdr = ["task", "cfg", "seed", "step", "warmup", "gen_end_s", "train_start_s", "train_end_s", "step_end_s",
               "peak_mem_gb_student", "t_gen", "t_old_log_prob", "t_update_actor", "t_unaccounted", "t_step",
               "teacher_compute_union_s", "teacher_after_gen_s", "teacher_wait_s", "teacher_tokens", "teacher_wall_s"]
        rows = []
        for cfg, step_s, after in (("p-l-240", 100.0, 12.0), ("p-s-480", 100.0, 2.0)):
            for s in range(5):
                rows.append({"task": "V3-1", "cfg": cfg, "seed": "1", "step": str(s), "warmup": "1" if s < 2 else "0",
                             "step_end_s": step_s, "t_gen": 30, "t_old_log_prob": 10, "t_update_actor": 55, "t_unaccounted": 5,
                             "t_step": 100, "teacher_compute_union_s": 20, "teacher_after_gen_s": after, "teacher_wait_s": 0})
        for cfg, seed, st_s in (("b-2t6s-s1", "1", 120.0), ("m-s1", "1", 100.0), ("b-2t6s-s2", "2", 118.0), ("m-s2", "2", 100.0)):
            for s in range(10):
                rows.append({"task": "V3-2", "cfg": cfg, "seed": seed, "step": str(s), "warmup": "1" if s < 2 else "0",
                             "train_start_s": 80, "train_end_s": 95, "step_end_s": st_s, "peak_mem_gb_student": 50,
                             "teacher_tokens": 700000 if cfg.startswith("m") else "", "teacher_wall_s": 10 if cfg.startswith("m") else ""})
        with open(os.path.join(td, "04-steps.csv"), "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=hdr, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        with open(os.path.join(td, "03-configs.csv"), "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["task", "cfg", "status"])
            w.writeheader()
            w.writerows([{"task": "V3-2", "cfg": "b-2t6s-s1", "status": "ok"}, {"task": "V3-2", "cfg": "b-4t4s", "status": "oom"}])
        ev = []
        for cfg, k in (("b-2t6s-s1", 40), ("m-s1", 42)):
            ev.append({"task": "V3-2", "cfg": cfg, "kind": "eval_per_problem",
                       "data": {"profile": "eopd", "benchmark": "aime25", "step": 10, "seed": 1,
                                "rows": [{"problem_id": i, "n": 8, "c": 8 if i < k // 8 else 0} for i in range(30)]}})
        ev.append({"task": "V3-4", "cfg": "calib", "kind": "calib", "data": {"anchor": "qwen3-8b-nothink", "pass": True}})
        with open(os.path.join(td, "08-script-outputs.jsonl"), "w", encoding="utf-8") as fh:
            for e in ev:
                fh.write(json.dumps(e) + "\n")
        k = run(td, os.path.join(td, "out"))
        p = {x["cfg"]: x for x in k["V3-1"]["phases"]}
        assert p["p-l-240"]["teacher_exposed_frac"] == 0.12 and p["p-l-240"]["phase_sum_max_err_s"] == 0.0, p
        assert k["V3-1"]["P1"]["verdict"] == "revived (doubtful)" and k["V3-1"]["P1"]["configs"] == ["p-l-240"]
        sp = {x["seed"]: x["paired_speedup"] for x in k["V3-2"]["pairs"]}
        assert sp == {"1": 1.2, "2": 1.18}, sp
        assert k["V3-2"]["fits_speed"]["verdict"] == "valid (b)", k["V3-2"]["fits_speed"]
        m = next(r for r in k["V3-2"]["arms"] if r["cfg"] == "m-s1")
        assert m["teacher_tok_s"] == 70000.0, m
        assert k["V3-4"]["C1"] == "pass"
        q = k["V3-2"]["quality_pairs"]
        assert len(q) == 1 and q[0]["benchmark"] == "aime25", q
    print("selftest ok")
    return 0


def main():
    if len(sys.argv) >= 2 and sys.argv[1] == "selftest":
        return selftest()
    if len(sys.argv) < 4 or sys.argv[2] != "--out":
        print(__doc__)
        return 2
    k = run(sys.argv[1], sys.argv[3])
    print(json.dumps({"P1": k["V3-1"]["P1"], "fits_speed": k["V3-2"]["fits_speed"], "C1": k["V3-4"]["C1"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
