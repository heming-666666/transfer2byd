#!/usr/bin/env python3
"""Turn the 10 return files into copy-safe text files that survive copying by hand (docs/06 §5).

Usage: python3 scripts/make-copysafe.py $OPD_RUNTIME/Transfer2me --out $OPD_RUNTIME/Transfer2me-text
For every file NN-name in the input directory it writes NN-name.txt:
  @FNN BEGIN name=<file> lines=<n> bytes=<b> sha256=<hex> codec=cs1
  FNNL000001#<check>|<line 1>
  FNNL000002#<check>:1/3|<first 1000 characters of line 2>    (long lines are split into parts)
  ...
  @FNN END lines=<n>
Inside a line, characters that copying or a Markdown view can change are written as @@<hex>; (one character) or
@@<n>s; (n spaces): every character except letters, digits, CJK and the punctuation , . : ; = + - / ( ) % ' " ? ! { } [ ]
(and single spaces between words). The researcher's restore tool undoes this and checks every line; the
readable summary stays readable because Chinese text and plain words are not escaped.
The script decodes its own output again and stops if anything does not round-trip.
"""
import argparse
import hashlib
import re
import sys
from pathlib import Path

SAFE_PUNCT = set(",.:;=+-/()%'\"?!{}[]")
REC = re.compile(r"F(\d{2})L(\d{6})#([0-9a-f]{4})(?::(\d+)/(\d+))?\|")
ESC = re.compile(r"@@(\d+)s;|@@([0-9A-Fa-f]{1,6});")
WIDTH = 1000
NAMES = ["00-summary.md", "01-env.yaml", "02-code.md", "03-configs.csv", "04-steps.csv", "05-metrics.csv",
         "06-rollouts.csv", "07-timeline.csv", "08-script-outputs.jsonl", "09-logs.md"]


def crc16(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:4]


def safe_char(c):
    o = ord(c)
    return (c.isascii() and c.isalnum()) or c in SAFE_PUNCT or 0x4E00 <= o <= 0x9FFF or 0x3001 <= o <= 0x303F \
        or 0xFF01 <= o <= 0xFF5E


def encode(line):
    out, i, n = [], 0, len(line)
    while i < n:
        c = line[i]
        if c == " ":
            j = i
            while j < n and line[j] == " ":
                j += 1
            run = j - i
            # a single space between two non-space characters is safe; runs, leading and trailing spaces are not
            if run == 1 and 0 < i and j < n:
                out.append(" ")
            else:
                out.append(f"@@{run}s;")
            i = j
            continue
        out.append(c if safe_char(c) else f"@@{ord(c):X};")
        i += 1
    return "".join(out)


def decode(text):
    def sub(m):
        return " " * int(m.group(1)) if m.group(1) else chr(int(m.group(2), 16))
    return ESC.sub(sub, text)


def split_parts(enc):
    """Split an encoded line into pieces of at most WIDTH characters without cutting an escape."""
    parts, i = [], 0
    while i < len(enc) or not parts:
        j = min(len(enc), i + WIDTH)
        k = enc.rfind("@@", i, j)
        if k != -1 and j < len(enc) and enc.find(";", k) >= j:
            j = k if k > i else enc.find(";", k) + 1
        # never let a part start or end with a space: the restore tool strips spaces at record edges
        while i + 1 < j < len(enc) and (enc[j - 1] == " " or enc[j] == " "):
            j -= 1
        parts.append(enc[i:j])
        i = j
        if i >= len(enc):
            break
    return parts


def convert(src, fi):
    data = src.read_bytes()
    text = data.decode("utf-8")
    if text and not text.endswith("\n"):
        sys.exit(f"{src.name}: must end with a newline (add one, then rerun)")
    lines = text.split("\n")[:-1] if text else []
    out = [f"@F{fi:02d} BEGIN name={src.name} lines={len(lines)} bytes={len(data)} "
           f"sha256={hashlib.sha256(data).hexdigest()} codec=cs1"]
    for ln, line in enumerate(lines, 1):
        if "\r" in line:
            sys.exit(f"{src.name}:{ln}: carriage return in the file; write Unix line endings")
        parts = split_parts(encode(line))
        c = crc16(line)
        if len(parts) == 1:
            out.append(f"F{fi:02d}L{ln:06d}#{c}|{parts[0]}")
        else:
            for p, piece in enumerate(parts, 1):
                out.append(f"F{fi:02d}L{ln:06d}#{c}:{p}/{len(parts)}|{piece}")
    out.append(f"@F{fi:02d} END lines={len(lines)}")
    return "\n".join(out) + "\n", lines


def verify(txt, lines, fi):
    got = {}
    for m_line in txt.split("\n"):
        m = REC.match(m_line)
        if m:
            ln, part = int(m.group(2)), int(m.group(4) or 1)
            got.setdefault(ln, {})[part] = m_line[m.end():]
    for ln, line in enumerate(lines, 1):
        parts = got.get(ln, {})
        if decode("".join(parts[p] for p in sorted(parts))) != line:
            sys.exit(f"F{fi:02d} line {ln}: round trip failed; report this to the researcher")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    src, out = Path(a.src), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    total = 0
    for name in NAMES:
        p = src / name
        if not p.exists():
            sys.exit(f"missing {p}; write all 10 files first (docs/06)")
        fi = int(name[:2])
        txt, lines = convert(p, fi)
        verify(txt, lines, fi)
        (out / (name + ".txt")).write_text(txt, encoding="utf-8")
        total += len(txt)
        print(f"{name + '.txt':32s} {len(lines):>8} lines {len(txt):>11,} characters")
    print(f"total {total:,} characters in {out}; tell the researcher these numbers together with the return id")


if __name__ == "__main__":
    main()
