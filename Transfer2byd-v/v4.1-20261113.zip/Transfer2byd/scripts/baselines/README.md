# baselines：官方示例的原样副本（只作对照）

| 文件 | 来源（2026-11-09 取） | 许可证 |
|---|---|---|
| `verl_run_qwen3_8b_fsdp.upstream.sh` | https://github.com/verl-project/verl ，commit `a911bca25d6adb26f5bef2dc57e7ba62e99b7ade`，`examples/on_policy_distillation_trainer/run_qwen3_8b_fsdp.sh` | Apache-2.0 |
| `verl_test_distillation_topk_symmetry_on_cpu.upstream.py` | 同上，`tests/workers/test_distillation_topk_symmetry_on_cpu.py` | Apache-2.0 |
| `slime_run-qwen3-4B-opd.upstream.sh` | https://github.com/THUDM/slime ，commit `79aa41a884ab0bf65222c94418f6357d3c31192b`，`examples/on_policy_distillation/run-qwen3-4B-opd.sh` | Apache-2.0 |

**用法**：
- 优先跑**你机器上已装版本里的同名文件**，环境要和本版其他实验一致（docs/16）；
- 已装版本里没有这个文件时，才参考这里的副本改写，并在 02 写清差异；
- 副本带文件头注释，正文与上游逐字相同。

slime 的脚本最后几行会执行 `pkill -9 python`、`ray stop --force`，在共享机器上**必须删掉**（易错点 E8）。
