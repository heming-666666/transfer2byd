#!/usr/bin/env python3
"""mini_return: v4 小回传（V4-0 + 教师池探针 V4-P1–P5）的生成与检查。只用 Python 3.10 标准库。

    # 第 1 步：脚本生成数据文件（不手改）
    python3 -I scripts/mini_return.py build --results $OPD_RUNTIME/results/v4 --out $OPD_RUNTIME/Transfer2me/v4a
    #   写出 05-metrics.csv、08-script-outputs.jsonl、10-runs.csv、11-energy.csv、12-engine.csv，
    #   以及回传目录旁边的 v4a-00-auto.md（各探针的自动判定表，照抄进 00-summary.md 第 2、3 节，不要改数字）
    # 第 2 步：你写 00-summary.md、01-env.yaml、09-logs.md、13-cloud-code.md（模板见 docs/25）
    # 第 3 步：检查，通过后才打包
    python3 -I scripts/mini_return.py check --out $OPD_RUNTIME/Transfer2me/v4a
    python3 -I scripts/ret_md.py pack --in $OPD_RUNTIME/Transfer2me/v4a --out $OPD_RUNTIME/Transfer2me/v4a-md --ret-id p01v4a-YYYYMMDD-01

判定的阈值抄自 routes/V4-P-教师池探针.md；判定只是按规则算，最终由研究者看数据决定。
"""
from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import io
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TASKS = ["V4-0", "V4-P1", "V4-P2", "V4-P3", "V4-P4", "V4-P5"]
AUTO = ["05-metrics.csv", "08-script-outputs.jsonl", "10-runs.csv", "11-energy.csv", "12-engine.csv",
        "15-gpu-util.csv", "16-skill-issues.md"]          # v4.1：15 由 scripts/v41/util_report.py、16 由 skill 的 skill_feedback.py 生成
HAND = ["00-summary.md", "01-env.yaml", "09-logs.md", "13-cloud-code.md", "14-detours.md"]   # v4.1：14 弯路记录（docs/26 第 6 节）
M_COLS = ["task", "cfg", "key", "x_name", "x", "value", "unit", "n", "lo", "hi", "src", "note"]


def load(p):
    try:
        with open(p, encoding="utf-8") as h:
            return json.load(h)
    except (OSError, ValueError):
        return None


def sha(p):
    d = hashlib.sha256()
    with open(p, "rb") as h:
        for b in iter(lambda: h.read(1 << 20), b""):
            d.update(b)
    return d.hexdigest()


def runs_of(results, task):
    out = []
    for d in sorted(glob.glob(os.path.join(results, task, "*", "run.json"))):
        r = load(d)
        if r:
            r["_dir"] = os.path.dirname(d)
            out.append(r)
    return out


def g(x, n=4):
    return "" if x is None else (round(x, n) if isinstance(x, float) else x)


class Rows:
    def __init__(self):
        self.m, self.raw, self.verdicts = [], [], []

    def add(self, task, cfg, key, value, unit="", x_name="", x="", n="", src="", note=""):
        self.m.append([task, cfg, key, x_name, x, g(value), unit, n, "", "", src, note])

    def ratio(self, task, cfg, key, num, den, unit_num, src, x_name="", x="", note=""):
        self.add(task, cfg, key + "_num", num, unit_num, x_name, x, src=src)
        self.add(task, cfg, key + "_den", den, unit_num, x_name, x, src=src)
        v = (num / den) if (num is not None and den) else None
        self.add(task, cfg, key, v, "ratio", x_name, x, src=src, note=note)
        return v

    def rawfile(self, task, run, path, kind):
        d = load(path)
        if d is None:
            try:
                d = {"text": open(path, encoding="utf-8", errors="replace").read()[:20000]}
            except OSError:
                return
        self.raw.append({"task": task, "cfg": run.get("cfg_name"), "run_id": run.get("run_id"), "kind": kind,
                         "file": os.path.relpath(path, os.path.dirname(os.path.dirname(run["_dir"]))),
                         "sha256": sha(path), "data": d})

    def verdict(self, probe, result, basis):
        self.verdicts.append((probe, result, basis))


def band(v, hi, lo, labels=("有效", "存疑", "无效"), higher_better=True):
    if v is None:
        return "无数据"
    if higher_better:
        return labels[0] if v >= hi else (labels[1] if v >= lo else labels[2])
    return labels[0] if v < lo else (labels[1] if v < hi else labels[2])


# ---------------------------------------------------------------- 各探针

def p1(R, results):
    cells = {}
    for run in runs_of(results, "V4-P1"):
        pb = load(os.path.join(run["_dir"], "pool_bench.json"))
        cfg = run.get("cfg_name")
        if not pb:
            R.add("V4-P1", cfg, "status", run.get("status"), note="没有 pool_bench.json")
            continue
        R.rawfile("V4-P1", run, os.path.join(run["_dir"], "pool_bench.json"), "pool_bench")
        K, mem = pb["K"], run.get("cfg", {}).get("engine_mem", "?")
        last = pb["repeats"][-1]
        for arm, a in last["arms"].items():
            x = f"K={K},arm={arm},mem={mem}"
            R.add("V4-P1", cfg, "feasible", a["status"], x_name="K,arm,engine_mem", x=x, src="pool_bench.json")
            R.add("V4-P1", cfg, "arm_wall_s", a.get("wall_s"), "s", "K,arm,engine_mem", x, src="pool_bench.json")
            R.add("V4-P1", cfg, "peak_gb", a.get("peak_gb"), "GB", "K,arm,engine_mem", x, src="pool_bench.json",
                  note="本进程峰值；同卡学生引擎的占用见 11-energy 的 mem_peak")
            if arm == "M" and "score_wall_s" in a:
                R.add("V4-P1", cfg, "score_wall_s", a["score_wall_s"], "s", "K,arm,engine_mem", x, src="pool_bench.json")
        for k in ("maxdiff_M_vs_R", "maxdiff_M_vs_S"):
            R.add("V4-P1", cfg, k, last.get(k), "logprob", "K,engine_mem", f"K={K},mem={mem}", src="pool_bench.json")
        cells[(str(mem), K)] = last
    res, basis = "无数据", []
    if cells:
        valid = doubt = invalid = False
        for mem in sorted({m for m, _ in cells}):
            ks = sorted(k for m, k in cells if m == mem)
            base = cells[(mem, ks[0])]["arms"].get("M", {}).get("peak_gb")
            for K in ks:
                arms = cells[(mem, K)]["arms"]
                Rs, Ss, Ms = (arms.get(x, {}) for x in ("R", "S", "M"))
                if K >= 2 and Rs.get("status") == "oom" and Ms.get("status") == "ok" and base and \
                        Ms.get("peak_gb", 1e9) / base < 1.10:
                    valid = True
                    basis.append(f"mem={mem} K={K}：常驻放不下，教师池放得下，峰值是 K={ks[0]} 时的 {Ms['peak_gb'] / base:.2f} 倍")
                if Rs.get("status") == "ok" and Ss.get("status") == "ok" and Ms.get("score_wall_s"):
                    q = Ss["wall_s"] / Ms["score_wall_s"]
                    basis.append(f"mem={mem} K={K}：换入换出总时间 ÷ 教师池打分时间 = {q:.3f}")
                    if K == max(ks) and q < 1.05:
                        invalid = True
                    elif 1.05 <= q < 1.15:
                        doubt = True
        res = "有效" if valid else ("存疑" if doubt else ("无效" if invalid else "未定（看数据）"))
        bad = [r for r in R.m if r[0] == "V4-P1" and r[2].startswith("maxdiff") and r[5] not in ("", 0, 0.0)]
        if bad:
            res += "；分数不一致（实现错误，必须先查）"
    R.verdict("P1 三种放法", res, "；".join(basis) or "—")


def tok_s(path):
    d = load(path)
    if not d or not d.get("levels"):
        return None, None, None
    lv = d["levels"][0]
    return lv.get("tokens"), lv.get("wall_s"), lv


def p2(R, results):
    res, basis = "无数据", "—"
    for run in runs_of(results, "V4-P2"):
        cfg, vals = run.get("cfg_name"), {}
        for case in ("full-off", "tail-off", "full-on", "tail-on"):
            p = os.path.join(run["_dir"], f"gen-{case}.json")
            t, w, lv = tok_s(p)
            if lv is None:
                continue
            R.rawfile("V4-P2", run, p, "gen_bench")
            vals[case] = (t / w) if (t and w) else None
            R.ratio("V4-P2", cfg, "gen_tok_s", t, w, "tokens / s", f"gen-{case}.json", "case", case)
        if os.path.exists(os.path.join(run["_dir"], "score-loop.jsonl")):
            R.rawfile("V4-P2", run, os.path.join(run["_dir"], "score-loop.jsonl"), "score_loop")
        if "full-on" in vals and "full-off" in vals:
            rf = R.ratio("V4-P2", cfg, "interf_full", vals["full-on"], vals["full-off"], "tok/s", "gen-full-*.json",
                         note="打分开 ÷ 打分关（满载）")
            rt = R.ratio("V4-P2", cfg, "interf_tail", vals.get("tail-on"), vals.get("tail-off"), "tok/s",
                         "gen-tail-*.json", note="打分开 ÷ 打分关（尾部）")
            res = band(rf, 0.90, 0.75)
            keep = (rt is not None and rf is not None and rf < 1 and (1 - rt) <= 0.5 * (1 - rf))
            basis = f"满载 {rf:.3f}；尾部 {rt:.3f}" if rt is not None else f"满载 {rf:.3f}"
            basis += "；尾部发起组件：" + ("保留" if keep else "不保留或无法判断")
    R.verdict("P2 同卡干扰", res, basis)


def best_gbps(bench):
    rows = bench.get("rows") or []
    if not rows:
        return None
    best = max(rows[0]["repeats"], key=lambda r: r.get("tok_s", 0))
    xs = [p.get("copy_GBps_mean") for p in best.get("per_gpu", []) if p.get("copy_GBps_mean")]
    return sum(xs) / len(xs) if xs else None


def p3(R, results):
    per = {}
    for run in runs_of(results, "V4-P3"):
        for p in glob.glob(os.path.join(run["_dir"], "bench-bw-n*.json")):
            b = load(p)
            if not b:
                continue
            R.rawfile("V4-P3", run, p, "bench")
            n = len(b.get("gpus", []))
            v = best_gbps(b)
            per[n] = v
            R.add("V4-P3", run.get("cfg_name"), "copy_GBps_per_gpu", v, "GB/s", "n_gpus", n, src=os.path.basename(p))
            if b.get("rows"):
                R.add("V4-P3", run.get("cfg_name"), "best_tok_s", b["rows"][0].get("best_tok_s"), "tok/s", "n_gpus", n,
                      src=os.path.basename(p))
    res, basis = "无数据", "—"
    if 1 in per and 8 in per and per[1]:
        q = R.ratio("V4-P3", "p3", "bw_ratio_n8", per[8], per[1], "GB/s", "bench-bw-n*.json", note="8 卡每卡 ÷ 单卡")
        res, basis = band(q, 0.7, 0.4), f"8 卡时每卡带宽是单卡的 {q:.3f}"
    R.verdict("P3 主机带宽", res, basis)


def p4(R, results):
    res, basis = [], []
    for run in runs_of(results, "V4-P4"):
        cfg = run.get("cfg_name")
        tp = {}
        for mode in ("stream", "resident"):
            p = os.path.join(run["_dir"], f"bench-{mode}.json")
            b = load(p)
            if not b:
                continue
            R.rawfile("V4-P4", run, p, "bench")
            for row in b.get("rows", []):
                tp[(mode, row["tokens_per_gpu"])] = row.get("best_tok_s")
                R.add("V4-P4", cfg, "best_tok_s", row.get("best_tok_s"), "tok/s", "mode,tokens", f"{mode},{row['tokens_per_gpu']}",
                      src=os.path.basename(p))
        for T in sorted({t for _, t in tp}):
            if ("stream", T) in tp and ("resident", T) in tp:
                v = R.ratio("V4-P4", cfg, "stream_over_resident", tp[("stream", T)], tp[("resident", T)], "tok/s",
                            "bench-*.json", "tokens", T)
                if T == 8192:
                    res.append(f"{cfg}：8K 时 {v:.3f} → " + ("积压组件必要" if v < 0.7 else ("存疑" if v < 0.9 else "只有 MoE 教师需要积压")))
        p = os.path.join(run["_dir"], "real-shape.json")
        rs = load(p)
        if rs:
            R.rawfile("V4-P4", run, p, "real_shape")
            for rank, x in rs.items():
                R.add("V4-P4", cfg, "copies_per_layer", x.get("copies_per_layer"), "count", "rank", rank, src="real-shape.json",
                      note="应为 1")
                c = x.get("copies_per_layer")
                basis.append(f"{cfg}：真实序列每层拷贝 {c if c is None else round(c, 3)} 次")
    R.verdict("P4 持平点与真实形状", "；".join(res) or "无数据", "；".join(basis) or "—")


def p5(R, results):
    res, basis = "无数据", "—"
    for run in runs_of(results, "V4-P5"):
        p = os.path.join(run["_dir"], "gen_bench.json")
        d = load(p)
        if not d:
            continue
        R.rawfile("V4-P5", run, p, "gen_bench")
        cfg, by = run.get("cfg_name"), {}
        for lv in d.get("levels", []):
            by[lv.get("mode")] = lv
            R.ratio("V4-P5", cfg, "gen_tok_s", lv.get("tokens"), lv.get("wall_s"), "tokens / s", "gen_bench.json", "mode",
                    lv.get("mode"))
            R.add("V4-P5", cfg, "occupancy", lv.get("occupancy"), "ratio", "mode", lv.get("mode"), src="gen_bench.json")
        if "wave" in by and "refill" in by and by["wave"].get("tok_s"):
            q = R.ratio("V4-P5", cfg, "refill_over_wave", by["refill"]["tok_s"], by["wave"]["tok_s"], "tok/s", "gen_bench.json")
            res, basis = band(q, 1.30, 1.10), f"持续补位 ÷ 整批等待 = {q:.3f}"
    R.verdict("P5 生成尾部", res, basis)


def v40(R, results):
    for run in runs_of(results, "V4-0"):
        for f in glob.glob(os.path.join(run["_dir"], "*")):
            if os.path.basename(f) in ("energy-selfcheck.txt", "selftest.txt"):
                R.rawfile("V4-0", run, f, os.path.basename(f).split(".")[0])
    for name in ("energy-selfcheck.txt",):
        p = os.path.join(os.path.dirname(os.path.dirname(results)), "state", name)
        if os.path.exists(p):
            R.raw.append({"task": "V4-0", "cfg": "-", "run_id": "-", "kind": "energy_selfcheck", "file": "state/" + name,
                          "sha256": sha(p), "data": {"text": open(p, encoding="utf-8", errors="replace").read()[:20000]}})


# ---------------------------------------------------------------- 命令

def write_csv(path, header, rows):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as h:
        w = csv.writer(h, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)
    os.replace(tmp, path)


def cmd_build(a):
    os.makedirs(a.out, exist_ok=True)
    auto_path = a.out.rstrip("/") + "-00-auto.md"
    clash = [f for f in AUTO if os.path.exists(os.path.join(a.out, f))] + ([auto_path] if os.path.exists(auto_path) else [])
    if clash and not a.overwrite_auto:
        sys.exit(f"输出目录里已有 {clash}；重新生成请加 --overwrite-auto（只覆盖脚本生成的文件，不动你写的文件）")
    R = Rows()
    v40(R, a.results)
    for f in (p1, p2, p3, p4, p5):
        f(R, a.results)
    write_csv(os.path.join(a.out, "05-metrics.csv"), M_COLS, R.m)
    with open(os.path.join(a.out, "08-script-outputs.jsonl"), "w", encoding="utf-8") as h:
        for r in R.raw:
            h.write(json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n")
    r = subprocess.run([sys.executable, "-I", os.path.join(HERE, "ret_extra.py"), "--results", a.results, "--out", a.out,
                        "--tasks", ",".join(TASKS)], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("ret_extra.py 失败：" + r.stderr[-500:])
    eng = []
    header = None
    for run in runs_of(a.results, "V4-P5"):
        p = os.path.join(run["_dir"], "engine.csv")
        if not os.path.exists(p):
            continue
        with open(p, encoding="utf-8", newline="") as h:
            rd = list(csv.reader(h))
        if not rd:
            continue
        header = ["task", "cfg", "run_id"] + rd[0]
        eng += [["V4-P5", run.get("cfg_name"), run.get("run_id")] + row for row in rd[1:]]
    write_csv(os.path.join(a.out, "12-engine.csv"), header or ["task", "cfg", "run_id", "NA:no-engine-log"], eng)
    # v4.1：卡时账与 skill 问题（缺工具或缺状态时写 NA，不让 build 失败）
    td = a.td or os.environ.get("ORCH_TD", "")
    r = subprocess.run([sys.executable, "-I", os.path.join(HERE, "v41", "util_report.py"), "--td", td,
                        "--out", os.path.join(a.out, "15-gpu-util.csv")], capture_output=True, text=True) if td else None
    if not r or r.returncode != 0:
        write_csv(os.path.join(a.out, "15-gpu-util.csv"), ["section", "note"],
                  [["NA", "没有 orchd 的任务目录（--td 或 ORCH_TD）" if not td else "util_report 失败：" + r.stderr[-200:].replace("\n", " ")]])
    sk = a.skill_feedback or (os.path.join(os.path.dirname(os.environ["ORCH_BIN"]), "skill_feedback.py") if os.environ.get("ORCH_BIN") else "")
    r = subprocess.run([sys.executable, "-I", sk, "export", "--td", td, "--out", os.path.join(a.out, "16-skill-issues.md"),
                        "--pkg-version", "v4.1"], capture_output=True, text=True) if (sk and td and os.path.exists(sk)) else None
    if not r or r.returncode != 0:
        with open(os.path.join(a.out, "16-skill-issues.md"), "w", encoding="utf-8") as h:
            h.write("# 16 skill 本身遇到的问题\n\nNA：没找到 skill_feedback.py 或任务目录（--skill-feedback / --td）。主窗按 skill R29 手工导出后替换本文件。\n")
    st = {t: [(x.get("cfg_name"), x.get("status")) for x in runs_of(a.results, t)] for t in TASKS}
    lines = ["## 2 自动判定（由 scripts/mini_return.py 按 routes/V4-P 的阈值算出，照抄，不改数字）", "",
             "| 探针 | 判定 | 依据 |", "|---|---|---|"]
    lines += [f"| {p} | {v} | {b} |" for p, v, b in R.verdicts]
    lines += ["", "## 3 各任务的运行（来自 10-runs.csv）", "", "| 任务 | 运行（配置: 状态） |", "|---|---|"]
    lines += [f"| {t} | {'；'.join(f'{c}: {s}' for c, s in st[t]) or '没有运行'} |" for t in TASKS]
    with open(auto_path, "w", encoding="utf-8") as h:
        h.write("\n".join(lines) + "\n")
    print(f"OK build：05 {len(R.m)} 行，08 {len(R.raw)} 行，12 {len(eng)} 行；判定：" +
          "；".join(f"{p}={v}" for p, v, _ in R.verdicts))
    print(f"自动判定表：{auto_path}（在回传目录外面，不会被打包）")
    print("下一步：写 00-summary.md（把自动判定表的内容放进第 2、3 节）、01-env.yaml、09-logs.md、13-cloud-code.md、14-detours.md，再运行 check")
    return 0


USER_PATH = re.compile(r"/(?:home|data|mnt|nfs|export|users?)/(?!<user>)([A-Za-z0-9._-]+)/")
SAFE_FIRST = {"opd-runtime", "paper", "models", "datasets", "shm", "proctor", "tmp", "local", "share", "lib", "bin"}


def cmd_check(a):
    probs = []
    for f in AUTO + HAND:
        p = os.path.join(a.out, f)
        if not os.path.exists(p):
            probs.append(f"缺 {f}" + ("（先运行 build）" if f in AUTO else "（你要写的文件，模板见 docs/25）"))
        elif os.path.getsize(p) == 0:
            probs.append(f"{f} 是空的（没有内容也要写“无”）")
    extra = sorted(set(os.listdir(a.out)) - set(AUTO + HAND)) if os.path.isdir(a.out) else []
    if extra:
        probs.append(f"多余的文件（小回传只交这 12 个：{AUTO + HAND}）：{extra}")
    s0 = os.path.join(a.out, "00-summary.md")
    if os.path.exists(s0):
        t = open(s0, encoding="utf-8").read()
        first = t.split("\n", 2)
        if not re.match(r"^回传编号：p01v4a-\d{8}-\d{2}$", first[0].strip()):
            probs.append("00-summary.md 第一行要写成“回传编号：p01v4a-YYYYMMDD-NN”")
        if len(first) < 2 or not first[1].strip().startswith("包版本：v4"):
            probs.append("00-summary.md 第二行要写成“包版本：v4.1 2026-11-13（小回传）”")
        for sec in ("## 1 ", "## 2 ", "## 3 ", "## 4 ", "## 5 ", "## 6 ", "## 7 "):
            if sec not in t:
                probs.append(f"00-summary.md 缺小节“{sec.strip()}”（见 docs/25 的模板）")
        auto = a.out.rstrip("/") + "-00-auto.md"
        if os.path.exists(auto):
            for line in open(auto, encoding="utf-8"):
                if line.startswith("| P") and line.strip() not in t:
                    probs.append("00-summary.md 第 2 节没有照抄自动判定表的这一行：" + line.strip()[:80])
    for f in AUTO + HAND:
        p = os.path.join(a.out, f)
        if not os.path.exists(p):
            continue
        for i, line in enumerate(open(p, encoding="utf-8", errors="replace"), 1):
            for m in USER_PATH.finditer(line):
                if m.group(1) not in SAFE_FIRST:
                    probs.append(f"{f} 第 {i} 行可能含账户目录名（{m.group(0)}），请换成 <user>")
                    break
            if len([x for x in probs if x.startswith(f + " 第")]) > 3:
                break
    m5 = os.path.join(a.out, "05-metrics.csv")
    if os.path.exists(m5):
        with open(m5, encoding="utf-8", newline="") as h:
            hd = next(csv.reader(h), [])
        if hd != M_COLS:
            probs.append("05-metrics.csv 的表头被改动了（由脚本生成，不要手改）")
    if probs:
        print("检查不通过：")
        for p in probs:
            print("  - " + p)
        return 1
    print("OK check：12 个文件齐全。下一步：ret_md.py pack（docs/25 第 4 步）")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--results", required=True)
    b.add_argument("--out", required=True)
    b.add_argument("--overwrite-auto", action="store_true")
    b.add_argument("--td", default="", help="orchd 的任务目录（默认 $ORCH_TD），用于 15、16")
    b.add_argument("--skill-feedback", default="", help="skill 的 skill_feedback.py 路径（默认 $ORCH_BIN 同目录）")
    c = sub.add_parser("check")
    c.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    return cmd_build(a) if a.cmd == "build" else cmd_check(a)


if __name__ == "__main__":
    sys.exit(main())
