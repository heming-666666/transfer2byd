#!/usr/bin/env python3
"""Append structured progress events to a per-agent spool (stdlib only). Read by the dashboard (docs/15).

Usage:
  python3 scripts/opd_event.py emit --agent WORKER-A --event task_started --task R2-P1 [--run-id ID]
          [--attempt 1] [--config-id C] [--partition A] [--status running] [--summary "..."] [--evidence PATH ...]
  python3 scripts/opd_event.py tail [--agent WORKER-A] [-n 20]
Writes one JSON line to $OPD_RUNTIME/state/events/<agent>.jsonl (schema_version 1, UTC time, per-agent seq).
Never put secrets, full logs or absolute home paths in --summary; evidence paths are relative to $OPD_RUNTIME.
"""
import argparse
import datetime as dt
import fcntl
import json
import os
import re
import sys
import uuid
from pathlib import Path

TYPES = {
    "project_reconciled", "task_dispatched", "task_queued", "task_started", "task_heartbeat", "config_started",
    "config_measured", "config_failed", "task_partial", "task_reported_done", "audit_started", "audit_verified",
    "audit_rejected", "task_blocked", "task_resumed", "resource_reservation_created", "resource_conflict_detected",
    "resource_reservation_released", "problem_opened", "problem_resolved", "milestone_updated",
    "package_version_changed", "source_error", "env_changed", "version_drift_detected",
}
AGENT = re.compile(r"^[A-Z][A-Z0-9-]{1,31}$")


def runtime() -> Path:
    return Path(os.environ.get("OPD_RUNTIME", Path.home() / "opd-runtime"))


def emit(agent, event, **f):
    """Append one event; returns the event dict. Raises ValueError on a bad agent id or event type."""
    if not AGENT.match(agent):
        raise ValueError(f"agent id must look like WORKER-A: {agent!r}")
    if event not in TYPES:
        raise ValueError(f"unknown event type {event!r}; allowed: {', '.join(sorted(TYPES))}")
    d = runtime() / "state" / "events"
    d.mkdir(parents=True, exist_ok=True)
    with open(d / f"{agent}.seq", "a+") as lk:          # per-agent counter, guarded by an exclusive lock
        fcntl.flock(lk, fcntl.LOCK_EX)
        lk.seek(0)
        seq = int((lk.read().strip() or "0")) + 1
        lk.seek(0); lk.truncate(); lk.write(str(seq)); lk.flush()
        ev = {"schema_version": 1, "event_id": str(uuid.uuid4()), "event_type": event,
              "event_time_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
              "producer_id": agent, "producer_seq": seq, "is_demo": bool(f.pop("is_demo", False))}
        ev.update({k: v for k, v in f.items() if v not in (None, [], "")})
        with open(d / f"{agent}.jsonl", "a", encoding="utf-8") as out:
            out.write(json.dumps(ev, ensure_ascii=False) + "\n")
    return ev


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("emit")
    e.add_argument("--agent", required=True); e.add_argument("--event", required=True)
    for k in ("task", "run-id", "config-id", "partition", "status", "summary", "reason"):
        e.add_argument(f"--{k}")
    e.add_argument("--attempt", type=int); e.add_argument("--evidence", nargs="*", default=[])
    e.add_argument("--demo", action="store_true", help="mark as demo data (never shown as real progress)")
    t = sub.add_parser("tail")
    t.add_argument("--agent"); t.add_argument("-n", type=int, default=20)
    a = ap.parse_args()
    if a.cmd == "emit":
        try:
            ev = emit(a.agent, a.event, task_id=a.task, run_id=a.run_id, attempt_no=a.attempt, config_id=a.config_id,
                      partition=a.partition, status=a.status, summary=a.summary, reason=a.reason,
                      evidence_refs=a.evidence, is_demo=a.demo)
        except ValueError as err:
            print(f"error: {err}", file=sys.stderr); return 2
        print(json.dumps(ev, ensure_ascii=False)); return 0
    files = sorted((runtime() / "state" / "events").glob(f"{a.agent or '*'}.jsonl"))
    rows = [json.loads(l) for f in files for l in f.read_text(encoding="utf-8").splitlines() if l.strip()]
    for r in sorted(rows, key=lambda r: r["event_time_utc"])[-a.n:]:
        print(r["event_time_utc"], r["producer_id"], r["event_type"], r.get("task_id", "-"), r.get("summary", ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
