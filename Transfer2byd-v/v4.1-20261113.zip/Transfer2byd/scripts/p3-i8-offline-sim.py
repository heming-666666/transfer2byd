#!/usr/bin/env python3
"""P3: offline simulation of teacher-scoring policies from rollout timelines (H5-sim). Usage: routes/V2-C.
  synth : make synthetic timelines for a smoke test
  run   : simulate sync / complete / stream_all / tail_k / i8 / oracle, and with --noise the noisy-ranking
          policy at each level plus a random ranking (prediction-error injection, v2)"""
import argparse
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from p3_model import DEFAULTS, load_timeline  # noqa: E402
from p3_synth import synth  # noqa: E402
from p3_policies import simulate  # noqa: E402


def run(a):
    P = dict(DEFAULTS)
    if a.params:
        P.update(json.loads(Path(a.params).read_text()))
    per_step, agg = [], defaultdict(list)
    for s, rollouts in sorted(load_timeline(a.timeline).items()):
        res = {p: simulate(rollouts, p, P) for p in ["sync", "complete", "stream_all", "i8", "oracle"]}
        res.update({f"tail_k={k}": simulate(rollouts, "tail_k", P, k=k) for k in P["tail_k"]})
        for e in a.noise or []:
            res[f"noisy={e:g}"] = simulate(rollouts, "noisy", dict(P, noise=e), None)
        if a.noise:
            res["random"] = simulate(rollouts, "random", P)
        per_step.append({"step": s, "rollouts": len(rollouts), "results": res})
        for name, v in res.items():
            agg[name].append(v)
    mean = {n: round(sum(x["end_s"] for x in v) / len(v), 3) for n, v in agg.items()}
    after = {n: round(sum(x["after_gen_s"] for x in v) / len(v), 3) for n, v in agg.items()}
    feasible = {n: all(x["feasible"] for x in v) for n, v in agg.items()}
    tails = [n for n in mean if n.startswith("tail_k") and feasible[n]]
    best_tail = min(tails, key=lambda n: mean[n]) if tails else None
    ref = min([mean["complete"]] + ([mean[best_tail]] if best_tail else []))
    g = round(1 - mean["i8"] / ref, 4)
    summary = {"task": "R2-P3", "steps": len(per_step), "params": P, "mean_end_s": mean,
               "mean_after_generation_s": after, "feasible": feasible, "best_tail_k": best_tail,
               "i8_gain_vs_sync": round(1 - mean["i8"] / mean["sync"], 4),
               "i8_gain_vs_complete": round(1 - mean["i8"] / mean["complete"], 4),
               "i8_gain_vs_best_baseline": g, "h5_sim_pass": g >= 0.10,
               "oracle_gain_vs_best_baseline": round(1 - mean["oracle"] / ref, 4),
               "noisy_gain_vs_best_baseline": {n: round(1 - mean[n] / ref, 4) for n in mean
                                               if n.startswith("noisy") or n == "random"},
               "noisy_worse_than_complete": [n for n in mean if (n.startswith("noisy") or n == "random")
                                             and mean[n] > mean["complete"]]}
    p = Path(a.out); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"summary": summary, "per_step": per_step}, indent=1) + "\n")
    s2 = Path(str(p).replace(".json", ".summary.json"))
    s2.write_text(json.dumps(summary, indent=1) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "params"}, indent=1))
    print(f"full: {p}\nsummary for return: {s2}", file=sys.stderr)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--timeline", required=True); r.add_argument("--params"); r.add_argument("--out", required=True)
    r.add_argument("--noise", type=float, nargs="*", help="prediction-error levels, e.g. 0 0.25 0.5 (v2)")
    g = sub.add_parser("synth")
    g.add_argument("--out", required=True)
    for name, default in [("steps", 2), ("rollouts", 256), ("group-size", 8), ("prompt-len", 256),
                          ("median-len", 4000), ("max-len", 16384), ("checkpoint", 64), ("seed", 0)]:
        g.add_argument(f"--{name}", type=int, default=default)
    g.add_argument("--sigma", type=float, default=0.8)
    a = ap.parse_args()
    if a.cmd == "run":
        run(a)
    else:
        n = synth(a.out, a.steps, a.rollouts, a.group_size, a.prompt_len, a.median_len, a.sigma, a.max_len,
                  a.checkpoint, seed=a.seed)
        print(f"wrote {n} rows -> {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
