#!/usr/bin/env python3
"""PROCTOR mode-B teacher service: the scoring subset of SGLang's HTTP API, backed by the layer-major scorer.
Spec: routes/V2-D-模式B原型.md. Requires lm_scorer.py in the same directory.

  python3 lm_server.py --packed /dev/shm/proctor/qwen3-32b --gpus 0,1,2,3,4,5,6,7 --port 30200 \
      --expected 512 --idle-ms 3000 --model-path Qwen3-32B

Requests are held until --expected requests have arrived, or until no request has arrived for --idle-ms; then one
layer-major pass scores all of them on every GPU (data-parallel, tokens balanced) and every request is answered.
POST /generate   {"input_ids": [...] or [[...], ...], "return_logprob": true, "logprob_start_len": s,
                  "sampling_params": {"max_new_tokens": 0}}
                 -> SGLang-shaped reply: meta_info.input_token_logprobs = [[logprob, token_id, null], ...] from
                    position s (position 0 has logprob null, as in SGLang). top_logprobs_num > 0 is rejected (400).
GET  /get_model_info -> {"model_path": --model-path}; GET /health; POST /flush (score what is pending now);
POST /set_expected {"expected": n}; GET /stats (passes, tokens, timing of the last pass).
Check the reply shape against a real SGLang reply and slime's parser before use (route card, step D2).
"""
import argparse
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lm_scorer import Pool, shard  # noqa: E402


class Batcher:
    def __init__(self, pool, n_gpus, expected, idle_ms, micro):
        self.pool, self.n, self.expected, self.idle = pool, n_gpus, expected, idle_ms / 1000
        self.micro = micro
        self.lock = threading.Condition()
        self.pending = []            # [ids, start, event, slot]
        self.last_arrival = time.time()
        self.force = False
        self.stats = {"passes": 0, "requests": 0, "tokens": 0, "last": None}
        threading.Thread(target=self.loop, daemon=True).start()

    def submit(self, items):
        """items: list of (ids, start). Blocks until scored; returns list of logprob lists."""
        ev = threading.Event()
        slots = [None] * len(items)
        with self.lock:
            for k, (ids, start) in enumerate(items):
                self.pending.append([ids, start, ev, (slots, k)])
            self.last_arrival = time.time()
            self.lock.notify_all()
        ev.wait()
        return slots

    def loop(self):
        while True:
            with self.lock:
                while True:
                    n = len(self.pending)
                    due = n and (n >= self.expected or self.force or time.time() - self.last_arrival >= self.idle)
                    if due:
                        break
                    self.lock.wait(timeout=0.05)
                batch, self.pending, self.force = self.pending, [], False
            seqs = [(b[0], b[1]) for b in batch]
            parts, idx = shard(seqs, self.n)
            t0 = time.time()
            out = self.pool.run(parts, micro=self.micro, tag="serve")
            wall = time.time() - t0
            for r in range(self.n):
                for j, i in enumerate(idx[r]):
                    slots, k = batch[i][3]
                    slots[k] = out[r]["lps"][j]
            done = {id(b[2]): b[2] for b in batch}
            toks = sum(len(s[0]) for s in seqs)
            self.stats["passes"] += 1; self.stats["requests"] += len(batch); self.stats["tokens"] += toks
            self.stats["last"] = {"requests": len(batch), "tokens": toks, "wall_s": round(wall, 3),
                                  "tok_s": round(toks / wall, 1) if wall > 0 else None,
                                  "per_gpu": {r: out[r]["timing"] for r in out}}
            for ev in done.values():
                ev.set()


def make_handler(batcher, model_path):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def _send(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

        def do_GET(self):
            if self.path.startswith("/get_model_info"):
                return self._send(200, {"model_path": model_path, "is_generation": True, "proctor_mode": "B"})
            if self.path.startswith("/health"):
                return self._send(200, {"ok": True})
            if self.path.startswith("/stats"):
                return self._send(200, batcher.stats)
            return self._send(404, {"error": "not found"})

        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0))
            req = json.loads(self.rfile.read(n) or b"{}")
            if self.path.startswith("/flush"):
                with batcher.lock:
                    batcher.force = True
                    batcher.lock.notify_all()
                return self._send(200, {"ok": True})
            if self.path.startswith("/set_expected"):
                batcher.expected = int(req["expected"])
                return self._send(200, {"expected": batcher.expected})
            if not self.path.startswith("/generate"):
                return self._send(404, {"error": "not found"})
            if req.get("top_logprobs_num"):
                return self._send(400, {"error": "top_logprobs_num is not supported by the layer-major scorer"})
            sp = req.get("sampling_params") or {}
            if isinstance(sp, list):
                sp = sp[0] if sp else {}
            if sp.get("max_new_tokens", 0) not in (0, None):
                return self._send(400, {"error": "scoring only: max_new_tokens must be 0"})
            ids = req.get("input_ids")
            if ids is None:
                return self._send(400, {"error": "input_ids required (text input is not supported)"})
            single = bool(ids) and isinstance(ids[0], int)
            batch = [ids] if single else ids
            starts = req.get("logprob_start_len", -1)
            starts = [starts] * len(batch) if not isinstance(starts, list) else starts
            items = []
            for x, s in zip(batch, starts):
                s = len(x) - 1 if s is None or s < 0 else s
                items.append((list(x), max(1, s)))
            lps = batcher.submit(items)
            replies = []
            for (x, s0), lp, s in zip(items, lps, starts):
                s = len(x) - 1 if s is None or s < 0 else s
                entries = ([[None, x[0], None]] if s == 0 else []) + [[v, x[k], None] for k, v in zip(range(s0, len(x)), lp)]
                replies.append({"text": "", "output_ids": [],
                                "meta_info": {"prompt_tokens": len(x), "completion_tokens": 0,
                                              "finish_reason": {"type": "length", "length": 0},
                                              "input_token_logprobs": entries, "output_token_logprobs": []}})
            return self._send(200, replies[0] if single else replies)

    return H


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--packed", required=True)
    ap.add_argument("--gpus", required=True)
    ap.add_argument("--port", type=int, default=30200)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--expected", type=int, default=10 ** 9, help="requests per step (rollout batch x samples)")
    ap.add_argument("--idle-ms", type=int, default=3000)
    ap.add_argument("--micro-tokens", type=int, default=32768)
    ap.add_argument("--attn", default="sdpa")
    ap.add_argument("--private-pinned", action="store_true")
    ap.add_argument("--model-path", default="proctor-layer-major")
    a = ap.parse_args()
    gpus = [int(x) for x in a.gpus.split(",")]
    pool = Pool(a.packed, gpus, mode="stream", attn=a.attn, private_pinned=a.private_pinned)
    print(json.dumps({"workers": pool.info}), flush=True)
    batcher = Batcher(pool, len(gpus), a.expected, a.idle_ms, a.micro_tokens)
    srv = ThreadingHTTPServer((a.host, a.port), make_handler(batcher, a.model_path))
    print(f"listening on {a.host}:{a.port}", flush=True)
    try:
        srv.serve_forever()
    finally:
        pool.close()


if __name__ == "__main__":
    main()
