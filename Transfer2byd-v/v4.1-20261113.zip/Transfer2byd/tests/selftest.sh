#!/usr/bin/env bash
# v4.1 包自测：只写一个临时目录，不碰 GPU、tmux、凭证。用法：bash tests/selftest.sh
# 全部通过时最后一行是 "SELFTEST OK n/n"，退出码 0。
set -u
PKG="$(cd "$(dirname "$0")/.." && pwd)"
S="$PKG/scripts"
T="$(mktemp -d)"
PASS=0; FAIL=0
ok() { PASS=$((PASS+1)); echo "  ok   $1"; }
bad() { FAIL=$((FAIL+1)); echo "  FAIL $1"; }
chk() { if eval "$2" >/dev/null 2>&1; then ok "$1"; else bad "$1"; fi; }

echo "[1] 语法"
for f in opd_run gpu_sampler dash preflight snapshot gen_bench engine_scan swap_bench ret_extra ret_md pool_bench mini_return; do
  chk "py_compile $f.py" "python3 -I -m py_compile '$S/$f.py'"
done

echo "[2] 启动器（替身 nvidia-smi）"
mkdir -p "$T/bin" "$T/rt"
cat > "$T/bin/smi" <<'PY'
#!/usr/bin/env python3
import sys
q=[a for a in sys.argv if a.startswith('--query-gpu=')]
f=q[0].split('=')[1].split(',') if q else []
for i in range(4):
    v={'index':str(i),'uuid':'GPU-t%d'%i,'power.draw':'90.5','utilization.gpu':'0','memory.used':'10','memory.total':'81559','temperature.gpu':'40','power.limit':'400.00'}
    print(', '.join(v[x] for x in f))
PY
chmod +x "$T/bin/smi"
export OPD_NVIDIA_SMI="$T/bin/smi" OPD_NO_NVML=1 OPD_RUNTIME="$T/rt"
unset OPD_GPU_LEASE
python3 -I "$S/opd_run.py" --task V4-0 --cfg st-a --run-id st-a --role smoke --gpus 1 --steps-total 3 --pre-idle 0.6 --min-free-gb 0.1 \
  --gpu-roles 'student=0' -- bash -c 'for i in 1 2 3; do echo "step $i/3"; sleep 0.3; done' >"$T/a.out" 2>&1
chk "运行成功" "grep -q 'status=ok' '$T/a.out'"
R="$T/rt/results/v4/V4-0/st-a"
for f in run.json run.log gpu.csv progress.json step_marks.jsonl SHA256SUMS; do chk "产生 $f" "test -s '$R/$f'"; done
chk "步号识别到 3" "grep -q '\"steps_seen\": 3' '$R/run.json'"
chk "进度为 done" "grep -q '\"phase\": \"done\"' '$R/progress.json'"
chk "索引追加" "grep -q 'st-a' '$T/rt/results/v4/results-index.jsonl'"
python3 -I "$S/opd_run.py" --task V4-0 --cfg st-a --run-id st-a --gpus 1 --min-free-gb 0.1 -- true >"$T/b.out" 2>&1
chk "拒绝覆盖已有目录（退出码 94）" "test $? -eq 94"
OPD_GPU_LEASE=external CUDA_VISIBLE_DEVICES=2 python3 -I "$S/opd_run.py" --task V4-0 --cfg st-c --run-id st-c --gpus 2 --min-free-gb 0.1 -- true >"$T/c.out" 2>&1
chk "外部卡锁下卡不够时报错（退出码 91）" "test $? -eq 91"
OPD_GPU_LEASE=external CUDA_VISIBLE_DEVICES=2,3 python3 -I "$S/opd_run.py" --task V4-0 --cfg st-d --run-id st-d --gpus 2 --pre-idle 0 --min-free-gb 0.1 -- bash -c 'echo "CUDA out of memory"; exit 1' >"$T/d.out" 2>&1
chk "OOM 判定" "grep -q '\"status\": \"oom\"' '$T/rt/results/v4/V4-0/st-d/run.json'"
chk "外部卡锁记录" "grep -q '\"lease\": \"external\"' '$T/rt/results/v4/V4-0/st-d/run.json'"
( python3 -I "$S/opd_run.py" --task V4-0 --cfg par-a --run-id par-a --gpus 1 --pre-idle 0 --min-free-gb 0.1 -- bash -c 'echo a > $OPD_RUN_DIR/out.txt; sleep 0.5' >/dev/null 2>&1 &
  python3 -I "$S/opd_run.py" --task V4-0 --cfg par-b --run-id par-b --gpus 1 --pre-idle 0 --min-free-gb 0.1 -- bash -c 'echo b > $OPD_RUN_DIR/out.txt; sleep 0.5' >/dev/null 2>&1 & wait )
chk "并行两个运行互不覆盖" "test \"\$(cat '$T/rt/results/v4/V4-0/par-a/out.txt')\" = a -a \"\$(cat '$T/rt/results/v4/V4-0/par-b/out.txt')\" = b"
chk "并行两个运行分到不同的卡" "test \"\$(grep -A2 gpu_ids '$T/rt/results/v4/V4-0/par-a/run.json' | tr -d ' \n')\" != \"\$(grep -A2 gpu_ids '$T/rt/results/v4/V4-0/par-b/run.json' | tr -d ' \n')\""

echo "[3] 看板、预检、回传表"
chk "看板 once" "python3 -I '$S/dash.py' once | grep -q 'OPD 实验看板 v4.1'"
chk "预检通过" "python3 -I '$S/preflight.py' --task V4-0 --need-gpus 1 --need-free-gb 0.1 --need-module json"
chk "预检发现缺路径" "! python3 -I '$S/preflight.py' --task V4-0 --need-free-gb 0.1 --need-path /no/such/path"
mkdir -p "$T/ret"
chk "ret_extra 生成两张表" "python3 -I '$S/ret_extra.py' --results '$T/rt/results/v4' --out '$T/ret' && test -s '$T/ret/10-runs.csv' -a -s '$T/ret/11-energy.csv'"
chk "10-runs 含失败的运行" "grep -q ',oom,' '$T/ret/10-runs.csv'"
chk "11-energy 有空闲窗口" "grep -q ',pre_idle,' '$T/ret/11-energy.csv'"
printf '[2026-11-10 17:40:01] Decode batch. #running-req: 23, #token: 187232, token usage: 0.61, gen throughput (token/s): 5123.4, #queue-req: 217\n' > "$T/sg.log"
chk "engine_scan 认出样例行" "python3 -I '$S/engine_scan.py' --log '$T/sg.log' --out '$T/eng.csv' | grep -q 'running_mean=23.0'"
chk "engine_scan 无引擎行时退出码 3" "echo x > '$T/no.log'; python3 -I '$S/engine_scan.py' --log '$T/no.log' --out '$T/e2.csv'; test \$? -eq 3"

echo "[3b] 教师池探针（假打分器）"
mkdir -p "$T/pool"
for t in a:16:36 b:30:40 c:66:64; do n=${t%%:*}; r=${t#*:}; gb=${r%%:*}; L=${r#*:}; mkdir -p "$T/pool/$n"
  echo "{\"n_layers\": $L, \"host_gb\": $gb, \"layer_bytes\": $((gb * 1000000000 / L))}" > "$T/pool/$n/meta.json"; done
python3 -I -c "
import json,random
random.seed(0)
with open('$T/pool/seqs.jsonl','w') as h:
    for i in range(12): h.write(json.dumps({'ids':[random.randint(1,999) for _ in range(random.randint(50,300))],'start':20})+'\n')"
chk "pool_bench 两个教师三臂都放得下、分数一致" "OPD_POOL_FAKE=1 python3 -I '$S/pool_bench.py' --gpu 0 --seqs '$T/pool/seqs.jsonl' --teachers '$T/pool/a,$T/pool/b' --repeats 1 --out '$T/pool/o2.json' && python3 -I -c \"import json;r=json.load(open('$T/pool/o2.json'))['repeats'][0];assert all(v['status']=='ok' for v in r['arms'].values()) and r['maxdiff_M_vs_R']==0\""
chk "pool_bench 三个教师时常驻放不下、教师池放得下" "OPD_POOL_FAKE=1 python3 -I '$S/pool_bench.py' --gpu 0 --seqs '$T/pool/seqs.jsonl' --teachers '$T/pool/a,$T/pool/b,$T/pool/c' --repeats 1 --out '$T/pool/o3.json' && python3 -I -c \"import json;a=json.load(open('$T/pool/o3.json'))['repeats'][0]['arms'];assert a['R']['status']=='oom' and a['M']['status']=='ok'\""
for f in "$S"/probes/*.sh; do chk "bash -n $(basename "$f")" "bash -n '$f'"; done
chk "manifest 是 orch-manifest/2，任务与 tasks.yaml 一致" "python3 -I -c \"
import json,re
m=json.load(open('$PKG/state/manifest.json')); assert m['schema']=='orch-manifest/2'
ids={i['id'] for i in m['items'] if i['kind']!='role'}
y=set(re.findall(r'- \\{id: ((?:V4|M-)[0-9A-Za-z.-]*),', open('$PKG/state/tasks.yaml').read()))
assert ids==y, (ids^y)
assert {'DASH','AUDIT','RTRN','ENV','SNAP'} <= {i['id'] for i in m['items'] if i['kind']=='role'}\""
OPD_POOL_FAKE=1 OPD_GPU_LEASE=external CUDA_VISIBLE_DEVICES=1 python3 -I "$S/opd_run.py" --task V4-P1 --cfg p1-k2-m40 --run-id p1k2 --gpus 1 --pre-idle 0 --min-free-gb 0.1 --param engine_mem=0.40 -- \
  bash -c 'python3 -I '"$S"'/pool_bench.py --gpu 0 --seqs '"$T"'/pool/seqs.jsonl --teachers '"$T"'/pool/a,'"$T"'/pool/b --repeats 1 --out $OPD_RUN_DIR/pool_bench.json' >/dev/null 2>&1
chk "小回传 build 生成 5 个数据文件和判定表" "python3 -I '$S/mini_return.py' build --results '$T/rt/results/v4' --out '$T/v4a' && test -s '$T/v4a/05-metrics.csv' -a -s '$T/v4a-00-auto.md' && grep -q 'P1 三种放法' '$T/v4a-00-auto.md'"
chk "小回传 check 发现缺手写文件" "! python3 -I '$S/mini_return.py' check --out '$T/v4a'"
python3 -I -c "
a=open('$T/v4a-00-auto.md',encoding='utf-8').read()
open('$T/v4a/00-summary.md','w',encoding='utf-8').write('回传编号：p01v4a-20261113-01\n包版本：v4.1 2026-11-13（小回传）\n\n## 1 概况\n自测\n\n'+a+'\n## 4 失败\n无\n## 5 决定\n无\n## 6 观察\n无\n## 7 反馈\n无\n')
for f in ('01-env.yaml','09-logs.md','13-cloud-code.md','14-detours.md'): open('$T/v4a/'+f,'w').write('无\n')"
chk "小回传 check 通过" "python3 -I '$S/mini_return.py' check --out '$T/v4a'"
chk "小回传打包再还原逐字节相同" "python3 -I '$S/ret_md.py' pack --in '$T/v4a' --out '$T/v4a-md' --ret-id p01v4a-20261113-01 >/dev/null && cat '$T'/v4a-md/*.md > '$T/v4a.txt' && python3 -I '$S/ret_md.py' unpack '$T/v4a.txt' --out '$T/v4a-un' >/dev/null && for f in '$T'/v4a/*; do cmp -s \"\$f\" '$T/v4a-un/'\$(basename \"\$f\") || exit 1; done"
chk "看板读到研究进展（论文完成度）" "python3 -I '$S/dash.py' once | grep -q '论文完成度'"

echo "[4] 回传容器"
printf '# 标题\n\n```diff\n-a\n+b\n```\n行尾空格  \n\ttab\n“弯引号”\n' > "$T/ret/02-code.md"
python3 -I -c "open('$T/ret/08-x.jsonl','w').write('{\"k\":\"'+'y'*70000+'\"}\n')"
chk "pack（含回读核对）" "python3 -I '$S/ret_md.py' pack --in '$T/ret' --out '$T/md' --ret-id st-20261112-01"
chk "每块不超过 30000 字" "python3 -I -c \"
import re,glob
m=max(len(b) for f in glob.glob('$T/md/*.md') for b in re.findall(r'\x60\x60\x60\x60text\n(.*?)\n\x60\x60\x60\x60',open(f,encoding='utf-8').read(),flags=re.S))
assert m<=30000\""
cat "$T"/md/*.md | grep -v '^README' > "$T/all.txt"
chk "unpack 还原" "python3 -I '$S/ret_md.py' unpack '$T/all.txt' --out '$T/un'"
chk "还原逐字节相同" "for f in '$T'/ret/*; do cmp -s \"\$f\" '$T/un/'\$(basename \"\$f\") || exit 1; done"
python3 -I -c "
t=open('$T/all.txt',encoding='utf-8').read(); i=t.index('yyyyyyyy')+100; open('$T/bad.txt','w',encoding='utf-8').write(t[:i]+'Z'+t[i+1:])"
chk "改一个字被发现（退出码 1）" "python3 -I '$S/ret_md.py' unpack '$T/bad.txt' --out '$T/un2'; test \$? -eq 1"


echo "[6] v4.1：orchd 接口、门 BW、卡时账、端口段"
for f in "$S"/v41/*.py "$S"/pkg/*.py; do chk "py_compile $(basename "$(dirname "$f")")/$(basename "$f")" "python3 -I -m py_compile '$f'"; done
for f in "$S"/v41/env.sh "$S"/pkg/orch_env.sh "$S"/v41/tasks/*.sh; do chk "bash -n v41/$(basename "$f")" "bash -n '$f'"; done
mkdir -p "$T/pk/state" && cp "$PKG/state/research-status.json" "$T/pk/state/" 2>/dev/null
chk "manifest、tasks.yaml、parallel-plan 与生成器一致" "python3 -I '$S/v41/make_manifest.py' --pkg '$T/pk' >/dev/null && cmp -s '$T/pk/state/manifest.json' '$PKG/state/manifest.json' && cmp -s '$T/pk/state/tasks.yaml' '$PKG/state/tasks.yaml' && cmp -s '$T/pk/state/parallel-plan.json' '$PKG/state/parallel-plan.json'"
chk "manifest 里的 id 唯一、依赖都存在" "python3 -I -c \"
import json
m=json.load(open('$PKG/state/manifest.json')); ids=[i['id'] for i in m['items']]
assert len(ids)==len(set(ids)); s=set(ids)
assert all(x in s for i in m['items'] for d in i.get('deps',[])+i.get('after',[]) for x in d.split('|'))
assert m['schema']=='orch-manifest/2'\""
mkbw() {  # mkbw <目录> <8 卡比例>
  for N in 1 8; do d="$1/results/v4/V4-P3/p3-n$N-x"; mkdir -p "$d"; echo "{\"status\":\"ok\",\"cfg_name\":\"p3-n$N\"}" > "$d/run.json"
    python3 -I -c "import json;N=$N;bw=55.0*(1 if N==1 else $2);json.dump({'gpus':list(range(N)),'rows':[{'repeats':[{'tok_s':1,'per_gpu':[{'copy_GBps_mean':bw}]*N}]}]},open('$d/bench-bw-n$N.json','w'))"; done; }
mkbw "$T/bw1" 0.95; mkbw "$T/bw2" 0.60; mkdir -p "$T/bw3"
chk "门 BW：8 卡 0.95 → pass" "python3 -I '$S/v41/gate_bw.py' --runtime '$T/bw1' | grep -q '\"verdict\": \"pass\"'"
chk "门 BW：8 卡 0.60 → fail" "python3 -I '$S/v41/gate_bw.py' --runtime '$T/bw2' | grep -q '\"verdict\": \"fail\"'"
chk "门 BW：没有 P3 数据 → 保守 fail（不阻塞后续）" "python3 -I '$S/v41/gate_bw.py' --runtime '$T/bw3' | grep -q '\"verdict\": \"fail\"'"
mkdir -p "$T/td/notes/sched"
python3 -I -c "
import json,time
t=time.time()
json.dump({'acct':{'used_s':7200,'alloc_idle_s':600,'idle_reserved_s':900},'heartbeat':t,'tasks':{'V4-P3':{'status':'running','gpus':['0','1'],'verdict':'ok'}},
 'snapshot':{'gpus':[{'idx':'0','used':20000,'util':60,'lease':'V4-P3','lock':'','procs':[[1,'V4-P3',20000]],'idle_why':''}]},'alerts':{}},open('$T/td/notes/sched/state.json','w'))
open('$T/td/notes/sched/gpu.jsonl','w').write(''.join(json.dumps({'t':t+i*3,'u':[60,0],'m':[1,1],'l':['V4-P3','']})+'\n' for i in range(5)))"
chk "卡时账 15-gpu-util.csv" "python3 -I '$S/v41/util_report.py' --td '$T/td' --out '$T/u.csv' && grep -q '真在用' '$T/u.csv' && grep -q 'V4-P3' '$T/u.csv'"
chk "看板读 orchd 的状态（任务、卡时账）" "python3 -I '$S/dash.py' collect --once --td '$T/td' && python3 -I -c \"
import json; s=json.load(open('$T/rt/dashboard/state.json')); assert s['orch']['tasks'][0]['id']=='V4-P3'; assert s['paper']['percent'] is not None\""
mkdir -p "$T/rt/state" && printf 'OPD_PY=python3\n' > "$T/rt/state/probe-env.sh"
chk "env.sh：端口段与 cell_done" "bash -c 'export PKG=$PKG OPD_RUNTIME=$T/rt ORCH_PORT_BASE=21400; . $S/v41/env.sh; [ \$(port 20) = 21420 ] && [ \$OPD_PORT = 21420 ] && ! cell_done V4-P3 p3-n1'"
chk "own_procs.py 没有运行号时不停任何进程" "python3 -I '$S/pkg/own_procs.py' --run ''; test \$? -eq 2"

echo "[7] v4.1：与 skill 2.0.0 的约定（启动确认、环境任务、P2 的并行与保护）"
ORCH_STARTED="$T/orch/.started" ORCH_PROGRESS="$T/orch/progress.json" bash -c "mkdir -p '$T/orch' && python3 -I '$S/opd_run.py' --task V4-0 --cfg st-orch --run-id st-orch --gpus 1 --steps-total 2 --pre-idle 0 --min-free-gb 0.1 -- bash -c 'sleep 0.3; echo step 1/2; sleep 0.3; echo step 2/2'" >/dev/null 2>&1
chk "opd_run：认出第一步时写 \$ORCH_STARTED（orchd 的启动确认）" "test -s '$T/orch/.started'"
chk "opd_run：进度同时写 \$ORCH_PROGRESS" "grep -q '\"steps_total\": 2' '$T/orch/progress.json'"
mkdir -p "$T/envchk/state" "$T/fakemods/torch" "$T/fakemods/sglang"
echo "__version__ = '0.0-fake'" > "$T/fakemods/torch/__init__.py"; echo "__version__ = '0.0-fake'" > "$T/fakemods/sglang/__init__.py"
printf '#!/usr/bin/env bash\nPYTHONPATH=%s exec python3 "$@"\n' "$T/fakemods" > "$T/fakepy"; chmod +x "$T/fakepy"
chk "env_ok：没有 probe-env.sh → 退 1（开环境窗）" "! python3 -I '$S/pkg/env_ok.py' --runtime '$T/envchk'"
printf 'OPD_PY=%s\nSGLANG_PY=%s\nOPD_SCORER=x\nOPD_STUDENT=x\nOPD_PACKED=x\nOPD_SEQS=x\nOPD_PROMPTS=x\n' "$T/fakepy" "$T/fakepy" > "$T/envchk/state/probe-env.sh"
chk "env_ok：解释器能导入 torch、sglang、没有基线 → 退 0（V41-ENV 直接完成）" "python3 -I '$S/pkg/env_ok.py' --runtime '$T/envchk'"
mkdir -p "$T/envchk/state/versions"
printf '{"env":"sglang","python_path":"%s","all_packages":{"sglang-not-installed":"9.9"}}' "$T/fakepy" > "$T/envchk/state/versions/sglang.json"
chk "env_ok：与 v4 的版本基线不一致（漂移）→ 退 1" "! python3 -I '$S/pkg/env_ok.py' --runtime '$T/envchk'"
mkdir -p "$T/sl"
chk "P2 打分保护：打分器连续 3 次失败 → 循环停下并留标记（不空转、不交假的“打分开”）" "bash -c 'RUN=$T/sl OPD_PY=false OPD_SCORER=x OPD_PACKED=x TEA=x OPD_SEQS=x SCORE_RETRY_SLEEP=0; . $S/probes/score_loop.sh; score_loop; test \$? -eq 1 && test -s $T/sl/score-loop.failed && ! score_ok 999999 测试'"
mkdir -p "$T/fakeorch" "$T/p2rt/state"
printf 'import json, sys\nprint(json.dumps(sys.argv[1:]))\n' > "$T/fakeorch/cellrun.py"
printf 'OPD_PY=python3\n' > "$T/p2rt/state/probe-env.sh"; printf 'P2_CBEST=128\n' > "$T/p2rt/state/v41-env.sh"
chk "P2：有 P2_CBEST 时两格交给 cellrun（每格 1 卡、已完成的格跳过）" "PKG='$PKG' OPD_RUNTIME='$T/p2rt' ORCH_BIN='$T/fakeorch/orchd.py' bash '$S/v41/tasks/p2.sh' | grep -q 'p2-cbest.*128' "
chk "manifest：所有 GPU 任务都依赖环境任务 V41-ENV；V41-ENV 有 skip_if_cmd" "python3 -I -c \"
import json
m=json.load(open('$PKG/state/manifest.json')); it={i['id']:i for i in m['items']}
assert it['V41-ENV'].get('skip_if_cmd')
assert all('V41-ENV' in i.get('deps',[]) for i in m['items'] if i['kind'].startswith('gpu'))
assert m['run_env']['OPD_GPU_LEASE']=='external' and m['brief']['rules']\""
chk "manifest：不写预计时长（gpu_options 的值只作偏好）；可选任务有 drop 预案" "python3 -I -c \"
import json
m=json.load(open('$PKG/state/manifest.json')); it={i['id']:i for i in m['items']}
assert not any('est_h' in i for i in m['items'])
assert it['V4-L']['if_fail']['action']=='drop' and it['V4-T']['if_fail']['action']=='drop'
assert it['V4-P2']['gpu_options']=={'2': None, '1': None}\""

SK="$PKG/skill/skill-upgrade-2.0.0/files/.claude/skills/multi-agent-orchestrator/scripts"
chk "优先级由依赖算出（用随包的 orchd）：探针 > 正确性门 Q0 > 最强基线 G2 > 其余；没有给探针手填加成" "python3 -I -B -c \"
import importlib.util, json
spec = importlib.util.spec_from_file_location('orchd', '$SK/orchd.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
man = json.load(open('$PKG/state/manifest.json', encoding='utf-8'))
items = {i['id']: m.norm_item(i, {}) for i in man['items'] if i['kind'] != 'role'}
tasks = {k: {'status': 'wait'} for k in items}
for k in ('V4-0','V4-P1','V4-NT','V4-G1','V4-E','V4-R','V41-ENV'): tasks[k]['status'] = 'done'
p = m.priorities(items, tasks)
probes = ['V4-P3','V4-P2','V4-P4a','V4-P4b','V4-P5']
rest = [k for k, it in items.items() if it['kind'].startswith('gpu') and k not in probes and not k.startswith(tuple(x + 's' for x in probes))]
assert min(p[k] for k in probes) > max(p[k] for k in rest), (p)
assert p['V41-Q0'] > p['V4-G2'] > max(p['V4-F8'], p['V4-Ft'], p['V4-L'], p['V4-T'])
assert p['V4-Q'] > p['V4-L'] and not any(items[k].get('prio_boost') for k in probes)
assert items['M-GATEP']['waiting_human'] and 'V41-Q0' in items['V4-G2']['after']
\""
chk "里程碑都有依赖、都不占卡；环境任务用 T 档、判断窗用 M 档（选档表）" "python3 -I -c \"
import json
m = json.load(open('$PKG/state/manifest.json', encoding='utf-8')); it = {i['id']: i for i in m['items']}
ms = [i for i in m['items'] if i['kind'] == 'milestone']
assert len(ms) == 5 and all(i.get('deps') and not i.get('gpu_options') and not i.get('cmd') for i in ms)
assert it['V41-ENV']['tier'] == 'T' and m['sched_defaults']['tier_by_kind']['judge'] == 'M'
\""

echo "SELFTEST $([ $FAIL -eq 0 ] && echo OK || echo FAILED) $PASS/$((PASS+FAIL))"
[ $FAIL -eq 0 ]
