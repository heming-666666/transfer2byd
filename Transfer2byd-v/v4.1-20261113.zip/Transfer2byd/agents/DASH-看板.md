# DASH（看板）——v4.1

只负责把看板起起来、保持在跑，不碰实验。

```bash
export OPD_RUNTIME=<运行根>
python3 -I $PKG/scripts/dash.py collect --td $TD &         # 每 5 秒采一次 orchd 状态、运行进度、研究进展
python3 -I $PKG/scripts/dash.py serve --port 30390 &       # 页面；远程看用 ssh -L 30390:127.0.0.1:30390
```

验收证据（交给主窗，写进回传 01 的 `dashboard_latency`）：`docs/15` 第 4 节的四条。采集进程退了就重起（不要改脚本）；页面显示有问题，截图写进报告并用 `skill_feedback.py add --kind gap --where 看板 ...` 或回传的“对传输包的反馈”记下。
