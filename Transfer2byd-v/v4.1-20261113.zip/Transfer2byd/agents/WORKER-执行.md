# WORKER（执行 = 子窗）——v4.1

你承接一个任务（或一个修复、一次验收、一次判断）。照 orchd 自动生成的任务书做（云端 skill 的 `brief.py`：执行、修复、验收、判断四种，固定几节：共同规则 → 本包的规定 → 你的任务的原始来源 → 环境 → 交接）。

## 每个任务都一样的做法（`routes/V41-总览与门控.md` 第 7 节）

1. 先读上下文卡 `notes/ctx/<窗名>.md`（换过窗的话前一扇窗做到哪里写在里面），再读路线卡。
2. `. $PKG/scripts/v41/env.sh`（端口段、ray 起停、只停自己的进程）。
3. GPU 命令一律 `python3 -I $ORCH_BIN exec --td $ORCH_TD <任务> -- <命令>`；每个实验经 `scripts/opd_run.py` 启动（`--gpus N` 用租约里的前 N 张；它认出第一步时 touch `$ORCH_STARTED`，orchd 据此确认实验真开始）。一组独立的格用 skill 的 `cellrun.py` 按租到的卡并行跑（`routes/V41` 第 7 节）。
4. 每完成一步在上下文卡末尾追加一行：时间｜做了什么｜结果文件｜下一步。
5. 写 `results/v4/<任务>/00-summary.md`（判据、上界、结果、证据路径），交结构化报告（skill 的 `templates/WORKER_REPORT.md`），写 `report` 事实。报告里必须有“给后来者的经验”（弯路，`docs/26` 第 6 节的格式；没有写“无”）。
6. skill 本身的问题用 `skill_feedback.py add`（R29）。

## 不做的事

不手设 `CUDA_VISIBLE_DEVICES`；不写死端口；不用 `ray stop`、`pkill`；不碰不是自己启动的进程；不改包里的脚本；冻结的运行脚本只改路线卡点名的参数与 CLI 语法、环境变量（写进 02）；不问人（遇决策选推荐项继续；确实要研究者拍板的一件事用 `orchd.py ask`，先做不依赖它的部分）。
