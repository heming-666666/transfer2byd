# 日志格式（OPD 实验的计时日志）

R1 的计时改造要输出下面两个 CSV。P3 离线仿真器和 R1 的分析都按这个格式读，列名不要改；多出来的列可以保留。时间一律用秒，从该步生成开始的时刻算起；绝对时间另外写在 `step_start_unix` 列。

## 1. 每步阶段耗时：`step_breakdown.csv`

| 列 | 含义 |
|---|---|
| `config_id` | 配置编号（网格实验用），单次实验写 `default` |
| `step` | 训练步 |
| `step_start_unix` | 该步开始的 Unix 时间 |
| `gen_start_s`、`gen_end_s` | 学生 rollout 生成的开始、结束（最后一条完成） |
| `score_start_s`、`score_end_s` | 教师打分的第一次请求开始、最后一次完成 |
| `train_start_s`、`train_end_s` | 学生训练（前向、反向、优化器）的开始、结束 |
| `sync_start_s`、`sync_end_s` | 权重同步到 rollout 引擎的开始、结束 |
| `step_end_s` | 该步结束 |
| `n_rollouts`、`n_prompts` | 本步的 rollout 数与提示数 |
| `tokens_generated` | 本步学生生成的 token 总数 |
| `tokens_scored` | 本步教师打分的 token 总数（含重算） |
| `max_len`、`p50_len`、`p90_len`、`n_truncated` | 回答长度统计，`n_truncated` 是达到长度上限的条数 |
| `teacher_busy_s` | 教师 GPU 忙碌的总时间（能拿到就填） |
| `peak_mem_gb_student`、`peak_mem_gb_teacher` | 显存峰值 |

## 2. 逐条 rollout 的生成进度：`rollout_timeline.csv`

| 列 | 含义 |
|---|---|
| `step` | 训练步 |
| `rollout_id` | 本步内唯一 |
| `group_id` | 同一提示的多条回答用同一个组号 |
| `prompt_len` | 提示 token 数 |
| `n_tokens` | 已生成的 token 数（检查点） |
| `t_s` | 达到 `n_tokens` 时的时间（秒，从该步生成开始算） |

每条 rollout 每生成 64 个 token 记一行（可以用 128），完成时再记一行，`n_tokens` 等于最终长度。512 条 × 16k 的一步大约 13 万行，可以接受。

没有真实日志时，可以用 `python3 scripts/p3-i8-offline-sim.py synth --out /tmp/synth.csv` 生成一份合成数据，先测试 P3。

## 3. 网格汇总：`grid.csv`（R1-E1）

每个配置一行：`config_id, student, teacher, teacher_precision, placement, teacher_gpus, student_gpus, max_response_len, group_size, prompts_per_step, steps_measured, mean_step_s, mean_gen_s, mean_score_after_gen_s, mean_train_s, mean_sync_s, tokens_per_s_student, tokens_per_s_teacher, peak_mem_gb, oom, notes`

## 4. v2 新增（V2-F）

`step_breakdown.csv` 末尾加 3 列：`teacher_busy_sum_s`（各教师请求耗时之和）、`n_teacher_requests`、`score_after_gen_s`（最后一个请求结束到生成结束的时间，可以为 0）。教师请求的开始与结束一律记绝对时间，再减去本步的 `step_start_unix`，修正 v1 中 `score_start_s` 为负的问题。
