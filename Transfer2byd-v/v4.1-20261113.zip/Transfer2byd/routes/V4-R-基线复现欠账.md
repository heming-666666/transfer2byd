# V4-R 基线复现欠账（R1-a、R2-a 第二次、R2-c）

| 项 | 值 |
|---|---|
| 卡数 | R1-a 4 张；R2 部分 8 张（官方示例的布局） |
| 能否并行 | R1-a 可与 V4-G1 同时（卡不重叠）；R2 部分独占整机 |
| 预计 | R1-a 约 0.5 小时；R2 部分约 1.3 小时 |
| 依赖 | V4-0 |

判据原文沿用 `routes/v3-参考/V3-R1-…md` 和 `V3-R2-…md`，这里只写 v4 补做的三件事。

## 1. R1-a：verl 官方示例卡在 `ready to fit`（v3 三次都一样）
目的不是硬跑通，而是拿到卡住时的栈，知道卡在哪。**先做最小复现**：官方配置、学生用 v3 换成的 `Qwen3-1.7B-Base`，其余不改。

```bash
python3 -I $PKG/scripts/opd_run.py --task V4-R --cfg r1a-stack --role repro --gpus 4 --steps-total 20 -- bash -c '
  export PYTHONFAULTHANDLER=1
  <v3 里启动 r1a 的那条命令，输出照常> &
  pid=$!
  for i in $(seq 1 120); do sleep 10; kill -0 $pid 2>/dev/null || break; done      # 最多等 20 分钟
  if kill -0 $pid 2>/dev/null; then
    echo "[r1a] 20 分钟仍在运行，导出栈"
    for p in $(pgrep -P $pid) $pid $(pgrep -f "ray::" | head -40); do kill -USR1 $p 2>/dev/null; done   # 无 py-spy 时
    command -v py-spy >/dev/null && for p in $(pgrep -f "ray::|main_ppo|TaskRunner" | head -40); do py-spy dump --pid $p > $OPD_RUN_DIR/stack-$p.txt 2>&1; done
    ray status > $OPD_RUN_DIR/ray-status.txt 2>&1; ray list actors > $OPD_RUN_DIR/ray-actors.txt 2>&1
    sleep 5; kill $pid; sleep 10; kill -9 $pid 2>/dev/null; exit 7
  fi; wait $pid'
```
- `faulthandler` 要在进程里登记了 SIGUSR1 才会打印栈；没有登记时只靠 `py-spy`。两样都没有就只交 `ray status`、`ray list actors` 和日志最后 200 行，并在 00 写明。
- 跑出 20 步：按 v3 路线卡的四条判据交数。仍卡住：交栈和 Ray 状态原文（09），写出你判断的卡点，**不要改 verl 的代码**。

## 2. R2-a 第二次（换种子）
用 v3 的 `run_r2a_official.sh` 冻结副本，只改种子，跑 12 步：
```bash
python3 -I $PKG/scripts/preflight.py --task V4-R --need-gpus 8 --frozen $ADP/<r2a 的启动脚本>
python3 -I $PKG/scripts/opd_run.py --task V4-R --cfg r2a-s2 --role repro --seed 2 --gpus 8 --steps-total 12 --warmup-steps 2 \
  --gpu-roles '<按官方布局写：teacher=…;student=…>' -- bash $ADP/<r2a 的启动脚本> <种子参数>
```
交：12 步的 `opd_kl`、`step_s`；与 v3 那次逐步的差（05 的 `r2a_seed_diff`，带两边原值）。

## 3. R2-c 编排等价
`official_d1.py` 生成的参数与官方示例参数各跑 3 步（都用种子 1），交 `orchestrator_equiv_max_rel`。**判据**：相对差不超过两次 R2-a 同一步之间的相对差。同时把两套参数的逐项差异表（参数名、官方值、我们的值、原因）写进 02。

## 4. 训练与计时的正确性门（采纳 GPT 的 O004 建议 Q0；做在 R2-a 第二次之后，同一环境）

v3 的数据还不能证明“训练在学”，也不能证明计时口径没问题。下面四项便宜，先做：
1. **不学习的负对照**：R2-a 的命令只把学习率改成 0，跑 3 步。期望：参数不变（打印第 1 步和第 3 步某一层权重的 sha256 或 L2 范数，用 slime 已有的保存检查点办法），`opd_kl` 不下降。和正常学习率的 3 步并排交。
2. **新权重确实被下一步的生成用上**：交 R2-a 日志里每步 `update_weights` 的记录行和引擎端收到权重的记录行（原文），证明第 k 步的生成用的是第 k−1 步更新后的权重。
3. **评测截断**：V3-8 的评测约 39% 的生成顶到长度上限。用 v3 的评测样本文件（不用 GPU），统计每个基准里“写到上限”的样本中，结尾有没有正常的结束符、是否带思考段，各抽 5 条看末尾 200 字，写进 00。若是聊天模板或停止符配置的问题，在 V4-Q 里改正并写明。
4. **计时口径**：v3 里 verl 的“教师暴露时间为 0”是由计时结构造成的——每条回答的教师请求在生成循环里等待，生成结束的时刻已经包含了最后几条的教师时间。本机按 v3 的时间线估算真实暴露约 3.8 s（一步 641 s 的 0.6%）。v4 起凡是记教师时间的任务，另记“最后一条回答写完的时刻”（`gen_last_token_s`），由研究者算真实暴露。

## 要交的
03 每次运行一行（含 `args_sha256`）；04 逐步；05 上面点名的键；08 r1a 的状态摘要；09 栈与 Ray 状态原文（每个进程最多 80 行）。
