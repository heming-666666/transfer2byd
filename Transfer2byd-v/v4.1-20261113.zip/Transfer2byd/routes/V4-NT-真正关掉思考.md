# V4-NT 真正关掉思考（探索层）

| 项 | 值 |
|---|---|
| 卡数 | 1 或 2（2 张时每张起一个引擎，时间减半） |
| 能否并行 | 能，只要卡不重叠；不是计时任务 |
| 预计 | 1 张卡约 0.6 小时 |
| 依赖 | V4-0 |

## 为什么做
v3 的 V3-1 把提示后缀换成“非思考”，但回答长度和截断率没有变（p-s-480-nt 截断率仍是 1.00），说明思考并没有关掉。没有一组可信的短回答，就没法判断“回答太长”在生成时间里占多少。

## 做法（只改一项：聊天模板的 `enable_thinking`）
1. 用学生 `Qwen3-4B`，起一个推理服务（引擎和参数用 v3 的 V3-2 学生引擎那一套）。
2. 从 V3-2 一步用的 240 条题目里取前 16 条，用分词器的聊天模板渲染两份提示：`enable_thinking=True` 和 `enable_thinking=False`（`tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, enable_thinking=False)`）。把两份各存成 `prompts-think.jsonl`、`prompts-nothink.jsonl`，每行 `{"prompt": "..."}`。渲染脚本用你 v3 里渲染提示的同一段代码，只多传这一个参数。
3. 两份各跑一次（采样参数与 V3-2 相同）：

```bash
python3 -I $PKG/scripts/opd_run.py --task V4-NT --cfg nt16-nothink --role probe --gpus 1 --steps-total 1 \
  --param enable_thinking=false -- \
  python3 -I $PKG/scripts/gen_bench.py --url http://127.0.0.1:<端口> --model <模型名> \
    --prompts $OPD_RUNTIME/results/v4/V4-NT/prompts-nothink.jsonl --concurrency 16 --n 16 --max-tokens 8192 \
    --temperature <同 V3-2> --top-p <同 V3-2> --out '$OPD_RUN_DIR/gen_bench.json'
```
（`'$OPD_RUN_DIR/…'` 用单引号，由启动器展开；think 那份把 cfg 和 prompts 换掉。）

4. 数出 16 条回答里含思考段（`<think>` 开头或出现 `</think>`）的条数。需要回答原文时，用你 v3 里保存回答的办法另存，原文留在云端。
5. 非思考那份通过后，再用全部 240 条跑一次（`--n 240 --concurrency 64`，cfg 写 `nt240-nothink`）。

## 判据（跑之前写死）
- 16 条里带思考段的不超过 1 条，且 240 条的截断率 < 0.2、长度 p50 < 4096：**有效**；
- 只满足前一条：**存疑**；否则 **无效**（写明看到的回答开头是什么样）。

## 要交的
03 各一行；05：`think_frac`（带分子分母）、`trunc_frac`（带分子分母）；06：长度分位数（`gen_bench.json` 的 `len_q`、`done_q`）。
