# V4-P 教师池探针：多教师 OPD 的主机内存教师池能不能成立（v4 的核心创新点，探针层）

> 这一组是 v4 最重要的任务。v3 显示教师的代价是**占卡**而不是时延：常驻教师 56–59% 的时间空闲（V3-9），按层打分峰值 12.7 GB 对常驻 42.8 GB，分数逐值相同。多教师 OPD（每个领域一个教师）里，各家都把每个教师常驻在专用卡上，教师占卡随教师数 K 线性增长。我们的想法：K 个教师都放在主机内存，按层流过学生自己的卡打分，把教师占的卡还给学生。这五个探针各回答一个“它会不会不成立”的问题。
> 全部通过 `opd_run.py` 启动；脚本在 `scripts/probes/`，研究者写好并在本机用替身跑通（真实 GPU 上没跑过，先跑每个探针的第一格当冒烟）。开跑前把 `scripts/probes/common.sh` 开头列的环境变量写进 `$OPD_RUNTIME/state/probe-env.sh`（V4-0 第 2 步）。

| 探针 | 回答什么 | 卡数 | 计时敏感 | 预计 | 能否并行 |
|---|---|---|---|---|---|
| P1 | K = 1、2、3 个教师时，常驻 / 整模型换入换出 / 教师池三种放法能不能放下、各要多久 | 1 | 否（只比状态和同进程内的时间） | 约 3 卡时 | 能，各格占不同的卡 |
| P2 | 同卡打分让学生生成慢多少；在生成尾部打分是不是干扰更小 | 1（租整机，其余卡空着） | 是 | 约 2 小时 | 不能 |
| P3 | 1、2、4、8 张卡同时从主机拷贝时每卡带宽掉多少 | 1、2、4、8 | 是，整机安静 | 约 1 卡时 | 不能 |
| P4 | 稠密教师的流式持平点；真实异长序列上每层是不是只拷一次 | 1（租整机，其余卡空着） | 是 | 约 1.5 小时 | 不能 |
| P5 | 学生生成的尾部是不是吞吐问题（备选创新点“切步续生成”的前提） | 1 | 是 | 约 2 卡时 | 只能和不占主机带宽的任务同时 |

## P1 三种放法（只改“教师放在哪里”）

教师（同一词表的 Qwen3，已在 `/dev/shm/proctor` 打包）：K = 1 → `qwen3-8b`；K = 2 → `qwen3-8b,qwen3-14b`；K = 3 → `qwen3-8b,qwen3-14b,qwen3-32b`。一步的 240 条真实序列按顺序轮流分给 K 个教师（模拟按领域路由）。学生引擎显存占比两档：0.40（V3-6 的值）、0.60。共 3 × 2 = 6 格。

```bash
for K in qwen3-8b qwen3-8b,qwen3-14b qwen3-8b,qwen3-14b,qwen3-32b; do for MEM in 0.40 0.60; do
  python3 -I $PKG/scripts/opd_run.py --task V4-P1 --cfg p1-k$(echo $K | tr ',' '\n' | wc -l)-m${MEM#0.} --role probe \
    --gpus 1 --steps-total 2 --param teachers=$K --param engine_mem=$MEM -- bash $PKG/scripts/probes/p1_pool.sh $K $MEM
done; done
```
**上界（先写）**：M 的峰值显存与 K 无关（约一个教师两层的缓冲，8–14 GB）；S 每个教师多出一次整模型换入（按 55 GB/s，8B 约 0.3 s、14B 约 0.55 s、32B 约 1.2 s）。
**判据**：
- **有效**：至少一档显存占比下，K ≥ 2 时 R 放不下而 M 放得下，且 M 的峰值随 K 增长不到 10%；
- **存疑**：R 都放得下，但 S 的（换入 + 打分 + 释放）总时间比 M 的打分总时间长 5–15%；
- **无效**：K = 3 时 R、S 都放得下，且 S 不比 M 慢 5% 以上（教师池没有独有优势）。
- 分数：`maxdiff_M_vs_R`、`maxdiff_M_vs_S` 必须是 0（不是 0 时 `pool_bench.py` 退出码 5，这是实现错误，停下报告）。

## P2 同卡干扰

```bash
python3 -I $PKG/scripts/opd_run.py --task V4-P2 --cfg p2-c240 --role probe --gpus 1 --timing-sensitive --steps-total 4 \
  -- bash $PKG/scripts/probes/p2_interf.sh 240 0.40 qwen3-32b
```
（满载并发 240 是 V3-2 一步的条数；V4-G1 已经跑出最好的并发时，用它替换 240，再跑一格 `p2-cbest`。）
**上界**：干扰为 0。**判据**：满载时打分开 / 关的生成吞吐比 ≥ 0.90 **有效**；0.75–0.90 **存疑**；< 0.75 **无效**（教师池的收益会被干扰吃掉）。另看尾部：尾部的减速 ≤ 满载减速的一半，就保留“尾部发起打分”这个组件；否则去掉。

## P3 多卡同时拷贝的带宽

整机安静时，依次跑 N = 1、2、4、8：
```bash
for N in 1 2 4 8; do python3 -I $PKG/scripts/opd_run.py --task V4-P3 --cfg p3-n$N --role bench --gpus $N --timing-sensitive \
  --steps-total 1 -- bash $PKG/scripts/probes/p3_bw.sh qwen3-32b; done
```
**上界**：每卡带宽不随卡数下降（单卡约 55 GB/s）。**判据**：N = 8 时每卡 ≥ 单卡的 0.7 倍 **有效**；0.4–0.7 **存疑**；< 0.4 **无效**（8 卡同卡的教师池会被主机带宽卡住，只适合少卡）。同时交 `numa.txt`、`topo.txt`。

## P4 持平点与真实形状

```bash
for T in qwen3-8b qwen3-32b; do python3 -I $PKG/scripts/opd_run.py --task V4-P4 --cfg p4-$T --role bench --gpus 1 \
  --timing-sensitive --steps-total 3 -- bash $PKG/scripts/probes/p4_breakeven.sh $T; done
```
- **持平点**：每档 token 数下 stream ÷ resident 的吞吐比（分子分母都交）。8K 时 < 0.7：教师池要“攒够 token 再扫”（积压组件必要）；0.7–0.9 存疑；≥ 0.9：只有 MoE 教师需要积压。32B 常驻在 131K 时可能放不下，照实记。
- **真实形状**（GPT 在 O004 里指出：v3 的混合层打分器在真实异长序列上每层拷了 8 次）：`real-shape.json` 里 `copies_per_layer` 应为 1。**不是 1 时**：记下数值，这说明真实负载下按层流式多付了拷贝，教师池必须先修这一点；不要改打分器，回传数字即可。

## P5 尾部是不是吞吐问题

```bash
python3 -I $PKG/scripts/opd_run.py --task V4-P5 --cfg p5-c240 --role probe --gpus 1 --timing-sensitive --steps-total 8 \
  -- bash $PKG/scripts/probes/p5_refill.sh 240 960 0.60
```
**上界**：1 ÷ 平均槽位占用率；v3 的 verl 一步算出平均占用 0.599，上界约 1.67。**判据**：refill ÷ wave 的吞吐 ≥ 1.30 **有效**；1.10–1.30 **存疑**；< 1.10 **无效**（尾部不是吞吐问题，备选创新点不成立）。

## 要交的
- 05：每格的状态（`feasible`，`x` 写 `K,臂,显存占比`）、每臂时间与峰值、比值（都带分子分母）、上界（`*_upper_bound`）；
- 08：`pool_bench.json`、各 `gen-*.json`、`gen_bench.json`、`bench-*.json`、`real-shape.json` 原样各一行；
- 11-energy（自动）、12-engine（P5 的 `engine.csv`）；09：任何 OOM 或报错原文。
