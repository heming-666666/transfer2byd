# V4-F 少卡可行性图：卡少的时候，教师还放得下吗（确认层）

| 项 | 值 |
|---|---|
| 卡数 | N = 1、2、4 三种 |
| 能否并行 | 预检（不计时）可以多格同时跑，只要卡不重叠；计时臂要整机安静（按层打分和整模型换入都占主机内存带宽） |
| 预计 | 预检约 3 小时；计时臂 N = 2 约 7 小时、N = 4 约 5 小时；N = 1 的计时是可选项（约 12 小时） |
| 依赖 | V4-0；学生引擎参数用 V4-G1 最好的一格 |

## 为什么做
8 张卡时，32B 的教师单独占 2 张卡，基线跑得动，模式 B 没有带来好处（v3）。卡少的时候不一样：只有 1–2 张卡时，常驻的 32B 教师（bf16 约 64 GB）要占掉一整张卡，学生就没有地方了。这一步画出一张图：每个卡数下，每种放法是“能跑 / OOM / 没跑”，能跑的各要多长时间、多少能耗。

## 四种放法

| 臂 | 含义 | v4 里怎么测 |
|---|---|---|
| **R** 常驻 | 教师一直在 GPU 上（SGLang 或常驻打分器）。分卡或同卡，取该卡数下能跑的最好布局，预检最多试 3 种 | 端到端：预检 + 计时 |
| **M** 模式 B | 教师权重在主机内存，按层流过 GPU（lm_server），与学生同卡 | 端到端：预检 + 计时 |
| **S** 整模型换入换出 | 只在打分时把整个教师拷上 GPU，打完释放 | **只做微基准**（`swap_bench.py`）：能不能放下、换入要多久、打分要多久。端到端的 S 臂要改 slime 的打分时机，代码还没有，v5 再做 |
| **Q** 量化教师 | 云端已有量化权重才做 | 只做预检，记状态和对 bf16 的打分偏差；没有权重就写 `NA:no-asset` |

配比：主配比 `Qwen3-4B ← Qwen3-32B`，slime，每步 30 题 × 8 条，上限 8192。第二配比 `Qwen3-1.7B-Base ← Qwen3-8B` 只做预检。

## 步骤
1. **预检**（每格 1 步，`--role probe`，不加 `--timing-sensitive`）：N ∈ {1,2,4} × {R 的各布局, M}。跑通记 ok；OOM 记 oom（`opd_run` 自动认）并把报错那几行放进 09；因为别的原因失败记 fail。**没跑的格不要写成 oom**。
```bash
python3 -I $PKG/scripts/opd_run.py --task V4-F --cfg f-n2-M-pre --role probe --arm modeB --gpus 2 --steps-total 1 \
  --gpu-roles 'shared=0,1' --param n_gpus=2 --param layout=colocated -- <slime 模式 B 的运行命令，2 张卡同卡>
```
卡数变了，批大小等要跟着换算：每步总条数不变（240 条），slime 的 `--global-batch-size` 不变，按卡数改每卡的 token 上限和引擎并发（并发 = V4-G1 最好一格的值）；换算后的参数全部进 `slime-args.txt`。
2. **S 臂微基准**（每个 N 一次，用 1 张卡；序列用 V3-2 留下的一步 `seqs.jsonl`）：
```bash
python3 -I $PKG/scripts/opd_run.py --task V4-F --cfg f-swap-32b --role bench --gpus 1 --timing-sensitive --steps-total 3 -- \
  $PY_SCORER $PKG/scripts/swap_bench.py --scorer <v3 通过自测的 lm_scorer.py> --packed /dev/shm/proctor/qwen3-32b \
    --gpu 0 --seqs <一步的 seqs.jsonl> --limit 240 --repeats 3 --out '$OPD_RUN_DIR/swap_bench.json'
```
先用 `--limit 8 --repeats 1` 冒烟。这个脚本研究者本机没法运行（没有 GPU），出错时把报错原文交回，不要改它。再在“卡上已经有学生引擎和训练器占着显存”的情况下重复一次（先起学生引擎，占比用 V4-G1 最好一格的值），看 S 是否还放得下。
3. **计时**（先 N = 2，再 N = 4；预检 ok 的 R、M 两臂）：每臂 2 步预热 + 3 步测量，R、M 交替。加 `--timing-sensitive`，其余卡空着。

## 上界与判据（先写上界）
- 每个 N，在 05 写 `f_upper_bound`：若 R 是分卡布局，M 同卡后学生多出的卡数比例就是生成段的上界，按 V4-F8 的算式折成整步上界。
- **有效**：某个 N 下 R 跑不了、S 的微基准也放不下，而 M 能跑；或 M 比“R 和 S 估算值里能跑的最好一个”快 ≥ 15%（且不超过上界）。
- **存疑**：快 5–15%。
- **无效**：所有 N 下，S 都放得下且（S 的换入时间 + 打分时间）与 M 的打分时间相差不到一步时间的 5%。这时模式 B 相对整模型换入没有可见优势。
- S 的端到端步时间只能估算：`R 同卡布局的步时间 − R 的教师影响 + S 的换入与打分时间`，在 05 里标 `unit=s_est`，写清算式各项，不要当实测。

## 要交的
- 03 每格一行（N、臂、布局、状态、每卡角色、`args_sha256`）；
- 05：可行性图的每格状态（键 `feasible`，值 ok/oom/fail/not-run，`x` 写 `N,臂,布局`）、上界、计时臂的步时间与比值（带分子分母）、`swap_bench` 的 init_s/score_s/free_s/peak_gb（每次重复一行）、S 的估算；
- 04 计时臂逐步；08 `swap_bench.json`；09 OOM 原文；11-energy。
