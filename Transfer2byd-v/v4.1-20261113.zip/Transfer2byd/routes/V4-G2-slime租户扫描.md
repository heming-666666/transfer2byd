# V4-G2 slime 的租户扫描：只调已有开关能拿回多少（探索层）

| 项 | 值 |
|---|---|
| 卡数 | 8，独占整机 |
| 能否并行 | 不能（步时间对比，任何别的负载都会改变结果） |
| 预计 | 约 3 小时（7–8 臂 × 4 步） |
| 依赖 | V4-0；V4-R 的 R2 部分 |

## 为什么做
slime 一步里有三个“租户”共用 8 张卡：学生生成引擎（SGLang）、学生训练器、教师。v3 里生成占整步 83–92%，而每张学生卡只有约 830 tok/s。这一步用**框架已有的开关**逐个去试，看哪一个能把时间拿回来。它同时决定后面的对比用哪个基线：如果某个开关就能快 15%，那 v3 的基线不是最强的。

## 参照臂
V3-2 的 `b-split`：学生 6 张卡 + 教师 2 张卡，参数与 v3 正式臂 `b-s1` 完全相同，种子 1。每臂 1 步预热 + 3 步测量。

## 各臂（相对参照臂一次只改一项）

| cfg | 只改的一项 | 对应的假设 |
|---|---|---|
| `g2-ref` | 无 | 参照 |
| `g2-mem080` | `--sglang-mem-fraction-static` 提到 0.80（放不下就 0.70，记下实际值） | 学生引擎 KV 池小 |
| `g2-offtrain` | 打开训练器在生成阶段换出（`--offload-train`；v3 是 `--no-offload-train`） | 训练器占着显存 |
| `g2-t1s7` | 教师只占 1 张卡（TP1），学生 7 张 | 教师卡空闲 |
| `g2-conc2x` | 引擎的最大并发请求数翻倍（slime 的 rollout 并发参数；写明参数名和新旧值） | 并发设低了 |
| `g2-len4096` | 回答长度上限 8192 → 4096 | 回答太长 |
| `g2-m-noscore` | 模式 B 臂（`m-split`）关掉教师打分空跑 | 教师与生成抢算力（对照是 v3 的 `m-s1`，不是 `g2-ref`） |
| `g2-mem-off` | 只在 `g2-mem080` 和 `g2-offtrain` 都 ≥ 1.05 时加：两项同时改 | 是否叠加 |

顺序：`g2-ref` → 各臂 → 最后再跑一次 `g2-ref`（cfg 写 `g2-ref2`），两次参照臂的差就是这一轮的噪声。

```bash
python3 -I $PKG/scripts/preflight.py --task V4-G2 --need-gpus 8 --frozen $ADP/<V3-2 的运行脚本>
python3 -I $PKG/scripts/opd_run.py --task V4-G2 --cfg g2-mem080 --arm base --pair s1 --seed 1 --gpus 8 --timing-sensitive \
  --steps-total 4 --warmup-steps 1 --gpu-roles 'teacher=0,1;student=2,3,4,5,6,7' \
  --param changed=sglang-mem-fraction-static --param old=<v3 的值> --param new=0.80 \
  --step-regex '<你在 v3 里用来认 slime 步号的那条正则>' -- \
  <V3-2 运行脚本的命令，参数与 b-s1 相同，只改上面这一项>
python3 -I $PKG/scripts/engine_scan.py --log <该运行的 slime/SGLang 日志> --out <该运行目录>/engine.csv
```
- V3-2 的运行脚本如果只能通过“配置名”选参数，就在它的配置表里**加一条新配置**（只加数据，不改逻辑），把这处改动的 diff 写进 02。
- 每次运行把 slime 最终的命令行参数原样存成 `$OPD_RUN_DIR/slime-args.txt`（03 的 `args_sha256` 取它的 sha256）。
- 每张卡在生成阶段和训练阶段各自的峰值显存：从 `gpu.csv` 按 04 的阶段起止时刻取（`ret_extra.py` 只给整次运行的；分阶段的由你的制表脚本按 `gen_start/gen_end/train_start/train_end` 切，写进 05 的 `mem_peak_gb_gen`、`mem_peak_gb_train`，`x` 写卡号）。

## 判据（跑之前写死；两次参照臂的差记为 e）
- `g2-mem080`、`g2-offtrain`、`g2-t1s7`、`g2-conc2x`：参照臂步时间 ÷ 该臂步时间。任一臂 ≥ 1.15 **有效**（基线换成这一臂）；1.05–1.15 **存疑**（加跑种子 2）；全部 < 1.05 **无效**。比值与 1 的差小于 2e 的，一律按“无差别”写。
- `g2-len4096`、`g2-m-noscore`：看生成段时间的变化。≥ 15% 有效；5–15% 存疑；< 5% 无效。
- 最强基线（门控 B1）= ≥ 1.05 的臂里步时间最短的那一臂；都不到 1.05 就仍用 `g2-ref`。

## 要交的
03（含 `args_sha256`、每张卡的角色）、04 逐步、05（各臂比值带分子分母、分阶段每卡峰值显存、参照臂噪声 e）、06、11-energy、12-engine。
