# V3-8 主流设置下的质量等价：Qwen3-1.7B-Base ← Qwen3-8B（整机，上限 36 GPU·h）

## 要回答什么

论文要说明“模式 B 不改变训练结果”，而且要在审稿人熟悉的设置下说明。

EOPD（ICML 2026）的设置是：
- Qwen3-1.7B-Base 学生 ← Qwen3-8B 非思考教师；
- MATH 训练集；
- 8K；
- 用 Avg@8 和 Pass@8 评测六个数学基准。

v2 只用后训练版学生，评测用贪心解码、每题 1 个样本，比较不了。这次在这个设置下，对比模式 A（调好的 SGLang 常驻教师）和模式 B 的准确率曲线。

## 设置

| 项 | 取值 |
|---|---|
| 框架 | slime（与 V2-D 相同的仓库和环境） |
| 学生 ← 教师 | Qwen3-1.7B-Base ← Qwen3-8B |
| 分词器 | **两边都用 Qwen3-8B 的分词器和对话模板**：Base 版没有登记 `<think>` 等附加 token（易错点 L10，以 V3-0 的 tokcheck 为准） |
| 对话模板 | 非思考：`<|im_start|>user\n{题目}\nPlease reason step by step, and put your final answer within \boxed{}.<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n` |
| 训练数据 | `DigitalLearningGmbH/MATH-lighteval` 的 train，7,500 条，固定顺序。**不能用它的 test**，test 包含 MATH-500 |
| 负载 | 每步 32 个提示 × 8 条 = 256 条，最大 8192 |
| 步数 | 2 步预热 + 30 步；第 0、10、20、30 步存检查点 |
| 运行 | 模式 A 种子 1、模式 B 种子 1、模式 A 种子 2，按这个顺序交替。第二个模式 A 种子用来标定种子噪声 |
| 学习率等 | 与 V2-D 相同，三次逐字一致（02 里贴配置原文） |

## 评测（每个检查点）

- 口径：`eval_metrics.py` 的 `eopd`（temperature 1.0、top-p 0.8、8192，每题 8 个样本）；
- 基准：MATH-500、AIME24、AIME25，以及 V3-0 补下来的 AMC23、Minerva、OlympiadBench；
- 判分用 math-verify 0.9.0，按题汇总后回传（`eval_per_problem`）；
- 第 0 步（Base 原样）也要评，它是起点。

## 判据（预设）

- **等价**：每个检查点、每个基准都满足下面一条：
  - 模式 B 与模式 A（种子 1）的 avg@8 之差，不超过两个模式 A 种子之间的差；
  - 或者按题配对 bootstrap 的 95% 区间包含 0。
- **有差异**：任何一个基准连续两个检查点都超出上面的范围。这时停下来查原因，先查分词器和模板，再查打分差异（V2-D 的 D3 显示开头 1–3 个 token 差异最大）。
- **合理性**：第 30 步的 MATH-500 avg@8 应明显高于第 0 步。没有提高，说明配置错了（易错点 L7）。

## 回传

- 03：3 次运行各一行。
- 04：每步一行。
- 08：每个检查点、每个基准的 `eval_per_problem`。
- 05：`loss` 曲线（x 写步号），以及每步的 `teacher_kl`（如果 slime 有记录）。
