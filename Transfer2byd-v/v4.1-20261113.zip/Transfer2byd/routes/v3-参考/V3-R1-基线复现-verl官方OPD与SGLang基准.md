# V3-R1 基线复现（一）：verl 官方 OPD 示例、我们的补丁是否改变语义、SGLang 官方基准（A 区 + B 区，约 14 GPU·h）

## 要回答什么

v2 用的都是我们自己写的启动脚本、计时补丁和测量脚本。后面所有“优化比基线好多少”的比较，都假定这些代码没有改变框架的行为、测量是对的，但这一点从来没有和官方版本对过。

本任务在**和本版其他实验完全相同的环境、相同的 commit** 上：
1. 跑通官方示例，证明环境和框架本身正常；
2. 证明我们的补丁关掉时与官方逐步一致；
3. 用官方基准工具交叉核对我们的吞吐测量。

**通过之后，V3-1、V3-2、V3-8 的比较才算在同一个架构、同一个环境下。**

## 复用什么

| 项 | 用什么 |
|---|---|
| 代码 | 你机器上的 `$OPD_RUNTIME/repos/verl`（HEAD `199636e` = 基线 commit 加我们的两个计时补丁）。**基线 commit** 是这两个补丁之前的那个提交，用 `git log --oneline -3` 找到它，写进 02 |
| 上游参照 | https://github.com/verl-project/verl 。包里的 `scripts/baselines/verl_run_qwen3_8b_fsdp.upstream.sh` 是 commit `a911bca25d6a` 的原样副本 |
| 环境 | `envs/verl`（v2 的 V2-A A 半所用），**不装任何包**。脚本里的 `uv run` 用 `VERL_USE_UV=0` 关掉 |
| 模型 | 学生 Qwen3-1.7B（tie-fixed 版，与 V2-A 相同），教师 Qwen3-8B |
| 数据 | GSM8K（`data/benchmarks/gsm8k/` 的 main/train 与 main/test）+ MATH-lighteval 的 train 与 test。用 verl 自带的 `examples/data_preprocess/gsm8k.py`、`math_dataset.py` 预处理，输入改成本地路径。预处理脚本的改动 diff 进 02 |

## 做法

**R1-a 官方示例原样跑（A 区 4 卡）**
- 优先用你 checkout 里的 `examples/on_policy_distillation_trainer/run_qwen3_8b_fsdp.sh`；不存在时，按上游副本改写，差异写进 02。
- 只覆盖这些参数，其余全部用官方默认：
  - `STUDENT_MODEL`、`TEACHER_MODEL`；
  - `NGPUS_PER_NODE=2`、`TEACHER_WORLD_SIZE=2`、`TEACHER_TP=1`、`ROLLOUT_TP=1`；
  - `trainer.total_training_steps=20`、`trainer.test_freq=5`、`trainer.logger=["console"]`；
  - 数据路径。
- 回传每步的 `actor/*`、`distillation/*`（或该版本里对应的蒸馏指标名）、`timing_s/*`，以及第 5、10、15、20 步的验证准确率。

**R1-b 官方的正确性检查：学生等于教师**
- verl 文档的 Debugging 一节：学生和教师用同一个模型时，蒸馏损失应该接近 0（不严格为 0，因为训练引擎和推理引擎不同）。
- 用 Qwen3-1.7B ← Qwen3-1.7B，跑 3 步。

**R1-c 我们的补丁关掉时是否与官方一致**
- 同一份配置、同一个种子（`data.seed`、`actor.seed` 等）、各 5 步，跑 4 次：
  - 基线 commit 跑 2 次，用 `git worktree` 检出，不改动现有 checkout；
  - `199636e` 加 `OPD_TIMING=0` 跑 2 次。
- 比较每步的损失和梯度范数。

**R1-d 官方单元测试（CPU）**
- `pytest tests/workers/test_distillation_topk_symmetry_on_cpu.py`。
- 文件不存在时，用包里的上游副本，并记下这件事。

**R1-e SGLang 官方基准对我们的测量（B 区 2 卡）**
- 用 SGLang 自带的单批基准，只测 prefill，`output_len=1`。0.5.23 里的模块名是 `sglang.bench_one_batch` 或 `sglang.benchmark.one_batch`，以安装版本为准。
- 模型与布局：Qwen3-8B TP1、Qwen3-32B TP2；每次 8K、32K、128K token（batch × input_len）；各 3 次。
- 对照：
  - (1) v1 的 R3-P2 和本包 `scripts/p2-residency-sweep.py` 在同一设置下的常驻吞吐；
  - (2) `lm_scorer.py bench --mode resident` 在同一模型、同一 token 数下的吞吐。

## 判据（预设）

- **R1-a 通过**：20 步跑完，没有 NaN；蒸馏损失后 5 步的均值低于前 5 步；GSM8K 验证准确率第 20 步不低于第 5 步。
- **R1-b 通过**：第 1 步每 token 的蒸馏损失 < 0.05，并且小于 R1-a 第 1 步的 1/10。
- **R1-c 通过**：每步损失的“补丁 − 基线”差，不超过两次基线之间差的 2 倍（或相对差 < 1e-3）。不通过时，**V3-1 的计时补丁要先修好再用**。
- **R1-e**：
  - 我们的 SGLang 测量与官方基准相差 ≤ 10%，否则测量脚本有问题，v1、v2 的相应结论要重看；
  - `lm_scorer` 常驻吞吐与 SGLang prefill 的比值如实报告。比值 < 0.8 时，论文里“达到常驻吞吐”的参照必须改成 SGLang，不能用 lm_scorer 自己的常驻模式。
- **任何一项不通过**：停下依赖它的任务，先在 00 写清现象和原因。R1-a、R1-b、R1-c 卡住 V3-1；R1-e 卡住论文的吞吐主张，不卡实验。

## 回传

- 03：每次运行一行。
- 04：R1-a、R1-c 的每步一行，`t_*` 列照 V3-1。
- 05：
  - `val_acc_gsm8k`、`val_acc_math`（x 写步号）；
  - `distill_loss_step1`（R1-a、R1-b 各一行）；
  - `patch_equiv_max_rel`（R1-c）；
  - `sglang_prefill_tok_s`、`ours_sglang_tok_s`、`lm_scorer_resident_tok_s`（x 写 token 数）。
- 08：pytest 输出的摘要。
- 02：所有覆盖参数和 diff，以及基线 commit 号。
