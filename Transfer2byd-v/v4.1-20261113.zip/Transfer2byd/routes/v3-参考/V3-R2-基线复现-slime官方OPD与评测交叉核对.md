# V3-R2 基线复现（二）：slime 官方 OPD 示例、我们的编排是否等价（整机，约 12 GPU·h）

## 要回答什么

V2-D 和 V3-2、V3-8 的基线和模式 B 都跑在 slime 上，参数由我们自己的 `official_d1.py` 生成（136 项）。要回答两件事：
1. 这套编排与 slime 官方 OPD 示例的行为是否一致；

slime 官方示例的布局（actor 4 卡 + rollout 2 卡 + 教师 SGLang TP2 两卡，不 colocate）正好就是 V3-2 的 `b-split` 基线。所以本任务同时给出 `b-split` 的官方参照。

## 复用什么

| 项 | 用什么 |
|---|---|
| 代码 | `$OPD_RUNTIME/repos/slime-d1-ipc-20261106`（V2-D 用的，HEAD `0b0c277` 加 D1 修复）和 `repos/slime`（同一 commit，没有 D1 修复）。上游参照 https://github.com/THUDM/slime ，包里的 `scripts/baselines/slime_run-qwen3-4B-opd.upstream.sh` 是 commit `79aa41a884ab` 的原样副本 |
| 环境 | `envs/slime-te218`，不装任何包 |
| 模型 | 官方示例的那一对：学生 Qwen3-4B-Instruct-2507 ← 教师 Qwen3-30B-A3B-Instruct-2507（云端两个都有）。学生要先按示例转成 torch_dist 格式 |
| 数据 | 示例用的是 `zhuzilin/dapo-math-17k`。云端的 `data/dapo-math-17k/dapo-math-17k.jsonl`（17,398 行，字段 prompt/label）很可能就是这一份，V3-0 的身份核对会确认 |

## 做法

**R2-a 官方示例（整机）**
- 用你 checkout 里的 `examples/on_policy_distillation/run-qwen3-4B-opd.sh`，只改下面这些：
  - 路径（`/root/...` 换成实际路径）；
  - 端口和 Ray 地址（按 docs/14 的 AB 分区段）；
  - `--rollout-max-response-len 8192`（官方是 131072；8K 与我们的主设置一致）；
  - `--num-rollout 12`（2 步预热 + 10 步）；
  - `--save-interval 100000`；
  - **删掉脚本最后的 `pkill -9 sglang`、`ray stop --force`、`pkill -9 ray`、`pkill -9 python`**，改为只停自己端口上的 Ray 和 SGLang（易错点 E8）。
- 其余参数一字不改，改过的地方 diff 进 02。
- 回传每步的 `step_time`、rollout 时间、训练时间、OPD KL（或该版本里对应的指标名）、loss、grad_norm。

**R2-b 学生等于教师（3 步）**
- 教师改成 Qwen3-4B-Instruct-2507 本身，OPD KL 应该接近 0。

**R2-c 我们的编排是否等价**
- 用 `official_d1.py`，按 R2-a 的设置生成 `train.py` 的参数，和 R2-a 实际用的参数逐项 diff。差异应该只有 docs 里写明的几项（卡数、教师 URL、`--save`），其他差异逐条列出原因。
- 用两套参数各跑 3 步（同一个种子），比较每步的 loss 和 grad_norm：差不超过两次 R2-a 之间差的 2 倍。
- R2-a 只跑 1 次时，再补跑 1 次，用来定种子噪声。

（评测管线的交叉核对移到 V3-4 第 6 步，因为它只用 V3-4 的生成结果，不需要等整机。）

## 判据（预设）

- **R2-a 通过**：跑完 12 步，没有 NaN；OPD KL 后 5 步的均值低于前 5 步。这个布局的步时间作为 V3-2 `b-split` 的官方参照。
- **R2-b 通过**：第 1 步的 OPD KL < 0.05，并且小于 R2-a 第 1 步的 1/10。
- **R2-c 通过**：
  - 参数差异只有写明的几项；
  - 每步指标在种子噪声以内。

  不通过时，V3-2 的模式 B 和基线都改用 R2-a 那套参数为底，重新生成，再跑。

## 回传

- 03、04：R2-a、R2-b、R2-c 每次运行、每步。
- 05：
  - `opd_kl`（x 写步号）；
  - `orchestrator_equiv_max_rel`；
- 08：参数 diff 的摘要。
- 02：所有改动的 diff。
