# CHANGELOG

## v4.1（2026-11-13，v4 的补完包；依据 v4 的部分回传与研究者 2026-11-13 的要求）

**为什么有这一版**：v4 跑了一半（V4-0、P1、NT、G1、E、R 已完成），回传同时报了云端编排 skill 的 7 个问题（两套锁、ray 端口冲突逼 4 卡任务整机独占、僵尸锁、占卡空转、子窗误杀、tee 截断、版本不符）。研究者要求：多卡持续用满、主窗只做分发与合并、每次派发核实真用卡、一事一窗做完关窗、看板多页签与论文完成度、skill 自己会变好、v5 等 v4 数据全回来再出。所以 v4.1 只补完 v4，并把执行方式换成 skill 2.0.0。

**改了什么**：
1. `state/manifest.json` 改为 `orch-manifest/2`（30 个任务 + 5 个角色），与 `tasks.yaml`、`parallel-plan.json` 由 `scripts/v41/make_manifest.py` 从同一张表生成。v4 已完成的 6 个任务写 `done_if`（证据在就判完成，不重跑）。
2. 新任务：V41-0 接手检查、V41-S1 ray 端口冒烟、V41-GBW 门 BW（P3 的 8 卡每卡带宽 ≥ 单卡 0.90 → 计时探针并行）、V41-Q0 正确性门（v4 R 卡第 4 节）、V41-R1b（R1-a 第 4 条补测）；P2、P4a、P4b、P5 各有并行与串行两个变体；V4-F 拆成 Fp（预检）与 Ft（计时臂）。
3. `scripts/v41/`：`env.sh`（端口段、两个 ray 集群的端口排法、agent 就绪判据、只停本运行的进程、跳过已完成的格）、`tasks/*.sh`、`gate_bw.py`、`util_report.py`、`own_procs.py`、`make_manifest.py`。
4. `opd_run.py`：结果目录按大版本（v4.1 → `results/v4/`）；`run.json` 记 orchd 的任务、运行号、槽位、端口段、卡。
5. 看板重做（`dash.py` + `dashboard/index.html`，`docs/15`）：七个页签、论文完成度（`research-status.json` 的 `paper_progress`）、5–20 秒刷新、读 orchd 的状态（每卡租约与核查、卡时账、告警、事件）。
6. 回传：多 `14-detours.md`、`15-gpu-util.csv`、`16-skill-issues.md`；编号统一为 `p01v4a-…` 与 `p01v41-…`（`check-return.py`、`mini_return.py` 同步）；`docs/06`、`25`、`prompts/P-v4a-小回传Prompt.md` 更新。
7. `docs/00` 改为 v4.1 版；新增 `docs/26`（云端环境经验与弯路记录）、`routes/V41-总览与门控.md`；`AGENTS.md`、`README.md`、`docs/13`、`docs/15` 重写。
8. `skill/`：主窗调用 Prompt、需要的 skill 版本、本轮 skill 优化记录、skill 2.0.0 升级包（研究者要求：以后每个实验包都带 skill 的使用 Prompt 与优化记录）。

**同日重做（2026-11-13 晚，打包前；研究者追加的要求：动态调度、不用预计时长；以“进程真起、持续占用、实验真开始”确认真开始；能并行的实验写成 1/2/4… 卡都能跑；异常与变更预先想全写清；skill 全局通用；环境任务优先）**：
9. manifest（31 个任务）：
   - 不写预计时长（`gpu_options` 的值只作偏好）；
   - 新增环境任务 V41-ENV（`scripts/v41/env_ok.py`），所有 GPU 任务都依赖它；
   - 每个任务写了 `if_fail` 预案：探针与补测 accept，可选任务 drop，核心任务不写；
   - V41-Q0、V4-A、V4-RT 完成时叫醒主窗（`notify`）；
   - 包的环境变量与子窗规则写进 `run_env`、`brief`（skill 全局通用，不认识本包的变量名）；
   - 门 BW 的命令自带后备：出错直接判串行。
10. P2 改用 skill 的 `cellrun.py` 按租到的卡并行跑两格（`tasks/p2.sh` → `tasks/p2_cell.sh`）；P2 的打分循环加保护：连续 3 次失败就停，整格判失败，不交假的“打分开”数据（`probes/score_loop.sh`）。
11. `opd_run.py`：进度同时写 `$ORCH_PROGRESS`，认出第一步时 touch `$ORCH_STARTED`（orchd 的启动确认）。`env.sh` 读 V41-ENV 的 `v41-env-override.sh`。
12. 文档：
    - `routes/V41`：任务总表按档位与预案重写，新增第 8 节环境任务、第 9 节本包的异常预案，第 7 节改为自动派窗与 cellrun；
    - `docs/00`、`13`、`15`、`AGENTS.md`、`README.md`、`agents/ORCH-主控.md` 同步；
    - `skill/` 的调用 Prompt 改为“通用骨架 + 本包第一节”；
    - 优化记录、需要的版本、升级包重建。

**同日再改（2026-11-13 夜，打包前；研究者问窗能否正常关、能否 resume、间隔会不会让上下文太长、优先级能否表达依赖、SuperAgent 有没有充分借鉴）**：
13. skill 2.0.0：
    - 主窗只挂 `orchd.py wait`（有事才醒，巡检不进上下文）；
    - 子窗交报告后等这一轮结束再优雅关窗；会话号记下，窗消失、key 失效、重试都 `--resume` 原会话；做完的任务追问用 `orchd.py reopen`；
    - 限流退避后让子窗接着做；
    - 里程碑与依赖算出的优先级；马上就绪的高优先级任务先留卡；
    - 1.7.0 的睡眠区间标为只用于手工模式。
14. manifest：
    - 去掉探针、Q0、G2、环境任务的手填 `prio_boost`；
    - 加五个里程碑（M-GATEP 研究者在等、M-PREMISE、M-V5DESIGN、两个论文节）；
    - G2 after Q0（先验证再正式）；
    - 环境窗 T 档、判断窗 M 档。

    算出的顺序与 `docs/00` 的研究顺序一致（包自测核对）。
15. 文档：`routes/V41` 第 1、7 节，`docs/00`、`13`，`agents/ORCH-主控.md`，`skill/` 的 Prompt、优化记录与升级包同步。

**怎样从 v4 衔接**：环境、模型、`/dev/shm/proctor` 里的打包教师、`results/v4/` 全部沿用；v4 的任务目录 `orch-v4-20261112` 不动，v4.1 新建 `orch-v4.1-20261113`；先确认 skill 是 2.0.0，再 `orchd.py init`。

**测试情况（研究者本机，没有 GPU）**：

| 项 | 测过什么 | 没测什么 |
|---|---|---|
| skill 2.0.0 的 orchd 与 cellrun | `tests/orchd_sim.py` 全过（假 nvidia-smi、假实验、假 tmux、假 winctl，数量见 `skill/优化记录.md`）；在 1.7.0 副本上安装、升级前后测试一致、回滚逐字节还原 | 真 GPU、真 tmux、真 claude（`skill-upgrade-2.0.0/UPGRADE.md` 第 4 步的上线冒烟） |
| v4.1 的排程 | 用 orchd 在假 8 卡、自动派窗模式下跑这份 manifest（调度器看不到真实时长；真实时长 ±30% 随机、带加载开销；另跑门 BW=fail 并注入失败），见 `docs/13` 第 3 节 | 真实时长与失败 |
| `scripts/v41/*` | `tests/selftest.sh` 第 6 节：语法、manifest 与生成器一致、门 BW 三种情形、卡时账、看板读 orchd 状态、端口段 | `ray_smoke.sh`、`tasks/*.sh` 只过了 `bash -n`（要真 ray 与真探针；V41-S1 就是它的冒烟） |
| 看板 | `dash.py collect/once` 对 orchd 状态跑通；页面的渲染函数在 node 里对真实采集结果跑通（七页、空数据都不报错） | 真浏览器里的显示 |
| 包自测 | `tests/selftest.sh` 88/88（第 7 节：启动确认的约定、环境检查三种情形、P2 打分保护、P2 交给 cellrun 的格、manifest 的环境依赖与预案、用随包的 orchd 核对优先级顺序、里程碑与档位） | — |

## v4 同日修订（2026-11-12，打包后、上传前；按规范重新打包，旧包备份在 `~/.cache/Transfer2byd/`）

1. **核心创新点**：多教师 OPD 的主机内存教师池（研究者用 idea-spark 与 brainstorming → creative-thinking 两个 skill 独立提出，融合后查新 Level 3、评估“修改后接受”）。新增探针 V4-P1–P5（`routes/V4-P-教师池探针.md`）和脚本 `scripts/pool_bench.py`、`scripts/probes/*.sh`；`gen_bench.py` 加 `--mode wave|refill|both`。可选任务 V4-M 取消（由 V4-P1 代替）。
2. **GPT 的 O004 意见**：V4-R 加正确性门 Q0（学习率 0 的负对照、权重版本、评测截断、计时口径）；V4-P4 直接数真实序列上的拷贝次数。
3. **与云端编排 skill 对接**：`state/manifest.json` 改为 `orch-manifest/1`（17 个任务、5 个角色，带 preflight/smoke/launch/tunable/expected_range）。
4. **看板**：新增研究进展、投稿与实验节点（以 OSDI 为主）、探索过的方向、论文进展（`state/research-status.json`）。
5. **小回传 v4a**（任务 V4-A）：V4-0 与 V4-P1–P5 结束后先交 9 个文件；新增 `docs/25-小回传v4a.md`（交什么、模板、步骤、检查）、`prompts/P-v4a-小回传Prompt.md`（给执行窗的任务书）、`scripts/mini_return.py`（生成 5 个数据文件和自动判定，检查 9 个文件）；`ret_extra.py` 加 `--tasks`。本机用模拟的运行目录测通 build → check（含 4 种常见错误）→ pack → unpack 逐字节相同。

**测试情况（追加）**：`pool_bench.py` 用内置的假打分器跑通三臂与 OOM 判定；`probes/p1_pool.sh` 用替身引擎和假打分器经启动器跑通；其余探针脚本只过了 `bash -n`；`gen_bench.py` 的 wave/refill 对模拟服务跑通（refill 吞吐是 wave 的 1.74 倍）；看板的研究进展部分用 `dash.py once` 和 `collect` 测过。真实 GPU 上都没跑过。

## v4（2026-11-12，依据 v3 的回传 return-20261111-01）

**改了什么，为什么**：
1. **研究问题**：v3 显示模式 B 在三组对比里都没有变快（0.54–0.95），教师推迟训练的时间为 0；slime 里生成占整步 83–92%。v4 改为回答四件事：学生生成为什么慢（V4-G1、G2、G3、NT）；“把教师的卡还给学生”补测（V4-F8，v3 两臂布局相同，没测到）；少卡时的可行性图，含整模型换入换出这一朴素对照（V4-F）；基线复现欠账和“看得出在学”的配置（V4-R、V4-Q）。详见 `docs/21`、`22`。
2. **代码由研究者写，云端只执行**（`docs/00` 第 2 节）：新增统一启动器 `opd_run.py`、GPU 采样 `gpu_sampler.py`、预检 `preflight.py`、快照 `snapshot.py`、看板 `dash.py` + `dashboard/index.html`、学生吞吐基准 `gen_bench.py`、引擎日志扫描 `engine_scan.py`、整模型换入微基准 `swap_bench.py`、回传表 `ret_extra.py`、回传容器 `ret_md.py`。v3 时云端写的运行脚本在 V4-0 冻结并回传。
3. **每个任务写明卡数、能否并行、是否计时、各卡数下的时长**（`state/tasks.yaml`），新增 `state/manifest.json`。卡锁只用一套（`OPD_GPU_LEASE=external` 或包内租约）。
4. **回传**：内容保留 v3 的 10 个文件，新增 `10-runs.csv`、`11-energy.csv`、`12-engine.csv`、`13-cloud-code.md`；容器改为带 CRC 的 markdown 代码块，每块不超过 3 万字（`docs/06`）。v3 回传里缺的 14 项数据逐项补采（`docs/18` 第 0 节）。
5. **能耗**：每次运行自动记录每张卡的功率和累计能耗，按角色、按步汇总。
6. **每条判据先写理论上界**（v3 的 V3-2 把阈值定在了上界上）。
7. 新增 `docs/00`、`21`–`24`；v3 的路线卡移到 `routes/v3-参考/`。

**怎样从 v3 衔接**：`$OPD_RUNTIME`、环境、模型、`/dev/shm/proctor` 里打包好的教师都沿用；v3 的结果目录 `results/v3/` 不动，v4 写 `results/v4/`。先做 V4-0。

**测试情况（研究者本机，Python 3.12，没有 GPU）**：
| 脚本 | 测过什么 | 没测什么 |
|---|---|---|
| `opd_run.py` | 用替身 `nvidia-smi` 跑通：包内租约选卡、外部卡锁、拒绝覆盖已有目录、卡不够时报错、OOM 判定、步号识别、进度文件、SHA256SUMS、索引追加 | 真实 GPU；长时间运行 |
| `gpu_sampler.py` | `nvidia-smi` 回退路径、空闲检查、列出空闲卡 | **NVML 的 ctypes 路径没有运行过**（本机没有驱动）；读不到时会自动退回 `nvidia-smi` 并在日志里说明。V4-0 第 3 步检查 |
| `dash.py`、`index.html` | 运行中的步号 2–3 秒内出现在 `state.json`；页面能取到 | 浏览器里的实际显示 |
| `gen_bench.py` | 对本机模拟的 `/v1/completions` 服务跑通，吞吐、占用率、截断数正确 | 真实引擎 |
| `engine_scan.py` | 三行按记忆写的 SGLang 日志样例 | **真实日志的字段可能略有不同**；找不到 `Decode batch` 行时退出码 3 |
| `ret_extra.py` | 用启动器产生的运行目录生成两张表；功率积分路径 | 累计能耗计数器路径只做了代码走查 |
| `ret_md.py` | v3 的真实回传数据（约 190 万字，96 块）打包再还原逐字节相同；乱序、任意位置切分 docx、重复块、弯引号、行尾空白、丢块、改字、截断、混入别的回传、缺索引 | Word 的真实粘贴（下一次回传时验证） |
| `preflight.py`、`snapshot.py` | 命令行与主要路径 | — |
| `check-return.py` | 只改了一处：允许 v4 新增的 4 个文件；用 v3 的真实回传加两张新表跑过 | — |
| `tests/selftest.sh` | 本机 39 项全部通过 | 云端的 Python 3.10（V4-0 第 1 步） |
| `swap_bench.py` | **只做了语法检查**（需要 torch 和 GPU） | 全部运行逻辑；先用 `--limit 8 --repeats 1` 冒烟 |
| 路线卡里对 v3 运行脚本的调用 | 无法测试（研究者没有这些脚本） | 全部；这是 V4-0 要回收它们的原因 |


## v3（2026-11-09，依据 v2 的回传 return-20261109-01）

**改了什么，为什么**：
1. **研究方向**：v2 的数据显示，大批量 OPD 中教师不在关键路径上。训练段占 41–65%；模式 B 的教师实测只占步时间的 7.6%；打分时机的退化在 480 条时只有 0.6–4%。所以主张从“更快”收窄到“放得下”：主结果改为 L 对与最强基线的对比（V3-2）和前沿对（V3-3）。V3-1 补上判定 C-PH 唯一缺的分阶段计时。
2. **回传格式**（docs/06 第 0 节、docs/18、docs/20）：
   - 全量数据记在云端，并登记到 `results-index.jsonl`；
   - 回传处理后的关键数据：06 改成每步一行的分布摘要；08 只放 summary；
   - 10 个文件全部转成防复制损坏的文本；
   - 合计约 40 万字以内；
   - 新增 docs/20：每个数据项怎么读、怎么处理、交到哪里，以及每一列的含义；
   - 新增分析脚本 `scripts/analysis/v3_tables.py`，云端和研究者各跑一次。
3. **资产与评测**（docs/04）：
   - 新增 `state/assets-manifest.json`（31 个槽位，逐文件哈希），以及 `scripts/select_assets.py`（离线核对、分词器检查）；
   - 新增 `scripts/eval_metrics.py`：口径跟随已发表论文；先用 Qwen3-8B 校准；按题汇总无损回传；配对 bootstrap。
4. **新增 docs/19**：资源与参数的理由、有效性自检。docs/11 加了 v2 遇到的问题。
5. `scripts/check-return.py` 的 06、07 表头改为 v2 实际回传的摘要格式。

**同日修订（依据你在 `Transfer2me/v2_raw/set/` 的资产盘点，打包后、上传前）**：
- 资产以盘点为准：新目录 `/data/<user>/paper/opd/{models,data}`；加入 Base 学生、Qwen3-30B-A3B-Thinking-2507、Qwen3.5/3.6；
- `select_assets.py` 加了防污染检查（safetensors 头、首尾全零）；新下载的文件要做全量哈希；
- V3-0 加评测集指纹和少量补下载（Qwen3.5-27B 续传、Qwen3.5-122B-A10B、AMC23 等小评测集、原版 DAPO）；
- 新增 V3-7（真实引擎重放，验证仿真器）、V3-8（EOPD 设置下的质量等价）、V3-9（多教师，可选）；
- V3-1 加学生训练调优；
- V3-3 改为先做混合注意力的 Qwen3.5-4B ← Qwen3.6-35B-A3B，再做 GLM。

**再次修订（同日，上传前）：基线复现与依赖梳理**：
- 新增 V3-R1（verl 官方 OPD 示例、学生等于教师的检查、补丁与官方等价、官方单元测试、SGLang 官方基准对我们的测量）和 V3-R2（slime 官方 OPD 示例、编排等价）。官方脚本的原样副本在 `scripts/baselines/`。
- 门控只加在和框架基线比较的任务上：R1 → V3-1、V3-9；R2 → V3-2、V3-8、V3-3b。不和基线比较的探索（V3-3a、V3-5、V3-7）不等复现。
- V3-3 拆成 V3-3a（B 区，不等复现）和 V3-3b（整机，等 R2）。
- 判分交叉核对从 V3-R2 移到 V3-4。
- V3-7 改为在 V3-1 的第一个配置出数后就开始。
- 大文件下载（Qwen3.5-27B、122B）移到交付之后。
- 研究者按估计时长推算：关键路径约 35 h，GPU·h 上限合计 256。

**从 v2 怎样衔接**：
- v2 的任务全部完成，不重跑；
- 环境、打包的权重（`/dev/shm/proctor/`）、slime 和 verl 的补丁照旧用；
- v2 损坏的 8 行 08 和截断的 05，在 V3-0 补传；
- v2 的原始结果目录至少保留到 v4 发出。


每个版本根据回传数据改了什么、为什么改。云端 agent 收到新版本后先读这里。

## v2（2026-11-06，11-07 修订后重新打包；修订前的包没有发出）：依据 v1 的回传 return-20261106-10

**11-07 修订**（研究者：回传只能人工复制文字；回传质量差、实验有问题的地方，要在包里详细说明）：
- **新增 `docs/18`**：
  - v1 回传的 13 个问题，每个写了原因、后果、v2 的要求、怎样自查；
  - 每类数据的硬性要求；
  - 交付前的自检顺序；
  - OOM、卡住、NaN 等问题的处理顺序。
- **回传改为防复制损坏的文本**（`docs/06` 第 5 节）：
  - `make-copysafe.py`：每行带地址和校验，长行切段，易损字符转义；
  - `show-lines.py`：补抄指定的行；
  - `sanity-check.py`：数值合理性检查，在 v1 数据上查出了 116 处问题。
- **V2-F**：写明了计时 bug 的确切原因（`update_step_score_timing` 用了最新一步的起点）和修法，加了新列的定义和验证步骤。
- **V2-A**：
  - 回答数改为 48、240、480，使其能被 2、3、4 张学生卡整除；
  - 加了关闭思考模式的配置，提供真实的长度分布；L 对加了 2 个 TP1 副本的对照，共 14 个配置；
  - 写全了 verl 参数的改法和常见问题；
  - 07 只交 3 个配置的 1 步。
- **V2-D**：
  - 每步回答数改为 480；
  - 加了在 slime 里接入的具体做法和常见问题；
  - 06 只交每次运行的首、末两步。
- **V2-B、V2-0**：加了常见问题（/dev/shm 不够、版本差异、G1 不为 0 等）。

### v2 首版内容（11-06）

**为什么改**：v1 测得两点。
- 小批量（每步 6 条）时教师最多只忙 8%；
- 引擎的权重卸载每 8,192 token 重传一次权重，吞吐只剩常驻的 13–45%，与单次 token 数无关。

研究者据此把方向改为“整步按层打分、教师权重放主机内存”（模式 B），并补测 v1 没覆盖的大批量。详见 `docs/01` 第 0 节。

**新增**：
- 任务 V2-0、V2-F、V2-B、V2-A、V2-C、V2-D、V2-E（可选），路线卡在 `routes/V2-*.md`；v1 的路线卡 R0–R5 已从本版移除，结果照旧留在 `results/R*`；
- `scripts/lm_scorer.py`：按层打分器，含 pack、selftest、bench、score、compare 子命令；
- `scripts/lm_server.py`：给 slime 用的教师服务，接口是 SGLang 打分接口的子集；
- `scripts/check-return.py`：回传前的自检；
- 包的五部分：
  - 并行计划：`docs/13` 第 3–5 节和 `state/parallel-plan.json`；
  - 角色卡：`agents/`；
  - 看板：`docs/15`、`prompts/`；
  - 版本锁：`docs/16`、`state/versions.lock.json`，pins 取 v1 实际运行的版本；
  - 可归因性：`docs/17`。

**修改**：
- **回传**：改为一次交齐的 10 个固定文件，写在 `$OPD_RUNTIME/Transfer2me/`，不切分、不限字数（`docs/06`、`07`）。`make-return-text.py` 已删除；本包的文件也不再限 4500 字。
- **P3 仿真器**：加了 `noisy`（按真实剩余长度 ×(1±e) 排序）和 `random` 两个策略，用 `--noise 0 0.25 0.5` 运行；不加 `--noise` 时，结果与 v1 完全相同。
- **计时补丁**：打分时刻的锚点由 V2-F 修正，`step_breakdown.csv` 末尾加 3 列。
- **文档**：`docs/01`、`02`、`05`、`11`、`12` 已更新。

**从 v1 怎样衔接**：
- **不用重做**：v1 的全部任务都已完成，环境、模型、仓库、`results/R*` 都保留；
- **v1 修过的问题**：照旧沿用，见 `docs/11` 第 0 节；
- **新环境**：本版不装新环境；按层打分器用 `envs/verl-torch214-test`；
- **v1 遗留的未完成项**：
  - R3-F1 的端到端由 V2-E 接手，改用单引擎布局；
  - c05 和 c06 的干净重跑由 V2-A 的 L 对覆盖；
  - FP8 教师不再做；
  - R4-Q1 的离线设定是错的，梯度为零，质量对比改由 V2-D 在线做。

**已知限制**：
- `lm_scorer.py` 和 `lm_server.py` 都没有在 GPU 上运行过，所以 V2-B 的门槛 G1–G3 必须先过；
  - `lm_server.py` 用模拟的打分器测过批处理和回复格式；
  - P3 的新策略用合成数据测过；
- HF 的 MoE 实现可能比 SGLang 慢很多：30B-A3B 的绝对吞吐只作参考，比值才是结论；
- 混合层模型（GLM-5.3）要先扩展打分器（V2-E）。

## v1（2026-11-04）首版

- 路线 R0–R5 的实验卡；任务清单 `state/tasks.yaml`；
- 环境配置（`docs/02`–`04`）、实验思路（`docs/01`）、步骤总览（`docs/05`）、回传规则与每个任务要交的内容（`docs/06`、`07`）、基础知识来源（`docs/08`）、参考文献指导（`docs/09`）、安全规定（`docs/10`）、常见问题（`docs/11`）、实验与论文的对应（`docs/12`）；
- 脚本：
  - P0 带宽、P1 增量打分、P2 驻留扫描、P3 离线仿真（`p3-i8-offline-sim.py` 调用 `p3_model.py`、`p3_policies.py`、`p3_synth.py`）、P4 保真度、P7 降级代价；
  - SGLang 启动、环境快照、文字回传打包 `make-return-text.py`、传输校验 `verify-package.py`；
- 传输约束：只能传文字，每次不超过 5000 字。本包每个文件都不超过 4500 字；回传分段每段不超过 4500 字。

**已知限制**：
- 脚本都没有在 GPU 上运行过：P1、P2、P4、P7 和回传打包用模拟服务器测过逻辑，P3 用合成数据测过；
- SGLang 返回字段名按 0.5.23 的原生接口编写，不一致时脚本会打印实际字段名后停止；
- P3 的同卡模式没有计入教师打分对学生解码的拖慢，结果偏乐观；
- 合成数据的初步提示：教师单独占卡、打分又快时，选择性流式的收益只有百分之几；截断比例高、教师在生成阶段有空闲时收益更大。以 E0 的真实日志为准。

**下一版会根据什么修改**：R0、R2-P1 的回传（接口能否增量打分、硬件常数），G1 前的 E0 与 P3 结果（选 I8 v2 还是 I11，以及端到端主结果的配置）。
