# 升级步骤、上线冒烟与回滚

记号：`H` = 本机用户目录（skill 装在 `$H/.claude/skills/multi-agent-orchestrator/`）；`U` = 本升级包解压目录。

## 1 先看计划（不写文件）

```bash
cd $U && python3 -I install.py --home $H --dry-run
```

应看到：
- 现有版本 1.7.0；
- 一组“写”：`SKILL.md`、`HANDOFF.md`、`templates/WORKER_BRIEF.md`、`templates/checks.json` 是替换，其余是新建，含 `scripts/{orchd,cellrun,brief}.py`、`references/manual.md`；
- 4 个“追加”；
- wait_event.py 两处；
- 调用 Prompt 两份。

数量以 dry-run 打印的为准；与 `SHA256SUMS` 里 `files/` 下的文件数一致。

## 2 安装

```bash
python3 -I install.py --home $H
```

最后一行必须是 `OK 已升级到 2.0.0；回滚：tar xzf ... -C /`。中间：

- `orchd_sim.py` 必须 `ORCHD SIM OK 192/192`（约 8 分钟）；
- `gates.sh`、`gates_sched.sh`、`selftest.sh` 要么退 0，要么与“升级前基线”完全一样（安装器会先跑一遍基线再比）；
- 任何一行 `FAIL`：不要用 2.0.0，把输出整段报给研究者，按第 5 节回滚。

## 3 检查（11 条，逐条贴结果）

```bash
S=$H/.claude/skills/multi-agent-orchestrator/scripts
head -5 $H/.claude/skills/multi-agent-orchestrator/SKILL.md | grep 'version: 2.0.0'
python3 -I $S/orchd.py help | head -3
bash $S/winctl.sh help | head -3
python3 -I $S/skill_feedback.py --help | head -3
python3 -I $S/cellrun.py 2>&1 | head -2                                        # 打印用法
python3 -I $S/brief.py --help | head -2
python3 -I $S/orchd.py help | grep -E "^  (wait|reopen) "                          # 两行
grep -c "2.0.0 起" $H/.claude/skills/multi-agent-orchestrator/references/watch.md      # ≥ 1：旧的睡眠区间已标为只用于手工模式
grep -c orch_sched $H/skill/skill-addons/orch-v1/scripts/wait_event.py        # ≥ 1
python3 -I $H/skill/skill-addons/orch-v1/scripts/skill_lint.py $H/.claude/skills/multi-agent-orchestrator | tail -1   # 0 个错误
diff $H/skill/multiagent.md $H/multiagent.md && echo 两份调用Prompt一致
```

## 4 上线冒烟（真机，约 20 分钟，占 2–3 张卡几分钟）

目的：确认 `orchd` 在真 nvidia-smi、真 tmux 上做对这些事：
- 分卡、启动、**启动确认**、核查、停止、收锁；
- `cellrun` 按租约并行跑格并还卡。

**挑三张空卡的时段做**。它只用 orchd 分给它的卡，不影响别的实验。

```bash
T=$(mktemp -d /tmp/orchd-smoke.XXXX); mkdir -p $T/td
TPY=<装了 torch 的 python 绝对路径，例如包内 docs 写的解释器>   # 守护在 tmux 窗里起，不继承当前 shell 的变量，所以直接写进 manifest
printf '%s\n' 'import os, time, torch' \
  'x = torch.randn(8192, 8192, device="cuda"); y = x @ x; torch.cuda.synchronize(); t = time.time()' \
  'p = os.environ.get("ORCH_STARTED")' \
  'open(p, "w").write("1") if p else None' \
  'while time.time() - t < float(os.environ.get("SECS", "60")): y = x @ x' \
  'print("ok")' > $T/burn.py                                    # 第一步算完才写开始标志
echo '["c1","c2","c3"]' > $T/cells.json
printf '%s\n' '{"schema":"orch-manifest/2","items":[' \
 " {\"id\":\"SMOKE-GPU\",\"kind\":\"gpu-job\",\"deps\":[],\"gpu_options\":{\"1\":null},\"warmup_s\":120,\"stall_s\":120,\"cmd\":\"$TPY $T/burn.py\"}," \
 ' {"id":"SMOKE-IDLE","kind":"gpu-job","deps":[],"gpu_options":{"1":null},"warmup_s":30,"cmd":"sleep 120"},' \
 " {\"id\":\"SMOKE-CELL\",\"kind\":\"gpu-job\",\"deps\":[],\"gpu_options\":{\"2\":null},\"warmup_s\":120,\"cmd\":\"SECS=40 python3 -I $S/cellrun.py --cells $T/cells.json -- $TPY $T/burn.py\"}," \
 ' {"id":"SMOKE-CPU","kind":"cpu-job","deps":["SMOKE-GPU"],"cmd":"echo after-gpu"}]}' > $T/m.json
python3 -I -m json.tool $T/m.json > /dev/null && echo manifest-ok
python3 -I $S/orchd.py init --td $T/td --manifest $T/m.json --lockdir $H/Benchmark/_overnight/gpu_locks --session <会话名> \
  --set start_hold_s=10
tmux new-window -d -t <会话名>: -n orchd-smoke "python3 -I $S/orchd.py daemon --td $T/td"
sleep 45;  python3 -I $S/orchd.py status --td $T/td      # SMOKE-GPU、SMOKE-CELL 核查 ok 且有“启动用时”；SMOKE-IDLE loading
sleep 30;  python3 -I $S/orchd.py status --td $T/td      # SMOKE-IDLE 变 not_on_gpu 并有告警（故意的：它不用卡）
python3 -I $S/orchd.py kill --td $T/td SMOKE-IDLE
sleep 90;  python3 -I $S/orchd.py status --td $T/td --all  # SMOKE-GPU、SMOKE-CELL、SMOKE-CPU done，锁全收回
python3 -I $S/orchd.py util --td $T/td
head -30 $T/td/work/sched/SMOKE-CELL/*/cells-summary.json
ls $H/Benchmark/_overnight/gpu_locks | grep -c . || true  # 不应有 orchd:…:SMOKE-* 的锁
tmux kill-window -t <会话名>:orchd-smoke
```

通过标准（全部满足）：

1. `SMOKE-GPU` 在租到的那张卡上核查为 `ok`，`status` 里有“启动用时 N 秒”，`nvidia-smi` 看得到它的进程在那张卡上；
2. `SMOKE-IDLE` 过了 30 s 启动时限变 `not_on_gpu`，`$T/td/notes/events/orchd.jsonl` 有一条 `orch_alert`；
3. `kill` 后 `SMOKE-IDLE` 为 `failed`（被停止），它的锁被收回；
4. `SMOKE-CELL` 租 2 张卡，前两格同时跑；第三格时还掉 1 张卡（事实流有“还卡”）。`cells-summary.json` 里 3 格都是 done；
5. `SMOKE-GPU` 跑完后 `SMOKE-CPU` 立即执行并 `done`；
6. 结束后锁目录里没有 `orchd:…:SMOKE-*`；`util` 有“真在用”和“启动开销”两行的卡时。

7. **（子窗会话，选做但建议做）** 在会话里开一扇最简单的子窗、关掉，再用原会话恢复：
   ```bash
   echo "只回答“收到”，然后什么都不做。" > $T/b.md
   ORCH_TD=<已写好 notes/orch.env 的任务目录> bash $S/winctl.sh open smoke-w $T/b.md          # 最后一行 session=<会话号>
   ORCH_TD=<同上> bash $S/winctl.sh close smoke-w                                              # 送 /exit，最后一行 session=<同一个号>
   ORCH_TD=<同上> bash $S/winctl.sh open smoke-w2 $T/b.md --resume <会话号> --msg "你上一条回复是什么？只回答原话。"
   tmux capture-pane -p -t <会话名>:smoke-w2 | tail -5                                           # 应答出“收到”
   ORCH_TD=<同上> bash $S/winctl.sh close smoke-w2
   ```
   通过标准：两次 close 打印的会话号相同，恢复的窗答得出上一轮的内容。

把 6 条（做了第 7 条就是 7 条）的结果和 `status` 输出贴进升级报告。任何一条不过：报研究者。修好之前，实验包先照 `skill/需要的skill版本.md` 最后一节用 1.7.0 手工执行（`gpu_sched.py` 仍在）。

## 5 回滚

```bash
tar xzf $H/skill/archive/multi-agent-orchestrator-pre-2.0.0-<时间>.tar.gz -C /
```

备份里是升级前的整个 skill 目录、附加件 wait_event.py、两份调用 Prompt（绝对路径）。回滚后新加的文件（`orchd.py`、`winctl.sh` 等）会留着但不再被 SKILL.md 引用，可以不管。
