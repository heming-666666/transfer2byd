# multi-agent-orchestrator 2.0.0 升级包（2026-11-13）

给云端主窗和研究者。**先读本篇，再照 `UPGRADE.md` 一步步做**；要云端 agent 自己装，把 `prompts/P-skill升级.md` 分隔线之间的内容发给它。

## 一句话

v4 现场的空卡大半不是“发现得慢”，而是**分配和核查分家**：两套锁；没人核实分出去的卡是否真在算；ray 端口冲突逼得 4 卡任务整机独占；主窗陷在排障里，没人派别的任务。

2.0.0 加了一个不调用模型的守护 `orchd`。它是唯一的 GPU 分配者：
- **按优先级与强制依赖动态发卡**：每 3 秒从实时状态重排，不用任何预计时长；
- 自己启动全脚本化的实验，确认每个任务**真开始**（进程真起、持续占用、实验真开始）；
- 每 3 秒核查每张卡是不是真有该任务的进程在算；
- 自动开关工作窗、修复窗、验收窗，照任务包预先写好的预案处理失败；
- 只在要人决定时叫醒主窗。

主窗只掌控全局：后台挂一个 `orchd.py wait`，巡检在它里面做、不进主窗上下文，只在有事时醒来；要判断的开判断窗。子窗做完就优雅关窗、还 key，会话保留，之后要用就 `--resume` 回去。能并行的实验用 `cellrun.py` 写成 1/2/4/8 卡都能跑，调度占卡更灵活。

**先读 `MANUAL.md`**（完整使用手册，含“异常与变更怎么处理”的总表），再照 `UPGRADE.md` 装。研究者的每条要求怎么做到、怎么验证，见 `REQUIREMENTS.md`。

## 包里有什么

| 路径 | 内容 |
|---|---|
| `README.md`（本篇）、`MANUAL.md`、`REQUIREMENTS.md`、`UPGRADE.md` | 总览；完整使用手册（与 skill 里的 `references/manual.md` 相同）；需求追踪表；升级、冒烟、回滚 |
| `install.py` | 安装器：核对 1.7.0 → 备份 → 写文件 → 追加 → 改 wait_event.py 两处 → 写调用 Prompt 两份 → 跑测试（升级前后对比）→ 记录。先用 `--dry-run` 看 |
| `files/.claude/skills/multi-agent-orchestrator/` | 新文件或整文件替换：`SKILL.md`、`HANDOFF.md`、`scripts/{orchd.py,cellrun.py,brief.py,winctl.sh,skill_feedback.py}`、`references/{manual,main-loop,orchd,package-contract,evolution}.md`、`templates/`、`tests/`（数量见 `install.py --dry-run`） |
| `files/skill/multiagent.md` | 调用 Prompt 的通用骨架（第一节每个任务包重填；任务包里的 `skill/P-主窗调用.md` 是填好的），安装时写两份副本 |
| `appends/` | 追加到 `references/{rules,pitfalls,env,scripts}.md` 末尾的 2.0.0 一节（不改原文） |
| `prompts/` | `PROMPTS.md`（一览与以后怎么改）、`P1-压缩恢复.md`、`P2-判断窗.md`、`P3-临时加任务.md`、`P-skill升级.md` |
| `SHA256SUMS` | 本包每个文件的 sha256 |

**不在包里、保持你机器上原样的**：其余 skill 文件（`references/` 其他篇、`scripts/` 其他脚本、附加件除 wait_event.py 外的全部、`tools/key_window.py`、`tools/gpu_lock.sh`）。它们本来就是你本机的逐字节原版；本包只改上面列的文件，避免用转换过的副本覆盖原版。

文件里的 `@ORCH_HOME@` 是本机用户目录的占位，`install.py --home <目录>` 时写成真实路径。

## 理解 2.0.0：三个角色、一条主循环

```
              研究者
                │ 只和主窗说话
        ┌───────▼────────┐  事件：orch_alert（升级）/ orch_attention（子窗要你决定）/ orch_result（结果、预案、判断结论）
        │ 主窗：只掌控全局 │◄──────────────────────────┐
        │ health·判断·转告 │                           │
        └───────┬────────┘                           │
     orchd.py judge / drop / add / prio / ack         │
                ▼                                     │
   ┌──────────────────────────────────────────┐      │
   │ orchd daemon（脚本，不调用模型）            │──────┘
   │ 唯一分卡者：优先级 + 强制依赖，动态、不估时长 │
   │ 启动 job、确认真开始、每 3 s 核查、卡时账     │
   │ 自动开关：工作窗 / 修复窗 / 验收窗 / 判断窗   │
   │ 预案：if_fail、fallback_for；全局保护        │
   └───────┬───────────────────────┬──────────┘
      gpu-job / cpu-job        子窗 ×N（一事一窗、做完关窗、上下文卡）
     （cellrun 按租约并行跑格）  GPU 命令经 orchd.py exec
```

- **分卡**（研究者 2026-11-13）：
  - CPU 任务依赖一满足就跑；
  - GPU 任务按“有多少任务依赖它”排优先级，相同时先放长链的头、再随机；
  - 每个任务取此刻放得下的最优先一档：能用 8 卡加速就 8 卡，只能用 1/2/4 卡就给那么多，余卡给下一个；
  - 被挡太久的高优先级任务开启动保护，只抢占可抢占的任务；
  - 不用预计时长：任务早结束、晚结束、失败，都不会打乱安排。
- **核实**：启动确认三项都有才算真开始。之后每 3 秒查：分了卡没进程、分 4 用 2、占着卡没真开始、有进程但空转、进程跑错卡、卡上有无主进程、有空卡有任务却没发。汇报里“在跑”的必须核查为 `ok`。
- **异常**：
  - 任务包预先写好修不好怎么办（`if_fail`）、备选方案（`fallback_for`）；
  - 运行中的变化（不可执行、缺前序、优先级要变、坏卡、磁盘满）都有对应的命令与处理表（`MANUAL.md` 第 6 节）。
- **隔离**：每个任务一个槽位、一段端口、一个 ray 临时目录；cellrun 再给同时跑的格各分一小段。进程带标签，`orchd.py kill` 只停自己的。
- **上下文**：
  - 主窗（L 档 840k）只在有事时醒，一个包全程约 15 万 token，一般不压缩；
  - 子窗一事一窗，交报告后等这一轮结束才关，会话号记下；
  - 窗消失、key 失效、重试都接着原会话；做完的任务要追问用 `orchd.py reopen`。
- **优先级**：由依赖算出，含“谁要这些结果”的里程碑；有人在等的决定点排在最前。

细节：

- `MANUAL.md`：使用手册；
- `references/orchd.md`：规则、判据、命令全表；
- `references/main-loop.md`：主窗每一步的命令；
- `references/package-contract.md`：任务包怎么写。

## 以后怎么用

- **每一轮**：任务包里带一份填好的调用 Prompt（`skill/P-主窗调用.md`：第一节随包，其余是通用骨架），研究者原样发给主窗。主窗上下文被压缩后用 `prompts/P1`；要判断的事按 `prompts/P2` 开判断窗；研究者临时的要求按 `prompts/P3`。
- **任务包**：按 `references/package-contract.md` 写 `state/manifest.json`（orch-manifest/2）。要点：
  - 写全依赖、档位（能并行的写多档，独立的格用 cellrun）、令牌；
  - 写启动证据、完成判据、门控分支、预案与备选；
  - 写包自己的 `run_env`、`brief`；
  - 不写预计时长。
- **汇报**：R19 的六行。第 3 行“用卡”必须有 `orchd.py util` 的数字：真在用、启动开销、空卡各类。
- **skill 自己会变好**（R29）：
  - 任何窗遇到 skill 本身的问题，就 `skill_feedback.py add` 记一条；
  - 每次回传都带 skill 问题的导出；
  - 研究者一侧据此出下一版升级包（格式见 `references/evolution.md` 第 5 节），改代码的规矩与陷阱见第 7 节，云端照 `UPGRADE.md` 装；
  - 运行中不改 skill（紧急热修见 evolution 第 3 节）。

## 已验证

- **本地（无 GPU）**：
  - `tests/orchd_sim.py` 192/192：分配、抢占、启动确认、核查、自动派窗、判断窗、预案与备选、运行中改计划、全局保护、子窗看护、cellrun、里程碑与优先级、子窗的一生与 resume、接口失败、主窗的等待；
  - 用 v4.1 的 manifest 在假 8 卡上模拟（`tools/plan_sim.py`）。
- **安装器**：在 1.7.0 的副本上跑 `install.py`，写入、追加、wait_event.py 两处改动成功；回滚后逐字节回到 1.7.0。其余测试与升级前基线一致：本机无 nvidia-smi、无云端路径，升级前就过不了那几项，云端应当全过。
- **没有在真 GPU、真 tmux、真 claude 上跑过**：所以 `UPGRADE.md` 第 4 步有一个约 15 分钟的上线冒烟，过了再用于实验包。还要云端确认的几项见 `REQUIREMENTS.md` 最后一节。
