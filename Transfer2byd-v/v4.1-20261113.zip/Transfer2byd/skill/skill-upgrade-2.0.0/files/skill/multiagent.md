# 主 skill 调用 Prompt（multi-agent-orchestrator 2.0.0 的通用骨架）

> 怎么用：
>
> - **每个任务包只重填第一节**（包里的 `skill/P-主窗调用.md` 已经按该包填好，研究者原样发给主窗）。
> - 第二至六节是通用的，不随任务包变。通用的规则写在 skill 里（SKILL.md 与 `references/manual.md`），这里只提醒每次都要做的几件事。
> - 改动这份骨架时：通用部分改 skill 并升版本；包特有的只写进第一节。

请使用 multi-agent-orchestrator skill 执行以下任务。

- skill 路径：`@ORCH_HOME@/.claude/skills/multi-agent-orchestrator/SKILL.md`。开跑前先读全；版本必须 ≥ 第一节写的最低版本，`python3 -I $S/orchd.py help` 能打印才算装好。
- 优先级按 skill 的 R02：安全硬约束 > 任务包自带的执行规则（包内 `AGENTS.md`、`docs/`、路线卡、`state/manifest.json`）> 本 Prompt 的输入项 > 本 skill 的其他默认做法。
- 认为某条规则在当前情况下明显不合理时，**先照规则做**，再在汇报第一行写「需要你决定：……」，不许自行改判。
- 路径前缀：`S=@ORCH_HOME@/.claude/skills/multi-agent-orchestrator/scripts`；`A=@ORCH_HOME@/skill/skill-addons/orch-v1/scripts`。

## 一、本轮任务与任务包（每个任务包重填这一节）

- 任务包：`<zip 路径>`，VERSION = `<版本 日期>`。解压到 `<目录>`（记作 `PKG`），解压后设只读。
- 任务目录（记作 `TD`）：`<目录>`。与以前各轮的任务目录并列，不覆盖、不改写。
- 运行根（记作 `RT`，包规定的结果位置）：`<目录>`。结果写在哪个子目录照包内规定。
- tmux 会话（记作 `SES`）：`<会话名>`；子窗工作目录 `@ORCH_HOME@`。
- 本机交付目录：`<目录>`。
- 最低 skill 版本：`<版本>`。不够时先照 `PKG/skill/需要的skill版本.md` 升级：另开一个窗做，升级报告交给我之后再开工。
- 版本校验：解压后先读 `VERSION` 与 `CHANGELOG.md`，与上面写的不一致时先告诉我，不许自己判断。
- 本轮特别提醒（包特有的：哪些老任务靠 `done_if` 直接判完成、环境任务、回传几次与文件名……）：
  1. `<…>`

## 二、开工（通用）

照 skill 的 `references/main-loop.md` 第 1 节逐条做：

1. 版本校验；
2. 写 `TD/notes/orch.env`（写了它 orchd 就自动派窗）与 `checks.json`；
3. `orchd.py init --td $TD --manifest $PKG/state/manifest.json --pkg $PKG --runtime $RT --lockdir @ORCH_HOME@/Benchmark/_overnight/gpu_locks --session $SES`，`--lockdir` 与 `tools/gpu_lock.sh` 同一个目录；
4. 在 tmux 窗 `orchd` 用 1.4 节带自动重启的命令起守护；
5. 覆盖表与扫描；
6. 看板（照包内说明）；
7. `orchd.py health` 退 0，再在后台挂上 `orchd.py wait`（第三节），才算开工完成。

开工后，全脚本化的任务由 orchd 自己跑，要判断的任务由 orchd 自动开窗承接，**你不派任何任务**。

## 三、你只掌控全局（通用，R22、R31）

1. **唯一的等待**（Bash `run_in_background`，同一时刻只挂一个）：`python3 -I $S/orchd.py wait --td $TD`。巡检在它里面每分钟做一次，不进你的上下文；它只在有事时返回，只打印十几行。**不要 `sleep`、不要 ScheduleWakeup、不要自己定时去看**（旧的 10–180 秒睡眠区间只适用于没有 orchd 的手工模式）。
2. **它返回时**按退出码做：
   - 退 3（定时汇报，没事）：不用汇报，直接重挂；
   - 退 2（守护没在跑）：照 `references/main-loop.md` 1.4 重起守护（不要 init），重挂；
   - 退 0 或 1：逐条照它写的办法与 `references/manual.md` 第 6 节的表处理。处理完 `orch_check.py`，`orchd.py ack` 处理过的告警，重挂。
3. **要判断的事**开判断窗，不自己读证据：`python3 -I $S/orchd.py judge --td $TD <短名> --question "<告警原文>；请判断……并给出完整命令" [--about <任务>]`。它交结论时会叫醒你。
4. **子窗要我决定的问题**（`orch_attention`）原话转给我，附窗名与任务号，不改写、不替我答。我答了就 `winctl.sh send <窗> "研究者答复：<原话>"`。
5. **结果就绪**（输出里的 `[结果就绪]`）一句话告诉我。我追问某个做完的任务时：`python3 -I $S/orchd.py reopen --td $TD <任务> --question "<我的原话>"`，它会接着那个任务的原会话回答。
6. **不做**：
   - 读日志全文与子窗对话、排障、改代码、跑实验、挑卡、手设 `CUDA_VISIBLE_DEVICES`；
   - 手写任务书、手工开关工作窗、`sleep` 轮询；
   - kill 进程（只在第 6 节的表让你停时用 `orchd.py kill <任务>`）。
7. **核实真在用卡**（R24、R34）：汇报里写“在跑”的任务核查必须是 `ok`，并且已确认真开始（有启动用时）；空卡只允许是 `util` 列出的五类正常原因。

## 四、异常与变更（通用，R36）

- 先看任务包有没有写预案（`if_fail`、`fallback_for`、门控分支）。有就由 orchd 照做，你只告诉我结果。
- 运行中改计划只用 orchd 的命令：`drop`、`add`、`dep`、`prio`、`edit`、`cordon`、`config`、`hold`、`accept`、`retry`。
  - 每条都写 `--reason`；orchd 会记进 `notes/decisions.md`；
  - 会改变研究方向或取舍的（放弃核心任务、改主实验的配置），先问我。
- 表里没有的情况开判断窗，照它建议的完整命令做。拿不准就问我。

## 五、任务细节（通用）

1. **包只读、产出分开**：
   - 任务目录只放 `notes/`、`briefs/`、`output/`、`work/`；
   - 实验数据按包内规定写到运行根，不与旧版结果同名。
2. **接手不重建**：续跑或压缩恢复后按 skill 的 Prompt P1 做（restore_card → health → decisions），**不要重新 init**。守护心跳过期就按 `main-loop.md` 1.4 重起。
3. **包内脚本不改逻辑**：
   - 按包里的冒烟 → 正式推进，只改包内点名可调的参数，并记原值、新值与理由；
   - 环境不对时照包的环境任务新建隔离环境，绝不改现有环境（R32、R04）。
4. **弯路要记**：任何花了 10 分钟以上的非实验问题，子窗报告里写“现象 → 根因 → 解法 → 下次怎么避免”；回传时收进包规定的弯路文件。
5. **skill 本身的问题当场记**（R29）：`python3 -I $S/skill_feedback.py add --td $TD --kind <bug|rule|gap|doc|perf> --where <R编号或脚本> --symptom "<现象原文>"`。运行中不改 skill。

## 六、回传与汇报（通用）

- 回传规范**以包内为准**：回传规则、文件清单、自检脚本。本 Prompt 不重复文件清单。
- 回传前跑包自带检查器，把命令、退出码和最后几行原样贴进汇报。
- 每次回传都带三样，文件名照包内：
  - 卡时账：`orchd.py util --csv`，或包内的卡时账脚本；
  - 弯路记录；
  - skill 问题：`skill_feedback.py export` 生成，没有问题也交，写“无”。
- 包内分多次回传的，各次按包内规定的时点独立交，不合并、不互相等待。回传开独立承办窗、验收开独立验收窗，验收通过才交给我（R12、R20）。
- 汇报按 R19 的六行格式。第 3 行“用卡”必须有 `orchd.py util` 的数字：真在用、启动开销、空卡各类。
