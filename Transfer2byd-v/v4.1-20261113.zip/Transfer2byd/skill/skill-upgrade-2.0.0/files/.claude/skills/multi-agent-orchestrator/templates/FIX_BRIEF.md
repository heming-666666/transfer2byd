# 修复任务书：fix-<任务> / 告警 #<号>

> 主窗收到 `orch_alert` 后复制本文件到 `briefs/fix-<任务>.md`，填好前 6 项，用
> `winctl.sh open fix-<任务> <本文件> --fix <任务>` 开窗。你（修复窗）只管这一件事，做完交报告、窗会被关掉。

1. 告警原文：<orchd.py status 里那一行，原样粘贴>
2. 任务：<任务 id>；路线卡：<PKG/routes/...>；manifest 里的命令：<cmd>
3. 证据路径：运行目录 <run_dir>（`console.log`、`spec.json`、`exit.json`），包内启动器的 `run.log`/`progress.json`：<路径>
4. 上下文卡：<TD>/notes/ctx/fix-<任务>.md（先读；上一扇修复窗做过的，接着做，不重做）
5. 允许改什么：只改路线卡点名可调的参数、环境变量、启动参数；改了什么写进上下文卡和报告（原值、新值、理由）。**不改包内脚本逻辑。**
6. 时间上限：<默认 60 分钟>；到时没修好就报「受阻」，写清已排除了什么。

## 怎么做

- 先读证据，按 `references/issues.md` 的失败五分类定性（瞬时 / 资源冲突 / 确定性 / 环境权限 / 未知），把判断写进上下文卡。
- 要在 GPU 上复现：**不要自己挑卡**。`orchd.py add --td <TD> --json '{"id":"DBG-<任务>-1","kind":"gpu-agent","gpu_options":{"1":0.3},"deps":[]}'`，等主窗把它派给你（或你所在的窗被 `orchd.py start DBG-... --window <本窗>` 登记），再 `orchd.py exec DBG-<任务>-1 -- <命令>`；用完 `orchd.py done DBG-<任务>-1`。
- 要停这个任务的进程：只用 `orchd.py kill <任务>`。看见别的进程（标签不是这个任务）一律不碰，写进报告。
- 修好之后：`orchd.py retry --td <TD> <任务>`（gpu-job 会被 orchd 重新分卡启动；agent 任务会重新预留，由主窗派窗）。
- 确认告警是正常现象（例如加载 70 GB 本来就要 20 分钟）：报告里写依据，并建议主窗 `ack`，同时建议 manifest 默认值（例如 `warmup_s`）下一版怎么改。

## 交报告

照 `templates/WORKER_REPORT.md`；同时写事实：

```bash
python3 -I <ADDONS>/facts.py emit --log <TD>/notes/facts.jsonl report id=fix-<任务> state=<完成|受阻> window=<窗> evidence="<上下文卡>;<改动记录>"
```

报告里必须有一段「给后来者的经验」：现象 → 根因 → 解法 → 下次怎么避免（回传窗会把它收进回传的弯路记录）。

**遇决策默认选推荐项继续，绝不反问人工。**
