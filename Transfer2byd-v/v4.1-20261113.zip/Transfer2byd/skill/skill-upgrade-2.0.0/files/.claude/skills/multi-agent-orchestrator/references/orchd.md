# orchd：分配、启动确认、核查、卡时账、命令全表

> 对应 R14、R15、R22–R25、R34–R36。
>
> - 脚本 `scripts/orchd.py`，只用标准库（Python ≥ 3.8）；帮助 `orchd.py help`。
> - 测试 `python3 -I tests/orchd_sim.py`：假 nvidia-smi、假实验、假 tmux、假 winctl，不要 GPU，192 项。
> - 出了状况怎么办见 `references/manual.md` 第 6 节。

## 1 为什么由脚本分配

v4 现场 7 个问题里，5 个是“分配与核查分家”造成的：

| v4 问题 | 机制上的原因 | orchd 怎么挡 |
|---|---|---|
| 1 卡已分出但没人用（6 张卡显存 0） | 包内租约和 skill 的锁两套账；判空只看显存 | 只有一套锁（同一个 `gpu_lock` 目录）。空卡 = 无锁 ∧ 无租约 ∧ 无计算进程 ∧ 显存低于阈值 ∧ 没被 `cordon`。启动确认（第 4 节）+ 核查：分了卡没用会报 `not_on_gpu` / `no_start` |
| 2 子窗 fork 反复 kill 别窗的 teacher | 进程没有归属标记 | 每个进程带 `ORCH_TASK`、`ORCH_RUN`、`ORCH_INST` 标签；`orchd.py kill` 只停带本任务标签的进程；R25 |
| 4 ray job agent 端口被并发 ray 抢 | 所有任务用同一组默认端口 | 每个在跑任务一个槽位：`ORCH_PORT_BASE = port_base + slot × port_span`，独立 `RAY_TMPDIR`；cellrun 再给同时跑的格各分一小段 |
| 5 强杀后 tee 的日志变 0 字节 | tee 进程被杀时截断 | 包装进程自己逐行写 `console.log` 并 flush；停止先 TERM 后 KILL |
| 6 僵尸锁占了 4 张卡三天 | 任务退出不收锁 | 任务结束自动收锁；自己的残留锁自动收；别人的老锁只点名不收 |
| 7 占着卡空转（不出 step） | 只看“进程在、显存满” | 进度不动 + 利用率低于阈值超过 `stall_s` → `stall`；从没真开始 → `no_start` |
| 3 冻结脚本与本机版本不匹配 | 环境问题，不是调度问题 | 包的环境任务（R32）；启动阶段失败单独标出，修复窗先查环境 |

## 2 分配：动态、不用预计时长（每 3 秒一轮，R15）

1. **就绪**：以下全部满足。
   - `deps` 都成功。`"A|B"` 只要 A、B 其中一个成功。
   - `after` 都结束（成功、失败、跳过都算）。
   - `gate` 的门控结论符合。
   - 没被 `hold`。
   - 备选任务（`fallback_for`）还要求主任务失败已成定局、或被放弃。
2. **跳过**：出现下列情况，任务记为 `skipped`，并沿依赖传播。
   - 门控结论不符合；
   - 强制前序被跳过、或失败已成定局（accept）。写在 `deps_optional` 里的前序例外。
   - 备选的主任务成功了，或主任务因门控、依赖被跳过。
3. **CPU 任务**：
   - `cpu-job` 一就绪就启动，同时最多 `cpu_slots` 个；
   - 带资源令牌的 CPU 任务等 GPU 分配之后再看令牌冲不冲突；
   - `cpu-agent` 一就绪就自动开窗。手工模式下改为发 `orch_sched` 事件。
4. **GPU 任务的先后**：
   - 优先级 = 自己的 `prio_boost` + 所有直接或间接依赖它的节点的分量之和，大的先。分量：任务 1 + 正的 `prio_boost`（正加成向上游传）；里程碑 `weight`（默认 1）；有人在等的里程碑（`waiting_human`）= 全部任务分量之和 + 1；
   - 同级比“下游最长依赖链的任务个数”；
   - 再按 `seed` 稳定随机，跨轮不变。
5. **卡数**：`gpu_options` = {卡数: 偏好}。值越小越优先（可写名次，也可写以前的实测时长，只用来排序）；值一样时卡少的在前。
   - 全没写值（`null`）时卡多的在前：能用 8 卡加速就给 8 卡。
   - `strict_tier: true` 只认首选档，例如计时实验的卡数是控制变量。
   - 取此刻放得下的最优先一档；余卡继续给下一个就绪任务。**有放得下的就绪任务就不让卡空着。**
6. **启动保护**（防饿死）：
   - 被挡住的最高优先级任务进入启动保护，比它低、又不可抢占的任务暂不占它要的卡与令牌。
   - 有下游链的任务（有任务经 `deps` 强制依赖它，或喂给有人在等的里程碑，或 `prio_boost` > 0）**马上**保护（`hold_after_s`，默认 0）：它晚一步，后面整条链都晚；普通里程碑不算“链”（没有会被拖的任务）。
   - 叶子任务等满 `leaf_hold_after_s`（默认 21600 秒）才保护：它晚跑不拖别人，空卡先给放得下的任务，不让卡白空着。
   - 逐任务写了 `hold_after_s` 的，以任务的为准。
   - **马上就绪的任务**：比当前任务优先、只差正在跑的 CPU 小步骤（例如门控判定）的 GPU 任务，也先留卡，最多 `imminent_hold_s`（300 秒），不触发抢占。由来：模拟门 BW = fail 的情形时，门控判定的那几秒里 Q0 拿走了整机，研究者等着的探针被推后 0.8 小时。
   - 由来：本机模拟时，有下游链的独占任务按旧规则等了 30 分钟才保护。这段时间里，一个低优先级任务用小档占了余卡、跑了 4 小时，独占任务因此晚了 2.6 小时，期间 6 张卡空着。反过来，给叶子任务马上保护，又会让放得下的小任务白等。
   - `preemptible: true` 的 `gpu-job` 照样可以先用这些卡。等停掉它们就能让被保护任务起跑时，orchd 发 TERM 抢占。
   - 被抢占的排回队列（`wait`，不算失败）。在抢占者起跑之前不会重启，不会来回抢。
   - 被保护的任务只被可抢占任务挡着时，不再放新的可抢占任务进来，免得刚起就被停、白付启动开销。
7. **资源令牌**：`res` = {令牌: "x" | "s"}。
   - 同名令牌，`x` 与任何持有者互斥，`s` 与 `s` 共存；
   - 每个 GPU 任务默认带 `machine:s`，所以 `machine:x` 就是整机独占。

   常用：

   | 令牌 | 用于 |
   |---|---|
   | `{"machine": "x"}` | 整机安静：端到端吞吐、P95、能耗的正式对比 |
   | `{"hostbw": "x"}` | 只怕主机内存带宽或 PCIe 争用：教师流式、换入换出、带宽探针 |
   | `{"hostbw": "s"}` | 用主机带宽，但能与同类共存 |
   | `{"disk": "x"}` | 大量读写模型文件 |

8. **分区**：`partition: "A"` 只从 manifest `partitions` 的 A 区挑卡。
9. **启动**：
   - `gpu-job`、`cpu-job`：在 tmux 窗 `j-<任务>` 里启动，命令外面套 `_run` 包装；没有会话就脱离启动。
   - `gpu-agent`：先预留卡，自动派窗模式下开工作窗；预留 `reserve_ttl_s` 内没人接手就收回、告警，冷却后再预留。
10. **全局暂停**：磁盘余量低于 `disk_min_gb`，或主窗 `config --set paused=原因`，就不启动任何新任务；在跑的不动。空卡记“暂停启动”。
11. **进度推算的剩余时间**（`progress_eta_t`）只给看板与巡检看，不参与任何分配。

## 3 运行环境（每次运行都有）

| 变量 | 值 |
|---|---|
| `CUDA_VISIBLE_DEVICES`、`ORCH_GPUS`、`ORCH_NGPU` | 租到的卡（`CUDA_DEVICE_ORDER=PCI_BUS_ID`，与 nvidia-smi 编号一致）；CPU 任务 `CUDA_VISIBLE_DEVICES=""` |
| `ORCH_TASK`、`ORCH_RUN`、`ORCH_INST` | 任务号、运行号、编排实例（进程归属靠它们） |
| `ORCH_SLOT`、`ORCH_PORT_BASE`、`ORCH_PORT_SPAN` | 槽位与端口段（默认 21000 + 200 × 槽位，段长 200） |
| `ORCH_TMP`、`RAY_TMPDIR` | 本槽位的临时目录 |
| `ORCH_RUN_DIR` | 本次运行目录（`console.log` 在这里） |
| `ORCH_STARTED` | `$ORCH_RUN_DIR/.started`：任务确认实验真开始时 `touch` 它（可选，最可靠的启动证据） |
| `ORCH_PROGRESS` | `$ORCH_RUN_DIR/progress.json`：任务可以写 `{"step":…, "steps_total":…, "last_step_s":…}`（cellrun 自动写） |
| `ORCH_PKG`、`ORCH_RUNTIME`、`ORCH_TD`、`ORCH_BIN` | 包根、运行根、任务目录、orchd.py 的路径 |
| `ORCH_EXEC=1` | 只在 `orchd.py exec` 里：cellrun 据此默认不还卡 |
| manifest 顶层 `run_env` 与条目的 `env` | 包自己的变量名，原样加上。占位符 `{PKG}` `{RUNTIME}` `{TD}` `{ID}` `{INST}` `{GPUS}` `{NGPU}` |

命令（`cmd`、`cwd`）里可以用占位符 `{PKG}` `{RUNTIME}` `{TD}` `{GPUS}` `{NGPU}` `{RUN_DIR}` `{ID}`。路径模式（`done_check`、`done_if`、`progress`、`started_if`）里可以用 `{RUNTIME}` `{PKG}` `{TD}` `{RUN_DIR}`。

**端口怎么用**：包内脚本从 `ORCH_PORT_BASE` 往上排，只要每个任务都从自己的端口段取，并发的 ray、SGLang 就不会互相抢。例如：

| 偏移 | 用途 |
|---|---|
| +0 | ray head |
| +1 | dashboard |
| +2…+8 | ray 的各服务端口 |
| +20…+59 | SGLang、教师服务 |
| +100…+199 | ray worker |

ray 一个集群要约 200 个端口。cellrun 让几格同时跑时，每格只分到 `port_span / 并发数` 个端口。格里要起 ray 的，manifest 把 `sched_defaults.port_span` 调大，例如 4 格并发 × 200 = 800，并保证 `port_base + max_slots × port_span < 65535`。

## 4 启动确认（R34，研究者 2026-11-13 的思路）

三项都满足才记“真开始”：

1. **进程真起来并占住资源**：
   - GPU job：租到的每张卡上都有它的进程；
   - agent 任务或 `allow_partial`：至少一张卡上有；
   - CPU job：包装进程在。
2. **连续占用 `start_hold_s` 秒**（默认 30，可逐任务写）。
3. **实验真开始的证据**，按顺序有一项就算：
   1. `$ORCH_STARTED` 存在（agent 任务看每次 exec 的运行目录）；
   2. `started_if`：路径模式列表，任一文件在本次派发之后出现；
   3. `started_log`：正则，在 `console.log` 的最后 256 KB 里出现；
   4. 进度文件在开始占用之后有变化：manifest 的 `progress`，以及 `$ORCH_PROGRESS`；
   5. 包什么都没声明（没写 `started_if`、`started_log`、`progress`）时：GPU 任务持续计算（利用率 ≥ `util_min`）满 `start_hold_s`；CPU 任务进程持续在跑。

结果：

| 情况 | orchd 怎么做 |
|---|---|
| 确认之后 | `confirmed_t`、`startup_s` 写进状态；事实流记 `task_set`（“真开始：派发后 N 秒确认 …”）；从此利用率才计入“真在用” |
| 确认之前 | 卡时计入“启动开销”；状态写 `start_stage`（等进程上卡 / 已占用 n/30 秒 / 已持续占用，等实验真开始） |
| 确认之前就非 0 退出 | 失败原因前面加“启动阶段失败（还没确认真开始就退出：多半是环境、路径、参数、端口或显存问题）” |
| 过了启动时限还没确认 | 时限是 job 的 `warmup_s`，agent 任务是距派发或上次 exec 结束的 `agent_idle_s`。卡上没进程报 `not_on_gpu`，部分卡上有报 `partial`，都有但没有开始证据报 `no_start` |

写包时：

- 加载很久的任务写 `progress`，或第一步算完时 `touch "$ORCH_STARTED"`；
- `warmup_s` 设成正常加载时间的 2–3 倍。

## 5 核查判据（每轮，写进 status 的“核查”列）

| 判定 | 条件 | 告警 | 自动模式下谁处理 |
|---|---|---|---|
| `loading` | 启动时限内还没确认真开始 | 否 | — |
| `ok` | 已真开始，卡上有它的进程，利用率或进度在动 | 否 | — |
| `gap` | agent 任务已真开始，两次运行之间卡上暂时没进程（未超过 `agent_idle_s`） | 否 | — |
| `reserved` | 已预留、等工作窗接手 | 否 | 超时收回并告警 |
| `no_start` | 过了启动时限，占着卡但没有任何真开始的证据 | 是 | agent：告警原文发进它的窗；job：告警持续 5 分钟后开修复窗 |
| `not_on_gpu` | 启动时限过后卡上没有它的进程；或真开始后进程没了持续 `lost_s`（默认 120） | 是 | 同上 |
| `partial` | 只有部分租到的卡上有它的进程（启动时限后；真开始后持续 `lost_s`）；`allow_partial` 的不判 | 是 | 同上 |
| `stall` | 真开始后利用率持续低于 `util_min` 且进度不动超过 `stall_s` | 是 | 同上 |
| `stray` | 它的进程出现在没租给它的卡上 | 是 | 同上 |
| `untagged` | 租到的卡上有不带标签的进程（命令没走 `orchd.py exec`） | 是 | 同上 |
| `rogue` | 卡上有计算进程但没有任何租约 | 是 | 升级：只读排查，不 kill |
| `orphan` | 已结束任务的残留进程 | 是 | 宽限 `orphan_grace_s` 后按标签自动收 |
| `stale_lock` | 别人的锁，锁龄 > 1 h、卡上零显存零进程 | 是 | 升级 |
| `idle_waste` | 有空卡、有就绪任务，却因可避免的原因超过 `idle_alert_s` 没发 | 是 | 升级 |
| `failed` | 非 0 退出（重试用完）、被停、退出 0 但 `done_check` 的产物不在、子窗报受阻 | 是 | 修复窗 → 预案 → 升级 |
| `disk`、`gpu_lost`、`overtime`、`smi`、`pidns`、`orchd_error` | 磁盘不足、掉卡、超过 `max_h`、nvidia-smi 连续失败、进程号空间不一致、守护本轮异常 | 是 | 升级（`pidns` 只是提示） |

**归属怎么判**：

- 读 `/proc/<pid>/environ` 里的 `ORCH_TASK`、`ORCH_RUN`、`ORCH_INST`，只取这几个键；读不到时沿父进程链找包装进程。
- 包装进程设了 child-subreaper。ray、SGLang 之类自己 daemonize 的孙进程也挂在它下面，退出时一并回收。
- 采样失败（nvidia-smi 超时）的那一轮不下任何结论。

## 6 卡时账（`orchd.py util`、`util --csv`）

| 类别 | 键 | 含义 | 应该是 |
|---|---|---|---|
| 真在用 | `used_s` | 已真开始、卡上有本任务进程、利用率 ≥ 阈值 | 越高越好 |
| 启动开销 | `startup_s` | 派发或预留到确认真开始：开窗、加载、编译、预热 | 写进论文的“系统开销”；偏大就查加载 |
| 租而未用 | `alloc_idle_s` | 真开始后空转、两次运行之间、CPU 阶段 | 持续偏高查 `stall` |
| 空卡：启动保护凑卡 | `idle_reserved_s` | 为被挡太久的高优先级任务留卡 | 少量 |
| 空卡：暂停启动 | `idle_paused_s` | 磁盘不足或主窗暂停 | 只在出事时 |
| 空卡：令牌等待 | `idle_token_s` | 计时任务要安静窗口 | 测量有效性的代价，写进汇报 |
| 空卡：余卡不够 | `idle_fit_s` | 剩下的卡不够任何就绪任务的最小档 | 少量 |
| 空卡：没有就绪任务 | `idle_noready_s` | 依赖或门控没到 | 只在关键路径上 |
| 空卡：可避免 | `idle_avoidable_s` | 加锁失败、没接预留、槽位用完 | **0**；不为 0 要查 |
| 别人占用 | `other_s` | 他人锁、看不见进程的显存、停用的卡 | 写进汇报 |
| 采样失败 | `unknown_s` | nvidia-smi 不可用的那几轮 | 少量 |

## 7 命令全表

| 命令 | 谁用 | 做什么 |
|---|---|---|
| `init --td TD --manifest M --pkg PKG --runtime RT --lockdir L --session SES [--set k=v]` | 主窗开工一次 | 读 manifest（校验依赖存在、无环、id 不重复），全部任务进事实流；已初始化过就拒绝（`--reinit` 才重建） |
| `daemon --td TD` | tmux 窗 `orchd` | 守护循环；一个任务目录只允许一个 |
| `health --td TD` | 主窗每次醒来 | 一条命令看全局；退 1 时逐条写了要做什么 |
| `status --td TD [--all\|--json]`、`util --td TD [--csv F]`、`check --td TD` | 主窗、判断窗 | 短表、卡时账、门禁 |
| `env --td TD ID`、`exec --td TD ID [--name N] -- 命令…` | 子窗 | 看租约；在租约内跑（无租约退 4） |
| `start`、`done`、`fail`、`fixwin` | winctl 与子窗自动用 | 承接、完成、失败、登记修复窗 |
| `ask --td TD ID --question "…"` | 子窗 | 一个要研究者决定的问题（主窗原话转达） |
| `wait --td TD [--timeout 秒]` | 主窗（后台挂着，唯一的等待） | 巡检每分钟在里面做、不进主窗上下文；只在有事时返回十几行：0 事件、1 巡检问题、2 守护没在跑、3 定时汇报 |
| `judge --td TD 短名 --question "…" [--about ID]` | 主窗 | 开判断窗；结论交了发 `orch_result kind=judge`，这一轮结束后关窗 |
| `reopen --td TD ID --question "…" [--fresh]` | 主窗 | 做完的任务还要用：resume 它的原会话开跟进窗 `fu-<任务>-<n>`；交了回答发 `orch_result kind=followup` 并关窗 |
| `retry --td TD ID` | 修复窗、主窗 | 失败、放弃、跳过的任务放回队列；因它跳过的下游要一并 retry |
| `accept --td TD ID --reason …` | 主窗 | 失败照实交：严格下游跳过，`after`、`deps_optional` 放行，备选就绪 |
| `drop --td TD ID --reason …` | 主窗 | 确实不可执行或决定不做：记为跳过（在跑的先 `kill`） |
| `add --td TD --json '{…}' [--reason …]` | 主窗、修复窗 | 临时加任务（依赖必须已存在） |
| `dep --td TD ID --add X\|--remove X [--after] --reason …` | 主窗 | 加或去掉前序（`X` 可以写成 `"A\|B"`）；会成环就拒绝 |
| `prio --td TD ID --boost N --reason …` | 主窗 | 改优先级加成 |
| `edit --td TD ID --set 字段=JSON … --reason …` | 主窗 | 改排程字段（`prio_boost` `gpu_options` `res` `deps` `after` `deps_optional` `strict_tier` `preemptible` `hold_after_s` `warmup_s` `stall_s` `util_min` `allow_partial` `retries` `partition` `notify` `gate` `if_fail` `max_h` `start_hold_s` `lost_s` `started_if` `started_log`）；`cmd` 之类不能改 |
| `cordon / uncordon --td TD 0,3 --reason …` | 主窗 | 停用 / 恢复某几张卡 |
| `config --td TD --set k=v --reason …` | 主窗 | 运行中改守护设置（`max_windows`、`max_fix`、`hold_after_s`、`disk_min_gb`、`paused`…），下一轮生效 |
| `shrink --td TD ID --gpus 2,3 [--reason …]` | cellrun 自动、子窗 | 把租约里用不上、且没有本任务进程的卡还给调度（至少留一张） |
| `hold / unhold --td TD ID` | 主窗 | 暂停 / 恢复调度某任务 |
| `gate --td TD 门 pass\|fail [--evidence …]` | 门控判定任务 | 写门控结论；不满足的分支自动跳过 |
| `kill --td TD ID [--grace 30]` | 只在第 6 节的表让你停时 | 只停这个任务自己的进程 |
| `ack --td TD 号\|all` | 主窗 | 确认告警，不再重复叫醒 |

## 8 自动派窗（写了 `notes/orch.env` 就打开）

| 时机 | orchd 做什么 |
|---|---|
| gpu-agent 预留到卡、cpu-agent 就绪 | `brief.py task` 生成任务书，`winctl.sh open w-<任务> … --task <任务>`（不超过 `max_windows`） |
| 任务失败或子窗报受阻 | `brief.py fix`，开 `fix-<任务>-<n>`，最多 `max_fix` 次。用完：包写了 `if_fail` 就照预案（`accept`/`drop`，并发 `orch_result` 告诉研究者），没写就升级为 `fix_exhausted` |
| agent 任务交“完成” | `brief.py audit`，开 `au-<任务>`；验收 fail 升级为 `audit_fail` |
| 在跑任务出用卡问题 | agent：告警原文发进它的窗；job：告警持续 5 分钟后开修复窗 |
| 子窗报告带 `attention`，或 `orchd.py ask` | 发 `orch_attention`，主窗原话转给研究者 |
| 已结束任务的残留进程 | 告警满 `orphan_grace_s` 后按标签收掉 |
| 子窗消失 | 工作窗：保留租约，按上下文卡重开（`max_win_restarts` 次），再消失判失败；修复窗、验收窗：允许重开 |
| 子窗 `win_idle_s` 没输出 | 发一次提醒；下一个周期仍没动静升级为 `win_idle` |
| 任务结束、修复交了报告、验收写了结论 | 等这一轮结束（hooks 的 Stop）或 `close_grace_s` 后关窗；winctl 送 `/exit`、收 key；会话号记进 `notes/sessions.jsonl` |
| 工作窗重开（窗消失、key 失效、任务重试） | 默认 `--resume` 原会话；上下文超限或原会话估计超过 `resume_max_tokens` 时开新窗 |
| 子窗这一轮因接口失败中断（StopFailure） | 限流、偶发错误：退避 `api_backoff_s` × 2^n 后发“接着做”；key 失效：换 key resume；上下文超限：开新窗；连续 `max_api_retries` 次升级 |
| 子窗压缩（PreCompact） | 记压缩次数，`health` 列出 |

## 9 守护本身

- **心跳过期**：
  1. `tmux capture-pane -p -t $SES:orchd | tail -30` 看报错；
  2. 用 `references/main-loop.md` 1.4 的命令重起，不要 `init`。

  1.4 的命令带自动重启循环，一般不用手工。状态在 `notes/sched/state.json` 里，不会丢。
- **一轮出异常**：守护不退出，写 `orch_alert kind=orchd_error`（同一错误 10 分钟内只报一次），日志在 `notes/sched/daemon.log`。
- **nvidia-smi 不可用**：连续 3 次失败才报 `smi`。期间不分 GPU、不下核查结论，CPU 任务照常。

## 10 主窗的等待与上下文预算（R11、R31、R37）

`orchd.py wait` 是主窗唯一的等待：

1. 它在后台挂着，每 2 秒看一眼 orchd 的事件文件。巡检每 `wait_health_every_s`（60 秒）做一次，与 `health` 同一套判据，都不进主窗上下文。
2. **叫醒主窗的（relay）**：
   - `orch_attention`（子窗要研究者决定的问题）；
   - `orch_alert`（要主窗决定的升级）；
   - `orch_result` 里的结果就绪（`kind=result`）、判断窗与跟进窗的结论；
   - 巡检发现的新问题；
   - 守护心跳过期。
3. **只记进摘要的（notice）**：
   - 任务结束；
   - 按预案处理（`kind=preset`）；
   - 门控结论（`kind=gate`）；
   - 里程碑达成（`kind=milestone`）；
   - 抢占通知。
   这一分法借自 SuperAgent：relay 进主会话的回合，notice 注入但不叫醒。
4. 同一件没处理完的事，`wait_realert_s`（1 小时）内不重复叫醒。
5. 没事时每 `summary_every_s`（2 小时）返回一次，给一行进展；主窗直接重挂。

按云端的模型档位定的数字（1.7.0 选档规则）：

| 窗 | 档位 | 上下文 | 预算 |
|---|---|---|---|
| 主窗 | L 档 | 配置 840k | 开工约 6–8 万 token；每次醒来 1–5k；一个约 25 小时的包全程约 15 万 |
| 子窗 | 默认 V_fast | 配置 280k，约 204k 自动压缩 | 一事一窗；resume 上限 `resume_max_tokens` 12 万 |

对比旧做法：

- 主窗按 10–180 秒睡眠醒来，一天醒几百到几千次。每次至少 1–2k token，几小时就要压缩一次，每压缩一次目标漂移一次（1.7.0 实测 +27.5%）。
- 2.0.0 初稿的等待会被每个子窗每一轮的 Stop 事件叫醒，6 扇窗时一小时几十次，同样会频繁压缩。
