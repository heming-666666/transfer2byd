#!/usr/bin/env python3
"""测试用假实验：fake_job.py <秒数> [--use K] [--util U] [--rc R] [--stray G] [--child] [--no-gpu] [--progress FILE]
                    [--idle-after S] [--mark-after S] [--load S]
在 CUDA_VISIBLE_DEVICES 的前 K 张卡上“占用”显存（写 apps 文件），睡够秒数后以 R 退出。
--idle-after S：S 秒后利用率降到 0、不再写进度（模拟真开始之后卡住）；--mark-after S：S 秒后 touch $ORCH_STARTED；
--load S：前 S 秒只占显存、利用率 0（模拟加载模型），之后才按 --util 计算。"""
import os, sys, time, signal, subprocess
a = sys.argv[1:]
secs = float(a[0]); use = None; util = 60; rc = 0; stray = None; child = False; nogpu = False; prog = None
idle_after = None; mark_after = None; load = 0.0
i = 1
while i < len(a):
    if a[i] == "--use": use = int(a[i+1]); i += 2
    elif a[i] == "--util": util = int(a[i+1]); i += 2
    elif a[i] == "--rc": rc = int(a[i+1]); i += 2
    elif a[i] == "--stray": stray = a[i+1]; i += 2
    elif a[i] == "--child": child = True; i += 1
    elif a[i] == "--no-gpu": nogpu = True; i += 1
    elif a[i] == "--progress": prog = a[i+1]; i += 2
    elif a[i] == "--idle-after": idle_after = float(a[i+1]); i += 2
    elif a[i] == "--mark-after": mark_after = float(a[i+1]); i += 2
    elif a[i] == "--load": load = float(a[i+1]); i += 2
    else: i += 1
d = os.path.join(os.environ["FAKE_GPU_DIR"], "apps"); os.makedirs(d, exist_ok=True)
cards = [c for c in os.environ.get("CUDA_VISIBLE_DEVICES", "").split(",") if c]
if use is not None: cards = cards[:use]
if stray: cards = cards + [stray]
files = []
def reg(pid):
    if nogpu: return
    for c in cards:
        p = os.path.join(d, "%d-%s" % (pid, c)); open(p, "w").write("GPU-fake-%s,20000,%d" % (c, 0 if load > 0 else util)); files.append(p)
def bye(*x):
    for p in files:
        try: os.remove(p)
        except OSError: pass
    sys.exit(143)
signal.signal(signal.SIGTERM, bye)
if child:
    # 模拟 ray：双 fork 出一个脱离的孙进程，也占卡（setsid 后父进程退出 -> 挂到 subreaper 下）
    pid = os.fork()
    if pid == 0:
        os.setsid()
        if os.fork() > 0: os._exit(0)
        files.clear(); reg(os.getpid())
        signal.signal(signal.SIGTERM, bye)
        while True: time.sleep(0.2)
    os.waitpid(pid, 0)
reg(os.getpid())
print("fake job on", cards, flush=True)
t0 = time.time()
idled = False
loaded = load <= 0
while time.time() - t0 < secs:
    el = time.time() - t0
    if not loaded and el >= load:
        loaded = True
        for p in files:
            c = p.rsplit("-", 1)[1]
            open(p, "w").write("GPU-fake-%s,20000,%d" % (c, util))
    if idle_after is not None and el >= idle_after and not idled:
        idled = True
        for p in files:
            c = p.rsplit("-", 1)[1]
            open(p, "w").write("GPU-fake-%s,20000,0" % c)
    if prog and not idled:
        open(prog, "a").write("step %d\n" % int(el))
    if mark_after is not None and el >= mark_after and os.environ.get("ORCH_STARTED"):
        open(os.environ["ORCH_STARTED"], "w").write("1")
        mark_after = None
    time.sleep(0.2)
bye_rc = rc
for p in files:
    try: os.remove(p)
    except OSError: pass
sys.exit(bye_rc)
