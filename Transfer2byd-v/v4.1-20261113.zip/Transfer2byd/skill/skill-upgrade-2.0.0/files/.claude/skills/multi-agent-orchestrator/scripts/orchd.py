#!/usr/bin/env python3
"""orchd —— 编排守护：唯一的 GPU 分配者 + 实时用卡核查 + 事件叫醒主窗（skill 2.0.0 新增）。

为什么要它（v4 现场的 7 个问题里有 5 个是“分配”和“核查”分家造成的）：
  1. 两套锁（包内 lease.py 与 skill 的 gpu_lock）各管各的，显存 0 但已被锁的卡被重复分出；
  2. 4 卡任务因 ray 端口冲突被迫“整机独占”，另外 4 张卡白白空着；
  3. 僵尸锁让 4 张卡三天不可用；
  4. 任务占着卡但在空转（等不到的 teacher、提交不上的 ray job），表面上“GPU 在用”；
  5. 子窗 fork 把别的窗的 teacher 当成自己的去 kill。
  所以：分配、启动、打标签、核查、停止都收到同一个不调用模型的脚本里，主窗只做决定。

子命令（主窗、子窗、守护共用；全部是标准库，Python ≥ 3.8）:
  init    --td 任务目录 --manifest 包/state/manifest.json [--pkg 包根] [--runtime 运行根]
          [--lockdir 锁目录] [--session tmux会话] [--facts 事实流] [--events-dir 事件目录] [--set k=v ...]
  daemon  --td 任务目录 [--interval 3]        守护循环；放在 tmux 的 orchd 窗里常驻
  tick    --td 任务目录                       跑一轮（测试与手动排障用）
  status  --td 任务目录 [--json] [--all]       给主窗看的短表（≤ 40 行）
  util    --td 任务目录 [--csv 文件]           卡时账：真用了多少、空闲的原因；--csv 导出回传用的表（total/hourly/task）
  check   --td 任务目录                       门禁：守护心跳过期 / 有未确认告警 / 有可避免的空卡 -> 退 1
  health  --td 任务目录                       主窗的定时巡检：一条命令看全局，退 1 时逐条写了要做什么（R31）
  ask     --td 任务目录 ID --question 文字     子窗：一个要研究者决定的具体问题（不必停工），orchd 叫醒主窗原话转达
  judge   --td 任务目录 短名 --question 文字 [--about 任务]   主窗：开一扇判断窗（自动生成任务书）；交了结论叫醒主窗、自动关窗
  wait    --td 任务目录 [--timeout 秒]         主窗唯一的等待（后台挂着；巡检在里面做、不进主窗上下文；只在有事时返回）
  reopen  --td 任务目录 ID --question 文字 [--fresh]   做完的任务还要用：resume 它的原会话开跟进窗；交了报告叫醒主窗
运行中改计划（主窗按研究者或判断窗的结论执行；都要 --reason，写进 notes/decisions.md 与事实流；任务包的 manifest 不动）:
  prio    --td 任务目录 ID --boost N --reason …           改优先级加成
  dep     --td 任务目录 ID --add|--remove 前序 [--after] --reason …   发现还需要别的东西：先 add 新任务，再加依赖（防环）
  edit    --td 任务目录 ID --set 字段=JSON … --reason …     改卡数档位、令牌、依赖、预热期等（可改字段见 EDITABLE）
  drop    --td 任务目录 ID --reason …                     确实不可执行或决定不做：记为跳过，严格依赖它的随之跳过
  cordon / uncordon --td 任务目录 0,3 --reason …          停用 / 恢复某几张卡（坏卡、长期被别人占）
  shrink  --td 任务目录 ID --gpus 2,3 [--reason …]         把租约里用不上的卡还给调度（cellrun.py 自动调用）
  config  --td 任务目录 --set 键=值 --reason …             运行中改守护设置（max_windows、hold_after_s、max_fix…）
  env     --td 任务目录 ID                     打印该任务租到的环境变量（export 行）
  exec    --td 任务目录 ID [--name 子运行名] -- 命令...   在该任务的租约内跑一条命令（子窗用）
  start   --td 任务目录 ID --window 窗名       主窗确认：agent 类任务已开窗承接（预留转为在跑）
  done    --td 任务目录 ID [--evidence 路径;路径]   任务完成（agent 类由子窗或主窗调用）
  fail    --td 任务目录 ID --reason 文字        任务失败（释放卡，等主窗派修复窗）
  retry   --td 任务目录 ID                     把失败、受阻、放弃（drop）或跳过的任务放回队列（因它跳过的下游要一并 retry）
  fixwin  --td 任务目录 ID --window 窗          登记失败任务的修复窗（check 不再报“失败无人管”）
  accept  --td 任务目录 ID --reason 文字        确认失败照实交、不再修（例如某格失败两次）；after 依赖照常放行
  hold / unhold --td 任务目录 ID [--reason …]  暂停/恢复调度某任务（不影响在跑的）
  gate    --td 任务目录 名 pass|fail [--evidence 路径]   写门控结论；不满足的分支自动跳过
  kill    --td 任务目录 ID [--grace 30]        只停这个任务自己的进程（先 TERM，宽限后 KILL）
  ack     --td 任务目录 告警号|all             确认告警（不再重复叫醒）
  add     --td 任务目录 --json '{...}'          临时加一个任务（字段同 manifest 的 item；依赖必须已存在）
异常与变更的处理办法（谁决定、用哪条命令）见 references/manual.md 的“异常与变更”一节。

任务种类（manifest 的 kind）:
  gpu-job    全脚本化的 GPU 实验：守护一分到卡就自己启动（tmux 窗 j-<ID>），不经模型
  gpu-agent  需要 agent 判断的 GPU 任务：守护先预留卡；自动派窗模式下自己生成任务书、开子窗承接（否则发 orch_sched
             事件给主窗）；子窗所有 GPU 命令都经 `orchd.py exec ID -- ...`，预留超时没人用就收回
  cpu-job    纯脚本 CPU 任务：依赖一满足就启动，不等 GPU
  cpu-agent  需要 agent 的 CPU 任务：依赖一满足就开子窗（自动派窗模式）或发 orch_sched 事件给主窗
  role       角色（看板、验收、回传窗等），不参与调度，只列出

分配规则（研究者 2026-11-13 定：动态调度、不用预计时长，只看优先级与强制依赖；本脚本照做并补上防饿死与安全抢占）:
  * 每轮从实时状态重新决定（任务提前、推迟、失败、被跳过都不影响正确性）。
  * 就绪 = deps 都成功（deps_optional 里的被跳过也算）、after 都结束、门控满足、没被 hold。
  * CPU 任务：一就绪立即执行（cpu_slots 封顶；带资源令牌的不与在跑任务冲突才执行）。
  * GPU 任务优先级 = 传递下游任务个数 + prio_boost；相同时先放“下游最长依赖链的任务个数”大的，再按 seed 稳定随机。
  * 卡数 = 包声明的档位（gpu_options）里此刻放得下的最优先一档：值是偏好（越小越优先）；没写值时卡多的优先
    （能用 8 卡加速就 8 卡）；strict_tier 只认首选档。余卡继续给下一个就绪任务；有放得下的就绪任务就不让卡空着。
  * 启动保护（防饿死）：最高优先级的被挡任务，若有下游链（有任务强制依赖它，或 prio_boost > 0）就马上保护
    （hold_after_s，默认 0：它晚一步整条链都晚）；叶子任务等满 leaf_hold_after_s（默认 6 小时）才保护（晚跑不拖别人，
    空卡先给放得下的任务）。保护期间比它低、又不可抢占的任务暂不占它要的卡与令牌；preemptible 的 gpu-job 可以先用这些卡，
    一旦停掉它们就能让被保护任务起跑时被抢占（排回队列，不算失败）。
  * 资源令牌 res：{"machine":"x"} = 整机独占；{"hostbw":"x"} = 主机带宽独占（带宽、计时类）；
    同名令牌 x 与任何持有者互斥，s 与 s 可共存。每个 GPU 任务默认持 machine:s。
  * 每个在跑任务分一个槽位 slot，端口段 = port_base + slot*port_span，ray 临时目录各用各的。
  * gpu_options 的值、progress 推算的剩余时间只用于排先后和看板，不参与任何“等多久”的计算。

启动确认（研究者 2026-11-13 的思路）：进程真起来、持续占用资源 start_hold_s 秒、实验真开始（开始标志 $ORCH_STARTED、
  started_if / started_log、进度更新，或没声明时的持续计算）三项都有，才记“真开始”（confirmed_t、startup_s）。
  之前的卡时记为启动开销；之前退出的失败记为“启动阶段失败”；过了启动时限 warmup_s 还没真开始报 no_start。

核查（每轮，结果写 status 与告警事件）:
  loading    启动时限（warmup_s；agent 任务 agent_idle_s）内还没确认真开始 —— 正常（看 start_stage 知道卡在哪一步）
  ok         已真开始，卡上有它的进程，利用率或进度在动
  gap        agent 任务已真开始，两次运行之间卡上暂时没有进程 —— 正常（超过 agent_idle_s 报 not_on_gpu）
  no_start   过了启动时限，占着卡但没有任何“实验真开始”的证据 —— 告警（卡在加载、等端口或数据、死锁）
  not_on_gpu 过了启动时限一个它的进程都没有；或真开始后进程没了超过 lost_s —— 告警（分了卡没用 / 进程没了）
  partial    只有部分租到的卡上有它的进程（启动时限后；真开始后持续 lost_s）—— 告警（分 4 用 2）
  stall      真开始后利用率持续低于 util_min 且进度不动超过 stall_s —— 告警（空转）
  stray      它的进程跑到了没租给它的卡上 —— 告警（CUDA_VISIBLE_DEVICES 没生效）
  untagged   租的卡上有不带标签的进程 —— 告警（命令没走 orchd.py exec）
  rogue      卡上有计算进程但没有任何租约；orphan 已结束任务的残留进程 —— 告警（自动模式下 orphan 宽限后自动收）
  idle_waste 有空卡、有能发的任务、却超过 idle_alert_s 没发 —— 告警（调度卡住了）
  进程归属：读 /proc/<pid>/environ 里的 ORCH_TASK（只取这一个键，不读别的），读不到时
  沿父进程链找守护记录的包装进程。包装进程设了 child-subreaper，ray 之类自己 daemonize 的
  子进程也挂在它下面，停止时一并回收，卡和端口都能放干净。

退出码：0 正常；1 check 不通过 / 操作被拒；2 用法错；4 exec 时该任务没有租约。
"""
import argparse
import ctypes
import fcntl
import glob
import hashlib
import json
import os
import random
import re
import shlex
import signal
import subprocess
import sys
import time

VERSION = "2.0.0"
DEFAULTS = {
    "interval_s": 3,
    "warmup_s": 900,          # 预热期：加载 70 GB 教师要 2–5 分钟，留足
    "stall_s": 900,           # 空转判定：利用率低且进度不动这么久才报
    "util_min": 5,            # 利用率低于它算“没在算”（%）
    "mem_free_mib": 1000,     # 显存低于它、且无计算进程、无锁，才算空卡
    "idle_alert_s": 120,      # 可避免的空卡持续这么久就叫醒主窗
    "reserve_ttl_s": 900,     # agent 任务的预留，主窗多久内要接手
    "agent_idle_s": 1800,     # agent 任务租着卡、卡上没进程这么久，告警（两次运行之间的空档）
    "realert_s": 1800,        # 同一告警持续存在时多久再叫一次
    "cpu_slots": 6,           # 同时跑的 cpu-job 上限
    "port_base": 21000,
    "port_span": 200,
    "max_slots": 16,
    "grace_s": 30,
    "auto_start": True,       # gpu-job / cpu-job 由守护直接启动
    "seed": 1,
    "heartbeat_stale_s": 60,
    # 自动派窗（2.0.0 发布前补；研究者：主窗只掌控全局、定时监控，其余都由子窗做）
    "auto_windows": False,    # init 时任务目录下有 notes/orch.env 就自动打开
    "max_windows": 6,         # 同时开着的自动子窗上限（key 池 10 把，留主窗与人工槽位）
    "max_fix": 2,             # 每个失败任务最多自动开几次修复窗，用完交主窗
    "auto_audit": True,       # agent 任务交“完成”报告后自动开验收窗
    "orphan_grace_s": 300,    # 已结束任务的残留进程，告警这么久后自动按标签收掉
    "win_open_timeout_s": 300,
    # 动态调度（不用预计时长）：最高优先级的被挡任务开启“启动保护”（低优先级、不可抢占的任务暂不占它要的卡与令牌）。
    # 有下游链的任务（有任务强制依赖它，或包给了正的 prio_boost）一被挡就保护：它晚一步，后面整条链都晚；
    # 叶子任务（没有任务强制依赖它）等满 leaf_hold_after_s 才保护：它晚跑不拖别人，空卡先给放得下的任务（不白空着）
    "hold_after_s": 0,
    "leaf_hold_after_s": 21600,
    # 即将就绪的高优先级 GPU 任务（只差正在跑的 CPU 小步骤，例如门控判定）：这么多秒内先替它留卡，
    # 免得低优先级的大任务趁这一两轮把整机占了（本机模拟里 Q0 就这样抢在了研究者等着的探针前面）
    "imminent_hold_s": 300,
    # 启动确认（研究者 2026-11-13）：进程真起来、持续占用资源一段时间、实验真开始（标志、进度或持续计算）三项都有，才算任务真正开始执行
    "start_hold_s": 30,       # 占卡（CPU 任务：进程在）要连续这么久才算“持续占用”
    "lost_s": 120,            # 真开始之后，卡上进程少了或没了，持续这么久才报（容许阶段切换的几秒空档）
    # 全局保护
    "disk_min_gb": 50,        # 运行目录所在盘的余量低于它就暂停启动新任务（在跑的不动）并告警
    "paused": "",             # 主窗暂停全部新启动：orchd.py config --set paused=原因（恢复：--set paused=）
    "win_idle_s": 1800,       # 自动派窗：子窗这么久没有任何输出就提醒它一次；再一个周期仍没动静升级给主窗
    "max_win_restarts": 1,    # 工作窗消失后保留租约、按恢复说明重开的次数；用完判失败交修复窗
    "win_check_s": 30,        # 多久列一次 tmux 窗（查子窗死活与动静）
    "judge_timeout_s": 1800,  # 判断窗多久没交结论就升级
    # 子窗的一生（借鉴 SuperAgent：会话按任务保留，窗与 key 用完就还；之后要用就 resume 回原会话）
    "close_min_s": 10,        # 交了报告至少等这么久再关窗（让子窗写完上下文卡）
    "close_grace_s": 180,     # 交了报告后没等到这一轮结束（Stop 事件）也最多等这么久就关
    "resume_on_retry": True,  # 任务重试时新工作窗接着原会话（SuperAgent：重试用同一个执行会话）
    "resume_max_tokens": 120000,  # 原会话估计超过这么多 token 就改开新窗 + 上下文卡（子窗 V_fast 约 204k 自动压缩）
    "api_backoff_s": 60,      # 子窗这一轮因限流或接口出错中断：等 60、120、240…秒后发消息让它接着做
    "max_api_retries": 4,     # 同一扇窗连续这么多次仍失败就升级给主窗
    "tier_by_kind": {},       # 各类子窗用的模型档位（如 {"judge": "M"}），任务自己的 tier 优先；不写就是 key_window 的默认档
    # 主窗的等待（orchd.py wait）：查健康不进主窗上下文，只在有事时醒来
    "wait_health_every_s": 60,
    "summary_every_s": 7200,  # 没事时多久醒一次给一行进展（主窗 L 档 840k：一天约 12 次，每次约 1–2k token）
    "wait_realert_s": 3600,   # 同一件没处理完的事，多久再叫醒一次
}
# 自动派窗模式下由 orchd 自己处理、不叫醒主窗的告警（其余都是“要主窗决定”的升级）
AUTO_HANDLED = {"failed", "not_on_gpu", "partial", "stall", "stray", "untagged", "orphan", "reserve_timeout", "cpu_wait",
                "no_start"}
GPU_ISSUES = ("not_on_gpu", "partial", "stall", "stray", "untagged", "no_start")   # 在跑任务的用卡问题（发进它的窗或开修复窗）
TERMINAL = {"done", "skipped"}
ACTIVE = {"running", "reserved"}

# ---------------------------------------------------------------- 基础

def now():
    return time.time()

def ts(t=None):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t or now()))

def paths(td):
    s = os.path.join(td, "notes", "sched")
    return {
        "dir": s, "cfg": os.path.join(s, "config.json"), "queue": os.path.join(s, "queue.json"),
        "state": os.path.join(s, "state.json"), "lock": os.path.join(s, "state.lock"),
        "gpu_log": os.path.join(s, "gpu.jsonl"), "runs": os.path.join(td, "work", "sched"),
    }

def read_json(p, default=None):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default

def write_json(p, obj):
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    tmp = p + ".tmp.%d" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)

class Locked:
    """state.json 的读改写都在这把 flock 下做；守护与 CLI 共用。"""
    def __init__(self, td):
        self.p = paths(td)
    def __enter__(self):
        os.makedirs(self.p["dir"], exist_ok=True)
        self.fd = os.open(self.p["lock"], os.O_RDWR | os.O_CREAT, 0o644)
        fcntl.flock(self.fd, fcntl.LOCK_EX)
        self.cfg = read_json(self.p["cfg"], {})
        self.queue = read_json(self.p["queue"], {"items": []})
        self.state = read_json(self.p["state"], {})
        self.state.setdefault("tasks", {})
        self.state.setdefault("alerts", {})
        self.state.setdefault("acct", {})
        self.state.setdefault("slots", {})
        self.state.setdefault("gates", {})
        return self
    def save(self):
        write_json(self.p["state"], self.state)
    def save_queue(self):
        write_json(self.p["queue"], self.queue)
    def __exit__(self, *a):
        fcntl.flock(self.fd, fcntl.LOCK_UN)
        os.close(self.fd)

def append_line(path, rec):
    if not path:
        return
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        fcntl.lockf(fd, fcntl.LOCK_EX)
        os.write(fd, (json.dumps(rec, ensure_ascii=False) + "\n").encode("utf-8"))
    finally:
        fcntl.lockf(fd, fcntl.LOCK_UN)
        os.close(fd)

def emit_fact(cfg, typ, **kv):
    """与 facts.py emit 同格式（type/ts/seq_t + 键值），覆盖表由 facts.py render 照常生成。"""
    if not cfg.get("facts"):
        return
    from datetime import datetime, timezone
    rec = {"type": typ, "ts": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
           "seq_t": now()}
    rec.update({k: str(v) for k, v in kv.items()})
    append_line(cfg["facts"], rec)

def emit_event(cfg, event, **kv):
    """写进 hooks 同一个事件目录，wait_event.py 照常被叫醒（事件名 orch_alert / orch_sched）。"""
    if not cfg.get("events_dir"):
        return
    rec = {"ts": ts(), "window": "orchd", "event": event}
    rec.update(kv)
    append_line(os.path.join(cfg["events_dir"], "orchd.jsonl"), rec)

# ---------------------------------------------------------------- GPU 与进程

def smi_cmd(cfg):
    return os.environ.get("ORCH_NVIDIA_SMI") or cfg.get("nvidia_smi") or "nvidia-smi"

def gpu_sample(cfg):
    """一次采样：[{idx, uuid, used, total, util}] 与 [(pid, uuid, mib)]。失败返回 (None, None)。"""
    smi = smi_cmd(cfg)
    try:
        r = subprocess.run([smi, "--query-gpu=index,uuid,memory.used,memory.total,utilization.gpu",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=20)
        a = subprocess.run([smi, "--query-compute-apps=pid,gpu_uuid,used_memory",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.TimeoutExpired):
        return None, None
    if r.returncode != 0:
        return None, None
    gpus = []
    for line in r.stdout.strip().splitlines():
        p = [x.strip() for x in line.split(",")]
        if len(p) < 5:
            continue
        def num(x):
            try:
                return int(float(x))
            except ValueError:
                return 0
        gpus.append({"idx": str(int(p[0])), "uuid": p[1], "used": num(p[2]), "total": num(p[3]), "util": num(p[4])})
    apps = []
    for line in (a.stdout or "").strip().splitlines():
        p = [x.strip() for x in line.split(",")]
        if len(p) >= 2 and p[0].isdigit():
            try:
                mib = int(float(p[2])) if len(p) > 2 else 0
            except ValueError:
                mib = 0
            apps.append((int(p[0]), p[1], mib))
    return gpus, apps

def proc_tag(pid):
    """只取 ORCH_TASK / ORCH_RUN / ORCH_INST 三个键；读不到（别的用户、已退出）返回 None。"""
    try:
        with open("/proc/%d/environ" % pid, "rb") as f:
            raw = f.read()
    except OSError:
        return None
    out = {}
    for kv in raw.split(b"\0"):
        if kv.startswith(b"ORCH_TASK=") or kv.startswith(b"ORCH_RUN=") or kv.startswith(b"ORCH_INST="):
            k, v = kv.split(b"=", 1)
            out[k.decode()] = v.decode("utf-8", "replace")
    return out

def ppid_of(pid):
    try:
        with open("/proc/%d/stat" % pid) as f:
            s = f.read()
        return int(s[s.rfind(")") + 2:].split()[1])
    except (OSError, ValueError, IndexError):
        return 0

def pid_alive(pid):
    if not pid:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    try:
        with open("/proc/%d/stat" % pid) as f:
            st = f.read()
        return st[st.rfind(")") + 2] != "Z"
    except OSError:
        return True

def owner_of(pid, wrappers, inst=""):
    """pid -> 任务 id。先看 ORCH_TASK 标签（另一套编排的进程返回 "other:<任务>"），再沿父链找守护记录的包装进程。"""
    tag = proc_tag(pid)
    if tag and tag.get("ORCH_TASK"):
        if inst and tag.get("ORCH_INST") and tag["ORCH_INST"] != inst:
            return "other:" + tag["ORCH_TASK"]
        return tag["ORCH_TASK"]
    p, hops = pid, 0
    while p > 1 and hops < 64:
        if p in wrappers:
            return wrappers[p]
        p = ppid_of(p)
        hops += 1
    return None

def tagged_pids(task=None, run=None, inst=""):
    """扫 /proc，找带 ORCH_TASK=<task>（或 ORCH_RUN=<run>）标签的进程；给了 inst 时只认本实例（或没写实例的旧标签）。"""
    out = []
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        pid = int(d)
        if pid == os.getpid():
            continue
        tag = proc_tag(pid)
        if not tag:
            continue
        if inst and tag.get("ORCH_INST") and tag["ORCH_INST"] != inst:
            continue
        if run and tag.get("ORCH_RUN") == run:
            out.append(pid)
        elif task and not run and tag.get("ORCH_TASK") == task:
            out.append(pid)
    return out

def lock_owners(lockdir):
    held = {}
    for d in glob.glob(os.path.join(lockdir, "gpu*.lock")):
        g = os.path.basename(d)[3:-5]
        try:
            owner = open(os.path.join(d, "owner"), encoding="utf-8").read().strip()
        except OSError:
            owner = "?"
        try:
            age = now() - os.path.getmtime(d)
        except OSError:
            age = 0
        held[g] = {"owner": owner or "?", "age_s": age}
    return held

def lock_cards(lockdir, cards, owner):
    """与 gpu_lock.sh 同格式（mkdir 原子锁 + owner 文件），ledger.sh/gpu_lock.sh status 都看得见。"""
    os.makedirs(lockdir, exist_ok=True)
    got = []
    for g in cards:
        d = os.path.join(lockdir, "gpu%s.lock" % g)
        try:
            os.mkdir(d)
        except FileExistsError:
            for x in got:
                unlock_one(lockdir, x, owner)
            return False
        with open(os.path.join(d, "owner"), "w", encoding="utf-8") as f:
            f.write(owner + "\n")
        got.append(g)
    return True

def unlock_one(lockdir, g, owner):
    d = os.path.join(lockdir, "gpu%s.lock" % g)
    try:
        cur = open(os.path.join(d, "owner"), encoding="utf-8").read().strip()
    except OSError:
        return
    if cur == owner:                      # 只删自己的锁
        try:
            os.remove(os.path.join(d, "owner"))
        except OSError:
            pass
        try:
            os.rmdir(d)
        except OSError:
            pass

def unlock_cards(lockdir, cards, owner):
    for g in cards:
        unlock_one(lockdir, g, owner)

# ---------------------------------------------------------------- 任务图

def items_by_id(queue):
    return {it["id"]: it for it in queue.get("items", [])}

def dep_ids(it, with_fallback=True):
    """一个任务引用的所有前序任务号：deps（“A|B” 表示 A 或 B 任一成功即可）、after、deps_optional、fallback_for。"""
    out = []
    for d in it.get("deps", []):
        out += [x for x in str(d).split("|") if x]
    out += list(it.get("after", [])) + list(it.get("deps_optional", []))
    if with_fallback and it.get("fallback_for"):
        out.append(it["fallback_for"])
    return out

def is_milestone(it):
    """里程碑：不执行的节点，只表示“谁需要这些结果”（研究者的决定点、下一轮的设计、论文的某一节）。
    依赖满足就自动记为完成；它让任务图之外的需求进入优先级：喂给它的任务按它的分量提前。"""
    return it.get("kind") == "milestone"


def priorities(items, tasks):
    """优先级 = 自己的 prio_boost + 所有直接或间接依赖它的节点的分量之和（每个节点只数一次；已完成、跳过的不数）。

    分量：任务 = 1 + max(0, prio_boost)（正加成往上游传：它急，它的前提也就急；负加成只压它自己）；
          里程碑 = weight（默认 1）；有人在等的里程碑（waiting_human）= 全部任务分量之和 + 1，
          所以喂给“人正在等的决定”的任务排在其余一切之前，彼此之间再按各自的下游排。
    只看依赖结构，不用任何预计时长。"""
    live = {k: v for k, v in items.items() if tasks.get(k, {}).get("status") not in ("done", "skipped")}
    val = {k: 1.0 + max(0.0, float(v.get("prio_boost", 0) or 0)) for k, v in live.items() if not is_milestone(v)}
    w_human = sum(val.values()) + 1.0
    for k, v in live.items():
        if is_milestone(v):
            val[k] = w_human if v.get("waiting_human") else float(v.get("weight", 1) or 1)
    down = {}
    for it in live.values():
        for d in dep_ids(it, with_fallback=False):
            down.setdefault(d, set()).add(it["id"])
    out = {}
    for tid, it in items.items():
        seen, stack = set(), list(down.get(tid, ()))
        while stack:
            n = stack.pop()
            if n in seen or n == tid:
                continue
            seen.add(n)
            stack.extend(down.get(n, ()))
        out[tid] = float(it.get("prio_boost", 0) or 0) + sum(val.get(n, 0.0) for n in seen)
    return out


def feeds_human(items, tasks):
    """直接或间接喂给“有人在等”的里程碑的任务：它们被挡时马上启动保护（人在等，不能被别的任务拖）。"""
    up = {}
    for it in items.values():
        for d in dep_ids(it, with_fallback=False):
            up.setdefault(it["id"], set()).add(d)
    out = set()
    for k, it in items.items():
        if is_milestone(it) and it.get("waiting_human") and tasks.get(k, {}).get("status") not in ("done", "skipped"):
            stack = list(up.get(k, ()))
            while stack:
                n = stack.pop()
                if n in out:
                    continue
                out.add(n)
                stack.extend(up.get(n, ()))
    return out


def final_failed(t):
    """失败已成定局：修复用完后照实交（accept，或包的预案 if_fail=accept）。"""
    return t.get("status") == "failed" and str(t.get("fix_assigned", "")).startswith("accepted")

def gpu_opts(it):
    """{卡数(int): 预计小时(float 或 None)}。兼容 v1 写法 gpus:[..] + est_h:{..}。"""
    o = it.get("gpu_options")
    if o:
        return {int(k): (float(v) if v not in (None, "") else None) for k, v in o.items()}
    g = it.get("gpus") or []
    est = it.get("est_h") or {}
    if isinstance(g, list) and g and any(int(x) > 0 for x in g):
        return {int(x): (float(est[str(x)]) if str(x) in est else None) for x in g if int(x) > 0}
    return {}

def is_gpu(it):
    return it.get("kind", "").startswith("gpu")

def res_of(it):
    r = dict(it.get("res") or {})
    if is_gpu(it):
        r.setdefault("machine", "s")
    return r

def res_compatible(a, b):
    for k, mode in a.items():
        if k in b and (mode == "x" or b[k] == "x"):
            return False
    return True

def fanout(items):
    """传递下游扇出（只数没被跳过的任务；备选任务 fallback_for 不算原任务的下游）。"""
    down = {}
    for it in items.values():
        for d in dep_ids(it, with_fallback=False):
            down.setdefault(d, set()).add(it["id"])
    out = {}
    for tid in items:
        seen, stack = set(), list(down.get(tid, ()))
        while stack:
            n = stack.pop()
            if n in seen or n == tid:
                continue
            seen.add(n)
            stack.extend(down.get(n, ()))
        out[tid] = len(seen)
    return out

def facts_view(cfg):
    """从事实流读子窗写的 report（最新一条的状态与时刻）与 gate 结论。

    返回 ({id: (状态, seq_t, 原始事实)}, {门: 结论})。report 只有比本次派发更新时才算数（重试后旧的“受阻”不会把新一次判失败）。
    原始事实里可以带 summary（≤ 600 字的结论）与 attention（一个要研究者决定的具体问题，SuperAgent 的 worker_attention）。
    """
    done, gates = {}, {}
    p = cfg.get("facts")
    if not p or not os.path.isfile(p):
        return done, gates
    try:
        for line in open(p, encoding="utf-8"):
            try:
                f = json.loads(line)
            except ValueError:
                continue
            if f.get("type") == "report" and f.get("id") and f.get("window") != "orchd":
                done[f["id"]] = (f.get("state"), float(f.get("seq_t") or 0), f)
            elif f.get("type") == "audit" and f.get("id"):
                done["audit:" + f["id"]] = (f.get("verdict"), float(f.get("seq_t") or 0), f)
            elif f.get("type") == "gate" and f.get("gate"):
                gates[f["gate"]] = f.get("verdict")
    except OSError:
        pass
    return done, gates


# ---------------------------------------------------------------- init / add

def norm_item(it, defaults):
    it = dict(it)
    kind = it.get("kind", "")
    if kind in ("task", ""):          # v1 manifest：按 gpus 判
        opts = gpu_opts(it)
        kind = "gpu-agent" if opts else "cpu-agent"
    if kind == "role":
        it["kind"] = "role"
        return it
    it["kind"] = kind
    it["deps"] = list(it.get("deps", it.get("depends", [])) or [])
    it["after"] = list(it.get("after", []) or [])
    if is_gpu(it):
        it["gpu_options"] = {str(k): v for k, v in gpu_opts(it).items()} or {"1": None}
    for k in ("warmup_s", "stall_s", "util_min"):
        it.setdefault(k, defaults.get(k))
    it.setdefault("retries", 0)
    it.setdefault("prio_boost", 0)
    return it

def cmd_init(a):
    p = paths(a.td)
    os.makedirs(p["dir"], exist_ok=True)
    man = read_json(a.manifest)
    if not man or "items" not in man:
        print("manifest 读不出 items：%s" % a.manifest, file=sys.stderr)
        return 2
    cfg = dict(DEFAULTS)
    cfg.update(man.get("sched_defaults", {}))
    cfg.update({"td": os.path.abspath(a.td), "manifest": os.path.abspath(a.manifest),
                "instance": hashlib.sha256(os.path.abspath(a.td).encode()).hexdigest()[:6],
                "pkg": os.path.abspath(a.pkg or os.path.dirname(os.path.dirname(os.path.abspath(a.manifest)))),
                "runtime": os.path.abspath(a.runtime) if a.runtime else "",
                "lockdir": a.lockdir or os.environ.get("ORCH_LOCKDIR", ""),
                "session": a.session or "", "facts": a.facts or os.path.join(a.td, "notes", "facts.jsonl"),
                "events_dir": a.events_dir or os.path.join(a.td, "notes", "events"),
                "partitions": man.get("partitions", {}), "schema": man.get("schema", ""),
                "run_env": man.get("run_env", {}), "brief": man.get("brief", {})})
    cfg["auto_windows"] = os.path.exists(os.path.join(a.td, "notes", "orch.env"))   # 写好 orch.env（winctl 的配置）就默认自动派窗
    for kv in a.set or []:
        k, v = kv.split("=", 1)
        cfg[k] = json.loads(v) if re.match(r"^(-?\d+(\.\d+)?|true|false|null|\[.*\]|\{.*\})$", v) else v
    if "{RUNTIME}" in json.dumps(man, ensure_ascii=False) and not cfg["runtime"]:
        print("manifest 里用到了 {RUNTIME}（done_if/done_check/progress），必须给 --runtime（任务包的运行根目录）", file=sys.stderr)
        return 2
    if not cfg["lockdir"]:
        print("缺 --lockdir（与 gpu_lock.sh 的 LOCKDIR 必须是同一个目录，否则又成了两套锁）", file=sys.stderr)
        return 2
    items = [norm_item(it, cfg) for it in man["items"]]
    ids = [it["id"] for it in items]
    dup = sorted({x for x in ids if ids.count(x) > 1})
    if dup:
        print("manifest 里 id 重复：%s" % dup, file=sys.stderr)
        return 2
    known = set(ids)
    bad = [(it["id"], d) for it in items for d in dep_ids(it) if d not in known]
    if bad:
        print("依赖指向不存在的任务：%s" % bad, file=sys.stderr)
        return 2
    imap = {it["id"]: it for it in items}
    if _has_cycle(imap):
        print("manifest 的依赖有环", file=sys.stderr)
        return 2
    with Locked(a.td) as L:
        old = L.state.get("tasks", {})
        if old and not a.reinit:
            print("已初始化过（%d 个任务的状态在 %s）；接手续跑不要重建，确需重建加 --reinit" % (len(old), p["state"]),
                  file=sys.stderr)
            return 1
        write_json(p["cfg"], cfg)
        L.queue = {"items": items, "loaded": ts(), "manifest": cfg["manifest"]}
        L.save_queue()
        L.state["tasks"] = {it["id"]: {"status": "wait", "attempt": 0} for it in items if it["kind"] != "role"}
        L.state["started"] = ts()
        L.save()
    for it in items:
        emit_fact(cfg, "task_add", id=it["id"], 类别=it["kind"], 名称=it.get("title", ""),
                  来源证据=it.get("source", it.get("route", "manifest")),
                  分区=("cpu" if not is_gpu(it) else (it.get("partition") or "A+B")),
                  依赖=",".join(it.get("deps", [])) or "无", 门控=",".join(sorted((it.get("gate") or {}).keys())) or "无",
                  可并行=json.dumps(res_of(it), ensure_ascii=False), 负责人窗=("orchd" if it["kind"].endswith("job") else ""),
                  备注="orchd init")
    print("orchd init：%d 项（gpu-job %d，gpu-agent %d，cpu-job %d，cpu-agent %d，里程碑 %d，role %d）；状态 %s" % (
        len(items), *[sum(1 for it in items if it["kind"] == k) for k in ("gpu-job", "gpu-agent", "cpu-job", "cpu-agent", "milestone", "role")],
        p["state"]))
    return 0

def cmd_add(a):
    it = json.loads(a.json)
    with Locked(a.td) as L:
        it = norm_item(it, L.cfg)
        ids = items_by_id(L.queue)
        if it["id"] in ids:
            print("id 已存在：%s" % it["id"], file=sys.stderr)
            return 1
        miss = [d for d in dep_ids(it) if d not in ids]
        if miss:
            print("依赖不存在：%s" % miss, file=sys.stderr)
            return 1
        if a.reason:
            it.setdefault("why", a.reason)
        L.queue["items"].append(it)
        L.save_queue()
        L.state["tasks"][it["id"]] = {"status": "wait", "attempt": 0}
        L.save()
        emit_fact(L.cfg, "task_add", id=it["id"], 类别=it["kind"], 名称=it.get("title", ""), 依赖=",".join(it["deps"]) or "无",
                  分区=("cpu" if not is_gpu(it) else "A+B"), 备注="orchd add")
        if a.reason:
            _log_edit(L, it["id"], "临时加任务（%s，依赖 %s）" % (it["kind"], ",".join(it["deps"] + it["after"]) or "无"), a.reason)
            L.save()
    print("已加入 %s" % it["id"])
    return 0

# ---------------------------------------------------------------- 调度核心

def deps_state(it, tasks):
    """返回 'ok' / 'wait' / 'skip'。

    deps：前序必须成功（done）；“A|B” = A、B 任一成功即可（主方案或它的备选）。
          前序被跳过、或失败已成定局（照实交）→ 本任务跳过；写在 deps_optional 里的前序例外（算满足）。
          前序失败但还在修 → 等。
    after：前序只要结束（done / failed / skipped）就满足——用于门控判定、回传这类“有什么交什么”的任务。
    fallback_for：备选任务（研究者预先写好的“主方案不行时怎么办”）：主任务成功或因门控/依赖被跳过 → 备选跳过；
          主任务失败已成定局、或被放弃（drop）→ 备选就绪。
    """
    fb = it.get("fallback_for")
    if fb:
        ft = tasks.get(fb, {})
        if ft.get("status") == "done" or (ft.get("status") == "skipped" and not ft.get("dropped")):
            return "skip"
        if not (final_failed(ft) or ft.get("dropped")):
            return "wait"
    for d in it.get("after", []):
        if tasks.get(d, {}).get("status") not in ("done", "failed", "skipped"):
            return "wait"
    opt = set(it.get("deps_optional", []))
    for d in it.get("deps", []):
        alts = [x for x in str(d).split("|") if x]
        sts = [tasks.get(x, {}) for x in alts]
        if any(x.get("status") == "done" for x in sts):
            continue
        if all(x.get("status") == "skipped" or final_failed(x) for x in sts):
            if d in opt or any(x in opt for x in alts):
                continue
            return "skip"
        return "wait"
    return "ok"

def gate_state(it, gates):
    need = it.get("gate") or {}
    for g, want in need.items():
        got = gates.get(g)
        if got is None:
            return "wait"
        if got != want:
            return "skip"
    return "ok"

def pat_sub(cfg, p, run_dir=""):
    """manifest 里路径模式的占位符：{RUNTIME} {PKG} {TD} {RUN_DIR}。"""
    return (p.replace("{RUNTIME}", cfg.get("runtime", "")).replace("{PKG}", cfg.get("pkg", "")).replace("{TD}", cfg["td"])
            .replace("{RUN_DIR}", run_dir or "/.orchd-no-run-dir"))   # 没有运行目录时匹配不到任何文件（不能变成空串去匹配别处）


def progress_files(cfg, it, t):
    """进度文件：manifest 的 progress（glob）+ 通用约定 $ORCH_PROGRESS（每次运行目录下的 progress.json，cellrun.py 自动写）。"""
    pats = it.get("progress") or []
    if isinstance(pats, str):
        pats = [pats]
    files = []
    for p in pats:
        files += glob.glob(pat_sub(cfg, p, t.get("run_dir", "")))
    dirs = [r["dir"] for r in (t.get("exec_runs") or [])[-1:]] + ([t["run_dir"]] if t.get("run_dir") else [])
    for d in dirs:
        f = os.path.join(d, "progress.json")
        if os.path.exists(f) and f not in files:
            files.append(f)
    return files


def progress_eta(cfg, it, t, tnow):
    """读进度文件（JSON 里有 step 与 steps_total 时）推算剩余时间，只给看板与巡检看；读不到返回 None。
    每步用时从“确认真开始”算起（不把启动、加载算进每一步）。"""
    best = None
    base = t.get("confirmed_t") or t.get("start_t") or tnow
    for f in progress_files(cfg, it, t):
        try:
            if os.path.getmtime(f) < (t.get("start_t") or 0) - 5:
                continue
            d = json.load(open(f, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        step, total = d.get("step"), d.get("steps_total")
        if not (isinstance(step, (int, float)) and isinstance(total, (int, float)) and total > 0 and 0 < step <= total):
            continue
        per = d.get("last_step_s") or (tnow - base) / step
        eta = tnow + max(0.0, (total - step) * float(per) * 1.1)
        best = eta if best is None else max(best, eta)
    return best


def chain_len(items, tasks):
    """每个任务下游最长依赖链的任务个数（不含已完成与跳过的）：同优先级时先放长链的头。只数个数，不用预计时长。"""
    down = {}
    for it in items.values():
        for d in dep_ids(it, with_fallback=False):
            down.setdefault(d, []).append(it["id"])
    memo = {}

    def depth(x, stack=()):
        if x in memo:
            return memo[x]
        if x in stack:
            return 0
        kids = [c for c in down.get(x, []) if tasks.get(c, {}).get("status") not in ("done", "skipped")]
        memo[x] = 1 + max([depth(c, stack + (x,)) for c in kids] or [0])
        return memo[x]
    return {x: depth(x) for x in items}


def strict_fanout(items, tasks):
    """只沿强制依赖（deps，含 "A|B" 的每一支）数传递下游个数（不含已完成与跳过的）：用来判断“它晚了会不会拖后面的链”。
    after、deps_optional、fallback_for 不算：前序失败或晚到它们照样能跑。"""
    down = {}
    for it in items.values():
        for d in it.get("deps", []):
            for x in str(d).split("|"):
                if x and x not in (it.get("deps_optional") or []):
                    down.setdefault(x, set()).add(it["id"])
    out = {}
    for tid in items:
        visited, seen, stack = set(), set(), list(down.get(tid, ()))
        while stack:
            n = stack.pop()
            if n in visited or n == tid:
                continue
            visited.add(n)
            if tasks.get(n, {}).get("status") not in ("done", "skipped") and not is_milestone(items.get(n, {})):
                seen.add(n)                       # 只数真会跑的任务；里程碑只是“谁要结果”，不算会被拖的链
            stack.extend(down.get(n, ()))
        out[tid] = len(seen)
    return out


def tier_order(it):
    """包声明的卡数档位，按偏好排好：gpu_options 的值是“偏好”（越小越优先，例如预计小时或名次），只用来排先后，
    不参与任何时间计算；值一样时卡少的在前（省下的卡给别的任务）；没写值时卡多的在前（能用 8 卡加速就 8 卡）。"""
    opts = {int(k): v for k, v in (it.get("gpu_options") or {"1": None}).items()}
    if opts and all(isinstance(v, (int, float)) for v in opts.values()):
        return sorted(opts, key=lambda n: (opts[n], n))
    return sorted(opts, reverse=True)


def part_cards(cfg, it, all_cards):
    p = (it.get("partition") or "").upper()
    parts = {k.upper(): {str(x) for x in v} for k, v in (cfg.get("partitions") or {}).items()}
    if p and p in parts:
        return [c for c in all_cards if c in parts[p]]
    return list(all_cards)


def free_slot(state, cfg):
    used = {int(v) for v in state["slots"].values()}
    for s in range(int(cfg.get("max_slots", 16))):
        if s not in used:
            return s
    return None


def owner_prefix(cfg):
    """锁的持有者写 orchd:<实例>:<任务>。实例 = 任务目录的短哈希：同一锁目录下的另一套编排的锁不会被当成自己的残留锁。"""
    return "orchd:%s:" % cfg.get("instance", "x")


def run_env(cfg, it, t, run_id):
    slot = int(t.get("slot", 0) or 0)
    base = int(cfg.get("port_base", 21000)) + slot * int(cfg.get("port_span", 200))
    gp = ",".join(t.get("gpus", []))
    env = {
        "ORCH_TASK": it["id"], "ORCH_RUN": run_id, "ORCH_INST": cfg.get("instance", ""), "ORCH_TD": cfg["td"],
        "ORCH_SLOT": str(slot),
        "ORCH_PORT_BASE": str(base), "ORCH_PORT_SPAN": str(cfg.get("port_span", 200)),
        "ORCH_GPUS": gp, "ORCH_NGPU": str(len(t.get("gpus", []))),
        "ORCH_BIN": os.path.abspath(__file__),      # 任务里的门控判定脚本用它写 gate：python3 -I $ORCH_BIN gate --td $ORCH_TD ...
        # 卡号一律按 PCI 总线顺序：与 nvidia-smi 的编号一致；不设时 CUDA 默认 FASTEST_FIRST，
        # 可能与 nvidia-smi 编号不同，归属与越界判定就会错
        "CUDA_DEVICE_ORDER": "PCI_BUS_ID",
    }
    if is_gpu(it):
        env["CUDA_VISIBLE_DEVICES"] = gp
    else:
        env["CUDA_VISIBLE_DEVICES"] = ""          # CPU 任务看不到任何卡，免得误占
    tmp = os.path.join(cfg.get("tmp_root") or "/tmp", "orch-%s" % os.environ.get("USER", "u"),
                       "%s-slot%d" % (cfg.get("instance", "x"), slot))
    env["ORCH_TMP"] = tmp
    env["RAY_TMPDIR"] = os.path.join(tmp, "ray")
    env["ORCH_PKG"], env["ORCH_RUNTIME"] = cfg.get("pkg", ""), cfg.get("runtime", "")
    # 包自己的环境变量名由包定（skill 全局通用，不认识任何包的变量名）：manifest 顶层 run_env + 条目的 env，
    # 值里可用占位符 {PKG} {RUNTIME} {TD} {ID} {INST} {GPUS} {NGPU}（例：某包的 MYPKG_GPU_LEASE=external、MYPKG_RUNTIME={RUNTIME}）
    rep = {"{PKG}": cfg.get("pkg", ""), "{RUNTIME}": cfg.get("runtime", ""), "{TD}": cfg["td"], "{ID}": it["id"],
           "{INST}": cfg.get("instance", ""), "{GPUS}": gp, "{NGPU}": str(len(t.get("gpus", [])))}
    for k, v in list((cfg.get("run_env") or {}).items()) + list((it.get("env") or {}).items()):
        v = str(v)
        for a_, b_ in rep.items():
            v = v.replace(a_, b_)
        env[k] = v
    return env


def subst(s, cfg, it, t, run_dir):
    rep = {"{PKG}": cfg.get("pkg", ""), "{RUNTIME}": cfg.get("runtime", ""), "{TD}": cfg["td"],
           "{GPUS}": ",".join(t.get("gpus", [])), "{NGPU}": str(len(t.get("gpus", []))),
           "{RUN_DIR}": run_dir, "{ID}": it["id"]}
    for k, v in rep.items():
        s = s.replace(k, v)
    return s


def launch(L, it, t, why):
    """守护直接启动 job：tmux 窗 j-<ID>（有会话时）或脱离的子进程；外面套 _run 包装。"""
    cfg = L.cfg
    t["attempt"] = int(t.get("attempt", 0)) + 1
    # 运行号要全局唯一：同一台机器上另一套编排可能在同一秒跑同名任务；包内按 ORCH_RUN 停进程（own_procs）会误杀别人的
    run_id = "%s-a%d-%s-%s" % (it["id"], t["attempt"], time.strftime("%Y%m%dT%H%M%S"), cfg.get("instance", "x")[:4])
    run_dir = os.path.join(paths(cfg["td"])["runs"], it["id"], run_id)
    os.makedirs(run_dir, exist_ok=True)
    cmd = subst(it.get("cmd", ""), cfg, it, t, run_dir)
    env = run_env(cfg, it, t, run_id)
    env["ORCH_RUN_DIR"] = run_dir
    env["ORCH_STARTED"] = os.path.join(run_dir, ".started")      # 任务确认实验真开始时 touch 它（可选，最可靠的证据）
    env["ORCH_PROGRESS"] = os.path.join(run_dir, "progress.json")  # 任务可以在这里写 {"step":…, "steps_total":…}
    spec = {"task": it["id"], "run": run_id, "cmd": cmd,
            "cwd": subst(it.get("cwd") or cfg.get("pkg") or cfg["td"], cfg, it, t, run_dir),
            "env": env, "grace_s": cfg.get("grace_s", 30)}
    write_json(os.path.join(run_dir, "spec.json"), spec)
    me = os.path.abspath(__file__)
    argv = [sys.executable, "-I", me, "_run", "--spec", os.path.join(run_dir, "spec.json")]
    win = "j-" + it["id"]
    started = False
    if cfg.get("session"):
        try:
            if subprocess.run(["tmux", "has-session", "-t", cfg["session"]], capture_output=True, timeout=10).returncode == 0:
                line = " ".join(shlex.quote(x) for x in argv)
                r = subprocess.run(["tmux", "new-window", "-d", "-t", cfg["session"] + ":", "-n", win, line],
                                   capture_output=True, timeout=10)
                if r.returncode == 0:
                    t["window"] = cfg["session"] + ":" + win
                    started = True
        except (OSError, subprocess.TimeoutExpired):
            started = False
    if not started:                                  # 没有会话或 tmux 出错：脱离启动，照样有包装与日志
        log = open(os.path.join(run_dir, "wrapper.out"), "ab")
        subprocess.Popen(argv, stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True)
        t["window"] = "(detached)"
    t.update(status="running", run=run_id, run_dir=run_dir, start_t=now(), started=ts(), why=why,
             wrapper_pid=None, last_progress_t=now(), progress_sig=None, low_since=None, verdict="loading",
             confirmed_t=None, startup_s=None, start_ev="", occ_since=None, busy_since=None, sig_at_occ=None, lost_since=None,
             start_stage="启动中：已派发，等进程起来")
    emit_fact(cfg, "dispatch", id=it["id"], window=t["window"])
    if t.get("gpus"):
        emit_fact(cfg, "lease", id=it["id"], gpus=",".join(t["gpus"]), window=t["window"])


def finish(L, tid, status, reason="", evidence=""):
    cfg, t = L.cfg, L.state["tasks"][tid]
    if t.get("gpus"):
        unlock_cards(cfg["lockdir"], t["gpus"], owner_prefix(cfg) + tid)
        emit_fact(cfg, "release", id=tid)
    L.state["slots"].pop(tid, None)
    t.update(status=status, end_t=now(), ended=ts(), reason=reason, gpus=[])
    t.pop("slot", None)
    if status == "done":
        emit_fact(cfg, "report", id=tid, state="完成", window="orchd", run_window=t.get("window", ""),
                  evidence=evidence or t.get("run_dir", ""))
        it = items_by_id(L.queue).get(tid, {})
        if it.get("notify"):                     # 研究者要知道的结果（如回传交好了）：叫醒主窗转告
            emit_event(cfg, "orch_result", kind="result", task=tid, msg="%s 完成：%s" % (tid, (t.get("last_report") or {}).get("summary", "")[:300]))
    elif status == "failed":
        emit_fact(cfg, "report", id=tid, state="受阻", window="orchd", run_window=t.get("window", ""),
                  evidence=t.get("run_dir", ""), note=reason[:200])


def alert(L, key, kind, msg, task=""):
    a = L.state["alerts"].get(key)
    t = now()
    if a and a.get("acked"):
        a["last_t"] = t
        return
    if not a:
        n = L.state.get("alert_seq", 0) + 1
        L.state["alert_seq"] = n
        a = {"no": n, "kind": kind, "task": task, "msg": msg, "first_t": t, "first": ts(t), "last_t": t, "sent_t": 0}
        L.state["alerts"][key] = a
    a["last_t"], a["msg"] = t, msg
    if L.cfg.get("auto_windows") and kind in AUTO_HANDLED:
        a["auto"] = True                       # 自动派窗模式：orchd 自己处理（修复窗、给子窗发消息、自动收残留），不叫醒主窗
        return
    if t - a.get("sent_t", 0) >= L.cfg.get("realert_s", 1800):
        a["sent_t"] = t
        emit_event(L.cfg, "orch_alert", kind=kind, task=task, msg="[#%d] %s" % (a["no"], msg))


def clear_alerts(L, seen):
    for k in list(L.state["alerts"]):
        if k not in seen:
            L.state["alerts"].pop(k)


def globs_exist(cfg, pats):
    missing = []
    for p in pats or []:
        q = p.replace("{RUNTIME}", cfg.get("runtime", "")).replace("{PKG}", cfg.get("pkg", "")).replace("{TD}", cfg["td"])
        if not glob.glob(q):
            missing.append(q)
    return missing


def check_done(cfg, it, run_dir=""):
    return globs_exist(cfg, [x.replace("{RUN_DIR}", run_dir) for x in (it.get("done_check") or [])])


def progress_sig(cfg, it, t, fallback=True):
    """进度信号：进度文件的 mtime+大小；没有进度文件时（fallback）看日志（agent 任务看最近一次 exec 的日志）。"""
    files = progress_files(cfg, it, t)
    if not files and fallback:
        runs = t.get("exec_runs") or []
        if runs:
            files = [os.path.join(runs[-1]["dir"], "console.log")]
        elif t.get("run_dir"):
            files = [os.path.join(t["run_dir"], "console.log")]
    sig = []
    for f in sorted(files):
        try:
            st = os.stat(f)
            sig.append((f, int(st.st_mtime), st.st_size))
        except OSError:
            pass
    return json.dumps(sig)


def start_evidence(cfg, it, t, tnow, hold_s, cpu=False):
    """“实验真开始”的证据，有一项就算，返回说明（没有返回空串）：
      1. 任务自己写了开始标志 $ORCH_STARTED（运行目录下的 .started；cellrun.py 在第一格做完时写）
      2. manifest 的 started_if（文件出现，可用 {RUN_DIR}）或 started_log（日志尾部出现这个正则）
      3. 进度文件在开始占用之后更新了（manifest 的 progress 或 $ORCH_PROGRESS）
      4. 包什么都没声明时：GPU 任务持续计算（利用率 ≥ util_min）满 start_hold_s；CPU 任务进程持续在跑
    """
    dirs = [r["dir"] for r in (t.get("exec_runs") or [])] + ([t["run_dir"]] if t.get("run_dir") else [])
    for d in dirs:
        if os.path.exists(os.path.join(d, ".started")):
            return "任务写了开始标志"
    t0 = float(t.get("start_t") or 0) - 5
    for p in it.get("started_if") or []:
        for f in glob.glob(pat_sub(cfg, p, t.get("run_dir", ""))):
            try:
                if os.path.getmtime(f) >= t0:
                    return "started_if 出现 %s" % os.path.basename(f)
            except OSError:
                pass
    rx = it.get("started_log")
    if rx:
        for d in dirs:
            try:
                with open(os.path.join(d, "console.log"), "rb") as fh:
                    fh.seek(0, 2)
                    fh.seek(max(0, fh.tell() - 262144))
                    if re.search(rx, fh.read().decode("utf-8", "replace")):
                        return "日志出现 /%s/" % rx[:40]
            except (OSError, re.error):
                pass
    psig = progress_sig(cfg, it, t, fallback=False)
    if psig != "[]" and t.get("sig_at_occ") is not None and psig != t["sig_at_occ"]:
        return "进度在占用后更新"
    if not (it.get("started_if") or it.get("started_log") or it.get("progress")):
        if cpu:
            return "进程持续在跑"
        if t.get("busy_since") and tnow - t["busy_since"] >= hold_s:
            return "持续计算 %d 秒" % (tnow - t["busy_since"])
    return ""


def confirm_start(L, tid, it, t, occupied, busy, tnow):
    """启动确认（研究者 2026-11-13 的思路）：三项都满足才记“真开始”——
    进程真起来并占住资源（GPU 任务：租到的卡上都有它的进程；agent 或 allow_partial：至少一张；CPU 任务：进程在）、
    这种占用连续 start_hold_s 秒、实验真开始（start_evidence）。真开始之前的卡时记为启动开销（startup_s），
    之前退出的失败记为“启动阶段失败”，过了启动时限（warmup_s）还没真开始报 no_start。"""
    cfg = L.cfg
    hold_s = float(it.get("start_hold_s", cfg.get("start_hold_s", 30)))
    if occupied:
        if not t.get("occ_since"):
            t["occ_since"] = tnow
        if t.get("sig_at_occ") is None:
            t["sig_at_occ"] = progress_sig(cfg, it, t, fallback=False)
    else:
        t["occ_since"] = None
    t["busy_since"] = (t.get("busy_since") or tnow) if (occupied and busy) else None
    occ_for = tnow - t["occ_since"] if t.get("occ_since") else 0
    ev = start_evidence(cfg, it, t, tnow, hold_s, cpu=not is_gpu(it)) if occupied else ""
    if occupied and occ_for >= hold_s and ev:
        base = float((t.get("reserved_t") if is_agent(it) else None) or t.get("start_t") or tnow)
        t.update(confirmed_t=tnow, startup_s=round(tnow - base, 1), start_ev=ev, start_stage="已真开始（%s）" % ev)
        emit_fact(cfg, "task_set", id=tid, 备注="真开始：派发后 %d 秒确认（进程在、持续占用 ≥%d 秒、%s）" % (t["startup_s"], hold_s, ev))
        return True
    declared = bool(it.get("started_if") or it.get("started_log") or it.get("progress"))
    if not occupied:
        stage = "等进程上卡" if is_gpu(it) else "等进程起来"
    elif occ_for < hold_s:
        stage = "已占用 %d/%d 秒" % (occ_for, hold_s)
    else:
        stage = "已持续占用，等实验真开始（%s）" % ("开始标志、started_if/started_log 或进度更新" if declared else "开始标志或持续计算")
    t["start_stage"] = "启动中：" + stage
    return False


def tie_key(cfg, tid):
    """同优先级的随机次序：由 seed 与任务号决定，跨轮稳定（不会每分钟换一次顺序、来回抢预留）。"""
    return hashlib.sha256(("%s:%s" % (cfg.get("seed", 1), tid)).encode()).hexdigest()


def is_agent(it):
    return it.get("kind", "").endswith("agent")


def tick(td, quiet=False):
    with Locked(td) as L:
        cfg = L.cfg
        if not cfg:
            raise SystemExit("还没 init：%s" % paths(td)["cfg"])
        items = items_by_id(L.queue)
        tasks = L.state["tasks"]
        tnow = now()
        dt = min(max(tnow - L.state.get("last_tick_t", tnow), 0), 60)
        L.state["last_tick_t"], L.state["last_tick"] = tnow, ts(tnow)
        mine_prefix = owner_prefix(cfg)
        seen_alerts = set()
        gpus, apps = gpu_sample(cfg)
        sample_ok = gpus is not None
        if not sample_ok:
            L.state["smi_fail"] = L.state.get("smi_fail", 0) + 1
            if L.state["smi_fail"] >= 3:                 # 偶发一次超时不报；连续 3 次才报
                alert(L, "smi", "smi", "nvidia-smi 连续 %d 次不可用：暂停分配与核查（CPU 任务照常）" % L.state["smi_fail"])
                seen_alerts.add("smi")
            gpus, apps = [], []
        else:
            L.state["smi_fail"] = 0
        all_cards = [g["idx"] for g in gpus]
        by_uuid = {g["uuid"]: g["idx"] for g in gpus}
        held = lock_owners(cfg["lockdir"])

        # 1) 外部事实：子窗写的 report、gate
        fdone, fgates = facts_view(cfg)
        gates = dict(fgates)
        gates.update(L.state["gates"])

        # 2) 包装进程退出 -> 收尾（只管 job 类；agent 任务由 done/fail/report 收尾）
        wrappers = {}
        for tid, t in tasks.items():
            if t.get("status") != "running":
                continue
            it = items.get(tid, {})
            for r in t.get("exec_runs", []):
                if pid_alive(r.get("pid")):
                    wrappers[int(r["pid"])] = tid
            if is_agent(it):
                continue
            ex = read_json(os.path.join(t.get("run_dir", ""), "exit.json")) if t.get("run_dir") else None
            st = read_json(os.path.join(t.get("run_dir", ""), "wrapper.json")) if t.get("run_dir") else None
            if st and st.get("pid"):
                t["wrapper_pid"] = st["pid"]
                wrappers[int(st["pid"])] = tid
            if ex is not None:
                if ex.get("killed") and t.get("preempted_by"):
                    by = t.pop("preempted_by")
                    finish(L, tid, "wait", "被抢占：让更高优先级的 %s 起跑，已停下排回队列（可续跑的任务下次跳过已完成的部分）" % by)
                    t["preempted_for"] = by                 # 在 by 起跑之前不再启动（否则会反复抢占、白付启动开销）
                    emit_fact(cfg, "task_set", id=tid, 备注="被 orchd 抢占，让给 %s" % by)
                elif ex.get("killed"):
                    finish(L, tid, "failed", "被停止（信号 %s，rc %s）；日志 %s/console.log" % (
                        ex.get("signal"), ex.get("rc"), t.get("run_dir", "")))
                elif ex.get("rc") == 0:
                    miss = check_done(cfg, it, t.get("run_dir", ""))
                    if miss:
                        finish(L, tid, "failed", "退出码 0 但缺产物：%s" % miss[:3])
                    else:
                        finish(L, tid, "done", evidence=t.get("run_dir", ""))
                else:
                    reason = "退出码 %s；日志 %s/console.log" % (ex.get("rc"), t.get("run_dir", ""))
                    if not t.get("confirmed_t"):
                        reason = "启动阶段失败（还没确认真开始就退出：多半是环境、路径、参数、端口或显存问题）：" + reason
                    if int(t.get("attempt", 1)) <= int(it.get("retries", 0)):
                        finish(L, tid, "wait", "自动重试（第 %d 次失败）：%s" % (t.get("attempt", 1), reason))
                    else:
                        finish(L, tid, "failed", reason)
            elif t.get("wrapper_pid") and not pid_alive(t["wrapper_pid"]) and tnow - t.get("start_t", tnow) > 30:
                finish(L, tid, "failed", "包装进程消失且没有 exit.json（被外部强杀？残留进程用 orchd.py kill %s 收）" % tid)
            elif not t.get("wrapper_pid") and tnow - t.get("start_t", tnow) > 120:
                finish(L, tid, "failed", "启动 120 s 仍没有 wrapper.json（tmux 窗没起来？看 %s/wrapper.out）" % t.get("run_dir", ""))
        for tid, t in tasks.items():
            if t.get("status") == "failed" and not t.get("alerted"):
                t["alerted"] = True
                if not cfg.get("auto_windows"):      # 自动模式下由第 10 步开修复窗；修复次数用完才升级给主窗
                    emit_event(cfg, "orch_alert", kind="failed", task=tid, msg="%s 失败：%s" % (tid, t.get("reason", "")))

        # 3) agent 任务：子窗交的 report 完成/受阻 视为结束
        for tid, t in tasks.items():
            it = items.get(tid, {})
            if not is_agent(it):
                continue
            rep, rt_, rec = fdone.get(tid, (None, 0.0, {}))
            if t.get("status") in ACTIVE:
                if rt_ < float(t.get("start_t") or t.get("reserved_t") or 0):
                    continue                             # 上一次派发留下的旧报告，不算
                if rep in ("完成", "受阻", "待补证"):
                    t["last_report"] = {"state": rep, "seq": rt_, "summary": str(rec.get("summary", ""))[:600],
                                        "attention": rec.get("attention", ""), "window": rec.get("window", "")}
                if rep == "完成":
                    finish(L, tid, "done", evidence=rec.get("evidence") or "facts.jsonl report")
                elif rep == "受阻":
                    finish(L, tid, "failed", "子窗报告受阻：" + str(rec.get("summary", rec.get("note", "")))[:300])
                    t["alerted"] = False
            elif t.get("status") in ("wait", "ready") and rep == "完成" and rt_ > float(t.get("retry_t") or 0) \
                    and rt_ > float(t.get("end_t") or 0):
                t.update(status="done", ended=ts(), reason="事实流 report 完成（未经 orchd 派发）")

        # 4) 已有证据（done_if）、依赖与门控 -> wait / ready / skipped
        for tid, t in tasks.items():
            if t.get("status") in ("wait", "ready"):
                it = items[tid]
                if it.get("done_if") and not globs_exist(cfg, it["done_if"]):
                    t.update(status="done", ended=ts(), reason="done_if 的证据已在（%s）" % "；".join(it["done_if"])[:200])
                    emit_fact(cfg, "report", id=tid, state="完成", window="orchd", evidence=";".join(it["done_if"])[:500],
                              note="done_if")
                    continue
                if it.get("skip_if_cmd") and not t.get("skip_checked") and deps_state(it, tasks) == "ok" \
                        and gate_state(it, gates) == "ok":
                    # 只查一次（环境检查一类：现有环境已满足就不必开窗装）；在后台跑，不卡住守护的这一轮
                    sc = t.get("skip_check") or {}
                    if not sc.get("started"):
                        d = os.path.join(paths(cfg["td"])["runs"], tid)
                        os.makedirs(d, exist_ok=True)
                        outp, rcp = os.path.join(d, "skip-check.out"), os.path.join(d, "skip-check.rc")
                        for f in (outp, rcp):
                            try:
                                os.remove(f)
                            except OSError:
                                pass
                        cmd = subst(it["skip_if_cmd"], cfg, it, t, "")
                        script = "( %s ) > %s 2>&1; echo $? > %s.tmp && mv %s.tmp %s" % (
                            cmd, shlex.quote(outp), shlex.quote(rcp), shlex.quote(rcp), shlex.quote(rcp))
                        try:
                            pr = subprocess.Popen(["bash", "-lc", script], cwd=cfg.get("pkg") or None, stdin=subprocess.DEVNULL,
                                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
                                                  env=dict(os.environ, **run_env(cfg, it, t, tid + "-skipcheck")))
                            sc = {"started": tnow, "pid": pr.pid, "out": outp, "rcf": rcp}
                        except OSError as e:
                            sc = {"started": tnow, "pid": None, "out": outp, "rcf": rcp, "err": repr(e)}
                        t["skip_check"] = sc
                    rc = None
                    if os.path.exists(sc["rcf"]):
                        try:
                            rc = int(open(sc["rcf"]).read().strip() or 1)
                        except (OSError, ValueError):
                            rc = 1
                    elif sc.get("err"):
                        rc = 127
                    elif tnow - sc["started"] > float(it.get("skip_if_timeout_s", 300)):
                        try:
                            os.killpg(int(sc["pid"]), signal.SIGKILL)
                        except (OSError, TypeError, ValueError):
                            pass
                        rc = 124
                    if rc is None:
                        t["status"], t["why"] = "wait", "检查现状中（skip_if_cmd，已 %d 秒）" % (tnow - sc["started"])
                        continue
                    try:
                        tail = open(sc["out"], encoding="utf-8", errors="replace").read()[-300:]
                    except OSError:
                        tail = sc.get("err", "")
                    t["skip_checked"] = tnow
                    t["skip_check"] = dict(sc, rc=rc, tail=tail)
                    if rc == 0:
                        t.update(status="done", ended=ts(), reason="skip_if_cmd 通过（现状已满足）：%s" % tail.strip()[-160:])
                        emit_fact(cfg, "report", id=tid, state="完成", window="orchd", evidence="skip_if_cmd", note="skip_if_cmd: " + it["skip_if_cmd"][:200])
                        continue
                if t.get("hold"):
                    t["status"], t["why"] = "wait", "hold（主窗暂停）"
                    continue
                g = gate_state(it, gates)
                d = deps_state(it, tasks)
                if g == "skip" or d == "skip":
                    t.update(status="skipped", why="门控不满足" if g == "skip" else (
                        "备选不需要（主任务成功或不用跑）" if it.get("fallback_for") else "前序被跳过或失败已成定局"), ended=ts())
                    emit_fact(cfg, "report", id=tid, state="完成", window="orchd", evidence="", note="skipped:" + t["why"])
                elif g == "ok" and d == "ok" and is_milestone(it):
                    t.update(status="done", ended=ts(), end_t=tnow, reason="里程碑：要的结果都齐了")
                    emit_fact(cfg, "report", id=tid, state="完成", window="orchd", evidence="milestone", note="里程碑：要的结果都齐了")
                    emit_fact(cfg, "task_set", id=tid, 备注="里程碑达成：%s" % it.get("title", tid))
                    emit_event(cfg, "orch_result", kind="milestone", task=tid, msg="里程碑 %s（%s）要的结果都齐了" % (
                        tid, it.get("title", "")))
                elif g == "ok" and d == "ok":
                    t["status"] = "ready"
                    t.setdefault("ready_t", tnow)
                else:
                    t["status"], t["why"] = "wait", ("等门控 " + ",".join((it.get("gate") or {}).keys()) if g == "wait" else "等依赖")
        changed = True
        while changed:                                   # 跳过沿依赖传播，直到稳定
            changed = False
            for tid, t in tasks.items():
                if t.get("status") in ("wait", "ready") and deps_state(items[tid], tasks) == "skip":
                    t.update(status="skipped", why="依赖被跳过", ended=ts())
                    emit_fact(cfg, "report", id=tid, state="完成", window="orchd", evidence="", note="skipped:依赖被跳过")
                    changed = True

        # 5) GPU 使用核查（采样失败的这一轮不核查：没有数据就不下结论）
        procs_on = {}       # idx -> [(pid, owner, mib)]；owner: 任务号 / None（看得见但没标签）/ "?ns"（本容器看不见这个 pid）
        ns_unknown = 0
        for pid, uuid, mib in apps or []:
            idx = by_uuid.get(uuid)
            if idx is None:
                continue
            if not os.path.exists("/proc/%d" % pid):
                owner = "?ns"
                ns_unknown += 1
            else:
                owner = owner_of(pid, wrappers, cfg.get("instance", ""))
            procs_on.setdefault(idx, []).append((pid, owner, mib))
        if ns_unknown:
            seen_alerts.add("pidns")
            alert(L, "pidns", "pidns", "nvidia-smi 报的 %d 个计算进程在本容器的 /proc 里看不到（进程号空间不一致）："
                  "这些卡的归属降级为“租约内有显存就算在用”，越界/无主判定对它们不可用" % ns_unknown)
        util = L.state.setdefault("util_ema", {})
        for g in gpus:
            util[g["idx"]] = round(0.5 * util.get(g["idx"], g["util"]) + 0.5 * g["util"], 1)
        leased = {}
        for tid, t in tasks.items():
            for c in t.get("gpus", []) if t.get("status") in ACTIVE else []:
                leased[c] = tid
        for tid, t in tasks.items():
            if t.get("status") not in ACTIVE or not t.get("gpus") or not sample_ok:
                continue
            it = items[tid]
            agent = is_agent(it)

            def on_card(c, _tid=tid):
                return any(o == _tid or o == "?ns" for _, o, _ in procs_on.get(c, []))
            mine = [c for c in t["gpus"] if on_card(c)]
            untagged = [c for c in t["gpus"] if any(o is None for _, o, _ in procs_on.get(c, []))]
            stray = sorted({c for c, lst in procs_on.items() for _, o, _ in lst if o == tid and c not in t["gpus"]})
            age = tnow - t.get("start_t", tnow)
            sig = progress_sig(cfg, it, t)
            if sig != t.get("progress_sig"):
                t["progress_sig"], t["last_progress_t"] = sig, tnow
            umin = float(it.get("util_min", cfg["util_min"]))
            active_util = max([util.get(c, 0) for c in mine] or [0])
            if active_util >= umin:
                t["low_since"] = None
            elif mine and not t.get("low_since"):
                t["low_since"] = tnow
            warm = float(it.get("warmup_s", cfg["warmup_s"]))
            grace = float(cfg.get("agent_idle_s", 1800)) if agent else warm
            ref = max(t.get("start_t", tnow), t.get("last_exec_end_t", 0)) if agent else t.get("start_t", tnow)
            stall_s = float(it.get("stall_s", cfg["stall_s"]))
            short = len(mine) < len(t["gpus"]) and not it.get("allow_partial")
            if t["status"] == "running" and not t.get("confirmed_t"):
                need = 1 if (agent or it.get("allow_partial")) else len(t["gpus"])
                confirm_start(L, tid, it, t, len(mine) >= need, active_util >= umin, tnow)
            v = "ok"
            if t["status"] == "reserved":
                v = "reserved"
                if tnow - t.get("reserved_t", tnow) > cfg.get("reserve_ttl_s", 900):
                    finish(L, tid, "ready", "预留超时：主窗 %d s 内没接手，卡已收回" % cfg.get("reserve_ttl_s", 900))
                    tasks[tid]["cooldown_until"] = tnow + cfg.get("reserve_ttl_s", 900)
                    key = "rsv:" + tid
                    alert(L, key, "reserve_timeout", "%s 的预留超时被收回：主窗要开窗承接（winctl.sh open ... --task %s）" % (tid, tid), tid)
                    seen_alerts.add(key)
                    continue
            elif not t.get("confirmed_t"):              # 启动期：时限内都算“加载中”；过了时限按缺哪一项报
                if tnow - ref < grace:
                    v = "loading"
                elif not mine:
                    v = "not_on_gpu"
                elif short:
                    v = "partial"
                else:
                    v = "no_start"
            else:                                       # 真开始之后
                lost = (not mine or short) and not agent
                t["lost_since"] = (t.get("lost_since") or tnow) if lost else None
                if agent and not mine:
                    v = "gap" if tnow - ref < grace else "not_on_gpu"      # agent 两次运行之间
                elif agent and short and tnow - ref > grace:
                    v = "partial"
                elif lost and tnow - t["lost_since"] >= float(it.get("lost_s", cfg.get("lost_s", 120))):
                    v = "not_on_gpu" if not mine else "partial"
                elif t.get("low_since") and tnow - t["low_since"] > stall_s and tnow - t.get("last_progress_t", tnow) > stall_s:
                    v = "stall"
            if untagged and v in ("loading", "not_on_gpu", "partial", "no_start"):
                v = "untagged"
            if stray:
                v = "stray"
            t["verdict"], t["on_gpu"] = v, mine
            if v in GPU_ISSUES:
                key = "%s:%s" % (v, tid)
                seen_alerts.add(key)
                msg = {"not_on_gpu": "%s 租了 GPU %s，%s卡上没有它的进程（分了卡没用）",
                       "partial": "%s 租了 GPU %s，%s只有 " + ",".join(mine) + " 上有它的进程（分多用少）",
                       "stall": "%s 在 GPU %s 上利用率持续低于阈值、进度不动（空转）%s",
                       "stray": "%s 的进程跑到了没租给它的卡 " + ",".join(stray) + " 上（租约 GPU %s）%s",
                       "untagged": "%s 租的 GPU %s 上有不带 ORCH_TASK 标签的进程（命令没走 orchd.py exec？）%s",
                       "no_start": "%s 占着 GPU %s，%s仍没确认实验真开始（" + t.get("start_stage", "") +
                                   "）：卡在加载、等端口或数据、死锁，或包声明的开始证据写错了"}[v]
                when = ("真开始后" if t.get("confirmed_t") else "过了启动时限 %d 秒" % grace) if v in ("not_on_gpu", "partial", "no_start") else ""
                alert(L, key, v, msg % (tid, ",".join(t["gpus"]), when), tid)
        for tid, t in tasks.items():                     # CPU job 的启动确认（不占卡：只记启动用时，不告警）
            it = items.get(tid, {})
            if t.get("status") == "running" and it.get("kind") == "cpu-job" and not t.get("confirmed_t"):
                confirm_start(L, tid, it, t, bool(t.get("wrapper_pid")) and pid_alive(t["wrapper_pid"]), False, tnow)
        known = set(items)
        for g in gpus:
            c = g["idx"]
            if c in leased or not sample_ok:
                continue
            lst = procs_on.get(c, [])
            if not lst:
                continue
            h = held.get(c)
            if h and not h["owner"].startswith(mine_prefix):
                continue                         # 别的窗或别的编排合法锁着的卡
            tagged = sorted({o for _, o, _ in lst if o and o != "?ns" and o in known})
            if tagged:
                key = "orphan:" + c
                seen_alerts.add(key)
                alert(L, key, "orphan", "GPU%s 上还有已结束任务 %s 的进程（%d MiB）：用 orchd.py kill %s 收掉" % (
                    c, ",".join(tagged), g["used"], tagged[0]), tagged[0])
            elif any(o is None for _, o, _ in lst):
                key = "rogue:" + c
                seen_alerts.add(key)
                alert(L, key, "rogue", "GPU%s 上有计算进程（%s，%d MiB）但没有任何租约" % (
                    c, ",".join("pid%d" % p for p, o, _ in lst[:4]), g["used"]))

        # 5b) 全局保护：磁盘不足或主窗暂停 → 不再启动新任务（在跑的不动）；掉卡；超时
        if tnow - L.state.get("disk_t", 0) > 60:
            L.state["disk_t"] = tnow
            try:
                stv = os.statvfs(cfg.get("runtime") or cfg["td"])
                L.state["disk_free_gb"] = round(stv.f_bavail * stv.f_frsize / 2 ** 30, 1)
            except OSError:
                L.state["disk_free_gb"] = None
        fg = L.state.get("disk_free_gb")
        paused = ""
        if fg is not None and fg < float(cfg.get("disk_min_gb", 50)):
            paused = "磁盘只剩 %.0f GB" % fg
            seen_alerts.add("disk")
            alert(L, "disk", "disk", "运行目录所在盘只剩 %.0f GB（< disk_min_gb %s）：暂停启动新任务（在跑的不动）；"
                  "清理旧运行的临时文件或换盘后自动恢复" % (fg, cfg.get("disk_min_gb", 50)))
        if cfg.get("paused"):
            paused = "主窗暂停（%s）" % cfg.get("paused")
        L.state["paused"] = paused
        if sample_ok:
            L.state["gpu_n_max"] = max(int(L.state.get("gpu_n_max", 0)), len(gpus))
            if len(gpus) < L.state["gpu_n_max"]:
                seen_alerts.add("gpu_lost")
                alert(L, "gpu_lost", "gpu_lost", "nvidia-smi 只看到 %d 张卡（之前 %d 张）：有卡掉了（XID 或掉总线）；在跑的任务可能已坏，"
                      "看 nvidia-smi -q 与 dmesg，确认坏卡后 orchd.py cordon" % (len(gpus), L.state["gpu_n_max"]))
        for tid, t in tasks.items():
            mh = items.get(tid, {}).get("max_h")
            if t.get("status") in ACTIVE and mh and tnow - float(t.get("start_t") or tnow) > float(mh) * 3600:
                key = "overtime:" + tid
                seen_alerts.add(key)
                alert(L, key, "overtime", "%s 已跑 %.1f 小时，超过包写的上限 max_h=%s：看进度决定继续还是 kill（不自动停）" % (
                    tid, (tnow - float(t["start_t"])) / 3600, mh), tid)

        # 6) 本轮空卡与锁（锁在第 2 步收尾时可能刚释放：重读一次，刚结束任务的卡这一轮就能再分出去）
        held = lock_owners(cfg["lockdir"])
        free = []
        cordoned = set(L.state.get("cordoned", []))
        for g in gpus:
            c = g["idx"]
            if c in held or c in leased or procs_on.get(c) or g["used"] >= cfg["mem_free_mib"] or c in cordoned:
                continue
            free.append(c)
        foreign = [g["idx"] for g in gpus if g["idx"] not in held and g["idx"] not in leased
                   and not procs_on.get(g["idx"]) and g["used"] >= cfg["mem_free_mib"]]
        for c, h in held.items():
            if h["owner"].startswith(mine_prefix):
                own = h["owner"][len(mine_prefix):]
                if tasks.get(own, {}).get("status") not in ACTIVE and c not in leased:
                    unlock_one(cfg["lockdir"], c, h["owner"])     # 自己这一套编排的残留锁自己收
                continue
            g = next((x for x in gpus if x["idx"] == c), None)
            if g and g["used"] < cfg["mem_free_mib"] and not procs_on.get(c) and h["age_s"] > 3600:
                key = "stale:" + c
                seen_alerts.add(key)
                alert(L, key, "stale_lock", "GPU%s 疑似僵尸锁（持有者 %s，锁龄 %d 分钟、卡上零显存零进程）；"
                      "核实持有者已结束后回收：rm -rf %s" % (c, h["owner"], h["age_s"] // 60,
                                                    os.path.join(cfg["lockdir"], "gpu%s.lock" % c)))

        # 7) 分配：只看优先级与强制依赖，不用任何预计时长（启动、加载、等待、失败都会让预计失准）
        #    就绪 = 依赖与门控满足；优先级 = 传递下游个数 + prio_boost，同级先比“下游最长链的任务个数”，再稳定随机；
        #    卡数 = 包声明的、此刻放得下的最优先一档（不空等）；有卡就发（不让卡空着等“可能更好”的安排）；
        #    防饿死：最高优先级的被挡任务进入“启动保护”（有下游链的马上、叶子等满 leaf_hold_after_s）——比它低、又不可抢占的任务暂不占它要的卡与令牌；
        #    可抢占（preemptible）的任务照样可以先用这些卡，一旦让出就能让它起跑时被停下、排回队列。
        prio_map = priorities(items, tasks)
        chain = chain_len(items, tasks)
        for x, t in tasks.items():                       # 记下来给 status、看板看（为什么它排在前面）
            if t.get("status") in ("wait", "ready"):
                t["prio"] = round(prio_map.get(x, 0.0), 1)

        def prio(x):
            return prio_map.get(x, 0.0)
        ready = [tid for tid, t in tasks.items() if t.get("status") == "ready"]
        for tid, t in tasks.items():                     # 不再被挡的任务清掉等待起点
            if t.get("status") != "ready":
                t.pop("blocked_since", None)
        cpu_ready = sorted([x for x in ready if not is_gpu(items[x])], key=lambda x: (-prio(x), -chain.get(x, 0), tie_key(cfg, x)))
        cpu_running = sum(1 for tid, t in tasks.items() if t.get("status") == "running" and items[tid]["kind"] == "cpu-job")

        def start_cpu(tid, why):
            it, t = items[tid], tasks[tid]
            t["gpus"] = []
            t["slot"] = free_slot(L.state, cfg)
            if t["slot"] is None:
                t["slot"] = int(cfg.get("max_slots", 16))
            L.state["slots"][tid] = t["slot"]
            launch(L, it, t, why)

        cpu_res_ready = []
        for tid in cpu_ready:                            # CPU 任务（不带令牌）：依赖一满足就执行，不等 GPU
            it, t = items[tid], tasks[tid]
            if paused and it["kind"] == "cpu-job":
                t["why"] = "暂停启动：" + paused
                continue
            if it["kind"] == "cpu-job" and cfg.get("auto_start", True):
                if res_of(it):
                    cpu_res_ready.append(tid)
                    continue
                if cpu_running >= int(cfg.get("cpu_slots", 6)):
                    t["why"] = "CPU 槽位已满（%d）" % cpu_running
                    continue
                start_cpu(tid, "CPU 任务依赖已满足，立即执行")
                cpu_running += 1
            elif it["kind"] == "cpu-agent":
                if not t.get("proposed") or tnow - t.get("proposed_t", tnow) > cfg.get("reserve_ttl_s", 900):
                    again = bool(t.get("proposed"))
                    t["proposed"], t["proposed_t"] = True, tnow
                    if not cfg.get("auto_windows"):
                        emit_event(cfg, "orch_sched", kind="cpu_ready", task=tid,
                                   msg="%s（CPU，agent）%s依赖已满足：开子窗承接 winctl.sh open <窗> <任务书> --task %s" % (
                                       tid, "仍未承接，" if again else "", tid))
                    if again:
                        key = "cpuwait:" + tid
                        alert(L, key, "cpu_wait", "%s（CPU agent 任务）就绪超过 %d s 仍没有窗承接" % (tid, cfg.get("reserve_ttl_s", 900)), tid)
                if t.get("proposed") and tnow - t.get("ready_t", tnow) > cfg.get("reserve_ttl_s", 900):
                    seen_alerts.add("cpuwait:" + tid)

        gpu_ready = [x for x in ready if is_gpu(items[x])]
        gpu_ready.sort(key=lambda x: (-prio(x), -chain.get(x, 0), tie_key(cfg, x)))
        active_res = [(res_of(items[x]), x) for x, t in tasks.items()
                      if t.get("status") in ACTIVE and (is_gpu(items[x]) or items[x].get("res"))]
        remaining = list(free)
        for x, t in tasks.items():                       # 进度推算的剩余时间：只给看板与巡检看，不参与分配
            if t.get("status") in ACTIVE:
                t["progress_eta_t"] = progress_eta(cfg, items[x], t, tnow)
        hold = None              # {"task", "res", "cards", "since", "need"}：启动保护
        plan_notes = {}

        sfan = strict_fanout(items, tasks)
        human = feeds_human(items, tasks)

        def hold_after(it_):
            """被挡多久开启动保护：manifest 逐任务写了就用它；有下游链（有任务强制依赖它，或 prio_boost > 0）→ hold_after_s
            （默认 0，马上保护：它晚一步整条链都晚）；叶子 → leaf_hold_after_s（默认 6 小时：空卡先给放得下的任务）。"""
            v = it_.get("hold_after_s")
            if v is not None:
                return float(v)
            if sfan.get(it_["id"], 0) > 0 or it_["id"] in human or float(it_.get("prio_boost", 0)) > 0:
                return float(cfg.get("hold_after_s", 0))
            return float(cfg.get("leaf_hold_after_s", 21600))

        imm_lim = float(cfg.get("imminent_hold_s", 300))
        imminent = []
        for x, t in tasks.items():
            it_ = items.get(x, {})
            if t.get("status") != "wait" or not is_gpu(it_) or t.get("hold") or it_.get("fallback_for"):
                continue
            if gate_state(it_, gates) == "skip" or deps_state(it_, tasks) == "skip":
                continue
            unmet = [d for d in it_.get("after", []) if tasks.get(d, {}).get("status") not in ("done", "failed", "skipped")]
            for d in it_.get("deps", []):
                alts = [y for y in str(d).split("|") if y]
                if not any(tasks.get(y, {}).get("status") == "done" for y in alts):
                    unmet.extend(alts)
            pre_ = [d for d in dep_ids(it_, with_fallback=False) if items.get(d, {}).get("kind") == "cpu-job"]
            if unmet:
                ok_ = all(items.get(d, {}).get("kind") == "cpu-job" and tasks.get(d, {}).get("status") == "running"
                          and tnow - float(tasks[d].get("start_t") or tnow) < imm_lim for d in unmet)
            else:                                        # 前序都结束了、只差门控结论：判定它的 CPU 步骤刚结束
                ok_ = gate_state(it_, gates) == "wait" and any(
                    tnow - float(tasks.get(d, {}).get("end_t") or 0) < imm_lim for d in pre_)
            if ok_:
                imminent.append(x)
        imminent.sort(key=lambda x: (-prio(x), -chain.get(x, 0), tie_key(cfg, x)))

        def imminent_hold(x):
            """替马上就绪的 x 留卡。与 x 同优先级、同样马上就绪的任务（例如门控两支：结论出来前不知道放行哪一支）
            一起算：令牌取最严的（x 压过 s）、卡数取最大的首选档，所以哪一支被放行都不会被挡。"""
            sib = [y for y in imminent if prio(y) >= prio(x)]
            res = {}
            for y in sib:
                for k, v in res_of(items[y]).items():
                    res[k] = "x" if v == "x" or res.get(k) == "x" else "s"
            need = max(tier_order(items[y])[0] for y in sib)
            return {"task": x, "res": res, "cards": set(part_cards(cfg, items[x], remaining)[:need]), "since": tnow, "need": need,
                    "blockers": [], "pre": False, "nonpre_block": True, "imminent": True}
        for x, t in tasks.items():                       # 抢占过它的任务已经起跑（或不再等），解除“先让”的限制
            pf = t.get("preempted_for")
            if pf and tasks.get(pf, {}).get("status") not in ("ready", "wait"):
                t.pop("preempted_for", None)
        for tid in gpu_ready:
            it, t = items[tid], tasks[tid]
            if hold is None and imminent and prio(imminent[0]) > prio(tid):
                hold = imminent_hold(imminent[0])        # 比它优先、马上就绪的任务先留卡（不抢占任何在跑的任务）
            if paused:
                plan_notes[tid] = "暂停启动：" + paused
                continue
            if t.get("cooldown_until", 0) > tnow:
                plan_notes[tid] = "预留超时冷却中（主窗没接手）：卡先给别的任务，%s 后再预留" % ts(t["cooldown_until"])
                continue
            if t.get("preempted_for"):
                plan_notes[tid] = "让 %s 先起跑（本任务为它被抢占过）" % t["preempted_for"]
                continue
            r = res_of(it)
            pre = bool(it.get("preemptible"))
            if hold and pre and not hold.get("nonpre_block"):
                # 被保护的任务只被“可抢占的”挡着时，不再放新的可抢占任务进来（马上又要停，白付启动开销）
                plan_notes[tid] = "启动保护：%s 马上可以起跑，可抢占任务暂不启动" % hold["task"]
                continue
            if hold and not pre and not res_compatible(r, hold["res"]):
                plan_notes[tid] = "启动保护：先让 %s 起跑（它已等 %d 分钟），本任务暂不占冲突的令牌" % (
                    hold["task"], (tnow - hold["since"]) // 60)
                continue
            blockers = sorted({x for rr, x in active_res if not res_compatible(r, rr)})
            cand = part_cards(cfg, it, remaining)
            held_out = []
            if hold and not pre:
                held_out = [c for c in cand if c in hold["cards"]]
                cand = [c for c in cand if c not in hold["cards"]]
            tiers = tier_order(it)
            fit = [n for n in tiers if n <= len(cand)]
            if it.get("strict_tier"):
                fit = [n for n in fit if n == tiers[0]]
            if blockers or not fit:
                need_n = min(tiers) if not it.get("strict_tier") else tiers[0]
                if blockers:
                    plan_notes[tid] = "资源令牌冲突（%s，与 %s）" % (json.dumps(r, ensure_ascii=False), ",".join(blockers))
                elif held_out and need_n <= len(cand) + len(held_out):
                    plan_notes[tid] = "启动保护：空卡 %s 留给 %s（优先级更高、正在等卡）" % (",".join(held_out), hold["task"])
                else:
                    plan_notes[tid] = "余卡不足：最少要 %d 张，可用 %d 张" % (need_n, len(cand))
                t.setdefault("blocked_since", tnow)
                waited = tnow - t["blocked_since"]
                if hold is None and waited >= hold_after(it):
                    pool = part_cards(cfg, it, remaining)
                    need = tiers[0]
                    part_all = set(part_cards(cfg, it, all_cards))
                    nonpre = any(not items[b].get("preemptible") for b in blockers) or any(
                        not items[x].get("preemptible") and set(tt.get("gpus", [])) & part_all
                        for x, tt in tasks.items() if tt.get("status") in ACTIVE)
                    hold = {"task": tid, "res": r, "cards": set(pool[:need]), "since": t["blocked_since"], "need": need,
                            "blockers": blockers, "pre": pre, "nonpre_block": nonpre}
                    plan_notes[tid] += "；已等 %d 分钟，启动保护开启：低优先级、不可抢占的任务暂不占它要的卡与令牌" % (waited // 60)
                continue
            n = fit[0]
            take = cand[:n]
            if not lock_cards(cfg["lockdir"], take, mine_prefix + tid):
                plan_notes[tid] = "加锁失败（有人刚抢走了卡），下轮再试"
                continue
            slot = free_slot(L.state, cfg)
            if slot is None:
                unlock_cards(cfg["lockdir"], take, mine_prefix + tid)
                plan_notes[tid] = "端口槽位用完（max_slots）"
                continue
            why = "第 %d 档 %d 卡（包声明的可用档：%s）" % (tiers.index(n) + 1, n, ",".join(str(x) for x in tiers))
            remaining = [c for c in remaining if c not in take]
            t["gpus"], t["slot"] = take, slot
            t.pop("blocked_since", None)
            L.state["slots"][tid] = slot
            active_res.append((r, tid))
            if it["kind"] == "gpu-job" and cfg.get("auto_start", True):
                launch(L, it, t, why)
            else:
                t.update(status="reserved", reserved_t=tnow, why=why, start_t=tnow, verdict="reserved", confirmed_t=None,
                         startup_s=None, start_ev="", occ_since=None, busy_since=None, sig_at_occ=None, lost_since=None,
                         start_stage="启动中：已预留，等子窗接手")
                emit_fact(cfg, "lease", id=tid, gpus=",".join(take), window="(待开窗)")
                if not cfg.get("auto_windows"):
                    emit_event(cfg, "orch_sched", kind="gpu_reserved", task=tid,
                               msg="%s 已预留 GPU %s（%s）：%d 秒内开子窗承接 winctl.sh open <窗> <任务书> --task %s；"
                                   "子窗所有 GPU 命令走 orchd.py exec %s -- ..." % (tid, ",".join(take), why,
                                                                                  cfg.get("reserve_ttl_s", 900), tid, tid))
        # 抢占：启动保护中的任务 R，若停掉“比它低、可抢占”的在跑 job 就能让它马上起跑（卡数够、令牌不再冲突），就停掉它们。
        # 被抢占的任务排回队列、不算失败（可抢占的任务要能续跑：包里的 job 跳过已完成的格）。
        if hold and not hold.get("imminent"):
            R, itR = hold["task"], items[hold["task"]]
            victims = [x for x, t in tasks.items() if t.get("status") == "running" and items[x].get("kind") == "gpu-job"
                       and items[x].get("preemptible") and prio(x) < prio(R) and not t.get("preempted_by")
                       and (set(t.get("gpus", [])) & set(part_cards(cfg, itR, all_cards))
                            or not res_compatible(res_of(items[x]), hold["res"]))]
            others = [x for x in hold["blockers"] if x not in victims]
            freeable = set(part_cards(cfg, itR, remaining)) | {c for x in victims for c in tasks[x].get("gpus", [])
                                                               if c in set(part_cards(cfg, itR, all_cards))}
            tiersR = tier_order(itR)
            fitR = [n for n in tiersR if n <= len(freeable)] if not itR.get("strict_tier") else [n for n in tiersR[:1] if n <= len(freeable)]
            if victims and not others and fitR:
                for x in victims:
                    t = tasks[x]
                    if t.get("wrapper_pid") and pid_alive(int(t["wrapper_pid"])):
                        try:
                            os.kill(int(t["wrapper_pid"]), signal.SIGTERM)
                            t["preempted_by"] = R
                            emit_event(cfg, "orch_sched", kind="preempt", task=x, msg="%s 被抢占：让 %s 起跑（启动保护）" % (x, R))
                        except OSError:
                            pass
                plan_notes[R] = plan_notes.get(R, "") + "；已抢占 %s，下一轮起跑" % ",".join(victims)
        for tid in gpu_ready:
            if tasks[tid].get("status") == "ready":
                tasks[tid]["why"] = plan_notes.get(tid, "")
        L.state["hold"] = {"task": hold["task"], "since": ts(hold["since"]), "cards": sorted(hold["cards"])} if hold else None

        # 带令牌的 CPU 任务：与在跑任务不冲突；启动保护中，不可抢占的不占被保护任务冲突的令牌
        all_res = [res_of(items[x]) for x, t in tasks.items() if t.get("status") in ACTIVE]
        for tid in cpu_res_ready:
            it, t = items[tid], tasks[tid]
            r = res_of(it)
            if paused:
                t["why"] = "暂停启动：" + paused
                continue
            if cpu_running >= int(cfg.get("cpu_slots", 6)):
                t["why"] = "CPU 槽位已满（%d）" % cpu_running
                continue
            if not all(res_compatible(r, x) for x in all_res):
                t["why"] = "资源令牌冲突（%s）" % json.dumps(r, ensure_ascii=False)
                continue
            if hold and not it.get("preemptible") and not res_compatible(r, hold["res"]):
                t["why"] = "启动保护：令牌与 %s 冲突，等它起跑" % hold["task"]
                continue
            start_cpu(tid, "CPU 任务依赖已满足、资源令牌不冲突")
            all_res.append(r)
            cpu_running += 1

        # 8) 空卡原因与“可避免的空卡”告警
        idle_why = {}
        still_ready = [x for x in gpu_ready if tasks[x].get("status") == "ready"]
        avoidable = []
        for x in still_ready:
            w = tasks[x].get("why", "")
            if ("加锁失败" in w or "冷却" in w or "槽位" in w) and min(int(k) for k in items[x]["gpu_options"]) <= len(remaining):
                avoidable.append(x)
        for c in remaining:
            if paused and still_ready:
                idle_why[c] = "暂停启动：" + paused
            elif hold and c in hold["cards"] and hold.get("imminent"):
                idle_why[c] = "为马上就绪的 %s 留卡（它只差正在跑的 CPU 小步骤；最多留 %d 秒）" % (hold["task"], imm_lim)
            elif hold and c in hold["cards"]:
                idle_why[c] = "为 %s 凑卡（启动保护，它已等 %d 分钟）" % (hold["task"], (tnow - hold["since"]) // 60)
            elif not still_ready:
                waiting = [x for x, t in tasks.items() if t.get("status") == "wait" and is_gpu(items[x])]
                idle_why[c] = "没有就绪的 GPU 任务" + ("（%d 个在等依赖/门控）" % len(waiting) if waiting else "")
            elif avoidable:
                idle_why[c] = "可避免：%s" % "；".join("%s %s" % (x, tasks[x].get("why", "")) for x in avoidable[:3])
            else:
                idle_why[c] = "就绪任务放不下：" + "；".join("%s %s" % (x, tasks[x].get("why", "")) for x in still_ready[:3])
        if remaining and avoidable and sample_ok:
            if not L.state.get("idle_since"):
                L.state["idle_since"] = tnow
        else:
            L.state["idle_since"] = None
        if L.state.get("idle_since") and tnow - L.state["idle_since"] > cfg.get("idle_alert_s", 120):
            seen_alerts.add("idle")
            alert(L, "idle", "idle_waste", "空卡 %s 已 %d 秒，可避免：%s" % (
                ",".join(remaining), tnow - L.state["idle_since"], "；".join(
                    "%s（%s）" % (x, tasks[x].get("why", "")) for x in avoidable[:3])))
        for k, a in L.state["alerts"].items():
            if k.startswith("rsv:") and tnow - a["last_t"] < 3600:
                seen_alerts.add(k)
        scan_hook_events(L, tnow)                       # 子窗的 hooks 事件：会话号、这一轮结束、接口失败、压缩
        judge_windows(L, fdone, seen_alerts, tnow)       # 判断窗、跟进窗（两种模式都有）
        if cfg.get("auto_windows"):                      # 10) 自动派窗（主窗只掌控全局）
            auto_windows(L, items, tasks, fdone, seen_alerts, tnow)
        close_ready_windows(L, tnow)
        if not sample_ok:                                # 没有数据的一轮不清告警，也不新判
            seen_alerts |= {k for k in L.state["alerts"]}
        clear_alerts(L, seen_alerts)

        # 9) 卡时账（采样失败的这一轮记为 unknown）。租约按分配之后的状态重算：这一轮刚分出去的卡算启动开销，不算“别人占用”
        leased = {c: x for x, tt in tasks.items() if tt.get("status") in ACTIVE for c in tt.get("gpus", [])}
        acc = L.state["acct"]
        if not sample_ok:
            acc["unknown_s"] = acc.get("unknown_s", 0) + dt * max(len(L.state.get("snapshot", {}).get("gpus", [])), 1)
        for g in gpus:
            c = g["idx"]
            if c in leased:
                tid = leased[c]
                if not tasks[tid].get("confirmed_t"):
                    acc["startup_s"] = acc.get("startup_s", 0) + dt          # 启动开销：派发或预留 → 确认真开始
                elif c in tasks[tid].get("on_gpu", []) and util.get(c, 0) >= cfg["util_min"]:
                    acc["used_s"] = acc.get("used_s", 0) + dt
                else:
                    acc["alloc_idle_s"] = acc.get("alloc_idle_s", 0) + dt
            elif c in remaining:
                why = idle_why.get(c, "")
                if why.startswith("暂停"):
                    k = "idle_paused_s"               # 磁盘不足或主窗暂停
                elif why.startswith("为"):
                    k = "idle_reserved_s"             # 为被挡太久的高优先级任务凑卡（启动保护）
                elif why.startswith("没有"):
                    k = "idle_noready_s"              # 依赖/门控没到
                elif why.startswith("可避免"):
                    k = "idle_avoidable_s"            # 不该出现：加锁失败、主窗没接预留、槽位用完
                elif "令牌" in why:
                    k = "idle_token_s"                # 计时任务要安静窗口：令牌互斥逼出来的空卡
                else:
                    k = "idle_fit_s"                  # 余卡不够任何就绪任务的最小档
                acc[k] = acc.get(k, 0) + dt
            else:
                lst = procs_on.get(c, [])
                own = bool(lst) and all(o in known for _, o, _ in lst)     # 本编排刚结束的任务还在退出（收尾）：算自己的开销
                k = "alloc_idle_s" if own else "other_s"
                acc[k] = acc.get(k, 0) + dt
        if sample_ok:
            L.state["snapshot"] = {"t": tnow, "gpus": [{"idx": g["idx"], "used": g["used"], "total": g.get("total"), "util": g["util"],
                                                      "ema": util.get(g["idx"]), "lease": leased.get(g["idx"], ""),
                                                      "lock": held.get(g["idx"], {}).get("owner", ""),
                                                      "procs": [[p, o or "", m] for p, o, m in procs_on.get(g["idx"], [])],
                                                      "idle_why": idle_why.get(g["idx"], "")} for g in gpus],
                                   "free": remaining, "foreign_mem": foreign,
                                   "reservation": [sorted(hold["cards"]), ts(hold["since"]), hold["task"]] if hold else None}
        L.state["heartbeat"] = tnow
        L.save()
        if gpus:
            append_line(paths(td)["gpu_log"], {"t": round(tnow, 1), "u": [g["util"] for g in gpus],
                                               "m": [g["used"] for g in gpus],
                                               "l": [leased.get(g["idx"], "") for g in gpus]})
    return 0

# ---------------------------------------------------------------- 自动派窗（主窗只掌控全局）

def slug(tid):
    return re.sub(r"[^a-z0-9-]+", "-", tid.lower()).strip("-")[:28] or "t"


def winctl_path(cfg):
    return os.environ.get("ORCH_WINCTL") or cfg.get("winctl") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "winctl.sh")


def brief_path(cfg):
    return cfg.get("brief_tool") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "brief.py")


def spawn_win(cfg, op, name, brief="", task="", fix="", text="", tier="", resume="", msg=""):
    """后台跑一次 winctl（开窗要等 REPL 就绪，可能一两分钟，不能卡住守护）；结果写 notes/sched/win/<窗>.<op>.json。"""
    wd = os.path.join(paths(cfg["td"])["dir"], "win")
    os.makedirs(wd, exist_ok=True)
    res = os.path.join(wd, "%s.%s.json" % (name, op))
    try:
        os.remove(res)
    except OSError:
        pass
    argv = [sys.executable, "-I", os.path.abspath(__file__), "_win", "--td", cfg["td"], "--op", op, "--name", name]
    for k, v in (("--brief", brief), ("--task", task), ("--fix", fix), ("--text", text), ("--tier", tier),
                 ("--resume", resume), ("--msg", msg)):
        if v:
            argv += [k, v]
    log = open(os.path.join(wd, "%s.%s.out" % (name, op)), "ab")
    subprocess.Popen(argv, stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True)
    return res


def make_brief(cfg, kind, tid, win, reason=""):
    """调 brief.py 生成任务书（规范的几节：共同规则、角色、任务的原始来源、环境、交接）；失败返回 None。"""
    out = os.path.join(cfg["td"], "briefs", "%s.md" % win)
    argv = [sys.executable, "-I", brief_path(cfg), kind, "--td", cfg["td"], "--id", tid, "--win", win, "--out", out]
    if reason:
        argv += ["--reason", reason[:1500]]
    try:
        r = subprocess.run(argv, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return out if r.returncode == 0 and os.path.exists(out) else None


def win_result(cfg, name, op):
    return read_json(os.path.join(paths(cfg["td"])["dir"], "win", "%s.%s.json" % (name, op)))


def session_file(sid):
    """Claude Code 的会话记录 ~/.claude/projects/<目录>/<会话号>.jsonl（resume 就是读它）；找不到返回 None。"""
    if not sid or not re.match(r"^[0-9a-fA-F-]{36}$", sid):
        return None
    for p in glob.glob(os.path.join(os.path.expanduser("~"), ".claude", "projects", "*", sid + ".jsonl")):
        return p
    return None


def session_tokens(sid):
    """原会话大约多少 token（记录文件字节数 ÷ 3，粗估；压缩过的会话会高估，偏保守）。找不到记录返回 None。"""
    p = session_file(sid)
    try:
        return int(os.path.getsize(p) / 3.0) if p else None
    except OSError:
        return None


def note_session(cfg, name, w, op):
    """每扇窗的会话号都记一行 notes/sessions.jsonl（以后要用：orchd.py reopen，或 winctl.sh open … --resume <会话号>）。"""
    if w.get("session"):
        append_line(os.path.join(cfg["td"], "notes", "sessions.jsonl"), {"t": ts(), "window": name, "kind": w.get("kind", ""),
                    "task": w.get("task", ""), "session": w["session"], "op": op})


def classify_api_error(err):
    """子窗一轮失败（StopFailure）的原因：rate 限流 / context 上下文超限 / auth key 失效 / other 其他接口错误。"""
    e = (err or "").lower()
    if any(k in e for k in ("rate", "too many requests", "429", "overload", "529", "capacity")):
        return "rate"
    if any(k in e for k in ("too long", "context length", "context window", "context_length", "prompt_too_long",
                            "too many tokens", "max context", "上下文")):
        return "context"
    if any(k in e for k in ("auth", "401", "403", "permission", "api key", "api_key", "billing", "quota", "credit",
                            "access_denied", "forbidden", "invalid key")):
        return "auth"
    return "other"


def scan_hook_events(L, tnow):
    """读子窗的 hooks 事件（1.7.0 的 orch_hook.py 写在事件目录、每窗一个文件）：记下会话号、这一轮何时结束（Stop）、
    接口失败（StopFailure）、压缩次数（PreCompact）。主窗不再被这些事件叫醒，由这里处理。"""
    cfg = L.cfg
    ed = cfg.get("events_dir")
    if not ed or not os.path.isdir(ed):
        return
    W = L.state.setdefault("windows", {})
    off = L.state.setdefault("hook_off", {})
    for fn in sorted(os.listdir(ed)):
        if not fn.endswith(".jsonl") or fn == "orchd.jsonl":
            continue
        p = os.path.join(ed, fn)
        try:
            size = os.path.getsize(p)
        except OSError:
            continue
        o = int(off.get(fn, 0))
        if size < o:
            o = 0
        if size == o:
            continue
        try:
            with open(p, "rb") as f:
                f.seek(o)
                chunk = f.read(min(size - o, 4 << 20))
        except OSError:
            continue
        cut = chunk.rfind(b"\n")
        if cut < 0:
            continue
        off[fn] = o + cut + 1
        for line in chunk[:cut].splitlines():
            try:
                r = json.loads(line)
            except ValueError:
                continue
            w = W.get(str(r.get("window", "")).split(":")[-1])
            if not w:
                continue
            t_ = float(r.get("t") or tnow)
            ev = r.get("event", "")
            sid = r.get("session_id")
            if sid and (ev == "SessionStart" or not w.get("session")):
                w["session"] = sid
            if ev == "Stop":
                w["last_stop_t"] = t_
                w["api_fail_n"] = 0
            elif ev == "StopFailure":
                err = str(r.get("error") or r.get("error_type") or r.get("message") or "")
                w["fail"] = {"t": t_, "error": err[:200], "kind": classify_api_error(err), "handled": ""}
            elif ev == "PreCompact":
                w["compactions"] = int(w.get("compactions", 0)) + 1
                w["last_compact_t"] = t_
            elif ev == "UserPromptSubmit":
                w["last_prompt_t"] = t_
            elif ev == "SessionEnd":
                w["ended_t"] = t_


def mark_close(w, since):
    """这扇窗的事做完了：记下时刻，等它这一轮结束（Stop）或宽限期到了再关（close_ready_windows）。"""
    if w.get("state") == "open" and not w.get("close_since"):
        w["close_since"] = float(since)


def close_ready_windows(L, tnow):
    """关掉做完了的窗：交了报告至少 close_min_s 秒，并且这一轮已经结束（Stop 事件），或者已过 close_grace_s。"""
    cfg = L.cfg
    W = L.state.setdefault("windows", {})
    mn, gr = float(cfg.get("close_min_s", 10)), float(cfg.get("close_grace_s", 180))
    for name, w in W.items():
        since = w.get("close_since")
        if not since or w.get("state") != "open" or tnow - since < mn:
            continue
        if float(w.get("last_stop_t") or 0) >= since - 1 or tnow - since >= gr:
            spawn_win(cfg, "close", name)
            w.update(state="closing", t_close=tnow)


def auto_windows(L, items, tasks, fdone, seen_alerts, tnow):
    """研究者 2026-11-13：主窗只掌控全局、定时监控；派窗、修复、验收、关窗由这里做（SuperAgent 的 host 角色）。

    规则：
      * gpu-agent 预留到卡、cpu-agent 就绪 → 生成任务书、开工作窗 w-<任务>（不超过 max_windows）
      * 任务失败或子窗报“受阻” → 开修复窗 fix-<任务>-<n>（每个任务最多 max_fix 次），用完升级给主窗
      * agent 任务交“完成” → 开验收窗 au-<任务>（auto_audit）；验收 fail → 升级给主窗
      * 子窗报告里带 attention（一个要研究者决定的具体问题）→ 升级给主窗，原话转给研究者
      * 子窗在跑、orchd 判出 not_on_gpu/partial/stall/untagged/stray → 把告警原文发进该子窗，由它处理
      * 已结束任务的残留进程 → 告警满 orphan_grace_s 后按标签自动收掉
      * 任务结束、修复交了报告、验收写了结论 → 关窗收 key
      * 开窗或关窗失败 → 升级给主窗（主窗可手工 winctl.sh）
    """
    cfg = L.cfg
    W = L.state.setdefault("windows", {})

    def active_count():
        return sum(1 for w in W.values() if w.get("state") in ("opening", "open", "closing") and w.get("kind") != "main")

    # a) 开窗/关窗/发消息的结果（判断窗由 judge_windows 管，两种模式都一样）
    for name, w in list(W.items()):
        if w.get("kind") in ("judge", "followup"):
            continue
        if w.get("state") == "opening":
            r = win_result(cfg, name, "open")
            if r is not None:
                if r.get("rc") == 0:
                    w.update(state="open", opened_t=tnow, close_since=None, last_stop_t=None, fail=None)
                    if r.get("session"):
                        w["session"] = r["session"]
                    note_session(cfg, name, w, "open")
                else:
                    w.update(state="failed", error=r.get("tail", "")[-400:])
                    key = "winfail:" + name
                    seen_alerts.add(key)
                    alert(L, key, "auto_window", "自动开窗 %s 失败（rc=%s）：%s；主窗手工 winctl.sh open 或查 key 池" % (
                        name, r.get("rc"), r.get("tail", "")[-200:]), w.get("task", ""))
            elif tnow - w.get("t", tnow) > cfg.get("win_open_timeout_s", 300) + 60:
                w.update(state="failed", error="开窗超时")
                key = "winfail:" + name
                seen_alerts.add(key)
                alert(L, key, "auto_window", "自动开窗 %s 超时（%d s 没有结果）" % (name, tnow - w["t"]), w.get("task", ""))
        elif w.get("state") == "closing":
            r = win_result(cfg, name, "close")
            if r is not None:
                w.update(state="closed" if r.get("rc") == 0 else "close_failed", closed_t=tnow)
                if r.get("session"):
                    w["session"] = r["session"]
                note_session(cfg, name, w, "close")
                tt = tasks.get(w.get("task", ""), {})
                if w.get("kind") == "task" and w.get("session") and tt.get("win") in (name, None):
                    tt["last_session"] = w["session"]   # 之后重试或追问时 resume 回这个会话
                if r.get("rc") != 0:
                    key = "winclose:" + name
                    seen_alerts.add(key)
                    alert(L, key, "auto_window", "自动关窗 %s 失败：%s" % (name, r.get("tail", "")[-200:]), w.get("task", ""))
        if w.get("state") in ("failed", "close_failed"):
            seen_alerts.add("winfail:" + name)
            seen_alerts.add("winclose:" + name)

    def open_win(kind, tid, name, reason="", fix="", resume="", msg=""):
        b = make_brief(cfg, {"task": "task", "fix": "fix", "audit": "audit"}[kind], tid, name, reason)
        if not b:
            key = "brief:" + name
            seen_alerts.add(key)
            alert(L, key, "auto_window", "生成任务书失败（%s %s）：主窗手工写任务书开窗" % (kind, tid), tid)
            return False
        tier = (items.get(tid, {}).get("tier") if kind == "task" else "") or (cfg.get("tier_by_kind") or {}).get(kind, "")
        spawn_win(cfg, "open", name, brief=b, task=tid if kind == "task" else "", fix=tid if kind == "fix" else "",
                  tier=tier, resume=resume, msg=msg)
        old = W.get(name, {})
        W[name] = {"kind": kind, "task": tid, "state": "opening", "t": tnow, "brief": b, "tier": tier, "resume": resume,
                   "session": resume or "", "compactions": old.get("compactions", 0) if resume else 0}
        return True

    def close_win(name, since=None):
        w = W.get(name)
        if w:
            mark_close(w, tnow if since is None else since)

    # b) 工作窗：预留到卡的 gpu-agent 先开（卡在等它），再按优先级开就绪的 cpu-agent（子窗名额不够时先给重要的）
    for tid, t in sorted(tasks.items(), key=lambda kv: (kv[1].get("status") != "reserved", -float(kv[1].get("prio") or 0), kv[0])):
        it = items.get(tid, {})
        if not is_agent(it) or t.get("win"):
            continue
        want = (it["kind"] == "gpu-agent" and t.get("status") == "reserved") or \
               (it["kind"] == "cpu-agent" and t.get("status") == "ready")
        if not want:
            continue
        if active_count() >= int(cfg.get("max_windows", 6)):
            t["why"] = (t.get("why", "") + "；子窗已满（max_windows），等空位").strip("；")
            continue
        name = "w-" + slug(tid)
        if name in W and W[name].get("state") in ("opening", "open", "closing"):
            continue
        resume, msg = "", ""
        sid = t.get("resume_sid") or (t.get("last_session") if cfg.get("resume_on_retry", True) else "")
        if sid and not t.get("last_overflow"):
            est = session_tokens(sid)
            if est is not None and est <= float(cfg.get("resume_max_tokens", 120000)):
                resume = sid
                msg = t.get("resume_msg") or ("[orchd] 任务 %s 重新承接（第 %d 次；上一次：%s）。你还在原来的会话里：先看上下文卡末尾，"
                                              "核对已经做过的外部动作（启动过的运行、写过的结果与事实），不要重复，再接着做。" % (
                                                  tid, int(t.get("attempt", 0)) + 1, str(t.get("reason") or "已修复")[:160]))
            else:
                t["why"] = (t.get("why", "") + "；原会话%s，开新窗靠上下文卡接着做" % (
                    "找不到" if est is None else "约 %d 万 token、太长" % (est // 10000))).strip("；")
        if open_win("task", tid, name, resume=resume, msg=msg):
            t["win"] = name
            t.pop("resume_sid", None)
            t.pop("resume_msg", None)
    # c) 子窗报告：attention 升级；受阻/失败 → 修复窗
    for tid, t in tasks.items():
        it = items.get(tid, {})
        rep = t.get("last_report") or {}
        if rep.get("attention") and not rep.get("attention_sent"):
            rep["attention_sent"] = tnow
            key = "attention:" + tid
            seen_alerts.add(key)
            alert(L, key, "attention", "%s 需要研究者决定：%s" % (tid, rep["attention"]), tid)
            emit_event(cfg, "orch_attention", task=tid, msg=rep["attention"])
        if rep.get("attention") and not L.state["alerts"].get("attention:" + tid, {}).get("acked"):
            seen_alerts.add("attention:" + tid)
    for tid, t in tasks.items():
        if t.get("status") != "failed" or str(t.get("fix_assigned", "")).startswith("accepted"):
            continue
        it = items.get(tid, {})
        n = int(t.get("fix_n", 0))
        cur = t.get("fix_win")
        if cur and W.get(cur, {}).get("state") in ("opening", "open", "closing"):
            continue
        if n >= int(cfg.get("max_fix", 2)):
            plan = it.get("if_fail")
            act = plan.get("action") if isinstance(plan, dict) else plan
            note = plan.get("note", "") if isinstance(plan, dict) else ""
            if act in ("accept", "drop"):                 # 包预先写好的“修不好怎么办”：不叫醒主窗，照预案做，告诉研究者
                if act == "accept":
                    t["fix_assigned"] = "accepted: 包的预案 if_fail=accept" + ("（%s）" % note if note else "")
                else:
                    t.update(status="skipped", dropped=True, ended=ts(), why="包的预案 if_fail=drop：修复 %d 次仍失败，放弃" % n)
                msg = "%s 自动修复 %d 次仍失败，按包的预案 %s 处理%s；最近原因：%s" % (
                    tid, n, act, ("：" + note) if note else "", t.get("reason", "")[:200])
                emit_fact(cfg, "task_set", id=tid, 备注=msg[:300])
                emit_event(cfg, "orch_result", kind="preset", task=tid, msg=msg)
                with open(os.path.join(cfg["td"], "notes", "decisions.md"), "a", encoding="utf-8") as f:
                    f.write("%s｜orchd 按包的预案处理 %s：%s｜%s\n" % (ts(), tid, act, msg))
                continue
            key = "fixout:" + tid
            seen_alerts.add(key)
            alert(L, key, "fix_exhausted", "%s 自动修复 %d 次仍失败：主窗决定（orchd.py accept 照实交 / 研究者介入）；最近原因：%s" % (
                tid, n, t.get("reason", "")[:200]), tid)
            continue
        if active_count() >= int(cfg.get("max_windows", 6)) + 1:     # 修复窗可以用人工槽位之外的那 1 个余量
            continue
        name = "fix-%s-%d" % (slug(tid), n + 1)
        if open_win("fix", tid, name, reason=t.get("reason", "")):
            t["fix_n"], t["fix_win"], t["fix_assigned"] = n + 1, name, name
    # d) 验收窗
    if cfg.get("auto_audit", True):
        for tid, t in tasks.items():
            it = items.get(tid, {})
            if not is_agent(it) or t.get("status") != "done" or t.get("audit_win") or t.get("audit_skip"):
                continue
            if str(t.get("reason", "")).startswith(("done_if", "事实流 report 完成（未经")) or t.get("skipped_audit"):
                t["audit_skip"] = True
                continue
            if active_count() >= int(cfg.get("max_windows", 6)):
                break
            name = "au-" + slug(tid)
            if open_win("audit", tid, name):
                t["audit_win"] = name
        for tid, t in tasks.items():
            v = fdone.get("audit:" + tid)
            if v and t.get("audit_win") and not t.get("audit_seen"):
                t["audit_seen"] = v[0]
                close_win(t["audit_win"], v[1])
                if v[0] == "fail":
                    key = "auditfail:" + tid
                    seen_alerts.add(key)
                    alert(L, key, "audit_fail", "%s 验收没过：看验收窗报告（%s），主窗决定 retry 还是照实交" % (
                        tid, t["audit_win"]), tid)
            if t.get("audit_seen") == "fail" and not L.state["alerts"].get("auditfail:" + tid, {}).get("acked"):
                seen_alerts.add("auditfail:" + tid)
    # e) 在跑的 agent 任务出现用卡问题：把告警原文发进它的工作窗
    for key, a in L.state["alerts"].items():
        tid = a.get("task", "")
        t = tasks.get(tid, {})
        if a.get("kind") in GPU_ISSUES and is_agent(items.get(tid, {})) \
                and t.get("win") and W.get(t["win"], {}).get("state") == "open" and not a.get("sent_win"):
            a["sent_win"] = tnow
            spawn_win(cfg, "send", t["win"], text="[orchd 观测 #%d] %s。请检查你的运行并处理；确属正常（例如还在加载）就在上下文卡写一句理由。"
                      % (a["no"], a["msg"]))
        elif a.get("kind") in GPU_ISSUES and not is_agent(items.get(tid, {})) \
                and t.get("status") == "running" and tnow - a.get("first_t", tnow) > 300 and not t.get("fix_win"):
            name = "fix-%s-%d" % (slug(tid), int(t.get("fix_n", 0)) + 1)     # job 任务没有窗：开修复窗看
            if int(t.get("fix_n", 0)) < int(cfg.get("max_fix", 2)) and active_count() < int(cfg.get("max_windows", 6)) + 1:
                if open_win("fix", tid, name, reason=a["msg"]):
                    t["fix_n"], t["fix_win"] = int(t.get("fix_n", 0)) + 1, name
    # f) 残留进程：告警满宽限期后按标签收掉（只收本实例、已结束任务的进程）
    for key, a in list(L.state["alerts"].items()):
        if a.get("kind") == "orphan" and tnow - a.get("first_t", tnow) > cfg.get("orphan_grace_s", 300) and not a.get("reaped"):
            tid = a.get("task", "")
            if tasks.get(tid, {}).get("status") in ACTIVE:
                continue
            killed = 0
            for pid in tagged_pids(task=tid, inst=cfg.get("instance", "")):
                try:
                    os.kill(pid, signal.SIGTERM)
                    killed += 1
                except OSError:
                    pass
            a["reaped"] = tnow
            emit_fact(cfg, "task_set", id=tid, 备注="orchd 收掉了 %d 个残留进程（标签 ORCH_TASK=%s）" % (killed, tid))
    # g) 关窗：任务结束、修复窗交了报告或任务已重试
    for tid, t in tasks.items():
        if t.get("win") and t.get("status") in ("done", "failed", "skipped") and W.get(t["win"], {}).get("state") == "open":
            close_win(t["win"], t.get("end_t") or tnow)
        fw = t.get("fix_win")
        if fw and W.get(fw, {}).get("state") == "open":
            frep = fdone.get(fw)
            if (frep and frep[1] >= W[fw].get("opened_t", 0) - 5) or t.get("status") in ("wait", "ready", "running", "reserved", "done"):
                close_win(fw, (frep[1] if frep else None) or t.get("retry_t") or tnow)
                if t.get("status") != "failed":
                    t["fix_win"] = None
    # i) 子窗死活与长时间没动静
    watch_windows(L, items, tasks, W, seen_alerts, tnow, spawn_win)
    # h) 工作窗：任务又回到“预留/就绪”（例如重试）时允许重新开窗
    for tid, t in tasks.items():
        w = W.get(t.get("win") or "", {})
        if t.get("win") and w.get("state") in ("closed", "failed", "close_failed") and t.get("status") in ("reserved", "ready"):
            if w.get("session"):
                t["last_session"] = w["session"]
            t["win"] = None
    # j) 子窗这一轮因接口失败中断（StopFailure）：限流退避后催它接着做；key 失效换 key 回原会话；上下文超限开新窗
    api_failures(L, items, tasks, W, seen_alerts, tnow, spawn_win)


def judge_windows(L, fdone, seen_alerts, tnow):
    """判断窗（主窗用 orchd.py judge 开）：开好、交了结论 → 叫醒主窗（orch_result kind=judge，附结论原文）并关窗；
    超过 judge_timeout_s 没结论 → 升级。自动派窗开不开都生效。"""
    cfg = L.cfg
    W = L.state.setdefault("windows", {})
    for name, w in W.items():
        if w.get("kind") not in ("judge", "followup"):
            continue
        what = "判断窗" if w["kind"] == "judge" else "跟进窗"
        if w.get("state") == "opening":
            r = win_result(cfg, name, "open")
            if r is not None:
                if r.get("rc") == 0:
                    w.update(state="open", opened_t=tnow)
                    if r.get("session"):
                        w["session"] = r["session"]
                    note_session(cfg, name, w, "open")
                else:
                    w.update(state="failed", error=r.get("tail", "")[-300:])
                    emit_event(cfg, "orch_alert", kind="auto_window", task=name, msg="%s %s 开不起来：%s" % (what, name, r.get("tail", "")[-200:]))
        elif w.get("state") == "open" and not w.get("close_since"):
            rep_ = fdone.get(name)
            if rep_ and rep_[1] >= w.get("opened_t", w.get("t", 0)) - 5:
                summ = str(rep_[2].get("summary", ""))[:800]
                w["verdict"] = summ[:300]
                emit_event(cfg, "orch_result", kind=w["kind"], task=name, msg="%s %s 的结论（问题：%s）：%s" % (
                    what, name, w.get("question", "")[:120], summ))
                mark_close(w, rep_[1])
            elif tnow - w.get("opened_t", tnow) > float(cfg.get("judge_timeout_s", 1800)):
                key = "judge:" + name
                seen_alerts.add(key)
                alert(L, key, "judge_timeout", "判断窗 %s 开了 %d 分钟还没交结论：看一眼或关掉重开" % (name, (tnow - w["opened_t"]) // 60), w.get("task", ""))
        elif w.get("state") == "closing":
            r = win_result(cfg, name, "close")
            if r is not None:
                w.update(state="closed" if r.get("rc") == 0 else "close_failed", closed_t=tnow)
                if r.get("session"):
                    w["session"] = r["session"]
                note_session(cfg, name, w, "close")


def cmd_judge(a):
    """主窗要判断一件事时用（R22 第 3 条）：orchd 生成判断窗任务书、开窗；判断窗交了结论（≤ 10 行）就叫醒主窗并关窗。"""
    with Locked(a.td) as L:
        cfg = L.cfg
        name = "judge-" + slug(a.name)
        W = L.state.setdefault("windows", {})
        if W.get(name, {}).get("state") in ("opening", "open", "closing"):
            print("判断窗 %s 已经开着" % name, file=sys.stderr)
            return 1
        b = make_brief(cfg, "judge", a.about or "-", name, a.question)
        if not b:
            print("生成判断窗任务书失败（brief.py judge）", file=sys.stderr)
            return 1
        tier = (cfg.get("tier_by_kind") or {}).get("judge", "")
        spawn_win(cfg, "open", name, brief=b, tier=tier)
        W[name] = {"kind": "judge", "task": a.about or "", "state": "opening", "t": now(), "brief": b, "question": a.question[:300],
                   "tier": tier}
        L.save()
    print("判断窗 %s 正在打开（任务书 %s）；它交结论时会发 orch_result（kind=judge）叫醒你" % (name, b))
    return 0


def cmd_reopen(a):
    """任务做完后还要用它的会话（研究者追问、补一段分析、解释某个数）：用原会话 resume 开一扇跟进窗 fu-<任务>-<n>；
    它交了报告就叫醒主窗（orch_result kind=followup）、关窗。要重跑实验的不用它：用 retry（新工作窗默认也接着原会话）。"""
    with Locked(a.td) as L:
        cfg = L.cfg
        W = L.state.setdefault("windows", {})
        t = L.state["tasks"].get(a.id)
        if not t:
            print("没有这个任务：%s" % a.id, file=sys.stderr)
            return 1
        sid = "" if a.fresh else (t.get("last_session") or W.get(t.get("win") or "", {}).get("session", ""))
        if not a.fresh and not session_file(sid):
            print("没有找到 %s 的原会话记录（%s）：改开新窗，靠上下文卡与结果文件回答" % (a.id, sid or "没记下会话号"), file=sys.stderr)
            sid = ""
        n = 1 + sum(1 for k in W if k.startswith("fu-%s-" % slug(a.id)))
        name = "fu-%s-%d" % (slug(a.id), n)
        b = make_brief(cfg, "followup", a.id, name, a.question)
        if not b:
            print("生成跟进窗任务书失败（brief.py followup）", file=sys.stderr)
            return 1
        msg = ("[研究者追问] %s 回答完照任务书 %s 第 4 节交接（report id=%s）。" % (a.question[:600], b, name)) if sid else ""
        tier = (cfg.get("tier_by_kind") or {}).get("followup", "")
        spawn_win(cfg, "open", name, brief=b, resume=sid, msg=msg, tier=tier)
        W[name] = {"kind": "followup", "task": a.id, "state": "opening", "t": now(), "brief": b, "question": a.question[:300],
                   "resume": sid, "session": sid, "tier": tier}
        _log_edit(L, a.id, "开跟进窗 %s（%s）" % (name, "resume 原会话 " + sid if sid else "新会话"), a.question[:200])
        L.save()
    print("跟进窗 %s 正在打开（%s）；它交报告时会发 orch_result（kind=followup）叫醒你" % (name, "接着原会话 " + sid if sid else "新会话"))
    return 0


def win_session(cfg):
    """自动子窗所在的 tmux 会话：notes/orch.env 的 ORCH_SESSION（winctl 用的那个）；没有就用 init 的 --session。"""
    try:
        for line in open(os.path.join(cfg["td"], "notes", "orch.env"), encoding="utf-8"):
            m = re.match(r"\s*(?:export\s+)?ORCH_SESSION=[\"']?([^\"'\s#<>]+)", line)
            if m:
                return m.group(1)
    except OSError:
        pass
    return cfg.get("session", "")


def tmux_windows(session):
    """{窗名: 最近一次输出的时刻（epoch）}；tmux 不可用或会话不存在返回 None（没有数据就不下结论）。"""
    try:
        r = subprocess.run(["tmux", "list-windows", "-t", session, "-F", "#{window_name}\t#{window_activity}"],
                           capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    out = {}
    for line in r.stdout.splitlines():
        name, _, act = line.partition("\t")
        try:
            out[name.strip()] = float(act)
        except ValueError:
            out[name.strip()] = 0.0
    return out


def watch_windows(L, items, tasks, W, seen_alerts, tnow, spawn):
    """子窗死活与长时间没动静（每 30 秒查一次）：
      * 工作窗消失（崩溃、被关、key 失效）→ 保留租约、按上下文卡的恢复说明重开一次（max_win_restarts）；再消失 → 判失败、交修复窗
      * 修复窗、验收窗消失 → 允许重开（修复窗计入 max_fix）
      * 窗 win_idle_s 没有任何输出 → 发一次提醒；下一个周期仍没动静 → 升级给主窗（win_idle）
    """
    cfg = L.cfg
    sess = win_session(cfg)
    if not sess:
        return
    every = float(cfg.get("win_check_s", 30))
    if tnow - L.state.get("win_check_t", 0) >= every:
        L.state["win_check_t"] = tnow
        live = tmux_windows(sess)
        L.state["win_live"] = live
    live = L.state.get("win_live")
    if live is None:
        return
    for name, w in W.items():
        if w.get("state") != "open" or w.get("kind") == "main":
            continue
        tid = w.get("task", "")
        t = tasks.get(tid, {})
        if name not in live:
            if tnow - w.get("opened_t", tnow) < every or (L.state.get("win_check_t", 0) < w.get("opened_t", 0)):
                continue                              # 刚开好的窗：等下一次列窗再判
            w.update(state="dead", dead_t=tnow)
            emit_fact(cfg, "task_set", id=tid or "-", 备注="子窗 %s 消失（崩溃、被关或 key 失效）" % name)
            if w.get("kind") == "task" and t.get("win") == name and t.get("status") in ("running", "reserved", "ready"):
                n = int(t.get("win_restarts", 0))
                if n < int(cfg.get("max_win_restarts", 1)):
                    t["win_restarts"], t["win"] = n + 1, None
                    if t.get("status") == "running":
                        if is_gpu(items.get(tid, {})):
                            t.update(status="reserved", reserved_t=tnow)     # 租约保留，新窗接着做
                        else:
                            t["status"] = "ready"
                    if w.get("session") and (w.get("fail") or {}).get("kind") != "context":
                        t["resume_sid"] = w["session"]            # 1.7.0 的经验：别丢上下文，resume 回原会话
                        t["resume_msg"] = ("[orchd] 这扇窗刚才意外关了，已用原会话恢复。从中断处继续：先看上下文卡末尾，"
                                           "核对已经做过的外部动作，不要重复。")
                    t["why"] = "子窗 %s 消失：%s重开（第 %d 次）" % (name, "用原会话 resume " if t.get("resume_sid") else "按上下文卡", n + 1)
                else:
                    finish(L, tid, "failed", "子窗 %s 第 %d 次消失（看 tmux 与 key 池）：交修复窗" % (name, n + 1))
                    t["alerted"] = False
            elif w.get("kind") == "fix" and t.get("fix_win") == name:
                t["fix_win"] = None
            elif w.get("kind") == "audit" and t.get("audit_win") == name and not t.get("audit_seen"):
                t["audit_win"] = None
            continue
        act = live.get(name) or 0
        lim = float(cfg.get("win_idle_s", 1800))
        if act and tnow - act >= lim and tnow - w.get("opened_t", tnow) >= lim:
            if w.get("nudges", 0) == 0:
                spawn(cfg, "send", name, text="[orchd] 这个窗 %d 分钟没有任何输出。若在等长命令，在上下文卡写一句；若卡住（API 报错、"
                      "等输入、死循环），按任务书第 4 节交 report（受阻，写明卡在哪一步）。" % ((tnow - act) // 60))
                w.update(nudges=1, nudged_t=tnow)
            elif tnow - w.get("nudged_t", tnow) >= lim:
                key = "winidle:" + name
                seen_alerts.add(key)
                alert(L, key, "win_idle", "子窗 %s %d 分钟没有任何输出（提醒过一次）：主窗看屏；卡死就 winctl.sh close %s，"
                      "orchd 会按上下文卡重开" % (name, (tnow - act) // 60, name), tid)


def api_failures(L, items, tasks, W, seen_alerts, tnow, spawn):
    """子窗这一轮因接口失败中断（hooks 的 StopFailure）后，那扇窗停在输入提示，没人管就一直空着：
      * 限流、其他接口错误 → 等 api_backoff_s × 2^n（最多 15 分钟）后发一句“接着做”；连续 max_api_retries 次仍失败 → 升级
      * key 失效、没有权限 → 换一把 key，用原会话 resume 接着做（上下文不丢）
      * 上下文超过模型上限 → 只能开新窗靠任务书与上下文卡接着做（1.7.0 实测：超限的会话 resume 仍然 400）
    窗自己恢复了（失败之后又有一轮正常结束或新的输入）就不管。"""
    cfg = L.cfg
    for name, w in W.items():
        f = w.get("fail")
        if not f or f.get("handled") or w.get("state") != "open":
            continue
        if float(w.get("last_stop_t") or 0) > f["t"] or float(w.get("last_prompt_t") or 0) > f["t"] + 1:
            f["handled"] = "recovered"
            continue
        tid = w.get("task", "")
        t = tasks.get(tid, {})
        kind, n = f.get("kind"), int(w.get("api_fail_n", 0))
        if kind in ("rate", "other"):
            if tnow - f["t"] < min(float(cfg.get("api_backoff_s", 60)) * 2 ** n, 900):
                continue
            if n >= int(cfg.get("max_api_retries", 4)):
                key = "api:" + name
                seen_alerts.add(key)
                alert(L, key, "api_failures", "子窗 %s 连续 %d 次因%s中断（%s）：看 key 池与网关；必要时 winctl.sh close %s 后让 orchd 重开" % (
                    name, n + 1, "限流" if kind == "rate" else "接口出错", f.get("error", "")[:120], name), tid)
                f["handled"] = "escalated"
                continue
            spawn(cfg, "send", name, text="[orchd] 上一步因%s中断（%s）。请从中断处接着做：先看上下文卡末尾，不要重复已做过的外部动作。" % (
                "限流" if kind == "rate" else "接口出错", f.get("error", "")[:80]))
            w["api_fail_n"] = n + 1
            f["handled"] = "nudged"
        elif w.get("kind") == "task" and t.get("win") == name and t.get("status") in ("running", "reserved"):
            # 换 key（auth）或开新会话（context）：工作窗重开，租约保留
            t["win"] = None
            if is_gpu(items.get(tid, {})):
                t.update(status="reserved", reserved_t=tnow)
            else:
                t["status"] = "ready"
            if kind == "auth" and w.get("session"):
                t["resume_sid"] = w["session"]
                t["resume_msg"] = "[orchd] 上一把 key 失效（%s），已换 key 回到原会话。从中断处接着做，先看上下文卡末尾。" % f.get("error", "")[:60]
            else:
                t["last_overflow"] = kind == "context"
                t.pop("resume_sid", None)
            w.update(state="closed", closed_t=tnow)
            spawn(cfg, "close", name)
            f["handled"] = "reopened"
            emit_fact(cfg, "task_set", id=tid, 备注="子窗 %s %s：%s" % (name, "换 key 回原会话" if kind == "auth" else "上下文超限，开新窗",
                                                                  f.get("error", "")[:120]))
        else:
            key = "api:" + name
            seen_alerts.add(key)
            alert(L, key, "api_failures", "子窗 %s 因%s中断（%s）：主窗看一眼，必要时关掉重开" % (
                name, "key 失效" if kind == "auth" else "上下文超限", f.get("error", "")[:120]), tid)
            f["handled"] = "escalated"


def cmd_win(a):
    """（内部）跑一次 winctl，结果写文件给守护读。"""
    cfg = read_json(paths(a.td)["cfg"], {})
    tool = winctl_path(cfg)
    argv = ([sys.executable, "-I", tool] if tool.endswith(".py") else ["bash", tool]) + [a.op, a.name]
    if a.op == "open":
        argv.append(a.brief)
        for k, v in (("--task", a.task), ("--fix", a.fix), ("--tier", a.tier), ("--resume", a.resume), ("--msg", a.msg)):
            if v:
                argv += [k, v]
    elif a.op == "send":
        argv.append(a.text)
    env = dict(os.environ, ORCH_TD=a.td)
    try:
        r = subprocess.run(argv, capture_output=True, text=True, timeout=cfg.get("win_open_timeout_s", 300), env=env)
        rc, out = r.returncode, r.stdout + r.stderr
    except (OSError, subprocess.TimeoutExpired) as e:
        rc, out = 124, repr(e)
    m = re.findall(r"session=([0-9a-fA-F-]{36})", out)
    res = {"rc": rc, "tail": out[-1500:], "t": now()}
    if m:
        res["session"] = m[-1]                         # winctl 开窗时指定、关窗时从屏上读到的会话号
    write_json(os.path.join(paths(a.td)["dir"], "win", "%s.%s.json" % (a.name, a.op)), res)
    return 0


def _health(cfg, queue, st):
    """巡检的判据（health 与 wait 共用）：返回 (给人看的几行, 要主窗处理的事)。"""
    items = items_by_id(queue)
    tasks = st.get("tasks", {})
    W = st.get("windows", {})
    issues, lines = [], []
    hb = now() - st.get("heartbeat", 0)
    lines.append("== orchd 心跳 %d 秒前%s；自动派窗 %s；子窗 %d 扇在用" % (hb, "" if hb < cfg.get("heartbeat_stale_s", 60) else "（过期！）",
                 "开" if cfg.get("auto_windows") else "关",
                 sum(1 for w in W.values() if w.get("state") in ("opening", "open", "closing"))))
    if hb >= cfg.get("heartbeat_stale_s", 60):
        issues.append("守护没在跑：照 references/main-loop.md 1.4 重起（不要 init）")
    snap = st.get("snapshot") or {}
    cards = []
    for g in snap.get("gpus", []):
        v = tasks.get(g.get("lease"), {}).get("verdict", "") if g.get("lease") else ""
        cards.append("%s:%s%s" % (g["idx"], g.get("lease") or ("锁" if g.get("lock") else "空"), "(" + v + ")" if v else ""))
    lines.append("== 卡：" + "  ".join(cards))
    running = [(k, t) for k, t in tasks.items() if t.get("status") in ACTIVE]
    for k, t in sorted(running):
        age = (now() - t.get("last_progress_t", now())) / 60
        w = W.get(t.get("win") or "", {})
        lines.append("  %-10s %-8s 核查 %-10s 进度 %3d 分钟前更新  窗 %s(%s)  %s" % (k, t["status"], t.get("verdict", "-"), age,
                     t.get("win") or t.get("window", "-"), w.get("state", "-"),
                     ("启动用时 %d 秒" % t["startup_s"]) if t.get("confirmed_t") else t.get("start_stage", "")))
        if t.get("verdict") in GPU_ISSUES and not cfg.get("auto_windows"):
            issues.append("%s 核查 %s：开修复窗（templates/FIX_BRIEF.md）" % (k, t["verdict"]))
    esc = [x for x in (st.get("alerts") or {}).values() if not x.get("acked") and not x.get("auto")]
    for x in sorted(esc, key=lambda x: x["no"])[:10]:
        issues.append("告警 #%d %s：%s" % (x["no"], x["kind"], x["msg"][:160]))
    for name, w in W.items():
        if w.get("state") == "opening" and now() - w.get("t", now()) > cfg.get("win_open_timeout_s", 300):
            issues.append("子窗 %s 开了 %d 秒还没就绪：看 tmux 窗与 notes/sched/win/%s.open.out" % (name, now() - w["t"], name))
    fails = [k for k, t in tasks.items() if t.get("status") == "failed" and not t.get("fix_assigned")]
    if fails:
        issues.append("失败任务没有修复窗：%s" % ",".join(fails))
    acc = st.get("acct", {})
    tot = sum(v for k, v in acc.items() if k != "alloc_s") or 1
    lines.append("== 卡时：真在用 %.1f%%，启动开销 %.1f%%，可避免的空卡 %.1f%%" % (100 * acc.get("used_s", 0) / tot,
                 100 * acc.get("startup_s", 0) / tot, 100 * (acc.get("idle_avoidable_s", 0) + acc.get("idle_other_s", 0)) / tot))
    cnt = {}
    for t in tasks.values():
        cnt[t.get("status")] = cnt.get(t.get("status"), 0) + 1
    lines.append("== 任务：" + "，".join("%s %d" % kv for kv in sorted(cnt.items())))
    comp = {n: w.get("compactions", 0) for n, w in W.items() if w.get("compactions")}
    if comp:
        lines.append("== 子窗上下文压缩次数：" + "，".join("%s %d" % kv for kv in sorted(comp.items())))
    return lines, issues


def cmd_health(a):
    """主窗按需看的全局详情（定时巡检由 orchd.py wait 在后台做）；退 0 = 一切正常，1 = 有要主窗处理的事（逐条写了怎么办）。"""
    cfg, queue, st = load_ro(a.td)
    if not cfg:
        print("FAIL 还没 init")
        return 1
    lines, issues = _health(cfg, queue, st)
    print("\n".join(lines))
    if issues:
        print("== 要主窗处理的（%d）：" % len(issues))
        for x in issues:
            print("  - " + x)
        return 1
    print("== 一切正常：不用做任何事，重挂等待即可")
    return 0

WAKE_NOTICE_KINDS = {"preset", "milestone", "gate"}   # 这些 orch_result 只记进下次醒来的摘要，不叫醒主窗（SuperAgent 的 notice）


def _status_line(cfg, queue, st):
    items = items_by_id(queue)
    tasks = st.get("tasks", {})
    g = (st.get("snapshot") or {}).get("gpus", [])
    lease = sum(1 for x in g if x.get("lease"))
    okn = sum(1 for x in g if x.get("lease") and tasks.get(x["lease"], {}).get("verdict") in ("ok", "gap"))
    real = [k for k in tasks if not is_milestone(items.get(k, {}))]

    def cnt(*ss):
        return sum(1 for k in real if tasks[k].get("status") in ss)
    acc = st.get("acct", {})
    tot = sum(v for k, v in acc.items() if k != "alloc_s") or 1
    al = sum(1 for x in (st.get("alerts") or {}).values() if not x.get("acked") and not x.get("auto"))
    return "卡 %d/%d 有任务（在用 %d）｜在跑 %d 就绪 %d 等待 %d｜完成 %d/%d｜真在用 %.0f%% 启动开销 %.0f%%｜未确认告警 %d" % (
        lease, len(g), okn, cnt("running", "reserved"), cnt("ready"), cnt("wait"), cnt("done", "skipped"), len(real),
        100 * acc.get("used_s", 0) / tot, 100 * acc.get("startup_s", 0) / tot, al)


def cmd_wait(a):
    """主窗唯一的等待（R11；Bash 的 run_in_background 挂着）。巡检在这里每分钟做一次，不进主窗上下文；
    只有要主窗处理的事才返回，并且只打印十几行：
      0 有事件：子窗要研究者决定的问题、要主窗决定的升级、结果就绪、判断窗或跟进窗的结论
      1 巡检发现新的问题        2 守护没在跑        3 到了定时汇报（没事，直接重挂）        4 用法错
    结束、按预案处理、门控结论、里程碑、抢占这类通知不叫醒主窗，记进下次醒来时的摘要（借鉴 SuperAgent 的 relay / notice 两分）。"""
    P = paths(a.td)
    cfg = read_json(P["cfg"], {})
    if not cfg:
        print("还没 init：%s" % P["cfg"])
        return 4
    curp = os.path.join(P["dir"], "main_wait.json")
    cur = read_json(curp, {}) or {}
    evp = os.path.join(cfg.get("events_dir") or os.path.join(a.td, "notes", "events"), "orchd.jsonl")
    off = int(cur.get("off", 0))
    reported = dict(cur.get("reported", {}))
    notes = list(cur.get("notes", []))
    last_status = cur.get("last_status", {})
    summary_every = float(a.timeout or cfg.get("summary_every_s", 7200))
    health_every = float(a.health_every or cfg.get("wait_health_every_s", 60))
    realert = float(cfg.get("wait_realert_s", 3600))
    stale = float(cfg.get("heartbeat_stale_s", 60))
    t0, last_h = now(), 0.0
    write_json(curp, dict(cur, waiting_since=ts(t0), waiting_since_t=t0))

    def ikey(x):
        return re.sub(r"\d+", "#", x)[:100]
    wake, found, code, reason = [], [], 3, "定时汇报"
    while True:
        try:
            size = os.path.getsize(evp)
        except OSError:
            size = 0
        if size < off:
            off = 0
        if size > off:
            with open(evp, "rb") as f:
                f.seek(off)
                chunk = f.read(size - off)
            cut = chunk.rfind(b"\n")
            if cut >= 0:
                off += cut + 1
                for line in chunk[:cut].splitlines():
                    try:
                        e = json.loads(line)
                    except ValueError:
                        continue
                    ev, kind = e.get("event", ""), e.get("kind", "")
                    if ev in ("orch_alert", "orch_attention") or (ev == "orch_result" and kind not in WAKE_NOTICE_KINDS):
                        wake.append(e)
                    elif ev in ("orch_result", "orch_sched"):
                        notes.append(str(e.get("msg", ""))[:90])
        _, queue, st = load_ro(a.td)
        if wake:
            code, reason = 0, "有 %d 件事" % len(wake)
            break
        hb = now() - float(st.get("heartbeat", 0) or 0)
        if hb > 2 * stale:
            code, reason = 2, "守护没在跑"
            break
        if now() - last_h >= health_every:
            last_h = now()
            _, issues = _health(cfg, queue, st)
            found = [x for x in issues if now() - float(reported.get(ikey(x), 0)) >= realert]
            if found:
                code, reason = 1, "巡检发现 %d 件事" % len(found)
                break
        if now() - t0 >= summary_every:
            break
        time.sleep(a.poll)
    items, tasks = items_by_id(queue), st.get("tasks", {})
    lines = ["== orchd wait：%s（等了 %d 分钟）" % (reason, (now() - t0) // 60)]
    label = {"orch_attention": "需要研究者决定", "orch_alert": "要主窗决定"}
    for e in wake[:10]:
        lab = label.get(e.get("event")) or {"judge": "判断窗结论", "followup": "跟进窗结论"}.get(e.get("kind"), "结果就绪")
        lines.append("  [%s] %s%s" % (lab, (e.get("task") + "：") if e.get("task") and e.get("task") not in str(e.get("msg", ""))[:40] else "",
                                       str(e.get("msg", ""))[:300]))
    if len(wake) > 10:
        lines.append("  …还有 %d 条（notes/events/orchd.jsonl）" % (len(wake) - 10))
    if code == 2:
        lines.append("  守护心跳 %d 秒前：照 references/main-loop.md 1.4 重起守护（不要 init），再重挂 orchd.py wait" % hb)
    for x in found[:8]:
        lines.append("  [巡检] " + x[:220])
    if code in (0, 1):                                    # 这一刻还在的问题都算报过，免得同一件事反复叫醒
        _, issues = _health(cfg, queue, st)
        for x in issues:
            reported[ikey(x)] = now()
    ch = {"done": [], "failed": [], "skipped": []}
    for k, t_ in tasks.items():
        s_ = t_.get("status")
        if s_ in ch and last_status.get(k) != s_ and not is_milestone(items.get(k, {})):
            ch[s_].append(k)
    dig = ["%s %s" % (n, ",".join(sorted(v)[:8]) + ("等 %d 个" % len(v) if len(v) > 8 else "")) for n, v in
           (("完成", ch["done"]), ("失败", ch["failed"]), ("跳过", ch["skipped"])) if v]
    if dig or notes:
        lines.append("-- 这段时间（不用处理）：" + "；".join(dig + notes[-4:])[:400])
    lines.append("-- 现在：" + _status_line(cfg, queue, st))
    lines.append({0: "-- 处理完：用过的告警 orchd.py ack --td %s <号>；再重挂 orchd.py wait --td %s（Bash run_in_background）",
                  1: "-- 处理完：用过的告警 orchd.py ack --td %s <号>；再重挂 orchd.py wait --td %s（Bash run_in_background）",
                  2: "-- 重起守护后：重挂 orchd.py wait --td %s%s",
                  3: "-- 没有要处理的事：不用汇报，直接重挂 orchd.py wait --td %s%s"}[code] % (
        (a.td, a.td) if code in (0, 1) else (a.td, "（Bash run_in_background）")))
    print("\n".join(lines))
    cut_t = now() - 3 * realert
    write_json(curp, {"off": off, "reported": {k: v for k, v in reported.items() if v > cut_t}, "notes": [],
                      "last_status": {k: t_.get("status") for k, t_ in tasks.items()}, "woke": ts(), "woke_code": code})
    return code

# ---------------------------------------------------------------- 包装进程（_run / exec）

def set_subreaper():
    try:
        libc = ctypes.CDLL(None, use_errno=True)
        libc.prctl(36, 1, 0, 0, 0)      # PR_SET_CHILD_SUBREAPER
    except (OSError, AttributeError):
        pass

def children_of(pid):
    out = []
    for d in os.listdir("/proc"):
        if d.isdigit() and ppid_of(int(d)) == pid:
            out.append(int(d))
    return out

def descendants(pid):
    seen, stack = [], children_of(pid)
    while stack:
        p = stack.pop()
        if p in seen:
            continue
        seen.append(p)
        stack.extend(children_of(p))
    return seen

def stop_tree(child, run, grace, inst=""):
    """先 TERM 整个进程组与带本运行标签的进程，宽限后 KILL；只动自己的（运行号 + 本编排实例都要对上）。"""
    def targets():
        ps = set(descendants(os.getpid())) | set(tagged_pids(run=run, inst=inst))
        ps.discard(os.getpid())
        return ps
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        pass
    for p in targets():
        try:
            os.kill(p, signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            pass
    t0 = now()
    while now() - t0 < grace:
        if not [p for p in targets() if pid_alive(p)]:
            break
        time.sleep(0.5)
        for p in targets():                 # 回收挂到 subreaper 下的僵尸；不碰主子进程（留给 child.wait 取 rc）
            if p != child.pid:
                try:
                    os.waitpid(p, os.WNOHANG)
                except (ChildProcessError, OSError):
                    pass
    for p in targets():
        try:
            os.kill(p, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass

def run_wrapped(task, run, cmd, cwd, env_add, log_path, grace, info_path, exit_path, argv_cmd=None):
    """在新进程组里跑命令；输出逐行写日志并 flush（被强杀也不会像 tee 那样截断已写内容）。"""
    set_subreaper()
    env = dict(os.environ)
    env.update(env_add)
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    for d in (env.get("ORCH_TMP"), env.get("RAY_TMPDIR")):
        if d:
            os.makedirs(d, exist_ok=True)
    log = open(log_path, "ab", buffering=0)
    log.write(("== %s 开始 %s run=%s GPU=%s 端口段=%s\n== cmd: %s\n" % (ts(), task, run, env.get("CUDA_VISIBLE_DEVICES", "-"),
               env.get("ORCH_PORT_BASE", "-"), cmd if cmd else " ".join(argv_cmd or []))).encode())
    popen_args = argv_cmd if argv_cmd else ["bash", "-lc", cmd]
    child = subprocess.Popen(popen_args, cwd=cwd or None, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             stdin=subprocess.DEVNULL, start_new_session=True)
    if info_path:
        write_json(info_path, {"pid": os.getpid(), "child": child.pid, "start": ts(), "task": task, "run": run})
    state = {"sig": None}

    def on_sig(signum, frame):
        state["sig"] = signum
        log.write(("== %s 收到信号 %d：停止本运行的进程树（宽限 %d s）\n" % (ts(), signum, grace)).encode())
        stop_tree(child, run, grace, env_add.get("ORCH_INST", ""))
    signal.signal(signal.SIGTERM, on_sig)
    signal.signal(signal.SIGINT, on_sig)
    signal.signal(signal.SIGHUP, on_sig)
    for line in iter(child.stdout.readline, b""):
        log.write(line)
        if not env.get("ORCH_QUIET"):
            try:
                sys.stdout.buffer.write(line)
                sys.stdout.flush()
            except (OSError, ValueError):
                pass
    rc = child.wait()
    # 子进程退了，但 ray/sglang 之类 daemonize 出去的孙进程（挂在 subreaper 下）可能还占着卡和端口
    left = [p for p in set(descendants(os.getpid())) | set(tagged_pids(run=run)) if pid_alive(p) and p != os.getpid()]
    if left:
        log.write(("== %s 主命令已退出，回收残留进程 %s\n" % (ts(), left[:20])).encode())
        stop_tree(child, run, min(grace, 15), env_add.get("ORCH_INST", ""))
    log.write(("== %s 结束 rc=%s\n" % (ts(), rc)).encode())
    log.close()
    if exit_path:
        write_json(exit_path, {"rc": rc, "end": ts(), "signal": state["sig"], "killed": bool(state["sig"]),
                               "leftover_reaped": len(left)})
    return rc

def cmd_run(a):
    spec = read_json(a.spec)
    rd = os.path.dirname(a.spec)
    rc = run_wrapped(spec["task"], spec["run"], spec["cmd"], spec["cwd"], spec["env"], os.path.join(rd, "console.log"),
                     int(spec.get("grace_s", 30)), os.path.join(rd, "wrapper.json"), os.path.join(rd, "exit.json"))
    return rc

def cmd_exec(a):
    if not a.cmd:
        print("用法：orchd.py exec --td 任务目录 ID -- 命令...", file=sys.stderr)
        return 2
    cmdv = a.cmd
    with Locked(a.td) as L:
        t = L.state["tasks"].get(a.id)
        it = items_by_id(L.queue).get(a.id)
        if not t or not it:
            print("没有这个任务：%s" % a.id, file=sys.stderr)
            return 1
        if is_gpu(it) and t.get("status") not in ACTIVE:
            print("拒绝：%s 现在没有 GPU 租约（状态 %s）。GPU 命令只能在租约内跑，等 orchd 预留后由主窗 start。"
                  % (a.id, t.get("status")), file=sys.stderr)
            return 4
        if t.get("status") == "reserved":
            t["status"] = "running"
        n = len(t.setdefault("exec_runs", [])) + 1
        run = "%s-x%d-%s-%s" % (a.id, n, a.name or time.strftime("%Y%m%dT%H%M%S"), L.cfg.get("instance", "x")[:4])
        rd = os.path.join(paths(a.td)["runs"], a.id, run)
        if t.get("slot") is None:
            t["slot"] = free_slot(L.state, L.cfg) or 0
            L.state["slots"][a.id] = t["slot"]
        env = run_env(L.cfg, it, t, run)
        env["ORCH_RUN_DIR"] = rd
        env["ORCH_STARTED"] = os.path.join(rd, ".started")
        env["ORCH_PROGRESS"] = os.path.join(rd, "progress.json")
        t["exec_runs"].append({"run": run, "dir": rd, "pid": os.getpid(), "start": ts()})
        t["run_dir"] = t.get("run_dir") or rd
        L.save()
    env["ORCH_QUIET"] = ""
    env["ORCH_EXEC"] = "1"                        # cellrun.py 据此默认不还卡（子窗后面的命令可能还要用）
    rc = run_wrapped(a.id, run, None, os.getcwd(), env, os.path.join(rd, "console.log"), a.grace,
                     os.path.join(rd, "wrapper.json"), os.path.join(rd, "exit.json"), argv_cmd=cmdv)
    with Locked(a.td) as L:
        t = L.state["tasks"].get(a.id, {})
        for r in t.get("exec_runs", []):
            if r["run"] == run:
                r.update(rc=rc, end=ts())
        t["last_exec_end_t"] = now()
        L.save()
    return rc

def cmd_env(a):
    with Locked(a.td) as L:
        t = L.state["tasks"].get(a.id)
        it = items_by_id(L.queue).get(a.id)
        if not t or not it:
            print("没有这个任务：%s" % a.id, file=sys.stderr)
            return 1
        if is_gpu(it) and t.get("status") not in ACTIVE:
            print("# %s 没有租约（状态 %s）" % (a.id, t.get("status")), file=sys.stderr)
            return 4
        env = run_env(L.cfg, it, t, t.get("run") or (a.id + "-manual"))
    for k, v in sorted(env.items()):
        print("export %s=%s" % (k, shlex.quote(v)))
    return 0

# ---------------------------------------------------------------- 主窗与子窗的动作

def set_status(a, fn):
    with Locked(a.td) as L:
        if a.id not in L.state["tasks"]:
            print("没有这个任务：%s" % a.id, file=sys.stderr)
            return 1
        r = fn(L, L.state["tasks"][a.id])
        L.save()
        return r or 0

def cmd_start(a):
    def f(L, t):
        if t.get("status") not in ("reserved", "ready", "running"):
            print("%s 状态是 %s，不能 start" % (a.id, t.get("status")), file=sys.stderr)
            return 1
        it = items_by_id(L.queue)[a.id]
        if is_gpu(it) and t.get("status") == "ready":
            print("%s 还没有预留到卡；等 orchd 预留（orch_sched 事件）后再 start" % a.id, file=sys.stderr)
            return 1
        t.update(status="running", window=a.window, start_t=now(), started=ts(), cooldown_until=0)
        emit_fact(L.cfg, "dispatch", id=a.id, window=a.window)
        print("%s -> running（窗 %s，GPU %s）" % (a.id, a.window, ",".join(t.get("gpus", [])) or "无"))
    return set_status(a, f)

def cmd_done(a):
    def f(L, t):
        if t.get("status") in TERMINAL:
            print("%s 已是 %s" % (a.id, t["status"]))
            return 0
        finish(L, a.id, "done", evidence=a.evidence or "")
        print("%s -> done" % a.id)
    return set_status(a, f)

def cmd_fail(a):
    def f(L, t):
        finish(L, a.id, "failed", a.reason)
        t["alerted"] = True
        emit_event(L.cfg, "orch_alert", kind="failed", task=a.id, msg="%s 失败：%s" % (a.id, a.reason))
        print("%s -> failed" % a.id)
    return set_status(a, f)

def cmd_retry(a):
    def f(L, t):
        if t.get("status") in ACTIVE:
            print("%s 还在跑，先 kill" % a.id, file=sys.stderr)
            return 1
        t.update(status="wait", reason="retry", alerted=False, proposed=False, fix_assigned="", cooldown_until=0,
                 retry_t=now(), verdict="", skip_checked=None, skip_check=None)
        t.pop("dropped", None)                   # 放弃过的任务重新做：它的备选不再因“放弃”而就绪
        print("%s -> wait（下一轮重新调度）" % a.id)
    return set_status(a, f)

def cmd_fixwin(a):
    def f(L, t):
        t["fix_assigned"] = a.window
        print("%s 的修复窗：%s" % (a.id, a.window))
    return set_status(a, f)

def cmd_accept(a):
    """主窗确认“这个失败照实交、不再修”（例如某格失败两次）：check 不再报它；after 依赖照常放行。"""
    def f(L, t):
        if t.get("status") != "failed":
            print("%s 不是 failed（是 %s）" % (a.id, t.get("status")), file=sys.stderr)
            return 1
        t["fix_assigned"] = "accepted: " + a.reason
        emit_fact(L.cfg, "task_set", id=a.id, 备注="失败照实交：" + a.reason)
        print("%s：失败已确认照实交（%s）" % (a.id, a.reason))
    return set_status(a, f)

def cmd_ask(a):
    """子窗要研究者决定一件事时用（不必停下手上能继续的工作）：记下问题，叫醒主窗，主窗把原话转给研究者。"""
    def f(L, t):
        t["last_report"] = dict(t.get("last_report") or {}, attention=a.question, seq=now(), attention_sent=None)
        print("已记下要研究者决定的问题（%s）：%s" % (a.id, a.question))
    return set_status(a, f)

def cmd_hold(a, on):
    def f(L, t):
        t["hold"] = on
        if getattr(a, "reason", ""):
            _log_edit(L, a.id, "hold=%s" % on, a.reason)
        print("%s hold=%s" % (a.id, on))
    return set_status(a, f)

def cmd_gate(a):
    with Locked(a.td) as L:
        L.state["gates"][a.name] = a.verdict
        L.save()
        emit_fact(L.cfg, "gate", gate=a.name, verdict=a.verdict, evidence=a.evidence or "")
        emit_event(L.cfg, "orch_result", kind="gate", task=a.name, msg="门 %s = %s" % (a.name, a.verdict))
    print("gate %s = %s" % (a.name, a.verdict))
    return 0

def cmd_kill(a):
    with Locked(a.td) as L:
        t = L.state["tasks"].get(a.id)
        if not t:
            print("没有这个任务：%s" % a.id, file=sys.stderr)
            return 1
        pids = []
        if t.get("wrapper_pid"):
            pids.append(int(t["wrapper_pid"]))
        pids += [int(r["pid"]) for r in t.get("exec_runs", []) if pid_alive(r.get("pid"))]
        run = t.get("run")
    for p in pids:
        try:
            os.kill(p, signal.SIGTERM)          # 包装进程收到后负责停自己的进程树
        except (ProcessLookupError, PermissionError):
            pass
    t0 = now()
    while now() - t0 < a.grace + 20 and any(pid_alive(p) for p in pids):
        time.sleep(0.5)
    left = tagged_pids(task=a.id, inst=read_json(paths(a.td)["cfg"], {}).get("instance", ""))
    for p in left:                               # 包装进程不在了，按标签兜底（只动带本任务标签的）
        try:
            os.kill(p, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    print("已停 %s：包装进程 %s，按标签兜底 %d 个%s" % (a.id, pids or "无", len(left), "（run %s）" % run if run else ""))
    return 0

def cmd_ack(a):
    with Locked(a.td) as L:
        n = 0
        for k, al in L.state["alerts"].items():
            if a.no == "all" or str(al.get("no")) == a.no:
                al["acked"] = True
                n += 1
        L.save()
    print("已确认 %d 条告警" % n)
    return 0

# ---------------------------------------------------------------- 运行中改计划（只由主窗或判断窗按研究者/证据决定后执行）

EDITABLE = {"prio_boost", "gpu_options", "res", "deps", "after", "deps_optional", "strict_tier", "preemptible",
            "hold_after_s", "warmup_s", "stall_s", "util_min", "allow_partial", "retries", "partition", "notify", "gate",
            "if_fail", "max_h", "start_hold_s", "lost_s", "started_if", "started_log"}


def _log_edit(L, tid, what, reason):
    rec = {"t": ts(), "task": tid, "what": what, "reason": reason}
    L.state.setdefault("edits", []).append(rec)
    emit_fact(L.cfg, "task_set", id=tid or "-", 备注=("运行中修改：%s（%s）" % (what, reason))[:300])
    with open(os.path.join(L.cfg["td"], "notes", "decisions.md"), "a", encoding="utf-8") as f:
        f.write("%s｜orchd 运行中修改 %s：%s｜%s｜%s\n" % (ts(), tid or "-", what, reason, tid or "-"))


def _has_cycle(items):
    color = {}

    def dfs(x):
        color[x] = 1
        for d in dep_ids(items[x]):
            if d not in items:
                continue
            if color.get(d) == 1 or (color.get(d) is None and dfs(d)):
                return True
        color[x] = 2
        return False
    return any(color.get(x) is None and dfs(x) for x in items)


def cmd_edit(a):
    """改一个任务的排程字段（写进 orchd 自己的运行清单 queue.json；任务包的 manifest 不动），必须写理由。"""
    with Locked(a.td) as L:
        items = items_by_id(L.queue)
        it = items.get(a.id)
        if not it:
            print("没有这个任务：%s" % a.id, file=sys.stderr)
            return 1
        changes = []
        for kv in a.set or []:
            k, v = kv.split("=", 1)
            if k not in EDITABLE:
                print("不能改 %s（可改：%s）" % (k, ",".join(sorted(EDITABLE))), file=sys.stderr)
                return 2
            try:
                val = json.loads(v)
            except ValueError:
                val = v
            if k == "gpu_options":
                if not isinstance(val, dict) or not all(str(x).isdigit() and int(x) > 0 for x in val):
                    print("gpu_options 要写成 {\"卡数\": 偏好或 null}", file=sys.stderr)
                    return 2
                val = {str(x): y for x, y in val.items()}
            if k == "res" and not (isinstance(val, dict) and all(x in ("x", "s") for x in val.values())):
                print('res 要写成 {"令牌名": "x" 或 "s"}', file=sys.stderr)
                return 2
            if k in ("deps", "after", "deps_optional") and not isinstance(val, list):
                print("%s 要写成任务号列表" % k, file=sys.stderr)
                return 2
            if k in ("deps", "after", "deps_optional"):
                bad = [x for d in val for x in str(d).split("|") if x not in items or x == a.id]
                if bad:
                    print("依赖不存在或指向自己：%s" % bad, file=sys.stderr)
                    return 2
            old = it.get(k)
            it[k] = val
            changes.append("%s: %s -> %s" % (k, json.dumps(old, ensure_ascii=False), json.dumps(val, ensure_ascii=False)))
        if _has_cycle(items):
            print("改完会出现依赖环，没有保存", file=sys.stderr)
            return 1
        L.save_queue()
        for c in changes:
            _log_edit(L, a.id, c, a.reason)
        running = L.state["tasks"].get(a.id, {}).get("status") in ACTIVE
        L.save()
    print("%s 已改：%s%s" % (a.id, "；".join(changes), "（它正在跑：本次运行不受影响，下一次调度才按新值）" if running else ""))
    return 0


def cmd_dep(a):
    """加或去掉一个前序依赖（真实执行时发现还需要别的东西：先 add 新任务，再 dep --add）。"""
    with Locked(a.td) as L:
        items = items_by_id(L.queue)
        it = items.get(a.id)
        if not it or (a.add and any(x not in items or x == a.id for x in a.add.split("|"))):
            print("任务不存在或指向自己：%s %s" % (a.id, a.add or ""), file=sys.stderr)
            return 1
        if not (a.add or a.remove):
            print("要给 --add 或 --remove", file=sys.stderr)
            return 2
        key = "after" if a.after else "deps"
        cur = list(it.get(key, []))
        if a.add and a.add not in cur:
            cur.append(a.add)
        if a.remove:
            cur = [d for d in cur if d != a.remove]
        old = it.get(key, [])
        it[key] = cur
        if _has_cycle(items):
            it[key] = old
            print("加了会出现依赖环，没有保存", file=sys.stderr)
            return 1
        t = L.state["tasks"].get(a.id, {})
        if t.get("status") == "ready" and a.add and L.state["tasks"].get(a.add, {}).get("status") not in ("done",):
            t["status"], t["why"] = "wait", "新加了前序 %s" % a.add
        L.save_queue()
        _log_edit(L, a.id, "%s: %s -> %s" % (key, old, cur), a.reason)
        note = ""
        if t.get("status") in ACTIVE:
            note = "（%s 正在跑：新依赖只约束下一次调度；要它等前序，先 orchd.py kill 再 retry）" % a.id
        elif t.get("status") in TERMINAL or t.get("status") == "failed":
            note = "（%s 已是 %s：要按新依赖重做，用 orchd.py retry）" % (a.id, t.get("status"))
        L.save()
    print("%s 的 %s：%s%s" % (a.id, key, cur, note))
    return 0


def cmd_prio(a):
    a.set = ["prio_boost=%s" % a.boost]
    return cmd_edit(a)


def cmd_drop(a):
    """放弃一个任务（确实不可执行、或研究者决定不做）：记为跳过；严格依赖它的任务随之跳过，after 依赖照常放行。"""
    with Locked(a.td) as L:
        t = L.state["tasks"].get(a.id)
        if not t:
            print("没有这个任务：%s" % a.id, file=sys.stderr)
            return 1
        if t.get("status") in ACTIVE:
            print("%s 还在跑：先 orchd.py kill 再 drop" % a.id, file=sys.stderr)
            return 1
        if t.get("status") == "done":
            print("%s 已完成，不能放弃（要重做用 retry）" % a.id, file=sys.stderr)
            return 1
        t.update(status="skipped", why="放弃：" + a.reason, ended=ts(), reason="dropped: " + a.reason, dropped=True)
        items = items_by_id(L.queue)
        down = sorted(x for x, it in items.items() if a.id in it.get("deps", []) and a.id not in it.get("deps_optional", []))
        _log_edit(L, a.id, "放弃（跳过）；严格依赖它的会跳过：%s" % (",".join(down) or "无"), a.reason)
        L.save()
    print("%s 已放弃；严格依赖它的任务（下一轮跳过）：%s" % (a.id, ",".join(down) or "无"))
    return 0


def cmd_shrink(a):
    """把租约里用不上的卡还给调度（cellrun.py 在剩下的格用不满租约时自动调用；子窗也可以手工还）。
    只能还确实没有本任务进程的卡；至少留一张（全还就是任务结束，用 done）。"""
    cards = [c.strip() for c in a.gpus.split(",") if c.strip()]
    with Locked(a.td) as L:
        t = L.state["tasks"].get(a.id)
        if not t or t.get("status") not in ACTIVE:
            print("%s 没有在跑的租约" % a.id, file=sys.stderr)
            return 1
        bad = [c for c in cards if c not in t.get("gpus", [])]
        keep = [c for c in t.get("gpus", []) if c not in cards]
        if bad or not cards or not keep:
            print("只能还 %s 租约里的卡、且至少留一张（租约 %s，要还 %s）" % (a.id, ",".join(t.get("gpus", [])), a.gpus), file=sys.stderr)
            return 1
        gpus, apps = gpu_sample(L.cfg)
        if gpus is not None:
            by_uuid = {g["uuid"]: g["idx"] for g in gpus}
            busy = sorted({by_uuid.get(u) for pid, u, _ in apps
                           if by_uuid.get(u) in cards and owner_of(pid, {}, L.cfg.get("instance", "")) == a.id})
            if busy:
                print("GPU %s 上还有 %s 的进程，不能还" % (",".join(busy), a.id), file=sys.stderr)
                return 1
        unlock_cards(L.cfg["lockdir"], cards, owner_prefix(L.cfg) + a.id)
        t["gpus"] = keep
        t.setdefault("released", []).append({"t": ts(), "gpus": cards, "reason": a.reason})
        emit_fact(L.cfg, "task_set", id=a.id, 备注="还卡 %s（%s）；租约剩 %s" % (",".join(cards), a.reason, ",".join(keep)))
        L.save()
    print("%s 还了 GPU %s，租约剩 %s" % (a.id, ",".join(cards), ",".join(keep)))
    return 0


def cmd_cordon(a, on):
    """暂停把某张卡分给任何任务（坏卡、XID/ECC 报错、别人长期占用）；卡上在跑的任务不受影响。"""
    with Locked(a.td) as L:
        cur = set(L.state.get("cordoned", []))
        for g in a.gpus.split(","):
            (cur.add if on else cur.discard)(g.strip())
        L.state["cordoned"] = sorted(cur)
        _log_edit(L, "", ("停用 GPU %s" if on else "恢复 GPU %s") % a.gpus, a.reason)
        L.save()
    print("停用的卡：%s" % (",".join(sorted(cur)) or "无"))
    return 0


def cmd_config(a):
    """运行中改守护的设置（如 max_windows、hold_after_s、max_fix、auto_windows），下一轮生效。"""
    with Locked(a.td) as L:
        cfg = read_json(L.p["cfg"], {})
        for kv in a.set or []:
            k, v = kv.split("=", 1)
            if k in ("td", "lockdir", "instance", "manifest"):
                print("%s 不能在运行中改" % k, file=sys.stderr)
                return 2
            try:
                cfg[k] = json.loads(v)
            except ValueError:
                cfg[k] = v
            _log_edit(L, "", "设置 %s = %s" % (k, v), a.reason)
        write_json(L.p["cfg"], cfg)
        L.save()
    print("已保存设置（下一轮生效）")
    return 0

# ---------------------------------------------------------------- 只读视图

def load_ro(td):
    p = paths(td)
    return read_json(p["cfg"], {}), read_json(p["queue"], {"items": []}), read_json(p["state"], {})

def cmd_status(a):
    cfg, queue, st = load_ro(a.td)
    if not cfg:
        print("还没 init", file=sys.stderr)
        return 2
    items = items_by_id(queue)
    tasks = st.get("tasks", {})
    if a.json:
        print(json.dumps({"snapshot": st.get("snapshot"), "tasks": tasks, "alerts": st.get("alerts"),
                          "acct": st.get("acct")}, ensure_ascii=False, indent=1))
        return 0
    hb = st.get("heartbeat", 0)
    print("== orchd %s  心跳 %s（%s）" % (VERSION, ts(hb) if hb else "无", "正常" if now() - hb < cfg.get("heartbeat_stale_s", 60)
                                     else "过期！守护没在跑"))
    snap = st.get("snapshot") or {}
    for g in snap.get("gpus", []):
        who = g["lease"] or (("锁:" + g["lock"]) if g["lock"] else "")
        v = tasks.get(g["lease"], {}).get("verdict", "") if g["lease"] else ""
        print("  GPU%-2s %6d MiB %3d%%(ema %5.1f) %-14s %-10s %s" % (g["idx"], g["used"], g["util"], g.get("ema") or 0,
              who or "空", v, g.get("idle_why", "") if not who else ("进程 %d 个" % len(g["procs"]))))
    cnt = {}
    for t in tasks.values():
        cnt[t.get("status")] = cnt.get(t.get("status"), 0) + 1
    print("== 任务：" + "，".join("%s %d" % (k, v) for k, v in sorted(cnt.items())))
    for tid, t in sorted(tasks.items(), key=lambda kv: kv[0]):
        s = t.get("status")
        if s in ("running", "reserved", "failed") or (s == "ready") or (a.all and s not in TERMINAL):
            extra = ""
            if s in ACTIVE:
                extra = "GPU %s 槽 %s 已跑 %d 分 核查=%s 窗 %s %s" % (",".join(t.get("gpus", [])) or "-", t.get("slot"),
                         (now() - t.get("start_t", now())) // 60, t.get("verdict", "-"), t.get("window", "-"),
                         ("启动用时 %d 秒" % t["startup_s"]) if t.get("confirmed_t") else t.get("start_stage", ""))
            elif s == "failed":
                extra = t.get("reason", "")[:120]
            else:
                extra = ("优先级 %s｜" % t["prio"] if t.get("prio") is not None else "") + t.get("why", "")[:120]
            print("  %-14s %-9s %-9s %s" % (tid, items.get(tid, {}).get("kind", ""), s, extra))
    al = [x for x in (st.get("alerts") or {}).values() if not x.get("acked")]
    if al:
        print("== 未确认告警 %d 条：" % len(al))
        for x in sorted(al, key=lambda x: x["no"])[:10]:
            print("  #%d %s %s（自 %s）" % (x["no"], x["kind"], x["msg"][:160], x["first"]))
    if snap.get("reservation"):
        r = snap["reservation"]
        print("== 启动保护：%s 自 %s 起被挡，空出来的 GPU %s 先留给它（低优先级、不可抢占的任务暂不占）" % (r[2], r[1], ",".join(r[0]) or "—"))
    acc = st.get("acct", {})
    tot = sum(v for k, v in acc.items() if k != "alloc_s") or 1
    sh = lambda k: 100.0 * acc.get(k, 0) / tot
    print("== 卡时：真在用 %.1f%%，启动开销 %.1f%%，租而未用 %.1f%%，空卡（预留 %.1f%% / 令牌等待 %.1f%% / 余卡不够 %.1f%% / 无就绪 %.1f%% / 可避免 %.1f%%），别人占用 %.1f%%" % (
        sh("used_s"), sh("startup_s"), sh("alloc_idle_s"), sh("idle_reserved_s"), sh("idle_token_s"), sh("idle_fit_s"), sh("idle_noready_s"),
        sh("idle_avoidable_s") + sh("idle_other_s"), sh("other_s")))
    return 0

UTIL_ROWS = [("真在用（已确认真开始、有本任务进程、利用率≥阈值）", "used_s"),
             ("启动开销（派发或预留 → 确认真开始：开窗、加载、编译、预热）", "startup_s"),
             ("租而未用（真开始后：空转、两次运行之间、CPU 阶段）", "alloc_idle_s"),
             ("空卡：为被挡太久的高优先级任务凑卡（启动保护）", "idle_reserved_s"),
             ("空卡：暂停启动（磁盘不足、主窗暂停）", "idle_paused_s"), ("空卡：计时任务要安静窗口（令牌互斥）", "idle_token_s"),
             ("空卡：余卡不够任何就绪任务", "idle_fit_s"), ("空卡：没有就绪任务（依赖/门控未到）", "idle_noready_s"),
             ("空卡：可避免（加锁失败/没接预留/槽位用完）", "idle_avoidable_s"), ("别人占用（他人锁、未知显存）", "other_s"),
             ("采样失败", "unknown_s")]


def cmd_util(a):
    cfg, queue, st = load_ro(a.td)
    acc = st.get("acct", {})
    tot = sum(v for k, v in acc.items() if k != "alloc_s") or 1
    if a.csv:
        return util_csv(a.td, st, a.csv)
    print("卡时账（自 %s 起，单位 GPU·小时）" % st.get("started", "?"))
    for name, k in UTIL_ROWS:
        v = acc.get(k, 0) + (acc.get("idle_other_s", 0) if k == "idle_avoidable_s" else 0)
        print("  %-40s %8.2f  %5.1f%%" % (name, v / 3600, 100 * v / tot))
    print("  %-40s %8.2f" % ("合计", tot / 3600))
    print("  （空卡只应出现在“预留”“令牌等待”“余卡不够”“没有就绪任务”四类；“可避免”大于 0 要查）")
    return 0


def util_csv(td, st, out):
    """卡时账导出成 CSV（回传用；文件名与位置由任务包定）：total 各类卡时、hourly 每小时每卡、task 每个任务的卡时。"""
    import csv
    from collections import Counter, defaultdict
    acc = st.get("acct", {})
    tot = sum(v for k, v in acc.items() if k != "alloc_s") or 1.0
    rows = [["total", "", "", name, round(acc.get(k, 0) / 3600, 3), round(acc.get(k, 0) / tot, 4), "GPU·h / 占比"]
            for name, k in UTIL_ROWS]
    hourly = defaultdict(lambda: {"u": [], "lease": Counter(), "idle": 0, "n": 0})
    per_task, last_t = Counter(), None
    gl = paths(td)["gpu_log"]
    if os.path.exists(gl):
        for line in open(gl, encoding="utf-8"):
            try:
                r = json.loads(line)
            except ValueError:
                continue
            dt = min(max(r["t"] - last_t, 0), 60) if last_t else 0
            last_t = r["t"]
            hour = time.strftime("%Y-%m-%d %H:00", time.localtime(r["t"]))
            for i, (u, lease) in enumerate(zip(r.get("u", []), r.get("l", []))):
                h = hourly[(hour, i)]
                h["u"].append(u)
                h["n"] += 1
                if lease:
                    h["lease"][lease] += 1
                    per_task[lease] += dt
                else:
                    h["idle"] += 1
    for (hour, i), h in sorted(hourly.items()):
        top = h["lease"].most_common(1)
        rows.append(["hourly", hour, i, top[0][0] if top else "", round(sum(h["u"]) / len(h["u"]), 1) if h["u"] else "",
                     round(h["idle"] / h["n"], 3) if h["n"] else "", "平均利用率% / 空着的采样占比"])
    for task, sec in per_task.most_common():
        rows.append(["task", "", "", task, round(sec / 3600, 3), "", "租到的卡时（GPU·h）"])
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["section", "hour", "gpu", "name", "value", "share", "unit"])
        w.writerows(rows)
    print("写出 %s：%d 行（真在用 %.1f%%）" % (out, len(rows), 100 * acc.get("used_s", 0) / tot))
    return 0


def cmd_check(a):
    cfg, queue, st = load_ro(a.td)
    bad = []
    if not cfg:
        print("FAIL 还没 init")
        return 1
    if now() - st.get("heartbeat", 0) > cfg.get("heartbeat_stale_s", 60):
        bad.append("守护心跳过期（orchd daemon 没在跑）")
    al = [x for x in (st.get("alerts") or {}).values() if not x.get("acked")]
    if al:
        bad.append("未确认告警 %d 条：%s" % (len(al), "；".join(x["msg"][:80] for x in al[:3])))
    fails = [k for k, t in st.get("tasks", {}).items() if t.get("status") == "failed" and not t.get("fix_assigned")]
    if fails:
        bad.append("失败任务没有修复窗：%s" % ",".join(fails))
    if bad:
        print("FAIL " + " | ".join(bad))
        return 1
    print("OK orchd：心跳正常、无未确认告警")
    return 0

def run_daemon(a):
    """守护循环。一个任务目录只允许一个守护（pid 文件）；每轮异常不退出，同一错误 10 分钟内只报一次。"""
    P = paths(a.td)
    cfg = read_json(P["cfg"], {})
    if not cfg:
        print("还没 init：%s" % P["cfg"], file=sys.stderr)
        return 2
    pidf = os.path.join(P["dir"], "daemon.pid")
    old = read_json(pidf, {})
    if old.get("pid") and old["pid"] != os.getpid() and pid_alive(int(old["pid"])):
        try:
            cmdline = open("/proc/%d/cmdline" % int(old["pid"]), "rb").read().replace(b"\0", b" ").decode("utf-8", "replace")
        except OSError:
            cmdline = ""
        if "orchd.py" in cmdline and "daemon" in cmdline:
            print("这个任务目录已有守护在跑（pid %s，自 %s）；不重复启动" % (old["pid"], old.get("start")), file=sys.stderr)
            return 1
    write_json(pidf, {"pid": os.getpid(), "start": ts(), "version": VERSION})
    iv = a.interval or cfg.get("interval_s", 3)
    logp = os.path.join(P["dir"], "daemon.log")

    def log(msg):
        line = "%s %s" % (ts(), msg)
        print(line, flush=True)
        with open(logp, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    log("orchd %s 守护启动：任务目录 %s，每 %.1f s 一轮，pid %d" % (VERSION, a.td, iv, os.getpid()))
    last_err, last_err_t = "", 0.0
    while True:
        try:
            tick(a.td)
        except SystemExit as e:
            log("退出：%s" % e)
            return 2
        except Exception as e:                       # 守护不能因为一次异常退出
            msg = repr(e)[:300]
            log("本轮异常：%s" % msg)
            if msg != last_err or now() - last_err_t > 600:
                emit_event(cfg, "orch_alert", kind="orchd_error", msg="orchd 本轮异常（10 分钟内同一错误只报一次）：%s；"
                           "看 %s" % (msg, logp))
                last_err, last_err_t = msg, now()
        time.sleep(iv)


# ---------------------------------------------------------------- 入口

def main(argv):
    if not argv or argv[0] in ("help", "-h", "--help"):
        print(__doc__)
        return 0 if argv else 2
    cmd = argv[0]
    p = argparse.ArgumentParser(prog="orchd.py " + cmd)
    if cmd != "_run":
        p.add_argument("--td", required=True, help="任务目录（notes/ 所在处）")
    if cmd == "init":
        p.add_argument("--manifest", required=True)
        p.add_argument("--pkg", default="")
        p.add_argument("--runtime", default="")
        p.add_argument("--lockdir", default="")
        p.add_argument("--session", default="")
        p.add_argument("--facts", default="")
        p.add_argument("--events-dir", default="")
        p.add_argument("--set", action="append")
        p.add_argument("--reinit", action="store_true")
    elif cmd == "daemon":
        p.add_argument("--interval", type=float, default=0)
    elif cmd in ("status",):
        p.add_argument("--json", action="store_true")
        p.add_argument("--all", action="store_true")
    elif cmd in ("edit", "prio", "dep", "drop"):
        p.add_argument("id")
        p.add_argument("--reason", required=True, help="为什么改（写进 decisions.md 与事实流）")
        if cmd == "edit":
            p.add_argument("--set", action="append", required=True, help="字段=JSON 值，可多次")
        if cmd == "prio":
            p.add_argument("--boost", type=float, required=True)
        if cmd == "dep":
            p.add_argument("--add", default="")
            p.add_argument("--remove", default="")
            p.add_argument("--after", action="store_true", help="改 after 依赖（前序结束就放行）而不是 deps")
    elif cmd == "wait":
        p.add_argument("--timeout", type=float, default=0, help="最长等多少秒就给一次定时汇报（默认 summary_every_s）")
        p.add_argument("--poll", type=float, default=2.0)
        p.add_argument("--health-every", type=float, default=0)
    elif cmd == "reopen":
        p.add_argument("id")
        p.add_argument("--question", required=True, help="要它做的事（研究者的追问原话等）")
        p.add_argument("--fresh", action="store_true", help="不接原会话，开新会话（靠上下文卡与结果文件）")
    elif cmd == "judge":
        p.add_argument("name", help="判断窗的短名（窗名 judge-<短名>）")
        p.add_argument("--question", required=True, help="要判断的事：告警原文 + 要它回答什么")
        p.add_argument("--about", default="", help="相关任务号（可空）")
    elif cmd == "shrink":
        p.add_argument("id")
        p.add_argument("--gpus", required=True, help="要还的卡号，逗号分隔")
        p.add_argument("--reason", default="用不上")
    elif cmd in ("cordon", "uncordon"):
        p.add_argument("gpus", help="卡号，逗号分隔")
        p.add_argument("--reason", required=True)
    elif cmd == "config":
        p.add_argument("--set", action="append", required=True)
        p.add_argument("--reason", required=True)
    elif cmd in ("env", "done", "fail", "retry", "hold", "unhold", "kill", "start", "exec", "fixwin", "accept", "ask"):
        p.add_argument("id")
        if cmd == "done":
            p.add_argument("--evidence", default="")
        if cmd in ("fail", "accept"):
            p.add_argument("--reason", required=True)
        if cmd in ("hold", "unhold"):
            p.add_argument("--reason", default="", help="为什么暂停（写进 decisions.md）")
        if cmd == "ask":
            p.add_argument("--question", required=True)
        if cmd == "kill":
            p.add_argument("--grace", type=int, default=30)
        if cmd in ("start", "fixwin"):
            p.add_argument("--window", required=True)
        if cmd == "exec":
            p.add_argument("--name", default="")
            p.add_argument("--grace", type=int, default=30)
            p.add_argument("cmd", nargs="*")
    elif cmd == "gate":
        p.add_argument("name")
        p.add_argument("verdict", choices=["pass", "fail"])
        p.add_argument("--evidence", default="")
    elif cmd == "ack":
        p.add_argument("no")
    elif cmd == "add":
        p.add_argument("--json", required=True)
        p.add_argument("--reason", default="", help="为什么临时加（写进 decisions.md）")
    elif cmd == "_run":
        p.add_argument("--spec", required=True)
    elif cmd == "_win":
        p.add_argument("--op", required=True, choices=["open", "close", "send"])
        p.add_argument("--name", required=True)
        p.add_argument("--brief", default="")
        p.add_argument("--task", default="")
        p.add_argument("--fix", default="")
        p.add_argument("--text", default="")
        p.add_argument("--tier", default="")
        p.add_argument("--resume", default="")
        p.add_argument("--msg", default="")
    elif cmd == "util":
        p.add_argument("--csv", default="", help="导出卡时账 CSV 到这个文件（回传用）")
    elif cmd not in ("tick", "check", "health"):
        print("未知子命令 %s" % cmd, file=sys.stderr)
        return 2
    rest = []
    if cmd == "exec" and "--" in argv:
        k = argv.index("--")
        argv, rest = argv[:k], argv[k + 1:]
    try:
        a = p.parse_args(argv[1:])
    except SystemExit:
        return 2
    if cmd == "exec":
        a.cmd = rest or [x for x in (a.cmd or []) if x != "--"]
    if cmd == "init":
        return cmd_init(a)
    if cmd == "_run":
        return cmd_run(a)
    if cmd == "_win":
        return cmd_win(a)
    if cmd == "daemon":
        return run_daemon(a)
    if cmd == "tick":
        return tick(a.td)
    return {"status": cmd_status, "util": cmd_util, "check": cmd_check, "health": cmd_health, "env": cmd_env, "exec": cmd_exec,
            "start": cmd_start, "done": cmd_done, "fail": cmd_fail, "retry": cmd_retry,
            "hold": lambda x: cmd_hold(x, True), "unhold": lambda x: cmd_hold(x, False),
            "gate": cmd_gate, "kill": cmd_kill, "ack": cmd_ack, "add": cmd_add, "fixwin": cmd_fixwin,
            "accept": cmd_accept, "ask": cmd_ask, "edit": cmd_edit, "dep": cmd_dep, "prio": cmd_prio, "drop": cmd_drop,
            "cordon": lambda x: cmd_cordon(x, True), "uncordon": lambda x: cmd_cordon(x, False), "config": cmd_config,
            "shrink": cmd_shrink, "judge": cmd_judge, "reopen": cmd_reopen, "wait": cmd_wait}[cmd](a)

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
