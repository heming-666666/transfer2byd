---
name: multi-agent-orchestrator
description: 全局通用的多窗编排器：把写好了 manifest（任务、依赖、卡数档位、资源令牌、命令、判据、门控、异常预案）的任务包交给它，由脚本守护 orchd 按优先级与强制依赖动态分配 GPU（不用预计时长）、启动脚本化的实验、确认任务真开始、自动开窗派发需要判断的任务（自动生成任务书）、自动修复、自动验收、每 3 秒核查每张卡是否真在算、用事件只在需要时叫醒主窗；主窗只掌控全局与定时巡检，子窗一事一窗、做完自动关窗；skill 本身的问题当场记录、随回传交回，持续升级。当用户给出一个较大的、可拆成多个任务的工作（实验包、批量处理、长流程），希望多窗并行、把多张 GPU 持续用满、主窗上下文最短时使用。
version: 2.0.0
license: MIT
metadata:
  tags: [orchestration, multi-window, tmux, claude-code, parallel, gpu-scheduler, watchdog, superagent]
  related_skills: [verification-before-completion]
---

# 多 Agent 并行编排器（2.0.0）

**一句话**：任务包写好一切 → orchd 自动执行 → 主窗只掌控全局。分工借鉴 DeepSeek 开源的 Super-Agent 原型（`deepseek-ai/dsh-superagent-prototype`，MIT，2026-10-31 版）：host 存储并执行确定性的工作、orchestrator 只路由与决定、worker 一任务一会话一目录、只在有人必须行动或结果就绪时才说话。

| 角色 | 是谁 | 只做什么 | 不做什么 |
|---|---|---|---|
| 主窗（orchestrator） | 主窗 Claude | 开工搭场；被事件叫醒或定时巡检（`orchd.py health`）；处理升级（要判断的派判断窗）；把子窗的问题原话转给研究者；告诉研究者结果就绪；收尾汇报 | 不读日志与子窗对话、不排障、不改代码、不跑实验、不挑卡、不写任务书、不手工开关工作窗、不 sleep |
| 守护（host + watchdog） | `scripts/orchd.py daemon`（tmux 窗 `orchd`，不调用模型） | 唯一的 GPU 分配者；按优先级与强制依赖动态发卡（不用预计时长）；启动 job、确认真开始；**自动派窗**：生成任务书（`brief.py`）、开工作窗、失败开修复窗、完成开验收窗、结束关窗；每 3 秒核查真用卡；子窗的问题与结果用事件叫醒主窗 | 判断类决定（失败两次后怎么办、门控之外的取舍） |
| 子窗（worker） | `winctl.sh` 开的 Claude 会话 | 一个任务或一个问题；照任务书与路线卡做；GPU 命令经 `orchd.py exec`；进展写上下文卡；交 report（带 summary，需要时带 attention） | 不开窗、不给别的窗发消息、不问人（要决定的用 `orchd.py ask`）、不碰别人的进程 |

**这个 skill 是全局通用的**（R33）：它不认识任何具体任务包；任务包的路径、变量名、回传文件名、实验步骤都由任务包（manifest 的 `run_env`、`brief`，路线卡）与调用 Prompt 的第一节决定。

`@ORCH_HOME@` 指本机用户目录（skill 装在 `@ORCH_HOME@/.claude/skills/multi-agent-orchestrator/`，附加件在 `@ORCH_HOME@/skill/skill-addons/orch-v1/`），安装时由 `install.py` 写成真实路径。调用 Prompt 见 `@ORCH_HOME@/skill/multiagent.md`；完整的使用手册是 `references/manual.md`。

> **结构**：本文件只放常驻规则（开工与每次压缩恢复后读全），按需内容在 `references/`。交叉引用一律用 R 编号，编号永不改。2.0.0 新增 R22–R37，R21 由 R22–R24 取代（保留编号作历史）。

## 变更记录

- **2.0.0（2026-11-13，按研究者「多卡监控仍有空闲卡；主窗只掌控全局、定时监控；任何小任务都派子窗；子窗隔离；派发后核实真用卡；一事一窗做完关窗；skill 全局通用、细节由任务包与 Prompt 定；环境任务优先；动态调度、不用预计时长，只看优先级与强制依赖；以“进程真起、持续占用、实验真开始”确认任务真开始；能并行的实验写成 1/2/4/8 卡都能跑的脚本；异常与变更要预先想全、写清；做完的窗要能关、要用时能 resume；按云端模型定间隔、尽量不压缩；优先级要表达实验之间的依赖；充分借鉴 SuperAgent；skill 要非常正确，以后一直用」要求，对照 v4 现场回传的 7 个问题与 DeepSeek Super-Agent 原型重做调度层）**：
  1. **`scripts/orchd.py`：唯一的 GPU 分配者 + 启动确认 + 用卡核查 + 自动派窗 + 异常处理**。
     - **动态调度、不用预计时长**（R15）：每 3 秒按实时状态重新决定；就绪 = 强制依赖满足；优先级 = 传递下游个数 + `prio_boost`，同级先放长链的头、再稳定随机；卡数 = 声明的档位里此刻放得下的最优先一档（没写偏好时卡多的优先，`strict_tier` 只认首选档）；有放得下的就绪任务就不让卡空着；被挡的最高优先级任务开“启动保护”（有下游链的马上、叶子等 6 小时），只抢占 `preemptible` 的任务，被抢占的排回队列、在抢占者起跑前不重启（不会来回抢）。
     - **启动确认**（R34，研究者的思路）：进程真起并占住资源、持续 `start_hold_s`、实验真开始（`$ORCH_STARTED` 标志、`started_if`/`started_log`、进度更新或持续计算）三项都有才记“真开始”；之前的卡时记启动开销，之前退出的标“启动阶段失败”，过启动时限没开始报 `no_start`。
     - 资源令牌（`machine:x` 整机、`hostbw:x/s` 主机带宽）；每个任务一个槽位、端口段、ray 临时目录；进程带 `ORCH_TASK`/`ORCH_RUN`/`ORCH_INST` 标签，subreaper 收孙进程，`kill` 只停自己的；锁写 `gpu_lock` 同一目录（`orchd:<实例>:<任务>`）；`CUDA_DEVICE_ORDER=PCI_BUS_ID`。
     - 核查每 3 秒：`loading`、`ok`、`gap`、`no_start`、`not_on_gpu`、`partial`、`stall`、`stray`、`untagged`、`rogue`、`orphan`、`idle_waste`；采样失败的那一轮不下结论；卡时账区分真在用、启动开销、租而未用、启动保护凑卡、令牌等待、余卡不够、无就绪、暂停、可避免。
     - **自动派窗**（写了 `notes/orch.env` 就默认打开）：gpu-agent 预留到卡、cpu-agent 就绪 → `brief.py` 生成任务书 → `winctl.sh open`；失败或报受阻 → 修复窗（最多 `max_fix` 次），用完按包的 `if_fail` 预案或升级；agent 任务交“完成” → 验收窗；用卡问题 → 告警发进它的窗或开修复窗；残留进程宽限后按标签收；子窗消失 → 保留租约按上下文卡重开一次；子窗长时间没输出 → 提醒一次再升级；结束就关窗。只有要主窗决定的事才写事件（`orch_alert`、`orch_attention`、`orch_result`）。
     - **异常与变更**（R36）：包里的预案 `if_fail`（accept/drop）、备选 `fallback_for` 与 `"主|备"` 依赖；失败照实交后严格下游自动跳过（不再永远等）；运行中改计划的命令 `prio`、`dep`、`edit`、`drop`、`add --reason`、`cordon`/`uncordon`、`config`（含全局暂停）、`shrink`（还卡），都要理由、进 `notes/decisions.md`，改依赖时防环；全局保护：磁盘余量不足暂停启动、掉卡告警、超过 `max_h` 告警。
     - `health`（主窗的定时巡检）、`ask`（子窗一个具体问题）、`util --csv`（卡时账导出）、`skip_if_cmd`（环境任务）、`done_if`、`after`、`run_env`（包自己的环境变量）、`notify`。
     - **主窗的等待 `orchd.py wait`**（R11、R31、R37）：巡检在后台每分钟做一次、不进主窗上下文；只有要主窗处理的事才返回（十几行）；结束、预案、门控、里程碑只记进摘要（借鉴 SuperAgent 的 relay / notice 两分）；没事每 2 小时一行。子窗的 hooks 事件由 orchd 读（会话号、这一轮结束、接口失败、压缩次数），不再叫醒主窗。
     - **子窗的一生**（R26）：开窗时指定会话号；先写上下文卡、最后交报告；等这一轮结束再优雅关窗（`/exit`）、收 key；窗意外消失或 key 失效时 `--resume` 回原会话；重试默认接着原会话（太长就开新窗）；上下文超限开新窗；做完的任务要追问用 `orchd.py reopen`。限流按 60、120、240… 秒退避后让子窗接着做。
     - **优先级表达依赖**（R15）：`kind: milestone` 写“谁要这些结果”；有人在等的决定点（`waiting_human`）优先于一切；正加成向上游传。模型档位按任务与窗的种类选（`tier`、`tier_by_kind`）。
  2. **`scripts/cellrun.py`**（R35）：一组独立的格按租到的卡并行跑（1 卡一格接一格，4 卡同时 4 格，格可以要不同卡数），对齐的连续卡块优先、每格独立端口小段与临时目录；剩下的格用不满租约时自动还卡；已完成的格跨重试、跨抢占跳过；失败的格不挡别的格；停止时一起停、收掉格留下的服务。
  3. **`scripts/brief.py`**：任务书自动生成（执行 / 修复 / 验收 / 判断四种），固定几节：共同规则 → 包的规定（manifest `brief.rules`）→ 任务的原始来源（路线卡、manifest 条目，不改写、不加计划）→ 环境 → 交接。
  4. **`scripts/winctl.sh`**：开窗（claim key、`ORCH_*` 变量、禁菜单、送任务书、补 Enter、mark、start；上下文卡有内容时自动附“恢复说明”）、关窗、给窗发消息。
  5. **`scripts/skill_feedback.py`**（R29）：skill 本身的问题当场记、回传导出；`references/evolution.md`：闭环、版本史、升级包格式。
  6. 常驻规则 R22（主窗只掌控全局）、R26（子窗的一生、会话保留与 resume）、R30（原生子 agent 只在窗内做只读分析）、R31（定时巡检在 wait 里做）、R32（环境任务优先、只新建不改旧）、R33（全局通用）、R34（启动确认）、R35（多档脚本）、R36（异常预案与改计划命令）、R37（上下文预算与模型档位）；references 五篇（manual 使用手册、main-loop、orchd、package-contract、evolution）。
  7. 测试：`tests/orchd_sim.py` 192 项（假 nvidia-smi、假实验、假 tmux、假 winctl、假 hooks 事件），覆盖分配、抢占、启动确认、核查、自动派窗、预案与备选、运行中改计划、全局保护、子窗看护、cellrun、里程碑与优先级、子窗的一生与 resume、接口失败、主窗的等待；逐行复查修掉的会出错的地方见 `HANDOFF.md`。另用 orchd 在假 8 卡上模拟真实任务包的 manifest（`tools/plan_sim.py`）。
- **1.7.0（2026-11-13，研究者再指出「多卡监控脚本没设置好，有时仍有空闲卡」，按现场实测补四处）**：1.6.0 只做到了「每轮跑一次快照」，仍然滞后；本轮把监控变成事件驱动，并修掉三处会真实压低用卡率的判据错误。① **`gpu_sched.py wait`（新）**——阻塞等待整机空闲卡集合变多、或「被卡数不足挡住的任务」变成可发，退 0 立刻叫醒主窗（3 = 超时无变化）。主窗用后台命令挂着即可，不必等 5～180 s 的睡眠周期；只靠周期发现「卡空了」是空卡滞后的直接原因。② **僵尸锁点名**——v4 现场实测 `gpu0-3.lock` 建于 11-10 03:12、持有者 V3-1 当天 09:30 就已完成、卡上零显存零进程，三天没人回收；`watch`/`plan`/`schedule_state` 原先把这四张算成已占用，等于凭空少四张卡。现在三处都按「锁龄 ≥ `--stale-min`（默认 60 分钟）且卡上显存低于阈值」点名并打印 `rm -rf` 命令，**绝不自动回收**（不是我的锁，回收是不可逆动作）。③ **运行态交叉核对**——`plan --facts <事实流>`：覆盖表写「等依赖」但事实流显示已 `dispatch` 且没有完成报告的任务，一律按在跑处理。v4 实测 V4-R 的 `opd_run.py` 15:43 已占 GPU6/7 各 70 GB，表里仍写「等依赖」，`plan` 正把它列进「建议下发」——再发一次就是同一任务两个实例抢同一批卡。④ **按 `est_h` 选最快档而非最大档**——研究者原话是「能加快实验进展就整 8 卡」，8 卡并不总是更快：v4 的 V4-R 声明 `est_h {"4": 0.5, "8": 1.6}`，整 8 卡发它比 4 卡慢 3 倍。现在有 `est_h` 就选预计耗时最短那档，没有才退回最大卡数；`--options` 支持 `T=8:0.5,4:1.0` 写法。**顺带修掉三处判据偏差**：`is_cpu` 原来只认「分区恰等于 cpu」，`A+B+CPU` 的角色行（v4 的 WORKER-EXEC、全部角色卡 `gpus:[0]`）因此被当成 GPU 任务抢卡；分区 `A+B`/`AB` 现在按并集处理（原来只认单区名，A+B 任务会因 `parts` 里没有这个键而拿到任意卡）；独占任务在整机空闲时优先于同级小任务（原来同级随机，v4 全空时 V4-P2/P3/P4 三个独占任务永远排在小任务后面，5 张卡空着而 `plan` 报「不是漏派」——饥饿）。**新增干扰提示**：「可并行」列在各任务包里写法不一（v3 填窗名、v4 填 `Y`/`partition`/`预检Y计时N`），「只发不影响别卡的实验」这条要求没有机读判据；`plan` 现在对与别卡同跑、而该列不是明确 `Y`/`独占整机` 的任务标 ⚠，只提示不拦截（`references/env.md` 4.2e）。`tests/gates_sched.sh` 由 44 条增到 **64 条全过**，`tests/gates.sh` 20 条全过。备份 `skill/archive/multi-agent-orchestrator-pre-1.7.0-20261113-155053.tar.gz`。
- **1.6.0（2026-11-13，按研究者「仍会有空闲卡，主窗要实时监控空闲卡并按优先级下发」要求）**：**新增 R21 与 `scripts/gpu_sched.py`**。三处实测根因一起修：① **门禁的空卡判据是过期快照**——`templates/checks.json` 的 `--free-gpus` 是占位符，复制后没人改，R10 拿它判空卡等于拿旧数据；`schedule_state.py` 新增 `--free-gpus auto`，现查 `nvidia-smi` 并扣除 `gpu_lock`（手拼的 `nvidia-smi` 会把已被锁住但显存未涨的卡算成空闲），模板改成 `auto`。② **覆盖表被 CSV 引号挤歪列**——`schedule_state.py`/`scan_package.py`/`coverage_check.py` 都直切逗号，真实 v4 表里 `"V4-0,V4-R"` 让 V4-G3、V4-Q 的状态列读成空串、V4-G2 读成「独占整机」，三个就绪任务对调度器完全不可见；三处统一改成 `csv` 模块解析（竖线表仍按竖线切），并统一认「负责人窗」表头（原来按内部键 `负责人` 取值，真实表读丢负责人，导致「等资源」被误判成没派）。③ **`gpu_lock.sh` 忽略卡号指定**——文档示例 `CUDA_VISIBLE_DEVICES=4,5 gpu_lock.sh acquire` 实测返回 `0,1` 并锁住 `gpu0/1`，v3 账本里「评测校准 B区4-5」实际占着 `2,3` 即由此而来；新增 `GPU_LOCK_CARDS=4,5` 显式指定，**不够数直接失败、绝不退回自动挑卡**，默认行为与所有既有调用方不变（刻意不读 `CUDA_VISIBLE_DEVICES`，那是 acquire 的输出，读它会自反馈）。**新脚本 `gpu_sched.py`**：`watch` 报实时空闲卡（显存 + 锁双条件、`--state` 记历史、连续 3 轮仍空则点名+起始时间）；`plan` 按研究者定的规则给下发建议——CPU 任务无依赖立即执行、有依赖则前序完成即执行；GPU 任务按**传递下游扇出**定优先级，相同优先级随机（`--seed` 可复现）；最高优先级够 8 卡就整 8 卡发，只支持 1/2/4 卡时按声明最大卡数发、余卡继续按优先级填满；`独占整机` 在有任务在跑时跳过并写原因；分区 A/B 只从本区挑卡。**新门禁 `--fail-on-idle`**：有空卡、有能发的任务、却一张没发才退 1；「余卡不足」与「独占整机」属合法拦下不算漏派（否则门禁永远红着会被无视）。`templates/checks.json` 增加 `gpu_plan` 检查项（block）。**新增 `tests/gates_sched.sh`（39 条，含反向用例）全过；`tests/gates.sh` 20 条全过；附加件 `selftest.sh` 104 条全过**；`skill_lint` 0 错误。备份：`skill/archive/multi-agent-orchestrator-pre-1.6.0-20261113-151957.tar.gz`、`multiagent-pre-1.6.0-*.md`、`gpu_lock.sh-pre-1.6.0-*`、`gpu_free.sh-pre-1.6.0-*`。
- **1.5.2（2026-11-12，独立审查后修文档级缺陷，不改脚本）**：① **R09 命令修正**：原写 `winstate.py --events-dir <dir> mark <窗>`，`mark` 不在首位会被当作窗名，静默不写事件且误报「无事件」（实测复现）；改为 `winstate.py mark <窗> --events-dir <dir> [--session <会话名>]`，并注明「带 `--session` 就一定带同样前缀复查」。② **R12 补事实流写入**：八态推导依赖 `gate`/`lease`/`report`/`audit`/`user` 等每类事实，此前只有 `task_add`/`dispatch`/`report` 有教学，`audit`（决定「已完成」）无人写——验收闭环会断；R12 现补齐各角色该写哪类事实的命令。③ **watch.md 判据统一**：其「看护节奏」（3.7.3）与「主窗持续自检」（九·五）两节仍把 `watch_start.sh` 抓屏写成主判据，与 R09「先看事件、watch_start 为后备」矛盾；改为「先 `winstate.py`，无事件/判 GPU 空转才退回 `watch_start.sh`」。④ **references 失效节号清理**：三·七、六·六、六·七、二·五、6.5.1、6.6.4、3.7.4 等指向已拆走的 1.3.0 章节号，改为指向对应 references 文件或 R 编号。⑤ **rules.md R17 与 SKILL.md 对齐**：规则卡原写「脚本（换 key + resume）」，与 SKILL.md「无冷却、需重开窗、部分可执行」两说，已统一并标缺口。⑥ **按需查阅表补 `references/rules.md`、`templates/`、`references/repair-*.md`、`references/scripts.md` 入口**（此前 rules.md 只能从调用 Prompt 进）。`skill_lint` 0 错误；`gates.sh` 20 通过、`selftest.sh` 104 通过；新增命令均实测 exit 0。备份 `archive/*-pre-review-20261112-153120.tar.gz`。

- **1.5.1（2026-11-12，按 1.5.0 审查结论逐项修）**：① **删掉了一条会毁数据的路径**——`facts.py render` 原本整表重写覆盖表，而 R10 的 `evidence` 门禁调的就是它；任务没写 `task_add` 时它会把手工维护的行整片吞掉（复现：3 行 → 1 行，`.prev` 也被覆盖，不可恢复）。现在 `render` 发现表里有事实流不认识的 id 就退 3、一个字不写，另加 `--force`；新增只读的 `facts.py check` 做「事实流 vs 覆盖表」比对，`templates/checks.json` 的 `evidence` 改用它。自测增 5 项（含反向用例：事实流齐全时不得误拦），104 通过 0 失败。② **守卫不再代答**：`guard.sh` 的「决策菜单选第 1 项」与「权限确认框按 Enter」改成只写 `orch_alert` 报警事件（自动同意一个没看过的确认框，可能同意一次删除或覆盖）；恢复提示、未提交粘贴、排队消息三类无歧义的仍自动处理。同一窗同类问题只报一次。③ **事实流接通了两端**：`templates/TASK_COVERAGE.md` 与 `references/task-flow.md` 要求建表时每行写 `task_add`；`templates/WORKER_BRIEF.md` 与 `WORKER_REPORT.md` 要求子窗交报告时写 `report` 事实并给绝对证据路径。此前这两类事实全流程没人写，事实流永远是空的。④ **R07 接通**：`open_windows.sh` 启动子窗带 `--disallowedTools AskUserQuestion`（主窗不带）。⑤ **主窗启动命令补齐五个 `ORCH_*` 变量**（`references/windows-and-keys.md` 第二节 + 缺了会怎样的对照表）；此前一个都没设，`restore_card.py --require-main` 从不输出，C06 实际未生效。⑥ **hooks 升到扩展档**（12 个事件）：`StopFailure`、`SubagentStart` 2026-11-12 本机实测触发（`SubagentStart` 靠真开子 agent、`StopFailure` 靠传不存在的模型名），`winstate.py` 的「限流 / 出错 / 有未结束子 agent」判据由此变成真的；`PostCompact` 因需要真实长上下文才能触发，**尚未单独验证**（同源的 `SessionStart(compact)` 恢复卡已实测，功能不受影响）——见 `$A/hooks/README.md`。⑦ **`winstate.py` 的 error 字段修正**：原来把 session_id、prompt_id、effort 一起拼进 error，限流关键字可能命中无关字段；改为只取 `error` 字段，并把 `too many requests`/`429` 也算限流。⑧ **文档修假**：`references/task-flow.md:67` 不再指已停用的 `usage-prompts.md`；变更记录里「常驻部分 81 行」改为实测（物理 54 行、非空 27 行、R 规则 20 条、全文件 109 行）；「任务分析与拆解」按 1.5.0 的搬迁映射真正移到 `references/task-flow.md`——**此前它还在 SKILL.md 里，与记录不符**；`usage-prompts.md` 标注停用（实际模板是 `@ORCH_HOME@/skill/multiagent.md`）。⑨ **调用 prompt 重写**：`multiagent.md` 只留本任务特有输入（路径、V3 事实、目录隔离、回传落点），凡是 skill 已有的规则改为一张「照哪里做」对照表，不再抄第二遍；删掉已失效的四个 `orch-*` 子 agent 段（该目录已空，改用内置 `general-purpose`/`Explore`/`Plan`/`fork`）。⑩ `open_windows.sh --dry-run` 现在会打印 `ORCH_EVENTS_DIR`/`ORCH_WINDOW` 前缀（不打印就等于没验证）。备份见 `@ORCH_HOME@/skill/archive/*-20261112-111433.tar.gz` 与 `settings-20261112-basic-hooks.json`。

- **1.5.0（2026-11-12）**：按 `skill-guide-20261111` 09 篇的规则治理方案重构。**SKILL.md 由 770 行拆成常驻规则 + 按需查阅**：常驻部分只放不可逆安全约束、每轮必做门禁、角色与优先级，规则编号 **R01–R20 以后不再改号**（交叉引用一律用 R 编号，不再用会随章节调整失效的 §节号）。原 搬迁映射（左侧是 1.4.0 的节名）：打开主流程窗、选档规则、开子窗并派发、守卫、子窗错误处理 → `references/windows-and-keys.md`；派发后启动看护、监控节奏、主窗持续自检、长值守编排模式 → `references/watch.md`；串并行调度、环境管理、空资源问责 → `references/env.md`；难题台账与指导文件 → `references/issues.md`；网络不可达记录 → `references/net.md`；坑 → `references/pitfalls.md`；验收窗、子窗交接报告、任务状态机、svideo 交付形态、数据回传与复核验收 → `references/return-and-audit.md`；辅助脚本一览 → `references/scripts.md`；任务分析与拆解、开工第一步的任务覆盖清单、主窗的输入纪律、任务书与调用 Prompt 的分工、上下文压缩后重载 skill → `references/task-flow.md`。**常驻部分的行数口径**（2026-11-12 重测，此前写的 81 行是错的）：从 `
## 常驻规则（开工、每次压缩恢复后读全）

> 一句话：**任务包写好了一切**（任务、依赖、卡数、命令、判据、分支），**orchd 自动执行**（分卡、启动、开窗、修复、验收、关窗、核查），**主窗只掌控全局**（被事件叫醒或定时巡检时看一眼，只处理要它决定的事），这样主窗的上下文最短、最不会漂移。

### 角色与优先级

**R01** 主窗是唯一的决策者和唯一对研究者说话的入口；研究者只对主窗说话。子窗之间不互相说话，子窗只通过交接（事实流的 report、`orchd.py ask`）向上说话。

**R02** 冲突时的优先级：安全硬约束（R03–R07、R25）> 任务包（包内 `AGENTS.md`、`docs/`、路线卡、`state/manifest.json`）> 本轮调用 Prompt 的输入项 > 本 skill 的其他默认做法。不确定时按更保守的一边做，并在汇报里写明。主窗认为某条规则在当前情况下明显不合理时，**先按规则做**，在汇报第一行写「需要你决定：规则 Rxx 在这里是否适用，因为⋯⋯」，由研究者决定。

**R33 skill 全局通用，细节由任务包与 Prompt 定**：本 skill 不认识任何具体任务包的路径、变量名、文件名与实验内容；这些写在任务包（manifest 的 `run_env`、`brief`、路线卡、回传规范）和调用 Prompt 的第一节里。skill 里出现的具体例子只是例子。

### 安全硬约束（任何时候都不能违反）

**R03** 不 kill、不改、不覆盖不属于本轮任务的进程和文件；不擅自结束别人的进程。停自己的任务只用 `orchd.py kill <任务>`（R25）。

**R04** 能用的环境不改：不在已有环境里升级、降级、删包；要新版本就新建一个隔离的环境（R32）。

**R05** 共享文件只由脚本写（`orchd.py`、`facts.py`、`progress.sh`、`ledger.sh`、`hard_issue.sh`、`net_blocked.sh`、`snapshot.py`、`skill_feedback.py`）；禁止对共享文件用 `sed -i`、`>` 重定向或编辑器直接改；删除或批量改文件前先做快照（`snapshot.py take`）。`notes/sched/` 下的文件只由 `orchd.py` 写。

**R06** 凭证只在池文件和每窗配置文件里；日志、事实流、汇报里只写池内编号。

**R07** 子窗不得弹出选择菜单：子窗一律用 `winctl.sh open` 开（自带 `--disallowedTools AskUserQuestion`；自动派窗也走它）。要研究者决定的事，子窗用 `orchd.py ask`（结构化的一个问题），不是菜单。主窗**不加**这个参数。

### 主窗做什么、不做什么

**R22 主窗只掌控全局**（借鉴 DeepSeek Super-Agent 的 orchestrator：只路由与决定，不调查、不改写任务、不替执行者排障）。开工后主窗只做五件事：

1. **等**：一个后台 `wait_event.py`（R11），被事件叫醒或超时醒来；
2. **巡检**：`orchd.py health --td <任务目录>`（R31），退 0 就什么都不做、重挂等待；
3. **处理升级**：health 列出的每一条照 `references/main-loop.md` 第 3 节的表处理——要读证据、要判断的，开一扇**判断窗**（`brief.py judge` 生成任务书，窗只回 ≤ 10 行结论），主窗只看结论再决定；
4. **转告研究者**：子窗的 `attention` 问题原话转给研究者（`orch_attention` 事件）、结果就绪（`orch_result` 事件，例如回传交好了）、需要研究者决定的升级；其余进展不报（R19）；
5. **收尾**：全部结束后核对 R20，汇报。

主窗不做：读日志全文与子窗的完整对话、排障、改代码、跑实验命令、手工挑卡、手写任务书（`brief.py` 生成）、手工开关工作窗（自动派窗模式下 orchd 自己做）、`sleep` 轮询、kill 进程。

**R30 原生子 agent 只在窗内做只读分析**：Claude Code 的原生子 agent（`general-purpose`、`Explore` 一类，或附加件 `agents/` 里的 orch-log-digest、orch-audit-slice 等）用于在一扇窗内**并行地只读**——读大日志、分片核对、查文件——结果只回摘要，省本窗的上下文。凡是要跑命令改东西、占 GPU、跑很久、需要独立上下文的事，一律开 tmux 子窗（由 orchd 开），不用原生子 agent。主窗要了解一件事的细节时，优先开判断窗；只读几份小文件时可以用一个原生子 agent。

### 每轮必做（顺序固定）

**R08** 开工第一件事（`references/main-loop.md` 第 1 节，逐条照做）：版本校验 → 写 `notes/orch.env`（写了它 orchd 就默认**自动派窗**）→ `orchd.py init`（读包内 `state/manifest.json`，全部 id 自动进事实流）→ tmux 窗 `orchd` 起守护 → `facts.py render` 生成覆盖表、跑 `scan_package.py` → 看板。之后主窗进入 R22 的循环；工作窗、修复窗、验收窗由 orchd 开。

**R09** 子窗一律经 `winctl.sh open` 开（自动派窗模式下 orchd 调它；手工模式或判断窗时主窗调它）：它按顺序做完 claim key、带 `ORCH_*` 变量与 `--disallowedTools AskUserQuestion` 启动、送任务书、补 Enter、`winstate.py mark`、`orchd.py start`。开窗后 20 秒 `winstate.py` 复查“执行中/空闲”；自动派窗模式下这一步由 health 里的“子窗开了 N 秒还没就绪”兜底。

**R10** 每次准备等待前：跑 `orch_check.py --config <任务目录>/notes/checks.json`（含 `orchd.py check`）。退出码 1 不许等、不许报「在等」；4 表示检查器坏了，本轮相应项人工判断并写明；2 按 BROKEN 处理。

**R11 主窗只用 `orchd.py wait` 等待**（2.0.0；借鉴 SuperAgent：主会话不睡、不轮询，消息自己来）：用 Bash 的 `run_in_background` 挂 `python3 -I $S/orchd.py wait --td <任务目录>`，同一时刻只挂一个。巡检在它里面每分钟做一次，**不进主窗上下文**；只有要主窗处理的事才返回，只打印十几行：退 0 有事件（子窗要研究者决定的问题、要主窗决定的升级、结果就绪、判断窗或跟进窗的结论）、1 巡检发现新的问题、2 守护没在跑、3 到了定时汇报（默认 2 小时；没事，直接重挂）。任务结束、按预案处理、门控结论、里程碑、抢占这类通知不叫醒主窗，记进下次醒来的摘要。**主窗不 `sleep`、不用 ScheduleWakeup、不轮询**：1.7.0 的 10–180 秒睡眠区间（`references/watch.md`）只适用于没有 orchd 的手工模式；子窗的 hooks 事件（Stop、Notification、StopFailure……）由 orchd 处理，主窗不再等它们。手工模式（没有 `notes/orch.env`）才用 `wait_event.py`。

**R12** 「完成」只以 `facts.py render ... --check-evidence` 推导的「已完成」为准；子窗说完成只是「等待验收」。验收由独立验收窗做（自动派窗模式下 orchd 在 agent 任务交“完成”后自动开 `au-<任务>` 窗，任务书由 `brief.py audit` 生成）：自己从磁盘重算，不信自报。事实谁写：orchd 写 `task_add`/`dispatch`/`lease`/`release` 与 job 任务的 `report`；子窗写 `report`（带 `summary`，需要时带 `attention`）；验收窗写 `audit`；门控由包里的判定任务或主窗写 `gate`。依赖推进以 `report 完成` 为准（卡不空等），回传以 `audit pass` 为准。

**R13** 汇报前跑 `orchd.py health`、`orchd.py util`、`facts.py render --log <notes/facts.jsonl> --coverage <notes/task-coverage.csv> --check-evidence`；汇报格式见 R19。

### 资源

**R14** **包内任务的 GPU 只由 orchd 分配**（R23）。不手工挑卡、不手设 `CUDA_VISIBLE_DEVICES`、不用 `ledger.sh`/`gpu_lock.sh acquire` 给包内任务抢卡。临时的 GPU 活（排障复现）也用 `orchd.py add` 加成任务。

**R15 动态调度：只看优先级与强制依赖，不用预计时长**（研究者 2026-11-13）。orchd 每 3 秒从实时状态重新决定：就绪 = 强制依赖（`deps`）都成功、`after` 都结束、门控满足；优先级 = 自己的 `prio_boost` + 所有直接或间接依赖它的节点的分量之和（任务 1 + 正的 `prio_boost`，正加成因此向上游传；里程碑 `weight`；**有人在等的里程碑**（`waiting_human`）的分量大过全部任务之和，喂给它的任务排在一切之前），同级先放下游最长链的头、再稳定随机；任务图之外的需求（研究者的决定点、下一轮设计、论文某一节）写成 `kind: milestone` 节点，不要给任务手填大数；卡数 = 包声明的档位里此刻放得下的最优先一档（没写偏好值时卡多的优先，`strict_tier` 只认首选档），余卡给下一个就绪任务，有放得下的就绪任务就不让卡空着。最高优先级的被挡任务开“启动保护”：有下游链的（有任务强制依赖它，或 `prio_boost` > 0）**马上**保护，它晚一步整条链都晚；叶子任务等满 `leaf_hold_after_s`（默认 6 小时）才保护，空卡先给放得下的任务。保护期间低优先级、不可抢占的任务暂不占它要的卡与令牌；`preemptible` 的任务可先用，到时被抢占排回队列。比它优先、**马上就绪**的 GPU 任务（只差正在跑的 CPU 小步骤，例如门控判定）也先留卡，最多 `imminent_hold_s`（5 分钟），不抢占任何在跑的任务。计时敏感的任务写资源令牌（`machine:x` 整机安静、`hostbw:x` 主机带宽独占等），orchd 按令牌互斥，不靠人记；违反时这次结果标「疑似受干扰」，不得当正式对比。任务提前、推迟、失败都不影响正确性，所以**不要**为了“排得更准”去估时长或手工改顺序。

**R21**（1.6.0–1.7.0，2.0.0 起由 R22–R24 取代）`gpu_sched.py` 保留作 orchd 不可用时的人工后备。

**R23 GPU 命令只在租约内跑**：`gpu-job` 由 orchd 自己启动；agent 任务的子窗所有 GPU 命令一律 `orchd.py exec <任务> -- <命令>`（无租约时退 4）。租到的卡与端口段用 `orchd.py env <任务>` 看。

**R24 派发后核实真的在用卡**：orchd 每 3 秒核查每张租出去的卡（`loading`、`ok`、`gap`、`no_start`、`not_on_gpu`、`partial`、`stall`、`stray`、`untagged`、`rogue`、`orphan`、`idle_waste`），并做启动确认（R34）。自动派窗模式下：agent 任务的问题原文发进它的工作窗，job 任务的问题开修复窗，残留进程宽限后自动收，处理不了的才升级给主窗。汇报里写「在跑」的任务核查必须是 `ok`（agent 任务两次运行之间可以是 `gap`）；每次汇报带 `orchd.py util` 的占比，**空卡只允许是“启动保护凑卡”“令牌等待”“余卡不够”“没有就绪任务”“暂停启动”五类**，启动开销单独一行。

**R25 只动自己的进程**（安全硬约束）：任何窗停进程只用 `orchd.py kill <自己的任务>`。进程标签带任务与实例（`ORCH_TASK`、`ORCH_INST`），另一套编排的进程不会被认成自己的。看见可疑进程不 kill，写进交接。

**R26 一事一窗、做完关窗、会话保留、要用就 resume**：每个任务或每个问题一扇子窗（工作窗 `w-<任务>`、修复窗 `fix-<任务>-<n>`、验收窗 `au-<任务>`、判断窗 `judge-<事>`、跟进窗 `fu-<任务>-<n>`）；子窗只写自己的输出与 `work/<窗>/`；进展逐步追加到上下文卡 `notes/ctx/<窗>.md`。开窗时 winctl 用 `claude --session-id` 指定会话号，orchd 记进状态与 `notes/sessions.jsonl`。**关窗**：子窗先写上下文卡、最后写 report；orchd 等这一轮结束（hooks 的 Stop）或 `close_grace_s` 后才关；winctl 送 `/exit` 让 claude 自己退出、收 key（借鉴 SuperAgent：执行会话按任务保留，名额——窗与 key——用完就还）。**再用**：窗意外消失 → 保留租约、`--resume` 回原会话；key 失效 → 换 key、`--resume`；任务重试 → 新工作窗默认 `--resume` 原会话（估计超过 `resume_max_tokens` 就开新窗靠上下文卡）；上下文超过模型上限 → 只能开新窗（1.7.0 实测：超限的会话 resume 仍 400）；做完的任务要追问 → `orchd.py reopen <任务> --question …`。同时开着的子窗不超过 `max_windows`，另留一个人工槽位。

**R27 停止要优雅、取数认启动器自己的文件**：停任务先 TERM、宽限再 KILL；结果只从 orchd 包装进程写的 `console.log` 与任务包启动器写的文件取，`tee` 的副本只作辅助。

**R28 任务包接口 orch-manifest/2**（`references/package-contract.md`）：任务、依赖（`deps`/`after`）、卡数档位、资源令牌、命令、产物检查、续跑证据（`done_if`/`skip_if_cmd`）、门控变体、包自己的环境变量（`run_env`）与子窗规则（`brief`）都写在 manifest 里。缺字段时 `orchd init` 按默认补并提示。

**R31 定时巡检在 `orchd.py wait` 里做**：每 60 秒按 health 的判据查一遍（守护心跳、在跑任务的核查与窗、未确认告警、开不起来的窗、没人管的失败），**不进主窗上下文**；查出新问题才叫醒主窗（同一件事 `wait_realert_s` 内不重复叫）；没事每 `summary_every_s`（默认 2 小时）醒一次给一行进展。固定时点（门控出结论、里程碑达成、结果就绪）由 orchd 写成通知或事件，主窗不用自己记。要看全局详情时手工跑 `orchd.py health`。

**R34 启动确认：三项都有才算“真开始”**（研究者 2026-11-13 的思路）：① 进程真起来并占住资源（GPU 任务：租到的卡上都有它的进程；agent 或 `allow_partial`：至少一张；CPU 任务：进程在）；② 这种占用连续 `start_hold_s` 秒（默认 30）；③ 实验真开始——任务写了开始标志 `$ORCH_STARTED`、manifest 的 `started_if`/`started_log` 出现、进度文件在占用后更新，或包什么都没声明时持续计算满 `start_hold_s`。真开始之前的卡时记“启动开销”（`startup_s`，每个任务的启动用时进事实流与看板）；之前退出的失败标“启动阶段失败”（多半是环境、路径、参数、端口、显存，修复窗先查这些）；过了启动时限 `warmup_s` 还没真开始报 `no_start`。任务包要让“真开始”可判：长加载的任务写 `progress` 或在第一步算完时 `touch "$ORCH_STARTED"`，并把 `warmup_s` 设成加载时间的 2–3 倍。

**R35 能并行的实验写成多档脚本**（研究者 2026-11-13）：一组互相独立的格（配置、种子、分片、模型）一律用 `scripts/cellrun.py` 跑——租到 1 张卡一格接一格，租到 4 张同时跑 4 格；剩下的格用不满租约时自动 `orchd.py shrink` 还卡；已完成的格跨重试、跨抢占跳过；同时跑的格各有端口小段与临时目录。单个大运行按 `$ORCH_NGPU` 设并行度（TP/DP），不写死卡数。manifest 把所有能用的档都写进 `gpu_options`（如 `{"4": null, "2": null, "1": null}`）；结果不能依赖档位（计时类除外：计时的格用 `--max-par 1`、`strict_tier` 或独占令牌）。

**R36 异常预案先写进任务包，运行中改计划只用 orchd 命令**：任务包为每个任务写好“修不好怎么办”（`if_fail`: `accept` 照实交 / `drop` 放弃 / 不写 = 交主窗）与备选方案（`fallback_for`：主方案失败成定局或被放弃时才跑；下游写 `"主|备"` 任一成功即可）。运行中发现的变化一律用命令改、写理由、进 `notes/decisions.md`：确实不可执行 → `drop`；发现还缺前序 → `add` 新任务 + `dep --add`；优先级要变 → `prio`；档位、令牌、时限要变 → `edit`；坏卡 → `cordon`；全局暂停 → `config --set paused=原因`。每一种情况由谁决定、用哪条命令，照 `references/manual.md` 第 6 节的表；表里没有的，开判断窗。

**R37 上下文预算：按云端的模型档位定间隔，尽量不压缩**（研究者 2026-11-13）：主窗用 L 档（配置 840k；1.7.0 选档规则）。2.0.0 的主窗每次醒来约 1–2k token（定时汇报）到 3–5k（要处理的事），开工读 skill 与包约 6–8 万；按“有事才醒 + 2 小时一行”，一个约 25 小时的包全程约 15 万，远低于压缩线，**一般整轮不压缩**。子窗默认 V_fast 档（配置 280k，约 204k 自动压缩）：一事一窗、做完就关，所以每扇窗的上下文只是一件事；重试时 resume 原会话的上限 `resume_max_tokens` = 12 万（给新的一轮留出余量）。档位按活选（1.7.0 选档表）：任务包可在 manifest 写 `tier`、`sched_defaults.tier_by_kind`（例如环境任务用 T、判断窗用 M），orchd 开窗时传给 winctl。每扇子窗的压缩次数 orchd 从 hooks 的 PreCompact 记下，`orchd.py health` 列出，回传时写进 skill 问题。

**R32 环境任务优先、只新建不改旧**：实验按云端现有的版本设计；任务包确实要不同版本时，包里写一个环境任务（`kind: cpu-agent` 或 `cpu-job`，`skip_if_cmd` 是“现有环境已满足”的检查命令，`prio_boost` 高），用到它的任务都依赖它。环境任务在自己的窗里**新建隔离环境**（新目录、新 venv/conda 环境），装完跑冒烟，把解释器路径写进包规定的环境文件；**绝不在现有环境里升级、降级、删包**（R04）。

### 失败与上报

**R16** 失败先分类（启动阶段失败 / 瞬时 / 资源冲突 / 确定性 / 环境权限 / 未知）；收敛型重试可以继续但逐层记根因，发散型（同一现象反复或随机）第 3 次就停。自动派窗模式下 orchd 对失败任务最多自动开 `max_fix`（默认 2）次修复窗，用完按包的 `if_fail` 预案处理（`accept`/`drop`，并发 `orch_result` 告诉研究者）；没写预案才升级给主窗。`orchd` 的自动重试只用 manifest 的 `retries`，被 `kill` 停掉的不重试，被抢占的排回队列不算失败。失败照实交（accept）或放弃（drop）后：严格依赖它的任务自动跳过，`after` 与 `deps_optional` 照常放行，它的备选（`fallback_for`）就绪。

**R17** 被限流：换凭证后 resume 原会话，不判任务失败（`references/windows-and-keys.md`）。`key_window.py` 没有冷却机制，换 key 实际要重开窗（`winctl.sh close` + `open`，上下文卡保证接得上）。

**R18** 每个非显然的决定写一行 `notes/decisions.md`：时间｜决定｜依据｜影响的任务。

**R29 skill 自身的问题当场记、运行中不改 skill**：任何窗遇到 skill 本身的问题（脚本报错或误判、规则不清或矛盾、文档与脚本不一致、缺功能、太慢），当场 `python3 -I $S/skill_feedback.py add --td <任务目录> --kind bug|rule|gap|doc|perf --where <R编号或脚本> --symptom "<现象原文>" [...]`；实验本身的问题记弯路。每次回传都用 `skill_feedback.py export` 导出（文件名照任务包；包没规定时用 `skill-issues.md`）。运行中默认不改 skill；不改就完全跑不下去时按 `references/evolution.md` 第 3 节热修并报「需要你决定」。升级只按研究者一侧给的升级包装。

### 汇报与收尾

**R19** 只在有实质变化或需要研究者决定时汇报（主窗大部分时间不说话）；固定六行格式：需要你决定（没有写「无」）｜任务进展｜用卡（`orchd.py util` 一行 + 8 张卡此刻的归属）｜难题状态｜未解决难题｜记录路径。子窗的 `attention` 问题原话转述，不改写、不替研究者回答。

**R20** 还有未解决项时不能宣称完成；回传一律按任务包内的回传规范，从磁盘重算重取；每次回传都附 skill 问题的导出（R29）与卡时账（`orchd.py util --csv`），文件名照任务包。

## 按需查阅（遇到时再读）

| 遇到 | 读 |
| --- | --- |
| 开工第一步、主窗循环、每类升级怎么处理 | `references/main-loop.md` |
| orchd 的分配规则、启动确认、核查判据、自动派窗、卡时账、全部命令 | `references/orchd.md` |
| 完整使用手册：安装、开工、日常、**异常与变更怎么处理（谁决定、哪条命令）**、子窗的一生与上下文预算、改 skill、Prompt 怎么用 | `references/manual.md` |
| 一组独立的格按租到的卡并行跑、还卡、续跑 | `scripts/cellrun.py`（文件头有完整用法）、`references/package-contract.md` 第 4 节 |
| 写或读任务包的 manifest（orch-manifest/2）、环境任务的写法 | `references/package-contract.md` |
| 开窗、选档、凭证与限流、子窗出错 | `references/windows-and-keys.md` |
| 看护判据、hooks、`winstate` 与 `watch_start`、长值守 | `references/watch.md` |
| 环境管理、ray/SGLang 并发的端口与临时目录 | `references/env.md`（第 4.2 节起由 `references/orchd.md` 取代） |
| 开工拆解、覆盖表、输入纪律、压缩恢复 | `references/task-flow.md` |
| 难题台账与外部指导 | `references/issues.md` |
| 网络不可达 | `references/net.md` |
| 历史上的坑（含 v4 现场 7 问） | `references/pitfalls.md` |
| 验收窗、交接报告、状态机、回传与复核 | `references/return-and-audit.md` |
| 每条规则的生效时刻、执行手段 | `references/rules.md` |
| skill 自身的问题怎么记、怎么升级、版本史 | `references/evolution.md` |
| 任务书（自动生成用 `scripts/brief.py`；手工时的模板）、修复书、上下文卡、交接报告、orch.env | `scripts/brief.py`、`templates/` |
| 全部脚本与附加件的用途、参数 | `references/scripts.md` |

## 执行手段标注

`[脚本]` 有可执行判据、`[门禁]` 有退出码拦截、`[自觉]` 只能靠主窗自律。2.0.0 把 R09、R12（验收派窗）、R14、R15、R16（修复派窗与预案）、R23–R26、R31、R34、R35（cellrun）、R36（命令与预案）的主要部分变成了 `[脚本]`；剩下的 `[自觉]` 是 R01、R02、R18、R22 的“不亲自动手”、R30。

## When to Use

- 用户给出一个较大的任务（尤其是写好了 manifest 的实验任务包），希望多窗并行、持续把多张 GPU 用满、主窗统一掌控、验收窗保证质量
- 任务可拆成互不干扰（或部分依赖）的多个子任务；有共享硬件资源（GPU、端口、主机带宽）需要调度

**Do NOT use**：单步小任务、无需拆解的任务、需要密切人机交互的探索性工作。
