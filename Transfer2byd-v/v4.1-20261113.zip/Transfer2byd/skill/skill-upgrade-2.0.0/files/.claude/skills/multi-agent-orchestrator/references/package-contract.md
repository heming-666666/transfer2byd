# 任务包接口：orch-manifest/2（R28、R33–R36）

> 研究者一侧写包时，照这一篇写 `state/manifest.json`；云端 `orchd init` 照这一篇读。v1（`orch-manifest/1`）也能读：
> - `gpus` + `est_h` 换算成 `gpu_options`；
> - `kind: task` 按有没有 GPU 换成 `gpu-agent`/`cpu-agent`。
>
> **skill 是全局通用的**：包的路径、变量名、结果位置、实验步骤都写在包里，skill 不认识任何具体的包。

## 1 顶层

```json
{
  "schema": "orch-manifest/2",
  "package_version": "v4.1",
  "partitions": {"A": [0,1,2,3], "B": [4,5,6,7]},
  "sched_defaults": {"warmup_s": 1200, "stall_s": 900, "util_min": 5, "port_base": 21000, "port_span": 200},
  "run_env": {"MYPKG_RUNTIME": "{RUNTIME}", "MYPKG_GPU_LEASE": "external"},
  "brief": {"rules": ["结果一律写 {RUNTIME}/results/<任务>/<运行号>/"], "read_first": ["routes/总览.md"],
            "results_hint": " {RUNTIME}/results/{ID}/ "},
  "items": [ ... ]
}
```

| 键 | 作用 |
|---|---|
| `sched_defaults` | 覆盖 orchd 的默认值，只写需要改的：`warmup_s` `stall_s` `util_min` `start_hold_s` `lost_s` `hold_after_s` `leaf_hold_after_s` `port_span` `cpu_slots` `max_windows` `max_fix` `disk_min_gb` … |
| `run_env` | 包自己的环境变量，每个运行都带上。值里可用 `{PKG}` `{RUNTIME}` `{TD}` `{ID}` `{INST}` `{GPUS}` `{NGPU}`；常用来告诉包内启动器“卡已由 orchd 分好，别再自己抢” |
| `brief.rules` | 每份任务书第 1b 节“本任务包的规定” |
| `brief.read_first` | 每份任务书都要先读的包内文件 |
| `brief.results_hint` | 结果放在哪 |

## 2 每个任务（items 的一项）

| 字段 | 必填 | 含义 |
|---|---|---|
| `id` | 是 | 唯一；与路线卡、结果目录同名 |
| `kind` | 是 | `gpu-job` / `gpu-agent` / `cpu-job` / `cpu-agent` / `milestone` / `role`（第 3 节） |
| `title`、`source`、`why` | 建议 | 一句话标题；路线卡路径（任务书据此写“先读什么”）；放在这里的理由 |
| `deps` | 是 | 强制前序：都成功才就绪。`"A\|B"` = A 或 B 任一成功即可（主方案或它的备选）。`[]` = 无依赖 |
| `deps_optional` | 否 | 其中的前序被跳过、或失败已成定局时也算满足 |
| `after` | 否 | 前序只要结束就放行（成功、失败、跳过都算）。门控判定、回传这类“有什么交什么”的任务用它 |
| `fallback_for` | 否 | 本任务是某任务的备选：主任务失败已成定局（accept，或预案 `if_fail: accept`）或被放弃（drop）才就绪；主任务成功、或因门控与依赖被跳过时，备选跳过 |
| `if_fail` | 否 | 修复 `max_fix` 次仍失败时的预案：`"accept"`（照实交）、`"drop"`（放弃），或 `{"action": …, "note": "…"}`。不写 = 升级给主窗 |
| `gate` | 否 | {门名: "pass"\|"fail"}：门控结论符合才跑，不符合就跳过（主线写 pass，备选写 fail） |
| `gpu_options` | GPU 任务是 | {卡数: 偏好}。**把所有真能用的档都写上**。值是偏好，越小越优先（可写名次或以前实测的时长，只用来排序，不做时间计算）；全写 `null` = 卡多的优先 |
| `strict_tier` | 否 | `true`：只认首选档，例如计时实验的卡数是控制变量 |
| `preemptible` | 否 | `true`：可以被更高优先级、被挡太久的任务抢占（只对 `gpu-job`）。必须能续跑 |
| `prio_boost` | 否 | 加在优先级上的数。正数也会传给它的所有前提（它急，前提也急）；负数只压自己（可选任务给 -3）。**任务图之外的需求不要用它**，写成里程碑（第 3 节） |
| `waiting_human`、`weight` | 里程碑用 | `waiting_human: true` = 有人在等这个决定点（如研究者等小回传判门），喂给它的任务排在一切之前；`weight` = 普通里程碑的分量（默认 1） |
| `tier` | 否 | 这个任务的子窗用哪个模型档位（如环境任务 `"T"`）；不写用 `sched_defaults.tier_by_kind` 或 key_window 的默认档 |
| `hold_after_s` | 否 | 本任务被挡多久开启动保护。不写时：有下游链的马上保护，叶子等 `leaf_hold_after_s`（6 小时）。只在确有理由时写，例如某个叶子任务的结果下一轮要用：写 0，或给正的 `prio_boost` |
| `partition` | 否 | `"A"`/`"B"`：只从该区挑卡 |
| `res` | 否 | 资源令牌（`references/orchd.md` 2.7）；计时敏感的正式对比必须写 |
| `allow_partial` | 否 | `true`：本来就只在部分租到的卡上起进程（不判 `partial`；启动确认只要一张卡） |
| `cmd`、`cwd`、`env` | job 是 | 完整命令（可用 `{PKG}` `{RUNTIME}` `{TD}` `{GPUS}` `{NGPU}` `{RUN_DIR}` `{ID}`）；`cwd` 不写默认包根；额外环境变量 |
| `done_check` | job 建议 | 产物路径模式：退出码 0 但缺产物判失败，不报假完成。可用 `{RUN_DIR}` |
| `done_if` | 否 | 证据路径模式：全部存在就直接判完成、不跑（续跑包里已做完的任务用它） |
| `skip_if_cmd` | 否 | 依赖与门控满足时跑一次，退 0 就直接判完成（环境任务：现有环境已满足就不开窗装） |
| `progress` | 建议 | 进度文件路径模式。JSON 里有 `step`、`steps_total` 时看板能推算剩余时间；进度更新也是启动确认与空转判定的依据 |
| `started_if`、`started_log` | 否 | 实验真开始的证据：文件出现，或 `console.log` 尾部出现这个正则（第 5 节） |
| `warmup_s` | 建议 | 启动时限：正常加载时间的 2–3 倍。加载 70 GB 级模型写 1200 以上 |
| `start_hold_s`、`lost_s`、`stall_s`、`util_min` | 否 | 启动确认的持续占用时长、真开始后进程消失多久才报、空转判定时长、利用率阈值 |
| `max_h` | 否 | 超过就告警（`overtime`，不自动停）。只用来发现跑飞的任务，不参与调度 |
| `retries` | 否 | 非零退出时自动重试次数（默认 0；只给确认是瞬时失败的任务） |
| `notify` | 否 | `true`：完成时发 `orch_result` 叫醒主窗告诉研究者（例如回传交好了） |
| `returns`、`optional` | 建议 | 回传要交的文件；是否可选（看板与回传用） |

## 3 kind 怎么选

| kind | 什么样的任务 | 说明 |
|---|---|---|
| `gpu-job` | 命令写全、不需要现场判断的 GPU 任务：探针、网格扫描、基准、训练脚本 | orchd 一分到卡就自己跑。**这是把卡用满的主力**：能脚本化的都写成 job，要判断的部分拆到 agent 任务里 |
| `gpu-agent` | 要读路线卡、按结果判断、可能要改参数重跑的 GPU 任务：环境适配、复现、端到端接入 | 子窗所有 GPU 命令经 `orchd.py exec` |
| `cpu-job` | 脚本化的 CPU 任务：汇总、出表、打包、门控判定 | — |
| `cpu-agent` | 要 agent 的 CPU 任务：写回传、审计、读代码、环境任务 | — |
| `milestone` | “谁需要这些结果”：研究者的决定点、下一轮的设计、论文的某一节 | 不执行、不占卡；`deps` 写它要的结果，依赖满足就自动记完成。它让任务图之外的需求进入优先级：喂给它的任务按它的分量提前 |
| `role` | 看板、验收、回传承办等角色 | 不调度 |

## 4 能并行的实验：多档脚本与 cellrun（R35）

研究者 2026-11-13：能并行做的实验一定要写成 1、2、4、8 张卡都能跑的脚本，让调度占卡更灵活。

**一组互相独立的格**（配置、种子、分片、模型）用 `scripts/cellrun.py`。它按租到的卡同时跑几格：

```bash
# 包里的 job 脚本（manifest: "gpu_options": {"4": null, "2": null, "1": null}）
CELLRUN="$(dirname "$ORCH_BIN")/cellrun.py"
python3 -I "$CELLRUN" --cells "$PKG/state/cells/my-grid.json" --gpus-per-cell 1 \
  --done-cmd 'bash -c ". \"$PKG/scripts/env.sh\" && cell_done MY-GRID {cell}"' \
  -- bash "$PKG/scripts/run_cell.sh" {cell} {conc}
```

- **格列表**：一个 JSON 数组。元素是格名，或 `{"id": …, "gpus": 2, "conc": 240}`，键可以用作命令里的占位符。按先后排，大格在前。
- **怎么跑**：
  - 租到 1 张卡一格接一格，4 张卡同时 4 格；
  - 格可以要不同卡数，cellrun 优先挑对齐的连续卡块；
  - 同时跑的格各有端口小段（`ORCH_PORT_BASE`/`ORCH_PORT_SPAN` 被改写）与临时目录；每格的日志在 `$ORCH_RUN_DIR/cells/<格>/console.log`。
- **完成与续跑**：
  - 格完成记在 `$ORCH_TD/work/cells/<任务>/`，跨重试、跨抢占不变，所以任务可以续跑，`preemptible` 才安全；
  - `--done-cmd` 退 0 也算已完成（结果已在）。
- **还卡**：剩下的格用不满租约时，自动 `orchd.py shrink` 还卡，等卡的任务立刻用上。子窗里经 `exec` 跑时默认不还，加 `--release` 才还。
- **失败**：失败的格不挡别的格；全部结束后有失败退 1，`cells-summary.json` 列出每格的结果。
- **停止**：收到停止信号时一起停，收掉格留下的服务。
- **报错**：格要的卡比租约多、端口段不够分，退 2 并写明怎么改 manifest。

**单个大运行**（一个训练、一个大模型服务）按 `$ORCH_NGPU` 设并行度（TP、DP、副本数），不写死卡数。manifest 写它真能用的档。

**结果不能依赖档位**：同一格用几张卡、同时有几格在跑，结果都要一样。计时类除外：

- 计时的格写 `--max-par 1`（同一任务里不同时跑），或 manifest 只声明一档（`strict_tier`）；
- 并带上独占令牌（`hostbw:x` 或 `machine:x`）。

## 5 让“真开始”可判（R34）

orchd 要见到三项才记“真开始”：进程占住资源、持续 `start_hold_s`、实验真开始的证据。包的责任是给出第三项：

1. 首选：脚本在**第一步真正算完**时 `touch "$ORCH_STARTED"`。例如第一个 batch 出了 loss、第一条请求返回了、冒烟格通过了。
2. 或者在 manifest 写 `progress`，指向启动器每步更新的进度文件；或者写进 `$ORCH_PROGRESS`。
3. 或者写 `started_if`（第一步的产物文件）、`started_log`（日志里第一步的标志行的正则）。
4. 什么都不写时，GPU 任务以持续计算满 `start_hold_s` 为准。多数训练、推理够用，但只做 CPU 预处理的阶段会被当作还没开始。

`warmup_s` 是启动时限，设成正常加载时间的 2–3 倍。过了它还没真开始就报 `no_start`。

## 6 写包时的硬要求（保证卡能用满、异常有预案）

1. **每个 GPU 任务给出所有真能用的档**。同一实验 1/2/4/8 卡都能跑的都写上，orchd 才能按余卡回填。独立的格用 cellrun；单个运行按 `$ORCH_NGPU`。
2. **只写真正的强制依赖**。“有什么交什么”的写 `after`。依赖越少，并行越多。
3. **门控判定写成 `cpu-job`，用 `after`**：读结果文件、按路线卡的阈值算出 pass/fail，写结论文件并调用 `orchd.py gate`；前序失败或没数据就判保守的一支。主线与备选都写进 manifest（主线 `gate: {"P": "pass"}`，备选 `gate: {"P": "fail"}`）。
4. **端口与临时目录一律从 `ORCH_PORT_BASE`、`ORCH_TMP` 派生**，不写死端口；ray 用 `--temp-dir $RAY_TMPDIR`。
5. **计时类正式对比写 `res`**：整机安静 `machine:x`；只怕主机带宽 `hostbw:x`。不写的任务视为可以和别的任务同机并行。
6. **每个 job 都有 `done_check`、进度、续跑**（已完成的格跳过）。被抢占、被重启后不重做。
7. **先冒烟再正式**：
   - 新脚本先跑最小规模（1 步、几条数据）；
   - 冒烟通过才 `touch "$ORCH_STARTED"` 并进正式格；
   - 或者冒烟单独成一个 1 卡、几分钟的 job，正式任务依赖它。
8. **让真开始可判**（第 5 节），`warmup_s` 写够。
9. **预案**：
   - 可选或探索性任务写 `if_fail: "drop"`；
   - 照实交即可的写 `"accept"`；
   - 有退路的写备选任务（`fallback_for` + 下游 `"主|备"`）；
   - 会改变研究方向的不写预案，交主窗与研究者。
10. **环境任务**（R32）：实验按云端现有版本设计。确实要别的版本时，写一个环境任务：
    - `cpu-agent`，`skip_if_cmd` = 检查现有环境是否满足，`prio_boost` 高；
    - 用到它的任务都依赖它；
    - 它的路线卡写清新建隔离环境的步骤与冒烟。
11. **不写预计时长**。调度只看优先级与强制依赖。要排先后，先想“谁需要它的结果”：写进依赖或里程碑（研究者在等的写 `waiting_human`）；“先验证再正式”的写 `after`（例如正式的计时实验 after 正确性门）；实在说不出依赖的才用 `prio_boost`。要防跑飞写 `max_h`。
13. **优先级要自查**：生成 manifest 后，用 skill 的 `priorities()` 算一遍，看顺序是否符合研究上的先后，写进包的 `docs/13`（p01 v4.1 的包自测有这一项）。
12. **包的变量与规则写进 `run_env`、`brief`**，不要指望 skill 认识它们。

## 7 例子

```json
{"id": "GRID", "kind": "gpu-job", "title": "干扰扫描 6 格", "source": "routes/GRID.md", "deps": ["SMOKE"],
 "gpu_options": {"4": null, "2": null, "1": null}, "res": {"hostbw": "s"}, "preemptible": true,
 "cmd": "bash {PKG}/scripts/tasks/grid.sh", "done_check": ["{RUNTIME}/results/GRID/summary.json"],
 "progress": ["{RUNTIME}/results/GRID/*/progress.json"], "warmup_s": 1200, "if_fail": "accept"}
{"id": "BIG", "kind": "gpu-job", "deps": [], "gpu_options": {"8": null}, "res": {"machine": "x"}, "strict_tier": true,
 "cmd": "bash {PKG}/scripts/tasks/big.sh", "started_log": "step 1/", "warmup_s": 1800, "max_h": 12}
{"id": "BIG-LITE", "kind": "gpu-job", "fallback_for": "BIG", "gpu_options": {"4": null}, "cmd": "…"}
{"id": "ANALYZE", "kind": "cpu-job", "deps": ["BIG|BIG-LITE"], "cmd": "…"}
{"id": "ENV", "kind": "cpu-agent", "source": "routes/ENV.md", "deps": [], "tier": "T",
 "skip_if_cmd": "python3 -I {PKG}/scripts/check-versions.py --quiet"}
{"id": "M-DECIDE", "kind": "milestone", "title": "研究者等这批结果判门", "deps": ["GRID", "BIG|BIG-LITE"], "waiting_human": true,
 "why": "研究者要靠它决定下一轮"}
```
