#!/usr/bin/env python3
"""orchd 的模拟测试：假 nvidia-smi + 假实验，验证分配规则、核查判据、停止与门控。

用法：python3 -I tests/orchd_sim.py [--keep]     退出码 0 = 全过；最后一行 “ORCHD SIM OK n/n”
不需要 GPU、不需要 tmux；全部在临时目录里跑，不碰真实锁目录。
"""
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ORCHD = os.path.join(os.path.dirname(HERE), "scripts", "orchd.py")
JOB = os.path.join(HERE, "fake_job.py")
CELLRUN = os.path.join(os.path.dirname(HERE), "scripts", "cellrun.py")
PY = sys.executable
# 假 nvidia-smi / 假 tmux 要能直接执行：解压工具不一定保留可执行位（Python 的 zipfile 就不保留），
# 所以每次测试都在临时目录里放一份带可执行位的副本，第一行指向当前解释器。
_BIN = tempfile.mkdtemp(prefix="orchd-testbin-")


def _exe(src, name, interp=None):
    dst = os.path.join(_BIN, name)
    body = open(src, encoding="utf-8").read()
    if interp:
        body = "#!" + interp + "\n" + "\n".join(body.split("\n")[1:]) if body.startswith("#!") else "#!" + interp + "\n" + body
    with open(dst, "w", encoding="utf-8") as f:
        f.write(body)
    os.chmod(dst, 0o755)
    return dst


SMI = _exe(os.path.join(HERE, "fake_smi.py"), "fake_smi", PY)
TMUX = _exe(os.path.join(HERE, "fake_tmux.sh"), "tmux")
WINCTL = _exe(os.path.join(HERE, "fake_winctl.py"), "fake_winctl.py", PY)
results = []

def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  -- " + str(detail)[:400]), flush=True)

class Sim:
    def __init__(self, items, n=8, sets=None, partitions=None, auto=False, top=None):
        self.root = tempfile.mkdtemp(prefix="orchd-sim-")
        self.td = os.path.join(self.root, "td")
        self.fake = os.path.join(self.root, "fake")
        self.lock = os.path.join(self.root, "locks")
        os.makedirs(os.path.join(self.fake, "apps"))
        self.env = dict(os.environ, ORCH_NVIDIA_SMI=SMI, FAKE_GPU_DIR=self.fake, FAKE_GPU_N=str(n), ORCH_QUIET="1",
                        ORCH_WINCTL=WINCTL, FAKE_ORCHD=ORCHD)
        man = {"schema": "orch-manifest/2", "partitions": partitions or {"A": [0, 1, 2, 3], "B": [4, 5, 6, 7]}, "items": items}
        man.update(top or {})
        self.man = os.path.join(self.root, "manifest.json")
        json.dump(man, open(self.man, "w"), ensure_ascii=False)
        base = ["warmup_s=2", "stall_s=2", "idle_alert_s=2", "reserve_ttl_s=4", "agent_idle_s=3", "grace_s=2",
                "start_hold_s=0.8", "lost_s=1", "close_min_s=0", "close_grace_s=1",
                "realert_s=0", "heartbeat_stale_s=30", "tmp_root=" + os.path.join(self.root, "tmp")]
        args = ["init", "--td", self.td, "--manifest", self.man, "--lockdir", self.lock, "--pkg", self.root,
                "--runtime", os.path.join(self.root, "rt")]
        for s in base + (["auto_windows=true"] if auto else ["auto_windows=false"]) + (sets or []):
            args += ["--set", s]
        r = self.run(*args)
        assert r.returncode == 0, r.stdout + r.stderr

    def run(self, *args, env=None):
        return subprocess.run([PY, "-I", ORCHD] + list(args), capture_output=True, text=True, env=env or self.env,
                              cwd=self.root)

    def tick(self, n=1, gap=0.4):
        for _ in range(n):
            r = self.run("tick", "--td", self.td)
            if r.returncode != 0:
                print(r.stdout, r.stderr)
            time.sleep(gap)

    def st(self):
        return json.load(open(os.path.join(self.td, "notes", "sched", "state.json")))

    def task(self, tid):
        return self.st()["tasks"][tid]

    def until(self, pred, limit=30, gap=0.4):
        t0 = time.time()
        while time.time() - t0 < limit:
            self.tick(1, gap)
            if pred(self.st()):
                return True
        return False

    def events(self):
        p = os.path.join(self.td, "notes", "events", "orchd.jsonl")
        return [json.loads(x) for x in open(p)] if os.path.isfile(p) else []

    def winlog(self):
        p = os.path.join(self.fake, "winctl.log")
        return [json.loads(x) for x in open(p)] if os.path.isfile(p) else []

    def emit(self, typ, **kv):
        rec = {"type": typ, "ts": "x", "seq_t": time.time()}
        rec.update(kv)
        with open(os.path.join(self.td, "notes", "facts.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    def facts(self):
        p = os.path.join(self.td, "notes", "facts.jsonl")
        return [json.loads(x) for x in open(p)] if os.path.isfile(p) else []

    def close(self, keep=False):
        st = self.st()
        for tid, t in st["tasks"].items():
            if t.get("status") in ("running", "reserved"):
                self.run("kill", "--td", self.td, tid, "--grace", "1")
        if not keep:
            shutil.rmtree(self.root, ignore_errors=True)

def job(tid, secs, opts=None, deps=None, kind="gpu-job", extra="", **kw):
    it = {"id": tid, "kind": kind, "deps": deps or [], "cmd": "%s %s %s %s" % (PY, JOB, secs, extra)}
    if kind.startswith("gpu"):
        it["gpu_options"] = opts or {"1": 0.01}
    it.update(kw)
    return it

def t1_priority_and_tiers():
    print("== 1 优先级、最快档、余卡回填、CPU 立即执行")
    items = [
        job("A", 3, {"8": 0.003, "4": 0.001}),                 # 4 卡比 8 卡快 -> 取 4
        job("B", 3, {"2": 0.001}),
        job("C1", 3, {"1": 0.001}), job("C2", 3, {"1": 0.001}), job("C3", 3, {"1": 0.001}),
        job("D1", 1, {"8": 0.001}, deps=["A"]), job("D2", 1, {"1": 0.001}, deps=["A"]),
        job("E", 1, {"1": 0.001}, deps=["B"]),
        job("CPU0", 1, kind="cpu-job"),
        job("CPU1", 1, kind="cpu-job", deps=["CPU0"]),
    ]
    s = Sim(items)
    s.tick(1)
    st = s.st()["tasks"]
    check("1a 扇出最大的 A 先发，按 est_h 选 4 卡（不是 8 卡）", st["A"]["status"] == "running" and len(st["A"]["gpus"]) == 4, st["A"])
    check("1b 余卡给下一优先级 B（2 卡）", st["B"]["status"] == "running" and len(st["B"]["gpus"]) == 2, st["B"])
    nC = sum(1 for x in ("C1", "C2", "C3") if st[x]["status"] == "running")
    check("1c 剩下 2 张卡回填两个 1 卡任务，第三个等卡", nC == 2, [st[x]["status"] for x in ("C1", "C2", "C3")])
    check("1d CPU 任务无依赖立即执行", st["CPU0"]["status"] == "running", st["CPU0"])
    used = sum(len(t.get("gpus", [])) for t in st.values() if t["status"] == "running")
    check("1e 8 张卡全部分出", used == 8, used)
    lockdirs = sorted(os.listdir(s.lock))
    check("1f 锁与 gpu_lock.sh 同格式（gpu<i>.lock/owner）", len(lockdirs) == 8 and
          open(os.path.join(s.lock, lockdirs[0], "owner")).read().startswith("orchd:"), lockdirs)
    ok = s.until(lambda S: S["tasks"]["CPU1"]["status"] in ("running", "done"), 15)
    check("1g CPU 依赖一完成立即执行后继", ok, s.task("CPU1"))
    ok = s.until(lambda S: all(S["tasks"][x]["status"] == "done" for x in S["tasks"]), 60)
    check("1h 全部任务跑完", ok, {k: v["status"] for k, v in s.st()["tasks"].items()})
    sl = s.st()
    check("1i 结束后锁全部释放", os.listdir(s.lock) == [], os.listdir(s.lock))
    a = s.task("A")
    ports = set()
    spec = json.load(open(os.path.join(a["run_dir"], "spec.json")))
    check("1j 运行环境带标签、端口段、独立 ray 临时目录",
          spec["env"]["ORCH_TASK"] == "A" and spec["env"].get("ORCH_INST")
          and "ORCH_PORT_BASE" in spec["env"] and "slot" in spec["env"]["RAY_TMPDIR"], spec["env"])
    log = open(os.path.join(a["run_dir"], "console.log")).read()
    check("1k 包装日志逐行落盘、写明 GPU 与 rc", "fake job on" in log and "rc=0" in log, log[-300:])
    facts = [f["type"] for f in s.facts()]
    check("1l 事实流有 task_add/dispatch/lease/release/report", all(x in facts for x in
          ("task_add", "dispatch", "lease", "release", "report")), sorted(set(facts)))
    acc = sl["acct"]
    check("1m 卡时账有“真在用”", acc.get("used_s", 0) > 0, acc)
    s.close()

def t2_exclusive_and_backfill():
    print("== 2 整机独占任务：优先级 + 启动保护（不靠预计时长）；可抢占的任务先用空卡，到时让出")
    items = [
        job("L", 6, {"4": None}, prio_boost=5),                                  # 先占 4 卡，跑 6 s
        job("X", 2, {"8": None}, res={"machine": "x"}, prio_boost=3),             # 独占任务
        job("S", 30, {"1": None}),                                               # 不可抢占的低优先级任务
        job("P", 60, {"2": None}, preemptible=True),                             # 可抢占的低优先级任务
    ]
    s = Sim(items, sets=["hold_after_s=0"])
    s.tick(1)
    st = s.st()["tasks"]
    check("2a 高优先级 L 先拿 4 卡", st["L"]["status"] == "running" and len(st["L"]["gpus"]) == 4, st["L"])
    check("2b 独占任务 X 被挡 → 启动保护", st["X"]["status"] == "ready" and "启动保护" in st["X"].get("why", ""), st["X"])
    check("2c 不可抢占的低优先级 S 不占保护期的卡", st["S"]["status"] == "ready" and "启动保护" in st["S"].get("why", ""), st["S"])
    check("2d 可抢占的 P 先用空卡（不让卡白空着）", st["P"]["status"] == "running", st["P"])
    snap = s.st()["snapshot"]
    check("2e 状态里写明启动保护", s.st().get("hold", {}).get("task") == "X", s.st().get("hold"))
    ok = s.until(lambda S: S["tasks"]["X"]["status"] in ("running", "done"), 40)
    pst = s.task("P")
    check("2f L 结束后：抢占 P、X 整机起跑", ok and (pst["status"] in ("wait", "ready", "running", "done")) and "抢占" in (
        pst.get("reason", "") + json.dumps(s.events(), ensure_ascii=False)), (s.task("X"), pst))
    ok = s.until(lambda S: S["tasks"]["X"]["status"] == "done", 30)
    ok2 = s.until(lambda S: S["tasks"]["S"]["status"] in ("running", "done") and S["tasks"]["P"]["status"] in ("running", "done"), 20)
    check("2g X 结束后 S 与被抢占的 P 都重新跑（P 不算失败）", ok and ok2 and s.task("P")["status"] != "failed", (s.task("S"), s.task("P")))
    s.close()

def t3_verdicts():
    print("== 3 用卡核查：分了没用 / 分多用少 / 没真开始 / 空转 / 越界 / 无主进程")
    items = [
        job("NOGPU", 20, {"1": 0.01}, extra="--no-gpu", partition="A"),
        job("HALF", 20, {"2": 0.01}, extra="--use 1", partition="A"),
        job("IDLE", 20, {"1": 0.01}, extra="--util 0", partition="B"),
        job("LATE", 20, {"1": 0.01}, extra="--idle-after 2.5", partition="A"),
        job("GOOD", 20, {"1": 0.01}, extra="--progress {RUN_DIR}/p.txt", progress="{TD}/work/sched/GOOD/*/p.txt",
            partition="B"),
    ]
    s = Sim(items)
    s.tick(1)
    st = s.st()["tasks"]
    stray_card = [c for c in "01234567" if c not in sum((t.get("gpus", []) for t in st.values()), [])][0]
    # STRAY：用 exec 不行（要租约），这里直接起一个带 GOOD 标签、跑到别的卡上的进程
    env = dict(s.env, ORCH_TASK="GOOD", CUDA_VISIBLE_DEVICES=stray_card)
    p_stray = subprocess.Popen([PY, JOB, "20"], env=env)
    rogue_card = [c for c in "01234567" if c not in sum((t.get("gpus", []) for t in st.values()), []) and c != stray_card][0]
    env2 = dict(s.env, CUDA_VISIBLE_DEVICES=rogue_card)
    env2.pop("ORCH_TASK", None)
    p_rogue = subprocess.Popen([PY, JOB, "20"], env=env2)
    ok = s.until(lambda S: S["tasks"]["NOGPU"].get("verdict") == "not_on_gpu", 15)
    check("3a 过了预热期卡上没进程 -> not_on_gpu", ok, s.task("NOGPU"))
    ok = s.until(lambda S: S["tasks"]["HALF"].get("verdict") == "partial", 10)
    check("3b 租 2 张只用 1 张 -> partial", ok, s.task("HALF"))
    ok = s.until(lambda S: S["tasks"]["IDLE"].get("verdict") == "no_start", 15)
    check("3c 占着卡、利用率一直 0、也没有进度（从没真开始）-> no_start", ok and not s.task("IDLE").get("confirmed_t"), s.task("IDLE"))
    ok = s.until(lambda S: S["tasks"]["LATE"].get("verdict") == "stall", 15)
    check("3c2 真开始之后利用率掉到 0、进度不动 -> stall", ok and s.task("LATE").get("confirmed_t"), s.task("LATE"))
    ok = s.until(lambda S: S["tasks"]["GOOD"].get("verdict") == "stray", 10)
    check("3d 带 GOOD 标签的进程跑到没租的卡 -> stray", ok, s.task("GOOD"))
    al = s.st()["alerts"]
    check("3e 无租约的计算进程 -> rogue 告警", any(k.startswith("rogue:") for k in al), list(al))
    ev = [e for e in s.events() if e["event"] == "orch_alert"]
    kinds = {e.get("kind") for e in ev}
    check("3f 每类问题都发了 orch_alert 事件（叫醒主窗）", {"not_on_gpu", "partial", "stall", "no_start", "stray", "rogue"} <= kinds, kinds)
    r = s.run("check", "--td", s.td)
    check("3g check 门禁：有未确认告警 -> 退 1", r.returncode == 1, r.stdout)
    r = s.run("status", "--td", s.td)
    check("3h status 能打印（≤ 40 行）", r.returncode == 0 and len(r.stdout.splitlines()) <= 40, r.stdout)
    p_stray.kill(); p_rogue.kill()
    p_stray.wait(); p_rogue.wait()
    s.close()

def t4_kill_own_only():
    print("== 4 停止只动自己的进程；daemonize 出去的孙进程也收回")
    items = [job("K", 60, {"1": 0.01}, extra="--child"), job("OTHER", 60, {"1": 0.01})]
    s = Sim(items)
    s.tick(1)
    ok = s.until(lambda S: S["tasks"]["K"].get("verdict") == "ok" and S["tasks"]["OTHER"].get("verdict") == "ok", 10)
    apps = os.listdir(os.path.join(s.fake, "apps"))
    k = s.task("K")
    check("4a K 的主进程和脱离的孙进程都在卡上", ok and sum(1 for a in apps if a.endswith("-" + k["gpus"][0])) >= 2, apps)
    r = s.run("kill", "--td", s.td, "K", "--grace", "2")
    time.sleep(1)
    apps2 = os.listdir(os.path.join(s.fake, "apps"))
    left_k = [a for a in apps2 if a.endswith("-" + k["gpus"][0])]
    check("4b kill K 后它的进程（含孙进程）全部消失", left_k == [], (r.stdout, apps2))
    o = s.task("OTHER")
    check("4c OTHER 不受影响", any(a.endswith("-" + o["gpus"][0]) for a in apps2), apps2)
    ok = s.until(lambda S: S["tasks"]["K"]["status"] == "failed", 10)
    check("4d 被停的任务记为失败并释放卡", ok and not any(
        open(os.path.join(s.lock, d, "owner")).read().strip().endswith(":K") for d in os.listdir(s.lock)), s.task("K"))
    s.close()

def t5_gates():
    print("== 5 门控：通过走主线，不通过走备选，跳过沿依赖传播")
    items = [
        job("JUDGE", 1, kind="cpu-job"),
        job("MAIN", 1, {"1": 0.001}, deps=["JUDGE"], gate={"P": "pass"}),
        job("MAIN2", 1, {"1": 0.001}, deps=["MAIN"]),
        job("ALT", 1, {"1": 0.001}, deps=["JUDGE"], gate={"P": "fail"}),
        job("AFTER", 1, kind="cpu-job", deps=["MAIN2", "ALT"], deps_optional=["MAIN2", "ALT"]),
    ]
    s = Sim(items)
    s.until(lambda S: S["tasks"]["JUDGE"]["status"] == "done", 15)
    s.tick(2)
    check("5a 门控没出结论时主线、备选都等", s.task("MAIN")["status"] == "wait" and s.task("ALT")["status"] == "wait",
          (s.task("MAIN"), s.task("ALT")))
    s.run("gate", "--td", s.td, "P", "fail")
    ok = s.until(lambda S: S["tasks"]["ALT"]["status"] in ("running", "done"), 10)
    check("5b P=fail -> 备选 ALT 起跑", ok, s.task("ALT"))
    check("5c 主线 MAIN 与其下游 MAIN2 被跳过", s.task("MAIN")["status"] == "skipped" and s.task("MAIN2")["status"] == "skipped",
          (s.task("MAIN"), s.task("MAIN2")))
    ok = s.until(lambda S: S["tasks"]["AFTER"]["status"] == "done", 20)
    check("5d 可选依赖被跳过时，汇总任务照常执行", ok, s.task("AFTER"))
    s.close()

def t6_agent_flow():
    print("== 6 agent 任务：预留 -> 主窗 start -> 子窗 exec -> done；无租约 exec 被拒；预留超时收回")
    items = [job("AG", 0, {"2": 0.01}, kind="gpu-agent"), job("AG2", 0, {"1": 0.01}, kind="gpu-agent"),
             job("CA", 0, kind="cpu-agent"), job("LATE", 0, {"1": 0.01}, kind="gpu-agent", deps=["CA"])]
    s = Sim(items)
    r = s.run("exec", "--td", s.td, "LATE", "--", PY, JOB, "0.5")
    check("6a 没有租约的 GPU 任务 exec 被拒（退 4）", r.returncode == 4, r.stderr)
    s.tick(1)
    st = s.st()["tasks"]
    check("6b gpu-agent 拿到预留并发 orch_sched 事件", st["AG"]["status"] == "reserved" and
          any(e["event"] == "orch_sched" and e.get("task") == "AG" for e in s.events()), st["AG"])
    check("6c cpu-agent 依赖满足即通知主窗", any(e["event"] == "orch_sched" and e.get("task") == "CA" for e in s.events()))
    r = s.run("start", "--td", s.td, "AG", "--window", "w-ag")
    check("6d 主窗 start 后转为 running", r.returncode == 0 and s.task("AG")["status"] == "running", r.stdout + r.stderr)
    r = s.run("exec", "--td", s.td, "AG", "--name", "smoke", "--", PY, JOB, "1.5")
    t = s.task("AG")
    run_dir = t["exec_runs"][-1]["dir"]
    log = open(os.path.join(run_dir, "console.log")).read()
    check("6e exec 在租约卡上跑、日志与 rc 落盘", r.returncode == 0 and ("GPU=" + ",".join(t["gpus"])) in log, log[:300])
    r = s.run("env", "--td", s.td, "AG")
    check("6f env 打印租约环境", "CUDA_VISIBLE_DEVICES=" in r.stdout and "ORCH_PORT_BASE=" in r.stdout, r.stdout)
    s.run("done", "--td", s.td, "AG", "--evidence", run_dir)
    s.tick(1)
    check("6g done 后释放卡", s.task("AG")["status"] == "done" and not any(
        open(os.path.join(s.lock, d, "owner")).read().strip().endswith(":AG") for d in os.listdir(s.lock)))
    ok = s.until(lambda S: S["tasks"]["AG2"]["status"] == "ready", 15)
    check("6h AG2 预留超时没人接 -> 收回并告警", ok and any(k.startswith("rsv:") for k in s.st()["alerts"]), s.task("AG2"))
    # 子窗只写 report 事实（旧流程）也能推进依赖
    s.run("start", "--td", s.td, "CA", "--window", "w-ca")
    time.sleep(0.05)
    subprocess.run([PY, "-c", "import json,time;open(%r,'a').write(json.dumps({'type':'report','id':'CA','state':'完成','ts':'x','seq_t':time.time(),'window':'w-ca'})+'\\n')"
                    % os.path.join(s.td, "notes", "facts.jsonl")])
    ok = s.until(lambda S: S["tasks"]["CA"]["status"] == "done" and S["tasks"]["LATE"]["status"] in ("reserved", "ready"), 10)
    check("6i 子窗写 report 完成 -> 依赖推进", ok, (s.task("CA"), s.task("LATE")))
    s.close()

def t7_fail_retry_stale():
    print("== 7 失败重试、失败告警、产物检查、僵尸锁")
    items = [job("F", 0.5, {"1": 0.001}, extra="--rc 3", retries=1),
             job("NOOUT", 0.5, {"1": 0.001}, done_check=["{TD}/does-not-exist/*"]),
             job("OK", 0.5, {"1": 0.001})]
    s = Sim(items)
    os.makedirs(os.path.join(s.lock, "gpu7.lock"))
    open(os.path.join(s.lock, "gpu7.lock", "owner"), "w").write("V3-1\n")
    old = time.time() - 7200
    os.utime(os.path.join(s.lock, "gpu7.lock"), (old, old))
    inst = json.load(open(os.path.join(s.td, "notes", "sched", "config.json")))["instance"]
    os.makedirs(os.path.join(s.lock, "gpu6.lock"))
    open(os.path.join(s.lock, "gpu6.lock", "owner"), "w").write("orchd:%s:GHOST\n" % inst)
    os.makedirs(os.path.join(s.lock, "gpu5.lock"))
    open(os.path.join(s.lock, "gpu5.lock", "owner"), "w").write("orchd:zzzzzz:OTHERPKG\n")
    ok = s.until(lambda S: S["tasks"]["F"]["status"] == "failed", 30)
    check("7a 非零退出先重试 1 次再判失败", ok and s.task("F")["attempt"] == 2, s.task("F"))
    check("7b 失败发 orch_alert", any(e.get("kind") == "failed" and e.get("task") == "F" for e in s.events()))
    ok = s.until(lambda S: S["tasks"]["NOOUT"]["status"] == "failed", 15)
    check("7c 退出 0 但缺产物 -> 失败（不报假完成）", ok and "缺产物" in s.task("NOOUT").get("reason", ""), s.task("NOOUT"))
    al = s.st()["alerts"]
    check("7d 他人的老锁只点名不回收", "stale:7" in al and os.path.isdir(os.path.join(s.lock, "gpu7.lock")), list(al))
    check("7e 本实例自己的残留锁自动收回", not os.path.isdir(os.path.join(s.lock, "gpu6.lock")))
    check("7g 另一套编排（别的实例）的锁不动、不分它的卡", os.path.isdir(os.path.join(s.lock, "gpu5.lock"))
          and all("5" not in t.get("gpus", []) for t in s.st()["tasks"].values()))
    check("7f 被占的 GPU7 不分给任何任务", all("7" not in t.get("gpus", []) for t in s.st()["tasks"].values()))
    s.close()

def t8_partition_and_foreign():
    print("== 8 分区、别人占的显存、端口段不重叠")
    items = [job("PA", 3, {"4": 0.001}, partition="A"), job("PB", 3, {"2": 0.001}, partition="B"),
             job("PB2", 3, {"2": 0.001}, partition="B")]
    s = Sim(items)
    open(os.path.join(s.fake, "extra_mem"), "w").write("5,30000\n")
    s.tick(1)
    st = s.st()["tasks"]
    check("8a A 区任务只拿 0-3", st["PA"]["status"] == "running" and set(st["PA"]["gpus"]) <= set("0123"), st["PA"])
    bcards = sorted(st["PB"].get("gpus", []) + st["PB2"].get("gpus", []))
    check("8b B 区任务避开被别人占显存的 GPU5", "5" not in bcards, bcards)
    check("8c B 区只剩 3 张：两个 2 卡任务只能发一个", sum(1 for x in ("PB", "PB2") if st[x]["status"] == "running") == 1,
          (st["PB"], st["PB2"]))
    slots = [t.get("slot") for t in st.values() if t["status"] == "running"]
    check("8d 每个在跑任务一个槽位（端口段不重叠）", len(slots) == len(set(slots)), slots)
    s.close()

def t10_cpu_res():
    print("== 10 资源令牌对 CPU 任务也生效")
    items = [job("TIMED", 3, {"8": 0.001}, res={"machine": "x", "hostbw": "x"}, prio_boost=5),
             job("PACK", 1, kind="cpu-job", res={"hostbw": "s", "disk": "x"}),
             job("PLAIN", 1, kind="cpu-job")]
    s = Sim(items)
    s.tick(1)
    st = s.st()["tasks"]
    check("10a 计时任务在跑时，占主机带宽的 CPU 任务等", st["TIMED"]["status"] == "running" and st["PACK"]["status"] == "ready"
          and "令牌" in st["PACK"].get("why", ""), (st["TIMED"], st["PACK"]))
    check("10b 不声明令牌的 CPU 任务照常立即执行", st["PLAIN"]["status"] == "running", st["PLAIN"])
    ok = s.until(lambda S: S["tasks"]["PACK"]["status"] in ("running", "done"), 20)
    check("10c 计时任务结束后 CPU 任务立即开跑", ok and s.task("TIMED")["status"] == "done", s.task("PACK"))
    s.close()


def t11_smi_failure():
    print("== 11 nvidia-smi 失败的那几轮：不误报、不分卡")
    s = Sim([job("RUN", 30, {"1": 0.01}), job("LATER", 1, {"1": 0.001}, deps=["RUN"])])
    ok = s.until(lambda S: S["tasks"]["RUN"].get("verdict") == "ok", 10)
    open(os.path.join(s.fake, "smi_fail"), "w").write("1")
    time.sleep(2.5)                      # 超过预热期 2 s：如果拿空数据核查，会误判 not_on_gpu
    s.tick(4)
    st = s.st()
    check("11a 采样失败期间不判 not_on_gpu、不清空核查", ok and st["tasks"]["RUN"].get("verdict") == "ok", st["tasks"]["RUN"])
    check("11b 连续 3 次失败才报 smi 告警", "smi" in st["alerts"], list(st["alerts"]))
    os.remove(os.path.join(s.fake, "smi_fail"))
    s.tick(2)
    check("11c 恢复后 smi 告警自动清除", "smi" not in s.st()["alerts"], list(s.st()["alerts"]))
    s.close()

def t12_token_reservation():
    print("== 12 主机带宽独占的任务不被源源不断的共享任务饿死（启动保护 + 抢占可抢占的）")
    items = [job("SHARE1", 6, {"2": None}, res={"hostbw": "s"}, prio_boost=9),
             job("EXCL", 2, {"1": None}, res={"hostbw": "x"}, prio_boost=5),
             job("SHARE_LONG", 30, {"2": None}, res={"hostbw": "s"}),
             job("SHARE_PRE", 60, {"1": None}, res={"hostbw": "s"}, preemptible=True),
             job("PLAIN", 30, {"1": None})]
    s = Sim(items, sets=["hold_after_s=0"])
    s.tick(1)
    st = s.st()["tasks"]
    check("12a 共享任务在跑时，独占任务进入启动保护", st["EXCL"]["status"] == "ready" and "启动保护" in st["EXCL"].get("why", ""),
          st["EXCL"])
    check("12b 不可抢占的共享任务不许再开（会挡住独占任务）", st["SHARE_LONG"]["status"] == "ready", st["SHARE_LONG"])
    check("12c 可抢占的共享任务可以先用（之后让出）", st["SHARE_PRE"]["status"] == "running", st["SHARE_PRE"])
    check("12d 不碰令牌的任务照常用余卡", st["PLAIN"]["status"] == "running", st["PLAIN"])
    ok = s.until(lambda S: S["tasks"]["EXCL"]["status"] in ("running", "done"), 30)
    check("12e SHARE1 结束后：抢占 SHARE_PRE，独占任务起跑", ok and s.task("SHARE_PRE")["status"] != "failed", (s.task("EXCL"), s.task("SHARE_PRE")))
    s.close()

def t13_tie_fewer_cards_and_env():
    print("== 13 同样快取卡少的；运行环境带 PCI 顺序；CPU 任务看不到卡")
    s = Sim([job("TIE", 2, {"8": 0.5, "4": 0.5}), job("CPUJ", 2, kind="cpu-job")])
    s.tick(1)
    t = s.task("TIE")
    check("13a 8 卡与 4 卡预计一样快 -> 取 4 卡", len(t.get("gpus", [])) == 4, t)
    spec = json.load(open(os.path.join(t["run_dir"], "spec.json")))
    check("13b CUDA_DEVICE_ORDER=PCI_BUS_ID（与 nvidia-smi 编号一致）", spec["env"].get("CUDA_DEVICE_ORDER") == "PCI_BUS_ID")
    c = s.task("CPUJ")
    cspec = json.load(open(os.path.join(c["run_dir"], "spec.json")))
    check("13c CPU 任务的 CUDA_VISIBLE_DEVICES 为空", cspec["env"].get("CUDA_VISIBLE_DEVICES") == "", cspec["env"])
    check("13d 运行环境带 ORCH_RUN_DIR（= orchd 的运行目录）", cspec["env"].get("ORCH_RUN_DIR") == c["run_dir"], cspec["env"])
    s.close()

def t14_daemon_single():
    print("== 14 一个任务目录只允许一个守护")
    s = Sim([job("D1", 1, {"1": 0.001})])
    p1 = subprocess.Popen([PY, "-I", ORCHD, "daemon", "--td", s.td, "--interval", "0.5"], env=s.env,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.5)
    r = s.run("daemon", "--td", s.td, "--interval", "0.5")
    check("14a 第二个守护被拒（退 1）", r.returncode == 1 and "已有守护" in r.stderr, r.stderr)
    ok = s.until(lambda S: S["tasks"]["D1"]["status"] == "done", 15, gap=0.5)
    check("14b 守护照常推进任务", ok, s.task("D1"))
    p1.terminate(); p1.wait()
    s.close()

def t15_retry_old_report():
    print("== 15 重试后，旧的“受阻”报告不会把新一次判失败；done_if 直接判完成")
    items = [job("AGR", 0, {"1": 0.01}, kind="gpu-agent"),
             job("HAVE", 0, {"1": 0.01}, kind="gpu-agent", done_if=["{TD}/notes"])]
    s = Sim(items)
    s.tick(1)
    check("15a done_if 的证据在 -> 首轮直接完成", s.task("HAVE")["status"] == "done", s.task("HAVE"))
    s.run("start", "--td", s.td, "AGR", "--window", "w1")
    time.sleep(0.05)
    subprocess.run([PY, "-c", "import json,time;open(%r,'a').write(json.dumps({'type':'report','id':'AGR','state':'受阻','ts':'x','seq_t':time.time(),'window':'w1'})+'\\n')"
                    % os.path.join(s.td, "notes", "facts.jsonl")])
    s.tick(1)
    check("15b 子窗报受阻 -> 失败", s.task("AGR")["status"] == "failed", s.task("AGR"))
    s.run("retry", "--td", s.td, "AGR")
    s.tick(1)
    s.run("start", "--td", s.td, "AGR", "--window", "w2")
    s.tick(2)
    check("15c 重试后重新预留、承接，旧报告不再生效", s.task("AGR")["status"] == "running", s.task("AGR"))
    s.close()

def t16_orphan_untagged():
    print("== 16 已结束任务的残留进程、租约卡上的无标签进程")
    s = Sim([job("FIN", 0.5, {"1": 0.001}), job("AGU", 0, {"1": 0.01}, kind="gpu-agent")])
    ok = s.until(lambda S: S["tasks"]["FIN"]["status"] == "done" and S["tasks"]["AGU"]["status"] == "reserved", 15)
    s.run("start", "--td", s.td, "AGU", "--window", "w")
    agu = s.task("AGU")
    used = set(agu["gpus"])
    free_card = [c for c in "01234567" if c not in used][0]
    po = subprocess.Popen([PY, JOB, "30"], env=dict(s.env, ORCH_TASK="FIN", CUDA_VISIBLE_DEVICES=free_card))
    env2 = dict(s.env, CUDA_VISIBLE_DEVICES=agu["gpus"][0]); env2.pop("ORCH_TASK", None)
    pu = subprocess.Popen([PY, JOB, "30"], env=env2)
    ok2 = s.until(lambda S: any(k.startswith("orphan:") for k in S["alerts"]), 10)
    check("16a 已结束任务 FIN 的进程还占着卡 -> orphan 告警（提示 orchd.py kill FIN）", ok and ok2 and any(
        "orchd.py kill FIN" in a["msg"] for a in s.st()["alerts"].values()), list(s.st()["alerts"]))
    ok3 = s.until(lambda S: S["tasks"]["AGU"].get("verdict") == "untagged", 10)
    check("16b 租约卡上的进程没带本任务标签 -> untagged 告警", ok3, s.task("AGU"))
    po.kill(); pu.kill(); po.wait(); pu.wait()
    s.close()

def t17_after_accept():
    print("== 17 after：前序失败也放行（门控判定、回传）；accept 确认失败照实交")
    items = [job("PROBE", 0.3, {"1": 0.001}, extra="--rc 2"), job("JUDGE", 0.3, kind="cpu-job", after=["PROBE"]),
             job("STRICT", 0.3, kind="cpu-job", deps=["PROBE"])]
    s = Sim(items)
    ok = s.until(lambda S: S["tasks"]["PROBE"]["status"] == "failed", 15)
    ok2 = s.until(lambda S: S["tasks"]["JUDGE"]["status"] in ("running", "done"), 10)
    check("17a 前序失败后 after 依赖照常放行", ok and ok2, s.task("JUDGE"))
    check("17b deps 依赖仍在等（前序没成功）", s.task("STRICT")["status"] == "wait", s.task("STRICT"))
    r = s.run("check", "--td", s.td)
    check("17c 失败没人管时 check 不过", r.returncode == 1 and "失败任务没有修复窗" in r.stdout, r.stdout)
    s.run("accept", "--td", s.td, "PROBE", "--reason", "失败两次，照实交")
    s.run("ack", "--td", s.td, "all")
    r = s.run("check", "--td", s.td)
    check("17d accept 之后 check 不再因它不过", "失败任务没有修复窗" not in r.stdout, r.stdout)
    s.close()

def t18_run_dir_done_check():
    print("== 18 done_check 可以写 {RUN_DIR}（任务自己的运行目录）")
    s = Sim([job("RD", 0, kind="cpu-job", cmd="touch \"$ORCH_RUN_DIR/out.json\"", done_check=["{RUN_DIR}/out.json"]),
             job("RDBAD", 0, kind="cpu-job", cmd="true", done_check=["{RUN_DIR}/out.json"])])
    ok = s.until(lambda S: S["tasks"]["RD"]["status"] == "done" and S["tasks"]["RDBAD"]["status"] == "failed", 15)
    check("18a 写了产物的判完成、没写的判失败", ok, (s.task("RD"), s.task("RDBAD")))
    s.close()


def t19_auto_task_window():
    print("== 19 自动派窗：预留 → 自动生成任务书并开窗 → 交完成 → 关窗、自动开验收窗 → 验收 → 关窗")
    s = Sim([job("AG", 0, {"1": 0.01}, kind="gpu-agent", source="routes/AG.md", title="示例任务", notify=True)], auto=True,
            top={"brief": {"rules": ["示例包规则：结果写 {RUNTIME}/r/{ID}"], "results_hint": " {RUNTIME}/r/{ID}/ "}})
    ok = s.until(lambda S: S["tasks"]["AG"]["status"] == "running" and S.get("windows", {}).get("w-ag", {}).get("state") == "open", 15)
    b = os.path.join(s.td, "briefs", "w-ag.md")
    txt = open(b, encoding="utf-8").read() if os.path.exists(b) else ""
    check("19a 预留后 orchd 自己生成任务书、开窗、登记承接（主窗不用动）", ok and "routes/AG.md" in txt, s.st().get("windows"))
    check("19b 任务书含包规则与 exec/env/kill 的完整命令", "1b 本任务包的规定" in txt and "exec --td" in txt and "kill --td" in txt, txt[:300])
    s.emit("report", id="AG", state="完成", window="fake:w-ag", evidence=s.td, summary="示例结论")
    ok = s.until(lambda S: S["tasks"]["AG"]["status"] == "done" and S["windows"].get("au-ag", {}).get("state") == "open"
                 and ["close", "w-ag"] in [c["args"][:2] for c in s.winlog()], 15)
    calls = [c["args"][:2] for c in s.winlog()]
    check("19c 交完成 → 工作窗（等这一轮结束或宽限期后）关闭、验收窗打开", ok and ["close", "w-ag"] in calls, calls)
    check("19f notify 的任务完成 → 发 orch_result 叫醒主窗转告研究者", any(e["event"] == "orch_result" and e.get("task") == "AG"
          for e in s.events()))
    s.emit("audit", id="AG", verdict="pass", evidence=s.td)
    ok = s.until(lambda S: S["windows"].get("au-ag", {}).get("state") == "closed", 15)
    check("19d 验收写了结论 → 验收窗关闭", ok, s.st().get("windows"))
    ev = [e for e in s.events() if e["event"] == "orch_alert"]
    check("19e 全程没有叫醒主窗的告警", not ev, ev)
    s.close()

def t20_auto_fix_and_escalate():
    print("== 20 自动修复：失败 → 修复窗（两次）→ 仍失败才升级给主窗")
    s = Sim([job("FJ", 0.2, {"1": 0.001}, extra="--rc 2")], auto=True)
    ok = s.until(lambda S: S.get("windows", {}).get("fix-fj-1", {}).get("state") == "open", 20)
    b = os.path.join(s.td, "briefs", "fix-fj-1.md")
    check("20a 失败后自动开修复窗，任务书里有失败原因", ok and "退出码 2" in open(b, encoding="utf-8").read(), s.st().get("windows"))
    s.emit("report", id="fix-fj-1", state="受阻", window="fake:fix-fj-1", summary="查不出")
    ok = s.until(lambda S: S.get("windows", {}).get("fix-fj-2", {}).get("state") == "open", 20)
    check("20b 修复窗交了报告仍失败 → 开第二个修复窗", ok, s.st().get("windows"))
    s.emit("report", id="fix-fj-2", state="受阻", window="fake:fix-fj-2", summary="仍查不出")
    ok = s.until(lambda S: any(k.startswith("fixout:") for k in S["alerts"]), 20)
    check("20c 两次修复用完 → 升级给主窗（发 orch_alert）", ok and any(e.get("kind") == "fix_exhausted" for e in s.events()),
          list(s.st()["alerts"]))
    s.run("accept", "--td", s.td, "FJ", "--reason", "照实交")
    s.run("ack", "--td", s.td, "all")
    r = s.run("health", "--td", s.td)
    check("20d 主窗 accept + ack 后巡检通过（退 0）", r.returncode == 0, r.stdout)
    s.close()

def t21_retry_closes_fix():
    print("== 21 修复窗 retry 后：任务重新调度、修复窗自动关")
    s = Sim([job("RJ", 0.2, {"1": 0.001}, extra="--rc 2")], auto=True)
    s.until(lambda S: S.get("windows", {}).get("fix-rj-1", {}).get("state") == "open", 20)
    s.run("retry", "--td", s.td, "RJ")
    ok = s.until(lambda S: S["windows"].get("fix-rj-1", {}).get("state") == "closed", 20)
    check("21a retry 后修复窗关闭、任务重新跑", ok and s.task("RJ")["attempt"] >= 2, (s.st().get("windows"), s.task("RJ")))
    s.close()

def t22_attention_health_maxwin_failure():
    print("== 22 子窗要研究者决定的问题、巡检、子窗上限、开窗失败")
    s = Sim([job("Q1", 0, kind="cpu-agent"), job("Q2", 0, kind="cpu-agent"), job("Q3", 0, kind="cpu-agent")], auto=True,
            sets=["max_windows=2"])
    s.until(lambda S: sum(1 for w in S.get("windows", {}).values() if w["state"] == "open") == 2, 15)
    s.tick(2)
    W = s.st()["windows"]
    check("22a 子窗上限 2：只开两扇，第三个等空位", sum(1 for w in W.values() if w["state"] in ("open", "opening")) == 2
          and "等空位" in s.task("Q3").get("why", "") or s.task("Q3").get("win") is None, (W, s.task("Q3")))
    s.run("ask", "--td", s.td, "Q1", "--question", "用方案 A 还是 B？推荐 A")
    s.tick(2)
    check("22b ask → 发 orch_attention 叫醒主窗，原话转达", any(e["event"] == "orch_attention" and "方案 A" in e.get("msg", "")
          for e in s.events()))
    r = s.run("health", "--td", s.td)
    check("22c 巡检把待决定的问题列出来（退 1）", r.returncode == 1 and "方案 A" in r.stdout, r.stdout)
    s.close()
    s = Sim([job("F1", 0, kind="cpu-agent")], auto=True)
    s.env["FAKE_WINCTL_RC"] = "1"
    ok = s.until(lambda S: any(k.startswith("winfail:") for k in S["alerts"]), 15)
    check("22d 自动开窗失败 → 升级给主窗", ok and any(e.get("kind") == "auto_window" for e in s.events()), list(s.st()["alerts"]))
    s.close()

def t23_send_and_orphan():
    print("== 23 在跑的子窗出用卡问题：告警原文发进它的窗；残留进程自动收")
    s = Sim([job("SA", 0, {"1": 0.01}, kind="gpu-agent"), job("DONEJ", 0.2, {"1": 0.001})], auto=True,
            sets=["agent_idle_s=2", "orphan_grace_s=2"])
    ok = s.until(lambda S: S["tasks"]["SA"].get("verdict") == "not_on_gpu", 20)
    ok2 = s.until(lambda S: any(c["args"][0] == "send" for c in s.winlog()), 10)
    check("23a not_on_gpu → 告警发进 SA 的工作窗（不叫醒主窗）", ok and ok2 and not any(
        e.get("kind") == "not_on_gpu" for e in s.events() if e["event"] == "orch_alert"), s.winlog()[-2:])
    s.until(lambda S: S["tasks"]["DONEJ"]["status"] == "done", 15)
    inst = json.load(open(os.path.join(s.td, "notes", "sched", "config.json")))["instance"]
    used = set(s.task("SA").get("gpus", []))
    card = [c for c in "01234567" if c not in used][0]
    po = subprocess.Popen([PY, JOB, "60"], env=dict(s.env, ORCH_TASK="DONEJ", ORCH_INST=inst, CUDA_VISIBLE_DEVICES=card))
    ok = s.until(lambda S: any(k.startswith("orphan:") for k in S["alerts"]), 10)
    t0 = time.time()
    while time.time() - t0 < 15 and po.poll() is None:
        s.tick(1)
    check("23b 已结束任务的残留进程：宽限期后自动按标签收掉", ok and po.poll() is not None, po.poll())
    if po.poll() is None:
        po.kill()
    po.wait()
    s.close()

def t24_skip_runenv_csv():
    print("== 24 skip_if_cmd（现状已满足就不跑）、包自定义环境变量、卡时账 CSV")
    s = Sim([job("ENVOK", 0, kind="cpu-agent", skip_if_cmd="true"), job("ENVNO", 0, kind="cpu-agent", skip_if_cmd="false"),
             job("RE", 0.5, {"1": 0.001})], top={"run_env": {"MYPKG_TASK": "{ID}@{INST}", "MYPKG_LEASE": "external"}})
    s.tick(2)
    check("24a skip_if_cmd 退 0 → 直接完成", s.task("ENVOK")["status"] == "done" and "skip_if_cmd" in s.task("ENVOK")["reason"],
          s.task("ENVOK"))
    check("24b skip_if_cmd 退非 0 → 照常就绪", s.task("ENVNO")["status"] in ("ready", "running"), s.task("ENVNO"))
    spec = json.load(open(os.path.join(s.task("RE")["run_dir"], "spec.json")))
    inst = json.load(open(os.path.join(s.td, "notes", "sched", "config.json")))["instance"]
    check("24c manifest 的 run_env 进了运行环境（占位符已替换），skill 本身不带任何包的变量名",
          spec["env"].get("MYPKG_TASK") == "RE@" + inst and spec["env"].get("MYPKG_LEASE") == "external"
          and "OPD_GPU_LEASE" not in spec["env"], spec["env"])
    s.until(lambda S: S["tasks"]["RE"]["status"] == "done", 15)
    out = os.path.join(s.root, "u.csv")
    r = s.run("util", "--td", s.td, "--csv", out)
    check("24d util --csv 导出卡时账", r.returncode == 0 and open(out).readline().startswith("section,hour,gpu"), r.stdout)
    s.close()
    s = Sim([job("SLOWCHK", 0, kind="cpu-agent", skip_if_cmd="sleep 30", skip_if_timeout_s=2), job("OTHER", 3, {"1": None})])
    t0 = time.time()
    s.run("tick", "--td", s.td)
    dt = time.time() - t0
    check("24e 慢的 skip_if_cmd 在后台跑：这一轮不卡住守护，别的任务照常发卡", dt < 2 and s.task("OTHER")["status"] == "running"
          and "检查现状中" in s.task("SLOWCHK").get("why", ""), (dt, s.task("SLOWCHK")))
    ok = s.until(lambda S: S["tasks"]["SLOWCHK"].get("skip_checked"), 10)
    check("24f skip_if_cmd 超时 → 当作“现状不满足”，照常就绪", ok and s.task("SLOWCHK")["skip_check"]["rc"] == 124
          and s.task("SLOWCHK")["status"] in ("ready", "running"), s.task("SLOWCHK"))
    s.close()


def t25_priority_no_estimates():
    print("== 25 不用预计时长：同优先级先放长链的头；没写值时卡多的档优先；严格档位")
    items = [job("SHORTCHAIN", 2, {"1": None}), job("SC1", 0.2, {"1": None}, deps=["SHORTCHAIN"]),
             job("LONGCHAIN", 2, {"1": None}), job("LC1", 0.2, kind="cpu-job", deps=["LONGCHAIN"]),
             job("LC2", 0.2, kind="cpu-job", deps=["LC1"])]
    s = Sim(items, n=1)
    s.tick(1)
    st = s.st()["tasks"]
    check("25a 下游个数相同时，下游链更长的 LONGCHAIN 先上唯一的卡", st["LONGCHAIN"]["status"] == "running"
          and st["SHORTCHAIN"]["status"] == "ready", (st["LONGCHAIN"], st["SHORTCHAIN"]))
    s.close()
    s = Sim([job("BIG", 2, {"8": None, "4": None, "2": None}), job("STRICT", 2, {"4": None, "2": None}, strict_tier=True)], n=6)
    s.tick(1)
    st = s.st()["tasks"]
    check("25b 没写偏好值：放得下的最大档（6 张卡里给 BIG 4 张）", len(st["BIG"].get("gpus", [])) == 4, st["BIG"])
    check("25c strict_tier：只认首选档，余 2 张也不降档", st["STRICT"]["status"] == "ready", st["STRICT"])
    s.close()
    # 有下游链的被挡任务马上保护：低优先级任务不能占它要的卡（不然它要等那个任务跑完，后面整条链都晚）
    items = [job("LONG", 4, {"1": None}, prio_boost=5), job("BIG", 1, {"2": None}, strict_tier=True),
             job("NEXT", 0.2, kind="cpu-job", deps=["BIG"]), job("SMALL", 1, {"1": None}, prio_boost=-1)]
    s = Sim(items, n=2)
    s.tick(2)
    st = s.st()["tasks"]
    check("25d 有下游链的 BIG 被挡 → 马上启动保护：低优先级的 SMALL 不占它要的卡", st["LONG"]["status"] == "running"
          and st["SMALL"]["status"] == "ready" and "启动保护" in st["SMALL"].get("why", ""), (st["BIG"], st["SMALL"]))
    ok = s.until(lambda S: S["tasks"]["BIG"]["status"] in ("running", "done"), 20)
    check("25e LONG 一结束 BIG 立刻起跑（先于 SMALL）", ok and s.task("SMALL")["status"] in ("ready", "wait"), (s.task("BIG"), s.task("SMALL")))
    s.close()
    # 叶子任务（没有任务依赖它）被挡时不马上保护：空卡先给放得下的任务
    items = [job("LONG", 4, {"1": None}, prio_boost=5), job("BIGLEAF", 1, {"2": None}, strict_tier=True),
             job("SMALL", 1, {"1": None}, prio_boost=-1)]
    s = Sim(items, n=2)
    s.tick(2)
    st = s.st()["tasks"]
    check("25f 叶子任务被挡：不马上保护，空卡给放得下的 SMALL（不让卡白空着）", st["SMALL"]["status"] in ("running", "done")
          and st["BIGLEAF"]["status"] == "ready", (st["BIGLEAF"], st["SMALL"]))
    s.close()

def t26_start_confirmation():
    print("== 26 启动确认：进程真起 + 持续占用 + 实验真开始；启动开销单独记；启动阶段失败单独标")
    items = [
        job("MARK", 8, {"1": None}, extra="--util 0 --mark-after 1.5", started_if=["{RUN_DIR}/never"], partition="A"),
        job("LOGRX", 8, {"1": None}, extra="--util 0", started_log="fake job on", partition="A"),
        job("BUSY", 8, {"1": None}, partition="A"),
        job("EARLYFAIL", 0.3, {"1": None}, extra="--rc 3", partition="B"),
        job("CPUJ", 3, kind="cpu-job"),
    ]
    s = Sim(items, sets=["start_hold_s=1"])
    s.tick(1)
    st = s.st()["tasks"]
    check("26a 刚派发：还没确认真开始，看得到卡在哪一步", not st["BUSY"].get("confirmed_t") and "启动中" in st["BUSY"].get("start_stage", ""),
          st["BUSY"])
    ok = s.until(lambda S: S["tasks"]["MARK"].get("confirmed_t"), 12)
    check("26b 任务写了开始标志 $ORCH_STARTED（利用率 0 也算真开始）", ok and "开始标志" in s.task("MARK").get("start_ev", ""), s.task("MARK"))
    ok = s.until(lambda S: S["tasks"]["LOGRX"].get("confirmed_t"), 12)
    check("26c 日志出现 started_log 的正则 → 真开始", ok and "日志" in s.task("LOGRX").get("start_ev", ""), s.task("LOGRX"))
    ok = s.until(lambda S: S["tasks"]["BUSY"].get("confirmed_t"), 12)
    b = s.task("BUSY")
    check("26d 什么都没声明：持续计算满 start_hold_s → 真开始，记下启动用时", ok and "持续计算" in b.get("start_ev", "")
          and b.get("startup_s") is not None and b["startup_s"] >= 1, b)
    ok = s.until(lambda S: S["tasks"]["EARLYFAIL"]["status"] == "failed", 12)
    check("26e 还没真开始就退出 → 标“启动阶段失败”", ok and "启动阶段失败" in s.task("EARLYFAIL").get("reason", ""), s.task("EARLYFAIL"))
    ok = s.until(lambda S: S["tasks"]["CPUJ"].get("confirmed_t") or S["tasks"]["CPUJ"]["status"] == "done", 10)
    check("26f CPU job：进程持续在跑也做启动确认", ok and s.task("CPUJ").get("start_ev") == "进程持续在跑", s.task("CPUJ"))
    acc = s.st()["acct"]
    check("26g 卡时账把启动开销单独记（startup_s），真开始后才记真在用", acc.get("startup_s", 0) > 0 and acc.get("used_s", 0) > 0, acc)
    check("26g2 刚分出去的卡不算“别人占用”（这台假机器上没有别人）", acc.get("other_s", 0) == 0, acc)
    facts = [f for f in s.facts() if f["type"] == "task_set" and "真开始" in f.get("备注", "")]
    check("26h 事实流记下每个任务的真开始与启动用时", len(facts) >= 3, facts[:2])
    r = s.run("health", "--td", s.td)
    check("26i 巡检显示启动用时与启动开销", "启动开销" in r.stdout and "启动用时" in r.stdout, r.stdout)
    s.close()


def t27_runtime_changes():
    print("== 27 运行中改计划：不可执行就放弃、发现缺前序就加任务加依赖、改优先级与档位、停用坏卡")
    items = [job("ROOT", 30, {"1": None}), job("NEED", 1, {"1": None}, deps=["ROOT"]), job("AFTERJ", 0.2, kind="cpu-job", after=["ROOT"]),
             job("OPT", 0.2, kind="cpu-job", deps=["ROOT"], deps_optional=["ROOT"]), job("LOW", 1, {"1": None}),
             job("HIGH", 1, {"1": None})]
    s = Sim(items, n=2)
    s.tick(1)
    r = s.run("drop", "--td", s.td, "ROOT", "--reason", "x")
    check("27a 在跑的任务不能直接 drop（先 kill）", r.returncode == 1 and "kill" in r.stderr, r.stderr)
    s.run("kill", "--td", s.td, "ROOT", "--grace", "1")
    s.tick(2)
    r = s.run("drop", "--td", s.td, "ROOT", "--reason", "环境缺依赖、确实跑不了")
    s.tick(3)
    st = s.st()["tasks"]
    check("27b drop：任务记为跳过，严格依赖它的 NEED 随之跳过", r.returncode == 0 and st["ROOT"]["status"] == "skipped"
          and st["NEED"]["status"] == "skipped", (r.stdout, st["ROOT"], st["NEED"]))
    check("27c after 依赖与 deps_optional 照常放行", st["AFTERJ"]["status"] in ("running", "done") and st["OPT"]["status"] in ("running", "done"),
          (st["AFTERJ"], st["OPT"]))
    dec = open(os.path.join(s.td, "notes", "decisions.md"), encoding="utf-8").read()
    check("27d 每次改动写进 decisions.md（含理由）", "确实跑不了" in dec, dec[-300:])
    s.close()
    s = Sim([job("A", 30, {"1": None}), job("B", 1, {"1": None}), job("C", 1, {"1": None})], n=1)
    s.tick(1)
    r = s.run("add", "--td", s.td, "--json", json.dumps({"id": "PRE", "kind": "cpu-job", "cmd": "%s %s 0.2" % (PY, JOB)}),
              "--reason", "B 真跑时发现缺数据预处理")
    r2 = s.run("dep", "--td", s.td, "B", "--add", "PRE", "--reason", "B 要等预处理")
    r3 = s.run("dep", "--td", s.td, "PRE", "--add", "B", "--reason", "制造环")
    check("27e 发现缺前序：add 新任务 + dep 加依赖；会成环的改动被拒绝", r.returncode == 0 and r2.returncode == 0 and r3.returncode == 1,
          (r.stdout + r.stderr, r2.stdout + r2.stderr, r3.stderr))
    r = s.run("prio", "--td", s.td, "C", "--boost", "5", "--reason", "C 的结果决定下一步")
    s.run("kill", "--td", s.td, "A", "--grace", "1")
    s.tick(3)
    st = s.st()["tasks"]
    check("27f prio：C 的优先级提高后先拿到唯一的卡；B 在等新前序", r.returncode == 0 and st["C"]["status"] in ("running", "done")
          and st["B"]["status"] in ("wait", "ready") and st["PRE"]["status"] in ("running", "done"), (st["C"], st["B"], st["PRE"]))
    r = s.run("edit", "--td", s.td, "B", "--set", 'gpu_options={"2": null}', "--reason", "x")
    r2 = s.run("edit", "--td", s.td, "B", "--set", "cmd=rm -rf /", "--reason", "x")
    check("27g edit：可改字段才能改（cmd 之类不行）", r.returncode == 0 and r2.returncode == 2, (r.stdout, r2.stderr))
    s.close()
    s = Sim([job("J1", 20, {"1": None}), job("J2", 20, {"1": None})], n=2)
    r = s.run("cordon", "--td", s.td, "1", "--reason", "GPU1 报 XID")
    s.tick(2)
    st = s.st()
    check("27h cordon：停用的卡不再分出（另一个任务等卡）", r.returncode == 0 and sum(1 for t in st["tasks"].values() if t["status"] == "running") == 1
          and "1" not in sum((t.get("gpus", []) for t in st["tasks"].values()), []), st["tasks"])
    s.run("uncordon", "--td", s.td, "1", "--reason", "修好了")
    s.tick(2)
    check("27i uncordon 后照常分配", sum(1 for t in s.st()["tasks"].values() if t["status"] == "running") == 2, s.st()["tasks"])
    r = s.run("config", "--td", s.td, "--set", "max_windows=3", "--reason", "key 池只剩 4 把")
    check("27j config：运行中改守护设置", r.returncode == 0 and json.load(open(os.path.join(s.td, "notes", "sched", "config.json")))["max_windows"] == 3,
          r.stdout + r.stderr)
    s.close()


def t28_cellrun():
    print("== 28 cellrun：按租到的卡并行跑格；尾部用不上的卡还给调度；续跑跳过已完成；失败汇总；停止时一起停")
    tmp = tempfile.mkdtemp(prefix="cellrun-")
    cells = os.path.join(tmp, "cells.json")
    json.dump(["c%d" % i for i in range(5)], open(cells, "w"))
    cmd = "%s -I %s --cells %s -- %s %s 2" % (PY, CELLRUN, cells, PY, JOB)
    s = Sim([{"id": "GRID", "kind": "gpu-job", "deps": [], "cmd": cmd, "gpu_options": {"4": None}, "prio_boost": 1},
             job("WAITER", 2, {"1": None})], n=4)
    ok = s.until(lambda S: S["tasks"]["GRID"]["status"] in ("done", "failed"), 40)
    g, w = s.task("GRID"), s.task("WAITER")
    summ = json.load(open(os.path.join(g["run_dir"], "cells-summary.json")))
    check("28a 4 卡租约同时跑 4 格、5 格全部完成", ok and g["status"] == "done" and summ["done"] == 5 and summ["max_par"] == 4, summ)
    heads = [open(os.path.join(g["run_dir"], "cells", "c%d" % i, "console.log"), encoding="utf-8").readline() for i in range(4)]
    ports = {h.split("端口 ")[1].split("…")[0] for h in heads if "端口 " in h}
    check("28b 同时跑的格各有自己的端口小段", len(ports) == 4, heads)
    check("28c 网格尾部：用不上的卡还给 orchd，等卡的 WAITER 在网格结束前就开跑",
          g.get("released") and w.get("start_t", 1e18) < g.get("end_t", 0), (g.get("released"), w.get("start_t"), g.get("end_t")))
    env = dict(s.env, ORCH_TD=s.td, ORCH_TASK="GRID", ORCH_RUN_DIR=os.path.join(tmp, "again"))
    r = subprocess.run([PY, "-I", CELLRUN, "--cells", cells, "--gpus", "0,1", "--no-release", "--", PY, JOB, "30"],
                       capture_output=True, text=True, env=env, timeout=60)
    summ2 = json.load(open(os.path.join(tmp, "again", "cells-summary.json")))
    check("28d 续跑：已完成的格全部跳过（重试、抢占后不重做）", r.returncode == 0 and all(c["status"] == "done_before" for c in summ2["cells"]),
          r.stdout[-300:])
    s.close()
    env = dict(os.environ, FAKE_GPU_DIR=os.path.join(tmp, "fake"), ORCH_RUN_DIR=os.path.join(tmp, "fail"))
    os.makedirs(os.path.join(tmp, "fake", "apps"), exist_ok=True)
    r = subprocess.run([PY, "-I", CELLRUN, "--cells-json", json.dumps([{"id": "ok1", "rc": 0}, {"id": "bad", "rc": 3}]),
                        "--gpus", "0,1", "--state-dir", os.path.join(tmp, "st1"), "--", PY, JOB, "0.3", "--rc", "{rc}"],
                       capture_output=True, text=True, env=env, timeout=60)
    summ3 = json.load(open(os.path.join(tmp, "fail", "cells-summary.json")))
    check("28e 失败的格不挡别的格；结束退 1，汇总列出失败格", r.returncode == 1 and summ3["failed"] == ["bad"]
          and summ3["done"] == 1, (r.returncode, summ3))
    r = subprocess.run([PY, "-I", CELLRUN, "--cells-json", json.dumps([{"id": "big", "gpus": 4}]), "--gpus", "0,1",
                        "--state-dir", os.path.join(tmp, "st2"), "--", PY, JOB, "1"], capture_output=True, text=True, env=env, timeout=30)
    check("28f 格要的卡比租约多：一格不跑、退 2、写明怎么改", r.returncode == 2 and "gpu_options" in r.stderr, r.stderr)
    r = subprocess.run([PY, "-I", CELLRUN, "--cells-json", json.dumps(["a%d" % i for i in range(8)]), "--gpus", "0,1,2,3,4,5,6,7",
                        "--state-dir", os.path.join(tmp, "st3"), "--", PY, JOB, "1"], capture_output=True, text=True,
                       env=dict(env, ORCH_PORT_SPAN="100"), timeout=30)
    check("28g 端口段不够分给同时跑的格：退 2、提示调大 port_span", r.returncode == 2 and "port_span" in r.stderr, r.stderr)
    p = subprocess.Popen([PY, "-I", CELLRUN, "--cells-json", json.dumps(["l1", "l2"]), "--gpus", "0,1", "--grace", "3",
                          "--state-dir", os.path.join(tmp, "st4"), "--", PY, JOB, "60"], stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, env=dict(env, ORCH_RUN_DIR=os.path.join(tmp, "term")))
    time.sleep(2)
    p.send_signal(signal.SIGTERM)
    try:
        rc = p.wait(timeout=15)
    except subprocess.TimeoutExpired:
        p.kill()
        rc = None
    time.sleep(0.5)
    left = [f for f in os.listdir(os.path.join(tmp, "fake", "apps")) if os.path.exists("/proc/" + f.split("-")[0])]
    check("28h 收到 SIGTERM：在跑的格一起停、退 143、卡上不留进程", rc == 143 and not left, (rc, left))
    r = subprocess.run([PY, "-I", CELLRUN, "--cells-json", json.dumps(["s1"]), "--gpus", "0", "--state-dir", os.path.join(tmp, "st5"),
                        "--", PY, JOB, "1", "--child"], capture_output=True, text=True,
                       env=dict(env, ORCH_RUN_DIR=os.path.join(tmp, "child"), ORCH_RUN="RUN-X"), timeout=60)
    time.sleep(0.5)
    left = [f for f in os.listdir(os.path.join(tmp, "fake", "apps")) if os.path.exists("/proc/" + f.split("-")[0])]
    check("28i 一格结束后，它 setsid 出去的服务（带 ORCH_CELL 标签）也被收掉，下一格拿到干净的卡", r.returncode == 0 and not left,
          (r.returncode, left, r.stdout[-200:]))
    shutil.rmtree(tmp, ignore_errors=True)


def t29_fallback_and_plans():
    print("== 29 预先写好的预案：主方案失败成定局 → 备选接上；A|B 依赖；严格下游跳过；if_fail=accept/drop 不叫醒主窗")
    items = [job("MAIN", 0.2, {"1": None}, extra="--rc 2", if_fail="accept"),
             job("ALT", 0.3, {"1": None}, fallback_for="MAIN"),
             job("USE", 0.2, kind="cpu-job", deps=["MAIN|ALT"]),
             job("STRICT", 0.2, kind="cpu-job", deps=["MAIN"]),
             job("GOODM", 0.2, {"1": None}), job("ALT2", 0.2, {"1": None}, fallback_for="GOODM"),
             job("DROPME", 0.2, {"1": None}, extra="--rc 2", if_fail={"action": "drop", "note": "可选任务"}),
             job("AFTERD", 0.2, kind="cpu-job", deps=["DROPME"]), job("ALT3", 0.2, kind="cpu-job", fallback_for="DROPME")]
    s = Sim(items, auto=True, sets=["max_fix=0"])
    ok = s.until(lambda S: all(S["tasks"][x]["status"] in ("done", "skipped") for x in ("ALT", "USE", "STRICT", "ALT2", "AFTERD", "ALT3")), 40)
    st = s.st()["tasks"]
    check("29a 主方案失败、按 if_fail=accept 成定局 → 备选 ALT 跑完；USE（MAIN|ALT）用备选的结果跑完",
          ok and str(st["MAIN"].get("fix_assigned", "")).startswith("accepted") and st["ALT"]["status"] == "done" and st["USE"]["status"] == "done",
          {k: (v["status"], v.get("why", "")) for k, v in st.items()})
    check("29b 只认 MAIN 的严格下游 STRICT 跳过（不会永远等）", st["STRICT"]["status"] == "skipped", st["STRICT"])
    check("29c 主方案成功 → 它的备选 ALT2 跳过", st["GOODM"]["status"] == "done" and st["ALT2"]["status"] == "skipped", st["ALT2"])
    check("29d if_fail=drop：放弃，严格下游跳过，备选 ALT3 接上", st["DROPME"]["status"] == "skipped" and st["DROPME"].get("dropped")
          and st["AFTERD"]["status"] == "skipped" and st["ALT3"]["status"] == "done", (st["DROPME"], st["AFTERD"], st["ALT3"]))
    ev = s.events()
    check("29e 照预案处理：发 orch_result 告诉研究者，不发 fix_exhausted 叫主窗决定",
          sum(1 for e in ev if e["event"] == "orch_result" and "预案" in e.get("msg", "")) == 2
          and not any(e.get("kind") == "fix_exhausted" for e in ev), ev[-4:])
    s.close()
    root = tempfile.mkdtemp(prefix="orchd-bad-")
    man = os.path.join(root, "m.json")
    for bad in ([{"id": "A", "kind": "cpu-job", "deps": ["B"]}, {"id": "B", "kind": "cpu-job", "deps": ["A"]}],
                [{"id": "A", "kind": "cpu-job", "deps": ["X|NOPE"]}]):
        json.dump({"schema": "orch-manifest/2", "items": bad}, open(man, "w"))
        r = subprocess.run([PY, "-I", ORCHD, "init", "--td", os.path.join(root, "td%d" % len(bad[0]["deps"][0])), "--manifest", man,
                            "--lockdir", os.path.join(root, "l")], capture_output=True, text=True)
        check("29f init 拒绝%s" % ("依赖环" if len(bad) == 2 else "指向不存在任务的 A|B 依赖"), r.returncode == 2, r.stderr)
    shutil.rmtree(root, ignore_errors=True)


def t30_global_guards():
    print("== 30 全局保护：磁盘不足、主窗暂停 → 不启动新任务；掉卡告警；超过 max_h 告警（不自动停）")
    s = Sim([job("D1", 30, {"1": None}, max_h=0.0003), job("D2", 1, kind="cpu-job")], sets=["disk_min_gb=1000000000"])
    os.makedirs(os.path.join(s.root, "rt"), exist_ok=True)
    s.tick(2)
    st = s.st()
    check("30a 磁盘不足：GPU、CPU 任务都不启动，写明原因，告警叫醒主窗", all(t["status"] == "ready" and "暂停" in t.get("why", "")
          for t in st["tasks"].values()) and any(e.get("kind") == "disk" for e in s.events()), st["tasks"])
    s.run("config", "--td", s.td, "--set", "disk_min_gb=0", "--reason", "清理后")
    s.run("tick", "--td", s.td)
    st0 = s.st()
    st0["disk_t"] = 0
    json.dump(st0, open(os.path.join(s.td, "notes", "sched", "state.json"), "w"))
    s.tick(2)
    check("30b 余量恢复后照常启动", s.task("D1")["status"] == "running", s.task("D1"))
    ok = s.until(lambda S: any(k.startswith("overtime:") for k in S["alerts"]), 10)
    check("30c 超过 max_h：告警（任务照常在跑）", ok and s.task("D1")["status"] == "running", list(s.st()["alerts"]))
    s.env["FAKE_GPU_N"] = "7"
    s.tick(2)
    check("30d 掉卡：nvidia-smi 看到的卡变少 → gpu_lost 告警", "gpu_lost" in s.st()["alerts"], list(s.st()["alerts"]))
    s.env["FAKE_GPU_N"] = "8"
    s.close()
    s = Sim([job("P1", 1, {"1": None})])
    s.run("config", "--td", s.td, "--set", "paused=研究者要先看 v4a", "--reason", "研究者要求")
    s.tick(2)
    check("30e 主窗暂停：新任务不启动", s.task("P1")["status"] == "ready" and "主窗暂停" in s.task("P1").get("why", ""), s.task("P1"))
    s.run("config", "--td", s.td, "--set", "paused=", "--reason", "恢复")
    ok = s.until(lambda S: S["tasks"]["P1"]["status"] in ("running", "done"), 10)
    check("30f 取消暂停后照常启动", ok, s.task("P1"))
    s.close()


def t31_window_watch():
    print("== 31 子窗消失 → 保留租约、按恢复说明重开；再消失 → 判失败交修复；长时间没输出 → 提醒一次，再升级")
    bindir = tempfile.mkdtemp(prefix="orchd-bin-")
    os.symlink(TMUX, os.path.join(bindir, "tmux"))
    s = Sim([job("WA", 0, {"1": None}, kind="gpu-agent")], auto=True,
            sets=["session=fake", "win_check_s=1", "reserve_ttl_s=60", "win_idle_s=1000", "agent_idle_s=1000"])
    s.env["PATH"] = bindir + os.pathsep + s.env["PATH"]
    ok = s.until(lambda S: S.get("windows", {}).get("w-wa", {}).get("state") == "open" and S["tasks"]["WA"]["status"] == "running", 20)
    gp = s.task("WA").get("gpus")
    time.sleep(1.2)
    open(os.path.join(s.fake, "win_windows"), "w").write("")
    ok2 = s.until(lambda S: S["tasks"]["WA"].get("win_restarts") == 1 and S["windows"].get("w-wa", {}).get("state") == "open"
                  and S["tasks"]["WA"]["status"] == "running", 25)
    check("31a 工作窗消失 → 租约保留（同一张卡）、按恢复说明重开一次", ok and ok2 and s.task("WA").get("gpus") == gp,
          (s.task("WA"), s.st().get("windows")))
    time.sleep(1.2)
    open(os.path.join(s.fake, "win_windows"), "w").write("")
    ok3 = s.until(lambda S: S["tasks"]["WA"]["status"] == "failed" or S["tasks"]["WA"].get("fix_win"), 25)
    check("31b 再次消失 → 判失败，交修复窗", ok3 and "消失" in s.task("WA").get("reason", ""), s.task("WA"))
    s.close()
    s = Sim([job("IA", 0, kind="cpu-agent")], auto=True, sets=["session=fake", "win_check_s=1", "win_idle_s=2"])
    s.env["PATH"] = bindir + os.pathsep + s.env["PATH"]
    s.until(lambda S: S.get("windows", {}).get("w-ia", {}).get("state") == "open", 20)
    open(os.path.join(s.fake, "win_idle"), "w").write(str(int(time.time()) - 100))
    ok = s.until(lambda S: any(c["args"][:2] == ["send", "w-ia"] for c in s.winlog()), 15)
    ok2 = s.until(lambda S: any(e.get("kind") == "win_idle" for e in s.events()), 15)
    check("31c 子窗长时间没输出：先发一次提醒，下一个周期仍没动静才升级给主窗", ok and ok2, (s.winlog()[-2:], s.events()[-2:]))
    s.close()
    shutil.rmtree(bindir, ignore_errors=True)


def t32_judge_window():
    print("== 32 判断窗：主窗一条命令开窗（任务书自动生成）→ 交结论 → 叫醒主窗（附结论）→ 自动关窗")
    s = Sim([job("JA", 30, {"1": None})])
    r = s.run("judge", "--td", s.td, "stuck", "--question", "JA 的告警原文……要不要停掉重跑？", "--about", "JA")
    ok = s.until(lambda S: S.get("windows", {}).get("judge-stuck", {}).get("state") == "open", 15)
    b = open(os.path.join(s.td, "briefs", "judge-stuck.md"), encoding="utf-8").read()
    check("32a judge：自动生成判断窗任务书并开窗（自动派窗关着也行）", r.returncode == 0 and ok and "要判断的事" in b and "facts.py emit" in b, r.stdout + r.stderr)
    s.emit("report", id="judge-stuck", state="完成", window="fake:judge-stuck", summary="正常加载，建议 ack")
    ok = s.until(lambda S: S["windows"]["judge-stuck"]["state"] in ("closing", "closed"), 15)
    ev = [e for e in s.events() if e["event"] == "orch_result" and e.get("kind") == "judge"]
    check("32b 判断窗交了结论 → orch_result 叫醒主窗（带结论原文）、自动关窗", ok and ev and "建议 ack" in ev[-1]["msg"], ev)
    r = s.run("judge", "--td", s.td, "free", "--question", "空卡 3 张的原因？")
    check("32c 不针对单个任务的判断窗也能开", r.returncode == 0, r.stderr)
    s.close()


def hook(s, win, event, **kv):
    """模拟 1.7.0 的 orch_hook.py：每窗一个事件文件，一行一个事件。"""
    rec = {"ts": "x", "t": time.time(), "window": "fake:" + win, "event": event}
    rec.update(kv)
    d = os.path.join(s.td, "notes", "events")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "fake__%s.jsonl" % win), "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def fake_transcript(s, sid, nbytes):
    d = os.path.join(s.env["HOME"], ".claude", "projects", "-fake-workdir")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, sid + ".jsonl"), "w") as f:
        f.write("x" * nbytes)


def t33_priority_milestones():
    print("== 33 优先级表达依赖：里程碑（谁要这些结果）、有人在等的决定点优先、正加成向上游传")
    items = [job("PROBE", 1, {"1": None}), job("BIG", 1, {"1": None}), job("B1", 0.2, kind="cpu-job", deps=["BIG"]),
             job("B2", 0.2, kind="cpu-job", deps=["BIG"]), job("B3", 0.2, kind="cpu-job", deps=["B2"]),
             {"id": "M-DECIDE", "kind": "milestone", "deps": ["PROBE"], "waiting_human": True, "title": "研究者等它判门"},
             job("PRE", 1, {"1": None}), job("URGENT", 1, {"1": None}, deps=["PRE"], prio_boost=10), job("LEAF", 1, {"1": None})]
    s = Sim(items, n=1)
    s.tick(1)
    st = s.st()["tasks"]
    check("33a 喂给“有人在等”的里程碑的 PROBE 排第一（压过下游多的 BIG）", st["PROBE"]["status"] == "running"
          and st["PROBE"]["gpus"], {k: (v["status"], v.get("prio")) for k, v in st.items()})
    check("33b 正加成向上游传：URGENT 的前提 PRE 的优先级高于下游多的 BIG", st["PRE"].get("prio", 0) > st["BIG"].get("prio", 0),
          (st["PRE"].get("prio"), st["BIG"].get("prio")))
    check("33c 里程碑不占卡、不开窗，PROBE 一完成就自动记为完成", s.until(lambda S: S["tasks"]["M-DECIDE"]["status"] == "done", 15)
          and not s.task("M-DECIDE").get("gpus"), s.task("M-DECIDE"))
    ev = [e for e in s.events() if e.get("kind") == "milestone"]
    check("33d 里程碑达成写一条 notice（不叫醒主窗的那类）", ev and ev[0]["event"] == "orch_result", ev)
    s.close()
    root = tempfile.mkdtemp(prefix="orchd-bad-")
    json.dump({"schema": "orch-manifest/2", "items": [{"id": "M", "kind": "milestone", "deps": ["NOPE"]}]}, open(os.path.join(root, "m.json"), "w"))
    r = subprocess.run([PY, "-I", ORCHD, "init", "--td", os.path.join(root, "td"), "--manifest", os.path.join(root, "m.json"),
                        "--lockdir", os.path.join(root, "l")], capture_output=True, text=True)
    check("33e 里程碑的依赖也要存在（init 拒绝）", r.returncode == 2, r.stderr)
    shutil.rmtree(root, ignore_errors=True)


def t34_window_lifecycle():
    print("== 34 子窗的一生：开窗记会话号 → 交报告后等这一轮结束才关 → 重试时 resume 原会话；太长的会话改开新窗；追问用 reopen")
    s = Sim([job("LA", 0, kind="cpu-agent", title="分析")], auto=True, sets=["close_grace_s=30"])
    s.env["HOME"] = os.path.join(s.root, "home")
    ok = s.until(lambda S: S.get("windows", {}).get("w-la", {}).get("state") == "open", 15)
    sid = s.st()["windows"]["w-la"].get("session", "")
    check("34a 开窗时记下会话号（winctl 打印 session=）", ok and len(sid) == 36, s.st().get("windows"))
    s.emit("report", id="LA", state="完成", window="fake:w-la", evidence=s.td, summary="ok")
    s.tick(3)
    check("34b 交了报告、这一轮还没结束：先不关窗（子窗还在写上下文卡）", s.st()["windows"]["w-la"]["state"] == "open"
          and ["close", "w-la"] not in [c["args"][:2] for c in s.winlog()], s.st()["windows"]["w-la"])
    hook(s, "w-la", "Stop", session_id=sid)
    ok = s.until(lambda S: S["windows"]["w-la"]["state"] == "closed", 10)
    lst = s.task("LA").get("last_session")
    sess = [json.loads(x) for x in open(os.path.join(s.td, "notes", "sessions.jsonl"))]
    check("34c 这一轮结束（Stop）后才关窗；会话号记进任务与 notes/sessions.jsonl", ok and lst == sid
          and any(x["session"] == sid and x["op"] == "close" for x in sess), (lst, sess[-2:]))
    fake_transcript(s, sid, 3000)
    s.run("retry", "--td", s.td, "LA")
    ok = s.until(lambda S: S["tasks"]["LA"].get("win") and S["windows"].get("w-la", {}).get("state") == "open", 15)
    opens = [c["args"] for c in s.winlog() if c["args"][:2] == ["open", "w-la"]]
    check("34d 重试：新工作窗用 --resume 回到原会话，第一句话说明是第几次承接", ok and "--resume" in opens[-1]
          and opens[-1][opens[-1].index("--resume") + 1] == sid and "重新承接" in opens[-1][opens[-1].index("--msg") + 1], opens[-1])
    s.emit("report", id="LA", state="完成", window="fake:w-la", evidence=s.td, summary="ok2")
    hook(s, "w-la", "Stop", session_id=sid)
    s.until(lambda S: S["windows"]["w-la"]["state"] == "closed", 10)
    fake_transcript(s, sid, 3 * 200000)
    s.run("retry", "--td", s.td, "LA")
    ok = s.until(lambda S: S["windows"].get("w-la", {}).get("state") == "open" and len([c for c in s.winlog() if c["args"][:2] == ["open", "w-la"]]) == 3, 15)
    opens = [c["args"] for c in s.winlog() if c["args"][:2] == ["open", "w-la"]]
    check("34e 原会话估计超过 resume_max_tokens：改开新窗（靠上下文卡），不 resume", ok and "--resume" not in opens[-1], opens[-1])
    s.emit("report", id="LA", state="完成", window="fake:w-la", evidence=s.td, summary="ok3")
    hook(s, "w-la", "Stop")
    s.until(lambda S: S["windows"]["w-la"]["state"] == "closed", 10)
    sid2 = s.task("LA").get("last_session")
    fake_transcript(s, sid2, 2000)
    r = s.run("reopen", "--td", s.td, "LA", "--question", "第 3 步的数从哪来？")
    ok = s.until(lambda S: S.get("windows", {}).get("fu-la-1", {}).get("state") == "open", 15)
    fu = [c["args"] for c in s.winlog() if c["args"][:2] == ["open", "fu-la-1"]]
    check("34f reopen：做完的任务追问，用原会话开跟进窗", r.returncode == 0 and ok and "--resume" in fu[-1] and sid2 in fu[-1], (r.stdout, r.stderr, fu))
    s.emit("report", id="fu-la-1", state="完成", window="fake:fu-la-1", summary="来自 run.log 第 12 行")
    hook(s, "fu-la-1", "Stop")
    ok = s.until(lambda S: S["windows"]["fu-la-1"]["state"] == "closed", 10)
    ev = [e for e in s.events() if e.get("kind") == "followup"]
    check("34g 跟进窗交了回答：叫醒主窗（orch_result kind=followup，带原文）、关窗", ok and ev and "run.log" in ev[-1]["msg"], ev)
    s.close()


def t35_api_failures():
    print("== 35 子窗这一轮因接口失败中断：限流退避后催；key 失效换 key 回原会话；上下文超限开新窗；窗死了 resume")
    s = Sim([job("RA", 0, kind="cpu-agent"), job("RB", 0, kind="cpu-agent"), job("RC", 0, kind="cpu-agent")], auto=True,
            sets=["api_backoff_s=0.5", "max_api_retries=2"])
    s.env["HOME"] = os.path.join(s.root, "home")
    s.until(lambda S: all(S.get("windows", {}).get(w, {}).get("state") == "open" for w in ("w-ra", "w-rb", "w-rc")), 20)
    W = s.st()["windows"]
    for w in ("w-ra", "w-rb", "w-rc"):
        fake_transcript(s, W[w]["session"], 1000)
    hook(s, "w-ra", "StopFailure", error="rate_limit_error: 429 Too Many Requests", session_id=W["w-ra"]["session"])
    hook(s, "w-rb", "StopFailure", error="authentication_failed: invalid api key", session_id=W["w-rb"]["session"])
    hook(s, "w-rc", "StopFailure", error="prompt is too long: 230000 tokens > 200000 maximum", session_id=W["w-rc"]["session"])
    ok = s.until(lambda S: any(c["args"][:2] == ["send", "w-ra"] and "限流" in c["args"][2] for c in s.winlog()), 10)
    check("35a 限流：退避后给那扇窗发“接着做”（不叫醒主窗）", ok and not any(e.get("kind") == "api_failures" for e in s.events()), s.winlog()[-3:])
    ok = s.until(lambda S: len([c for c in s.winlog() if c["args"][:2] == ["open", "w-rb"]]) >= 2, 15)
    ob = [c["args"] for c in s.winlog() if c["args"][:2] == ["open", "w-rb"]][-1]
    check("35b key 失效：换一把 key、--resume 回原会话接着做", ok and "--resume" in ob and W["w-rb"]["session"] in ob, ob)
    ok = s.until(lambda S: len([c for c in s.winlog() if c["args"][:2] == ["open", "w-rc"]]) >= 2, 15)
    oc = [c["args"] for c in s.winlog() if c["args"][:2] == ["open", "w-rc"]][-1]
    check("35c 上下文超限：开新会话（不 resume：超限的会话 resume 仍会报错）", ok and "--resume" not in oc, oc)
    sid = s.st()["windows"]["w-ra"]["session"]
    for i in range(3):
        hook(s, "w-ra", "StopFailure", error="rate_limit 429", session_id=sid)
        s.tick(4, 0.4)
    ok = s.until(lambda S: any(e.get("kind") == "api_failures" for e in s.events()), 10)
    check("35d 同一扇窗连续限流超过 max_api_retries：升级给主窗", ok, [e for e in s.events() if e["event"] == "orch_alert"][-2:])
    s.close()
    bindir = tempfile.mkdtemp(prefix="orchd-bin-")
    os.symlink(TMUX, os.path.join(bindir, "tmux"))
    s = Sim([job("WR", 0, {"1": None}, kind="gpu-agent")], auto=True,
            sets=["session=fake", "win_check_s=1", "reserve_ttl_s=60", "win_idle_s=1000", "agent_idle_s=1000"])
    s.env["PATH"] = bindir + os.pathsep + s.env["PATH"]
    s.env["HOME"] = os.path.join(s.root, "home")
    s.until(lambda S: S.get("windows", {}).get("w-wr", {}).get("state") == "open" and S["tasks"]["WR"]["status"] == "running", 20)
    sid = s.st()["windows"]["w-wr"]["session"]
    fake_transcript(s, sid, 1000)
    time.sleep(1.2)
    open(os.path.join(s.fake, "win_windows"), "w").write("")
    ok = s.until(lambda S: len([c for c in s.winlog() if c["args"][:2] == ["open", "w-wr"]]) >= 2
                 and S["tasks"]["WR"]["status"] == "running", 25)
    o = [c["args"] for c in s.winlog() if c["args"][:2] == ["open", "w-wr"]][-1]
    check("35e 工作窗意外消失：保留租约，用原会话 resume 重开（上下文不丢）", ok and "--resume" in o and sid in o and "意外" in o[o.index("--msg") + 1], o)
    s.close()
    shutil.rmtree(bindir, ignore_errors=True)


def t36_main_wait():
    print("== 36 主窗的等待：只在有事时醒来；结束与预案之类不叫醒、进摘要；同一件事不反复叫醒；守护停了会说")
    s = Sim([job("WQ", 0, kind="cpu-agent"), job("WJ", 30, {"1": None})], auto=True, sets=["heartbeat_stale_s=30"])
    s.tick(3)

    def wait(timeout=6, extra=()):
        return subprocess.run([PY, "-I", ORCHD, "wait", "--td", s.td, "--timeout", str(timeout), "--poll", "0.2", "--health-every", "0.3"]
                              + list(extra), capture_output=True, text=True, env=s.env, timeout=60)
    r = wait(3)
    check("36a 开工后的第一轮：没有要处理的事 → 定时汇报（退 3），只有几行", r.returncode == 3 and len(r.stdout.splitlines()) <= 6, r.stdout)
    s.run("gate", "--td", s.td, "BW", "pass")
    s.run("ask", "--td", s.td, "WQ", "--question", "用 A 还是 B？推荐 A")
    s.tick(2)
    r = wait(10)
    check("36b 子窗要研究者决定 → 立刻醒来（退 0），原话带出来；门控结论只进摘要", r.returncode == 0 and "用 A 还是 B" in r.stdout
          and "需要研究者决定" in r.stdout and "门 BW = pass" in r.stdout and "[结果就绪] 门" not in r.stdout, r.stdout)
    r = wait(2)
    check("36c 同一件事没处理完：不在 wait_realert_s 之内反复叫醒", r.returncode == 3, r.stdout)
    s.run("config", "--td", s.td, "--set", "wait_realert_s=0.5", "--reason", "测试")
    time.sleep(0.6)
    s.tick(1)
    r = wait(5)
    check("36d 过了 wait_realert_s 还没处理：再叫醒一次（退 1，写明是哪件事）", r.returncode == 1 and "用 A 还是 B" in r.stdout, r.stdout)
    s.run("config", "--td", s.td, "--set", "heartbeat_stale_s=0.1", "--reason", "测试")
    time.sleep(0.5)
    r = wait(5)
    check("36e 守护心跳过期：醒来（退 2）并写明怎么重起", r.returncode == 2 and "1.4" in r.stdout, r.stdout)
    s.close()


def t37_imminent_hold():
    print("== 37 马上就绪的高优先级任务先留卡：低优先级的大任务不能趁门控判定的那几秒把整机占了；留卡有时限")
    items = [{"id": "M-H", "kind": "milestone", "deps": ["PROBE"], "waiting_human": True},
             job("DEC", 1.5, kind="cpu-job"), job("PROBE", 1, {"1": None}, after=["DEC"]), job("BIGLOW", 1, {"2": None}, strict_tier=True)]
    s = Sim(items, n=2)
    s.tick(1)
    st = s.st()["tasks"]
    check("37a 判定步骤 DEC 在跑、PROBE 马上就绪：低优先级的 BIGLOW 先不占它要的卡", st["DEC"]["status"] == "running"
          and st["BIGLOW"]["status"] == "ready" and "留卡" in json.dumps(s.st().get("snapshot", {}), ensure_ascii=False), (st["BIGLOW"], s.st().get("hold")))
    ok = s.until(lambda S: S["tasks"]["PROBE"]["status"] in ("running", "done"), 15)
    order = s.task("BIGLOW").get("start_t") or 1e18
    check("37b DEC 一结束 PROBE 先起跑，BIGLOW 排在它后面", ok and order >= s.task("PROBE")["start_t"], (s.task("PROBE"), s.task("BIGLOW")))
    s.close()
    items = [{"id": "M-H", "kind": "milestone", "deps": ["PROBE"], "waiting_human": True},
             job("DEC", 30, kind="cpu-job"), job("PROBE", 1, {"1": None}, after=["DEC"]), job("BIGLOW", 1, {"2": None}, strict_tier=True)]
    s = Sim(items, n=2, sets=["imminent_hold_s=1"])
    ok = s.until(lambda S: S["tasks"]["BIGLOW"]["status"] in ("running", "done"), 15)
    check("37c 前序的 CPU 步骤跑得久（超过 imminent_hold_s）：不再留卡，卡给放得下的任务", ok and s.task("DEC")["status"] == "running",
          s.task("BIGLOW"))
    s.close()
    # 门控两支：结论出来前不知道放行哪一支，令牌按最严的一支留（串行那支要 hostbw:x，共享 hostbw 的低优先级任务先别进来）
    gate_cmd = "%s -I %s gate --td {TD} G fail" % (PY, ORCHD)
    items = [{"id": "M-H", "kind": "milestone", "deps": ["PA|PS"], "waiting_human": True},
             {"id": "DEC", "kind": "cpu-job", "deps": [], "cmd": "sleep 1.5; " + gate_cmd},
             job("PA", 1, {"1": None}, after=["DEC"], gate={"G": "pass"}, res={"hostbw": "s"}),
             job("PS", 1, {"1": None}, after=["DEC"], gate={"G": "fail"}, res={"hostbw": "x"}),
             job("SHARE", 4, {"1": None}, res={"hostbw": "s"})]
    s = Sim(items, n=4)
    s.tick(1)
    check("37d 门控两支都马上就绪：按最严的令牌留（hostbw:x），共享主机带宽的低优先级任务先不进来",
          s.task("SHARE")["status"] == "ready", (s.task("SHARE"), s.st().get("hold")))
    ok = s.until(lambda S: S["tasks"]["PS"]["status"] in ("running", "done"), 15)
    check("37e 结论是 fail：串行那支先跑，共享任务排在它后面", ok and (s.task("SHARE").get("start_t") or 1e18) >= s.task("PS")["start_t"],
          (s.task("PS"), s.task("SHARE")))
    s.close()


def t38_two_instances():
    print("== 38 同一台机器两套编排在同一秒跑同名任务：一边结束收尾时不会误杀另一边的进程（运行号带实例）")
    a = Sim([job("SAME", 1.5, {"1": None})])
    b = Sim([job("SAME", 6, {"1": None})])
    a.run("tick", "--td", a.td)
    b.run("tick", "--td", b.td)
    ra, rb = a.task("SAME").get("run", ""), b.task("SAME").get("run", "")
    check("38a 两边的运行号不同（带编排实例）", ra and rb and ra != rb, (ra, rb))
    ok = a.until(lambda S: S["tasks"]["SAME"]["status"] == "done", 15)
    b.tick(2)
    check("38b A 的任务结束收尾后，B 的同名任务还在跑", ok and b.task("SAME")["status"] == "running", b.task("SAME"))
    ok = b.until(lambda S: S["tasks"]["SAME"]["status"] in ("done", "failed"), 20)
    check("38c B 的任务照常跑完（退出码 0，不是被别人停的）", ok and b.task("SAME")["status"] == "done", b.task("SAME"))
    a.close()
    b.close()


def t9_tmux_launch():
    print("== 9 有 tmux 会话时，job 在 j-<任务> 窗里启动")
    import tempfile as _t
    bindir = _t.mkdtemp(prefix="orchd-bin-")
    os.symlink(TMUX, os.path.join(bindir, "tmux"))
    s = Sim([job("TM", 1, {"1": 0.001})], sets=["session=fake"])
    s.env["PATH"] = bindir + os.pathsep + s.env.get("PATH", "")
    ok = s.until(lambda S: S["tasks"]["TM"]["status"] == "done", 20)
    wins = open(os.path.join(s.fake, "tmux_windows")).read().split() if os.path.isfile(os.path.join(s.fake, "tmux_windows")) else []
    check("9a job 经 tmux new-window 启动（窗名 j-TM）并跑完", ok and wins == ["j-TM"] and s.task("TM")["window"] == "fake:j-TM",
          (wins, s.task("TM")))
    s.close()
    shutil.rmtree(bindir, ignore_errors=True)

def main():
    keep = "--keep" in sys.argv
    for f in (t1_priority_and_tiers, t2_exclusive_and_backfill, t3_verdicts, t4_kill_own_only, t5_gates,
              t6_agent_flow, t7_fail_retry_stale, t8_partition_and_foreign, t9_tmux_launch, t10_cpu_res,
              t11_smi_failure, t12_token_reservation, t13_tie_fewer_cards_and_env, t14_daemon_single,
              t15_retry_old_report, t16_orphan_untagged, t17_after_accept, t18_run_dir_done_check,
              t19_auto_task_window, t20_auto_fix_and_escalate, t21_retry_closes_fix, t22_attention_health_maxwin_failure,
              t23_send_and_orphan, t24_skip_runenv_csv, t25_priority_no_estimates, t26_start_confirmation,
              t27_runtime_changes, t28_cellrun, t29_fallback_and_plans, t30_global_guards, t31_window_watch,
              t32_judge_window, t33_priority_milestones, t34_window_lifecycle, t35_api_failures, t36_main_wait,
              t37_imminent_hold, t38_two_instances):
        try:
            f()
        except Exception as e:
            import traceback
            traceback.print_exc()
            check(f.__name__ + " 异常", False, repr(e))
    n = sum(1 for _, ok in results if ok)
    shutil.rmtree(_BIN, ignore_errors=True)
    print("ORCHD SIM %s %d/%d" % ("OK" if n == len(results) else "FAIL", n, len(results)))
    return 0 if n == len(results) else 1

if __name__ == "__main__":
    sys.exit(main())
