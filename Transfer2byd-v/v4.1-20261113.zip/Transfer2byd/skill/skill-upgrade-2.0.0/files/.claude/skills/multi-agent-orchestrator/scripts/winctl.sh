#!/usr/bin/env bash
# winctl.sh —— 子窗的一生：开窗(带任务书与上下文卡) → 承接任务 → 交报告 → 关窗收 key（skill 2.0.0）
#
# 用法:
#   winctl.sh open  <窗名> <任务书绝对路径> [--tier V_fast] [--task <任务ID> | --fix <失败任务ID>] [--ctx <上下文卡>]
#                   [--resume <会话号> [--msg <第一句话>]] [--dry-run]
#   winctl.sh close <窗名> [--force] [--dry-run]
#   winctl.sh send  <窗名> <文字> [--dry-run]       给一扇子窗发一句话（orchd 把用卡告警原文发给承接任务的窗）
#   winctl.sh list
#   winctl.sh help
#
# 配置：读 $ORCH_TD/notes/orch.env（init 时由 SKILL.md 第 0 步写好），至少要有
#   ORCH_SESSION  ORCH_TD  ORCH_SKILL_ROOT  ORCH_ADDONS  ORCH_WORKDIR  ORCH_KEYTOOL  ORCH_SETTINGS_FMT
#   ORCH_SETTINGS_FMT 例：@ORCH_HOME@/claude-presets/.run/window-%s.json（%s = 窗名）
#
# open 做的事（与 references/windows-and-keys.md 第三节手工步骤逐条对应，一次做完不漏步）:
#   1. 建 tmux 窗 → key_window.py prune + claim（每窗独立 key）
#   2. 启动 claude：带 5 个 ORCH_* 变量、--disallowedTools AskUserQuestion（R07）
#   3. 等 REPL 就绪（抓屏见到输入提示），再送“读任务书 + 上下文卡”的一句话，Enter，2 s 后补一个 Enter
#   4. winstate.py mark（R09）；写上下文卡头（窗名、任务、任务书、开窗时间、会话号）
#   5. 给了 --task 时：orchd.py start <任务> --window <会话:窗>（预留转在跑）
#   会话号：新开的窗用 claude --session-id <uuid> 指定（这一版的 claude 支持时），记进 notes/sched/win/<窗>.session；
#   --resume <会话号>：用 claude --resume 回到原会话（之前的对话都在），换一把新 key；第一句话用 --msg（没给就送任务书那句）。
#   最后一行打印 session=<会话号>（orchd 读它）。
# close 做的事：
#   1. 该窗承接的 orchd 任务还在 running/reserved 时拒绝（--force 跳过，用于确认已死的窗）
#   2. 优雅退出：送 /exit，等 claude 自己退出（最多 20 s；会话记录写完整），从屏上读 claude --resume <会话号> 那一行
#   3. 上下文卡追加“关窗”一行（含会话号与以后怎么接着用）
#   4. tmux kill-window → key_window.py release（收回 key）；打印 session=<会话号>
# 退出码：0 成功；1 前置条件不满足（被拒）；2 用法错；3 REPL 没就绪（窗已建，交主窗看屏）
set -uo pipefail

usage() { sed -n '2,30p' "$0"; }
cmd=${1:-help}; shift || true
case "$cmd" in help|-h|--help) usage; exit 0;; open|close|list|send) ;; *) echo "未知子命令 $cmd" >&2; usage >&2; exit 2;; esac

TD=${ORCH_TD:-}
[ -n "$TD" ] && [ -f "$TD/notes/orch.env" ] && . "$TD/notes/orch.env"
for v in ORCH_SESSION ORCH_TD ORCH_SKILL_ROOT ORCH_ADDONS ORCH_WORKDIR ORCH_KEYTOOL ORCH_SETTINGS_FMT; do
  if [ -z "${!v:-}" ]; then echo "缺配置 $v（先 export ORCH_TD=<任务目录>，并确认 \$ORCH_TD/notes/orch.env 已写好）" >&2; exit 2; fi
done
S=$ORCH_SESSION
ORCHD="python3 -I $ORCH_SKILL_ROOT/scripts/orchd.py"
DRY=0
run() { if [ "$DRY" = 1 ]; then printf '[dry-run] %s\n' "$*"; else eval "$@"; fi; }

if [ "$cmd" = list ]; then
  echo "== tmux 会话 $S 的窗："
  tmux list-windows -t "$S" -F '  #{window_name}  #{pane_current_command}' 2>/dev/null || echo "  （会话不存在）"
  echo "== orchd 在跑/预留的任务："
  $ORCHD status --td "$ORCH_TD" | grep -E 'running|reserved' || echo "  无"
  exit 0
fi

W=${1:-}; [ -n "$W" ] || { echo "缺窗名" >&2; exit 2; }; shift
if [ "$cmd" = send ]; then
  TEXT=${1:-}; [ -n "$TEXT" ] || { echo "缺要发的文字" >&2; exit 2; }; shift
  [ "${1:-}" = "--dry-run" ] && DRY=1
  tmux list-windows -t "$S" -F '#{window_name}' 2>/dev/null | grep -qx "$W" || { [ "$DRY" = 1 ] || { echo "窗 $W 不存在" >&2; exit 1; }; }
  run "tmux send-keys -t '$S:$W' Escape"
  run "sleep 0.3; tmux send-keys -t '$S:$W' C-u"
  run "tmux send-keys -t '$S:$W' $(printf %q "$TEXT") Enter"
  run "sleep 2; tmux send-keys -t '$S:$W' Enter"
  run "python3 -I '$ORCH_ADDONS/winstate.py' mark '$W' --events-dir '$ORCH_TD/notes/events' --session '$S'"
  echo "已发给 $S:$W"
  exit 0
fi
if [ "$cmd" = open ]; then
  BRIEF=${1:-}; [ -n "$BRIEF" ] || { echo "缺任务书路径" >&2; exit 2; }; shift
  TIER=V_fast; TASK=""; FIX=""; CTX="$ORCH_TD/notes/ctx/$W.md"; RESUME=""; FIRST=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --tier) TIER=${2:-V_fast}; shift 2;; --task) TASK=$2; shift 2;; --fix) FIX=$2; shift 2;; --ctx) CTX=$2; shift 2;;
      --resume) RESUME=$2; shift 2;; --msg) FIRST=$2; shift 2;;
      --dry-run) DRY=1; shift;; *) echo "未知参数 $1" >&2; exit 2;;
    esac
  done
  [ -n "$TIER" ] || TIER=V_fast
  [ -f "$BRIEF" ] || { echo "任务书不存在：$BRIEF" >&2; exit 1; }
  if tmux list-windows -t "$S" -F '#{window_name}' 2>/dev/null | grep -qx "$W"; then
    # 同名窗还在：多半是上一次承接后没关干净。先收 key 再关，再重开（任务的上下文卡保留，新窗接着做）
    echo "窗 $W 已存在：先关掉旧窗再重开（上下文卡保留）" >&2
    run "tmux kill-window -t '$S:$W' 2>/dev/null || true"
    run "python3 '$ORCH_KEYTOOL' release '$W' >/dev/null 2>&1 || true"
  fi
  if [ -n "$TASK" ]; then
    st=$($ORCHD status --td "$ORCH_TD" --json | python3 -c "import json,sys;print(json.load(sys.stdin)['tasks'].get('$TASK',{}).get('status',''))")
    case "$st" in reserved|ready|running) ;; *) echo "任务 $TASK 状态是 '$st'，不能开窗承接（GPU 任务要先等 orchd 预留）" >&2; exit 1;; esac
  fi
  SET=$(printf "$ORCH_SETTINGS_FMT" "$W")
  run "tmux has-session -t '$S' 2>/dev/null || tmux new-session -d -s '$S' -x 220 -y 50 -c '$ORCH_WORKDIR'"
  run "python3 '$ORCH_KEYTOOL' prune >/dev/null 2>&1 || true"
  run "tmux new-window -d -t '$S:' -n '$W' -c '$ORCH_WORKDIR'"
  run "python3 '$ORCH_KEYTOOL' claim '$W' '$TIER'"
  SID=""; SARG=""
  if [ -n "$RESUME" ]; then
    SID=$RESUME; SARG="--resume $RESUME"
  elif claude --help 2>/dev/null | grep -q -- '--session-id'; then
    SID=$(python3 -c 'import uuid; print(uuid.uuid4())'); SARG="--session-id $SID"
  fi
  mkdir -p "$ORCH_TD/notes/sched/win"
  [ -n "$SID" ] && [ "$DRY" = 0 ] && echo "$SID" > "$ORCH_TD/notes/sched/win/$W.session"
  LAUNCH="ORCH_ROLE=worker ORCH_TASK_DIR=$ORCH_TD ORCH_SKILL_ROOT=$ORCH_SKILL_ROOT ORCH_SESSION=$S ORCH_EVENTS_DIR=$ORCH_TD/notes/events ORCH_WINDOW=$S:$W ORCH_TD=$ORCH_TD ORCH_BIN=$ORCH_SKILL_ROOT/scripts/orchd.py claude $SARG --settings $SET --permission-mode bypassPermissions --disallowedTools AskUserQuestion"
  run "tmux send-keys -t '$S:$W' $(printf %q "$LAUNCH") Enter"
  if [ "$DRY" = 0 ]; then
    ok=0
    LIM=60; [ -n "$RESUME" ] && LIM=180                # 恢复长会话要先读回记录，给久一点
    for i in $(seq 1 $LIM); do
      sleep 1
      if tmux capture-pane -p -t "$S:$W" 2>/dev/null | grep -q '❯'; then ok=1; break; fi
    done
    if [ "$ok" = 0 ]; then echo "窗 $W 的 claude $LIM s 没见到输入提示：看屏（tmux capture-pane -p -t $S:$W）" >&2; exit 3; fi
  fi
  mkdir -p "$(dirname "$CTX")"
  if [ "$DRY" = 0 ] && [ ! -f "$CTX" ]; then
    printf '# 上下文卡：%s\n\n- 任务：%s\n- 任务书：%s\n- 开窗：%s\n- 会话：%s\n\n## 进展（只追加，每做完一步写一行：时间｜做了什么｜结果文件｜下一步）\n' \
      "$W" "${TASK:-无}" "$BRIEF" "$(date '+%F %T')" "${SID:-未记下}" > "$CTX"
  elif [ "$DRY" = 0 ] && [ -n "$RESUME" ]; then
    printf -- '- %s｜用原会话 %s 恢复（新 key）\n' "$(date '+%F %T')" "$RESUME" >> "$CTX"
  fi
  TID=${TASK:-${FIX:-}}
  if [ -n "$TID" ]; then
    GPUHINT="跑 GPU 命令只用：python3 -I \$ORCH_BIN exec --td \$ORCH_TD $TID -- <命令>（租到的卡与端口看 python3 -I \$ORCH_BIN env --td \$ORCH_TD $TID）；停进程只用 python3 -I \$ORCH_BIN kill --td \$ORCH_TD $TID。"
  else
    GPUHINT="本窗没有 GPU 租约，不跑任何 GPU 命令。"
  fi
  RECOV=""
  [ -s "$CTX" ] && [ "$(wc -l < "$CTX")" -gt 8 ] && RECOV="恢复说明：上下文卡里已有前一扇窗的进展——先核对结果目录与已做过的外部动作（启动过的运行、写过的事实），不要重复，再接着做。"
  MSG="请阅读 $BRIEF 并严格执行；先读上下文卡 $CTX，接着已有进展做，每完成一步在卡末追加一行。$RECOV$GPUHINT 不是你启动的进程一律不碰，看见可疑进程写进报告。遇决策默认选推荐项继续，绝不反问人工。"
  [ -n "$FIRST" ] && MSG="$FIRST（任务书 $BRIEF；上下文卡 $CTX）$GPUHINT"
  run "tmux send-keys -t '$S:$W' Escape"
  run "sleep 0.3; tmux send-keys -t '$S:$W' C-u"
  run "tmux send-keys -t '$S:$W' $(printf %q "$MSG") Enter"
  run "sleep 2; tmux send-keys -t '$S:$W' Enter"
  run "python3 -I '$ORCH_ADDONS/winstate.py' mark '$W' --events-dir '$ORCH_TD/notes/events' --session '$S'"
  [ -n "$TASK" ] && run "$ORCHD start --td '$ORCH_TD' '$TASK' --window '$S:$W'"
  [ -n "$FIX" ] && run "$ORCHD fixwin --td '$ORCH_TD' '$FIX' --window '$S:$W'"
  echo "已开窗 $S:$W（任务 ${TASK:-无}，上下文卡 $CTX${RESUME:+，接着原会话}）。20 s 后跑 winstate.py 复查是否已提交（R09）。"
  echo "session=${SID}"
  exit 0
fi

# close
FORCE=0
while [ $# -gt 0 ]; do case "$1" in --force) FORCE=1; shift;; --dry-run) DRY=1; shift;; *) echo "未知参数 $1" >&2; exit 2;; esac; done
busy=$($ORCHD status --td "$ORCH_TD" --json | python3 -c "
import json,sys
d=json.load(sys.stdin)['tasks']
print(' '.join(k for k,t in d.items() if t.get('status') in ('running','reserved') and str(t.get('window','')).endswith(':$W')))")
if [ -n "$busy" ] && [ "$FORCE" = 0 ]; then
  echo "拒绝关窗：$W 承接的任务还在跑：$busy（先让它 done/fail，或确认窗已死后加 --force）" >&2; exit 1
fi
CTX="$ORCH_TD/notes/ctx/$W.md"
SID=$(cat "$ORCH_TD/notes/sched/win/$W.session" 2>/dev/null)
if [ "$DRY" = 0 ] && tmux list-windows -t "$S" -F '#{window_name}' 2>/dev/null | grep -qx "$W"; then
  # 优雅退出：让 claude 自己退出（会话记录写完整、SessionEnd 照常触发），再收窗
  tmux send-keys -t "$S:$W" Escape; sleep 0.3; tmux send-keys -t "$S:$W" C-u
  tmux send-keys -t "$S:$W" "/exit" Enter
  for i in $(seq 1 20); do
    sleep 1
    c=$(tmux display-message -p -t "$S:$W" '#{pane_current_command}' 2>/dev/null)
    case "$c" in claude|node|"") ;; *) break;; esac
  done
  S2=$(tmux capture-pane -p -t "$S:$W" -S -80 2>/dev/null | grep -o 'claude --resume [0-9a-fA-F-]\{36\}' | tail -1 | awk '{print $3}')
  [ -n "$S2" ] && SID=$S2
fi
[ -f "$CTX" ] && [ "$DRY" = 0 ] && printf -- '- %s｜关窗；会话 %s（以后要用：orchd.py reopen <任务> --question …，或 winctl.sh open <新窗> <任务书> --resume %s）\n' \
  "$(date '+%F %T')" "${SID:-未记下}" "${SID:-<会话号>}" >> "$CTX"
run "tmux kill-window -t '$S:$W' 2>/dev/null || true"
run "python3 '$ORCH_KEYTOOL' release '$W'"
echo "已关窗 $W 并收回 key；上下文卡留在 $CTX；会话 ${SID:-未记下} 可以 resume。"
echo "session=${SID}"
exit 0
