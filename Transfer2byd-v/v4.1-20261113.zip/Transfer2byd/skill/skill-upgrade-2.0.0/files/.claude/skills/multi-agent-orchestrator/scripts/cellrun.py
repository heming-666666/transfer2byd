#!/usr/bin/env python3
"""cellrun —— 把一组互相独立的“格”按租到的卡并行跑（skill 2.0.0）。

研究者 2026-11-13：能并行做的实验，一定要写成 1、2、4、8 张卡都能跑的脚本，让调度占卡更灵活。
所以：租到 1 张卡就一格接一格跑；租到 4 张就同时跑 4 格（每格 1 卡）或 2 格（每格 2 卡）……；
剩下的格用不满租约时，把空出来的卡马上还给 orchd（orchd.py shrink），别的任务立刻用上，不在网格的尾巴上空等。

用法（在 orchd 启动的 gpu-job 里；或子窗里 `orchd.py exec --td … ID -- python3 -I …/cellrun.py …`）：
  python3 -I "$(dirname "$ORCH_BIN")/cellrun.py" (--cells 格.json | --cells-json '[…]')
      [--gpus-per-cell 1] [--max-par 0] [--done-cmd '命令 {cell}'] [--state-dir 目录] [--cell-retries 0]
      [--min-port-span 20] [--grace 20] [--release | --no-release] [--gpus 0,1] -- 命令模板 …

  格：JSON 列表；元素是格名（字符串）或对象 {"id": 格名, "gpus": 这一格要几张卡(可选), 其他键: 标量}。
      列表顺序就是先后（大格写在前面，免得小格先占散了卡）。
  命令模板的占位符：{cell} {gpus} {ngpu} {cell_dir} {k}（并发槽号），以及格对象里的任意标量键（例如 {conc}）。
  每一格的环境：
      CUDA_VISIBLE_DEVICES、ORCH_GPUS、ORCH_NGPU = 这一格的卡（卡号按 PCI 顺序，对齐的连续块优先）；
      ORCH_PORT_BASE、ORCH_PORT_SPAN = 本任务端口段里属于这一格的小段（同时跑的格不抢端口）；
      ORCH_TMP、RAY_TMPDIR = 这一格自己的临时目录；ORCH_RUN_DIR = <运行目录>/cells/<格>
      （这一格的 console.log、开始标志 ORCH_STARTED、进度 ORCH_PROGRESS 都在这里）；
      CELL_ID、CELL_DIR、CELL_JSON（整个格对象）、CELL_<键>（标量键，大写）、ORCH_CELL_SLOT、ORCH_CELL（进程标签）。
  一格结束后收掉它留下的进程（整个进程组 + 带 ORCH_CELL 标签的、自己 setsid 出去的服务），下一格拿到的是干净的卡。
  一格算完成：命令退 0（记 <state-dir>/<格>.done.json，下次跳过），或 --done-cmd 退 0（结果已在，不再跑）。
      state-dir 默认 $ORCH_TD/work/cells/$ORCH_TASK：跨重试、跨抢占不变，所以任务可以续跑。
  失败的格不挡别的格（可用 --cell-retries 自动重跑几次）；全部结束后有失败就退 1，全部完成退 0；
      <运行目录>/cells-summary.json 列出每一格的结果、卡、用时、日志。
  收到 SIGTERM / SIGINT（orchd kill、抢占）：把在跑的格一起停掉（先 TERM，--grace 秒后 KILL），退 143；已完成的格下次跳过。
  进度：每完成一格、或某格自己的 ORCH_PROGRESS 更新时，写任务级的 $ORCH_PROGRESS
      （step = 已完成格数，steps_total = 格数，cells_running = 在跑的格）；
      任一格写了自己的开始标志或第一格完成时 touch 任务级的 $ORCH_STARTED（orchd 的启动确认用）。
  还卡：只在 orchd 直接启动的 job 里默认打开（子窗 exec 里默认关，免得子窗后面的命令没卡用）；
      只还“剩下的格无论怎么排都用不上”的卡，还的是空着的卡，在跑的格不受影响。

退出码：0 全部完成；1 有格失败；2 用法或配置错（格要的卡比租约多、端口段不够分等，一格都没跑）；143 被停止。
计时类实验：同一任务里的格同时跑会互相干扰时，用 --max-par 1（或 manifest 只声明 1 卡档、带独占令牌）。
"""
import argparse
import json
import os
import re
import signal
import subprocess
import sys
import time


def now():
    return time.time()


def log(msg):
    print("%s cellrun: %s" % (time.strftime("%H:%M:%S"), msg), flush=True)


def write_json(p, obj):
    if not p:
        return
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    tmp = p + ".tmp.%d" % os.getpid()
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def safe(name):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", name)[:80] or "cell"


def load_cells(a):
    try:
        raw = json.loads(a.cells_json) if a.cells_json else json.load(open(a.cells, encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise SystemExit("读不出格列表：%r" % (e,))
    if not isinstance(raw, list):
        raise SystemExit("格列表要是 JSON 数组")
    cells = []
    for c in raw:
        if isinstance(c, str):
            c = {"id": c}
        if not isinstance(c, dict) or not c.get("id"):
            raise SystemExit("每一格要有 id：%r" % (c,))
        c = dict(c)
        c["id"] = str(c["id"])
        c["gpus"] = int(c.get("gpus", a.gpus_per_cell))
        cells.append(c)
    ids = [c["id"] for c in cells]
    dup = sorted({x for x in ids if ids.count(x) > 1})
    if dup:
        raise SystemExit("格名重复：%s" % dup)
    return cells


def fill(s, cell, cards, cell_dir, k):
    rep = {"{cell}": cell["id"], "{gpus}": ",".join(cards), "{ngpu}": str(len(cards)), "{cell_dir}": cell_dir, "{k}": str(k)}
    for key, v in cell.items():
        if isinstance(v, (str, int, float, bool)) and "{%s}" % key not in rep:
            rep["{%s}" % key] = str(v)
    for a_, b_ in rep.items():
        s = s.replace(a_, b_)
    return s


def pick(free, n):
    """从空着的卡里挑 n 张：先找对齐的连续块（0-1、2-3、0-3…，NVLink 上通常更近），没有就按卡号取前 n 张。"""
    ints = sorted(free, key=lambda x: int(x) if x.isdigit() else 10 ** 6)
    fs = set(ints)
    if n in (2, 4, 8) and all(x.isdigit() for x in ints):
        for st in range(0, max(int(x) for x in ints) + 1, n):
            blk = [str(i) for i in range(st, st + n)]
            if all(b in fs for b in blk):
                return blk
    return ints[:n]


def cell_pids(cid, run):
    """带这一格标签（ORCH_CELL=格、ORCH_RUN=本次运行）的进程：格自己 setsid 出去的服务（ray、推理服务）也能找到。"""
    out = []
    want = ("ORCH_CELL=%s" % cid).encode(), ("ORCH_RUN=%s" % run).encode()
    for d in os.listdir("/proc"):
        if not d.isdigit() or int(d) == os.getpid():
            continue
        try:
            env = open("/proc/%s/environ" % d, "rb").read().split(b"\0")
        except OSError:
            continue
        if want[0] in env and (not run or want[1] in env):
            out.append(int(d))
    return out


def cleanup_cell(p, cid, run, grace=3.0):
    """一格结束（或被停）后，收掉它留下的进程：先整个进程组，再按标签兜底；不碰别的格、别的任务。"""
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(p.pid, sig)
        except OSError:
            pass
        left = cell_pids(cid, run)
        for pid in left:
            try:
                os.kill(pid, sig)
            except OSError:
                pass
        t0 = now()
        while left and now() - t0 < grace:
            time.sleep(0.2)
            left = [x for x in left if os.path.exists("/proc/%d" % x)]
        if not left:
            return


def main(argv):
    if "--" not in argv:
        print(__doc__)
        return 2
    k = argv.index("--")
    opts, tmpl = argv[:k], argv[k + 1:]
    ap = argparse.ArgumentParser(prog="cellrun.py")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--cells", help="格列表 JSON 文件")
    g.add_argument("--cells-json", help="格列表 JSON 文本")
    ap.add_argument("--gpus-per-cell", type=int, default=1)
    ap.add_argument("--max-par", type=int, default=0, help="同时最多跑几格（0 = 卡够就跑）")
    ap.add_argument("--done-cmd", default="", help="退 0 表示这一格的结果已在（占位符同命令模板）")
    ap.add_argument("--state-dir", default="")
    ap.add_argument("--cell-retries", type=int, default=0)
    ap.add_argument("--min-port-span", type=int, default=20)
    ap.add_argument("--grace", type=float, default=20)
    ap.add_argument("--gpus", default="", help="覆盖 $ORCH_GPUS（手工试跑用）")
    rel = ap.add_mutually_exclusive_group()
    rel.add_argument("--release", dest="release", action="store_true", default=None)
    rel.add_argument("--no-release", dest="release", action="store_false")
    try:
        a = ap.parse_args(opts)
    except SystemExit:
        return 2
    if not tmpl:
        print("缺命令模板（-- 之后）", file=sys.stderr)
        return 2
    try:
        cells = load_cells(a)
    except SystemExit as e:
        print(e, file=sys.stderr)
        return 2
    lease = [c.strip() for c in (a.gpus or os.environ.get("ORCH_GPUS", "")).split(",") if c.strip()]
    cpu = not lease
    if not cpu:
        bad = [c for c in cells if c["gpus"] < 1 or c["gpus"] > len(lease)]
        if bad:
            print("格 %s 要 %s 张卡，租约只有 %d 张（%s）：manifest 的 gpu_options 最小档要不小于最大的一格" % (
                ",".join(c["id"] for c in bad), ",".join(str(c["gpus"]) for c in bad), len(lease), ",".join(lease)), file=sys.stderr)
            return 2
    run_dir = os.environ.get("ORCH_RUN_DIR") or os.path.abspath("cellrun-" + time.strftime("%Y%m%dT%H%M%S"))
    state_dir = a.state_dir or os.path.join(os.environ.get("ORCH_TD") or run_dir, "work", "cells",
                                            safe(os.environ.get("ORCH_TASK", "manual")))
    os.makedirs(state_dir, exist_ok=True)
    os.makedirs(run_dir, exist_ok=True)
    if cpu:
        cap = a.max_par or 1
    else:
        cap = len(lease) // min(c["gpus"] for c in cells) if cells else 1
        if a.max_par:
            cap = min(cap, a.max_par)
    cap = max(cap, 1)
    base = int(os.environ.get("ORCH_PORT_BASE", "21000") or 21000)
    span = int(os.environ.get("ORCH_PORT_SPAN", "200") or 200)
    sub = span // cap
    if sub < a.min_port_span:
        print("同时跑 %d 格时每格只分到 %d 个端口（本任务端口段 %d 个）：把 manifest 的 sched_defaults.port_span 调到 ≥ %d，"
              "或用 --max-par 限制并发" % (cap, sub, span, a.min_port_span * cap), file=sys.stderr)
        return 2
    tmp_root = os.environ.get("ORCH_TMP") or os.path.join(run_dir, "tmp")
    release = (not os.environ.get("ORCH_EXEC")) if a.release is None else a.release
    orchd_bin, td, task = os.environ.get("ORCH_BIN", ""), os.environ.get("ORCH_TD", ""), os.environ.get("ORCH_TASK", "")
    if release and not (orchd_bin and td and task):
        release = False
    task_prog, task_started = os.environ.get("ORCH_PROGRESS", ""), os.environ.get("ORCH_STARTED", "")

    def marker(c):
        return os.path.join(state_dir, safe(c["id"]) + ".done.json")

    summary = {c["id"]: {"id": c["id"], "gpus": c["gpus"], "status": "pending"} for c in cells}
    pending = []
    for c in cells:
        why = ""
        if os.path.exists(marker(c)):
            why = "上次已完成（%s）" % os.path.basename(marker(c))
        elif a.done_cmd:
            try:
                if subprocess.run(["bash", "-c", fill(a.done_cmd, c, [], "", 0)], timeout=120).returncode == 0:
                    why = "--done-cmd 判定结果已在"
            except (OSError, subprocess.TimeoutExpired):
                pass
        if why:
            summary[c["id"]].update(status="done_before", note=why)
            log("%s 跳过：%s" % (c["id"], why))
        else:
            pending.append(c)
    total = len(cells)
    free = list(lease)
    free_k = list(range(cap))
    running = {}
    tries = {}
    released = []
    stop = {"sig": None}
    marked = {"done": False}
    prog_sig = {}

    def on_term(signum, _frm):
        stop["sig"] = signum
    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)

    def n_done():
        return sum(1 for v in summary.values() if v["status"] in ("done", "done_before"))

    def write_progress():
        cell_steps = {}
        for cid, r in running.items():
            d = read_json(os.path.join(r["dir"], "progress.json"))
            if isinstance(d, dict) and "step" in d:
                cell_steps[cid] = [d.get("step"), d.get("steps_total")]
        write_json(task_prog, {"step": n_done(), "steps_total": total, "cells_running": sorted(running),
                               "cell_steps": cell_steps, "failed": sorted(k for k, v in summary.items() if v["status"] == "failed"),
                               "t": round(now(), 1)})

    def mark_started(why):
        if task_started and not marked["done"]:
            try:
                with open(task_started, "w") as f:
                    f.write(why + "\n")
                marked["done"] = True
                log("任务真开始：%s" % why)
            except OSError:
                pass

    def start(c, cards, k):
        cdir = os.path.join(run_dir, "cells", safe(c["id"]))
        os.makedirs(cdir, exist_ok=True)
        env = dict(os.environ)
        if not cpu:
            env.update(CUDA_VISIBLE_DEVICES=",".join(cards), ORCH_GPUS=",".join(cards), ORCH_NGPU=str(len(cards)))
        ctmp = os.path.join(tmp_root, "cell%d" % k)
        os.makedirs(os.path.join(ctmp, "ray"), exist_ok=True)
        env.update(ORCH_PORT_BASE=str(base + k * sub), ORCH_PORT_SPAN=str(sub), ORCH_TMP=ctmp,
                   RAY_TMPDIR=os.path.join(ctmp, "ray"), ORCH_RUN_DIR=cdir, ORCH_STARTED=os.path.join(cdir, ".started"),
                   ORCH_PROGRESS=os.path.join(cdir, "progress.json"), CELL_ID=c["id"], CELL_DIR=cdir,
                   CELL_JSON=json.dumps(c, ensure_ascii=False), ORCH_CELL_SLOT=str(k), ORCH_CELL=c["id"])
        for key, v in c.items():
            if isinstance(v, (str, int, float, bool)):
                env["CELL_" + re.sub(r"\W", "_", str(key)).upper()] = str(v)
        argv_c = [fill(x, c, cards, cdir, k) for x in tmpl]
        out = open(os.path.join(cdir, "console.log"), "ab")
        out.write(("== cellrun %s 开始 %s：卡 %s，端口 %d…%d，命令 %s\n" % (time.strftime("%F %T"), c["id"], ",".join(cards) or "-",
                   base + k * sub, base + (k + 1) * sub - 1, " ".join(argv_c))).encode("utf-8"))
        out.flush()
        try:
            p = subprocess.Popen(argv_c, stdout=out, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, env=env,
                                 start_new_session=True)
        except OSError as e:
            out.close()
            summary[c["id"]].update(status="failed", rc=127, note="起不来：%r" % (e,), log=os.path.join(cdir, "console.log"))
            log("%s 起不来：%r" % (c["id"], e))
            return False
        running[c["id"]] = {"p": p, "cards": cards, "k": k, "t0": now(), "dir": cdir, "out": out, "cell": c}
        summary[c["id"]].update(status="running", cards=cards, log=os.path.join(cdir, "console.log"))
        log("开始 %s：卡 %s（并发槽 %d，端口 %d 起 %d 个）" % (c["id"], ",".join(cards) or "-", k, base + k * sub, sub))
        return True

    def release_surplus():
        if not release or cpu or not free:
            return
        remaining = sorted([r["cell"]["gpus"] for r in running.values()] + [c["gpus"] for c in pending], reverse=True)
        usable = min(len(lease), sum(remaining[:cap]))
        in_use = sum(len(r["cards"]) for r in running.values())
        n = len(free) - max(0, usable - in_use)
        if n <= 0:
            return
        give = sorted(free, key=lambda x: -int(x) if x.isdigit() else 0)[:n]
        r = subprocess.run([sys.executable, "-I", orchd_bin, "shrink", "--td", td, task, "--gpus", ",".join(give),
                            "--reason", "cellrun：剩下的格用不上这些卡"], capture_output=True, text=True, timeout=60)
        if r.returncode == 0:
            for x in give:
                free.remove(x)
                lease.remove(x)
            released.append({"t": time.strftime("%F %T"), "gpus": give})
            log("还卡 %s 给 orchd（剩下的格最多同时用 %d 张）" % (",".join(give), usable))
        else:
            log("还卡失败（不再尝试）：%s" % (r.stdout + r.stderr).strip()[-200:])
            disable_release()

    def disable_release():
        nonlocal release
        release = False

    write_progress()
    log("共 %d 格（跳过已完成 %d），租约 %s，同时最多 %d 格，每格端口 %d 个%s" % (
        total, total - len(pending), ",".join(lease) or "（CPU）", cap, sub, "，用不上的卡会还给 orchd" if release else ""))
    while (pending or running) and stop["sig"] is None:
        launched = True
        while launched and pending and len(running) < cap and free_k and stop["sig"] is None:
            launched = False
            for c in list(pending):
                need = 0 if cpu else c["gpus"]
                if need <= len(free):
                    cards = pick(free, need) if need else []
                    for x in cards:
                        free.remove(x)
                    kk = free_k.pop(0)
                    pending.remove(c)
                    if not start(c, cards, kk):
                        free.extend(cards)
                        free_k.append(kk)
                    launched = True
                    break
        release_surplus()
        changed = False
        for cid, r in list(running.items()):
            if not marked["done"] and os.path.exists(os.path.join(r["dir"], ".started")):
                mark_started("格 %s 写了开始标志" % cid)
            try:
                st = os.stat(os.path.join(r["dir"], "progress.json"))
                sg = (st.st_mtime, st.st_size)
                if prog_sig.get(cid) != sg:
                    prog_sig[cid] = sg
                    changed = True
            except OSError:
                pass
            rc = r["p"].poll()
            if rc is None:
                continue
            r["out"].close()
            cleanup_cell(r["p"], cid, os.environ.get("ORCH_RUN", ""))     # 格留下的服务不能占着卡给下一格
            running.pop(cid)
            free.extend(r["cards"])
            free_k.append(r["k"])
            dur = round(now() - r["t0"], 1)
            if rc == 0:
                write_json(marker(r["cell"]), {"cell": cid, "rc": 0, "dur_s": dur, "cards": r["cards"], "end": time.strftime("%F %T")})
                summary[cid].update(status="done", rc=0, dur_s=dur)
                log("完成 %s（%.0f 秒）" % (cid, dur))
                mark_started("第一格 %s 已完成" % cid)
            else:
                tries[cid] = tries.get(cid, 0) + 1
                if tries[cid] <= a.cell_retries:
                    summary[cid].update(status="pending", rc=rc, note="第 %d 次失败，自动重跑" % tries[cid])
                    pending.insert(0, r["cell"])
                    log("%s 失败（rc %s），自动重跑第 %d 次" % (cid, rc, tries[cid]))
                else:
                    summary[cid].update(status="failed", rc=rc, dur_s=dur)
                    log("%s 失败（rc %s，%.0f 秒）：日志 %s" % (cid, rc, dur, summary[cid].get("log")))
            changed = True
        if changed:
            write_progress()
        time.sleep(0.5)
    if stop["sig"] is not None:
        log("收到信号 %s：停掉在跑的 %d 格（已完成的下次跳过）" % (stop["sig"], len(running)))
        for r in running.values():
            try:
                os.killpg(r["p"].pid, signal.SIGTERM)
            except OSError:
                pass
        t0 = now()
        while now() - t0 < a.grace and any(r["p"].poll() is None for r in running.values()):
            time.sleep(0.2)
        for cid, r in running.items():
            cleanup_cell(r["p"], cid, os.environ.get("ORCH_RUN", ""), grace=1.0)
            summary[cid].update(status="stopped")
    write_progress()
    res = {"total": total, "done": n_done(), "failed": sorted(k for k, v in summary.items() if v["status"] == "failed"),
           "lease": os.environ.get("ORCH_GPUS", a.gpus), "max_par": cap, "port_sub_span": sub, "released": released,
           "cells": [summary[c["id"]] for c in cells]}
    write_json(os.path.join(run_dir, "cells-summary.json"), res)
    if stop["sig"] is not None:
        return 143
    if res["failed"]:
        log("结束：%d/%d 格完成，失败 %s（cells-summary.json）" % (res["done"], total, ",".join(res["failed"])))
        return 1
    log("结束：%d/%d 格全部完成" % (res["done"], total))
    return 0


def read_json(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
