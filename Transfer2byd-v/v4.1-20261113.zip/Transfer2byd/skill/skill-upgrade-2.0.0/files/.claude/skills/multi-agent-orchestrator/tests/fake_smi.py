#!/usr/bin/env python3
"""测试用假 nvidia-smi：卡数由 FAKE_GPU_N 定（默认 8）；计算进程来自 $FAKE_GPU_DIR/apps/<pid>-<卡>，
内容 "uuid,mib,util"，进程不在了就不列。只认 orchd/gpu_lock 用到的两种查询。"""
import os, sys
d = os.environ["FAKE_GPU_DIR"]
if os.path.exists(os.path.join(d, "smi_fail")):      # 模拟 nvidia-smi 超时/出错
    sys.exit(9)
n = int(os.environ.get("FAKE_GPU_N", "8"))
apps = []
ad = os.path.join(d, "apps")
for fn in sorted(os.listdir(ad)) if os.path.isdir(ad) else []:
    pid = int(fn.split("-")[0])
    try:
        os.kill(pid, 0)
    except OSError:
        continue
    with open(os.path.join(ad, fn)) as f:
        uuid, mib, util = f.read().strip().split(",")
    apps.append((pid, uuid, int(mib), int(util)))
extra = {}
ep = os.path.join(d, "extra_mem")       # 模拟别的容器占的显存："卡号,MiB" 每行一条
if os.path.isfile(ep):
    for line in open(ep):
        if line.strip():
            g, m = line.split(","); extra[g.strip()] = int(m)
q = " ".join(sys.argv[1:])
if "query-gpu" in q:
    for i in range(n):
        u = "GPU-fake-%d" % i
        mine = [a for a in apps if a[1] == u]
        used = sum(a[2] for a in mine) + extra.get(str(i), 0)
        util = max([a[3] for a in mine] or [0])
        if "uuid" in q:
            print("%d, %s, %d, 81559, %d" % (i, u, used, util))
        else:
            print("%d, %d, %d, 30" % (i, used, util))
elif "query-compute-apps" in q:
    for pid, u, mib, util in apps:
        print("%d, %s, %d" % (pid, u, mib))
