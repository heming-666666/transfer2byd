#!/usr/bin/env python3
"""brief —— 由 orchd 的状态与任务包的 manifest 自动生成子窗任务书（skill 2.0.0）。

研究者 2026-11-13：实验包已经写好了任务之间的依赖与每个实验怎么做，主窗只掌控全局；所以任务书不用主窗写，
由本脚本照固定的几节拼出来（借鉴 DeepSeek Super-Agent：路由不改写请求、不加实现计划，执行者从原始来源取要求）：
  1 共同规则（不随任务变）  2 你的任务：原始来源（路线卡、manifest 条目）与完成标准  3 环境  4 交接

用法（orchd 自动调用；主窗手工开窗时也可以用）：
  brief.py task  --td <任务目录> --id <任务> --win <窗名> --out <文件>
  brief.py fix   --td <任务目录> --id <任务> --win <窗名> --out <文件> [--reason <失败原因或告警原文>]
  brief.py audit --td <任务目录> --id <任务> --win <窗名> --out <文件>
  brief.py judge --td <任务目录> --id <任务> --win <窗名> --out <文件> --reason <要判断的事>
  brief.py followup --td <任务目录> --id <任务> --win <窗名> --out <文件> --reason <研究者的追问>
manifest 顶层可选 `read_first`（字符串列表，包内相对路径）：每份任务书的“先读”都列上（如包的总览路线卡）。
退出码：0；2 用法错或任务不存在。
"""
import argparse
import json
import os
import sys
import time

SK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(p, d=None):
    try:
        return json.load(open(p, encoding="utf-8"))
    except (OSError, ValueError):
        return d


def orch_env(td):
    """读 notes/orch.env 里的路径（ORCH_ADDONS 等）；没有就返回空字典。"""
    out = {}
    try:
        for line in open(os.path.join(td, "notes", "orch.env"), encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"')
    except OSError:
        pass
    return out


def subst(s, cfg, run_dir=""):
    return (s.replace("{RUNTIME}", cfg.get("runtime", "")).replace("{PKG}", cfg.get("pkg", ""))
             .replace("{TD}", cfg.get("td", "")).replace("{RUN_DIR}", run_dir))


def common(cfg, env, tid, win):
    orchd = os.path.join(SK, "scripts", "orchd.py")
    fb = os.path.join(SK, "scripts", "skill_feedback.py")
    pkg_rules = [subst(x, cfg) for x in ((cfg.get("brief") or {}).get("rules") or [])]
    pr = ("\n## 1b 本任务包的规定（任务包写的，与上面冲突时以任务包为准，安全约束除外）\n\n" +
          "\n".join("- " + x for x in pkg_rules) + "\n") if pkg_rules else ""
    return pr_wrap(f"""## 1 共同规则（每扇子窗都一样，不随任务变）

- **只做本任务书写的这一件事。** 不开新窗、不给别的窗发消息、不派别的任务；需要主窗知道的写进交接（第 4 节）。
- **不问人**（本窗没有 AskUserQuestion）：遇决策选推荐项继续。确实要研究者拍板的一件事，用
  `python3 -I {orchd} ask --td {cfg['td']} {tid} --question "<一个具体问题，附两个选项与你的推荐>"`，然后先做不依赖它的部分。
- **GPU 只在租约内用**：GPU 命令一律 `python3 -I {orchd} exec --td {cfg['td']} {tid} -- <命令>`；租到哪几张卡、端口段与临时目录：
  `python3 -I {orchd} env --td {cfg['td']} {tid}`。不手设 `CUDA_VISIBLE_DEVICES`，不写死端口。
- **只动自己的进程**：停进程只用 `python3 -I {orchd} kill --td {cfg['td']} {tid}`（或包里的 `own_cleanup`）；不用 `ray stop`、`pkill`；
  看见不是你启动的进程（标签不是 `{tid}`）一律不碰，写进交接。
- **长命令放后台**：跑实验用 Bash 的 `run_in_background`，等它结束的通知，不要 `sleep` 轮询；每完成一步在上下文卡末尾追加一行
  「时间｜做了什么｜结果文件｜下一步」（上下文卡：`{cfg['td']}/notes/ctx/{win}.md`；窗被换掉时后继窗靠它接着做，开工先读它）。
- **上下文纪律**（子窗上下文有限，约 20 万 token 就会自动压缩）：日志只看 `tail -n 50`、`grep -n` 的结果，不 `cat` 整个日志或大文件；
  大段输出写进文件，只看摘要；上下文被压缩后（看到对话被总结），先重读本任务书与上下文卡再继续。
- **代码与参数只按任务包的规定改**（包没规定时：不改包里的脚本，参数只改路线卡点名的），每一处改动写进上下文卡与回传。
- **先冒烟再正式**：新脚本或改过的运行脚本先跑最小规模（1 步、几条数据）通过，再跑正式格。
- **不编造**：没测的写 `NA:原因`；估算标明“估算”。
- **弯路与 skill 问题**：花了 10 分钟以上的非实验问题写进交接的“给后来者的经验”；skill 本身的问题（脚本误判、规则不清）用
  `python3 -I {fb} add --td {cfg['td']} --kind bug|rule|gap|doc|perf --where <位置> --symptom "<现象原文>"`。
""", pr)


def pr_wrap(text, pkg_rules_block):
    return text + pkg_rules_block


def env_section(cfg, env, it, tid, win, t):
    lines = [f"## 3 环境", "",
             f"- 包根 `{cfg.get('pkg', '')}`（只读，环境变量 `ORCH_PKG`）；运行根 `{cfg.get('runtime', '')}`（`ORCH_RUNTIME`）；任务目录 `{cfg['td']}`（`ORCH_TD`）。"
             "包自己定义的环境变量（manifest 的 run_env）在 `orchd.py env` 的输出里。",
             f"- 本窗承接的任务 `{tid}`（种类 {it.get('kind')}），窗名 `{win}`。"]
    if it.get("kind", "").startswith("gpu"):
        lines.append(f"- 卡数档位 `{json.dumps(it.get('gpu_options'), ensure_ascii=False)}`；资源令牌 `{json.dumps(it.get('res') or {}, ensure_ascii=False)}`；"
                     f"本次租到 GPU `{','.join(t.get('gpus', [])) or '（开窗后看 env）'}`。计时类的“安静”由令牌保证，别的任务不会进来抢。")
    if env.get("ORCH_ADDONS"):
        lines.append(f"- 事实流工具 `{env['ORCH_ADDONS']}/facts.py`。")
    return "\n".join(lines) + "\n"


def handoff(cfg, env, tid, win, rid=None, kind="task"):
    facts = (env.get("ORCH_ADDONS", "<ADDONS>") + "/facts.py")
    rid = rid or tid
    extra = ""
    if kind == "task":
        extra = "orchd 看到“完成”就释放卡，等你这一轮结束后关窗，并自动开验收窗核对你的结果。"
    elif kind == "fix":
        extra = "orchd 看到你的报告，等你这一轮结束后关窗；任务若已 retry，它会照常重新分卡启动。"
    return f"""## 4 交接（做完或做不下去都要交；顺序不能反）

1. **先写上下文卡**：报告正文（`templates/WORKER_REPORT.md` 的格式）写进上下文卡末尾，必须有一节“给后来者的经验”
   （现象 → 根因 → 解法 → 下次怎么避免；没有写“无”）。
2. **最后一步才写事实**（写完这一条就结束这一轮，不要再做别的）：
   - 完成：`python3 -I {facts} emit --log {cfg['td']}/notes/facts.jsonl report id={rid} state=完成 window={win} evidence="<绝对路径1>;<绝对路径2>" summary="<≤600 字的结论：判据、上界、结果、证据在哪>"`。{extra}
   - 做不下去：同一条命令，`state=受阻`，`summary` 写已经排除了什么、卡在哪；需要研究者决定就再加 `attention="<一个具体问题，附选项与推荐>"`。
- 写不出真实的证据路径就不要报“完成”。
- 关窗不会丢东西：orchd 记下了本窗的会话号，以后要追问或重跑，会用 `claude --resume` 回到这个会话接着做。
"""


def scope_task(cfg, it, tid):
    src = it.get("source", "")
    man = load(os.path.join(cfg["td"], "notes", "sched", "queue.json"), {}) or {}
    b = cfg.get("brief") or {}
    rf = list(b.get("read_first") or (load(cfg.get("manifest", ""), {}) or {}).get("read_first", []))
    reads = [f"`{cfg.get('pkg', '')}/{x}`" for x in rf] + ([f"`{cfg.get('pkg', '')}/{src}`（本任务的路线卡：怎么做、判据、要交什么，**照原文做，不要自己加计划**）"] if src else [])
    di = [subst(x, cfg) for x in it.get("done_if", [])]
    keep = {k: it.get(k) for k in ("deps", "after", "gpu_options", "res", "done_if", "returns", "why", "warmup_s", "optional") if it.get(k) not in (None, [], {})}
    mh = it.get("max_h")
    return f"""## 2 你的任务：{tid} {it.get('title', '')}

先读（按顺序）：{'；'.join(reads) or '（manifest 没写路线卡：读任务包的入口说明）'}。

manifest 里本任务的条目（排程信息，已经由 orchd 执行，你不用再排）：
```json
{json.dumps(keep, ensure_ascii=False, indent=1)}
```

**完成的标准**：路线卡写的判据与要交的东西；结果放在{subst(b.get('results_hint', '路线卡规定的位置'), cfg).replace('{ID}', tid)}。
{('orchd 认的完成证据（都要写出来）：' + '；'.join('`' + x + '`' for x in di)) if di else ''}
{('**时间上限**：%s 小时（包写的 max_h；到时 orchd 告警）；到时还没结果就报“受阻”，写清现状。' % mh) if mh else '**没有固定时限**（调度不用预计时长）：按路线卡的判据推进；连续 30 分钟没有新进展、又说不清还差什么，就报“受阻”写清现状。'}
"""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("kind", choices=["task", "fix", "audit", "judge", "followup"])
    ap.add_argument("--td", required=True)
    ap.add_argument("--id", required=True)
    ap.add_argument("--win", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--reason", default="")
    a = ap.parse_args()
    sd = os.path.join(a.td, "notes", "sched")
    cfg = load(os.path.join(sd, "config.json"), {}) or {}
    queue = load(os.path.join(sd, "queue.json"), {}) or {}
    st = load(os.path.join(sd, "state.json"), {}) or {}
    items = {i["id"]: i for i in queue.get("items", [])}
    if not cfg or (a.id not in items and a.kind not in ("judge", "followup")):
        print("没有这个任务或还没 init：%s" % a.id, file=sys.stderr)
        return 2
    it, t = items.get(a.id, {"id": a.id, "title": "（不针对单个任务）"}), st.get("tasks", {}).get(a.id, {})
    env = orch_env(a.td)
    head = f"# 任务书：{a.win} / {a.id}（{ {'task': '执行', 'fix': '修复', 'audit': '验收', 'judge': '判断', 'followup': '跟进'}[a.kind] }窗，orchd 自动生成于 {time.strftime('%Y-%m-%d %H:%M')}）\n\n"
    if a.kind == "task":
        body = (f"> 你是子窗（执行者）。本窗只承接任务 `{a.id}`；技术上怎么做、怎么验证由你决定，主窗不会替你排障。\n\n"
                + common(cfg, env, a.id, a.win) + "\n" + scope_task(cfg, it, a.id) + "\n" + env_section(cfg, env, it, a.id, a.win, t)
                + "\n" + handoff(cfg, env, a.id, a.win))
    elif a.kind == "fix":
        rd = t.get("run_dir", "")
        runs = t.get("exec_runs") or []
        last = runs[-1]["dir"] if runs else rd
        rid = a.win
        body = (f"> 你是修复窗。任务 `{a.id}` 失败或出了用卡问题，你查明原因、修好后让 orchd 重新调度；修不好就照实报告。\n\n"
                + common(cfg, env, a.id, a.win)
                + f"""
## 2 要修的问题

- 原文：{a.reason or t.get('reason', '（看 orchd.py status）')}
- 任务 `{a.id}`（{it.get('title', '')}），路线卡 `{cfg.get('pkg', '')}/{it.get('source', '')}`；第 {t.get('attempt', 0)} 次运行。
- 证据：运行目录 `{last}`（`console.log`、`spec.json`、`exit.json`）；启动器写的 `run.log`、`progress.json` 在 `{cfg.get('runtime', '')}/results/` 下对应任务的目录。
- 怎么做：先读证据，按失败五分类（瞬时 / 资源冲突 / 确定性 / 环境权限 / 未知）定性，判断写进上下文卡。
  - 要在 GPU 上复现：`python3 -I {os.path.join(SK, 'scripts', 'orchd.py')} add --td {cfg['td']} --json '{{"id":"DBG-{a.id}-1","kind":"gpu-agent","gpu_options":{{"1":0.3}},"deps":[]}}'`，
    等 orchd 预留（会给本窗发消息），再 `exec DBG-{a.id}-1 -- <命令>`；用完 `done DBG-{a.id}-1`。
  - 修好：`python3 -I {os.path.join(SK, 'scripts', 'orchd.py')} retry --td {cfg['td']} {a.id}`（job 任务会被 orchd 重新分卡启动；agent 任务会重新开窗承接）。
  - 判断是正常现象（例如加载本来就要 20 分钟）：交接里写依据，并建议下一版 manifest 的默认值怎么改。
  - 失败两次以上、确属数据本身（例如某格 OOM 两次）：交接里建议主窗 `accept` 照实交。
- 时间上限 60 分钟。
"""
                + "\n" + env_section(cfg, env, it, a.id, a.win, t) + "\n" + handoff(cfg, env, a.id, a.win, rid=rid, kind="fix"))
    elif a.kind == "audit":
        facts = env.get("ORCH_ADDONS", "<ADDONS>") + "/facts.py"
        rep = (t.get("last_report") or {})
        body = (f"> 你是验收窗。独立核对任务 `{a.id}` 的结果：自己从磁盘重算，不信执行窗的自述。\n\n"
                + common(cfg, env, a.id, a.win)
                + f"""
## 2 要验收的

- 任务 `{a.id}`（{it.get('title', '')}），路线卡 `{cfg.get('pkg', '')}/{it.get('source', '')}`（判据与要交的东西以它为准）。
- 执行窗的结论：{rep.get('summary') or '（看事实流里该任务的 report）'}
- 必查：① 路线卡要交的文件都在、不为空；② 关键数字从原始文件重算（运行目录、`run.log`、`gpu.csv`、`progress.json`），与 00-summary 一致；
  ③ 判据先写了理论上界；④ 计时类任务：运行期间同机在跑什么（`{cfg['td']}/notes/sched/gpu.jsonl` 按时间查），与它的资源令牌是否相符；
  ⑤ 没有编造（NA 写了原因）；⑥ 失败的运行也在记录里。
- 结论写事实（必须写，orchd 靠它关窗）：
  `python3 -I {facts} emit --log {cfg['td']}/notes/facts.jsonl audit id={a.id} verdict=pass|fail evidence="<你核对用的文件;重算结果文件>"`
- fail 时把不一致的地方逐条写进上下文卡（文件、原值、重算值），主窗会决定重跑还是照实交。
""")
    elif a.kind == "followup":
        body = (f"> 你是跟进窗：任务 `{a.id}` 已经做完，研究者有一件后续的事要问或要补。能用原会话就接着原会话（orchd 已 resume），"
                f"不能就靠上下文卡与结果文件。只做这一件事，不跑 GPU、不改结果文件。\n\n"
                + common(cfg, env, a.id, a.win)
                + f"""
## 2 要做的事

{a.reason}

- 任务 `{a.id}`（{it.get('title', '')}）的上下文卡：`{cfg['td']}/notes/ctx/w-{a.id.lower()}.md`（文件名按窗名，找不到就 `ls {cfg['td']}/notes/ctx/`）；
  结果在{subst((cfg.get('brief') or {}).get('results_hint', '路线卡规定的位置'), cfg).replace('{ID}', a.id)}。
- 回答写进上下文卡末尾（结论、依据的文件与行），并执行
  `python3 -I {env.get('ORCH_ADDONS', '<ADDONS>')}/facts.py emit --log {cfg['td']}/notes/facts.jsonl report id={a.win} state=完成 window={a.win} summary="<回答，≤600 字>"`。
  orchd 看到这条就把回答原文转给主窗，并在你这一轮结束后关窗。
""")
    else:
        body = (f"> 你是判断窗：主窗把一件要判断的事交给你，你读证据、给结论与建议（≤ 10 行），主窗只看你的结论，不读细节。\n\n"
                + common(cfg, env, a.id, a.win)
                + f"""
## 2 要判断的事

{a.reason}

- 相关任务 `{a.id}`（{it.get('title', '')}）{('，路线卡 `%s/%s`' % (cfg.get('pkg', ''), it.get('source'))) if it.get('source') else ''}。
- 证据从 `orchd.py status --td {cfg['td']} --json`、上下文卡、运行目录里找；只读，不改任何东西、不跑实验。
- 交接：结论写进上下文卡末尾（≤ 10 行：结论、依据、建议的命令），并执行
  `python3 -I {env.get('ORCH_ADDONS', '<ADDONS>')}/facts.py emit --log {cfg['td']}/notes/facts.jsonl report id={a.win} state=完成 window={a.win} summary="<结论与建议的完整命令>"`。
  orchd 看到这条就把结论原文转给主窗并关窗；建议的命令写完整（例如 `orchd.py drop --td … 任务 --reason …`），主窗照着执行。
""")
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(head + body)
    print(a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
