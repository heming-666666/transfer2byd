#!/usr/bin/env python3
"""测试用假 winctl：记下每次调用；open --task 时替子窗做 orchd.py start，--fix 时做 fixwin。FAKE_WINCTL_RC 非 0 时模拟失败。
open 打印 session=<会话号>（--resume 时就是原会话号），close 打印记下的会话号，与真 winctl.sh 的输出约定一致。"""
import json, os, subprocess, sys, time, uuid
log = os.path.join(os.environ["FAKE_GPU_DIR"], "winctl.log")
args = sys.argv[1:]
rc = int(os.environ.get("FAKE_WINCTL_RC", "0"))
with open(log, "a") as f:
    f.write(json.dumps({"t": time.time(), "args": args, "rc": rc}) + "\n")
if rc:
    print("fake winctl 失败"); sys.exit(rc)
orchd = os.environ["FAKE_ORCHD"]; td = os.environ["ORCH_TD"]
wf = os.path.join(os.environ["FAKE_GPU_DIR"], "win_windows")
sd = os.path.join(td, "notes", "sched", "win")
def _wins():
    return [x for x in open(wf).read().split() if x] if os.path.exists(wf) else []
def opt(name):
    return args[args.index(name) + 1] if name in args else ""
if args and args[0] == "close":
    open(wf, "w").write("\n".join(w for w in _wins() if w != args[1]) + "\n")
    sid = open(os.path.join(sd, args[1] + ".session")).read().strip() if os.path.exists(os.path.join(sd, args[1] + ".session")) else ""
    print("ok"); print("session=" + sid); sys.exit(0)
if args and args[0] == "open":
    name, brief = args[1], args[2]
    assert os.path.exists(brief), brief
    open(wf, "w").write("\n".join([w for w in _wins() if w != name] + [name]) + "\n")
    sid = opt("--resume") or str(uuid.uuid4())
    os.makedirs(sd, exist_ok=True)
    open(os.path.join(sd, name + ".session"), "w").write(sid)
    if "--task" in args:
        subprocess.run([sys.executable, "-I", orchd, "start", "--td", td, opt("--task"), "--window", "fake:" + name], check=True)
    if "--fix" in args:
        subprocess.run([sys.executable, "-I", orchd, "fixwin", "--td", td, opt("--fix"), "--window", "fake:" + name], check=True)
    print("ok"); print("session=" + sid)
    sys.exit(0)
print("ok")
