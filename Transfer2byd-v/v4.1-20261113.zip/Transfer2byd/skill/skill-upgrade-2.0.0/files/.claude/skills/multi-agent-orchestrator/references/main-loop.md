# 主窗的开工与循环（R08、R22、R31 的逐条命令）

> 记号：
>
> | 记号 | 含义 |
> |---|---|
> | `TD` | 任务目录 |
> | `PKG` | 解压后的任务包根（只读） |
> | `RT` | 任务包的运行根（包规定的结果目录所在处） |
> | `S` | `@ORCH_HOME@/.claude/skills/multi-agent-orchestrator/scripts` |
> | `A` | `@ORCH_HOME@/skill/skill-addons/orch-v1/scripts` |
> | `SES` | tmux 会话名 |
>
> 命令照抄，只替换这几个记号。出了状况怎么办见 `references/manual.md` 第 6 节。

## 1 开工（只做一次；压缩恢复后不重做，见第 4 节）

```bash
# 1.1 版本校验：与调用 Prompt 第一节对不上就停下问研究者
cat $PKG/VERSION; head -40 $PKG/CHANGELOG.md
python3 -I $S/orchd.py help | head -2          # 第一行有 orchd；没有就是 skill 没升级到 2.0.0（照包里 skill/需要的skill版本.md 升级）

# 1.2 任务目录与配置。写了 notes/orch.env，orchd 就默认自动派窗（工作窗、修复窗、验收窗由它开关）
mkdir -p $TD/notes/events $TD/notes/ctx $TD/briefs $TD/output $TD/work
cp $S/../templates/orch.env $TD/notes/orch.env      # 按注释填：会话名、任务目录、工作目录、key 工具、settings 路径格式
cp $S/../templates/checks.json $TD/notes/checks.json # 把 <...> 换成真实路径

# 1.3 初始化：读包的 manifest，全部任务进事实流（task_add）
python3 -I $S/orchd.py init --td $TD --manifest $PKG/state/manifest.json --pkg $PKG --runtime $RT \
  --lockdir @ORCH_HOME@/Benchmark/_overnight/gpu_locks --session $SES
#   --lockdir 必须与 tools/gpu_lock.sh 的 LOCKDIR 相同（同一套锁）。
#   包写了 sched_defaults 的，以包为准；要改某个默认值，加 --set 键=值，并记 decisions.md。

# 1.4 起守护：常驻 tmux 窗 orchd；外面套一层循环，守护万一退出 5 秒后自己起来
tmux new-window -d -t $SES: -n orchd \
  "while true; do python3 -I $S/orchd.py daemon --td $TD; echo 'orchd 退出，5 秒后重起'; sleep 5; done 2>&1 | tee -a $TD/notes/orchd.log"
python3 -I $S/orchd.py health --td $TD       # 心跳正常、8 张卡都列出来才算起来了；第一次可能要等 3 秒再跑一次
#   然后进入第 2 节：后台挂 orchd.py wait

# 1.5 覆盖表 + 扫描（R08）
python3 -I $A/facts.py render --log $TD/notes/facts.jsonl --coverage $TD/notes/task-coverage.csv
python3 -I $S/scan_package.py $PKG $TD/notes/task-coverage.csv --aliases $TD/notes/role-aliases.txt; echo "scan rc=$?"

# 1.6 看板：照任务包的看板说明起（通常是包里的一条命令，或一扇只起看板的窗）
```

起来以后：

- 全脚本化的任务（`gpu-job`、`cpu-job`）由 orchd 自己开跑；
- 要判断的任务（`gpu-agent`、`cpu-agent`）由 orchd 自动生成任务书、开窗承接；
- **主窗不用派任何任务。**

## 2 循环（每次醒来都一样）

```bash
# 2.0 挂等待：同一时刻只挂一个，用 Bash 的 run_in_background
python3 -I $S/orchd.py wait --td $TD
#   巡检在它里面每分钟做一次，不进主窗上下文；只在有事时返回，只打印十几行：
#   0 = 有事件（要研究者决定的问题、要主窗决定的升级、结果就绪、判断窗或跟进窗的结论）
#   1 = 巡检发现新问题      2 = 守护没在跑      3 = 定时汇报（默认 2 小时；没事）
```

- **退 3**：什么都不做，不用汇报，回到 2.0。
- **退 2**：用 1.4 的命令重起守护（不要 init），回到 2.0。
- **退 0 或 1**：逐条处理它列出的事。每一条都能在 `references/manual.md` 第 6 节的表里找到：
  - **要读证据、要判断的**，开判断窗。窗只回 ≤ 10 行结论，交了会让 `orchd.py wait` 返回（`[判断窗结论]`）：
    ```bash
    python3 -I $S/orchd.py judge --td $TD <短名> --question "<原文>；请判断……并给出完整命令" --about <任务>
    ```
  - **要研究者决定的**（`[需要研究者决定]`、改变研究方向的取舍），原话转告，附窗名与任务号；
  - **研究者追问某个做完的任务**：`python3 -I $S/orchd.py reopen --td $TD <任务> --question "<原话>"`（接着那个任务的原会话）；
  - **照表能直接做的**，执行那一条命令。改计划的命令都要 `--reason`。

处理完后：

```bash
python3 -I $A/orch_check.py --config $TD/notes/checks.json     # R10：退 1 不许等
python3 -I $S/orchd.py ack --td $TD <已处理的告警号>             # 处理过的告警确认掉，免得反复叫醒
```

然后回到 2.0。**不要 `sleep`、不要 ScheduleWakeup、不要自己定时去看**：1.7.0 的 10–180 秒睡眠区间只适用于没有 orchd 的手工模式（第 6 节）。

要看全局详情时（例如研究者问“现在怎么样了”），手工跑一次 `python3 -I $S/orchd.py health --td $TD`。

## 3 主窗一定不做的事（R22）

- 不 `cat`/`tail` 实验日志全文，不读子窗的对话。要了解就开判断窗。
- 不亲自改脚本、调参数、重启服务、跑实验命令。
- 不手工 `CUDA_VISIBLE_DEVICES=...` 跑任何东西（R14、R23）。
- 不 `kill` 进程（R25）。在跑的任务要停只用 `orchd.py kill <任务>`，而且只在第 6 节的表让你这么做时。
- 不手写任务书、不手工开关工作窗（orchd 自己做）。
- 不 `sleep` 轮询。
- 核查不是 `ok` 的任务不说「在跑」（R24）。

## 4 压缩恢复后（Prompt P1）

```bash
python3 -I $A/restore_card.py --task-dir $TD --session $SES     # 恢复卡
python3 -I $S/orchd.py health --td $TD                           # 现场以 orchd 为准：不重建、不 init
tail -20 $TD/notes/decisions.md
```

然后直接回到 2.0（重挂 `orchd.py wait`）。

orchd 是独立进程，主窗压缩不影响它。心跳“过期”时：

1. 看 `orchd` 窗：`tmux capture-pane -p -t $SES:orchd | tail`；
2. 用 1.4 的命令重起。

状态在 `notes/sched/state.json` 里，不会丢。

## 5 汇报（R19 的第 3 行怎么写）

```bash
python3 -I $S/orchd.py util --td $TD
```

例：「用卡：真在用 84%，启动开销 6%，租而未用 4%，空卡 6%（无就绪任务 4%、令牌等待 2%）；GPU0-3 V4-Q(ok，启动用时 310 秒)，4-5 V41-R1b(ok)，6 V4-P5(loading：已持续占用，等实验真开始)，7 空（没有就绪任务）」。

## 6 手工模式（没有 `notes/orch.env`、自动派窗关着时）

orchd 照样分卡、启动 job、核查，但 agent 任务与修复要主窗派。手工模式下等待用 `wait_event.py --events-dir $TD/notes/events --cursor $TD/notes/main.cursor --timeout 900`（它也会被子窗的 Stop 等事件叫醒，主窗要自己看是谁）：

| 看到 | 做什么 | 命令 |
|---|---|---|
| `orch_sched kind=gpu_reserved` / `cpu_ready` | 在 `reserve_ttl_s` 内开窗承接 | `python3 -I $S/brief.py task --td $TD --id <任务> --win w-<任务> --out $TD/briefs/w-<任务>.md`，再 `winctl.sh open w-<任务> $TD/briefs/w-<任务>.md --task <任务>` |
| `orch_alert kind=failed` 或用卡问题 | 开修复窗 | `brief.py fix …  --reason "<告警原文>"`，再 `winctl.sh open fix-<任务>-1 … --fix <任务>` |
| 子窗交了“完成” | 开验收窗 | `brief.py audit …`，再 `winctl.sh open au-<任务> …` |
| 报告已交、任务不在跑的窗 | 关窗收 key | `winctl.sh close <窗>` |

其余与第 2 节相同。**能开自动派窗就开**：主窗上下文最短，不会漏派。
