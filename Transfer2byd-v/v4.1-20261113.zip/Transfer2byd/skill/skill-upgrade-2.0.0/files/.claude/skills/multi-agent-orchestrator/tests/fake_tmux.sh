#!/usr/bin/env bash
# 测试用假 tmux：has-session 恒成功；new-window -d -t S: -n W <命令行> 时把命令行放后台跑并记录窗名
case "$1" in
  has-session) exit 0;;
  new-window)
    shift; name=""; line=""
    while [ $# -gt 0 ]; do case "$1" in -d) shift;; -t) shift 2;; -n) name=$2; shift 2;; -c) shift 2;; *) line=$1; shift;; esac; done
    echo "$name" >> "${FAKE_GPU_DIR}/tmux_windows"
    setsid bash -c "$line" >/dev/null 2>&1 < /dev/null &
    exit 0;;
  list-windows)
    # 窗名来自 tmux_windows（job 窗）与 win_windows（假 winctl 开的子窗）；最近输出时刻 = 现在，或 win_idle 文件里写的时刻
    now=$(date +%s); idle=""; [ -f "${FAKE_GPU_DIR}/win_idle" ] && idle=$(cat "${FAKE_GPU_DIR}/win_idle")
    cat "${FAKE_GPU_DIR}/tmux_windows" "${FAKE_GPU_DIR}/win_windows" 2>/dev/null | sort -u | while read -r w; do
      [ -n "$w" ] && printf '%s\t%s\n' "$w" "${idle:-$now}"; done
    exit 0;;
  *) exit 0;;
esac
