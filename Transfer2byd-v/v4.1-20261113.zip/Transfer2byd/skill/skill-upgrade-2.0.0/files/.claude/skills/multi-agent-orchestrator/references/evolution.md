# skill 怎么一直变好：问题记录 → 回传 → 升级 → 安装 → 记账（R29）

> 给所有窗读。这套 skill 会一直用来跑实验包，每一轮实验都会暴露 skill 自身的问题。**运行中不改 skill**；把问题当场记下来，随回传交给研究者一侧，由研究者一侧（本机 Claude）统一出下一版升级包，云端照升级包安装。这样每次改动都有来由、有测试、能回滚。

## 1 闭环五步

| 步 | 谁 | 做什么 | 用什么 |
|---|---|---|---|
| ① 记 | 任何窗 | 遇到 skill 本身的问题，当场记一条（不要等到最后回忆） | `scripts/skill_feedback.py add` |
| ② 交 | 回传窗 | 每次回传（小回传、完整回传）都导出一份，放进回传目录 | `skill_feedback.py export --out <回传目录>/16-skill-issues.md` |
| ③ 改 | 研究者一侧 | 读 16，逐条判断：改脚本 / 改规则 / 改文档 / 不改（写理由）；出升级包（新版本号、改动表、测试） | 升级包（第 5 节的格式） |
| ④ 装 | 云端一个窗 | 照升级包的 `UPGRADE.md`：`--dry-run` → 安装（自动备份、升级前后测试对比）→ 上线冒烟 → 报告 | `install.py` |
| ⑤ 记账 | 研究者一侧 | 在本篇第 4 节版本史追加一行：问题 → 改动 → 测试 | 本篇 |

## 2 怎么判断是不是“skill 的问题”

| 现象 | 归哪 | 记在哪 |
|---|---|---|
| `orchd.py`、`winctl.sh`、`facts.py` 等报错、退出码不对、判据误报或漏报（例如明明在算却报 `stall`） | skill（bug） | `skill_feedback.py add --kind bug` |
| 照 SKILL.md 或 references 做会出错；两条规则说法矛盾；不知道该照哪条 | skill（rule） | `--kind rule` |
| 文档里的命令参数和脚本实际不一致（`--help` 对不上） | skill（doc） | `--kind doc` |
| 要靠手工补很多步骤才能完成某个常见动作；缺一个本该有的功能 | skill（gap） | `--kind gap` |
| 某个步骤特别慢、主窗为它耗了大量上下文 | skill（perf） | `--kind perf` |
| 实验 OOM、模型/框架版本不符、参数要调、端口被占、环境变量缺 | **实验**，不是 skill | 任务报告 + 弯路记录（14-detours.md） |
| 任务包的路线卡写错、清单（manifest）字段错 | **任务包** | 回传的“对传输包的反馈”一节 |

拿不准时两边都记，写清楚“不确定归哪”。

## 3 运行中能不能改 skill

- **默认不能。** 发现问题：先找规则允许的绕过办法（例如误报的告警 `orchd.py ack` 并写理由），记 `skill_feedback.py add`，继续做实验。
- **紧急例外**（不改就完全跑不下去，例如脚本有语法错、所有任务都被误判失败）：
  1. `snapshot.py take` 备份要改的文件；
  2. 只做最小改动，改动前后各跑一次相关测试（`tests/orchd_sim.py` 或 `tests/gates*.sh`）；
  3. `skill_feedback.py add --kind bug --severity high --workaround "热修：<改了哪几行>"`，并把 diff 写进 `--evidence` 指向的文件；
  4. 汇报第一行写「需要你决定：我热修了 skill 的 ……」。
  研究者一侧会在下一版正式收进或换成更好的修法。

## 4 版本史（每次升级追加一行；最新在上）

| 版本 | 日期 | 解决的问题（来源） | 主要改动 | 验证 |
|---|---|---|---|---|
| 2.0.0 | 2026-11-13 | v4 现场回传 7 问：两套锁、端口冲突逼整机独占、僵尸锁、占卡空转、子窗误杀、tee 截断、版本不符。研究者要求：主窗只掌控全局、定时巡检；一事一窗做完关窗；派发后核实真用卡；动态调度、不用预计时长（优先级 + 强制依赖）；以“进程真起、持续占用、实验真开始”确认真开始；能并行的实验写成 1/2/4/8 卡都能跑；异常与变更预先想全、写清；skill 全局通用；环境任务优先 | 新增 `orchd.py`（唯一分卡者、启动确认、每 3 s 用卡核查、自动派窗、判断窗与跟进窗、运行中改计划的命令、预案与备选、里程碑与依赖算出的优先级、全局保护、子窗看护、子窗的一生与 resume、接口失败退避、主窗的等待 `wait`）、`cellrun.py`、`brief.py`、`winctl.sh`（会话号、resume、优雅退出）、`skill_feedback.py`；R22–R37；orch-manifest/2；references 的 manual、main-loop、orchd、package-contract 与本篇；追加 watch、task-flow、usage-prompts、windows-and-keys 的 2.0.0 一节（旧的睡眠区间只用于手工模式） | `tests/orchd_sim.py` 192 项；`gates.sh`、`gates_sched.sh`、`selftest.sh` 与升级前一致（由 install.py 对比） |
| 1.7.0 | 2026-11-13 | 空卡仍会滞后发现 | `gpu_sched.py wait`（事件驱动看卡）、僵尸锁点名、`--facts` 交叉核对、按 `est_h` 选最快档（2.0.0 起不再用预计时长） | `gates_sched.sh` 64 项 |
| 1.6.0 | 2026-11-13 | 门禁拿过期快照判空卡；CSV 引号挤歪列；`gpu_lock.sh` 忽略指定卡号 | `gpu_sched.py`（watch/plan）、`--free-gpus auto`、`GPU_LOCK_CARDS` | `gates_sched.sh` 39 项 |
| 1.5.x | 2026-11-12 | SKILL.md 770 行难读；门禁假绿；事实流没人写 | 常驻规则 + references 拆分；R 编号固定；hooks 扩展；`facts.py check` | `gates.sh` 20 项、`selftest.sh` 104 项 |
| 1.4.0 | 2026-11-12 | 四处门禁静默假绿；无参开窗 | 解析修复；`snapshot.py`、`facts.py`、`winstate.py`、`orch_check.py` | `gates.sh` 17 项 |
| 1.1.0–1.3.0 | 2026-11-10 | 派发未提交、菜单挂死窗、key 分配 | 任务书十三项、启动看护、key 池 | — |

## 5 升级包的格式（研究者一侧出包时遵守；云端照它装）

```
skill-upgrade-<版本>-<日期>/
  README.md        一句话结论、改了什么、为什么、包里有什么、以后怎么用、已验证与没验证的
  UPGRADE.md       逐条命令：dry-run → 安装 → 检查 → 上线冒烟（真机）→ 回滚
  install.py       核对现版本 → 备份（tar.gz，绝对路径）→ 写文件 → 追加 → 原位修改（找不到原文就停）→ 跑测试（升级前后对比）→ 记录
  files/           新文件与整文件替换（只放研究者一侧有逐字节原版的文件；占位符 @ORCH_HOME@ 安装时替换）
  appends/         追加到某文件末尾的一节（不改原文；已追加过就跳过）
  prompts/         发给云端 agent 的升级任务书
  SHA256SUMS
```

规则：
- **版本号**：新机制或改了常驻规则的含义 → 次版本以上（2.0 → 2.1 / 3.0）；只修脚本缺陷或文档 → 修订号（2.0.0 → 2.0.1）。
- **只加不删**：旧脚本留作后备，文档写清“由谁取代”；R 编号永不改号、不复用。
- **每条改动对应一条来源**（16-skill-issues 的编号、回传里的问题号或研究者原话）和一项测试（能失败的那种）。
- **没在真机上验证过的，写进 README 的“没验证的”**，并在 UPGRADE 里给上线冒烟。

## 6 每个实验包里的 skill 部分（研究者一侧写包时遵守）

从 v4.1 起，每个实验包都带一个 `skill/` 目录：

| 文件 | 内容 |
|---|---|
| `skill/P-主窗调用.md` | 本包的调用 Prompt（第一节已按本包填好：包路径、版本、任务目录、会话名、交付目录、特别提醒），研究者原样发给主窗 |
| `skill/需要的skill版本.md` | 本包要求的最低 skill 版本；云端现有版本不够时，用哪个升级包、怎么装 |
| `skill/优化记录.md` | 本轮 skill 改了什么、为什么（对应哪些 16-skill-issues 条目）、怎么装、怎么回滚；没改就写“本轮不改 skill，理由……” |
| `skill/skill-upgrade-<版本>/`（需要升级时） | 完整升级包（第 5 节的格式） |

回传里固定有 `16-skill-issues.md`（`skill_feedback.py export` 生成）；没有问题也交，内容写“无”。

## 7 改 orchd 或 cellrun 时（给以后维护的人）

1. 先读 `references/manual.md` 第 8 节的代码结构导读（tick 的 1–10 步、auto_windows 的 a–i 节）。
2. 先写一个能失败的测试，加进 `tests/orchd_sim.py`：一组一个函数，再加进 `main()` 的列表。写完确认它在改代码前确实失败。
3. 改代码。改完全量跑 `python3 -I tests/orchd_sim.py`，约 8 分钟，必须全过。
4. 同步改文档：
   - SKILL.md 的规则（`parts/skill_rules.md`）与变更记录（`parts/skill_head.md`）；
   - `references/manual.md` 第 6 节（异常与变更的表）；
   - `references/orchd.md` 的命令表与判据表；
   - `references/package-contract.md` 的字段表。
5. 用 `build_pack.py` 重新生成升级包；不要手改包里的副本。
6. 用真实任务包的 manifest 跑一遍 `tools/plan_sim.py`，看卡时账有没有变差。

常见陷阱（2.0.0 开发时踩过）：

- 循环变量没在每轮重设，读到上一个任务的字段：`if_fail` 第一次就是这样错的。
- `glob` 的模式里不能有 `\0`，会抛 ValueError，每一轮都失败。
- 抢占与启动保护要防来回抢：被抢占的任务在抢占者起跑前不重启。
- 自己停掉的子进程不要在 `stop_tree` 里回收主子进程，否则退出码变成 0、被当成成功。
- 测试的假脚本要在临时目录里生成可执行副本：zip 解压不保留可执行位。
- 主窗的等待不能被子窗的 hooks 事件叫醒（每扇窗每一轮都有 Stop）：子窗事件归 orchd，主窗只等 `orchd.py wait`。
- 关窗要等子窗这一轮结束：它交了 report 后还在写上下文卡。
- 运行号必须全局唯一（带编排实例）：同一台机器上另一套编排可能在同一秒跑同名任务，按运行号停进程会误杀别人。
- 门控两支在结论出来前都“马上就绪”：留卡时按最严的一支留。
- 两个模拟要能同时跑而互不干扰：它们正好模拟了“同一台机器两套编排”。
- 旧版本留在 references 里的规则（例如 1.7.0 watch.md 的睡眠区间）升级时要显式标“只适用于手工模式”，否则两套规则并存。

## 8 下一版候选

见 `references/manual.md` 第 11.3 节：

- 无界面的判断窗、跟进窗、验收窗（`claude -p --resume`）；
- 子窗压缩后自动注入恢复卡；
- 子窗之间的一句话通知。

每一项都等真机回传（16-skill-issues、主窗与子窗的压缩次数、resume 是否顺利）再定。
