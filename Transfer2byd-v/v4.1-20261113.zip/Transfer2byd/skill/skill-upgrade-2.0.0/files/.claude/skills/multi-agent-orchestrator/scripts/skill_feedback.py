#!/usr/bin/env python3
"""skill_feedback —— 记录 skill 自身的问题（R29），回传给研究者一侧用于下一版 skill 升级。

任何窗（主窗、子窗、验收窗、回传窗）遇到“skill 本身”的问题都当场记一条，不在运行中改 skill：
  * 脚本出错或判据错（误报、漏报、退出码不对、命令报用法错）
  * 规则说不清、互相矛盾、照做会出错
  * 缺功能（要靠手工补的步骤）、太慢、太费 token
  * 文档里的命令与脚本实际参数不一致
实验本身的问题（OOM、环境版本、参数）不记这里，记任务的报告与弯路记录（14-detours.md）。

用法：
  skill_feedback.py add    --td <任务目录> --kind bug|rule|gap|doc|perf --where <R编号或脚本名> \
                           --symptom "<现象，原文>" [--evidence <文件路径>] [--workaround "<当时怎么绕过>"] \
                           [--suggest "<建议怎么改>"] [--severity high|mid|low] [--window <窗名>]
  skill_feedback.py list   --td <任务目录>
  skill_feedback.py export --td <任务目录> --out <回传目录>/16-skill-issues.md [--pkg-version v4.1]
写到 <任务目录>/notes/skill-feedback.jsonl（只追加，加锁），同时追加一份到 ~/.cache/orch-skill/feedback.jsonl（跨轮汇总）。
退出码：0；2 用法错。
"""
import argparse
import fcntl
import json
import os
import sys
import time

KINDS = {"bug": "脚本缺陷/判据错", "rule": "规则不清或矛盾", "gap": "缺功能/要手工补", "doc": "文档与脚本不一致",
         "perf": "太慢/太费 token"}
SEV = ("high", "mid", "low")


def append(path, rec):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        fcntl.lockf(fd, fcntl.LOCK_EX)
        os.write(fd, (json.dumps(rec, ensure_ascii=False) + "\n").encode("utf-8"))
    finally:
        fcntl.lockf(fd, fcntl.LOCK_UN)
        os.close(fd)


def read(path):
    out = []
    try:
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    except OSError:
        pass
    return out


def skill_version():
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "SKILL.md")
    try:
        for line in open(p, encoding="utf-8"):
            if line.startswith("version:"):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return "?"


def cmd_add(a):
    if a.kind not in KINDS or a.severity not in SEV:
        print("--kind 取 %s；--severity 取 %s" % ("|".join(KINDS), "|".join(SEV)), file=sys.stderr)
        return 2
    log = os.path.join(a.td, "notes", "skill-feedback.jsonl")
    n = len(read(log)) + 1
    rec = {"no": n, "time": time.strftime("%Y-%m-%d %H:%M:%S"), "skill_version": skill_version(), "kind": a.kind,
           "where": a.where, "severity": a.severity, "window": a.window or os.environ.get("ORCH_WINDOW", ""),
           "symptom": a.symptom, "evidence": a.evidence or "", "workaround": a.workaround or "", "suggest": a.suggest or "",
           "td": os.path.abspath(a.td)}
    append(log, rec)
    append(os.path.expanduser("~/.cache/orch-skill/feedback.jsonl"), rec)
    print("已记第 %d 条 skill 问题（%s，%s）：%s" % (n, KINDS[a.kind], a.where, a.symptom[:80]))
    return 0


def cmd_list(a):
    recs = read(os.path.join(a.td, "notes", "skill-feedback.jsonl"))
    if not recs:
        print("（没有记录）")
    for r in recs:
        print("#%d %s [%s/%s] %s：%s" % (r["no"], r["time"], r["kind"], r["severity"], r["where"], r["symptom"][:100]))
    return 0


def cmd_export(a):
    recs = read(os.path.join(a.td, "notes", "skill-feedback.jsonl"))
    lines = ["# 16 skill 本身遇到的问题（skill_feedback.py export 生成，不手改）", "",
             "包版本：%s；skill 版本：%s；共 %d 条。研究者一侧据此出下一版 skill（见 skill 的 references/evolution.md）。"
             % (a.pkg_version or "?", skill_version(), len(recs)), ""]
    if not recs:
        lines.append("无")
    else:
        lines += ["| # | 时间 | 类别 | 严重度 | 位置 | 现象 |", "|---|---|---|---|---|---|"]
        for r in recs:
            lines.append("| %d | %s | %s | %s | %s | %s |" % (r["no"], r["time"], KINDS.get(r["kind"], r["kind"]), r["severity"],
                                                          r["where"], r["symptom"].replace("|", "/")[:120]))
        lines.append("")
        for r in recs:
            lines += ["## %d %s（%s）" % (r["no"], r["where"], KINDS.get(r["kind"], r["kind"])), "",
                      "- 时间 / 窗：%s / %s；skill 版本 %s" % (r["time"], r["window"] or "-", r["skill_version"]),
                      "- 现象：%s" % r["symptom"], "- 证据：%s" % (r["evidence"] or "无"),
                      "- 当时怎么绕过：%s" % (r["workaround"] or "无"), "- 建议怎么改：%s" % (r["suggest"] or "无"), ""]
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("已导出 %d 条到 %s" % (len(recs), a.out))
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("add")
    s.add_argument("--td", required=True)
    s.add_argument("--kind", required=True)
    s.add_argument("--where", required=True)
    s.add_argument("--symptom", required=True)
    s.add_argument("--evidence", default="")
    s.add_argument("--workaround", default="")
    s.add_argument("--suggest", default="")
    s.add_argument("--severity", default="mid")
    s.add_argument("--window", default="")
    s = sub.add_parser("list")
    s.add_argument("--td", required=True)
    s = sub.add_parser("export")
    s.add_argument("--td", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--pkg-version", default="")
    a = ap.parse_args()
    return {"add": cmd_add, "list": cmd_list, "export": cmd_export}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
