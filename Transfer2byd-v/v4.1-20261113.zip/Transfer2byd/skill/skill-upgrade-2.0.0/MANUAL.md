# multi-agent-orchestrator 2.0.0 使用手册

> 给云端主窗、子窗，以及以后维护这个 skill 的人读。
>
> - 第 1–5 节：怎么用；
> - 第 6 节：出了状况怎么办（谁决定、用哪条命令）；
> - 第 7 节：怎么写任务包；
> - 第 8 节：怎么改 skill；
> - 第 9 节：Prompt 怎么用。
>
> 记号：
>
> | 记号 | 含义 |
> |---|---|
> | `TD` | 任务目录 |
> | `PKG` | 任务包根（只读） |
> | `S` | `@ORCH_HOME@/.claude/skills/multi-agent-orchestrator/scripts` |
> | `A` | `@ORCH_HOME@/skill/skill-addons/orch-v1/scripts` |
> | `SES` | tmux 会话名 |
>
> 命令照抄，只替换这些记号。

## 0 一句话与三条原则

**任务包写好一切 → orchd 自动执行 → 主窗只掌控全局。**

1. **任务包写好一切**。下面这些都写在包里，云端几乎只是运行平台：
   - 任务、强制依赖、卡数档位、资源令牌、命令；
   - 完成判据、门控分支；
   - 异常预案（修不好怎么办、备选方案）。
2. **orchd 自动执行**。`orchd.py daemon` 不调用模型，每 3 秒做一遍：
   - 分卡、启动，确认任务真开始，核查是否真在用卡；
   - 开窗、修复、验收、关窗，收残留进程；
   - 只有要人决定的事才叫醒主窗。
3. **主窗只掌控全局**。主窗在后台挂一个 `orchd.py wait`。巡检在它里面每分钟做一次，不进主窗上下文；它只在有事时返回：
   - 有要处理的事：照本手册第 6 节处理，要读证据的开判断窗，要研究者决定的原话转告；
   - 没事（每 2 小时一次）：直接重挂。

   主窗不读日志、不排障、不跑实验、不挑卡、不写任务书、不睡眠轮询。

## 1 角色、文件与数据流

```
研究者 ──对话── 主窗（orchestrator）
                 │  orchd.py wait（只在有事时返回；巡检在里面做）
                 ▼
         orchd.py daemon（host + watchdog，唯一的 GPU 分配者）
     ┌─────────┼──────────────┬────────────────┐
  gpu-job / cpu-job      gpu-agent / cpu-agent     判断窗
  （tmux 窗 j-<ID>，      （工作窗 w-<ID>、修复窗    （judge-<名>，主窗一条
   orchd 直接启动）         fix-<ID>-<n>、验收窗      命令开，交结论自动关）
                            au-<ID>，orchd 自动开关）
```

| 文件 | 谁写 | 是什么 |
|---|---|---|
| `PKG/state/manifest.json` | 研究者一侧（包作者） | 任务清单（orch-manifest/2，`references/package-contract.md`） |
| `TD/notes/sched/{config,queue,state}.json` | 只有 orchd | 配置、运行中的任务清单（含运行中改过的）、全部状态 |
| `TD/notes/sched/gpu.jsonl` | orchd | 每 3 秒每张卡的利用率、显存、租给谁（卡时账、计时干扰核对用） |
| `TD/work/sched/<ID>/<运行>/` | orchd 包装进程 | `console.log`、`spec.json`、`wrapper.json`、`exit.json`；任务可以写 `.started`（开始标志）、`progress.json` |
| `TD/notes/facts.jsonl` | orchd、子窗、验收窗 | 事实流：`task_add`、`dispatch`、`lease`、`release`、`report`、`audit`、`gate`、`task_set` |
| `TD/notes/events/orchd.jsonl` | orchd | 叫醒主窗的事件：`orch_alert`（升级）、`orch_attention`（子窗要研究者决定的问题）、`orch_result`（结果就绪、按预案处理了什么、判断窗结论） |
| `TD/notes/decisions.md` | orchd（运行中改计划）、主窗 | 每个非显然的决定一行：时间｜决定｜依据｜影响的任务 |
| `TD/notes/ctx/<窗>.md` | 各子窗 | 上下文卡：做到哪了、结果在哪、下一步、会话号（窗被换掉时新窗靠它接着做） |
| `TD/notes/sessions.jsonl` | orchd | 每扇窗的会话号（开窗、关窗各一行）；以后要用就 resume 回去 |
| `TD/notes/events/<会话>__<窗>.jsonl` | 子窗的 hooks（1.7.0 的 `orch_hook.py`） | 子窗的 Stop、StopFailure、PreCompact 等事件；orchd 读它们，主窗不读 |
| `TD/briefs/<窗>.md` | `brief.py`（orchd 调用） | 任务书 |

## 2 安装与升级

照升级包里的 `UPGRADE.md` 逐条做：

1. `install.py --dry-run`；
2. 安装（自动备份，升级前后跑测试对比）；
3. 检查；
4. 上线冒烟；
5. 需要时回滚。

装好的验证命令：

```bash
python3 -I $S/orchd.py help | head -3                         # 第一行有 orchd
python3 -I $S/../tests/orchd_sim.py | tail -1                 # ORCHD SIM OK 192/192（约 8 分钟）
python3 -I $S/cellrun.py 2>&1 | head -2                        # 打印用法
```

## 3 开工（每个任务包一次；压缩恢复后不重做）

逐条命令见 `references/main-loop.md` 第 1 节，按顺序做：

1. 版本校验。
2. 建任务目录，写 `notes/orch.env`。写了它，orchd 就默认**自动派窗**。
3. `orchd.py init` 读包的 manifest。全部任务进事实流，一个都不会漏。
4. 在 tmux 窗 `orchd` 里起守护。用 1.4 节带自动重启的那条命令。
5. 覆盖表、扫描、看板窗。
6. 跑一次 `orchd.py health`，确认心跳正常、8 张卡都列出来了。
7. 后台挂上 `orchd.py wait`（第 4.1 节），开工完成。

之后：

- `gpu-job`、`cpu-job` 由 orchd 直接启动；
- `gpu-agent`、`cpu-agent` 由 orchd 自动开窗承接。

主窗进入第 4 节的循环。

## 4 日常

### 4.1 主窗的循环（R11、R22、R31）

```bash
# 唯一的等待：Bash 的 run_in_background，同一时刻只挂一个
python3 -I $S/orchd.py wait --td $TD
```

它返回时只打印十几行：先是要处理的事，再是“这段时间不用处理的”摘要（谁完成了、按预案处理了什么、门控结论、里程碑），最后一行现在的状态。按退出码做：

| 退出码 | 意思 | 主窗做什么 |
|---|---|---|
| 0 | 有事件：子窗要研究者决定的问题、要主窗决定的升级、结果就绪、判断窗或跟进窗的结论 | 逐条处理（下表与第 6 节），`ack` 处理过的告警，重挂 |
| 1 | 巡检发现新问题（例如没人管的失败、开不起来的窗） | 照它写的办法与第 6 节处理，重挂 |
| 2 | 守护没在跑 | 用 `references/main-loop.md` 1.4 的命令重起守护（不要 init），重挂 |
| 3 | 定时汇报（默认 2 小时；没事） | 不用汇报，直接重挂 |

事件怎么处理：

| 输出里的标签 | 处理 |
|---|---|
| `[需要研究者决定]` | 子窗要研究者决定的问题。原话转给研究者，附窗名与任务号，不改写、不替研究者答。研究者答了：`winctl.sh send <窗> "研究者答复：<原话>"`，再 `orchd.py ack --td $TD <告警号>`。 |
| `[结果就绪]` | 例如小回传交好了。一句话告诉研究者在哪。 |
| `[判断窗结论]`、`[跟进窗结论]` | 照它建议的命令执行；要研究者决定的转研究者。 |
| `[要主窗决定]`、`[巡检]` | 照第 6 节。 |

**为什么这样等**（R37）：

- 3 秒一轮的分卡与核查在 orchd 里做，是脚本，不花任何 token；
- 主窗每醒一次至少花 1–2k token。旧的“每 10–180 秒醒一次看看”一天要醒几百到几千次，主窗几小时就要压缩一次；
- 现在主窗只在有事时醒（一个包通常十来次）加上每 2 小时一行，整轮一般不压缩。

### 4.2 orchd 自己处理、不叫醒主窗的事

- **CPU 任务**：一就绪立即启动。
- **GPU 任务**：按优先级发卡（第 5 节），确认真开始。
- **用卡问题**：
  - agent 任务出问题，告警原文发进它的窗；
  - job 任务出问题，开修复窗。
- **修复**：任务失败，开修复窗，最多 `max_fix` 次；用完按包的 `if_fail` 预案处理。
- **验收**：agent 任务交“完成”，开验收窗。
- **残留进程**：宽限后按标签收掉。
- **子窗的一生**（第 5.5 节）：
  - 记下会话号；
  - 交了报告、这一轮结束后才关窗；
  - 窗意外消失、key 失效时用原会话 resume 重开；
  - 上下文超限时开新窗。
- **子窗这一轮因限流或接口出错中断**：退避 60、120、240… 秒后让它接着做；连续 4 次仍失败才升级。
- **子窗长时间没输出**：发一次提醒。
- **通知**：任务结束、按预案处理、门控结论、里程碑达成，只记进下次醒来的摘要。

### 4.2 orchd 自己处理、不叫醒主窗的事

- **CPU 任务**：一就绪立即启动。
- **GPU 任务**：按优先级发卡（第 5 节），确认真开始。
- **用卡问题**：
  - agent 任务出问题，告警原文发进它的窗；
  - job 任务出问题，开修复窗。
- **修复**：任务失败，开修复窗，最多 `max_fix` 次；用完按包的 `if_fail` 预案处理。
- **验收**：agent 任务交“完成”，开验收窗。
- **残留进程**：宽限后按标签收掉。
- **子窗消失**：保留租约，按上下文卡重开一次。
- **子窗长时间没输出**：发一次提醒。
- **关窗**：任务结束就关窗、收 key。

### 4.3 子窗怎么工作

任务书由 `brief.py` 生成，固定五节：

1. 共同规则；
2. 包的规定（1b）；
3. 任务的原始来源（路线卡、manifest 条目）；
4. 环境；
5. 交接。

子窗：

- GPU 命令一律 `orchd.py exec --td $TD <ID> -- <命令>`；
- 进展追加到上下文卡；
- 做完交 `report`（带 `summary`），要研究者决定的事用 `orchd.py ask`，或在报告里加 `attention`；
- skill 本身的问题用 `skill_feedback.py add` 当场记。

## 5 调度、启动确认、核查、卡时账怎么读

### 5.1 动态调度，不用预计时长（R15）

研究者的规则是“优先级 + 强制依赖”。启动、加载、等待、失败都会让预计时长失准，所以 orchd 每 3 秒从实时状态重新决定：

1. **就绪**，以下都满足：
   - `deps` 都成功（`"A|B"` 只要其中一个成功）；
   - `after` 都结束；
   - 门控满足，没被 `hold`；
   - 备选任务（`fallback_for`）还要主任务失败已成定局。
2. **CPU 任务**：一就绪就跑，`cpu_slots` 封顶。
3. **GPU 任务的先后**：
   - 优先级 = 自己的 `prio_boost` + 所有直接或间接依赖它的节点的分量之和：
     - 普通任务的分量是 1 + 正的 `prio_boost`（正加成因此向上游传：它急，它的前提也就急）；
     - 里程碑（`kind: milestone`，“谁要这些结果”）的分量是 `weight`，默认 1；
     - **有人在等的里程碑**（`waiting_human`，例如研究者在等小回传判门）的分量大过全部任务之和，所以喂给它的任务排在一切之前；
   - 同级时下游最长依赖链（按任务个数）长的先；
   - 再按 `seed` 稳定随机，同级的次序跨轮不变，不会来回抢。
4. **卡数**：取包声明的档位里此刻放得下的最优先一档。
   - `gpu_options` 的值是偏好，越小越优先；
   - 没写值时卡多的优先：能用 8 卡加速就给 8 卡；
   - `strict_tier` 只认首选档。
   - 余卡继续给下一个就绪任务。**有放得下的就绪任务就不让卡空着。**
5. **防饿死**（启动保护）：
   - 最高优先级的被挡任务，若有下游链（有任务强制依赖它，或 `prio_boost` > 0），**马上**保护：它晚一步，后面整条链都晚。
   - 叶子任务（没有任务强制依赖它）等满 `leaf_hold_after_s`（默认 6 小时）才保护：它晚跑不拖别人，空卡先给放得下的任务。
   - 保护期间，低优先级、不可抢占的任务暂不占它要的卡与令牌；
   - `preemptible` 的任务照样先用这些卡，到它能起跑时被抢占；
   - 被抢占的任务排回队列、不算失败，在抢占者起跑前不会重启。
   - **马上就绪的也先留卡**：比当前任务优先的 GPU 任务只差一个正在跑的 CPU 小步骤（例如门控判定），orchd 最多 5 分钟（`imminent_hold_s`）先替它留卡，免得低优先级的大任务趁这几秒把整机占了。本机模拟里出过这种事：门 BW 判定的那几秒里，Q0 抢在研究者等着的探针前面拿走了整机。

例：8 张卡，就绪的有 A（下游 5 个，档 `{"8": null, "4": null}`）、B（下游 2 个，`{"2": null}`）、C1–C3（下游 0 个，`{"1": null}`）。

- A 拿 8 张。
- A 一结束，B 拿 2 张，C1–C3 各拿 1 张，余 3 张给后面就绪的任务。
- 若 A 改成只能 4 卡（`{"4": null}`），A 拿 4 张，B 拿 2 张，C1、C2 各 1 张，C3 等下一张空卡。

任务图之外的需求（研究者的决定点、下一轮的设计、论文的某一节）写成里程碑，不要给任务手填大数：里程碑写清“要哪些结果”，优先级就从依赖关系里算出来，看得出为什么谁排在前面（`orchd.py status` 的任务行带优先级）。

### 5.2 启动确认（R34）

三项都有才算“真开始”：

1. **进程真起来并占住资源**：
   - GPU 任务：租到的每张卡上都有它的进程；
   - agent 任务或 `allow_partial`：至少一张卡上有；
   - CPU 任务：进程在。
2. **这种占用连续 `start_hold_s` 秒**（默认 30）。
3. **实验真开始**，有一项就算：
   - 任务 `touch "$ORCH_STARTED"`；
   - manifest 的 `started_if` 文件出现，或 `started_log` 正则出现在日志尾部；
   - 进度文件（manifest 的 `progress`、`$ORCH_PROGRESS`）在开始占用之后更新了；
   - 包什么都没声明时：GPU 任务持续计算满 `start_hold_s`，CPU 任务进程持续在跑。

确认之后：

- `status`、`health`、看板显示“启动用时 N 秒”；
- 事实流记 `task_set …真开始`；
- 从派发到真开始的卡时记**启动开销**（`startup_s`）。

确认之前：

- 显示“启动中：等进程上卡”“已占用 12/30 秒”或“已持续占用，等实验真开始”；
- 退出的失败标**启动阶段失败**，多半是环境、路径、参数、端口或显存问题；
- 过了启动时限 `warmup_s` 还没真开始，报 `no_start`。

### 5.3 核查判据

| 判据 | 意思 | 谁处理 |
|---|---|---|
| `loading` | 启动时限内还没确认真开始 | 正常 |
| `ok` | 已真开始，卡上有它的进程，在算或在出进度 | 正常 |
| `gap` | agent 任务两次运行之间，卡上暂时没进程 | 正常；超过 `agent_idle_s` 转 `not_on_gpu` |
| `reserved` | gpu-agent 已预留卡、等工作窗接手 | 正常；`reserve_ttl_s` 没人接就收回 |
| `no_start` | 过了启动时限，占着卡但没有任何真开始的证据 | agent：发进它的窗；job：5 分钟后开修复窗 |
| `not_on_gpu` | 过了启动时限，卡上没有它的进程；或真开始后进程没了超过 `lost_s` | 同上 |
| `partial` | 只有部分租到的卡上有它的进程 | 同上 |
| `stall` | 真开始后利用率持续低于 `util_min`，且进度不动超过 `stall_s` | 同上 |
| `stray` / `untagged` | 进程跑到没租给它的卡，或租到的卡上有不带标签的进程 | 同上 |
| `rogue` / `orphan` | 卡上有无主进程，或已结束任务的残留进程 | `orphan` 宽限后自动收；`rogue` 升级 |

### 5.4 卡时账（`orchd.py util`）

各行的意思：

| 一行 | 意思 |
|---|---|
| 真在用 | 已真开始、有本任务进程、利用率 ≥ 阈值 |
| 启动开销 | 开窗、加载、编译、预热 |
| 租而未用 | 真开始后空转、两次运行之间、CPU 阶段 |
| 空卡（五类） | 启动保护凑卡、令牌等待、余卡不够、没有就绪任务、暂停启动 |
| 可避免 | 加锁失败、没接预留、槽位用完 |
| 别人占用 | 他人锁、未知显存 |
| 采样失败 | 那几轮 nvidia-smi 不可用 |

- **“可避免”大于 0 要查。**
- “启动开销”大说明加载太慢，或者 `start_hold_s`、`warmup_s` 设得不合适。
- 回传用 `util --csv` 导出，文件名照任务包。

### 5.5 子窗的一生与上下文预算（R26、R37）

一扇子窗从开到关：

1. **开窗**：winctl 用 `claude --session-id <新会话号>` 启动，会话号记进上下文卡、orchd 状态和 `notes/sessions.jsonl`；模型档位按任务的 `tier` 或 `tier_by_kind`，没写就是默认档 V_fast。
2. **做事**：进展写上下文卡；长命令放后台；日志只看尾部。
3. **交接**：先把报告写进上下文卡，最后一步才写 report。
4. **关窗**：orchd 等这一轮结束（hooks 的 Stop），或者交报告后 `close_grace_s`（默认 180 秒），才让 winctl 送 `/exit`、收 key。会话记录留在磁盘上。

之后还要用：

| 情况 | 怎么接着做 | 为什么 |
|---|---|---|
| 窗意外消失（崩溃、被关） | 保留租约，`--resume` 回原会话 | 上下文不丢（1.7.0 的经验：别重开新会话） |
| key 失效、没有权限 | 换一把 key，`--resume` 回原会话 | 同上 |
| 限流、接口偶发出错 | 窗还在：退避后发“接着做” | 不用重开 |
| 上下文超过模型上限（400） | 开新窗，靠任务书与上下文卡 | 超限的会话 resume 仍然 400（1.7.0 实测） |
| 任务失败、修复后重试 | 新工作窗默认 `--resume` 原会话；原会话估计超过 `resume_max_tokens`（12 万）就开新窗 | 接着原会话记得做过什么；太长的会话一接就要压缩 |
| 任务做完了，研究者追问、要补一段分析 | `orchd.py reopen <任务> --question "<原话>"`：resume 原会话开跟进窗 | 跟进窗交了回答就叫醒主窗、关窗 |

上下文预算（按云端现有的模型档位，1.7.0 选档规则）：

| 窗 | 档位 | 上下文 | 怎么控制 |
|---|---|---|---|
| 主窗 | L 档 | 配置 840k | 只在有事时醒（每次 1–5k token），2 小时一行；一个包全程约 15 万，一般不压缩 |
| 工作窗、修复窗、验收窗 | 默认 V_fast | 配置 280k，约 204k 自动压缩 | 一事一窗、做完就关；日志只看尾部；resume 上限 12 万 |
| 环境窗 | T 档（包里写 `tier: "T"`） | — | 安装、编译排障最强（选档表） |
| 判断窗 | M 档（`tier_by_kind`） | — | 只给结论类任务（选档表） |

每扇子窗压缩了几次，orchd 从 hooks 的 PreCompact 记下，`orchd.py health` 列出来；压缩多的任务，下一版包要拆小。

## 6 异常与变更：谁决定、用哪条命令（R36）

先按这一节的表处理，表里没有的开判断窗：

```bash
python3 -I $S/orchd.py judge --td $TD <短名> --question "<告警原文>；请判断……并给出完整命令" [--about <任务>]
```

判断窗交结论时 orchd 发 `orch_result kind=judge` 叫醒主窗，并自动关窗。

**每一次运行中的改动都要 `--reason`**。orchd 把改动写进 `notes/decisions.md` 与事实流。任务包的 manifest 不动，回传时据此交代“运行中改了什么”。

### 6.1 任务本身

| 情况 | 看到什么 | 谁处理 | 怎么做（命令） | 之后会怎样 |
|---|---|---|---|---|
| 启动阶段失败 | 失败原因开头是“启动阶段失败” | orchd → 修复窗 | 修复窗先查环境、路径、参数、端口、显存；修好 `retry`，修不好报受阻 | 修复用完按预案处理或升级 |
| 运行中失败（OOM、报错） | `failed`，修复窗自动开 | 修复窗 | 定性（瞬时、资源、确定性、环境、未知）；能修就 `retry`；同一现象两次以上是确定性的，建议 `accept` | 修复 `max_fix` 次用完：按 `if_fail` 预案处理；没写预案的升级为 `fix_exhausted` |
| 修复用完（`fix_exhausted`） | `orch_alert` | 主窗 | 1. 开判断窗看能不能换档或换参数；<br>2. 确属这一格本身的问题：`orchd.py accept --td $TD <ID> --reason "…"`；<br>3. 要改方案：`edit` 后 `retry`；<br>4. 不做了：`drop` | accept 之后：严格依赖它的任务自动跳过；`after` 与 `deps_optional` 放行；备选就绪 |
| 确实不可执行（缺数据、硬件不支持、上游结论使它没意义） | 修复窗或判断窗的结论 | 主窗；改变研究方向的先问研究者 | 在跑的先 `orchd.py kill --td $TD <ID>`；再 `orchd.py drop --td $TD <ID> --reason "…"` | 记为跳过；严格下游跳过；`after` 放行；`fallback_for` 它的备选就绪 |
| 真跑时发现还缺一个前序（预处理、下载、转换、校准） | 子窗报受阻或 `attention` | 主窗（判断窗给出新任务的 JSON） | `orchd.py add --td $TD --json '{"id":"PRE-X","kind":"cpu-job","cmd":"…","deps":[]}' --reason "…"`，再 `orchd.py dep --td $TD <原任务> --add PRE-X --reason "…"`；原任务在跑的先 `kill` 再 `retry` | orchd 防环（会成环就拒绝）；PRE-X 一完成原任务就绪 |
| 结果说明某任务要提前 | 门控或判断窗的结论 | 主窗 | `orchd.py prio --td $TD <ID> --boost 10 --reason "…"` | 下一轮按新优先级排；在跑的不受影响 |
| 档位、令牌、时限要改（例如 8 卡不比 4 卡快、某任务其实不怕带宽争用） | 判断窗结论 | 主窗 | `orchd.py edit --td $TD <ID> --set 'gpu_options={"4":null,"2":null}' --reason "…"`（可改字段见 `orchd.py edit` 的报错提示） | 下一次调度生效；在跑的那次不受影响 |
| 依赖写错（多了或少了） | 判断窗结论 | 主窗 | `orchd.py dep --td $TD <ID> --remove <X> --reason …` 或 `--add …`；`--after` 改 after 依赖 | 立即生效；防环 |
| 占着卡没真开始（`no_start`） | 告警 | agent：它的窗；job：修复窗 | 卡在加载：加大 `warmup_s`（`edit`），ack 告警；死锁或等不到端口：`kill` 再 `retry`；开始证据写错：下一版包修，本次 `edit` 去掉 `started_if` | 修复窗交报告后关窗 |
| 空转（`stall`） | 告警 | 同上 | 等不到的服务、死锁 → kill + retry；确属正常（长 CPU 阶段）→ 写理由、ack | — |
| 跑太久（`overtime`，超过包写的 `max_h`） | `orch_alert` | 主窗开判断窗看进度 | 在推进：ack；不推进：`kill` 后 `retry` 或 `drop` | orchd 不会自动停 |
| 结果不对（验收 fail） | `audit_fail` | 主窗开判断窗 | 能重跑：`retry`（验收窗会重开）；数据本身如此：`accept` 照实交，回传写明 | — |
| 门控判不出（前序失败、数据缺） | 门控判定任务的报告 | 包已写好 | 判定任务用 `after`，前序失败也照样判；没数据就判保守的一支 | 另一支自动跳过 |
| 研究者临时加一个任务 | 研究者说的 | 主窗 | `orchd.py add --td $TD --json '{…}' --reason "研究者要求：…"`（GPU 任务写 `gpu_options`，要判断的写 agent） | 下一轮按优先级排 |
| 研究者取消一个任务 | 研究者说的 | 主窗 | 在跑的 `kill`，然后 `drop --reason "研究者取消"` | 同“不可执行” |
| 先别启动某任务 | — | 主窗 | `orchd.py hold --td $TD <ID>`；恢复 `unhold` | 在跑的不受影响 |
| 被抢占 | `orch_sched kind=preempt` | orchd 自动 | 不用管（只有 `preemptible` 的 job 会被抢占，排回队列） | 在抢占者起跑后才重新启动；可续跑的跳过已完成的格 |

### 6.2 资源与平台

| 情况 | 看到什么 | 谁处理 | 怎么做 | 之后 |
|---|---|---|---|---|
| 坏卡（XID、ECC、某卡反复出错） | 判断窗结论、`gpu_lost` | 主窗 | `orchd.py cordon --td $TD 3 --reason "GPU3 XID 79"`，卡上的任务 `kill` + `retry`；修好后 `uncordon` | 这张卡不再分出 |
| 掉卡（`gpu_lost`） | nvidia-smi 看到的卡变少 | 主窗告诉研究者，开判断窗看 `nvidia-smi -q`、`dmesg` | `cordon` 掉那张卡；要重启机器的交研究者 | 其余卡照常调度 |
| 卡上有无主进程（`rogue`）或僵尸锁（`stale_lock`） | 告警 | 主窗开判断窗只读查归属 | **不 kill**（R25）；确属本轮编排遗留的，照判断窗的命令处理；归属不明交研究者 | — |
| 别人占着显存（`foreign_mem`） | status 的别人占用 | 不处理 | orchd 自动不分那张卡；长期占用就 `cordon` 并告诉研究者 | — |
| 磁盘余量不足（`disk`） | `orch_alert`；status 显示“暂停启动” | 主窗开判断窗列出可清理的文件（只限本任务目录与本包运行目录里的临时文件、旧运行的 ray 目录）；删前快照 | 清理后 orchd 自动恢复启动；清不出来交研究者 | 在跑的不动 |
| 要全局暂停（研究者要先看数据、机器要维护） | 研究者说的 | 主窗 | `orchd.py config --td $TD --set paused=研究者要先看v4a --reason …`；恢复 `--set paused= --reason …` | 新任务不启动，在跑的不动 |
| 端口冲突 | 启动阶段失败，日志有 address already in use | 修复窗 | 查是不是写死了端口（必须从 `ORCH_PORT_BASE` 派生）；是别的编排占的就 `retry`（换槽位） | — |
| 计时结果疑似受干扰 | 验收窗查 `gpu.jsonl` 发现同机有别的任务 | 验收窗 | 结果标“疑似受干扰”，不当正式对比；包的令牌写漏了 → 记 skill 或包问题，重跑时 `edit` 加令牌 | — |
| nvidia-smi 连续失败（`smi`） | 告警 | 主窗 | 等几轮；持续 10 分钟以上告诉研究者（驱动或容器问题），不自己修驱动 | 采样失败的那几轮不分卡、不下结论 |
| 进程号空间不一致（`pidns`） | 告警 | 不处理 | 说明容器看不到别人的进程；归属判定降级（有显存就算在用） | — |
| 网络不可达（下载、pip） | 任务报受阻 | 修复窗 | 照实记录、换包里写的离线来源；不自行改代理或网络配置，交研究者 | — |

### 6.3 窗、key 与守护

| 情况 | 看到什么 | 谁处理 | 怎么做 | 之后 |
|---|---|---|---|---|
| 开窗失败（`auto_window`） | `orch_alert` | 主窗 | `winctl.sh list` 看 key 池与窗；key 不够：`orchd.py config --td $TD --set max_windows=3 --reason "key 池只剩 4 把"` | orchd 下一轮重试开窗 |
| 子窗这一轮被限流、接口出错（hooks 的 StopFailure） | 不叫醒主窗 | orchd 自动 | 退避 60、120、240… 秒后给那扇窗发“接着做” | 连续 `max_api_retries`（4）次仍失败，升级为 `api_failures`：看 key 池与网关 |
| 子窗的 key 失效、没有权限 | StopFailure 里有 auth、401、403 | orchd 自动 | 工作窗：换一把 key，`--resume` 回原会话（租约保留） | 别的窗：升级给主窗 |
| 子窗上下文超过模型上限 | StopFailure 里有 too long、context length | orchd 自动 | 工作窗：开新窗，靠任务书与上下文卡（不 resume） | 下一版包把这个任务拆小 |
| 子窗消失（崩溃、被关） | 事实流 `子窗 … 消失` | orchd 自动 | 工作窗：保留租约，用原会话 resume 重开一次（`max_win_restarts`）；再消失判失败，交修复窗。修复窗、验收窗：允许重开 | — |
| 做完的任务还要用（研究者追问） | 研究者说的 | 主窗 | `orchd.py reopen --td $TD <任务> --question "<原话>"` | 跟进窗交了回答就叫醒主窗、关窗 |
| 子窗长时间没输出（`win_idle`） | 提醒过一次仍没动静 | 主窗 | `winctl.sh close <窗>`（orchd 会重开）；或开判断窗看屏 | — |
| 子窗问问题（`orch_attention`） | 事件 | 主窗 | 原话转研究者（第 4.1 节） | 子窗先做不依赖它的部分 |
| 判断窗没结论（`judge_timeout`） | 告警 | 主窗 | `winctl.sh close judge-<名>`，重新 `orchd.py judge` | — |
| 守护心跳过期 | health 第一行“过期！” | 主窗 | 用 `references/main-loop.md` 1.4 的命令重起，不要 init；看 `notes/sched/daemon.log` 最后几行 | 状态在 state.json 里，不会丢 |
| 守护本轮异常（`orchd_error`） | `orch_alert` | 主窗开判断窗读 `daemon.log` | 同一错误反复出现就记 `skill_feedback.py add --kind bug`；不改 orchd.py（R29） | 守护不会因为一次异常退出 |
| 主窗上下文被压缩 | — | 主窗 | 照 Prompt P1 恢复（第 9 节）；不重做开工、不 init；重挂 `orchd.py wait` | orchd 不受影响 |
| 云端机器重启（tmux 会话没了） | 心跳过期、子窗全没了 | 主窗 | 1. 重建会话；<br>2. 起守护（1.4）；<br>3. `orchd.py health`。<br>orchd 发现在跑的 job 没有包装进程，判失败交修复窗；修复窗判断后 `retry`，可续跑的任务跳过已完成的格 | — |

### 6.4 环境与版本（R32）

| 情况 | 怎么做 |
|---|---|
| 包需要的版本云端有 | 包的环境任务 `skip_if_cmd` 检查通过，直接判完成，不开窗。 |
| 云端版本不够（包写了环境任务） | 环境任务的窗**新建**隔离环境（新目录、新 venv/conda 环境），装完跑冒烟，把解释器路径写进包规定的环境文件。依赖它的任务之后才就绪。**绝不在现有环境里升级、降级、删包。** |
| 装不上（网络、编译） | 环境任务报受阻（`attention` 写清两个选项），研究者决定。依赖它的任务按 `if_fail` 预案处理，或跳过。 |
| 包没写环境任务、跑起来才发现版本不对 | 修复窗报受阻。主窗：<br>1. `orchd.py add` 一个环境任务（`cpu-agent`，`prio_boost` 高）；<br>2. `dep --add` 让相关任务依赖它；<br>3. 记 `skill_feedback.py add --kind gap`，下一版包补上。 |

## 7 写任务包（研究者一侧）

全文见 `references/package-contract.md`。最要紧的十条：

1. 能脚本化的都写成 job。要判断的才写 agent。
2. 每个 GPU 任务把所有能用的档都写进 `gpu_options`：
   - 一组独立的格用 `cellrun.py`，1/2/4/8 卡都能跑（R35）；
   - 单个大运行按 `$ORCH_NGPU` 设并行度。
3. 依赖只写真正的强制依赖（`deps`）。“有什么交什么”的写 `after`。
4. 计时类写资源令牌（`machine:x`、`hostbw:x`）。计时的格不能同时跑：`--max-par 1` 或 `strict_tier`。
5. 让“真开始”可判：
   - 写 `progress`，或在第一步算完时 `touch "$ORCH_STARTED"`；
   - `warmup_s` 设成加载时间的 2–3 倍。
6. 每个 job 有 `done_check`。能续跑：已完成的格跳过（cellrun 自带）。
7. 门控判定写成 `cpu-job`，用 `after`，没数据判保守的一支。主线和备选都写进 manifest。
8. 预案：
   - 可选或探索性任务写 `if_fail: "drop"`；
   - 照实交即可的写 `"accept"`；
   - 有备选方案的写备选任务（`fallback_for`），下游写 `"主|备"`；
   - 研究方向性的不写预案（交主窗与研究者）。
9. 需要新版本的写环境任务（`skip_if_cmd` 检查现状，`prio_boost` 高）。
10. 包自己的环境变量写 `run_env`，子窗规则写 `brief.rules`。skill 不认识任何包的变量名（R33）。

## 8 改 skill（以后一直要做）

- **问题怎么记、怎么交、怎么出升级包、怎么装**：`references/evolution.md`。
- **运行中不改 skill**（R29）；紧急热修按 evolution 第 3 节。

改 orchd 前先读懂结构。`scripts/orchd.py` 的 `tick()` 按顺序做：

1. 外部事实；
2. 包装进程退出 → 收尾（成功、失败、重试、抢占）；
3. agent 任务的报告；
4. `done_if`、`skip_if_cmd`、依赖与门控 → wait / ready / skipped，并传播跳过；
5. 用卡核查与启动确认（`confirm_start`、`start_evidence`）；
   - 5b. 全局保护（磁盘、暂停、掉卡、超时）；
6. 空卡与锁；
7. 分配：CPU 任务 → GPU 任务（启动保护、抢占）→ 带令牌的 CPU 任务；
8. 空卡原因与 `idle_waste`；
9. 卡时账；
10. 子窗的 hooks 事件（`scan_hook_events`：会话号、这一轮结束、接口失败、压缩）；判断窗与跟进窗（`judge_windows`）；自动派窗（`auto_windows` 的 a–j 节：开关窗结果、工作窗（含 resume）、报告与修复、验收、发消息、收残留、关窗、子窗看护、接口失败）；关掉做完了的窗（`close_ready_windows`）。

优先级在第 7 步开头由 `priorities()` 算（里程碑与 `waiting_human` 的分量、正加成向上游传），启动保护的“有下游链”由 `strict_fanout()` 与 `feeds_human()` 判。主窗的等待是独立的 `cmd_wait()`，只读状态与事件文件，不加锁改任何东西。

`cellrun.py` 是独立脚本，只通过 `orchd.py shrink` 和 orchd 交互。

改动的硬规矩：

- 每一处改动都要有能失败的测试，加进 `tests/orchd_sim.py`：
  - 用假 nvidia-smi `fake_smi.py`、假实验 `fake_job.py`、假 tmux、假 winctl；
  - 每组一个函数，加进 `main()` 的列表。
- 改完全量跑一遍（约 8 分钟），必须全过。
- 文档与代码同步改：SKILL.md 的规则、本手册、`references/orchd.md` 的命令表。
- 版本号规则与升级包格式见 evolution 第 4–5 节。不在真机上验证过的，写进升级包 README 的“没验证的”。

## 9 Prompt 怎么用

| Prompt | 什么时候 | 在哪 |
|---|---|---|
| 主窗调用 Prompt | 每个任务包开工时发给主窗：第一节由任务包填好（包路径、版本、任务目录、会话名、交付目录、特别提醒），其余几节通用 | 任务包 `skill/P-主窗调用.md`；通用骨架 `@ORCH_HOME@/skill/multiagent.md` |
| P1 压缩恢复 | 主窗上下文被压缩后，研究者发给主窗（或主窗自己照做） | 升级包 `prompts/P1-压缩恢复.md` |
| P2 判断窗 | 主窗要判断一件事时，照它写 `orchd.py judge` 的 `--question` | 升级包 `prompts/P2-判断窗.md` |
| P3 临时加任务、改计划 | 研究者临时要加、取消、提前一个任务 | 升级包 `prompts/P3-临时加任务.md` |
| P-skill 升级 | 装 skill 升级包 | 升级包 `prompts/P-skill升级.md` |

Prompt 以后怎么改：

- 通用的规则改 skill（SKILL.md 与本手册），不写进 Prompt；
- Prompt 只放每次都要提醒的几件事和本包的输入项；
- 每个任务包重新填第一节；
- Prompt 的改动记进任务包 `skill/优化记录.md`。

## 10 常见问答

- **为什么有空卡？**
  - 先看 `orchd.py status` 每张空卡的原因。只允许五类：启动保护凑卡、令牌等待、余卡不够、没有就绪任务、暂停启动。“可避免”大于 0 就开判断窗。
  - “没有就绪任务”多了，说明包的依赖链太串行，下一版包要拆格、加档位。
- **为什么某任务一直不开跑？** 看 `status` 里它那一行的原因，例如“启动保护：先让 X 起跑”“资源令牌冲突”“余卡不足：最少要 4 张”“等依赖”。
- **估计时间要不要写？** 不用。`gpu_options` 的值只是档位偏好。调度只看优先级与强制依赖。`progress` 推算的剩余时间只给看板看。
- **任务提前结束或拖很久，会不会打乱安排？** 不会。每 3 秒按实时状态重排，没有“计划”可以被打乱。
- **3 秒一轮会不会让上下文变长？** 不会。3 秒一轮在 orchd 里，是脚本，不经过模型。会进上下文的只有主窗每次醒来的十几行，以及子窗自己做事的记录（第 5.5 节）。
- **关了的窗还能接着用吗？** 能。会话号记在 `notes/sessions.jsonl` 和上下文卡里：`orchd.py reopen` 或 `winctl.sh open <新窗> <任务书> --resume <会话号>`。
- **主窗可以自己看日志吗？** 不可以（R22）。要了解就开判断窗，只看结论。

## 11 借鉴 DeepSeek SuperAgent 的对照

来源：`deepseek-ai/dsh-superagent-prototype`（MIT，commit `8c32a9dc`，2026-10-31）的 `docs/000–008` 与 `prompts/`，只阅读、没运行。

| SuperAgent 的做法 | 2.0.0 里对应的做法 | 在哪 |
|---|---|---|
| 三个角色：host 存状态、执行确定性的工作；main Session 只路由、不做技术决定、不加实现计划；每个 Ticket 一个 Executor Session | orchd（脚本，唯一写状态）；主窗只掌控全局；一事一窗的子窗 | R22、R05、R26 |
| 主会话不等待：报告、通知、后台任务结束都会自己作为消息到来；有守卫拒绝 `sleep`、超过 30 秒的命令和超过 5 秒的等待 | 主窗只挂 `orchd.py wait`，有事才返回；不 sleep、不 ScheduleWakeup、不轮询 | R11、第 4.1 节 |
| relay（叫醒主会话：worker_report、worker_attention、跟进）与 notice（注入但不叫醒：ticket_ended 等）两分 | wait 只为要处理的事返回；任务结束、预案、门控、里程碑只进下次醒来的摘要 | `cmd_wait`、`WAKE_NOTICE_KINDS` |
| 普通进展留在 Ticket 上，只有问题与报告上送；报告摘要 600 字，超了给读取指针 | 进展写上下文卡；report 的 summary ≤ 600 字加证据路径 | brief.py 第 4 节 |
| 一次只问一个具体问题（human_action），主会话原样转达；已授权的工作照常继续 | `orchd.py ask` / report 的 `attention`；主窗原话转研究者；子窗先做不依赖它的部分 | R19、第 4.1 节 |
| 执行会话按 Ticket 保留；空闲的 Ticket 由新消息继续；重试用同一个执行会话；被打断的 Assignment 带恢复说明重启 | 记下每扇窗的会话号；窗消失、key 失效、重试都 `--resume` 原会话并带一句恢复说明；做完的任务要追问用 `orchd.py reopen` | R26、第 5.5 节 |
| 名额（worker slot）只在干活时占：交给人之后立刻释放；上限之外留一个名额给人的消息；唤醒优先于新启动 | 做完就关窗、收 key（会话还在）；`max_windows` 之外留一个人工槽位；预留了卡的任务先开窗 | R26、auto_windows (b) |
| 一轮结束时后台还有工作就不算“在等”，不报给主会话 | 子窗的 Stop 事件由 orchd 读，不叫醒主窗；后台跑的实验照常 | `scan_hook_events` |
| 投递失败按 2 秒起、翻倍到 1 分钟重试；同一效果连败 3 次报健康问题 | 子窗这一轮因限流中断，按 60 秒起翻倍（最多 15 分钟）后让它接着做；连败 4 次升级 | `api_failures` |
| 执行者无人值守：去掉会问人、弹界面的工具 | 子窗 `--disallowedTools AskUserQuestion` | R07 |
| 路由不改写请求：执行者读原始来源（任务原文 1500 字 + 来源卡片） | 任务书按固定几节拼：共同规则、包的规定、路线卡与 manifest 条目原文、环境、交接 | brief.py |
| 人的暂停在跟进、新会话、重启之后都有效 | `hold`、`config --set paused=…` 存在 orchd 状态里，重启不丢 | 第 6.1、6.2 节 |
| 面板只显示要人处理的东西，健康时不占地方 | wait 健康时只打印一行；看板首页先列告警与要决定的事 | `cmd_wait`、看板 |

没有照搬的部分：

- 来源、触发、线程、准入策略：它接的是 GitHub、飞书上的请求。我们的任务都写在任务包里，研究者临时的要求走 Prompt P3。
- 合并 PR 一类的交付规则。
- “前台命令 5 秒后自动转后台”：这是它自己的执行框架的功能，Claude Code 没有。改为在任务书里要求长命令用 `run_in_background`。

### 11.2 结合 Claude Code 自己的特性（云端是最新版的 Claude Code）

SuperAgent 跑在 DeepSeek Harness 里，靠框架自带的会话、收件箱、后台任务。我们把同样的思路落在 Claude Code 已有的能力上，不自己造：

| SuperAgent 靠的 | Claude Code 里对应的能力 | 2.0.0 怎么用 |
|---|---|---|
| 主会话收到“消息”才动 | Bash 的 `run_in_background`：后台命令结束时会话被重新唤起，等待期间不花 token | 主窗唯一的等待 `orchd.py wait` 就是一个后台命令 |
| 执行会话持久、可续 | `claude --session-id <uuid>`、`--resume <id>`、`--fork-session`；会话记录在 `~/.claude/projects/<目录>/<会话>.jsonl` | winctl 开窗指定会话号，重开、重试、追问都 resume |
| 框架上报“这一轮结束”“出错了” | hooks：`Stop`、`StopFailure`、`PreCompact`、`SessionStart(compact/resume)`、`Notification`、`SessionEnd`（1.7.0 已装 `orch_hook.py`） | orchd 读这些事件：何时能关窗、限流与 key 失效、压缩次数、会话号 |
| 执行者不问人 | `--disallowedTools AskUserQuestion` | 子窗都带；要问用 `orchd.py ask` |
| 每个会话的模型与权限预设 | `--settings <文件>`（key_window 按档位写好）、`--permission-mode` | 每窗一把 key、按 `tier` 选档位 |
| 子任务并行读 | 原生子 agent（`Agent` 工具，`model` 不写，继承网关模型） | R30：只在窗内做只读分析 |
| 上下文治理 | 自动压缩（预设里的 `CLAUDE_AUTOCOMPACT_PCT_OVERRIDE` 等）、`/compact` | 主窗少醒、子窗一事一窗、resume 有上限；压缩后先重读任务书与上下文卡 |

### 11.3 下一版候选（还没做，记在这里，等真机回传再定）

| 候选 | 借鉴自 | 能带来什么 | 为什么这一版没做 |
|---|---|---|---|
| 判断窗、跟进窗、验收窗改用无界面模式：`claude -p --resume <id> --output-format stream-json`，不开 tmux 窗 | SuperAgent 的执行会话由宿主直接驱动 | 不用抓屏、不用补 Enter；这一轮的结束与结果都是确定的；不占 tmux 窗与人工槽位 | 云端网关与 key 池在无界面模式下的行为、hooks 是否照常触发，都没在真机上验证过；工作窗要长时间跑实验，仍用 tmux 窗 |
| 子窗压缩后自动注入恢复卡（`SessionStart` 的 compact 钩子，像主窗的 `restore_card.py` 那样） | SuperAgent：被打断的工作带恢复说明重启 | 压缩后子窗不用自己记得去重读任务书 | 要改 1.7.0 的钩子脚本，先看回传里子窗压缩了几次 |
| 主窗的 `orchd.py wait` 用 hooks 的事件直接触发，代替 2 秒一看 | SuperAgent 的收件箱 | 更省一点 CPU | 2 秒一看已经不花 token，收益小 |
| 子窗之间的“一句话通知”（≤100 字的事实，不授权） | SuperAgent 的 `note` | 例如 Q0 发现计时口径问题时直接告诉 G2 的窗 | 现在由主窗用 `winctl.sh send` 转，够用 |
