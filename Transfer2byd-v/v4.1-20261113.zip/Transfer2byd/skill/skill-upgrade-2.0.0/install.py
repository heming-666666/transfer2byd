#!/usr/bin/env python3
"""把 multi-agent-orchestrator 从 1.7.0 升到 2.0.0（只加不删，先备份，可回滚）。

用法:
  python3 -I install.py --home <本机用户目录> [--dry-run] [--force] [--skip-tests]
    --home       skill 装在 <home>/.claude/skills/multi-agent-orchestrator/、附加件在 <home>/skill/skill-addons/orch-v1/
                 的那个目录（例：/data/<user>）。所有新文件里的 @ORCH_HOME@ 会写成它。
    --dry-run    只打印要做什么，不写任何文件
    --force      现有 SKILL.md 不是 1.7.0 也继续（默认停下）
    --skip-tests 不跑测试（不建议）

做什么（按顺序；任何一步失败就停，已写的文件可用备份回滚）:
  1. 核对现有版本（SKILL.md 的 version: 1.7.0）与必须存在的文件
  2. 备份：<home>/skill/archive/multi-agent-orchestrator-pre-2.0.0-<时间>.tar.gz
     （skill 目录全部 + 附加件 wait_event.py + 两份 multiagent.md）
  3. 写新文件与整文件替换（files/ 下的全部，@ORCH_HOME@ 换成 --home）
  4. 追加 2.0.0 一节到 references/{rules,pitfalls,env,scripts}.md（已追加过就跳过）
  5. 原位修改附加件 wait_event.py 两处（找不到原文就报错、不改）
  6. 调用 Prompt 同时写 <home>/skill/multiagent.md 与 <home>/multiagent.md（两份副本，1.5.1 起的约定）
  7. 跑测试：tests/orchd_sim.py（必须全过，2.0.0 是 192/192）、tests/gates.sh、tests/gates_sched.sh、附加件 tests/selftest.sh
  8. 写安装记录 <home>/skill/archive/install-2.0.0-<时间>.log
退出码：0 成功；1 失败（看最后一行）；2 用法错。
回滚：tar xzf <备份> -C /   （备份里存的是绝对路径）
"""
import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import tarfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN = "@ORCH_HOME@"
APPENDS = {"rules.md.append": "references/rules.md", "pitfalls.md.append": "references/pitfalls.md",
           "env.md.append": "references/env.md", "scripts.md.append": "references/scripts.md",
           "watch.md.append": "references/watch.md", "task-flow.md.append": "references/task-flow.md",
           "usage-prompts.md.append": "references/usage-prompts.md", "windows-and-keys.md.append": "references/windows-and-keys.md"}
WAIT_PATCH = [
    ('DEFAULT = "Stop,StopFailure,SessionEnd,Notification,orch_alert"',
     'DEFAULT = "Stop,StopFailure,SessionEnd,Notification,orch_alert,orch_sched,orch_attention,orch_result"'),
    ('for k in ("notification_type", "error", "error_type", "source", "trigger"):',
     'for k in ("notification_type", "error", "error_type", "source", "trigger", "kind", "task", "msg"):'),
]
EXEC_BITS = ("scripts/orchd.py", "scripts/winctl.sh", "scripts/brief.py", "scripts/skill_feedback.py", "scripts/cellrun.py",
             "tests/orchd_sim.py",
             "tests/fake_smi.py", "tests/fake_job.py", "tests/fake_tmux.sh", "tests/fake_winctl.py")

log_lines = []

def passfail(line):
    """从测试最后一行取（通过数, 失败数）；取不到返回 (None, None)。"""
    import re
    m = re.search(r"(\d+)\s*通过[，, ]*\s*(\d+)\s*失败", line)
    return (int(m.group(1)), int(m.group(2))) if m else (None, None)

def say(msg):
    print(msg, flush=True)
    log_lines.append(msg)

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        h.update(f.read())
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--home", required=True)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--skip-tests", action="store_true")
    a = ap.parse_args()
    home = os.path.abspath(a.home)
    skill = os.path.join(home, ".claude", "skills", "multi-agent-orchestrator")
    addons = os.path.join(home, "skill", "skill-addons", "orch-v1")
    arch = os.path.join(home, "skill", "archive")
    stamp = time.strftime("%Y%m%d-%H%M%S")

    # 1 核对
    sk = os.path.join(skill, "SKILL.md")
    if not os.path.isfile(sk):
        say("FAIL 找不到 %s（--home 写错了？）" % sk)
        return 1
    ver = next((l.split(":", 1)[1].strip() for l in open(sk, encoding="utf-8") if l.startswith("version:")), "?")
    say("现有版本：%s" % ver)
    if ver == "2.0.0" and not a.force:
        say("已经是 2.0.0；要重装加 --force")
        return 0
    if ver != "1.7.0" and not a.force:
        say("FAIL 现有版本不是 1.7.0；本升级包按 1.7.0 写，确认后加 --force")
        return 1
    need = [os.path.join(addons, "scripts", "wait_event.py"), os.path.join(addons, "scripts", "facts.py"),
            os.path.join(addons, "scripts", "winstate.py")] + [os.path.join(skill, v) for v in APPENDS.values()]
    miss = [p for p in need if not os.path.isfile(p)]
    if miss:
        say("FAIL 缺文件：%s" % miss)
        return 1

    # 2 备份
    bak = os.path.join(arch, "multi-agent-orchestrator-pre-2.0.0-%s.tar.gz" % stamp)
    if a.dry_run:
        say("[dry-run] 备份到 %s" % bak)
    else:
        os.makedirs(arch, exist_ok=True)
        with tarfile.open(bak, "w:gz") as t:
            t.add(skill)
            t.add(os.path.join(addons, "scripts", "wait_event.py"))
            for p in (os.path.join(home, "skill", "multiagent.md"), os.path.join(home, "multiagent.md")):
                if os.path.isfile(p):
                    t.add(p)
        say("备份：%s" % bak)

    # 2.5 升级前先跑一遍旧测试，记下基线（升级后不得变差）
    legacy = [["bash", os.path.join(skill, "tests", "gates.sh")],
              ["bash", os.path.join(skill, "tests", "gates_sched.sh")],
              ["bash", os.path.join(addons, "tests", "selftest.sh")]]
    base = {}
    if not a.dry_run and not a.skip_tests:
        for cmd in legacy:
            if os.path.isfile(cmd[-1]):
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800, cwd=home)
                base[cmd[-1]] = (r.returncode, passfail((r.stdout.strip().splitlines() or [""])[-1]))
                say("升级前基线 %s -> rc=%d %s" % (os.path.basename(cmd[-1]), r.returncode, base[cmd[-1]][1]))

    # 3 新文件与整文件替换
    src_root = os.path.join(HERE, "files")
    written = []
    for dp, dns, fns in os.walk(src_root):
        dns[:] = [d for d in dns if d != "__pycache__"]          # 包自测导入过 orchd 会留下字节码缓存，不装
        for fn in fns:
            src = os.path.join(dp, fn)
            rel = os.path.relpath(src, src_root)
            if rel == os.path.join("skill", "multiagent.md") or fn.endswith(".pyc"):
                continue
            dst = os.path.join(home, rel)
            text = open(src, encoding="utf-8").read().replace(TOKEN, home)
            if a.dry_run:
                say("[dry-run] 写 %s（%s）" % (dst, "替换" if os.path.exists(dst) else "新建"))
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with open(dst, "w", encoding="utf-8", newline="") as f:
                f.write(text)
            if any(rel.endswith(x) for x in EXEC_BITS):
                os.chmod(dst, 0o755)
            written.append(dst)
    say("写入 %d 个文件" % len(written))

    # 4 追加
    for fn, rel in APPENDS.items():
        dst = os.path.join(skill, rel)
        add = open(os.path.join(HERE, "appends", fn), encoding="utf-8").read().replace(TOKEN, home)
        cur = open(dst, encoding="utf-8").read()
        first = add.strip().splitlines()[0]
        if first in cur:
            say("跳过追加（已有）：%s" % rel)
            continue
        if a.dry_run:
            say("[dry-run] 追加到 %s：%s" % (rel, first))
            continue
        with open(dst, "a", encoding="utf-8") as f:
            f.write(("" if cur.endswith("\n") else "\n") + add)
        say("已追加：%s" % rel)

    # 5 wait_event.py
    we = os.path.join(addons, "scripts", "wait_event.py")
    s = open(we, encoding="utf-8").read()
    for old, new in WAIT_PATCH:
        if new in s:
            continue
        if old not in s:
            say("FAIL wait_event.py 里找不到原文：%s（没改；请人工核对后照 HANDOFF.md 手改）" % old)
            return 1
        s = s.replace(old, new)
    if a.dry_run:
        say("[dry-run] 改 wait_event.py 两处")
    else:
        with open(we, "w", encoding="utf-8", newline="") as f:
            f.write(s)
        say("已改 wait_event.py（默认事件加 orch_sched；打印 kind/task/msg）")

    # 6 调用 Prompt 两份副本
    pm = open(os.path.join(src_root, "skill", "multiagent.md"), encoding="utf-8").read().replace(TOKEN, home)
    for dst in (os.path.join(home, "skill", "multiagent.md"), os.path.join(home, "multiagent.md")):
        if a.dry_run:
            say("[dry-run] 写调用 Prompt %s" % dst)
            continue
        with open(dst, "w", encoding="utf-8", newline="") as f:
            f.write(pm)
    if not a.dry_run:
        say("调用 Prompt 两份副本 sha256 %s" % sha(os.path.join(home, "multiagent.md"))[:12])

    # 7 测试
    ok = True
    if not a.dry_run and not a.skip_tests:
        r = subprocess.run([sys.executable, "-I", os.path.join(skill, "tests", "orchd_sim.py")], capture_output=True,
                           text=True, timeout=1800)
        last = (r.stdout.strip().splitlines() or [""])[-1]
        good = r.returncode == 0 and "ORCHD SIM OK" in last
        ok = ok and good
        say("%s orchd_sim.py -> rc=%d  %s" % ("PASS" if good else "FAIL", r.returncode, last[:160]))
        for cmd in legacy:
            if not os.path.isfile(cmd[-1]):
                say("跳过（不存在）：%s" % cmd[-1])
                continue
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800, cwd=home)
            pf = passfail((r.stdout.strip().splitlines() or [""])[-1])
            b = base.get(cmd[-1])
            # 判据：退出码 0；或与升级前完全一样（本机环境本来就过不了的项，不算升级引入）
            good = r.returncode == 0 or (b is not None and pf == b[1] and pf[1] is not None)
            ok = ok and good
            say("%s %s -> rc=%d %s（升级前 %s）" % ("PASS" if good else "FAIL", os.path.basename(cmd[-1]), r.returncode,
                                                  pf, b[1] if b else "无基线"))
    # 8 记录
    if not a.dry_run:
        lp = os.path.join(arch, "install-2.0.0-%s.log" % stamp)
        with open(lp, "w", encoding="utf-8") as f:
            f.write("\n".join(log_lines) + "\n")
        print("安装记录：%s" % lp)
    if not ok:
        say("FAIL 有测试没过：先别用 2.0.0，按上面的输出排查，或回滚：tar xzf %s -C /" % bak)
        return 1
    say("OK 已升级到 2.0.0" + ("（dry-run，未写任何文件）" if a.dry_run else "；回滚：tar xzf %s -C /" % bak))
    return 0

if __name__ == "__main__":
    sys.exit(main())
