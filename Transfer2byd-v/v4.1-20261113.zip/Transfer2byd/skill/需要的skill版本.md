# 本包需要的 skill 版本

**multi-agent-orchestrator ≥ 2.0.0**

## 为什么

本包的 `state/manifest.json` 是 `orch-manifest/2`，靠 2.0.0 新增的 `orchd.py` 执行。用到的功能：

- 调度：动态调度（优先级 + 强制依赖，不用预计时长）、`done_if`（v4 已完成的任务自动判完成）、`after`（前序结束就放行）、门控变体（门 BW 只放行一支）、资源令牌（`machine:x`、`hostbw:x/s`）、端口段（`ORCH_PORT_BASE`）；
- 启动与执行：启动确认、`skip_if_cmd` 环境任务（V41-ENV）、`cellrun.py`（P2 按租到的卡并行跑格）、自动派窗；
- 优先级：里程碑（`kind: milestone`，M-GATEP 等五个）、`after` 先验证再正式、`tier`/`tier_by_kind` 窗的模型档位；
- 窗与上下文：主窗的 `orchd.py wait`、子窗会话号与 `--resume`、`orchd.py reopen`；
- 异常预案：`if_fail`；
- 核查与卡时账。

1.7.0 没有这些，照 1.7.0 的流程跑会出现 v4 的那些问题：两套锁、端口冲突、整机独占、空转不报。

## 怎么查

```bash
head -5 <本机用户目录>/.claude/skills/multi-agent-orchestrator/SKILL.md      # 要看到 version: 2.0.0
python3 -I <本机用户目录>/.claude/skills/multi-agent-orchestrator/scripts/orchd.py help | head -2
python3 -I <本机用户目录>/.claude/skills/multi-agent-orchestrator/tests/orchd_sim.py | tail -1    # ORCHD SIM OK 192/192（约 8 分钟）
python3 -I <本机用户目录>/.claude/skills/multi-agent-orchestrator/scripts/cellrun.py 2>&1 | head -2  # 打印用法
```

## 不够时

照 `skill-upgrade-2.0.0/UPGRADE.md` 升级（`install.py` 先备份再装，测试不过会提示回滚）。升级只认 1.7.0 起步；现有版本不是 1.7.0（更早或被改过）时安装器会停下，把它的输出交研究者。

## 能不能先用 1.7.0 跑这个包

不建议。真要先跑（例如升级的上线冒烟没过、等研究者修）：只跑 `gpu-job` 类的探针（P3、P2–P5），按 `state/tasks.yaml` 的卡数手工用 `ledger.sh` 分卡，**一次只跑一个计时探针**（相当于门 BW = fail 的串行变体），在 00 里写明“以 1.7.0 手工执行”。agent 类任务等升级后再做。
