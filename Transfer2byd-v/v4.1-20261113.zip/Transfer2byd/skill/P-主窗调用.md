# 主窗调用 Prompt（skill 2.0.0；第一节已按 v4.1 包填好，其余各节是 skill 的通用骨架）

> 用法：
>
> - 把全文的 `@ORCH_HOME@` 换成本机用户目录（例：`/data/<user>`），整份发给主窗。
> - skill 装好后，`<本机用户目录>/skill/multiagent.md` 是通用骨架（第一节是空的）。以后每个任务包都带一份像本文件这样填好第一节的 Prompt。
> - 第二至六节与骨架逐字相同；要改通用部分就改 skill，不改这里（skill 升级包的 `prompts/PROMPTS.md`）。

请使用 multi-agent-orchestrator skill 执行以下任务。

- skill 路径：`@ORCH_HOME@/.claude/skills/multi-agent-orchestrator/SKILL.md`。开跑前先读全；版本必须 ≥ 第一节写的最低版本，`python3 -I $S/orchd.py help` 能打印才算装好。
- 优先级按 skill 的 R02：安全硬约束 > 任务包自带的执行规则（包内 `AGENTS.md`、`docs/`、路线卡、`state/manifest.json`）> 本 Prompt 的输入项 > 本 skill 的其他默认做法。
- 认为某条规则在当前情况下明显不合理时，**先照规则做**，再在汇报第一行写「需要你决定：……」，不许自行改判。
- 路径前缀：`S=@ORCH_HOME@/.claude/skills/multi-agent-orchestrator/scripts`；`A=@ORCH_HOME@/skill/skill-addons/orch-v1/scripts`。

## 一、本轮任务与任务包（每个任务包重填这一节）

- 任务包：`@ORCH_HOME@/paper/opd/raw-zip/v4.1-20261113.zip`，VERSION = `v4.1 2026-11-13`。解压到 `@ORCH_HOME@/paper/opd/Transfer2byd-unpacked/Transfer2byd-v4.1-unpacked/`（记作 `PKG`），解压后设只读。
- 任务目录（记作 `TD`）：`@ORCH_HOME@/paper/opd/Transfer2byd-unpacked/Transfer2byd-v4.1-unpacked/orch-v4.1-20261113/`。与 `orch-v4-20261112` 并列，不覆盖、不改写。
- 运行根（记作 `RT`）：`$OPD_RUNTIME=@ORCH_HOME@/opd-runtime`。v4.1 是 v4 的补完包，**结果继续写 `results/v4/`**：启动器按大版本取目录，每次运行新建 run 目录，不覆盖 v4 已有的运行。
- tmux 会话（记作 `SES`）：`paper-v41`；子窗工作目录 `@ORCH_HOME@`。
- 本机交付目录：`@ORCH_HOME@/paper/opd/Transfer2me/Transfer2me-v4.1`。
- 最低 skill 版本：`2.0.0`。不够时先照 `PKG/skill/需要的skill版本.md` 升级：另开一个窗，任务书是 `PKG/skill/skill-upgrade-2.0.0/prompts/P-skill升级.md`；升级报告交给我之后再开工。照 `skill/P0-怎么开始.md` 开工的，第 2 步已经升好，这里只核对版本。
- 版本校验：解压后先读 `VERSION` 与 `CHANGELOG.md`，与上面写的不一致时先告诉我，不许自己判断。
- 本轮特别提醒：
  1. **v4 做过的实验，哪些不用再做**（v4 的部分回传，研究者已核对；结果都在 `$OPD_RUNTIME/results/v4/`）：

     | 任务 | v4 的结果 | v4.1 怎么办 |
     |---|---|---|
     | V4-0 环境清点、云端脚本冻结 | 完成 | **不做**：orchd 按 `done_if` 自动判完成 |
     | V4-P1 教师池三种放法 | 完成（M 臂峰值 K1→K3 涨 15.6%，超过预设的 10%，照实记录） | **不做** |
     | V4-NT 真正关掉思考 | 完成、有效 | **不做** |
     | V4-G1 学生引擎单卡上限 | 完成（5.02 倍） | **不做** |
     | V4-E 三方等价 | 完成 | **不做** |
     | V4-R 基线复现 | R2-a 换种子（相对差 0.05–3.0%）、R2-c 编排等价（0.83%）、R1-a 20 步都完成；R1-a 第 4 条（GSM8K）没过 | **不重跑**；第 4 条由新任务 V41-R1b 补测；正确性门由 V41-Q0 做 |
     | V4-P5 生成尾部 | 不完整（两次运行都是 partial） | **补跑完整一次**：脚本只认 `run.json` 里 status=ok 的运行，partial 的不算 |
     | V4-F 少卡可行性 | 预检做了一部分（S/M 逐位一致、N=1 R 显存不够有记录），8 格里 7 格没跑 | **重做**：V4-Fp（预检）与 V4-Ft（计时臂）。v4 留下的 `results/v4/V4-F/00-summary.md` 是部分结果，不算完成；已有的记录（swap_bench 的 S/M 逐位一致；N=1 R 那一格的 OOM）直接引用，不重测；其余 7 格照 `routes/V4-F` 跑（V4-F 是要判断的任务，这一条由子窗照做，不是脚本自动跳过） |
     | V4-P2、P3、P4 | 没跑 | **做** |
     | V4-G2、G3、F8、Q | 没跑 | **做** |
     | V4-L、V4-T（可选） | 没跑 | 有空卡才做 |

     判定规则：只有上表前六个任务按 `done_if` 证据自动判完成。如果第一次 `health` 里它们不是 done，说明证据文件不在原处：**先告诉我，不要重跑**。其余任务一律按 v4.1 重新跑，结果另起运行目录，不覆盖 v4 的。
  2. **窗与等待**：后台只挂 `orchd.py wait`（不要 sleep）；子窗做完会自己关、会话号记下，要追问做完的任务用 `orchd.py reopen`。研究者在等的是小回传 v4a（里程碑 M-GATEP）：探针排在最前。
  3. **环境任务 V41-ENV**：现有环境满足（`scripts/pkg/env_ok.py`）就几秒内自动完成，所有 GPU 任务随即就绪。没有自动完成时 orchd 会开环境窗（`routes/V41` 第 8 节，只新建隔离环境、不改现有环境）；它要我决定时原话转给我。
  4. 本包的 `state/manifest.json` 是 orch-manifest/2，直接 `orchd.py init`。覆盖表由 `facts.py render` 从事实流生成，不手工建。异常预案在 `routes/V41-总览与门控.md` 第 9 节：探针修不好照实交，可选任务修不好放弃，核心任务交你与我。
  5. **回传两次**：小回传 v4a（`docs/25`，P2–P5 做完就交）与完整回传（`docs/06`、`07`）。两次都附 `14-detours.md`（弯路记录）、`15-gpu-util.csv`（卡时账，`scripts/v41/util_report.py` 生成）、`16-skill-issues.md`（skill 问题，`skill_feedback.py export`）。

## 二、开工（通用）

照 skill 的 `references/main-loop.md` 第 1 节逐条做：

1. 版本校验；
2. 写 `TD/notes/orch.env`（写了它 orchd 就自动派窗）与 `checks.json`；
3. `orchd.py init --td $TD --manifest $PKG/state/manifest.json --pkg $PKG --runtime $RT --lockdir @ORCH_HOME@/Benchmark/_overnight/gpu_locks --session $SES`，`--lockdir` 与 `tools/gpu_lock.sh` 同一个目录；
4. 在 tmux 窗 `orchd` 用 1.4 节带自动重启的命令起守护；
5. 覆盖表与扫描；
6. 看板（照包内说明）；
7. `orchd.py health` 退 0，再在后台挂上 `orchd.py wait`（第三节），才算开工完成。

开工后，全脚本化的任务由 orchd 自己跑，要判断的任务由 orchd 自动开窗承接，**你不派任何任务**。

## 三、你只掌控全局（通用，R22、R31）

1. **唯一的等待**（Bash `run_in_background`，同一时刻只挂一个）：`python3 -I $S/orchd.py wait --td $TD`。巡检在它里面每分钟做一次，不进你的上下文；它只在有事时返回，只打印十几行。**不要 `sleep`、不要 ScheduleWakeup、不要自己定时去看**（旧的 10–180 秒睡眠区间只适用于没有 orchd 的手工模式）。
2. **它返回时**按退出码做：
   - 退 3（定时汇报，没事）：不用汇报，直接重挂；
   - 退 2（守护没在跑）：照 `references/main-loop.md` 1.4 重起守护（不要 init），重挂；
   - 退 0 或 1：逐条照它写的办法与 `references/manual.md` 第 6 节的表处理。处理完 `orch_check.py`，`orchd.py ack` 处理过的告警，重挂。
3. **要判断的事**开判断窗，不自己读证据：`python3 -I $S/orchd.py judge --td $TD <短名> --question "<告警原文>；请判断……并给出完整命令" [--about <任务>]`。它交结论时会叫醒你。
4. **子窗要我决定的问题**（`orch_attention`）原话转给我，附窗名与任务号，不改写、不替我答。我答了就 `winctl.sh send <窗> "研究者答复：<原话>"`。
5. **结果就绪**（输出里的 `[结果就绪]`）一句话告诉我。我追问某个做完的任务时：`python3 -I $S/orchd.py reopen --td $TD <任务> --question "<我的原话>"`，它会接着那个任务的原会话回答。
6. **不做**：
   - 读日志全文与子窗对话、排障、改代码、跑实验、挑卡、手设 `CUDA_VISIBLE_DEVICES`；
   - 手写任务书、手工开关工作窗、`sleep` 轮询；
   - kill 进程（只在第 6 节的表让你停时用 `orchd.py kill <任务>`）。
7. **核实真在用卡**（R24、R34）：汇报里写“在跑”的任务核查必须是 `ok`，并且已确认真开始（有启动用时）；空卡只允许是 `util` 列出的五类正常原因。

## 四、异常与变更（通用，R36）

- 先看任务包有没有写预案（`if_fail`、`fallback_for`、门控分支）。有就由 orchd 照做，你只告诉我结果。
- 运行中改计划只用 orchd 的命令：`drop`、`add`、`dep`、`prio`、`edit`、`cordon`、`config`、`hold`、`accept`、`retry`。
  - 每条都写 `--reason`；orchd 会记进 `notes/decisions.md`；
  - 会改变研究方向或取舍的（放弃核心任务、改主实验的配置），先问我。
- 表里没有的情况开判断窗，照它建议的完整命令做。拿不准就问我。

## 五、任务细节（通用）

1. **包只读、产出分开**：
   - 任务目录只放 `notes/`、`briefs/`、`output/`、`work/`；
   - 实验数据按包内规定写到运行根，不与旧版结果同名。
2. **接手不重建**：续跑或压缩恢复后按 skill 的 Prompt P1 做（restore_card → health → decisions），**不要重新 init**。守护心跳过期就按 `main-loop.md` 1.4 重起。
3. **包内脚本不改逻辑**：
   - 按包里的冒烟 → 正式推进，只改包内点名可调的参数，并记原值、新值与理由；
   - 环境不对时照包的环境任务新建隔离环境，绝不改现有环境（R32、R04）。
4. **弯路要记**：任何花了 10 分钟以上的非实验问题，子窗报告里写“现象 → 根因 → 解法 → 下次怎么避免”；回传时收进包规定的弯路文件。
5. **skill 本身的问题当场记**（R29）：`python3 -I $S/skill_feedback.py add --td $TD --kind <bug|rule|gap|doc|perf> --where <R编号或脚本> --symptom "<现象原文>"`。运行中不改 skill。

## 六、回传与汇报（通用）

- 回传规范**以包内为准**：回传规则、文件清单、自检脚本。本 Prompt 不重复文件清单。
- 回传前跑包自带检查器，把命令、退出码和最后几行原样贴进汇报。
- 每次回传都带三样，文件名照包内：
  - 卡时账：`orchd.py util --csv`，或包内的卡时账脚本；
  - 弯路记录；
  - skill 问题：`skill_feedback.py export` 生成，没有问题也交，写“无”。
- 包内分多次回传的，各次按包内规定的时点独立交，不合并、不互相等待。回传开独立承办窗、验收开独立验收窗，验收通过才交给我（R12、R20）。
- 汇报按 R19 的六行格式。第 3 行“用卡”必须有 `orchd.py util` 的数字：真在用、启动开销、空卡各类。
