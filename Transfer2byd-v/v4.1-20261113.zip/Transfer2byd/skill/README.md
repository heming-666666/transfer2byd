# skill/：本实验包要用的云端编排 skill（multi-agent-orchestrator）

> 从 v4.1 起，每个实验包都带这个目录（研究者 2026-11-13 的要求）：本包的主窗调用 Prompt、需要的 skill 版本、本轮 skill 的优化记录；skill 要升级时附完整升级包。云端 agent 照这里做就能把 skill 装对、用对、记下问题。

## 目录里有什么

| 文件 | 给谁 | 做什么 |
|---|---|---|
| `需要的skill版本.md` | 主窗开工前 | 本包要求 skill ≥ 2.0.0；怎么查版本；不够时怎么升级 |
| `skill-upgrade-2.0.0/` | 负责升级的窗（或研究者） | 升级包，内容如下 |
| `P0-怎么开始.md` | 研究者 | **从这里开始**：上传、开主窗、发给主窗的一段话（它会先升级 skill，再照 P-主窗调用.md 开工） |
| `P-主窗调用.md` | 研究者发给主窗 | 本包的主窗调用 Prompt：第一节已按 v4.1 填好，其余是 skill 的通用骨架 |

升级包 `skill-upgrade-2.0.0/` 里有：

| 文件 | 内容 |
|---|---|
| `README.md` | 是什么、怎么理解 |
| `MANUAL.md` | 完整使用手册，第 6 节是异常与变更怎么处理 |
| `REQUIREMENTS.md` | 研究者每条要求怎么做到、怎么验证 |
| `UPGRADE.md` | 逐条命令：dry-run → 安装 → 检查 → 上线冒烟 → 回滚 |
| `install.py` | 安装器：自动备份、升级前后对比测试 |
| `prompts/` | `P-skill升级`（升级任务书）、`P1-压缩恢复`、`P2-判断窗`、`P3-临时加任务`、`PROMPTS`（一览与以后怎么改） |
| `优化记录.md` | 研究者、云端 | 本轮 skill 改了什么、为什么、对应哪些问题、怎么验证、没验证什么、下一轮要收集什么 |

## 三步用法

> 最省事的走法：照 `P0-怎么开始.md` 做，只要发给主窗一段话。主窗自己查版本、需要时升级，再照 `P-主窗调用.md` 开工。下面三步是分开做的写法，结果相同。

1. **查版本**：`head -5 <本机用户目录>/.claude/skills/multi-agent-orchestrator/SKILL.md`。是 `version: 2.0.0` → 跳到第 3 步。
2. **升级**（只做一次）：另开一个窗，把 `skill-upgrade-2.0.0/prompts/P-skill升级.md` 分隔线之间的内容（填好尖括号）发给它。它照 `UPGRADE.md` 装好、跑测试、做约 15 分钟的上线冒烟、交报告。报告里有任何 `FAIL` → 它会回滚，先别开工，把报告交研究者。
3. **开工**：把本目录的 `P-主窗调用.md` 发给主窗（`@ORCH_HOME@` 换成本机用户目录）。它的第一节就是本包的路径、版本、任务目录、会话名、交付目录与特别提醒；安装器装的 `<本机用户目录>/skill/multiagent.md` 是通用骨架，以后每个包重填第一节。
4. **运行中**：主窗上下文被压缩后发 `skill-upgrade-2.0.0/prompts/P1-压缩恢复.md`；研究者临时加、取消任务照 `P3`。

## 用的过程中

- skill 本身的问题（脚本误判、规则不清、文档与脚本不一致、缺功能）：任何窗当场 `python3 -I <skill>/scripts/skill_feedback.py add --td <任务目录> --kind bug|rule|gap|doc|perf --where <R编号或脚本> --symptom "<现象原文>" ...`；**运行中不改 skill**（紧急热修办法见 skill 的 `references/evolution.md` 第 3 节）。
- 每次回传都交 `16-skill-issues.md`（`skill_feedback.py export` 生成；没有问题也交，写“无”）。研究者一侧据此出下一版升级包，随下一个实验包发来。
