# 03 环境配置（二）：verl、slime，以及基础代码在哪里

## 1. 基础代码来源

| 代码 | 地址 | 用来做什么 |
|---|---|---|
| verl | https://github.com/verl-project/verl ，文档 https://verl.readthedocs.io ，OPD 文档 https://verl.readthedocs.io/en/latest/algo/opd.html | 基线 B1（内置 OPD，教师独立资源池）；R1 的 E0、E1 |
| slime | https://github.com/THUDM/slime | 基线 B3：外部 SGLang 教师（`--opd-type sglang`）；B4：教师放进 Megatron 训练器（`--opd-type megatron`）；R2-2 原型的底座 |
| SGLang | https://github.com/sgl-project/sglang （0.5.23） | 教师打分服务、本包测量脚本 |
| vLLM | https://github.com/vllm-project/vllm （0.32.0） | 对照、verl 的 rollout 引擎 |
| evalscope | https://github.com/modelscope/evalscope | 学生评测（`math_500`、`aime25`、`gsm8k`） |
| 本包脚本 | `scripts/` | P0–P7 测量、P3 离线仿真、启动、快照、回传 |

- 装在 `$OPD_RUNTIME/repos/<名字>`，记录 `git rev-parse HEAD`；
- 优先用最近的正式发布版（slime 在 2026-10-09 发布了 v0.4.0）；如果用 main 分支，写明原因。

## 2. 安装步骤

1. 按各自官方文档安装，推荐用官方 Docker 镜像或独立的虚拟环境，两个框架不要装进同一个环境；
2. verl 和 slime 各自依赖的 SGLang、vLLM、Megatron 版本以官方说明为准，可能和第 02 篇的独立 SGLang 环境不同。记录下来就行，不要强行统一；
3. 装完先跑官方的 OPD 示例（v1 的 R0-T1，已完成；路线卡在 v1 包里），能跑通再做改造。

## 3. 两个框架中 OPD 的已知事实（2026-10 至 11 月核对过的公开信息）

- **verl**：教师有独立资源池，资源池卡数必须等于各教师“副本数 × 每副本卡数”之和；教师必须和学生用同一个 tokenizer；打分用 `max_tokens=1, prompt_logprobs=topk`；有融合的 top-K 蒸馏 kernel，支持多教师、同步与全异步两种 trainer。
- **slime**：外部 SGLang 教师模式在 rollout 阶段逐条请求打分（作为自定义奖励函数）；SGLang 教师直接使用学生的 token id，教师架构可以不同，但 tokenizer 不能换；已有多教师（MOPD）的提交。

以上以你安装的版本为准，发现不一致就在回传里写明。

## 4. 在代码里找到要改的位置

不要猜文件路径，用搜索确定，并把找到的路径写进 `return.yaml`：

```bash
cd $OPD_RUNTIME/repos/verl  && grep -rn -i "opd\|distill\|teacher" --include=*.py | head -50
cd $OPD_RUNTIME/repos/slime && grep -rn -i "opd\|teacher\|prompt_logprob\|logprob_start_len" --include=*.py | head -50
grep -rn "timing" $OPD_RUNTIME/repos/verl --include=*.py | head -20   # verl 每步的阶段计时
```

要找的位置：
1. **每步的阶段计时**：生成、教师打分、训练、权重同步的起止时间。verl 训练日志里自带各阶段的计时指标，先确认它们是否已经覆盖这四个阶段，不够再补；
2. **rollout 的发起和完成**：在这里记录每条 rollout 的开始、结束时间和最终长度（`templates/log-schemas.md` 的 `rollout_timeline.csv`）；
3. **教师打分的请求**：slime 外部教师的请求代码在哪里、怎样拼 `input_ids`、用的是哪个 logprob 参数。R2-2 的原型就改这里。

## 5. 计时改造的要求

- **最小要求**：每条 rollout 记录开始时间、结束时间、最终长度、是否达到长度上限，再加每步的阶段时间。P3 只有起止两个点时，会按匀速插值；
- **更好的做法**：每生成 64 个 token 记一个时间点。可以在 rollout 请求里开流式输出，在客户端记录到达时间。流式输出可能稍微拖慢生成，所以要在同一配置下关掉计时再跑一次，对比步时间，差异写进回传；
- 计时代码放 `$OPD_RUNTIME/code/timing/`，用补丁（`git diff > code/timing/<框架>.patch`）的形式保存，回传时只附补丁摘要（改了哪些函数、加了哪些字段）；
- 时间统一用 `time.time()`（Unix 秒），写 CSV 时换算成“相对该步生成开始的秒数”。

## 6. 配置要点（两个框架都要记录的参数）

| 参数 | 说明 |
|---|---|
| 学生、教师模型路径 | 见第 04 篇 |
| 每步提示数、每个提示的回答数 n | E0 先用官方示例的默认值 |
| 最大回答长度 | 2k、8k、16k 三档（E1 的一个维度） |
| 教师放置 | 独立 GPU、与学生同卡（时分复用）、外部服务 |
| 教师精度与 KV 精度 | BF16 为基线 |
| 打分格式 | 采样 token 或 top-k |
| 同步 / 异步 | E0 先用同步模式 |
| 随机种子 | 至少记录 |

每次运行把完整配置文件复制到 `results/<任务>/config/`。
