# 14 多 agent 协作协议：并行执行的规则

> 适用于本包的所有任务。`docs/13` 写本版的并行安排（哪些任务可以同时跑、为什么），本文件写所有 agent 都要遵守的规则。角色卡在 `agents/`。

## 1. 角色（每个角色一个子 agent 或一个 tmux 窗口）

| 角色 | 做什么 | 不做什么 |
|---|---|---|
| `ORCH` 主控 | 读 `state/tasks.yaml` 与 `state/parallel-plan.json`，派发任务，维护 `$OPD_RUNTIME/state/progress.yaml`（**唯一写入者**），写回传目录 | 不自己占 GPU；不改实验定义 |
| `WORKER-A`、`WORKER-B` | 在自己的分区执行任务；两区任务由持有两区租约的那个 worker 执行 | 不碰另一分区的卡；不改环境 |
| `WORKER-CPU` | 下载、CPU 分析、不需要 GPU 的写代码 | 不在测量期间下载 |
| `ENV` | **唯一**可以安装、升级、新建环境的角色（`docs/16`） | 不在别人用环境时改它 |
| `AUDIT` | 独立核对回传，低频采样资源，发现干扰就标出 | 不替 worker 补数字；不杀进程 |
| `DASH` | 实时看板（`docs/15`），只读 | 不占 GPU；不改实验文件 |

平台不支持子 agent 时，由一个 agent 分时扮演这些角色，规则不变。

## 2. 租约：先拿租约，再动资源

```bash
python3 scripts/lease.py acquire --task R2-P1 --agent WORKER-A --res gpu:A noise:m env:sglang:s --ports A:1
# 输出 JSON：ok、lease id、分到的端口。exit 3 表示冲突，什么都没占，稍后重试或做别的任务
python3 scripts/lease.py release --task R2-P1        # 任务（或阶段）结束、失败、中断都要释放
python3 scripts/lease.py list                        # 谁占着什么
```

- 每个任务阶段要拿的资源，写在 `state/parallel-plan.json` 的 `phases[].lease` 和 `ports` 里，照抄即可；
- **`noise`**：测量用 `noise:m`（可以和别的测量同时进行），下载、装包、编译、加载大于 100 GB 的模型用 `noise:n`。m 和 n 不能同时存在，所以测量期间不会有下载；
- **`hostbw`**：权重或 KV 经主机内存、PCIe 传输的测量（例如主机流式、HiCache、换入）独占它，同时租下两个分区，保证另一分区空闲；
- **`env:<名>`**：使用环境写 `:s`；ENV 修改环境写 `:x`，有人在用就拿不到；
- 长任务加 `--pid <服务或训练的主进程号>`，进程退出后 `lease.py reap` 会自动回收；不知道进程号时用 `--ttl-h`，并定期 `renew`。

## 3. 端口与进程名（v1 的端口写死，两区同时跑会冲突）

| 分区 | 服务端口 | Ray | torch 分布式 |
|---|---|---|---|
| A（GPU 0–3） | 30000–30099 | `--port 6380 --dashboard-port 8266 --temp-dir /tmp/ray-A` | `MASTER_PORT=29510` |
| B（GPU 4–7） | 30100–30199 | `--port 6381 --dashboard-port 8267 --temp-dir /tmp/ray-B` | `MASTER_PORT=29520` |
| AB（两区） | 30200–30299 | `--port 6382 --dashboard-port 8268 --temp-dir /tmp/ray-AB` | `MASTER_PORT=29530` |
| CPU | 30300–30399 | — | — |

- 路线卡里写死的 `30000`、`30001`，一律换成租约分到的端口；SGLang 需要固定 NCCL 端口时，用同一租约里的另一个端口（参数名以 `--help` 为准）；
- `launch-sglang.sh` 的名字前面加任务号和分区，例如 `R2P1-A-q8`，避免两个 agent 用同一个 pid 文件；
- **起服务后先核对身份**：`wait` 只看端口，另一个 agent 的服务也会被当成就绪。`wait` 之后请求 `/get_model_info`，确认 `model_path` 是自己的模型，再开始测。

## 4. 进度、事件与回传

- 每个阶段开始、结束、出错时写事件：`python3 scripts/opd_event.py emit --agent WORKER-A --event task_started --task R2-P1 --partition A`。事件写进 `$OPD_RUNTIME/state/events/<agent>.jsonl`，看板从这里读；看板没开时也照样写；
- worker 只写 `results/<任务>/` 和事件；`progress.yaml` 由 ORCH 根据事件更新；
- 只有 ORCH 生成回传：全部任务结束后，把各任务的记录汇总成 `docs/06` 规定的 10 个文件，直接写在 `$OPD_RUNTIME/Transfer2me/` 下，AUDIT 核对后原样交付，不切分，不限字数；
- 测量结果要写明测量期间另一分区在做什么：`return.yaml` 的 `other_partition_busy`。

## 5. 中断、失败与交接

- 任何异常退出：先 `release`，再写 `task_blocked` 或 `config_failed` 事件，原因写进 `return.yaml`；
- 网格任务每测完一个配置就落盘，并写 `config_measured`；接手的 agent 从最后一个已测配置续跑；
- 心跳超过 90 秒没更新，AUDIT 先用 `/proc` 核对进程是否还在，**不要直接判定失败、重跑或杀进程**；
- 两个 agent 要同一份资源时，按 `docs/13` 的优先级（判断节点要用的任务优先），由 ORCH 决定。
