#!/usr/bin/env python3
"""生成派生文件并做交付前自检。

用法（在教学包根目录）：
  python3 tools/build_bundle.py                 # 生成 labs/ALL_CODE.md、BUNDLE_SINGLE_FILE.md，运行全部检查
  python3 tools/build_bundle.py --zip ../ai-infra-tutor-claude.zip            # 另外打包
  python3 tools/build_bundle.py --zip ../x.zip --test-zip <venv>/bin/python   # 打包后解压到临时目录并运行 run_all
检查项：相对链接与锚点、交叉引用（任务编号/题号/问题编号/论文 id/模块完整性）、密钥与隐私扫描、ALL_CODE 与源码一致。
"""
import argparse
import csv
import os
import re
import subprocess
import sys
import tempfile
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXCLUDE_DIRS = {"__pycache__", ".venv", ".git"}


def rd(p):
    return open(os.path.join(ROOT, p), encoding="utf-8").read()


def modules():
    return sorted(d for d in os.listdir(os.path.join(ROOT, "labs")) if re.match(r"m\d\d_", d))


def build_all_code():
    out = ["# 实验代码汇总（ALL_CODE）", "",
           "> 由 `tools/build_bundle.py` 从 `labs/` 源码自动生成，**请勿手工编辑**。每个实验附构建机的实测输出"
           "（`labs/<模块>/outputs/<实验>.txt`，计时数字因机器而异，趋势应一致）。供不能读取文件的教学 agent 使用：讲到哪个模块，"
           "就把对应一节发给它。", ""]
    for m in modules():
        title = rd(f"labs/{m}/README.md").splitlines()[0].lstrip("# ").strip()
        out += [f"## {title}（`labs/{m}/`）", ""]
        for f in sorted(os.listdir(os.path.join(ROOT, "labs", m))):
            if not (f.startswith("lab_") and f.endswith(".py")):
                continue
            out += [f"### `labs/{m}/{f}`", "", "```python", rd(f"labs/{m}/{f}").rstrip(), "```", ""]
            op = f"labs/{m}/outputs/{f[:-3]}.txt"
            if os.path.exists(os.path.join(ROOT, op)):
                out += [f"**实测输出**（`{op}`）：", "", "```text", rd(op).rstrip(), "```", ""]
            else:
                out += ["（尚无实测输出：运行 `python labs/run_all.py --save-outputs` 生成）", ""]
    return "\n".join(out) + "\n"


def build_bundle():
    guide = rd("papers/PAPER_STUDY_GUIDE.md")
    guide_core = guide.split("\n## 4. 选读论文")[0]
    rows = list(csv.DictReader(open(os.path.join(ROOT, "papers/reading_list.csv"), encoding="utf-8-sig")))
    rl = ["| id | 优先级 | 模块 | 标题 | 论文链接 | 代码 |", "| --- | --- | --- | --- | --- | --- |"]
    rl += [f"| `{r['id']}` | {r['优先级']} | {r['模块']} | {r['标题']} | {r['链接']} | {r['代码链接'] or '—'} |" for r in rows]
    parts = [
        ("说明", "> 本文件是教学包的单文件打包版，由 `tools/build_bundle.py` 自动生成，供**只能接收一段文本**的 agent 使用。"
         "它包含：教学提示词、课程大纲（含 76 个任务编号）、批改标准与作业单格式、题库（**不含答案**）、论文学习指南（36 篇必读）与"
         "完整论文清单、问题库、进度文件模板。\n>\n> 不包含的内容与使用方法：\n> - **各模块讲义**在 `labs/<模块>/README.md`，"
         "**实验代码与实测输出**在 `labs/ALL_CODE.md`：讲到哪个模块，学习者就把对应部分发给 agent。\n> - **参考答案**在 "
         "`exercises/answers/`：为了保证学习者先作答，参考答案不放在这里；批改时由学习者在**作答之后**把对应模块的答案文件发给 agent。\n"
         "> - 作业单仍然是一个个独立的 markdown 文件：agent 在回复中给出作业单全文，学习者保存为 `workbook/<任务编号>_<标题>.md`，"
         "作答后整份粘贴回来，agent 返回带红色批改的全文。"),
        ("教学提示词（START_PROMPT.md）", rd("START_PROMPT.md")),
        ("课程大纲（CURRICULUM.md）", rd("CURRICULUM.md")),
        ("批改标准（exercises/rubric.md）", rd("exercises/rubric.md")),
        ("作业单流程与模板（workbook/README.md、TEMPLATE）", rd("workbook/README.md") + "\n\n" + rd("workbook/TEMPLATE_作业单.md")),
        ("题库（exercises/question_bank.md，不含答案）", rd("exercises/question_bank.md")),
        ("论文学习指南（papers/PAPER_STUDY_GUIDE.md 第 1~3 节）", guide_core),
        ("完整论文清单（papers/reading_list.csv）", "\n".join(rl)),
        ("问题库（research/PROBLEM_BANK.md）", rd("research/PROBLEM_BANK.md")),
        ("进度文件模板（progress/LEARNER_PROGRESS.md）", rd("progress/LEARNER_PROGRESS.md")),
    ]
    out = ["# AI Infra 教学包 · 单文件打包版（BUNDLE_SINGLE_FILE）", ""]
    for i, (t, body) in enumerate(parts):
        body = re.sub(r"^(#+) ", lambda mm: "#" * min(len(mm.group(1)) + 2, 6) + " ", body, flags=re.M)  # 降级标题
        out += [f"## 第 {i} 部分　{t}", "", body.strip(), "", "---", ""]
    return "\n".join(out)


def md_files():
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = [d for d in dns if d not in EXCLUDE_DIRS]
        for f in fns:
            if f.endswith(".md"):
                yield os.path.relpath(os.path.join(dp, f), ROOT)


def anchors_of(path):
    text = rd(path)
    a = set(re.findall(r'<a id="([^"]+)"></a>', text))
    for h in re.findall(r"^#+ (.+)$", text, re.M):
        a.add(re.sub(r"[^\w一-鿿 -]", "", h).strip().lower().replace(" ", "-"))
    return a


def check_links():
    errs = []
    for f in md_files():
        if f in ("BUNDLE_SINGLE_FILE.md", "labs/ALL_CODE.md"):
            continue
        for target in re.findall(r"\]\(([^)\s]+)\)", rd(f)):
            if re.match(r"(https?|mailto):", target):
                continue
            path, _, anchor = target.partition("#")
            full = os.path.normpath(os.path.join(os.path.dirname(f), path)) if path else f
            if not os.path.exists(os.path.join(ROOT, full)):
                errs.append(f"{f}: 链接目标不存在 {target}")
            elif anchor and full.endswith(".md") and anchor.lower() not in anchors_of(full):
                errs.append(f"{f}: 锚点不存在 {target}")
        for p in re.findall(r"`((?:labs|papers|exercises|research|resources|progress|workbook|env|tools)/[^`*<> ]+?)`", rd(f)):
            if "<" in p or "*" in p or p.endswith("/notes/") or "/notes/" in p or re.search(r"\{|\[", p):
                continue
            base = p.split(" ")[0].rstrip("/")
            if base.startswith("workbook/D") or base.startswith("papers/notes"):
                continue                                         # 学习者将来创建的文件
            if not os.path.exists(os.path.join(ROOT, base)):
                errs.append(f"{f}: 引用的路径不存在 `{p}`")
    return errs


def check_xrefs():
    errs = []
    cur = rd("CURRICULUM.md")
    tasks = re.findall(r"^\| (D\d-T\d\d) \|", cur, re.M)
    if len(tasks) != 76 or len(set(tasks)) != 76:
        errs.append(f"CURRICULUM 任务数异常：{len(tasks)}")
    prog = re.findall(r"^\| (D\d-T\d\d) \|", rd("progress/LEARNER_PROGRESS.md"), re.M)
    if prog != tasks:
        errs.append("progress/LEARNER_PROGRESS.md 的任务清单与 CURRICULUM 不一致")
    qb = rd("exercises/question_bank.md")
    defined = set(re.findall(r"^### (Q-[A-Z0-9-]+) 〔", qb, re.M))
    for m in modules():
        defined |= set(re.findall(r"^### (Q-M\d\d-L[34]-\d\d)（", rd(f"labs/{m}/exercises.md"), re.M))
    defined |= set(re.findall(r"^\s*- (Q-P-[a-z0-9_]+-\d)：", rd("papers/PAPER_STUDY_GUIDE.md"), re.M))
    answers = "".join(rd(f"exercises/answers/{f}") for f in os.listdir(os.path.join(ROOT, "exercises/answers")))
    for q in sorted(defined):
        if q not in answers:
            errs.append(f"题目 {q} 在 exercises/answers/ 中没有参考答案")
    for f in md_files():
        if f in ("BUNDLE_SINGLE_FILE.md", "labs/ALL_CODE.md"):
            continue
        for q in set(re.findall(r"Q-(?:M\d\d-L\d-\d\d|DIAG-\d\d|P-[a-z0-9_]+-\d)", rd(f))):
            if q not in defined:
                errs.append(f"{f}: 引用了不存在的题号 {q}")
    pb = rd("research/PROBLEM_BANK.md")
    pids = set(re.findall(r'<a id="(p\d\d)"></a>', pb))
    if len(pids) != 30:
        errs.append(f"问题库条目数异常：{len(pids)}")
    ids = {r["id"] for r in csv.DictReader(open(os.path.join(ROOT, "papers/reading_list.csv"), encoding="utf-8-sig"))}
    idx = rd("labs/INDEX.md")
    for row in re.findall(r"^\| [^|]+ \| M\d\d-L\d\d? [^|]* \|.*$", idx, re.M):
        cells = [c.strip() for c in row.split("|")]
        for pid in re.split(r"[、,，\s]+", cells[-3]):
            if pid and pid != "—" and pid not in ids:
                errs.append(f"labs/INDEX.md: 论文 id 不在 reading_list 中：{pid}")
    for m in modules():
        for need in ["README.md", "exercises.md"]:
            if not os.path.exists(os.path.join(ROOT, "labs", m, need)):
                errs.append(f"labs/{m} 缺少 {need}")
        labs_ = [f for f in os.listdir(os.path.join(ROOT, "labs", m)) if f.startswith("lab_") and f.endswith(".py")]
        cpu = [f for f in labs_ if not f.endswith("_gpu.py")]
        if len(cpu) < 2:
            errs.append(f"labs/{m} 的 CPU 实验少于 2 个")
        readme = rd(f"labs/{m}/README.md")
        if "PROBLEM_BANK.md#p" not in readme:
            errs.append(f"labs/{m}/README.md 没有链接问题库")
        if not re.search(r"`[a-z0-9_]+`（|★`", readme) and "论文" not in readme:
            errs.append(f"labs/{m}/README.md 没有论文引用")
    return errs


SECRET_PATTERNS = [r"ghp_[A-Za-z0-9]{20,}", r"github_pat_[A-Za-z0-9_]{20,}", r"sk-[A-Za-z0-9]{20,}", r"AKIA[0-9A-Z]{16}",
                   r"-----BEGIN [A-Z ]*PRIVATE KEY-----", r"(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*['\"][^'\"]{8,}",
                   r"xox[baprs]-[A-Za-z0-9-]{10,}", r"privaterelay\.appleid\.com", r"/home/[a-z]+/\.ssh"]


def check_secrets():
    errs = []
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = [d for d in dns if d not in EXCLUDE_DIRS]
        for f in fns:
            p = os.path.join(dp, f)
            if f.endswith((".zip", ".png")):
                continue
            try:
                text = open(p, encoding="utf-8").read()
            except (UnicodeDecodeError, OSError):
                continue
            for pat in SECRET_PATTERNS:
                if re.search(pat, text):
                    errs.append(f"{os.path.relpath(p, ROOT)}: 疑似敏感信息（模式 {pat}）")
    return errs


def make_zip(zip_path):
    keep_workbook = {"README.md", "TEMPLATE_作业单.md", "EXAMPLE_D1-T11_批改示例.md"}
    n = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for dp, dns, fns in os.walk(ROOT):
            dns[:] = [d for d in dns if d not in EXCLUDE_DIRS]
            rel_dir = os.path.relpath(dp, ROOT)
            for f in sorted(fns):
                if rel_dir == "workbook" and f not in keep_workbook:
                    continue                                    # 不打包学习者自己的作业单
                rel = os.path.normpath(os.path.join(rel_dir, f))
                z.write(os.path.join(dp, f), os.path.join("ai-infra-tutor", rel))
                n += 1
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip")
    ap.add_argument("--test-zip", metavar="PYTHON", help="解压 zip 到临时目录，用该 python 运行 labs/run_all.py")
    a = ap.parse_args()
    old = rd("labs/ALL_CODE.md") if os.path.exists(os.path.join(ROOT, "labs/ALL_CODE.md")) else None
    new = build_all_code()
    open(os.path.join(ROOT, "labs/ALL_CODE.md"), "w", encoding="utf-8").write(new)
    print(f"[生成] labs/ALL_CODE.md（{len(new) // 1024}KB）；与上次生成{'一致' if old == new else '不同（已更新）' if old else '：首次生成'}")
    regen = build_all_code()
    print(f"[检查] ALL_CODE 与 labs/ 源码一致：{regen == new}")
    bundle = build_bundle()
    open(os.path.join(ROOT, "BUNDLE_SINGLE_FILE.md"), "w", encoding="utf-8").write(bundle)
    print(f"[生成] BUNDLE_SINGLE_FILE.md（{len(bundle) // 1024}KB）")
    total = 0
    for name, fn in [("相对链接与路径", check_links), ("交叉引用", check_xrefs), ("密钥与隐私", check_secrets)]:
        errs = fn()
        total += len(errs)
        print(f"[检查] {name}：{'通过' if not errs else f'{len(errs)} 个问题'}")
        for e in errs[:40]:
            print("    -", e)
    if a.zip:
        n = make_zip(a.zip)
        print(f"[打包] {a.zip}：{n} 个文件，{os.path.getsize(a.zip) // 1024}KB")
        if a.test_zip:
            with tempfile.TemporaryDirectory() as d:
                zipfile.ZipFile(a.zip).extractall(d)
                r = subprocess.run([a.test_zip, os.path.join(d, "ai-infra-tutor", "labs", "run_all.py")],
                                   capture_output=True, text=True)
                tail = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-500:]
                print(f"[检查] 解压后运行 run_all：退出码 {r.returncode}；{tail}")
                total += r.returncode != 0
    sys.exit(1 if total else 0)


if __name__ == "__main__":
    main()
