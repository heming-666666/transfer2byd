#!/usr/bin/env python3
"""用 GitHub REST API 核验仓库：是否存在、star、最后推送时间、许可证、是否归档。

用法：python3 -I tools/verify_repos.py <repo_candidates.txt> <raw_dir> <out.json>
"""
import json, sys, time, urllib.request
from datetime import date


def main(src, raw_dir, out_path):
    out = []
    for line in open(src, encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        repo, cat = line.split("\t")
        rec = {"repo": repo, "category": cat, "checked": str(date.today())}
        try:
            req = urllib.request.Request(f"https://api.github.com/repos/{repo}",
                                         headers={"Accept": "application/vnd.github+json",
                                                  "User-Agent": "ai-infra-tutor-verifier"})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            open(f"{raw_dir}/{repo.replace('/', '__')}.json", "wb").write(data)
            m = json.loads(data)
            rec.update(full_name=m["full_name"], stars=m["stargazers_count"], pushed_at=m["pushed_at"][:10],
                       license=(m.get("license") or {}).get("spdx_id") or "无",
                       archived=m["archived"], description=m.get("description") or "",
                       url=m["html_url"], status="ok")
        except urllib.error.HTTPError as e:
            rec["status"] = f"http {e.code}"
        except Exception as e:
            rec["status"] = f"error: {e}"
        out.append(rec)
        print(f"{repo:50s} {rec['status']:8s} {rec.get('stars', '')!s:>7} {rec.get('pushed_at', '')} "
              f"{rec.get('license', '')} {'ARCHIVED' if rec.get('archived') else ''} -> {rec.get('full_name', '')}",
              flush=True)
        time.sleep(0.5)
    json.dump(out, open(out_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4])
