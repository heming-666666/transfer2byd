#!/usr/bin/env python3
"""核验论文元数据：arXiv API（标题/作者/日期）、Crossref（DOI）、Semantic Scholar 批量接口（会议与年份）。

DBLP 搜索接口在 2026-10-18 返回反爬页面，故改用 Semantic Scholar。

用法：python3 -I tools/verify_papers.py <paper_candidates.tsv> <raw_dir> <out.json>
raw_dir 存放 API 原始响应（视为不可信数据，只解析不执行）；out.json 是解析后的核验结果。
"""
import csv, json, os, re, sys, time, urllib.parse, urllib.request
import xml.etree.ElementTree as ET
from datetime import date

UA = {"User-Agent": "ai-infra-tutor-verifier/1.0 (metadata check)"}
NS = {"a": "http://www.w3.org/2005/Atom", "x": "http://arxiv.org/schemas/atom"}


def get(url, raw_path=None, retries=3):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=60) as r:
                data = r.read()
            if raw_path:
                with open(raw_path, "wb") as f:
                    f.write(data)
            return data
        except Exception as e:  # 网络错误只记录，不做诊断
            err = e
            time.sleep(3 * (i + 1))
    raise RuntimeError(f"{url}: {err}")


def norm(s):
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def arxiv_batch(ids, raw_dir):
    out = {}
    for k in range(0, len(ids), 40):
        chunk = ids[k:k + 40]
        url = "https://export.arxiv.org/api/query?max_results=100&id_list=" + ",".join(chunk)
        data = get(url, f"{raw_dir}/arxiv_{k:03d}.xml")
        root = ET.fromstring(data)
        for e in root.findall("a:entry", NS):
            aid = e.find("a:id", NS).text.rsplit("/", 1)[-1]
            base = re.sub(r"v\d+$", "", aid)
            out[base] = {
                "title": " ".join(e.find("a:title", NS).text.split()),
                "authors": [a.find("a:name", NS).text for a in e.findall("a:author", NS)],
                "published": e.find("a:published", NS).text[:10],
                "journal_ref": (e.find("x:journal_ref", NS).text if e.find("x:journal_ref", NS) is not None else ""),
                "comment": (" ".join(e.find("x:comment", NS).text.split()) if e.find("x:comment", NS) is not None else ""),
            }
        time.sleep(3)
    return out


def crossref(doi, raw_dir, key):
    data = get("https://api.crossref.org/works/" + urllib.parse.quote(doi), f"{raw_dir}/crossref_{key}.json")
    m = json.loads(data)["message"]
    parts = (m.get("published-print") or m.get("published-online") or m.get("issued"))["date-parts"][0]
    return {
        "title": " ".join(((m.get("title") or [""])[0] + (": " + m["subtitle"][0] if m.get("subtitle") else "")).split()),
        "authors": [f"{a.get('given', '')} {a.get('family', '')}".strip() for a in m.get("author", [])],
        "published": "-".join(str(p) for p in parts),
        "container": (m.get("container-title") or [""])[0],
    }


def s2_batch(idents, raw_dir):
    """idents: ["ARXIV:2205.14135", "DOI:10.1145/..."]；返回 {ident: {venue, year, citations, url}}。"""
    body = json.dumps({"ids": idents}).encode()
    url = ("https://api.semanticscholar.org/graph/v1/paper/batch"
           "?fields=title,venue,year,publicationVenue,citationCount,externalIds,url")
    for i in range(4):
        try:
            req = urllib.request.Request(url, data=body, headers=dict(UA, **{"Content-Type": "application/json"}))
            with urllib.request.urlopen(req, timeout=90) as r:
                data = r.read()
            break
        except Exception as e:
            err = e
            time.sleep(10 * (i + 1))
    else:
        cached = f"{raw_dir}/s2_batch.json"              # 限流（HTTP 429）时回退到同日缓存的原始响应
        if os.path.exists(cached) and len(json.load(open(cached))) == len(idents):
            print(f"[提示] Semantic Scholar 不可用（{err}），使用缓存 {cached}", flush=True)
            data = open(cached, "rb").read()
        else:
            raise RuntimeError(f"semantic scholar batch: {err}")
    open(f"{raw_dir}/s2_batch.json", "wb").write(data)
    out = {}
    for ident, m in zip(idents, json.loads(data)):
        if m:
            pv = m.get("publicationVenue") or {}
            out[ident] = {"s2_title": m.get("title", ""), "venue": m.get("venue") or pv.get("name", ""),
                          "year": m.get("year"), "citations": m.get("citationCount"), "s2_url": m.get("url")}
    return out


def main(tsv, raw_dir, out_path):
    rows = list(csv.DictReader(open(tsv, encoding="utf-8"), delimiter="\t"))
    ax_ids = [r["ident"][6:] for r in rows if r["ident"].startswith("arxiv:")]
    ax = arxiv_batch(ax_ids, raw_dir)
    results = []
    for r in rows:
        kind, ident = r["ident"].split(":", 1)
        rec = dict(r, checked=str(date.today()), status="unverified")
        try:
            if kind == "arxiv":
                meta = ax.get(ident)
                if not meta:
                    rec["status"] = "arxiv-id-not-found"
                    results.append(rec); continue
                rec.update(meta, link=f"https://arxiv.org/abs/{ident}")
            elif kind == "doi":
                rec.update(crossref(ident, raw_dir, r["key"]), link=f"https://doi.org/{ident}")
            else:
                rec.update(title=r["title_hint"], link=ident)
            rec["title_match"] = norm(r["title_hint"])[:20] in norm(rec["title"]) if rec.get("title") else False
            rec["status"] = "ok" if rec["title_match"] else "title-mismatch"
        except Exception as e:
            rec["status"] = f"error: {e}"
        results.append(rec)
        if kind == "doi":
            time.sleep(1)
    s2_ids = [("ARXIV:" + r["ident"][6:]) if r["ident"].startswith("arxiv:")
              else ("DOI:" + r["ident"][4:]) if r["ident"].startswith("doi:") else "" for r in rows]
    s2 = s2_batch([i for i in s2_ids if i], raw_dir)
    for rec, sid in zip(results, s2_ids):
        rec.update(s2.get(sid, {}))
        print(f"{rec['key']:16s} {rec['status']:16s} {rec.get('published', '')[:7]:8s} "
              f"{str(rec.get('venue', ''))[:40]:40s} {rec.get('title', '')[:60]}", flush=True)
    json.dump(results, open(out_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4])
