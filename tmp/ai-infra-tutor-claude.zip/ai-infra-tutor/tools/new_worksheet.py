#!/usr/bin/env python3
"""生成作业单：按题号（或按任务编号的预设）从题库中抽题，写成 workbook/<任务编号>_<标题>.md。

用法（在教学包根目录）：
  python3 tools/new_worksheet.py --task D1-T11                 # 按任务编号的预设组卷（见 PRESETS）
  python3 tools/new_worksheet.py --task D3-T12 --ids Q-M06-L2-01 Q-P-zero-1   # 指定题号
  python3 tools/new_worksheet.py --list D2-T12                # 只打印预设会选哪些题，不写文件
题目来源：exercises/question_bank.md（L1/L2 与诊断题）、labs/<模块>/exercises.md（L3/L4）、
          papers/PAPER_STUDY_GUIDE.md（Q-P-<论文id>-<n> 精读题）。只读取题面，不读取答案文件。
"""
import argparse
import datetime
import os
import random
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DAY_MODULES = {1: ["M00", "M01", "M02"], 2: ["M03", "M04"], 3: ["M05", "M06"], 4: ["M07", "M08", "M09"],
               5: ["M10", "M11"], 6: ["M12", "M13"], 7: ["M14", "M15"]}
DAILY_TASK = {1: "D1-T11", 2: "D2-T12", 3: "D3-T12", 4: "D4-T10", 5: "D5-T12", 6: "D6-T10"}
LAB_ASSIGNED = {"Q-M04-L2-01", "Q-M10-L2-01"}   # 已在实验任务的完成标准中布置过的 L2 题（见 CURRICULUM.md）


def load_questions():
    """返回 {题号: 题面 markdown}。"""
    qs = {}
    text = open(os.path.join(ROOT, "exercises", "question_bank.md"), encoding="utf-8").read()
    for m in re.finditer(r"^### (Q-[A-Z0-9-]+) 〔([^〕]+)〕\n(.*?)(?=^### |^---|^## |\Z)", text, re.S | re.M):
        qs[m.group(1)] = f"〔{m.group(2)}〕 " + m.group(3).strip()
    for d in sorted(os.listdir(os.path.join(ROOT, "labs"))):
        p = os.path.join(ROOT, "labs", d, "exercises.md")
        if not os.path.exists(p):
            continue
        t = open(p, encoding="utf-8").read()
        for m in re.finditer(r"^### (Q-M\d\d-L[34]-\d\d)（([^）]*)）\n(.*?)(?=^### |\Z)", t, re.S | re.M):
            qs[m.group(1)] = f"〔{m.group(2)}；详见 labs/{d}/exercises.md〕 " + m.group(3).strip()
    g = open(os.path.join(ROOT, "papers", "PAPER_STUDY_GUIDE.md"), encoding="utf-8").read()
    for m in re.finditer(r"^\s*- (Q-P-[a-z0-9_]+-\d)：(.+)$", g, re.M):
        qs[m.group(1)] = "〔论文精读，详见 papers/PAPER_STUDY_GUIDE.md〕 " + m.group(2).strip()
    return qs


def preset(task, qs, seed):
    rng = random.Random(seed)
    day, num = int(task[1]), int(task.split("-T")[1])
    if task == "D1-T01":
        return "诊断测验", sorted(k for k in qs if k.startswith("Q-DIAG"))
    if task == "D7-T07":
        l1 = [rng.choice(sorted(k for k in qs if k.startswith(f"Q-M{m:02d}-L1"))) for m in range(16)]
        l2 = rng.sample(sorted(k for k in qs if re.match(r"Q-M\d\d-L2", k)), 4)
        return "综合测验", l1 + l2
    if num == 1 and day >= 2:                                   # 复习小测：前一天模块的 3 道 L1
        pool = sorted(k for k in qs for m in DAY_MODULES[day - 1] if k.startswith(f"Q-{m}-L1"))
        return f"第{day}天复习小测", rng.sample(pool, 3)
    if DAILY_TASK.get(day) == task:                             # 每日作业：当天各模块全部 L1 + 每模块 1 道 L2
        ids = []
        for m in DAY_MODULES[day]:
            ids += sorted(k for k in qs if k.startswith(f"Q-{m}-L1-"))
            l2 = [k for k in sorted(qs) if k.startswith(f"Q-{m}-L2-") and k not in LAB_ASSIGNED]
            ids += l2[:1]
        return f"第{day}天作业", ids
    return None, []


def render(task, title, ids, qs):
    today = datetime.date.today().isoformat()
    lines = [f"# 作业单 {task}：{title}", "",
             f"- 任务编号：{task}（见 `CURRICULUM.md`）", f"- 生成日期：{today}", "- 状态：待作答",
             f"- 题目数：{len(ids)}；满分与评分规则见 `exercises/rubric.md`", "",
             "> **作答方式**：在每道题的“【你的答案】”下方直接写，可以写公式、贴代码与运行输出。写完后告诉教学 agent“已作答 "
             f"{task}”。批改会以红色文字写在你的答案下方，你的原文不会被修改。答错的题会先给提示，请在“第 2 次作答”处重写。", ""]
    for i, q in enumerate(ids, 1):
        lines += [f"## 第 {i} 题　`{q}`", "", qs[q], "", "**【你的答案】**", "", "（在这里作答）", "",
                  "<!-- 批改区：教学 agent 在此处写入红色批改；如需第 2 次作答，写在批改下方 -->", ""]
    lines += ["---", "", "## 总评", "", "<!-- 教学 agent 在此写入红色总评：得分、薄弱点、下一步 -->", ""]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", required=False, help="任务编号，例如 D1-T11")
    ap.add_argument("--ids", nargs="*", default=[], help="指定题号；不指定时使用该任务的预设")
    ap.add_argument("--title", default=None)
    ap.add_argument("--list", metavar="TASK", help="只打印预设题号")
    ap.add_argument("--seed", type=int, default=0, help="随机抽题的种子（复习小测、综合测验）")
    ap.add_argument("--force", action="store_true", help="覆盖已存在的作业单（默认不覆盖，防止丢失作答）")
    a = ap.parse_args()
    qs = load_questions()
    task = a.list or a.task
    if not task or not re.fullmatch(r"D[1-7]-T\d\d", task):
        sys.exit("请用 --task D<天>-T<序号> 指定任务编号")
    title, ids = preset(task, qs, a.seed)
    if a.ids:
        ids, title = a.ids, a.title or title or "练习"
    if a.title:
        title = a.title
    missing = [q for q in ids if q not in qs]
    if missing:
        sys.exit(f"题库中找不到：{missing}")
    if not ids:
        sys.exit(f"{task} 没有预设题目，请用 --ids 指定题号")
    if a.list:
        print(f"{task} {title}: {' '.join(ids)}")
        return
    os.makedirs(os.path.join(ROOT, "workbook"), exist_ok=True)
    path = os.path.join(ROOT, "workbook", f"{task}_{title}.md")
    if os.path.exists(path) and not a.force:
        sys.exit(f"{path} 已存在（可能已有作答），不覆盖；确需重建请加 --force")
    open(path, "w", encoding="utf-8").write(render(task, title, ids, qs))
    print(f"已生成 {os.path.relpath(path, ROOT)}（{len(ids)} 题）")


if __name__ == "__main__":
    main()
