#!/usr/bin/env python3
"""由核验数据生成 papers/reading_list.csv 与 papers/references.bib。

输入（均在 tools/ 下）：paper_candidates.tsv（模块）、paper_meta.tsv（优先级/代码仓库/会议补充）、
      verified_papers.json（arXiv/Crossref/Semantic Scholar 核验结果）、verified_repos.json 与
      verified_paper_repos.json（GitHub API 核验结果）。代码链接只采用 API 核验存在的仓库。
用法：python3 -I tools/make_reading_list.py
"""
import csv
import json
import os
import re
import sys

T = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(T)
PREREQ = {"M00": "无", "M01": "M00", "M02": "M01", "M03": "M01,M02", "M04": "M02", "M05": "M01",
          "M06": "M04,M05", "M07": "M05,M06", "M08": "M05,M07", "M09": "M06,M07", "M10": "M01,M04",
          "M11": "M10", "M12": "M10,M11", "M13": "M02,M03", "M14": "M06,M11", "M15": "任意"}
VENUE = [("Operating Systems Design", "OSDI"), ("Operating Systems Principle", "SOSP"),
         ("Networked Systems Design", "NSDI"), ("Machine Learning and Syste", "MLSys"),
         ("Neural Information Processing", "NeurIPS"), ("Advances in Neural", "NeurIPS"),
         ("International Conference on Machine Lear", "ICML"), ("International Conference on Learning Rep", "ICLR"),
         ("High Performance Computing, Networking", "SC"), ("International Conference for High Perfor", "SC"),
         ("Architectural Support", "ASPLOS"), ("Computer Architecture", "ISCA"), ("USENIX Annual", "USENIX ATC"),
         ("VLDB", "VLDB"), ("European Conference on Computer Systems", "EuroSys"),
         ("Empirical Methods", "EMNLP"), ("Applications, Technologies", "SIGCOMM"),
         ("High-Performance Computer Architecture", "HPCA"), ("High-Performance Interconnects", "HOTI"),
         ("Transactions on Storage", "ACM TOS"), ("Transactions on Computer Systems", "ACM TOCS"),
         ("machine learning research", "JMLR"), ("Artificial Intelligence and Statistics", "AISTATS"),
         ("Performance Analysis of Systems", "ISPASS"), ("Annual Meeting of the Association", "ACL"),
         ("CACM", "CACM"), ("J. Parallel", "JPDC"), ("MAPL", "MAPL@PLDI"), ("Nature", "Nature")]


def short_venue(v):
    for pat, s in VENUE:
        if pat.lower() in (v or "").lower():
            return s
    return ""


def main():
    cands = {r["key"]: r for r in csv.DictReader(open(f"{T}/paper_candidates.tsv", encoding="utf-8"), delimiter="\t")}
    meta = {r["key"]: r for r in csv.DictReader(open(f"{T}/paper_meta.tsv", encoding="utf-8"), delimiter="\t")}
    ver = {r["key"]: r for r in json.load(open(f"{T}/verified_papers.json", encoding="utf-8"))}
    for k, extra in json.load(open(f"{T}/manual_meta.json", encoding="utf-8")).items():
        ver[k].update(extra)                               # 无 arXiv/DOI 的条目：在线查看官方页面后人工录入
    repos = {}
    for f in ["verified_repos.json", "verified_paper_repos.json"]:
        for r in json.load(open(f"{T}/{f}", encoding="utf-8")):
            if r["status"] == "ok":
                repos[r["full_name"].lower()] = r
    missing = set(cands) - set(meta)
    if missing:
        sys.exit(f"paper_meta.tsv 缺少：{sorted(missing)}")
    rows, bib, errors = [], [], []
    for key, c in cands.items():
        v, m = ver[key], meta[key]
        if v["status"] != "ok":
            errors.append(f"{key}: 核验状态 {v['status']}")
        sv = short_venue(v.get("venue")) or short_venue(v.get("container", ""))
        ov = m.get("venue_override") or ""
        ov_year = re.search(r"(19|20)\d\d", ov)
        venue = re.sub(r"\s*(19|20)\d\d", "", ov).strip() if ov else (sv or "arXiv 预印本")
        # 年份 = 首次公开年份：arXiv 首个版本日期；无 arXiv 版时取正式发表日期或会议页信息
        pub = str(v.get("published") or "")
        year = int(pub[:4]) if pub[:4].isdigit() else (int(ov_year.group(0)) if ov_year else v.get("year"))
        authors = v.get("authors") or []
        auth = ", ".join(authors[:3]) + (" et al." if len(authors) > 3 else "") if authors else "见原文"
        repo, code = (m.get("repo") or "").strip(), ""
        if repo and repo != "-":
            r = repos.get(repo.lower())
            if not r:
                errors.append(f"{key}: 仓库 {repo} 未通过 API 核验")
            else:
                code = r["url"] + ("（已归档）" if r.get("archived") else "")
        rows.append({"id": key, "标题": v["title"], "作者": auth, "年份(首次公开)": year, "会议/期刊": venue,
                     "链接": v["link"], "模块": c["module"], "优先级": m["priority"],
                     "前置知识": PREREQ[c["module"]], "是否有代码": "是" if code else "否",
                     "代码链接": code, "7天精读": "是" if m.get("deep") == "★" else "", "备注": m.get("note") or ""})
        btype = "article" if venue in ("CACM", "JPDC", "ACM TOS", "ACM TOCS", "JMLR", "Nature", "VLDB") else "misc"
        fields = {"title": "{" + v["title"] + "}", "author": " and ".join(authors) or "{see official page}",
                  "year": str(year), "url": v["link"]}
        if v["link"].startswith("https://arxiv.org/abs/"):
            fields["eprint"] = v["link"].rsplit("/", 1)[1]; fields["archivePrefix"] = "arXiv"
        if v["link"].startswith("https://doi.org/"):
            fields["doi"] = v["link"][16:]
        fields["note"] = "{" + venue + "}"
        first = re.sub(r"[^A-Za-z]", "", (authors[0].split()[-1] if authors else key)) or key
        bib.append(f"@{btype}{{{key},\n" + ",\n".join(f"  {k} = {{{val}}}" if not val.startswith("{") else f"  {k} = {val}"
                                                         for k, val in fields.items()) + "\n}")
    order = {"必读": 0, "选读": 1, "前沿": 2}
    rows.sort(key=lambda r: (order[r["优先级"]], r["模块"], r["年份(首次公开)"]))
    os.makedirs(f"{ROOT}/papers", exist_ok=True)
    with open(f"{ROOT}/papers/reading_list.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    with open(f"{ROOT}/papers/references.bib", "w", encoding="utf-8") as f:
        f.write("% 由 tools/make_reading_list.py 生成；元数据经 arXiv API / Crossref / Semantic Scholar 核验（2026-10-18）\n\n")
        f.write("\n\n".join(bib) + "\n")
    cnt = {p: sum(1 for r in rows if r["优先级"] == p) for p in order}
    print(f"写出 {len(rows)} 篇：{cnt}；有代码 {sum(r['是否有代码'] == '是' for r in rows)} 篇；"
          f"7 天精读 {sum(r['7天精读'] == '是' for r in rows)} 篇")
    for e in errors:
        print("  错误：", e)
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
