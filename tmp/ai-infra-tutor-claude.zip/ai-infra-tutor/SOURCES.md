# 调研日志（SOURCES）

> 构建日期：2026-10-18。本文件记录教学包的全部调研证据：检索词与命中情况、每条资源的核验方式与结果，以及未能核实的条目（待核实列表）。**正式清单（`papers/`、`resources/`）只收录本文件中标记为“已核实”的条目。**

## 1. 数量下限达成情况

| 要求 | 下限 | 实际 | 说明 |
| --- | --- | --- | --- |
| 论文初筛 | ≥ 80 | **124** | 全部通过 arXiv API / Crossref 核验标题，并用 Semantic Scholar 批量接口核对发表处 |
| 必读论文 | 25~40 | **36** | 另有选读 42 篇、前沿 46 篇（2024-10 以来的工作约 40 篇） |
| GitHub 仓库 | ≥ 30 | **101** | 全部通过 GitHub REST API 记录 star、最后推送时间、许可证、是否归档 |
| 课程与英文博客 | ≥ 15 | **25** | 每条都直接访问过（HTTP 200）或在线查看过页面内容 |
| 中文资料 | ≥ 15 | **16** | B 站视频 5、中文网页 5、中文 GitHub 仓库 6；另有 14 篇知乎文章因站点拒绝访问而列入待核实 |
| 每类检索词 | 每类 ≥ 5 组，中英文都有 | 论文 10、GitHub 5、英文网络 12、中文网络 9、工程 issue 5 | 见第 3 节 |

## 2. 核验方法与纪律

- **论文**：arXiv 论文用 arXiv API 的 `id_list` 批量查询标题、作者、首个版本日期；没有 arXiv 版本的论文（Roofline、Triton、PyTorch 2、Patarasuk & Yuan、GEMINI）用 Crossref 的 DOI 接口查询；发表处用 Semantic Scholar `paper/batch` 接口核对。Orca 既没有 arXiv 版也没有 DOI，在线查看了 USENIX 官方页面后人工录入（见 `tools/manual_meta.json`）。脚本：`tools/verify_papers.py`，结果：`tools/verified_papers.json`。
- **“年份”的含义**：Semantic Scholar 的 `year` 字段是首次公开年份，不是会议年份，例如 FlashAttention-2 显示 2023，正式发表在 ICLR 2024。由于没有可靠的会议年份数据源（DBLP 当天返回了反爬页面），`reading_list.csv` 中的年份统一定义为**首次公开年份**，“会议/期刊”列只写发表处名称。精读时请以论文首页为准。
- **GitHub**：`tools/verify_repos.py` 调用 `api.github.com/repos/<owner>/<name>`。仓库发生迁移的，以 API 返回的最终名称为准，并注明原名（例如 `volcengine/verl` → `verl-project/verl`）。
- **网页**：对课程、博客、中文资料逐个做普通 HTTP 访问并记录状态码；返回 403/412 或连接超时的，再用在线查看（WebFetch）打开页面核对标题与作者。两种方式都打不开的列入第 6 节“待核实”。
- **模型结构参数**（实验代码中使用）：在线查看 Hugging Face 上 Qwen2.5-7B、DeepSeek-V3 的 `config.json`，以及 Llama 3 论文 Table 3。**没有下载任何模型权重**。
- **一手 / 二手**：论文、官方文档、源码为一手来源；博客、视频、二手笔记为二手来源。教学包中的技术结论以一手来源为准，二手资料只作为学习辅助。
- **安全**：没有下载或运行任何来历不明的代码。API 原始响应作为不可信数据存放在工作区 `downloads/` 下的独立目录中，只解析、不执行，也不随教学包分发。
- **网络问题（只记录已出现的现象，不做诊断）**：DBLP 搜索接口返回反爬验证页面；Semantic Scholar 有一次返回 HTTP 429（限流），重试后成功；8 个网页直接访问超时，其中 7 个随后通过在线查看核实；知乎所有文章对脚本访问和在线查看都返回 403；B 站视频页对脚本访问返回 412，在线查看可以打开。

## 3. 检索日志

每条记录格式：编号 · 检索词 · 返回结果数 · 有效命中（被采用或值得记录的结果）。检索日期均为 2026-10-18。

### 3.1 论文（10 组，含中文 2 组）

| # | 检索词 | 结果 | 有效命中 |
| --- | --- | --- | --- |
| Q1 | LLM serving systems survey 2025 prefill decode disaggregation KV cache | 9 | KV Cache 管理综述 2607.02574、2607.08057；Nexus 2507.06608；SmartGen 2607.28150；KVServe 2605.13734；FlowPrefill 2602.16603 |
| Q2 | OSDI 2025 accepted papers LLM serving training | 9 | NanoFlow、BlitzScale、WLB-LLM、Stragglers what-if、TrainCheck、KunServe 2412.18169；DBLP OSDI'25 目录 |
| Q3 | SOSP 2025 papers LLM inference serving | 9 | Jenga、IC-Cache、Aegaeon、PrefillOnly、Pie、KTransformers；训练侧 ByteRobust、Sailor 等；SIGOPS 官方录用页 |
| Q4 | asynchronous RL training system rollout LLM 2025 arXiv slime AReaL | 9 | AReaL 2505.24298（NeurIPS'25）；AsyncFlow 2507.01663；ROLL Flash 2510.11345；Asynchronous RLHF 2410.18252；slime 没有独立论文 |
| Q21 | FP8 training large language models 2025 arXiv recipe stability DeepSeek fine-grained scaling | 9 | Scaling FP8 training to trillion-token LLMs 2409.12517；FP8 recipe 2509.22536；MOSS 2511.05811 |
| Q22 | MLSys 2025 accepted papers list | 9 | MLSys'25 录用列表（61/271）；最佳论文 FlashInfer；Marconi、FlexAttention |
| Q26 | MoE inference attention FFN disaggregation expert parallel serving 2025 arXiv | 9 | MegaScale-Infer 2504.02263；JANUS 2512.13525；Step-3 2507.19427；vLLM RFC #22799 |
| Q29 | LLM training checkpointing fault tolerance 2025 arXiv in-memory checkpoint ByteDance robust training infrastructure SOSP | 18 | ByteRobust 2509.16293（SOSP'25）；ByteCheckpoint 2407.20143（NSDI'25）；GEMINI（SOSP'23） |
| Q34 | 大模型推理系统 论文 综述 2025 KV Cache 调度 OSDI SOSP | 19 | KV Cache 管理综述 2412.19442；《计算机研究与发展》KV 缓存压缩综述；SOSP'25 推理系统论文 |
| Q35 | 大模型 分布式训练 论文 3D并行 流水线 气泡 2025 新进展 | 19 | 《计算机学报》2026 年第 1 期混合并行综述；Zero Bubble；Synergistic TP&PP 2510.27257；OctoPipe 2509.23722 |

另外，通过 API 对 126 个候选标识符做了批量核验（候选表：`tools/paper_candidates.tsv`）。

### 3.2 GitHub（5 组，含中文 1 组）

| # | 检索词 | 结果 | 有效命中 |
| --- | --- | --- | --- |
| Q20 | DeepEP expert parallel communication library MoE all-to-all low latency | 10 | deepseek-ai/DeepEP；Triton-distributed 2504.19442 |
| Q36 | github awesome LLM systems papers inference serving training list | 9 | ModelTC/awesome-lm-system、Shenggan/awesome-distributed-ml、lambda7xx/awesome-AI-system |
| Q37 | github minimal LLM inference engine from scratch paged attention educational | 10 | 多个个人教学项目；维护情况未知，不进正式清单；采用更成熟的 nano-vllm 作为参照 |
| Q38 | github 大模型 AI Infra 中文 教程 仓库 源码解读 | 9 | caomaolufei/AIInfraGuide、CalvinXKY/InfraTech、hzspyy/llm-infra、liguodongiot/llm-action |
| Q39 | github distributed training tutorial from scratch tensor parallel pipeline parallel minimal implementation | 9 | huggingface/picotron（支持 `--use_cpu`）、LambdaLabsML/distributed-training-guide |

### 3.3 英文网络：课程、工程博客、文档（12 组）

| # | 检索词 | 结果 | 有效命中 |
| --- | --- | --- | --- |
| Q11 | machine learning systems course 2025 syllabus LLM systems CMU 15-442 OR "15-779" OR CS336 | 28 | mlsyscourse.org、CMU 15-779、CS336 Spring 2025、dlsyscourse.org |
| Q12 | "How to Scale Your Model" JAX TPU book roofline | 9 | jax-ml.github.io/scaling-book |
| Q14 | Hugging Face Ultra-Scale Playbook training LLMs on GPU clusters | 9 | huggingface.co/spaces/nanotron/ultrascale-playbook |
| Q15 | NVIDIA Dynamo llm-d distributed inference disaggregated serving KV-aware routing 2025 | 18 | Dynamo 架构文档、llm-d.ai |
| Q18 | "Making Deep Learning Go Brrrr From First Principles" Horace He | 9 | horace.io/brrr_intro.html |
| Q19 | LLM inference KV cache memory calculation blog transformer inference arithmetic kipply | 9 | kipply 博客及其中英双语译本 |
| Q25 | GPU MODE lectures YouTube CUDA Triton PMPP reading group | 10 | YouTube @GPUMODE、Christian Mills 的课程笔记 |
| Q28 | vLLM blog anatomy of vLLM inference engine V1 scheduler paged attention 2025 | 9 | vLLM 官方博客 *Inside vLLM*（基于 commit 42172ad） |
| Q31 | NVIDIA technical blog mastering LLM techniques inference optimization KV cache batching | 9 | NVIDIA 技术博客两篇 |
| Q32 | Lilian Weng large transformer model inference optimization blog | 10 | Lil'Log 推理优化、大模型训练两篇 |
| Q40 | MIT 6.5940 EfficientML course Song Han fall 2024 lectures | 10 | efficientml.ai、YouTube 课程录像 |
| Q41 | UC Berkeley CS267 Applications of Parallel Computers spring 2025 course page | 9 | sites.google.com/lbl.gov/cs267-spr2025 |
| Q42 | PyTorch FSDP2 fully_shard tutorial getting started | 9 | PyTorch 官方 FSDP2 教程 |

### 3.4 中文网络：知乎、B 站、博客园、公众号（9 组）

| # | 检索词 | 结果 | 有效命中 |
| --- | --- | --- | --- |
| Q5 | AI Infra 学习路线 知乎 大模型 训练 推理 系统 | 9 | 知乎学习路线、AIInfraGuide、技能图谱、顶校课程（均因 403 列入待核实）；CSDN 两篇质量一般，不收录 |
| Q13 | B站 AI系统 ZOMI 视频课 大模型 推理 分布式 | 10 | ZOMI 大模型推理、数据并行视频（已在线核实） |
| Q16 | 大模型推理 vLLM 源码解读 知乎 PagedAttention continuous batching 调度 | 9 | 腾讯云 vLLM 源码文章（已核实）；知乎 4 篇（待核实） |
| Q17 | 微信公众号 AI Infra 分布式训练 Megatron 3D并行 源码 解读 | 9 | 公众号文章没有被搜索引擎收录；罗西的 Megatron 源码系列（博客园，已核实） |
| Q23 | GiantPandaCV BBuf 知乎 CUDA 优化 Triton 教程 中文 | 9 | BBuf 的 Triton 入门、CUDA-MODE 课程笔记（知乎，待核实）；BBuf 仓库（已核实） |
| Q24 | 投机解码 Speculative Decoding 原理 知乎 EAGLE Medusa 详解 | 9 | 知乎 EAGLE 解读（待核实） |
| Q27 | openmlsys 机器学习系统 设计和实现 在线书 | 9 | openmlsys.github.io（已核实，第 2 版目录） |
| Q30 | 李沐 论文精读 B站 Megatron GPipe ZeRO Pathways 视频 | 19 | 李沐 Megatron、ZeRO、如何读论文视频（已在线核实）；GPipe 那期没有找到单独链接 |
| Q33 | 知乎 ZeRO FSDP 原理 显存占用 分析 混合精度 优化器状态 16字节 | 10 | 知乎 ZeRO/FSDP 文章（待核实）；ZOMI 博客园 FSDP 文章（已核实）。各文给出的 16Ψ、ZeRO-1 的 4Ψ+12Ψ/N 与 ZeRO 原文一致 |

### 3.5 真实工程问题（GitHub issue / PR，5 组）

| # | 检索词 | 结果 | 采用的证据（链接见 `research/PROBLEM_BANK.md`） |
| --- | --- | --- | --- |
| Q6 | vLLM GitHub issue KV cache preemption recompute performance degradation | 9 | vllm #37003、#49545、#5339；vllm-ascend #10820；vLLM 优化文档中的抢占警告 |
| Q7 | Megatron-LM issue pipeline parallel bubble straggler slow training MFU low | 20 | 没有找到单一的代表性 issue；采用 Optimus 2408.03505（三千多卡训练中 GPU 空闲超过 48%）与 Megatron 的慢节点检测参数 |
| Q8 | verl GitHub issue rollout long tail generation GPU idle weight sync slow | 9 | verl PR #7864、issue #7990、volcengine/verl #3426；RollPacker 2509.21009 |
| Q9 | SGLang issue prefix cache hit rate radix cache eviction memory | 9 | sglang #22373、#26577；SGLang 博客 Unified Radix Cache |
| Q10 | DeepSpeed GitHub issue ZeRO-3 slow communication overhead allgather performance | 9 | DeepSpeed #1174、#5047、#7884 |

> 说明：issue 的内容来自检索结果中的摘要，没有逐条打开核对全文。在问题库中，它们被标为“有工程讨论”级别的证据，写论文前请自己打开原 issue 复核。

## 4. 论文核验结果（124 篇）

| id | 标题 | 首次公开 | S2 记录的发表处 | 链接 | 核验方式 |
| --- | --- | --- | --- | --- | --- |
| roofline | Roofline: an insightful visual performance model for multicore archite… | 2009 | CACM | https://doi.org/10.1145/1498765.1498785 | Crossref + Semantic Scholar |
| triton | Triton: an intermediate language and compiler for tiled neural network… | 2019 | MAPL@PLDI | https://doi.org/10.1145/3315508.3329973 | Crossref + Semantic Scholar |
| fa1 | FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awar… | 2022 | Neural Information Processing Systems | https://arxiv.org/abs/2205.14135 | arXiv API 批量查询 + Semantic Scholar |
| fa2 | FlashAttention-2: Faster Attention with Better Parallelism and Work Pa… | 2023 | International Conference on Learning Represen | https://arxiv.org/abs/2307.08691 | arXiv API 批量查询 + Semantic Scholar |
| sublinear | Training Deep Nets with Sublinear Memory Cost | 2016 | arXiv.org | https://arxiv.org/abs/1604.06174 | arXiv API 批量查询 + Semantic Scholar |
| mpt | Mixed Precision Training | 2017 | International Conference on Learning Represen | https://arxiv.org/abs/1710.03740 | arXiv API 批量查询 + Semantic Scholar |
| patarasuk | Bandwidth optimal all-reduce algorithms for clusters of workstations | 2009 | J. Parallel Distributed Comput. | https://doi.org/10.1016/j.jpdc.2008.09.002 | Crossref + Semantic Scholar |
| zero | ZeRO: Memory Optimizations Toward Training Trillion Parameter Models | 2019 | International Conference for High Performance | https://arxiv.org/abs/1910.02054 | arXiv API 批量查询 + Semantic Scholar |
| ddp | PyTorch Distributed: Experiences on Accelerating Data Parallel Trainin… | 2020 | Proceedings of the VLDB Endowment | https://arxiv.org/abs/2006.15704 | arXiv API 批量查询 + Semantic Scholar |
| fsdp | PyTorch FSDP: Experiences on Scaling Fully Sharded Data Parallel | 2023 | Proceedings of the VLDB Endowment | https://arxiv.org/abs/2304.11277 | arXiv API 批量查询 + Semantic Scholar |
| gpipe | GPipe: Efficient Training of Giant Neural Networks using Pipeline Para… | 2018 | arXiv.org | https://arxiv.org/abs/1811.06965 | arXiv API 批量查询 + Semantic Scholar |
| pipedream | PipeDream: Fast and Efficient Pipeline Parallel DNN Training | 2018 | arXiv.org | https://arxiv.org/abs/1806.03377 | arXiv API 批量查询 + Semantic Scholar |
| megatron | Megatron-LM: Training Multi-Billion Parameter Language Models Using Mo… | 2019 | arXiv.org | https://arxiv.org/abs/1909.08053 | arXiv API 批量查询 + Semantic Scholar |
| megatron3d | Efficient Large-Scale Language Model Training on GPU Clusters Using Me… | 2021 | International Conference for High Performance | https://arxiv.org/abs/2104.04473 | arXiv API 批量查询 + Semantic Scholar |
| seqpar | Reducing Activation Recomputation in Large Transformer Models | 2022 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2205.05198 | arXiv API 批量查询 + Semantic Scholar |
| alpa | Alpa: Automating Inter- and Intra-Operator Parallelism for Distributed… | 2022 | — | https://arxiv.org/abs/2201.12023 | arXiv API 批量查询 + Semantic Scholar |
| ringattn | Ring Attention with Blockwise Transformers for Near-Infinite Context | 2023 | International Conference on Learning Represen | https://arxiv.org/abs/2310.01889 | arXiv API 批量查询 + Semantic Scholar |
| ulysses | DeepSpeed Ulysses: System Optimizations for Enabling Training of Extre… | 2023 | arXiv.org | https://arxiv.org/abs/2309.14509 | arXiv API 批量查询 + Semantic Scholar |
| gshard | GShard: Scaling Giant Models with Conditional Computation and Automati… | 2020 | International Conference on Learning Represen | https://arxiv.org/abs/2006.16668 | arXiv API 批量查询 + Semantic Scholar |
| dsv3 | DeepSeek-V3 Technical Report | 2024 | — | https://arxiv.org/abs/2412.19437 | arXiv API 批量查询 + Semantic Scholar |
| megascale | MegaScale: Scaling Large Language Model Training to More Than 10,000 G… | 2024 | Symposium on Networked Systems Design and Imp | https://arxiv.org/abs/2402.15627 | arXiv API 批量查询 + Semantic Scholar |
| orca | Orca: A Distributed Serving System for Transformer-Based Generative Mo… | 2022 | — | https://www.usenix.org/conference/osdi22/presentation/yu | 在线查看官方页面 |
| vllm | Efficient Memory Management for Large Language Model Serving with Page… | 2023 | Symposium on Operating Systems Principles | https://arxiv.org/abs/2309.06180 | arXiv API 批量查询 + Semantic Scholar |
| sglang | SGLang: Efficient Execution of Structured Language Model Programs | 2023 | Neural Information Processing Systems | https://arxiv.org/abs/2312.07104 | arXiv API 批量查询 + Semantic Scholar |
| sarathiserve | Taming Throughput-Latency Tradeoff in LLM Inference with Sarathi-Serve | 2024 | USENIX Symposium on Operating Systems Design  | https://arxiv.org/abs/2403.02310 | arXiv API 批量查询 + Semantic Scholar |
| distserve | DistServe: Disaggregating Prefill and Decoding for Goodput-optimized L… | 2024 | USENIX Symposium on Operating Systems Design  | https://arxiv.org/abs/2401.09670 | arXiv API 批量查询 + Semantic Scholar |
| mooncake | Mooncake: A KVCache-centric Disaggregated Architecture for LLM Serving | 2024 | ACM Transactions on Storage | https://arxiv.org/abs/2407.00079 | arXiv API 批量查询 + Semantic Scholar |
| specdec | Fast Inference from Transformers via Speculative Decoding | 2022 | International Conference on Machine Learning | https://arxiv.org/abs/2211.17192 | arXiv API 批量查询 + Semantic Scholar |
| llmint8 | LLM.int8(): 8-bit Matrix Multiplication for Transformers at Scale | 2022 | Advances in Neural Information Processing Sys | https://arxiv.org/abs/2208.07339 | arXiv API 批量查询 + Semantic Scholar |
| gptq | GPTQ: Accurate Post-Training Quantization for Generative Pre-trained T… | 2022 | arXiv.org | https://arxiv.org/abs/2210.17323 | arXiv API 批量查询 + Semantic Scholar |
| smoothquant | SmoothQuant: Accurate and Efficient Post-Training Quantization for Lar… | 2022 | International Conference on Machine Learning | https://arxiv.org/abs/2211.10438 | arXiv API 批量查询 + Semantic Scholar |
| awq | AWQ: Activation-aware Weight Quantization for LLM Compression and Acce… | 2023 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2306.00978 | arXiv API 批量查询 + Semantic Scholar |
| eagle | EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty | 2024 | International Conference on Machine Learning | https://arxiv.org/abs/2401.15077 | arXiv API 批量查询 + Semantic Scholar |
| tvm | TVM: An Automated End-to-End Optimizing Compiler for Deep Learning | 2018 | USENIX Symposium on Operating Systems Design  | https://arxiv.org/abs/1802.04799 | arXiv API 批量查询 + Semantic Scholar |
| pt2 | PyTorch 2: Faster Machine Learning Through Dynamic Python Bytecode Tra… | 2024 | International Conference on Architectural Sup | https://doi.org/10.1145/3620665.3640366 | Crossref + Semantic Scholar |
| hybridflow | HybridFlow: A Flexible and Efficient RLHF Framework | 2024 | European Conference on Computer Systems | https://arxiv.org/abs/2409.19256 | arXiv API 批量查询 + Semantic Scholar |
| mlsysfrontier | MLSys: The New Frontier of Machine Learning Systems | 2019 | — | https://arxiv.org/abs/1904.03257 | arXiv API 批量查询 + Semantic Scholar |
| datamove | Data Movement Is All You Need: A Case Study on Optimizing Transformers | 2020 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2007.00072 | arXiv API 批量查询 + Semantic Scholar |
| pytorch19 | PyTorch: An Imperative Style, High-Performance Deep Learning Library | 2019 | Neural Information Processing Systems | https://arxiv.org/abs/1912.01703 | arXiv API 批量查询 + Semantic Scholar |
| fa3 | FlashAttention-3: Fast and Accurate Attention with Asynchrony and Low-… | 2024 | Neural Information Processing Systems | https://arxiv.org/abs/2407.08608 | arXiv API 批量查询 + Semantic Scholar |
| zerooffload | ZeRO-Offload: Democratizing Billion-Scale Model Training | 2021 | USENIX Annual Technical Conference | https://arxiv.org/abs/2101.06840 | arXiv API 批量查询 + Semantic Scholar |
| zeroinf | ZeRO-Infinity: Breaking the GPU Memory Wall for Extreme Scale Deep Lea… | 2021 | International Conference for High Performance | https://arxiv.org/abs/2104.07857 | arXiv API 批量查询 + Semantic Scholar |
| fp8fmt | FP8 Formats for Deep Learning | 2022 | arXiv.org | https://arxiv.org/abs/2209.05433 | arXiv API 批量查询 + Semantic Scholar |
| horovod | Horovod: fast and easy distributed deep learning in TensorFlow | 2018 | arXiv.org | https://arxiv.org/abs/1802.05799 | arXiv API 批量查询 + Semantic Scholar |
| amsp | AMSP: Reducing Communication Overhead of ZeRO for Efficient LLM Traini… | 2023 | — | https://arxiv.org/abs/2311.00257 | arXiv API 批量查询 + Semantic Scholar |
| zeropp | ZeRO++: Extremely Efficient Collective Communication for Giant Model T… | 2023 | arXiv.org | https://arxiv.org/abs/2306.10209 | arXiv API 批量查询 + Semantic Scholar |
| pipedream2bw | Memory-Efficient Pipeline-Parallel DNN Training | 2020 | International Conference on Machine Learning | https://arxiv.org/abs/2006.09503 | arXiv API 批量查询 + Semantic Scholar |
| zerobubble | Zero Bubble Pipeline Parallelism | 2023 | arXiv.org | https://arxiv.org/abs/2401.10241 | arXiv API 批量查询 + Semantic Scholar |
| switch | Switch Transformers: Scaling to Trillion Parameter Models with Simple … | 2021 | Journal of machine learning research | https://arxiv.org/abs/2101.03961 | arXiv API 批量查询 + Semantic Scholar |
| dsmoe | DeepSpeed-MoE: Advancing Mixture-of-Experts Inference and Training to … | 2022 | International Conference on Machine Learning | https://arxiv.org/abs/2201.05596 | arXiv API 批量查询 + Semantic Scholar |
| tutel | Tutel: Adaptive Mixture-of-Experts at Scale | 2022 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2206.03382 | arXiv API 批量查询 + Semantic Scholar |
| megablocks | MegaBlocks: Efficient Sparse Training with Mixture-of-Experts | 2022 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2211.15841 | arXiv API 批量查询 + Semantic Scholar |
| bamboo | Bamboo: Making Preemptible Instances Resilient for Affordable Training… | 2022 | Symposium on Networked Systems Design and Imp | https://arxiv.org/abs/2204.12013 | arXiv API 批量查询 + Semantic Scholar |
| oobleck | Oobleck: Resilient Distributed Training of Large Models Using Pipeline… | 2023 | Symposium on Operating Systems Principles | https://arxiv.org/abs/2309.08125 | arXiv API 批量查询 + Semantic Scholar |
| gemini_ckpt | GEMINI: Fast Failure Recovery in Distributed Training with In-Memory C… | 2023 | Symposium on Operating Systems Principles | https://doi.org/10.1145/3600006.3613145 | Crossref + Semantic Scholar |
| llama3 | The Llama 3 Herd of Models | 2024 | — | https://arxiv.org/abs/2407.21783 | arXiv API 批量查询 + Semantic Scholar |
| acme | Characterization of Large Language Model Development in the Datacenter | 2024 | Symposium on Networked Systems Design and Imp | https://arxiv.org/abs/2403.07648 | arXiv API 批量查询 + Semantic Scholar |
| bytecheckpoint | ByteCheckpoint: A Unified Checkpointing System for Large Foundation Mo… | 2024 | Symposium on Networked Systems Design and Imp | https://arxiv.org/abs/2407.20143 | arXiv API 批量查询 + Semantic Scholar |
| flexgen | FlexGen: High-Throughput Generative Inference of Large Language Models… | 2023 | International Conference on Machine Learning | https://arxiv.org/abs/2303.06865 | arXiv API 批量查询 + Semantic Scholar |
| sarathi | SARATHI: Efficient LLM Inference by Piggybacking Decodes with Chunked … | 2023 | arXiv.org | https://arxiv.org/abs/2308.16369 | arXiv API 批量查询 + Semantic Scholar |
| splitwise | Splitwise: Efficient generative LLM inference using phase splitting | 2023 | International Symposium on Computer Architect | https://arxiv.org/abs/2311.18677 | arXiv API 批量查询 + Semantic Scholar |
| llumnix | Llumnix: Dynamic Scheduling for Large Language Model Serving | 2024 | USENIX Symposium on Operating Systems Design  | https://arxiv.org/abs/2406.03243 | arXiv API 批量查询 + Semantic Scholar |
| tetriinfer | Inference without Interference: Disaggregate LLM Inference for Mixed D… | 2024 | arXiv.org | https://arxiv.org/abs/2401.11181 | arXiv API 批量查询 + Semantic Scholar |
| dejavu | DéjàVu: KV-cache Streaming for Fast, Fault-tolerant Generative LLM Ser… | 2024 | International Conference on Machine Learning | https://arxiv.org/abs/2403.01876 | arXiv API 批量查询 + Semantic Scholar |
| cachegen | CacheGen: KV Cache Compression and Streaming for Fast Large Language M… | 2023 | Conference on Applications, Technologies, Arc | https://arxiv.org/abs/2310.07240 | arXiv API 批量查询 + Semantic Scholar |
| specsample | Accelerating Large Language Model Decoding with Speculative Sampling | 2023 | arXiv.org | https://arxiv.org/abs/2302.01318 | arXiv API 批量查询 + Semantic Scholar |
| h2o | H$_2$O: Heavy-Hitter Oracle for Efficient Generative Inference of Larg… | 2023 | Neural Information Processing Systems | https://arxiv.org/abs/2306.14048 | arXiv API 批量查询 + Semantic Scholar |
| streamingllm | Efficient Streaming Language Models with Attention Sinks | 2023 | International Conference on Learning Represen | https://arxiv.org/abs/2309.17453 | arXiv API 批量查询 + Semantic Scholar |
| medusa | Medusa: Simple LLM Inference Acceleration Framework with Multiple Deco… | 2024 | International Conference on Machine Learning | https://arxiv.org/abs/2401.10774 | arXiv API 批量查询 + Semantic Scholar |
| eagle2 | EAGLE-2: Faster Inference of Language Models with Dynamic Draft Trees | 2024 | Conference on Empirical Methods in Natural La | https://arxiv.org/abs/2406.16858 | arXiv API 批量查询 + Semantic Scholar |
| kivi | KIVI: A Tuning-Free Asymmetric 2bit Quantization for KV Cache | 2024 | International Conference on Machine Learning | https://arxiv.org/abs/2402.02750 | arXiv API 批量查询 + Semantic Scholar |
| snapkv | SnapKV: LLM Knows What You are Looking for Before Generation | 2024 | Neural Information Processing Systems | https://arxiv.org/abs/2404.14469 | arXiv API 批量查询 + Semantic Scholar |
| ansor | Ansor: Generating High-Performance Tensor Programs for Deep Learning | 2020 | USENIX Symposium on Operating Systems Design  | https://arxiv.org/abs/2006.06762 | arXiv API 批量查询 + Semantic Scholar |
| mlir | MLIR: A Compiler Infrastructure for the End of Moore's Law | 2020 | arXiv.org | https://arxiv.org/abs/2002.11054 | arXiv API 批量查询 + Semantic Scholar |
| instructgpt | Training language models to follow instructions with human feedback | 2022 | Neural Information Processing Systems | https://arxiv.org/abs/2203.02155 | arXiv API 批量查询 + Semantic Scholar |
| dschat | DeepSpeed-Chat: Easy, Fast and Affordable RLHF Training of ChatGPT-lik… | 2023 | arXiv.org | https://arxiv.org/abs/2308.01320 | arXiv API 批量查询 + Semantic Scholar |
| openrlhf | OpenRLHF: An Easy-to-use, Scalable and High-performance RLHF Framework | 2024 | — | https://arxiv.org/abs/2405.11143 | arXiv API 批量查询 + Semantic Scholar |
| dsr1 | DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcem… | 2025 | Nature | https://arxiv.org/abs/2501.12948 | arXiv API 批量查询 + Semantic Scholar |
| thunderkittens | ThunderKittens: Simple, Fast, and Adorable AI Kernels | 2024 | arXiv.org | https://arxiv.org/abs/2410.20399 | arXiv API 批量查询 + Semantic Scholar |
| tilelang | TileLang: A Composable Tiled Programming Model for AI Systems | 2025 | arXiv.org | https://arxiv.org/abs/2504.17577 | arXiv API 批量查询 + Semantic Scholar |
| fp8trillion | Scaling FP8 training to trillion-token LLMs | 2024 | International Conference on Learning Represen | https://arxiv.org/abs/2409.12517 | arXiv API 批量查询 + Semantic Scholar |
| mxfp4 | Training LLMs with MXFP4 | 2025 | International Conference on Artificial Intell | https://arxiv.org/abs/2502.20586 | arXiv API 批量查询 + Semantic Scholar |
| nvfp4 | Pretraining Large Language Models with NVFP4 | 2025 | arXiv.org | https://arxiv.org/abs/2509.25149 | arXiv API 批量查询 + Semantic Scholar |
| nccl | Demystifying NCCL: An In-depth Analysis of GPU Communication Protocols… | 2025 | IEEE Symposium on High-Performance Interconne | https://arxiv.org/abs/2507.04786 | arXiv API 批量查询 + Semantic Scholar |
| comm100k | Collective Communication for 100k+ GPUs | 2025 | arXiv.org | https://arxiv.org/abs/2510.20171 | arXiv API 批量查询 + Semantic Scholar |
| tritondist | Triton-distributed: Programming Overlapping Kernels on Distributed AI … | 2025 | arXiv.org | https://arxiv.org/abs/2504.19442 | arXiv API 批量查询 + Semantic Scholar |
| usp | USP: A Unified Sequence Parallelism Approach for Long Context Generati… | 2024 | arXiv.org | https://arxiv.org/abs/2405.07719 | arXiv API 批量查询 + Semantic Scholar |
| loongtrain | LoongTrain: Efficient Training of Long-Sequence LLMs with Head-Context… | 2024 | arXiv.org | https://arxiv.org/abs/2406.18485 | arXiv API 批量查询 + Semantic Scholar |
| megascaleinfer | MegaScale-Infer: Serving Mixture-of-Experts at Scale with Disaggregate… | 2025 | arXiv.org | https://arxiv.org/abs/2504.02263 | arXiv API 批量查询 + Semantic Scholar |
| janus | Janus: Disaggregating Attention and Experts for Scalable MoE Inference | 2025 | arXiv.org | https://arxiv.org/abs/2512.13525 | arXiv API 批量查询 + Semantic Scholar |
| step3 | Step-3 is Large yet Affordable: Model-system Co-design for Cost-effect… | 2025 | arXiv.org | https://arxiv.org/abs/2507.19427 | arXiv API 批量查询 + Semantic Scholar |
| reliability | Revisiting Reliability in Large-Scale Machine Learning Research Cluste… | 2024 | International Symposium on High-Performance C | https://arxiv.org/abs/2410.21680 | arXiv API 批量查询 + Semantic Scholar |
| optimus | Optimus: Accelerating Large-Scale Multi-Modal LLM Training by Bubble E… | 2024 | USENIX Annual Technical Conference | https://arxiv.org/abs/2408.03505 | arXiv API 批量查询 + Semantic Scholar |
| bytescale | ByteScale: Efficient Scaling of LLM Training with a 2048K Context Leng… | 2025 | Conference on Applications, Technologies, Arc | https://arxiv.org/abs/2502.21231 | arXiv API 批量查询 + Semantic Scholar |
| byterobust | Robust LLM Training Infrastructure at ByteDance | 2025 | Symposium on Operating Systems Principles | https://arxiv.org/abs/2509.16293 | arXiv API 批量查询 + Semantic Scholar |
| cpinfer | Context Parallelism for Scalable Million-Token Inference | 2024 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2411.01783 | arXiv API 批量查询 + Semantic Scholar |
| nanoflow | NanoFlow: Towards Optimal Large Language Model Serving Throughput | 2024 | arXiv.org | https://arxiv.org/abs/2408.12757 | arXiv API 批量查询 + Semantic Scholar |
| podattn | POD-Attention: Unlocking Full Prefill-Decode Overlap for Faster LLM In… | 2024 | International Conference on Architectural Sup | https://arxiv.org/abs/2410.18038 | arXiv API 批量查询 + Semantic Scholar |
| dynamollm | DynamoLLM: Designing LLM Inference Clusters for Performance and Energy… | 2024 | International Symposium on High-Performance C | https://arxiv.org/abs/2408.00741 | arXiv API 批量查询 + Semantic Scholar |
| kunserve | KunServe: Parameter-centric Memory Management for Efficient Memory Ove… | 2024 | European Conference on Computer Systems | https://arxiv.org/abs/2412.18169 | arXiv API 批量查询 + Semantic Scholar |
| fastswitch | FastSwitch: Optimizing Context Switching Efficiency in Fairness-aware … | 2024 | arXiv.org | https://arxiv.org/abs/2411.18424 | arXiv API 批量查询 + Semantic Scholar |
| marconi | Marconi: Prefix Caching for the Era of Hybrid LLMs | 2024 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2411.19379 | arXiv API 批量查询 + Semantic Scholar |
| memserve | MemServe: Context Caching for Disaggregated LLM Serving with Elastic M… | 2024 | arXiv.org | https://arxiv.org/abs/2406.17565 | arXiv API 批量查询 + Semantic Scholar |
| microserving | A System for Microserving of LLMs | 2024 | arXiv.org | https://arxiv.org/abs/2412.12488 | arXiv API 批量查询 + Semantic Scholar |
| flashinfer | FlashInfer: Efficient and Customizable Attention Engine for LLM Infere… | 2025 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2501.01005 | arXiv API 批量查询 + Semantic Scholar |
| lmcache | LMCache: An Efficient KV Cache Layer for Enterprise-Scale LLM Inferenc… | 2025 | arXiv.org | https://arxiv.org/abs/2510.09665 | arXiv API 批量查询 + Semantic Scholar |
| jenga | Jenga: Effective Memory Management for Serving LLM with Heterogeneity | 2025 | Symposium on Operating Systems Principles | https://arxiv.org/abs/2503.18292 | arXiv API 批量查询 + Semantic Scholar |
| nexus | Nexus:Proactive Intra-GPU Disaggregation of Prefill and Decode in LLM … | 2025 | — | https://arxiv.org/abs/2507.06608 | arXiv API 批量查询 + Semantic Scholar |
| kvsurvey | From Tensor Buffer to Distributed Memory Hierarchy: A Survey of KV Cac… | 2026 | arXiv.org | https://arxiv.org/abs/2607.02574 | arXiv API 批量查询 + Semantic Scholar |
| pdmoe_survey | Towards Efficient Large Language Model Serving: A Survey on System-Awa… | 2026 | Annual Meeting of the Association for Computa | https://arxiv.org/abs/2607.08057 | arXiv API 批量查询 + Semantic Scholar |
| cacheblend | CacheBlend: Fast Large Language Model Serving for RAG with Cached Know… | 2024 | ACM Transactions on Computer Systems | https://arxiv.org/abs/2405.16444 | arXiv API 批量查询 + Semantic Scholar |
| qserve | QServe: W4A8KV4 Quantization and System Co-design for Efficient LLM Se… | 2024 | Conference on Machine Learning and Systems | https://arxiv.org/abs/2405.04532 | arXiv API 批量查询 + Semantic Scholar |
| quest | Quest: Query-Aware Sparsity for Efficient Long-Context LLM Inference | 2024 | International Conference on Machine Learning | https://arxiv.org/abs/2406.10774 | arXiv API 批量查询 + Semantic Scholar |
| eagle3 | EAGLE-3: Scaling up Inference Acceleration of Large Language Models vi… | 2025 | Neural Information Processing Systems | https://arxiv.org/abs/2503.01840 | arXiv API 批量查询 + Semantic Scholar |
| flexattn | Flex Attention: A Programming Model for Generating Optimized Attention… | 2024 | arXiv.org | https://arxiv.org/abs/2412.05496 | arXiv API 批量查询 + Semantic Scholar |
| rlhfuse | Optimizing RLHF Training for Large Language Models with Stage Fusion | 2024 | Symposium on Networked Systems Design and Imp | https://arxiv.org/abs/2409.13221 | arXiv API 批量查询 + Semantic Scholar |
| asyncrlhf | Asynchronous RLHF: Faster and More Efficient Off-Policy RL for Languag… | 2024 | International Conference on Learning Represen | https://arxiv.org/abs/2410.18252 | arXiv API 批量查询 + Semantic Scholar |
| areal | AReaL: A Large-Scale Asynchronous Reinforcement Learning System for La… | 2025 | Neural Information Processing Systems | https://arxiv.org/abs/2505.24298 | arXiv API 批量查询 + Semantic Scholar |
| streamrl | StreamRL: Scalable, Heterogeneous, and Elastic RL for LLMs with Disagg… | 2025 | arXiv.org | https://arxiv.org/abs/2504.15930 | arXiv API 批量查询 + Semantic Scholar |
| asyncflow | AsyncFlow: An Asynchronous Streaming RL Framework for Efficient LLM Po… | 2025 | arXiv.org | https://arxiv.org/abs/2507.01663 | arXiv API 批量查询 + Semantic Scholar |
| rollflash | Part II: ROLL Flash -- Accelerating RLVR and Agentic Training with Asy… | 2025 | arXiv.org | https://arxiv.org/abs/2510.11345 | arXiv API 批量查询 + Semantic Scholar |
| rollpacker | RollPacker: Mitigating Long-Tail Rollouts for Fast, Synchronous RL Pos… | 2025 | arXiv.org | https://arxiv.org/abs/2509.21009 | arXiv API 批量查询 + Semantic Scholar |
| laminar | Laminar: A Scalable Asynchronous RL Post-Training Framework | 2025 | European Conference on Computer Systems | https://arxiv.org/abs/2510.12633 | arXiv API 批量查询 + Semantic Scholar |
| llmservingsim2 | LLMServingSim 2.0: A Unified Simulator for Heterogeneous and Disaggreg… | 2026 | IEEE International Symposium on Performance A | https://arxiv.org/abs/2602.23036 | arXiv API 批量查询 + Semantic Scholar |

### 4.1 问题库与讲义中引用的补充论文（21 篇，Semantic Scholar 批量核验）

这些论文在 `research/PROBLEM_BANK.md` 或讲义中作为证据被引用，但不在 124 篇候选清单内。2026-10-18 用 Semantic Scholar `paper/batch` 接口按 arXiv 编号核对了标题（其中 `2408.03505`、`2509.21009`、`2510.12633` 也在候选清单中）。

| arXiv 编号 | 标题（S2 记录） | 年份 | 链接 |
| --- | --- | --- | --- |
| 2603.04716 | SLO-Aware Compute Resource Allocation for Prefill-Decode Disaggregated LLM Inference | 2026 | https://arxiv.org/abs/2603.04716 |
| 2602.16603 | FlowPrefill: Decoupling Preemption from Prefill Scheduling Granularity to Mitigate Head-of-Line Blocking in LLM Serving | 2026 | https://arxiv.org/abs/2602.16603 |
| 2605.18750 | A Readiness-Driven Runtime for Pipeline-Parallel Training under Runtime Variability | 2026 | https://arxiv.org/abs/2605.18750 |
| 2605.15617 | A Few GPUs, A Whole Lotta Scale: Faithful LLM Training Emulation with PrismLLM | 2026 | https://arxiv.org/abs/2605.15617 |
| 2605.28302 | How Far Can Disaggregation Go? A Design-Space Exploration of Attention-FFN Disaggregation for Efficient MoE LLM Serving | 2026 | https://arxiv.org/abs/2605.28302 |
| 2608.04502 | AFD-Ledger: Deployment Provisioning for Attention--FFN Disaggregation | 2026 | https://arxiv.org/abs/2608.04502 |
| 2606.20374 | ARGUS: Production-Scale Tracing and Performance Diagnosis for over 10,000-GPU Clusters | 2026 | https://arxiv.org/abs/2606.20374 |
| 2605.17821 | TierCheck: Tiered Checkpointing for Fault Tolerance in Large Language Model Training | 2026 | https://arxiv.org/abs/2605.17821 |
| 2511.12376 | BitSnap: Checkpoint Sparsification and Quantization in LLM Training | 2025 | https://arxiv.org/abs/2511.12376 |
| 2512.14946 | EVICPRESS: Joint KV-Cache Compression and Eviction for Efficient LLM Serving | 2025 | https://arxiv.org/abs/2512.14946 |
| 2606.01839 | Observation, Not Prediction: Conversation-Level Disaggregated Scheduling for Agentic Serving | 2026 | https://arxiv.org/abs/2606.01839 |
| 2607.07508 | Single-Rollout Asynchronous Optimization for Agentic Reinforcement Learning | 2026 | https://arxiv.org/abs/2607.07508 |
| 2606.03910 | NetKV: Network-Aware Decode Instance Selection for Disaggregated LLM Inference | 2026 | https://arxiv.org/abs/2606.03910 |
| 2605.13734 | KVServe: Service-Aware KV Cache Compression for Communication-Efficient Disaggregated LLM Serving | 2026 | https://arxiv.org/abs/2605.13734 |
| 2607.28150 | SmartGen: Seamless Disaggregated LLM Inference with Selective KV Cache Transfer | 2026 | https://arxiv.org/abs/2607.28150 |
| 2408.03505 | Optimus: Accelerating Large-Scale Multi-Modal LLM Training by Bubble Exploitation | 2024 | https://arxiv.org/abs/2408.03505 |
| 2509.21009 | RollPacker: Mitigating Long-Tail Rollouts for Fast, Synchronous RL Post-Training | 2025 | https://arxiv.org/abs/2509.21009 |
| 2510.12633 | Laminar: A Scalable Asynchronous RL Post-Training Framework | 2025 | https://arxiv.org/abs/2510.12633 |
| 2412.19442 | A Survey on Large Language Model Acceleration based on KV Cache Management | 2024 | https://arxiv.org/abs/2412.19442 |
| 2510.27257 | Synergistic Tensor and Pipeline Parallelism | 2025 | https://arxiv.org/abs/2510.27257 |
| 2509.23722 | OctoPipe: Reducing Pipeline Bubbles for Heterogeneous Models via Co-Optimizing Partitioning, Placement, and Scheduling | 2025 | https://arxiv.org/abs/2509.23722 |

## 5. GitHub 仓库核验结果

| 类别 | 仓库 | star | 最后推送 | 许可证 | 状态 |
| --- | --- | ---: | --- | --- | --- |
| RL 后训练 | [verl-project/verl](https://github.com/verl-project/verl)（原 volcengine/verl） | 23914 | 2026-10-18 | Apache-2.0 | 活跃 |
| RL 后训练 | [OpenRLHF/OpenRLHF](https://github.com/OpenRLHF/OpenRLHF) | 10095 | 2026-10-05 | Apache-2.0 | 活跃 |
| RL 后训练 | [THUDM/slime](https://github.com/THUDM/slime) | 8681 | 2026-10-17 | Apache-2.0 | 活跃 |
| RL 后训练 | [areal-project/AReaL](https://github.com/areal-project/AReaL)（原 inclusionAI/AReaL） | 5841 | 2026-10-16 | Apache-2.0 | 活跃 |
| 中文书/课程 | [Infrasys-AI/AISystem](https://github.com/Infrasys-AI/AISystem)（原 chenzomi12/AISystem） | 17999 | 2025-09-03 | Apache-2.0 | 活跃 |
| 中文书/课程 | [Infrasys-AI/AIInfra](https://github.com/Infrasys-AI/AIInfra) | 8436 | 2025-12-22 | Apache-2.0 | 活跃 |
| 中文书/课程 | [openmlsys/openmlsys](https://github.com/openmlsys/openmlsys)（原 openmlsys/openmlsys-zh） | 4869 | 2026-03-15 | 无 | 活跃 |
| 中文教程 | [liguodongiot/llm-action](https://github.com/liguodongiot/llm-action) | 25179 | 2026-10-14 | Apache-2.0 | 活跃 |
| 中文教程 | [xlite-dev/LeetCUDA](https://github.com/xlite-dev/LeetCUDA) | 12088 | 2026-10-18 | GPL-3.0 | 活跃 |
| 中文教程 | [CalvinXKY/InfraTech](https://github.com/CalvinXKY/InfraTech) | 4189 | 2026-09-20 | 无 | 活跃 |
| 中文教程 | [BBuf/how-to-optim-algorithm-in-cuda](https://github.com/BBuf/how-to-optim-algorithm-in-cuda) | 3317 | 2026-10-11 | 无 | 活跃 |
| 中文教程 | [caomaolufei/AIInfraGuide](https://github.com/caomaolufei/AIInfraGuide) | 2787 | 2026-10-12 | 无 | 活跃 |
| 中文教程 | [hzspyy/llm-infra](https://github.com/hzspyy/llm-infra) | 0 | 2026-09-29 | 无 | 活跃 |
| 中文论文精读 | [mli/paper-reading](https://github.com/mli/paper-reading) | 33977 | 2025-03-22 | Apache-2.0 | 活跃 |
| 低精度/量化 | [mit-han-lab/llm-awq](https://github.com/mit-han-lab/llm-awq) | 3651 | 2025-07-17 | MIT | 活跃 |
| 低精度/量化 | [NVIDIA/TransformerEngine](https://github.com/NVIDIA/TransformerEngine) | 3585 | 2026-10-16 | Apache-2.0 | 活跃 |
| 低精度/量化 | [pytorch/ao](https://github.com/pytorch/ao) | 3005 | 2026-10-16 | NOASSERTION | 活跃 |
| 在线书 | [stas00/ml-engineering](https://github.com/stas00/ml-engineering) | 19541 | 2026-10-16 | CC-BY-SA-4.0 | 活跃 |
| 在线书 | [jax-ml/scaling-book](https://github.com/jax-ml/scaling-book) | 1487 | 2026-10-11 | MIT | 活跃 |
| 推理系统 | [vllm-project/vllm](https://github.com/vllm-project/vllm) | 94050 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [sgl-project/sglang](https://github.com/sgl-project/sglang) | 37269 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [NVIDIA/TensorRT-LLM](https://github.com/NVIDIA/TensorRT-LLM) | 14847 | 2026-10-18 | NOASSERTION | 活跃 |
| 推理系统 | [LMCache/LMCache](https://github.com/LMCache/LMCache) | 12107 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [ai-dynamo/dynamo](https://github.com/ai-dynamo/dynamo) | 8328 | 2026-10-18 | NOASSERTION | 活跃 |
| 推理系统 | [kvcache-ai/Mooncake](https://github.com/kvcache-ai/Mooncake) | 6824 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [llm-d/llm-d](https://github.com/llm-d/llm-d) | 4856 | 2026-10-18 | Apache-2.0 | 活跃 |
| 教学实现 | [karpathy/nanoGPT](https://github.com/karpathy/nanoGPT) | 63897 | 2025-11-12 | MIT | 活跃 |
| 教学实现 | [karpathy/llm.c](https://github.com/karpathy/llm.c) | 31173 | 2025-06-26 | MIT | 活跃 |
| 教学实现 | [pytorch/examples](https://github.com/pytorch/examples) | 24072 | 2025-09-01 | BSD-3-Clause | 活跃 |
| 教学实现 | [GeeeekExplorer/nano-vllm](https://github.com/GeeeekExplorer/nano-vllm) | 15951 | 2026-04-26 | MIT | 活跃 |
| 教学实现 | [srush/GPU-Puzzles](https://github.com/srush/GPU-Puzzles) | 12539 | 2024-09-01 | MIT | 活跃 |
| 教学实现 | [gpu-mode/Triton-Puzzles](https://github.com/gpu-mode/Triton-Puzzles)（原 srush/Triton-Puzzles） | 2643 | 2026-04-01 | Apache-2.0 | 活跃 |
| 教学实现 | [huggingface/picotron](https://github.com/huggingface/picotron) | 2326 | 2025-08-26 | Apache-2.0 | 活跃 |
| 教学实现 | [srush/LLM-Training-Puzzles](https://github.com/srush/LLM-Training-Puzzles) | 1198 | 2024-01-10 | MIT | 活跃 |
| 教学实现 | [LambdaLabsML/distributed-training-guide](https://github.com/LambdaLabsML/distributed-training-guide) | 633 | 2025-10-22 | MIT | 活跃 |
| 算子/Kernel | [Dao-AILab/flash-attention](https://github.com/Dao-AILab/flash-attention) | 25154 | 2026-10-18 | BSD-3-Clause | 活跃 |
| 算子/Kernel | [deepseek-ai/FlashMLA](https://github.com/deepseek-ai/FlashMLA) | 13087 | 2026-10-15 | MIT | 活跃 |
| 算子/Kernel | [NVIDIA/cutlass](https://github.com/NVIDIA/cutlass) | 10617 | 2026-10-15 | NOASSERTION | 活跃 |
| 算子/Kernel | [deepseek-ai/DeepGEMM](https://github.com/deepseek-ai/DeepGEMM) | 8979 | 2026-10-14 | MIT | 活跃 |
| 算子/Kernel | [flashinfer-ai/flashinfer](https://github.com/flashinfer-ai/flashinfer) | 6681 | 2026-10-18 | Apache-2.0 | 活跃 |
| 算子/Kernel | [linkedin/Liger-Kernel](https://github.com/linkedin/Liger-Kernel) | 6664 | 2026-10-17 | BSD-2-Clause | 活跃 |
| 算子/Kernel | [HazyResearch/ThunderKittens](https://github.com/HazyResearch/ThunderKittens) | 3757 | 2026-09-12 | MIT | 活跃 |
| 编译器/DSL | [mlc-ai/mlc-llm](https://github.com/mlc-ai/mlc-llm) | 23251 | 2026-10-06 | Apache-2.0 | 活跃 |
| 编译器/DSL | [triton-lang/triton](https://github.com/triton-lang/triton) | 20397 | 2026-10-17 | MIT | 活跃 |
| 编译器/DSL | [apache/tvm](https://github.com/apache/tvm) | 13844 | 2026-10-18 | Apache-2.0 | 活跃 |
| 编译器/DSL | [tile-ai/tilelang](https://github.com/tile-ai/tilelang) | 8646 | 2026-10-16 | NOASSERTION | 活跃 |
| 训练框架 | [deepspeedai/DeepSpeed](https://github.com/deepspeedai/DeepSpeed) | 43241 | 2026-10-18 | Apache-2.0 | 活跃 |
| 训练框架 | [hpcaitech/ColossalAI](https://github.com/hpcaitech/ColossalAI) | 41430 | 2026-10-15 | Apache-2.0 | 活跃 |
| 训练框架 | [NVIDIA/Megatron-LM](https://github.com/NVIDIA/Megatron-LM) | 18186 | 2026-10-18 | NOASSERTION | 活跃 |
| 训练框架 | [pytorch/torchtitan](https://github.com/pytorch/torchtitan) | 5818 | 2026-10-18 | BSD-3-Clause | 活跃 |
| 训练框架 | [deepseek-ai/DualPipe](https://github.com/deepseek-ai/DualPipe) | 3018 | 2026-01-14 | MIT | 活跃 |
| 训练框架 | [huggingface/nanotron](https://github.com/huggingface/nanotron) | 2843 | 2026-10-08 | Apache-2.0 | 活跃 |
| 训练框架 | [zhuzilin/ring-flash-attention](https://github.com/zhuzilin/ring-flash-attention) | 1065 | 2025-09-10 | MIT | 活跃 |
| 训练框架 | [feifeibear/long-context-attention](https://github.com/feifeibear/long-context-attention) | 696 | 2026-09-16 | Apache-2.0 | 活跃 |
| 训练框架 | [sail-sg/zero-bubble-pipeline-parallelism](https://github.com/sail-sg/zero-bubble-pipeline-parallelism) | 467 | 2025-05-07 | NOASSERTION | 活跃 |
| 课程作业 | [gpu-mode/lectures](https://github.com/gpu-mode/lectures) | 6878 | 2026-09-09 | Apache-2.0 | 活跃 |
| 课程作业 | [stanford-cs336/assignment1-basics](https://github.com/stanford-cs336/assignment1-basics) | 3032 | 2026-04-07 | MIT | 活跃 |
| 课程作业 | [dlsyscourse/hw1](https://github.com/dlsyscourse/hw1) | 2 | 2025-09-25 | 无 | 活跃 |
| 通信 | [deepseek-ai/DeepEP](https://github.com/deepseek-ai/DeepEP) | 10288 | 2026-10-16 | MIT | 活跃 |
| 通信 | [NVIDIA/nccl](https://github.com/NVIDIA/nccl) | 5172 | 2026-10-16 | NOASSERTION | 活跃 |
| 通信 | [NVIDIA/nccl-tests](https://github.com/NVIDIA/nccl-tests) | 1675 | 2026-10-05 | BSD-3-Clause | 活跃 |
| 论文/资源列表 | [xlite-dev/Awesome-LLM-Inference](https://github.com/xlite-dev/Awesome-LLM-Inference) | 5531 | 2026-08-14 | GPL-3.0 | 活跃 |
| 论文/资源列表 | [HuaizhengZhang/AI-Infra-from-Zero-to-Hero](https://github.com/HuaizhengZhang/AI-Infra-from-Zero-to-Hero)（原 HuaizhengZhang/Awesome-System-for-Machine-Learning） | 4435 | 2025-07-25 | MIT | 活跃 |
| 论文/资源列表 | [gpu-mode/resource-stream](https://github.com/gpu-mode/resource-stream) | 2378 | 2026-06-15 | MIT | 活跃 |
| 论文/资源列表 | [AmberLJC/LLMSys-PaperList](https://github.com/AmberLJC/LLMSys-PaperList) | 2297 | 2026-10-17 | 无 | 活跃 |
| 论文/资源列表 | [byungsoo-oh/ml-systems-papers](https://github.com/byungsoo-oh/ml-systems-papers) | 657 | 2026-10-17 | 无 | 活跃 |
| 论文/资源列表 | [lambda7xx/awesome-AI-system](https://github.com/lambda7xx/awesome-AI-system) | 380 | 2026-05-14 | 无 | 活跃 |
| 论文/资源列表 | [Shenggan/awesome-distributed-ml](https://github.com/Shenggan/awesome-distributed-ml) | 281 | 2024-10-08 | 无 | 活跃 |
| 论文/资源列表 | [mental2008/awesome-papers](https://github.com/mental2008/awesome-papers) | 232 | 2026-10-06 | MIT | 活跃 |
| 论文/资源列表 | [ModelTC/awesome-lm-system](https://github.com/ModelTC/awesome-lm-system) | 57 | 2023-12-17 | Apache-2.0 | 活跃 |
| 论文代码(alpa) | [alpa-projects/alpa](https://github.com/alpa-projects/alpa) | 3177 | 2023-12-09 | Apache-2.0 | 已归档 |
| 论文代码(cachegen) | [UChi-JCL/CacheGen](https://github.com/UChi-JCL/CacheGen) | 172 | 2024-10-09 | 无 | 活跃 |
| 论文代码(distserve) | [LLMServe/DistServe](https://github.com/LLMServe/DistServe) | 844 | 2025-04-06 | Apache-2.0 | 活跃 |
| 论文代码(dsv3) | [deepseek-ai/DeepSeek-V3](https://github.com/deepseek-ai/DeepSeek-V3) | 104506 | 2025-08-28 | MIT | 活跃 |
| 论文代码(eagle) | [SafeAILab/EAGLE](https://github.com/SafeAILab/EAGLE) | 2555 | 2026-02-20 | NOASSERTION | 活跃 |
| 论文代码(flexgen) | [FMInference/FlexLLMGen](https://github.com/FMInference/FlexLLMGen) | 9344 | 2024-10-28 | Apache-2.0 | 已归档 |
| 论文代码(gpipe) | [kakaobrain/torchgpipe](https://github.com/kakaobrain/torchgpipe) | 866 | 2024-07-25 | BSD-3-Clause | 活跃 |
| 论文代码(gptq) | [IST-DASLab/gptq](https://github.com/IST-DASLab/gptq) | 2386 | 2024-03-27 | Apache-2.0 | 活跃 |
| 论文代码(h2o) | [FMInference/H2O](https://github.com/FMInference/H2O) | 535 | 2024-08-01 | 无 | 活跃 |
| 论文代码(horovod) | [horovod/horovod](https://github.com/horovod/horovod) | 14679 | 2026-09-17 | NOASSERTION | 已归档 |
| 论文代码(kivi) | [jy-yuan/KIVI](https://github.com/jy-yuan/KIVI) | 435 | 2025-11-20 | MIT | 活跃 |
| 论文代码(llmint8) | [bitsandbytes-foundation/bitsandbytes](https://github.com/bitsandbytes-foundation/bitsandbytes) | 8526 | 2026-09-07 | MIT | 活跃 |
| 论文代码(llumnix) | [llumnix-project/llumnix-ray](https://github.com/llumnix-project/llumnix-ray)（原 AlibabaPAI/llumnix） | 561 | 2026-03-12 | Apache-2.0 | 活跃 |
| 论文代码(loongtrain) | [InternLM/InternEvo](https://github.com/InternLM/InternEvo) | 421 | 2025-08-21 | Apache-2.0 | 活跃 |
| 论文代码(medusa) | [FasterDecoding/Medusa](https://github.com/FasterDecoding/Medusa) | 2775 | 2024-06-25 | Apache-2.0 | 活跃 |
| 论文代码(megablocks) | [databricks/megablocks](https://github.com/databricks/megablocks) | 1598 | 2026-03-25 | Apache-2.0 | 活跃 |
| 论文代码(megascale) | [volcengine/veScale](https://github.com/volcengine/veScale) | 1043 | 2026-03-03 | Apache-2.0 | 活跃 |
| 论文代码(mpt) | [NVIDIA/apex](https://github.com/NVIDIA/apex) | 9004 | 2026-10-12 | BSD-3-Clause | 活跃 |
| 论文代码(nanoflow) | [efeslab/Nanoflow](https://github.com/efeslab/Nanoflow) | 976 | 2026-03-29 | 无 | 活跃 |
| 论文代码(pipedream) | [msr-fiddle/pipedream](https://github.com/msr-fiddle/pipedream) | 395 | 2022-11-04 | MIT | 活跃 |
| 论文代码(podattn) | [microsoft/vattention](https://github.com/microsoft/vattention) | 525 | 2026-08-24 | MIT | 活跃 |
| 论文代码(pytorch19) | [pytorch/pytorch](https://github.com/pytorch/pytorch) | 104841 | 2026-10-18 | NOASSERTION | 活跃 |
| 论文代码(qserve) | [mit-han-lab/omniserve](https://github.com/mit-han-lab/omniserve) | 864 | 2025-03-06 | Apache-2.0 | 活跃 |
| 论文代码(quest) | [mit-han-lab/Quest](https://github.com/mit-han-lab/Quest) | 411 | 2025-07-10 | MIT | 活跃 |
| 论文代码(ringattn) | [haoliuhl/ringattention](https://github.com/haoliuhl/ringattention) | 774 | 2025-10-13 | Apache-2.0 | 活跃 |
| 论文代码(sarathiserve) | [microsoft/sarathi-serve](https://github.com/microsoft/sarathi-serve) | 534 | 2026-01-08 | Apache-2.0 | 活跃 |
| 论文代码(smoothquant) | [mit-han-lab/smoothquant](https://github.com/mit-han-lab/smoothquant) | 1698 | 2024-07-12 | MIT | 活跃 |
| 论文代码(snapkv) | [FasterDecoding/SnapKV](https://github.com/FasterDecoding/SnapKV) | 336 | 2025-07-10 | Apache-2.0 | 活跃 |
| 论文代码(splitwise) | [mutinifni/splitwise-sim](https://github.com/mutinifni/splitwise-sim) | 167 | 2024-04-25 | MIT | 活跃 |
| 论文代码(streamingllm) | [mit-han-lab/streaming-llm](https://github.com/mit-han-lab/streaming-llm) | 7274 | 2024-07-11 | MIT | 活跃 |
| 论文代码(tutel) | [microsoft/Tutel](https://github.com/microsoft/Tutel) | 1028 | 2026-10-04 | MIT | 活跃 |

共 101 个仓库（按最终仓库名去重），数据为 2026-10-18 通过 GitHub REST API 实时查询的结果，原始响应保存在 `downloads/github-20261018/`（工作区内，不随教学包分发）。

### 5.1 课程、英文博客与文档（25 条，已核实）

| 资源 | 链接 | 核验 |
| --- | --- | --- |
| CMU 10-414/714 Deep Learning Systems | https://dlsyscourse.org/lectures/ | HTTP 200 |
| CMU 15-442/642 Machine Learning Systems | https://mlsyscourse.org/ | HTTP 200 |
| CMU 15-779 Advanced ML Systems (LLM Edition) | https://www.cs.cmu.edu/~zhihaoj2/15-779/ | HTTP 200 |
| Stanford CS336 Language Modeling from Scratch（2025 春） | https://cs336.stanford.edu/spring2025 | HTTP 200 |
| MIT 6.5940 EfficientML.ai | https://efficientml.ai | HTTP 200 |
| UC Berkeley CS267（2025 春） | https://sites.google.com/lbl.gov/cs267-spr2025 | HTTP 200 |
| Hugging Face *The Ultra-Scale Playbook* | https://huggingface.co/spaces/nanotron/ultrascale-playbook | HTTP 200 |
| *How to Scale Your Model*（Google DeepMind） | https://jax-ml.github.io/scaling-book/ | HTTP 200 |
| Horace He, *Making Deep Learning Go Brrrr From First Principles* | https://horace.io/brrr_intro.html | HTTP 200 |
| kipply, *Transformer Inference Arithmetic* | https://kipply.github.io/blog/transformer-inference-arithmetic/ | HTTP 200 |
| Lilian Weng, *Large Transformer Model Inference Optimization* | https://lilianweng.github.io/posts/2023-01-10-inference-optimization/ | HTTP 200 |
| Lilian Weng, *How to Train Really Large Models on Many GPUs?* | https://lilianweng.github.io/posts/2021-09-25-train-large/ | 直接访问超时；在线查看核实（2021-09-24） |
| vLLM 博客 *Inside vLLM: Anatomy of a High-Throughput LLM Inference System* | https://vllm.ai/blog/2025-09-05-anatomy-of-vllm | 直接访问超时；在线查看核实（作者 Aleksa Gordić，2025-09-05） |
| NVIDIA 技术博客 *Mastering LLM Techniques: Inference Optimization* | https://developer.nvidia.com/blog/mastering-llm-techniques-inference-optimization/ | HTTP 200 |
| NVIDIA 技术博客 *LLM Inference Benchmarking: Fundamental Concepts* | https://developer.nvidia.com/blog/llm-benchmarking-fundamental-concepts/ | HTTP 200 |
| GPU MODE 讲座录像 | https://www.youtube.com/@GPUMODE | HTTP 200 |
| Christian Mills 的 GPU MODE 课程笔记 | https://christianjmills.com/series/notes/cuda-mode-notes.html | HTTP 200 |
| NVIDIA Dynamo 架构文档 | https://docs.dynamo.nvidia.com/dynamo/v-0-9-0/design-docs/overall-architecture | HTTP 200 |
| llm-d 项目主页 | https://llm-d.ai/ | HTTP 200 |
| SGLang 博客 *Unified Radix Cache* | https://www.sglang.io/blog/unified-radix-cache | HTTP 200 |
| PyTorch 官方 FSDP2 教程 | https://docs.pytorch.org/tutorials/intermediate/FSDP_tutorial.html | HTTP 200 |
| Triton 官方教程 | https://triton-lang.org/main/getting-started/tutorials/index.html | HTTP 200 |
| MLSys 2025 录用论文列表 | https://mlsys.org/Conferences/2025/AcceptedPapers | HTTP 200 |
| SOSP 2025 录用论文列表 | https://sigops.org/s/conferences/sosp/2025/accepted.html | HTTP 200 |
| vLLM 官方文档：优化与调参 | https://docs.vllm.ai/en/latest/configuration/optimization.html | HTTP 200 |

### 5.2 中文资料（16 条，已核实）

| 资源 | 链接 | 核验 | 备注 |
| --- | --- | --- | --- |
| 李沐《Megatron LM 论文精读》 | https://www.bilibili.com/video/BV1nB4y1R7Yz/ | 在线查看（2022-06-03，56:08） | 二手，适合配合 M07 |
| 李沐《Zero 论文精读》 | https://www.bilibili.com/video/BV1tY411g7ZT/ | 在线查看（2022-06-17，52:21） | 配合 M06 |
| 李沐《如何读论文》 | https://www.bilibili.com/video/BV1H44y1t75x/ | 在线查看（2021-10-06） | 配合 M15 三遍阅读法 |
| ZOMI酱《大模型推理整体知识》 | https://www.bilibili.com/video/BV1dyqDYvEv2/ | 在线查看（2024-12-11） | 推理系列第一集 |
| ZOMI酱《DP、DDP、FSDP 数据并行原理》 | https://www.bilibili.com/video/BV1JK411S7gL/ | 在线查看（2022-11-01） | 配合 M06 |
| 罗西的思考《[源码解析] 模型并行分布式训练 Megatron (3)》 | https://www.cnblogs.com/rossiXYZ/p/15871062.html | HTTP 200 | 系列文章，代码版本较旧，读时注意对照当前源码 |
| ZOMI酱《【AI系统】完全分片数据并行 FSDP》 | https://www.cnblogs.com/ZOMI/articles/18562942 | HTTP 200 | |
| 《Transformer 推理算术》中英双语版 | https://rickliang-jy.github.io/Time-to-First-Token-Chinese/blogs/transformer-inference-arithmetic/index.html | 在线查看 | 页面注明译文由 AI 翻译整理，以英文原文为准 |
| 腾讯云《从源码剖析 vLLM 的显存管理与连续批处理》 | https://cloud.tencent.com/developer/article/2714056 | 在线查看（2026-07-22） | 作者匿名，标题有营销式表述，质量一般，只作入门参考 |
| 《机器学习系统：设计和实现》（openmlsys）在线书第 2 版 | https://openmlsys.github.io/ | 在线查看 | 中英双语 |
| Infrasys-AI/AISystem（ZOMI《AI 系统》） | https://github.com/Infrasys-AI/AISystem | GitHub API | |
| Infrasys-AI/AIInfra（原 chenzomi12/AIFoundation） | https://github.com/Infrasys-AI/AIInfra | GitHub API | |
| openmlsys/openmlsys | https://github.com/openmlsys/openmlsys | GitHub API | |
| BBuf/how-to-optim-algorithm-in-cuda | https://github.com/BBuf/how-to-optim-algorithm-in-cuda | GitHub API | 含 CUDA-MODE 课程中文笔记 |
| xlite-dev/LeetCUDA | https://github.com/xlite-dev/LeetCUDA | GitHub API | |
| mli/paper-reading（李沐论文精读索引） | https://github.com/mli/paper-reading | GitHub API | |

另外还有 3 个中文教程仓库经 API 核实，收录在资源清单的“补充”部分：caomaolufei/AIInfraGuide、CalvinXKY/InfraTech、liguodongiot/llm-action。

## 6. 待核实与暂不推荐（不进入正式清单）

| 条目 | 链接 | 未能核实的原因 |
| --- | --- | --- |
| 知乎《AI Infra学习路线》 | https://zhuanlan.zhihu.com/p/2021970155182326008 | 直接访问与在线查看均返回 403；只在搜索结果中见到标题 |
| 知乎《AIInfraGuide：开源全栈AI Infra学习教程》 | https://zhuanlan.zhihu.com/p/2028489934944642636 | 403（对应 GitHub 仓库 caomaolufei/AIInfraGuide 已核实） |
| 知乎《AI Infra 技能图谱总览》 | https://zhuanlan.zhihu.com/p/2010002284084471084 | 403 |
| 知乎《最新AI infra 顶校相关免费课程》 | https://zhuanlan.zhihu.com/p/1972609708171960745 | 403 |
| 知乎《从源码读懂 vLLM 系列一》 | https://zhuanlan.zhihu.com/p/2060033883849204419 | 403 |
| 知乎《vLLM: PagedAttention & Continuous Batching》 | https://zhuanlan.zhihu.com/p/1912879297791767692 | 403 |
| 知乎《大模型推理服务调度优化技术-Continuous batching》 | https://zhuanlan.zhihu.com/p/719610083 | 403；据摘要讲的是 vLLM V0 调度，可能已过时 |
| 知乎 猛猿《Megatron 源码解读 1/2》 | https://zhuanlan.zhihu.com/p/629121480 ；https://zhuanlan.zhihu.com/p/634377071 | 403 |
| 知乎 BBuf《OpenAI Triton 入门笔记一》 | https://zhuanlan.zhihu.com/p/679232270 | 403（同一作者的 GitHub 仓库已核实） |
| 知乎《CUDA-MODE 课程笔记 第 29 课 Triton 内部机制》 | https://zhuanlan.zhihu.com/p/11901442836 | 403 |
| 知乎《EAGLE 1/2 论文解读》 | https://zhuanlan.zhihu.com/p/716344354 | 403 |
| 知乎《LLM训练-从显存占用分析到DeepSpeed ZeRO 三阶段解读》 | https://zhuanlan.zhihu.com/p/694880795 | 403 |
| 知乎《PyTorch FSDP 设计解读与性能分析》 | https://zhuanlan.zhihu.com/p/2006736398171017994 | 403 |
| GiantPandaCV 网站 | http://giantpandacv.com/ | 首页返回 404 |
| 李沐《GPipe 论文精读》 | （B 站合集内） | 搜索结果没有给出单独链接 |
| POD-Attention 的代码位置 | 可能在 microsoft/vattention | 无法确认代码是否在该仓库中，因此 reading_list 中没有填写代码链接 |
| Llama-2-7B 的结构参数（32 层、hidden 4096、32 个 KV 头，MHA） | — | 官方 config 需要登录才能查看；实验代码中使用的是普遍认可的数值，请自行对照 Llama 2 论文 |
| 微信公众号上的 AI Infra 文章 | — | 搜索引擎不收录，无法核实 |
| 第 3.5 节各 issue 的全文 | 见问题库 | 只看到了检索摘要，没有逐条打开核对 |
| hzspyy/llm-infra | https://github.com/hzspyy/llm-infra | 已通过 API 核实存在，但 star 为 0、项目很新，质量无法判断，暂不推荐 |
| 个人教学推理引擎（xiyiji/paged-llm、ysaatci/mini-infer 等） | 见 Q37 | 维护情况和质量无法判断 |
| BPipe（ICML'23，显存均衡的流水线并行） | https://proceedings.mlr.press/v202/kim23l/kim23l.pdf | 只在检索结果中见到（Q7），没有用 API 核验；问题库 P18 引用了其“阶段间显存相差超过 25GiB”的观察 |
| WLB-LLM（OSDI'25）、Understanding Stragglers in Large Model Training Using What-if Analysis（OSDI'25） | 见 DBLP OSDI'25 目录 | 只在检索结果中见到（Q2），没有 arXiv 编号可供 API 核验；讲义与问题库中引用了其结论 |
