# M00 定位：AI Infra 的版图、关键指标与学习路线

- **对应任务**：D1-T02（讲义）、D1-T03（实验 L01）、D1-T04（实验 L02）
- **先修**：无
- **预计学时**：1.2 小时
- **学习目标**（学完后应该能做到）：
  1. 说出 AI Infra 的四层版图，并把任意一篇系统论文放到正确的层次里。
  2. 给出一份请求时间线，能算出 TTFT、TPOT、吞吐、goodput。
  3. 用 6ND 估算一次训练的 GPU·小时；用“每步读一遍权重”估算 decode 的吞吐上限。
  4. 解释为什么系统论文越来越多地报告 goodput 和 P99，而不只报告平均吞吐。

## 1. 核心讲义

### 1.1 AI Infra 是什么：一个四层版图

AI Infra（AI 系统 / 机器学习系统，Machine Learning Systems）研究的是**怎样让模型的训练和推理跑得更快、更省、更稳**。它的核心矛盾只有一句话：**模型对算力、显存、带宽的需求，增长得比硬件快**。所有技术都在用某种方式“搬运”这个矛盾。

| 层次 | 关心的问题 | 典型技术 | 本课程模块 |
| --- | --- | --- | --- |
| 硬件与算子 | 单个算子能不能吃满 GPU | Roofline、tiling、算子融合、FlashAttention、Triton、编译器 | M01、M03、M13 |
| 单机运行时 | 一张卡上的显存与执行效率 | 显存账本、混合精度、激活重计算、CUDA Graph、KV Cache | M02、M04、M10 |
| 分布式训练 | 很多卡怎样一起训练一个模型 | 集合通信、数据并行/ZeRO、张量/流水线/序列/专家并行、容错 | M05~M09 |
| 推理服务与后训练 | 怎样在 SLO 内用最少的卡服务最多的请求；RL 训练如何把推理和训练拼在一起 | 连续批处理、PagedAttention、前缀缓存、PD 分离、投机解码、量化、RL 系统 | M11、M12、M14 |

类比：如果把模型看作一座工厂，算子层管的是“单台机床的效率”，运行时管的是“车间的物料摆放”，分布式训练管的是“多个车间怎样分工、怎样运送半成品”，推理服务管的是“接订单、排产、按时交货”。

### 1.2 必须熟悉的指标

**训练侧**

- **吞吐**（tokens/s 或 samples/s）：每秒处理多少训练 token。
- **MFU**（Model FLOPs Utilization，模型 FLOPs 利用率）：
  `MFU = (每 token 的模型 FLOPs × 实际吞吐) / 硬件峰值 FLOPs`。
  训练时每 token 约需 `6N` FLOPs（前向 `2N`，反向 `4N`，N 是参数量）。注意 MFU 不计入激活重计算等“额外做的”计算；把重计算也算进去的叫 HFU（Hardware FLOPs Utilization）。
- **显存峰值**、**有效训练时间比**（ETTR，扣除故障与重启后真正在训练的时间占比，见 M09）。

**推理侧**（以 LLM 为例）

- **TTFT**（Time To First Token，首 token 延迟）：从请求到达到第一个 token 产出，主要由排队时间加 prefill 时间组成。
- **TPOT**（Time Per Output Token，每个输出 token 的平均间隔）：`(最后一个 token 时间 − 第一个 token 时间) / (输出 token 数 − 1)`。也常用 ITL（Inter-Token Latency，相邻 token 的间隔）来观察卡顿。
- **吞吐**：每秒输出多少 token（或完成多少请求）。
- **goodput**：每秒完成的、**同时满足 TTFT 与 TPOT SLO** 的请求数。这个概念由 DistServe 明确提出，是推理系统论文的核心指标。吞吐高而 goodput 低，说明系统在用牺牲用户体验的方式换数字。
- **尾延迟**：P99（第 99 百分位）。用户感受到的往往是最差的那一部分请求。

**成本侧**：GPU·小时、每百万 token 的成本（$/1M tokens）。

### 1.3 两个“信封背面”公式

1. **训练算力**：`总 FLOPs ≈ 6 × N × D`（N 为参数量，D 为训练 token 数）。
   例：7B 模型训练 2T token，总量为 6 × 7e9 × 2e12 = 8.4e22 FLOPs。H100 BF16 稠密峰值约 989 TFLOPS，MFU 为 40% 时，需要 8.4e22 / (989e12 × 0.4) ≈ 2.1e8 GPU·秒 ≈ 5.9 万 GPU·小时。
2. **decode 吞吐上限**：decode 每生成一步，都要把全部权重从显存读一遍，还要读所有序列的 KV Cache：
   `每步时间 ≈ max( (2N + B × KV每序列) / 显存带宽 ,  2N × B / 峰值算力 )`。
   batch 为 1 时，7B 模型（BF16 权重 14GB）在 H100（3.35TB/s）上仅读权重每步就至少要 4.2ms，吞吐上限约 240 token/s；再加上 4K 上下文的 KV（约 2.15GB），就是 L02 输出中的 207 token/s。此时算力利用率不到 1%。这一个数字解释了推理系统里的大部分工作。

### 1.4 学习路线（与 `CURRICULUM.md` 的 7 天安排对应）

第 1~2 天理解“单卡为什么慢”（Roofline、访存、显存）→ 第 3~4 天理解“多卡怎样协作”（通信、各种并行）→ 第 5~6 天理解“推理系统怎样排产”（批处理、KV 管理、加速）→ 第 7 天把这些知识用到 RL 后训练系统和研究方法上，并开始选题。

## 2. 实验

### M00-L01 推理服务指标（`lab_01_serving_metrics.py`）

- **目标**：从合成时间线算出 TTFT、TPOT、吞吐、goodput、SLO 达成率，并估算 MFU。
- **命令**：`python labs/m00_overview/lab_01_serving_metrics.py`
- **先预测**（运行前写在作业单里）：
  1. 负载从低到高时，平均 TPOT 和 P99 TPOT 哪个涨得更快？
  2. 原始 token 吞吐上升时，goodput 一定上升吗？
- **关键代码**：`synth_trace()` 用 `1/(1−ρ)` 模拟排队延迟随负载急剧上升（M/M/1 排队论的直觉）；`metrics()` 按定义计算各项指标；`mfu()` 按 6N/2N 计算。
- **实测输出摘要**（固定随机种子，任何机器上都一样）：

  | 负载 | TTFT P50 / P99 (ms) | TPOT 均值 / P99 (ms) | 吞吐 (tok/s) | goodput (req/s) | SLO 达成率 |
  | --- | --- | --- | --- | --- | --- |
  | 0.2 | 37 / 87 | 15.7 / 16.0 | 2267 | 8.78 | 100% |
  | 0.6 | 89 / 355 | 23.4 / 24.8 | 2100 | 8.13 | 100% |
  | 0.9 | 362 / 2023 | 29.5 / 31.9 | 1979 | 4.81 | 62.7% |
  | 1.2 | 1202 / 7141 | 35.9 / 39.2 | 1713 | 1.58 | 23.7% |

  MFU 估算：7B 训练、每卡 3000 tok/s 时为 12.7%；7B 推理 decode、每卡 2500 tok/s 时只有 3.5%。
- **解读**：负载从 0.6 升到 0.9 时，TTFT 的 P99 涨了约 5.7 倍，而 P50 只涨了约 4 倍；吞吐只降了 6%，goodput 却降了 41%。**只看吞吐会严重高估系统的可用容量。**
- **可调参数与扫描建议**：`--load 0.5 0.7 0.8 0.85 0.9 0.95`（细扫拐点）；`--slo-tpot 0.03`（收紧 SLO，观察 goodput 何时崩溃）。
- **暴露的问题**：吞吐与尾延迟的取舍、SLO 感知调度 → [P05](../../research/PROBLEM_BANK.md#p05)、[P30](../../research/PROBLEM_BANK.md#p30)。

### M00-L02 成本估算（`lab_02_cost_model.py`）

- **目标**：用 6ND 估算训练成本；用 roofline 式模型估算 decode 吞吐和每百万 token 成本，并检查显存是否放得下。
- **命令**：`python labs/m00_overview/lab_02_cost_model.py`
- **先预测**：
  1. 7B 模型训练 2T token，在 MFU=40% 的 H100 上大约要多少 GPU·小时？
  2. 推理 batch 从 1 提到 64，每百万 token 成本大概能降多少倍？为什么不会无限下降？
- **实测输出摘要**：MFU 为 0.2、0.4、0.55 时，分别需要约 11.8 万、5.9 万、4.3 万 GPU·小时（1024 卡分别为 4.8、2.4、1.7 天）。decode 吞吐：batch=1 时 207 tok/s（每百万 token 3.35 美元），batch=16 时 1108 tok/s（0.63 美元），**batch=32 起显存放不下**（4K 上下文时每条序列的 KV 约 2.15GB）。
- **解读**：batch 从 1 增到 16，成本降到约 1/5，但继续增大时收益递减，并且很快被 KV Cache 显存卡住。这就是 PagedAttention（减少浪费）、GQA/MLA（减少每 token 的 KV）、KV 量化（减少每个元素的字节数）这些工作的共同动机。
- **可调参数**：`--params 70e9`、`--mfu 0.3 0.5`、`--gpu A100-80G`、`--gpu-price`（价格是假设值，请按你能租到的价格修改）。
- **暴露的问题**：[P01](../../research/PROBLEM_BANK.md#p01) decode 受访存限制；[P02](../../research/PROBLEM_BANK.md#p02) KV Cache 决定并发上限；[P18](../../research/PROBLEM_BANK.md#p18) 训练效率损失。

## 3. 常见误区

- “MFU 低就说明代码写得差”：decode 的 MFU 天生很低，因为它受访存限制。判断时要先用 Roofline 找出上限（M01）。
- “吞吐越高越好”：在 SLO 约束下，比较的应该是 goodput。
- “平均延迟代表用户体验”：要看 P99 和最长卡顿（M11-L02 会单独测量）。
- “6ND 是精确值”：它忽略了注意力的 `O(s²)` 项和重计算；序列很长时要加上 `12·L·s²·h` 量级的注意力 FLOPs（见 M07-L03 的代码）。

## 4. 论文与延伸阅读

- 本模块没有必读论文。DistServe（`distserve`）在 D5 精读时会再回到 goodput 的定义。
- 选读：`mlsysfrontier`（MLSys 这一研究方向的定位）。
- 资源：*How to Scale Your Model* 第 1 章（Roofline 与成本估算）；Hugging Face *Ultra-Scale Playbook* 开篇（训练指标）。链接见 `resources/RESOURCES.md`。

## 5. 自测题

`exercises/question_bank.md` 中的 Q-M00-L1-01 ~ Q-M00-L4-01。动手类练习见本目录的 `exercises.md`。
