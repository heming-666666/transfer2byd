"""[M00-L02] 训练与推理的"信封背面"成本估算

目标：用 6ND 法则估算训练所需 GPU·小时和费用；用吞吐估算推理每百万 token 成本；
      理解 MFU 与批大小对成本的杠杆作用。
先预测：
  1. 把 7B 模型训练 2T token，在 MFU=40% 的 H100 上大约要多少 GPU·小时？
  2. 推理批大小从 1 提到 64，每百万 token 成本大概降多少倍？为什么不会无限下降？
可调参数：--params（参数量）、--tokens（训练 token 数）、--mfu（0.2~0.6）、--gpu-price（$/GPU·h）
暴露的问题：MFU 每提高 1 个百分点都对应真金白银 → PROBLEM_BANK P18、P01
对应论文：MegaScale（MFU 55.2%）、Megatron 3D 并行（SC'21）
"""
import argparse

# 公开规格（NVIDIA 官方数据表；BF16 稠密，不含稀疏加速）
GPUS = {
    "A100-80G": {"flops": 312e12, "hbm_bw": 2.0e12, "mem": 80e9},
    "H100-SXM": {"flops": 989e12, "hbm_bw": 3.35e12, "mem": 80e9},
}


def train_cost(params, tokens, gpu, mfu, price):
    flops = 6 * params * tokens                     # 前向 2N + 反向 4N（每 token）
    gpu_sec = flops / (GPUS[gpu]["flops"] * mfu)
    return flops, gpu_sec / 3600, gpu_sec / 3600 * price


def decode_tokens_per_s(params, batch, gpu, kv_bytes_per_seq):
    """非常粗的 decode 吞吐模型：每步需读一遍全部权重 + 所有序列的 KV；
    每步时间 = max(访存时间, 计算时间)。这是 roofline 思想的直接应用（见 M01、M10）。"""
    g = GPUS[gpu]
    bytes_step = 2 * params + batch * kv_bytes_per_seq   # BF16 权重 2 字节/参数
    flops_step = 2 * params * batch
    t = max(bytes_step / g["hbm_bw"], flops_step / g["flops"])
    return batch / t, bytes_step / g["hbm_bw"] > flops_step / g["flops"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--params", type=float, default=7e9)
    ap.add_argument("--tokens", type=float, default=2e12)
    ap.add_argument("--gpu", default="H100-SXM", choices=GPUS)
    ap.add_argument("--mfu", type=float, nargs="+", default=[0.2, 0.4, 0.55])
    ap.add_argument("--gpu-price", type=float, default=2.5, help="美元/GPU·小时（假设值，可改）")
    a = ap.parse_args()

    print(f"== 训练：{a.params / 1e9:.0f}B 参数 × {a.tokens / 1e12:.1f}T token on {a.gpu} ==")
    for m in a.mfu:
        flops, gh, usd = train_cost(a.params, a.tokens, a.gpu, m, a.gpu_price)
        print(f"  MFU={m:.2f}: 总 FLOPs={flops:.2e}  GPU·h={gh:,.0f}  "
              f"费用≈${usd:,.0f}  (1024 卡需 {gh / 1024 / 24:.1f} 天)")

    # Llama-2-7B 风格（32 层、MHA 32 头×128 维）在 4096 长度下每序列 KV ≈ 2·32·4096·4096·2B = 2.1GB
    kv_per_seq = 2 * 32 * 4096 * 4096 * 2
    print(f"\n== 推理 decode：每序列 KV={kv_per_seq / 1e9:.2f} GB（4096 上下文）==")
    print(f"  {'batch':>5s} {'tok/s':>9s} {'$/1M tok':>9s}  瓶颈        显存是否放得下")
    for b in [1, 4, 16, 32, 64, 128]:
        tps, mem_bound = decode_tokens_per_s(a.params, b, a.gpu, kv_per_seq)
        usd = a.gpu_price / 3600 / tps * 1e6
        fits = 2 * a.params + b * kv_per_seq <= GPUS[a.gpu]["mem"]
        print(f"  {b:5d} {tps:9.0f} {usd:9.3f}  {'访存' if mem_bound else '算力':6s}     {'是' if fits else '否 (OOM)'}")
    print("\n[小结] 训练成本与 MFU 成反比；推理成本随批增大而下降，但很快会被 KV Cache 显存卡住。"
          "\n       这就是 PagedAttention、GQA/MLA、KV 量化等工作的动机（M10~M12）。"
          "\n[问题库] P01 decode 访存受限；P02 KV Cache 是并发上限；P18 训练效率损失")


if __name__ == "__main__":
    main()
