"""[M00-L01] 从请求时间线计算推理服务指标：TTFT / TPOT / 吞吐 / goodput / MFU

目标：拿到一份"每个 token 何时产出"的时间线后，能自己算出论文里常见的指标，
      并理解为什么系统论文越来越多地报告 goodput（满足 SLO 的请求吞吐）而不是原始吞吐。
先预测：
  1. 负载从低到高时，平均 TPOT 和 P99 TPOT 哪个涨得更快？
  2. 原始 token 吞吐上升时，goodput 一定上升吗？
可调参数：--load（0.2~1.5，服务器繁忙程度）、--n（请求数）、--slo-ttft、--slo-tpot
暴露的问题：吞吐与延迟的取舍、尾延迟 → PROBLEM_BANK P05、P30
对应论文：DistServe（goodput 定义）、Sarathi-Serve（TTFT/TPOT 取舍）
"""
import argparse
import random
import statistics


def percentile(xs, p):
    xs = sorted(xs)
    k = (len(xs) - 1) * p / 100
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def synth_trace(n, load, seed=0):
    """生成合成时间线：每个请求的到达时间和每个输出 token 的产出时刻（秒）。
    简化模型：排队时间随 load 非线性增长（M/M/1 风格 1/(1-rho)），decode 步长随批大小线性增长。"""
    rng = random.Random(seed)
    rho = min(load, 0.97)
    t, trace = 0.0, []
    for _ in range(n):
        t += rng.expovariate(10.0)                     # 平均每秒 10 个请求
        prompt = rng.randint(128, 2048)
        out = rng.randint(16, 512)
        queue = rng.expovariate(1.0) * 0.05 * rho / (1 - rho)   # 排队延迟
        prefill = prompt * 2e-5 * (1 + load)                   # prefill 与 prompt 长度成正比
        step = 0.012 * (1 + 1.5 * load)                        # 批越大，每步 decode 越慢
        first = t + queue + prefill
        toks = [first]
        for _ in range(out - 1):
            # 偶发的 prefill 插队会让某些 decode 步变长（尾延迟的来源之一）
            stall = 0.08 * load if rng.random() < 0.02 * load else 0.0
            toks.append(toks[-1] + step * rng.uniform(0.9, 1.1) + stall)
        trace.append({"arrive": t, "prompt": prompt, "tokens": toks})
    return trace


def metrics(trace, slo_ttft, slo_tpot):
    ttft = [r["tokens"][0] - r["arrive"] for r in trace]
    tpot = [(r["tokens"][-1] - r["tokens"][0]) / max(len(r["tokens"]) - 1, 1) for r in trace]
    span = max(r["tokens"][-1] for r in trace) - min(r["arrive"] for r in trace)
    n_tok = sum(len(r["tokens"]) for r in trace)
    ok = sum(1 for a, b in zip(ttft, tpot) if a <= slo_ttft and b <= slo_tpot)
    return {
        "TTFT p50/p99 (ms)": (percentile(ttft, 50) * 1e3, percentile(ttft, 99) * 1e3),
        "TPOT mean/p99 (ms)": (statistics.mean(tpot) * 1e3, percentile(tpot, 99) * 1e3),
        "吞吐 (output tok/s)": n_tok / span,
        "请求吞吐 (req/s)": len(trace) / span,
        "goodput (满足SLO req/s)": ok / span,
        "SLO 达成率": ok / len(trace),
    }


def mfu(n_params, tokens_per_s, peak_flops, training):
    """MFU = 实际有效 FLOPs / 峰值。训练每 token ≈ 6N FLOPs（前向 2N + 反向 4N），推理 ≈ 2N。"""
    per_tok = (6 if training else 2) * n_params
    return per_tok * tokens_per_s / peak_flops


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=400)
    ap.add_argument("--load", type=float, nargs="+", default=[0.2, 0.6, 0.9, 1.2])
    ap.add_argument("--slo-ttft", type=float, default=0.5, help="秒")
    ap.add_argument("--slo-tpot", type=float, default=0.04, help="秒")
    a = ap.parse_args()

    print("== 不同负载下的服务指标（合成时间线）==")
    for load in a.load:
        m = metrics(synth_trace(a.n, load), a.slo_ttft, a.slo_tpot)
        print(f"\n-- load={load}")
        for k, v in m.items():
            print(f"  {k:24s} " + (f"{v[0]:9.1f} / {v[1]:9.1f}" if isinstance(v, tuple) else f"{v:9.3f}"))

    print("\n== MFU 估算 ==")
    # H100 SXM BF16 稠密峰值约 989 TFLOPS（NVIDIA 官方规格，不含稀疏）
    peak = 989e12
    for name, n, tps, tr in [("7B 训练, 每卡 3000 tok/s", 7e9, 3000, True),
                             ("70B 训练, 每卡 400 tok/s", 70e9, 400, True),
                             ("7B 推理 decode, 每卡 2500 tok/s", 7e9, 2500, False)]:
        print(f"  {name:32s} MFU = {mfu(n, tps, peak, tr) * 100:5.1f}%")
    print("\n[小结] 负载升高时 P99 先于均值恶化；吞吐还在涨时 goodput 可能已经下降。"
          "\n       decode 的 MFU 很低是常态：它受访存限制而不是算力限制（见 M01、M10）。"
          "\n[问题库] P05 prefill/decode 干扰与 TTFT-TPOT 取舍；P30 SLO 感知调度")


if __name__ == "__main__":
    main()
