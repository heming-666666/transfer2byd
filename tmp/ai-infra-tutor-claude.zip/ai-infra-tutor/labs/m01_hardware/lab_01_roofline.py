"""[M01-L01] Roofline：理论分析 + 在本机 CPU 上实测

目标：会计算算子的算术强度（Arithmetic Intensity, AI = FLOPs / 访存字节），
      用 Roofline 判断它在某硬件上是算力受限还是带宽受限；并在本机实测"屋顶"。
先预测：
  1. 4096×4096 的 GEMM 和 batch=1 的 decode GEMV（1×4096 乘 4096×4096），在 H100 上谁是访存受限？
  2. 你的 CPU 上，矩阵越大 GFLOPS 越高还是越低？到哪里饱和？
可调参数：--sizes（实测 GEMM 尺寸）、--copy-mb（带宽测试数据量）、--threads
暴露的问题：decode/逐元素算子天然访存受限 → PROBLEM_BANK P01、P11
对应论文：Roofline（Williams et al., CACM 2009）；Data Movement Is All You Need（MLSys'21）
"""
import argparse
import time

import numpy as np
import torch

HW = {  # 峰值算力（FLOP/s）与带宽（B/s），NVIDIA 官方数据表，BF16 稠密
    "A100": (312e12, 2.0e12),
    "H100": (989e12, 3.35e12),
}


def gemm_ai(m, n, k, bytes_per=2):
    flops = 2 * m * n * k
    traffic = bytes_per * (m * k + k * n + m * n)    # 理想情况：每个矩阵只读/写一次
    return flops, traffic, flops / traffic


def analyze():
    cases = {
        "GEMM 4096^3 (训练/prefill)": gemm_ai(4096, 4096, 4096),
        "GEMM 512x4096x4096 (prefill 512 token)": gemm_ai(512, 4096, 4096),
        "GEMV 1x4096x4096 (decode batch=1)": gemm_ai(1, 4096, 4096),
        "GEMM 32x4096x4096 (decode batch=32)": gemm_ai(32, 4096, 4096),
        # 逐元素：读 1 写 1，每元素 1 FLOP
        "elementwise add 16M": (16e6, 2 * 2 * 16e6, 16e6 / (4 * 16e6)),
    }
    print(f"{'算子':40s} {'AI(FLOP/B)':>10s}  " + "  ".join(f"{h:>18s}" for h in HW))
    for name, (f, t, ai) in cases.items():
        row = []
        for peak, bw in HW.values():
            ridge = peak / bw                      # 屋脊点：AI 超过它才可能算力受限
            attain = min(peak, ai * bw)
            row.append(f"{'算力' if ai >= ridge else '访存'} {attain / peak * 100:5.1f}%峰值")
        print(f"{name:40s} {ai:10.1f}  " + "  ".join(f"{r:>18s}" for r in row))
    for h, (peak, bw) in HW.items():
        print(f"  {h} 屋脊点 = {peak / bw:.0f} FLOP/B")


def bench(fn, reps=5):
    fn()                                           # 预热
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); ts.append(time.perf_counter() - t0)
    return min(ts)


def measure(sizes, copy_mb):
    print("\n== 本机实测：GEMM 吞吐（torch.matmul, fp32）==")
    best = 0
    for n in sizes:
        a, b = torch.randn(n, n), torch.randn(n, n)
        t = bench(lambda: a @ b)
        gf = 2 * n ** 3 / t / 1e9
        best = max(best, gf)
        print(f"  n={n:5d}  {t * 1e3:8.2f} ms  {gf:8.1f} GFLOP/s  AI(fp32)={gemm_ai(n, n, n, 4)[2]:.0f}")
    print("\n== 本机实测：内存带宽（大数组拷贝，读+写）==")
    src = np.ones(int(copy_mb * 2 ** 20 // 8))
    dst = np.empty_like(src)
    t = bench(lambda: np.copyto(dst, src))
    bw = 2 * src.nbytes / t
    print(f"  拷贝 {copy_mb} MB: {bw / 1e9:.1f} GB/s")
    print(f"\n本机屋脊点 ≈ {best * 1e9 / bw:.1f} FLOP/B（峰值 GEMM {best:.0f} GFLOP/s ÷ 带宽 {bw / 1e9:.1f} GB/s）")
    v = torch.randn(4096); W = torch.randn(4096, 4096)
    t = bench(lambda: W @ v)
    print(f"  GEMV 4096x4096: {2 * 4096 * 4096 / t / 1e9:.1f} GFLOP/s，"
          f"有效带宽 {4 * 4096 * 4096 / t / 1e9:.1f} GB/s（权重读取主导）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", type=int, nargs="+", default=[64, 256, 512, 1024, 2048])
    ap.add_argument("--copy-mb", type=int, default=256)
    ap.add_argument("--threads", type=int, default=0, help="0=默认")
    a = ap.parse_args()
    if a.threads:
        torch.set_num_threads(a.threads)
    print(f"torch 线程数 = {torch.get_num_threads()}")
    print("== 理论 Roofline 分析 ==")
    analyze()
    measure(a.sizes, a.copy_mb)
    print("\n[小结] GEMV 的 AI≈1 FLOP/B，远低于任何硬件的屋脊点，所以 decode 阶段算力大量闲置。"
          "\n       把多个请求合批（batch）是提高 AI 的最直接手段（M10、M11）。"
          "\n[问题库] P01 decode 访存受限；P11 小算子开销")


if __name__ == "__main__":
    main()
