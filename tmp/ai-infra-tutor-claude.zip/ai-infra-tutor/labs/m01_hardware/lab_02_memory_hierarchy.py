"""[M01-L02] 存储层次：工作集大小与访问模式如何决定有效带宽

目标：观察缓存层次（L1/L2/L3/DRAM）对带宽的影响，以及顺序访问与跨步访问的差异。
      GPU 上的 SRAM(shared memory)/L2/HBM 层次与之同理，FlashAttention 正是利用这一点。
先预测：
  1. 工作集从 16KB 增到 1GB，求和带宽会怎样变化？拐点大致在哪？
  2. 步长（stride）从 1 增到 16（每次跳过若干 float64），有效带宽下降多少？为什么？
可调参数：--max-mb、--strides、--reps
暴露的问题：数据搬运而非计算往往才是瓶颈 → PROBLEM_BANK P01、P12
对应论文：FlashAttention（IO 感知）；Data Movement Is All You Need
"""
import argparse
import time

import numpy as np


def bandwidth(arr, reps):
    arr.sum()                                       # 预热，载入缓存
    t0 = time.perf_counter()
    for _ in range(reps):
        arr.sum()
    dt = (time.perf_counter() - t0) / reps
    return arr.nbytes / dt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-mb", type=int, default=512)
    ap.add_argument("--strides", type=int, nargs="+", default=[1, 2, 4, 8, 16])
    ap.add_argument("--reps", type=int, default=0, help="0=自动")
    a = ap.parse_args()

    print("== 工作集大小 vs 求和带宽（顺序读）==")
    kb = 16
    while kb <= a.max_mb * 1024:
        n = kb * 1024 // 8
        arr = np.ones(n)
        reps = a.reps or max(3, int(2e8 // arr.nbytes))   # 小数组多重复几次，减少计时噪声
        bw = bandwidth(arr, reps)
        bar = "#" * int(bw / 2e9)
        print(f"  {kb / 1024:9.3f} MB  {bw / 1e9:7.1f} GB/s  {bar[:60]}")
        kb *= 4

    print("\n== 跨步访问（总读取元素数相同）==")
    base = np.ones(16 * 2 ** 20)                    # 128MB，远大于缓存
    n_read = len(base) // max(a.strides)
    for s in a.strides:
        view = base[: n_read * s : s]               # 读取 n_read 个元素，间隔 s
        t0 = time.perf_counter()
        for _ in range(5):
            view.sum()
        dt = (time.perf_counter() - t0) / 5
        useful = n_read * 8 / dt
        print(f"  stride={s:3d}: 有效带宽 {useful / 1e9:6.1f} GB/s"
              f"（每 64B 缓存行只用到 {min(8, max(1, 8 // s))}/8 个元素）")
    print("\n[小结] 工作集超出缓存后带宽骤降；跨步访问浪费缓存行。GPU 上对应的是"
          "\n       合并访存（coalescing）和分块（tiling）：让数据在片上 SRAM 里被反复使用。"
          "\n[问题库] P01 访存受限；P12 算子融合与数据复用")


if __name__ == "__main__":
    main()
