# M01 动手练习

> 参考答案：`exercises/answers/M01.md`（作答前不要看）。

### Q-M01-L3-01（改代码，20 分钟）
在 `lab_01_roofline.py` 的 `analyze()` 中加入两个算子：(a) LayerNorm（每元素约 8 FLOPs，读 1 写 1，BF16）；(b) prefill 阶段 `QK^T`，形状 `[s, d] × [d, s]`，s=4096、d=128。算出它们的 AI，判断在 H100 上的瓶颈，并解释为什么 FlashAttention 要把 `QK^T` 和 softmax 融合在一起。

### Q-M01-L3-02（测量，20 分钟）
用 `--threads 1` 和默认线程数各运行一次 L01，填写下表，并回答：多线程提高的是峰值算力还是带宽？本机的屋脊点怎样变化？

| 线程数 | GEMM 峰值 GFLOP/s | 拷贝带宽 GB/s | 屋脊点 FLOP/B |
| --- | --- | --- | --- |
| 1 | | | |
| 默认 | | | |

### Q-M01-L3-03（改代码 + 解释，15 分钟）
在 L02 中新增“随机访问”测试：用 `np.random.permutation` 生成索引，读取 128MB 数组中的 200 万个元素（`arr[idx].sum()`），与顺序读同样数量的元素比较有效带宽。说明结果对 embedding 查表、KV Cache 分页（M11）的启示。

### Q-M01-L4-01（研究型，30 分钟）
Roofline 假设“每个字节只从 HBM 读一次”。请为 decode 阶段 batch=B 的注意力（每条序列上下文长度 L、GQA 下 KV 头数 h_kv、头维 d）写出 FLOPs 与访存字节的表达式，画出 AI 随 B 和 L 的变化，并说明：为什么增大 batch 能提升线性层的 AI，却**不能**提升注意力部分的 AI？这对“decode 注意力受带宽限制”这一问题（P01、P07）意味着什么？
