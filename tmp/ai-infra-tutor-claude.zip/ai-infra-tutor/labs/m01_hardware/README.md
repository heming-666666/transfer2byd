# M01 硬件与性能模型：GPU 架构、存储层次、算术强度与 Roofline

- **对应任务**：D1-T05（讲义）、D1-T06（L01）、D1-T07（L02）、D1-T08（论文 ★`roofline`）
- **先修**：M00
- **预计学时**：2 小时
- **学习目标**：
  1. 说出 GPU 的执行层次（SM、warp、线程）和存储层次（寄存器 → 共享内存/L1 → L2 → HBM），以及每层大致的容量和带宽。
  2. 给定任意矩阵乘的形状，算出 FLOPs、最少访存字节和算术强度（Arithmetic Intensity, AI）。
  3. 用 Roofline 判断一个算子在 A100/H100 上受算力限制还是受带宽限制，并给出可达到的性能上限。
  4. 在本机实测出“屋脊点”，并用它解释后面各模块里看到的现象。

## 1. 核心讲义

### 1.1 GPU 是一台“吞吐机器”

CPU 用少量强大的核心、大缓存和复杂的乱序执行把单线程延迟降到最低；GPU 则用成千上万个简单线程，靠“同时有很多活可干”来掩盖延迟。以 NVIDIA 为例：

- **SM**（Streaming Multiprocessor，流式多处理器）：GPU 的基本计算单元。A100 有 108 个 SM，H100 SXM 有 132 个。每个 SM 里有 CUDA 核（标量/向量运算）和 **Tensor Core**（专做小矩阵乘累加，是 BF16/FP8 峰值算力的来源）。
- **warp**：32 个线程组成一个 warp，按 SIMT（单指令多线程）方式同步执行。分支发散（同一 warp 内的线程走不同分支）会让效率下降。
- **线程块（block）**：一组线程被调度到同一个 SM 上，可以共享片上的共享内存（shared memory）并同步。Triton 的“program”大致对应一个 block（M03）。

**存储层次**（数量级，以 H100 为例，具体数值请以官方白皮书为准）：

| 层次 | 容量 | 带宽/延迟 | 谁来管理 |
| --- | --- | --- | --- |
| 寄存器 | 每个 SM 256KB | 最快 | 编译器 |
| 共享内存 / L1 | 每个 SM 最多约 228KB | 很快（片上） | 程序员显式管理（tiling 就发生在这里） |
| L2 缓存 | 约 50MB | 较快 | 硬件 |
| HBM 显存 | 80GB | 约 3.35TB/s | 程序员（“读一遍权重”就是读这里） |
| 主机内存（经 PCIe） | 数百 GB | 每方向几十 GB/s | offload（M04）、KV 卸载（M11） |
| 其他 GPU（NVLink / InfiniBand） | — | 节点内数百 GB/s；节点间每卡几十 GB/s | 集合通信（M05） |

**关键直觉**：越往下容量越大、越慢。高性能 kernel 的全部艺术，就是**让数据尽可能在上层被重复使用**，少往下层跑。

### 1.2 算术强度与 Roofline

一个算子做了 `F` 次浮点运算，至少要搬运 `B` 字节数据，则

```
算术强度 AI = F / B        （单位：FLOP/Byte）
可达性能 ≤ min( 峰值算力,  AI × 显存带宽 )
屋脊点（ridge point） = 峰值算力 / 显存带宽
```

- AI **低于**屋脊点：受带宽限制（memory-bound），提升算力没有用，要么减少数据搬运，要么提高复用。
- AI **高于**屋脊点：受算力限制（compute-bound），才轮到优化计算本身。

H100：989 TFLOPS / 3.35 TB/s ≈ **295 FLOP/B**；A100：312 / 2.0 ≈ **156 FLOP/B**。注意屋脊点在一代代变高：算力比带宽涨得快，越来越多的算子落到了受带宽限制的一侧，这也是 FlashAttention、算子融合、量化越来越重要的根本原因。

### 1.3 例题：矩阵乘的算术强度

`C[M,N] = A[M,K] · B[K,N]`，BF16（2 字节）：

- FLOPs = `2·M·N·K`（每个乘加算 2 次）
- 最少访存 = `2·(M·K + K·N + M·N)` 字节（每个矩阵读或写一次）
- 方阵 `M=N=K=4096`：AI = 2·4096³ / (2·3·4096²) = 4096/3 ≈ **1365**，远高于 295，受算力限制。
- decode 时的 GEMV：`M=1, N=K=4096`：AI ≈ 2·4096² / (2·4096²) ≈ **1**，受带宽限制，只能用到 H100 峰值算力的 0.3%。
- batch=32 的 decode：`M=32`，AI ≈ 31.5，仍然受带宽限制，但已经比 batch=1 好 30 倍。**这就是推理系统拼命凑 batch 的原因。**

### 1.4 Roofline 的局限

- 它只给出**上限**，不说明怎样达到；kernel 的实现质量（tiling、流水线、指令选择）决定能离上限多近。
- 单一的“显存带宽”假设数据只从 HBM 来。有缓存复用时，可以画“分层 roofline”（L2、共享内存各一条斜线）。
- 没有考虑**开销**：小算子的耗时往往被 kernel 启动、Python 分发主导（M02），这时 roofline 预测的时间远小于实际。
- 没有考虑通信：分布式场景要再加一条“网络带宽”屋顶（M05、M07）。

## 2. 实验

### M01-L01 Roofline：理论分析 + 本机实测（`lab_01_roofline.py`）

- **目标**：计算 5 类算子在 A100/H100 上的位置，并实测本机 CPU 的 GEMM 峰值与内存带宽，得到本机屋脊点。
- **命令**：`python labs/m01_hardware/lab_01_roofline.py`（可加 `--threads 1` 对比）
- **先预测**：
  1. 4096³ GEMM 和 batch=1 的 GEMV，在 H100 上谁受带宽限制？
  2. 你的 CPU 上，矩阵越大 GFLOPS 越高还是越低？到哪里饱和？
- **实测输出摘要**（构建机：16 逻辑核，torch 8 线程）：
  - 理论部分：GEMV 的 AI = 1.0，在 H100 上只能达到峰值的 0.3%；batch=32 时为 10.7%。
  - GEMM 实测：n=64 时 60 GFLOP/s，n=256 时 314，n≥1024 时饱和在约 **543 GFLOP/s**。
  - 内存拷贝带宽约 **51 GB/s** → 本机屋脊点约 **10.6 FLOP/B**（比 H100 低约 28 倍）。
  - GEMV 4096×4096 的有效带宽约 107 GB/s。它高于拷贝带宽，是因为 64MB 的权重矩阵有一部分命中了 CPU 的大缓存，而且读比“读+写”的拷贝更省。
- **解读**：小矩阵达不到峰值，是因为并行度不够、开销占比大；本机屋脊点很低，意味着在 CPU 上大部分算子“看起来”都受算力限制——这一点在 M10-L02 解释 batch 扩展的拐点时还会用到。
- **扫描建议**：`--sizes 32 64 128 256 384 512 768 1024`，画出 GFLOPS 随 n 的曲线；`--threads 1 2 4 8` 观察并行度。
- **暴露的问题**：[P01](../../research/PROBLEM_BANK.md#p01) decode 受访存限制；[P11](../../research/PROBLEM_BANK.md#p11) 小算子开销。

### M01-L02 存储层次（`lab_02_memory_hierarchy.py`）

- **目标**：观察工作集大小与访问步长对有效带宽的影响。
- **命令**：`python labs/m01_hardware/lab_02_memory_hierarchy.py`
- **先预测**：
  1. 工作集从 16KB 增到 1GB，求和带宽会怎样变化？拐点大致在哪里？
  2. 步长从 1 增到 16，有效带宽下降多少？为什么？
- **实测输出摘要**：工作集在 0.25MB~4MB 时带宽最高（约 53 GB/s，数据在 L2/L3 里）；到 16MB 降到约 30 GB/s，64MB 以上稳定在约 25 GB/s（已经超出缓存，走主存）。步长 1 → 2 → 4 → 8 → 16 时，有效带宽为 33 → 25 → 10 → 4.5 → 2.3 GB/s。
- **解读**：步长为 8 个 float64 时，每条 64 字节的缓存行只用到 1 个元素，浪费了 7/8 的带宽。GPU 上的对应概念是**合并访存（coalescing）**：一个 warp 的 32 个线程最好访问连续地址。16KB 时带宽偏低，是因为数组太小，计时被函数调用开销主导（又一个 overhead 的例子）。
- **扫描建议**：`--strides 1 3 5 7 9`，观察非 2 的幂次步长；`--max-mb 1024`。
- **暴露的问题**：[P01](../../research/PROBLEM_BANK.md#p01)、[P12](../../research/PROBLEM_BANK.md#p12)。

## 3. 常见误区

- “GPU 越贵、算力越高，推理就越快”：decode 主要看显存带宽和容量，不是 TFLOPS。
- “AI 只取决于算子类型”：同一个矩阵乘，batch 不同，AI 可以差几十倍。
- “算子融合会减少计算量”：融合减少的是**访存**，计算量不变（M03）。
- 把 TFLOPS 和 TOPS、稠密和稀疏峰值混在一起比较：厂商宣传的“稀疏峰值”通常是稠密峰值的 2 倍，本课程一律使用 BF16 稠密峰值。

## 4. 论文与延伸阅读

- ★ `roofline`：Williams, Waterman, Patterson. *Roofline: an insightful visual performance model for multicore architectures*. CACM 2009. DOI: https://doi.org/10.1145/1498765.1498785 。精读问题见 `papers/PAPER_STUDY_GUIDE.md`。
- 选读：`datamove`（*Data Movement Is All You Need*，Transformer 训练中数据搬运才是瓶颈）。
- 资源：Horace He《Making Deep Learning Go Brrrr From First Principles》（把耗时分为计算、访存、开销三类）；*How to Scale Your Model* 中 Roofline 和 GPU 两章。

## 5. 自测题

Q-M01-L1-01 ~ Q-M01-L4-01（`exercises/question_bank.md`）；动手练习见 `exercises.md`。
