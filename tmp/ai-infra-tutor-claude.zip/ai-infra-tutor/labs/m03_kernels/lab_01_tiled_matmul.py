"""[M03-L01] 矩阵乘分块（tiling）：为什么分块能把访存降一个数量级

目标：用"片上缓存可容纳 M 个元素"的抽象模型，计算朴素/分块矩阵乘从慢速内存（HBM/DRAM）
      搬运的数据量，理解 tile 大小与算术强度的关系；再实测 numpy 分块实现验证正确性。
先预测：
  1. N=1024 时朴素三重循环（无缓存复用）要从慢速内存读多少元素？分块 T=64 时呢？
  2. tile 翻倍，访存量怎么变？tile 能无限大吗？受什么限制？
可调参数：--n、--tiles、--sram-kb（片上存储容量，H100 每个 SM 共享内存最多 228KB）
暴露的问题：kernel 性能取决于数据复用；tile 选择是调优问题 → PROBLEM_BANK P13
对应论文：Triton（MAPL'19，以 block 为编程单位）；TVM / Ansor（自动搜索 tile）
真实框架对照：NVIDIA/cutlass include/cutlass/gemm/ 的 threadblock tile 配置；
              Triton 官方教程 03-matrix-multiplication.py
"""
import argparse
import time

import numpy as np


def traffic_naive(n):
    # C[i,j] = sum_k A[i,k]B[k,j]：每个 C 元素读 A 的一行 + B 的一列，没有复用
    return 2 * n ** 3 + n * n


def traffic_tiled(n, t):
    # C 按 t×t 分块；每个 C 块需要读 (n/t) 个 A 块 + (n/t) 个 B 块，每块 t^2 元素
    blocks = (n // t) ** 2
    return blocks * (2 * (n // t) * t * t) + n * n   # = 2n^3/t + n^2


def tiled_matmul(A, B, t):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=A.dtype)
    for i in range(0, n, t):
        for j in range(0, n, t):
            acc = np.zeros((t, t), dtype=A.dtype)       # 对应寄存器/共享内存里的累加器
            for k in range(0, n, t):
                acc += A[i:i + t, k:k + t] @ B[k:k + t, j:j + t]   # 两个 tile 在"片上"相乘
            C[i:i + t, j:j + t] = acc
    return C


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1024)
    ap.add_argument("--tiles", type=int, nargs="+", default=[8, 16, 32, 64, 128, 256])
    ap.add_argument("--sram-kb", type=int, default=228)
    a = ap.parse_args()
    n = a.n
    flops = 2 * n ** 3
    print(f"== 访存模型（N={n}，fp16 每元素 2 字节，片上容量 {a.sram_kb}KB）==")
    base = traffic_naive(n)
    print(f"  朴素：读写 {base:.3e} 元素，AI = {flops / (2 * base):6.2f} FLOP/B")
    for t in a.tiles:
        tr = traffic_tiled(n, t)
        need_kb = 3 * t * t * 2 / 1024                  # A、B、C 三个 tile 同时在片上
        ok = "放得下" if need_kb <= a.sram_kb else "放不下!"
        print(f"  T={t:4d}：读写 {tr:.3e} 元素（{base / tr:6.1f}× 更少），"
              f"AI = {flops / (2 * tr):7.1f} FLOP/B，片上需 {need_kb:7.1f}KB {ok}")

    print("\n== numpy 分块实现：正确性与耗时（python 循环有开销，仅用于理解）==")
    m = 512
    A = np.random.default_rng(0).standard_normal((m, m)).astype(np.float32)
    B = np.random.default_rng(1).standard_normal((m, m)).astype(np.float32)
    ref = A @ B
    for t in [16, 64, 128, 512]:
        t0 = time.perf_counter()
        C = tiled_matmul(A, B, t)
        dt = time.perf_counter() - t0
        print(f"  T={t:4d}: {dt * 1e3:8.1f} ms  max误差={np.abs(C - ref).max():.2e}  "
              f"python 循环次数={(m // t) ** 3}")
    print("\n[小结] 访存量 ≈ 2N³/T：tile 越大复用越多，但受片上存储容量、寄存器数和并行度限制。"
          "\n       numpy 版里 T 太小时被 Python 循环开销拖慢——对应 GPU 上 tile 太小导致 launch/调度开销。"
          "\n[问题库] P13 自动调优与可移植性；P12 数据复用")


if __name__ == "__main__":
    main()
