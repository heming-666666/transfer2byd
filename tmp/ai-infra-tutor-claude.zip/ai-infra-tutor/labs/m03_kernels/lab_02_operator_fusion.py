"""[M03-L02] 算子融合（operator fusion）：省掉中间结果的读写

目标：对比 bias+GELU+残差+缩放 这一串逐元素算子在"每步单独执行"和"融合为一次遍历"时的
      访存量与耗时；理解为什么逐元素算子融合几乎总是划算的。
先预测：
  1. 5 个逐元素算子串联，未融合时读写了多少次整张量？融合后呢？
  2. 实测加速比会接近理论访存比吗？为什么可能达不到？
可调参数：--rows、--cols、--reps
暴露的问题：融合机会需要编译器发现；动态形状/图断裂会阻止融合 → PROBLEM_BANK P12
对应论文：PyTorch 2（TorchInductor 自动融合）；TVM（算子融合规则）；FlashAttention（极致融合）
真实框架对照：torch/_inductor/scheduler.py（融合决策）；Liger-Kernel 中手写的融合 Triton kernel
说明：本机没有 C 编译器，torch.compile/Triton 无法在 CPU 上生成真正的融合 kernel。因此用两种方式量化：
  (a) 逐算子计时，看每个算子的耗时是否与其读写量成正比；
  (b) 实测"读 2 张量写 1 张量"的单遍遍历耗时，作为理想融合 kernel 的下界（融合 kernel 也只需这一遍）。
  另外给出"框架层面按块拼凑"的版本作为反例：它并不能带来融合收益。
"""
import argparse
import time

import torch


def unfused(x, b, r):
    y = x + b                       # 读 x,b 写 y
    y = torch.nn.functional.gelu(y)  # 读 y 写 y'
    y = y + r                       # 读 y',r 写 y''
    y = y * 0.5                     # 读写
    return y.clamp_(-10, 10)        # 读写（原地）


def fused_blocked(x, b, r, block=4096):
    """模拟融合 kernel：按行块处理，块足够小能留在缓存里，每个元素只从 DRAM 读/写一次。"""
    out = torch.empty_like(x)
    rows = max(1, block // x.shape[1])          # 每块包含的行数
    for i in range(0, x.shape[0], rows):
        sl = slice(i, i + rows)
        y = x[sl] + b
        y = torch.nn.functional.gelu(y)
        y.add_(r[sl]).mul_(0.5).clamp_(-10, 10)
        out[sl] = y
    return out


def timeit(fn, reps):
    fn()
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    return (time.perf_counter() - t0) / reps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=8192)
    ap.add_argument("--cols", type=int, default=4096)
    ap.add_argument("--reps", type=int, default=5)
    a = ap.parse_args()
    torch.manual_seed(0)
    x = torch.randn(a.rows, a.cols); r = torch.randn(a.rows, a.cols); b = torch.randn(a.cols)
    nbytes = x.numel() * 4

    # 理论访存（以"整张量读或写一次"为单位）
    unfused_io = 2 + 2 + 3 + 2 + 2          # 每步读写次数之和（bias 很小忽略）
    fused_io = 3                            # 读 x、读 r、写 out
    print(f"== 理论访存：张量 {nbytes / 2 ** 20:.0f} MB ==")
    print(f"  未融合：约 {unfused_io} 次整张量读写 = {unfused_io * nbytes / 2 ** 30:.2f} GB")
    print(f"  融合：  约 {fused_io} 次整张量读写 = {fused_io * nbytes / 2 ** 30:.2f} GB"
          f"（理论上限加速 {unfused_io / fused_io:.1f}×）")

    ref = unfused(x, b, r)
    out = fused_blocked(x, b, r, block=64 * 1024)
    print(f"\n  结果一致性 max|差| = {(ref - out).abs().max().item():.2e}")
    print("\n== (a) 逐算子计时 ==")
    y = x + b
    ops = [("x + b        (读2写1)", lambda: x + b),
           ("gelu(y)      (读1写1)", lambda: torch.nn.functional.gelu(y)),
           ("y + r        (读2写1)", lambda: y + r),
           ("y * 0.5      (读1写1)", lambda: y * 0.5),
           ("clamp_       (读1写1)", lambda: y.clamp_(-10, 10))]
    for name, fn in ops:
        t = timeit(fn, a.reps)
        print(f"  {name} {t * 1e3:7.1f} ms")
    t_u = timeit(lambda: unfused(x, b, r), a.reps)
    print(f"  整串未融合            {t_u * 1e3:7.1f} ms  有效带宽 {unfused_io * nbytes / t_u / 1e9:6.1f} GB/s")

    print("\n== (b) 理想融合 kernel 的下界：单遍 读 x、r 写 out ==")
    buf = torch.empty_like(x)
    t_1 = timeit(lambda: torch.add(x, r, out=buf), a.reps)
    print(f"  单遍遍历 {t_1 * 1e3:7.1f} ms → 融合后最多可快 {t_u / t_1:4.2f}×（若 GELU 计算不成为新瓶颈）")

    print("\n== 反例：框架层面按块拼凑（每块内仍是多个独立算子）==")
    for blk in [16 * 1024, 4 * 1024 * 1024]:
        t_f = timeit(lambda: fused_blocked(x, b, r, block=blk), a.reps)
        print(f"  block={blk // 1024:5d}K元素 {t_f * 1e3:7.1f} ms  相对未融合 {t_u / t_f:4.2f}×")
    print("\n[小结] 逐元素算子受访存限制，耗时大致正比于读写遍数；真正的融合必须发生在单个 kernel"
          "\n       内部（数据留在寄存器里），在 Python/框架层面切块拼凑得不到收益，块小时反而被开销拖慢。"
          "\n       这正是 TorchInductor/XLA/TVM 自动生成融合 kernel 的价值。GELU 在 CPU 上计算较重，"
          "\n       说明'访存受限'的判断要结合具体硬件（GPU 上它仍是访存受限）。"
          "\n[问题库] P12 融合机会与编译器自动化的边界")


if __name__ == "__main__":
    main()
