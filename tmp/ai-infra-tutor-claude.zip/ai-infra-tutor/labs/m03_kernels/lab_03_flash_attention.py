"""[M03-L03] FlashAttention 的核心：分块 + 在线 softmax（online softmax）

目标：从零实现分块注意力，验证与标准注意力数值一致；用 IO 模型比较标准注意力与
      FlashAttention 对 HBM 的访问量，理解"不把 N×N 矩阵写回 HBM"带来的收益。
先预测：
  1. 标准注意力需要在 HBM 中存储多大的中间矩阵？N=8192、fp16 时是多少 MB（每个头）？
  2. 在线 softmax 遇到更大的新最大值时，之前累加的结果该怎么修正？
可调参数：--n（序列长度）、--d（头维度）、--block（分块大小）、--sram-kb
暴露的问题：长上下文下注意力的显存与访存；kernel 需要随硬件重写 → PROBLEM_BANK P07、P13
对应论文：FlashAttention（2205.14135）定理 2 的 IO 复杂度 Θ(N²d²/M)；FlashAttention-2/3
真实框架对照：Dao-AILab/flash-attention csrc/flash_attn/src/flash_fwd_kernel.h；
              Triton 官方教程 06-fused-attention.py
"""
import argparse
import math
import time

import torch


def standard_attention(q, k, v):
    s = q @ k.T / math.sqrt(q.shape[-1])     # N×N 分数矩阵（写回 HBM）
    p = torch.softmax(s, dim=-1)             # 再读、再写 N×N
    return p @ v


def flash_attention(q, k, v, block):
    """单头前向。外层遍历 Q 块，内层遍历 K/V 块，维护行最大值 m、行和 l、输出累加 o。"""
    n, d = q.shape
    scale = 1 / math.sqrt(d)
    out = torch.empty_like(q)
    for i in range(0, n, block):
        qi = q[i:i + block] * scale
        m = torch.full((qi.shape[0], 1), -float("inf"))
        l = torch.zeros(qi.shape[0], 1)
        o = torch.zeros(qi.shape[0], d)
        for j in range(0, n, block):
            s = qi @ k[j:j + block].T                       # 只在"片上"出现 block×block
            m_new = torch.maximum(m, s.max(dim=1, keepdim=True).values)
            p = torch.exp(s - m_new)
            corr = torch.exp(m - m_new)                     # 旧结果按新最大值重新缩放
            l = l * corr + p.sum(dim=1, keepdim=True)
            o = o * corr + p @ v[j:j + block]
            m = m_new
        out[i:i + block] = o / l
    return out


def io_model(n, d, sram_bytes, bytes_per=2):
    std = bytes_per * (4 * n * d + 4 * n * n)        # 读 QKV 写 O + 写 S、读 S、写 P、读 P
    m = sram_bytes / bytes_per
    blk = max(1, int(m // (4 * d)))                   # FA1 论文中 Bc = ceil(M / 4d)
    passes = math.ceil(n / blk)                       # K/V 被完整读取的次数
    flash = bytes_per * (2 * n * d + passes * 2 * n * d)
    return std, flash, blk


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1024)
    ap.add_argument("--d", type=int, default=64)
    ap.add_argument("--block", type=int, default=128)
    ap.add_argument("--sram-kb", type=int, default=192)
    a = ap.parse_args()
    torch.manual_seed(0)
    q, k, v = (torch.randn(a.n, a.d) for _ in range(3))

    ref = standard_attention(q, k, v)
    t0 = time.perf_counter(); out = flash_attention(q, k, v, a.block); dt = time.perf_counter() - t0
    print("== 正确性 ==")
    print(f"  N={a.n}, d={a.d}, block={a.block}: max|差| = {(ref - out).abs().max().item():.2e}"
          f"  （分块实现耗时 {dt * 1e3:.1f} ms，CPU 上不追求速度）")
    q2 = q.clone(); q2[0] *= 50                       # 制造很大的分数，检验数值稳定
    print(f"  大数值输入下 max|差| = {(standard_attention(q2, k, v) - flash_attention(q2, k, v, a.block)).abs().max().item():.2e}")

    print(f"\n== HBM 访问量模型（fp16，片上 {a.sram_kb}KB，每个头）==")
    print(f"  {'N':>6s} {'S矩阵MB':>9s} {'标准(MB)':>10s} {'Flash(MB)':>10s} {'比值':>6s}")
    for n in [1024, 4096, 8192, 32768, 131072]:
        std, fl, blk = io_model(n, a.d, a.sram_kb * 1024)
        print(f"  {n:6d} {2 * n * n / 2 ** 20:9.1f} {std / 2 ** 20:10.1f} {fl / 2 ** 20:10.1f} {std / fl:6.1f}×")
    print(f"  （片上块大小 Bc = {io_model(1024, a.d, a.sram_kb * 1024)[2]}）")
    print("\n[小结] FlashAttention 计算量不变（甚至略多），但不再把 N×N 矩阵写回 HBM，"
          "\n       显存从 O(N²) 降为 O(N)。它说明：在访存受限的世界里，'重算'可以比'存储'便宜。"
          "\n[问题库] P07 长上下文；P13 kernel 随硬件演进需要重写（FA3 针对 Hopper）")


if __name__ == "__main__":
    main()
