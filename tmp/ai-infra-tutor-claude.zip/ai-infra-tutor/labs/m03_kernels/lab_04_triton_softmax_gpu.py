"""[M03-L04]【选做·需 GPU】用 Triton 写一个融合 softmax kernel

目标：体验以"块（block）"为单位的 GPU 编程：一个 program 处理一行，读一次、在片上算完
      max/exp/sum/除法、写一次。与 torch.softmax 和"未融合手写 softmax"比较带宽。
先预测：未融合手写 softmax（5 个算子）比融合 kernel 慢几倍？
可调参数：--rows、--cols
CPU 替代：labs/m03_kernels/lab_02_operator_fusion.py（融合的访存分析）与 lab_03（在线 softmax）。
         没有 GPU 时本脚本只打印说明并以 0 退出（run_all 记为 SKIP）。
依赖：env/requirements-gpu.txt 中的 triton（随 CUDA 版 torch 一起安装）
暴露的问题：手写 kernel 的开发成本与可移植性 → PROBLEM_BANK P13
对应论文：Triton（MAPL'19）
真实框架对照：triton-lang/triton python/tutorials/02-fused-softmax.py
"""
import argparse
import sys

import torch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=4096)
    ap.add_argument("--cols", type=int, default=2048)
    a = ap.parse_args()
    try:
        import triton
        import triton.language as tl
    except ImportError:
        triton = None
    if triton is None or not torch.cuda.is_available():
        print("[SKIP] 需要 NVIDIA GPU + triton。CPU 替代实验：m03 lab_02（融合访存分析）、lab_03（在线 softmax）。")
        sys.exit(0)

    @triton.jit
    def softmax_kernel(out_ptr, in_ptr, stride, n_cols, BLOCK: tl.constexpr):
        row = tl.program_id(0)                          # 每个 program 负责一行
        offs = tl.arange(0, BLOCK)
        mask = offs < n_cols
        x = tl.load(in_ptr + row * stride + offs, mask=mask, other=-float("inf"))
        x = x - tl.max(x, axis=0)                       # 数值稳定
        num = tl.exp(x)
        y = num / tl.sum(num, axis=0)
        tl.store(out_ptr + row * stride + offs, y, mask=mask)

    def triton_softmax(x):
        out = torch.empty_like(x)
        BLOCK = triton.next_power_of_2(x.shape[1])
        softmax_kernel[(x.shape[0],)](out, x, x.stride(0), x.shape[1], BLOCK=BLOCK)
        return out

    def naive_softmax(x):
        m = x.max(dim=1, keepdim=True).values
        z = x - m
        num = torch.exp(z)
        return num / num.sum(dim=1, keepdim=True)

    x = torch.randn(a.rows, a.cols, device="cuda")
    assert torch.allclose(triton_softmax(x), torch.softmax(x, dim=1), atol=1e-6)
    nbytes = 2 * x.numel() * x.element_size()           # 理想：读一次写一次
    for name, fn in [("triton 融合", triton_softmax), ("torch.softmax", lambda t: torch.softmax(t, 1)),
                     ("手写未融合", naive_softmax)]:
        ms = triton.testing.do_bench(lambda: fn(x))
        print(f"  {name:14s} {ms:7.3f} ms  有效带宽 {nbytes / ms / 1e6:7.1f} GB/s")
    print("[小结] 融合 kernel 接近一次读写的带宽上限；未融合版本因多次 HBM 往返明显更慢。")


if __name__ == "__main__":
    main()
