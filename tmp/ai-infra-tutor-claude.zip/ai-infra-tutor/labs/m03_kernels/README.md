# M03 算子与 Kernel：矩阵乘分块、算子融合、Triton 入门、FlashAttention 的 IO 感知

- **对应任务**：D2-T02（讲义）、D2-T03~T05（L01~L03）、D2-T06（论文 ★`fa1`）；L04 为 GPU 选做
- **先修**：M01、M02
- **预计学时**：2.7 小时
- **学习目标**：
  1. 推导分块矩阵乘从慢速内存读写的数据量约为 `2N³/T + N²`，并说明 tile 大小受哪些资源限制。
  2. 解释算子融合为什么省时间，以及为什么融合必须发生在单个 kernel 内部。
  3. 读懂一个 Triton kernel：program id、`tl.arange`、mask、load/store、`constexpr` 块大小。
  4. 手推在线 softmax 的修正公式，复述 FlashAttention 的 IO 复杂度 `Θ(N²d²/M)` 与标准注意力 `Θ(Nd + N²)` 的差别。

## 1. 核心讲义

### 1.1 为什么要分块（tiling）

朴素的三重循环里，计算 `C[i,j]` 要读 A 的一整行和 B 的一整列，相邻的 `C` 元素之间没有复用，总读取约 `2N³` 个元素，算术强度只有约 0.5 FLOP/B（M01 中受带宽限制的那一端）。

**分块**：把 C 分成 `T×T` 的小块，每个小块需要 A 的 `T` 行和 B 的 `T` 列；把这两条“带子”按 `T×T` 的块依次搬进片上存储（共享内存），在片上做完乘累加。每个 A 块、B 块被搬进来一次，就参与了 `T` 次复用：

```
慢速内存读写量 ≈ (N/T)² 个 C 块 × (N/T) 步 × 2 个块 × T² 个元素 + N²（写 C）= 2N³/T + N²
算术强度 ≈ 2N³ / (2 字节 × 2N³/T) = T/2   （fp16）
```

所以 tile 越大，复用越多。但 tile 不能无限大：

- **片上容量**：A、B、C 三个 tile 要同时放在共享内存或寄存器里。T=256、fp16 时需要 384KB，超过了 H100 每个 SM 约 228KB 的共享内存。
- **并行度**：tile 太大，块的总数太少，喂不饱 132 个 SM（“尾部效应”，wave quantization）。
- **寄存器压力**：累加器放在寄存器里，寄存器不够会溢出到更慢的内存。

真实的 GEMM kernel（cuBLAS、CUTLASS）还有多层分块：线程块 tile → warp tile → 指令级 tile（Tensor Core 的 MMA 形状），以及多级流水（异步拷贝下一块的同时计算当前块）。

### 1.2 算子融合（operator fusion）

逐元素算子（加偏置、激活函数、残差加、缩放……）的算术强度都低于 1，受带宽限制。不融合时，每个算子都要从 HBM 读输入、再把输出写回 HBM：5 个算子串联，大约要读写 11 次整个张量；融合成一个 kernel 后，数据读进寄存器，连续做完全部运算再写回，只需读 2 次、写 1 次。

- 融合**不减少计算**，减少的是**访存与 kernel 启动次数**。
- 融合必须发生在**单个 kernel 内部**。在框架层面把张量切成块、每块里仍然调用多个算子，数据照样在内存里往返（L02 的反例）。
- **谁来融合**：手写（FlashAttention、Liger-Kernel 中的融合 kernel）或编译器自动完成（TorchInductor、XLA、TVM，见 M13）。矩阵乘一般作为“锚点”，只把后面的逐元素算子并进它的尾部（epilogue fusion）。

### 1.3 Triton 编程模型

Triton 让你用 Python 写 GPU kernel，编程单位是**块（block）**而不是单个线程：

```python
@triton.jit
def add_kernel(x_ptr, y_ptr, out_ptr, n, BLOCK: tl.constexpr):
    pid = tl.program_id(0)                     # 我是第几个 program（≈ 一个线程块）
    offs = pid * BLOCK + tl.arange(0, BLOCK)   # 这个 program 负责的一段下标
    mask = offs < n                            # 越界保护
    x = tl.load(x_ptr + offs, mask=mask)
    y = tl.load(y_ptr + offs, mask=mask)
    tl.store(out_ptr + offs, x + y, mask=mask)
```

线程如何划分、共享内存如何分配、怎样合并访存，大部分由编译器决定；你只需决定每个 program 处理多大的块，以及块之间怎样分工。L04（GPU 选做）实现了一个融合 softmax：一个 program 处理一行，读一次、在片上算完 max/exp/sum/除法、写一次。

### 1.4 FlashAttention：IO 感知的精确注意力

标准注意力 `O = softmax(QK^T/√d)·V` 要把 `N×N` 的分数矩阵 S 和概率矩阵 P 写回 HBM，再读出来；序列长度 N 很大时，S、P 的读写远远超过 Q、K、V 本身（N=8192 时，每个头的 S 就有 128MB）。

FlashAttention 的思路：**不让 N×N 矩阵出现在 HBM 里**。

1. 把 Q 分成行块，K、V 分成列块；每次只把一个 Q 块和一个 K/V 块读进片上 SRAM。
2. 在片上算出这一小块分数，用**在线 softmax** 逐块更新结果：维护每行的当前最大值 `m`、归一化分母 `l` 和输出累加 `o`。遇到新的块时：

```
m_new = max(m, rowmax(S_blk))
p     = exp(S_blk − m_new)
l     = l · exp(m − m_new) + rowsum(p)        ← 旧结果按新最大值“重新缩放”
o     = o · exp(m − m_new) + p · V_blk
最后  O = o / l
```

3. 反向时不保存 P，而是用保存下来的 `m`、`l` 重新计算——**用重算换存储**，在受带宽限制的世界里反而更快。

论文的定理：标准注意力的 HBM 访问量为 `Θ(Nd + N²)`，FlashAttention 为 `Θ(N²d²/M)`（M 为 SRAM 大小），对常见的 d 和 M，后者小得多。FlashAttention-2 进一步改善了并行划分和工作分配；FlashAttention-3 针对 Hopper 架构利用异步执行和 FP8。这说明**同一个算法要随硬件反复重写**，kernel 的可移植性本身就是研究问题（P13）。

## 2. 实验

### M03-L01 分块矩阵乘（`lab_01_tiled_matmul.py`）

- **先预测**：(1) N=1024 时，朴素实现要从慢速内存读多少元素？T=64 时呢？(2) tile 翻倍，访存量怎样变？tile 能无限大吗？
- **实测输出摘要**：朴素实现读写约 2.15e9 个元素，AI = 0.5；T=64 时减少 62 倍（AI = 31），T=128 时减少 120 倍（AI = 60，片上需 96KB）；T=256 时 AI = 114，但需要 384KB，**放不下**。numpy 分块实现与 `A@B` 的误差约 5e-5；T=16 时因 32768 次 Python 循环耗时 80ms，T=128 时为 1.8ms。
- **解读**：访存随 1/T 下降、AI 随 T 线性上升，正是公式 `2N³/T` 的体现；numpy 版本里 T 太小时被 Python 循环拖慢，对应 GPU 上 tile 太小、块太多带来的调度开销。
- **扫描建议**：`--n 4096 --sram-kb 164`（A100 的共享内存上限），找出能放下的最大 T。
- **真实框架对照**：NVIDIA/cutlass `include/cutlass/gemm/` 中的 threadblock tile 配置；Triton 官方教程 `03-matrix-multiplication.py`。
- **暴露的问题**：[P13](../../research/PROBLEM_BANK.md#p13)、[P12](../../research/PROBLEM_BANK.md#p12)。

### M03-L02 算子融合（`lab_02_operator_fusion.py`）

- **先预测**：(1) 5 个逐元素算子串联，未融合时读写了多少次整张量？融合后呢？(2) 实测加速比会接近理论访存比吗？
- **实测输出摘要**（128MB 张量）：理论访存 1.38GB → 0.38GB（上限 3.7 倍）。逐算子耗时：`x+b` 11.2ms、`gelu` 12.9ms、`y+r` 11.9ms、`*0.5` 10.4ms、`clamp_` 3.9ms，整串 53.7ms（有效带宽 27.5GB/s）。单遍“读 2 写 1”的遍历只要 6.4ms，即理想融合 kernel 最多可快约 8 倍。框架层面按块拼凑：块小时 0.47 倍（更慢），块大时 1.43 倍。
- **解读**：耗时大致正比于读写遍数；理想融合的上限（约 8 倍）比按“11 次 vs 3 次”估算的 3.7 倍还高，因为未融合时每个算子还要分配新的输出张量。本机没有 C++ 编译器，无法用 torch.compile 生成真正的融合 kernel，所以实验用“单遍遍历”给出下界——这是测量方法上的取舍，请在作业中说明它的局限。
- **扫描建议**：`--rows 1024 4096 16384` 观察张量大小进入、离开缓存时的变化。
- **真实框架对照**：`torch/_inductor/scheduler.py`（融合决策）；linkedin/Liger-Kernel 中的融合 Triton kernel（RMSNorm、SwiGLU、交叉熵）。
- **暴露的问题**：[P12](../../research/PROBLEM_BANK.md#p12)。

### M03-L03 FlashAttention 的在线 softmax（`lab_03_flash_attention.py`）

- **先预测**：(1) 标准注意力要在 HBM 中存储多大的中间矩阵？N=8192、fp16 时每个头多少 MB？(2) 在线 softmax 遇到更大的新最大值时，之前累加的结果怎样修正？
- **实测输出摘要**：分块实现与标准实现的最大误差约 2.7e-7；把某个 query 放大 50 倍制造极端分数后，误差约 2.4e-6，说明减去最大值的写法数值稳定。IO 模型（片上 192KB，Bc=384）：N=1024 时 HBM 访问量减少约 8.5 倍，N=8192 时减少约 11 倍，N=131072 时减少约 12 倍；N=8192 时 S 矩阵每头 128MB。
- **解读**：计算量没变，节省的是 N×N 矩阵的读写；N 越大节省越多，比值趋于一个由 d 和 M 决定的常数。
- **扫描建议**：`--block 32 64 256` 验证结果与块大小无关；`--d 128` 观察 d 变大时 IO 收益怎样变化（对照定理中的 d² 项）。
- **真实框架对照**：Dao-AILab/flash-attention `csrc/flash_attn/src/flash_fwd_kernel.h`；Triton 官方教程 `06-fused-attention.py`；flashinfer-ai/flashinfer（面向推理服务的注意力 kernel 库，见 M11）。
- **暴露的问题**：[P07](../../research/PROBLEM_BANK.md#p07) 长上下文；[P13](../../research/PROBLEM_BANK.md#p13) kernel 随硬件重写。

### M03-L04【选做·需 GPU】Triton 融合 softmax（`lab_04_triton_softmax_gpu.py`）

在有 NVIDIA GPU 的环境中运行（`bash env/setup.sh --gpu`）。比较 Triton 融合版、`torch.softmax` 与手写未融合版的带宽。没有 GPU 时脚本打印 SKIP 并以 0 退出；CPU 上请用 L02 和 L03 理解同样的原理。

## 3. 常见误区

- “FlashAttention 是近似注意力”：它是**精确**的，只改变计算顺序和存储方式。
- “tile 越大越好”：受片上容量、寄存器、并行度三重限制。
- “融合能减少 FLOPs”：只减少访存和启动开销。
- “Triton 一定比 CUDA 慢”：对很多受带宽限制的算子，Triton 能达到接近手写 CUDA 的性能；但对复杂的 Hopper 特性（TMA、warp 特化），手写或专用 DSL（ThunderKittens、TileLang）仍有优势。

## 4. 论文与延伸阅读

- 必读：`triton`（MAPL 2019）、★`fa1`（arXiv 2205.14135）、`fa2`（arXiv 2307.08691）。
- 选读：`fa3`；前沿：`flashinfer`、`thunderkittens`、`tilelang`。
- 资源：srush/GPU-Puzzles、gpu-mode/Triton-Puzzles（在线练习）；GPU MODE 第 12 讲（Flash Attention）、第 14 讲（Triton 实践指南）；BBuf/how-to-optim-algorithm-in-cuda 中的中文 CUDA-MODE 笔记。

## 5. 自测题

Q-M03-L1-01 ~ Q-M03-L4-01；动手练习见 `exercises.md`。
