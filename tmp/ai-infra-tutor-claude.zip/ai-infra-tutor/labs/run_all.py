#!/usr/bin/env python3
"""一键冒烟测试：依次运行 labs/m*/lab_*.py（默认参数），检查退出码、耗时与内存。

用法（在教学包根目录）：
  python labs/run_all.py                    # 运行全部实验
  python labs/run_all.py --only m05 m11     # 只运行指定模块
  python labs/run_all.py --save-outputs     # 同时把每个实验的输出保存到 labs/<模块>/outputs/<实验>.txt
验收标准：CPU 实验单个 ≤ 300 秒、峰值内存 ≤ 4GB；GPU 选做实验在无 GPU 时打印 [SKIP] 并以 0 退出。
"""
import argparse
import datetime
import os
import platform
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
TIME_LIMIT, MEM_LIMIT_MB = 300, 4096


def run(path):
    with tempfile.TemporaryFile(mode="w+") as out:
        t0 = time.perf_counter()
        p = subprocess.Popen([sys.executable, "-I", path], stdout=out, stderr=subprocess.STDOUT,
                             cwd=os.path.dirname(path))
        status, ru, killed = None, None, False
        while status is None:
            pid, st, r = os.wait4(p.pid, os.WNOHANG)
            if pid:
                status, ru = st, r
                break
            if time.perf_counter() - t0 > TIME_LIMIT * 2:
                p.kill(); killed = True
            time.sleep(0.05)
        dt = time.perf_counter() - t0
        p.returncode = os.waitstatus_to_exitcode(status)
        out.seek(0)
        text = out.read()
    return p.returncode, dt, ru.ru_maxrss / 1024, text, killed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*", default=[], help="模块前缀，如 m05 m11")
    ap.add_argument("--save-outputs", action="store_true")
    a = ap.parse_args()
    labs = []
    for mod in sorted(d for d in os.listdir(ROOT) if d.startswith("m") and os.path.isdir(os.path.join(ROOT, d))):
        if a.only and not any(mod.startswith(o) for o in a.only):
            continue
        for f in sorted(os.listdir(os.path.join(ROOT, mod))):
            if f.startswith("lab_") and f.endswith(".py"):
                labs.append(os.path.join(ROOT, mod, f))
    print(f"Python {platform.python_version()} | {platform.platform()} | {datetime.datetime.now():%Y-%m-%d %H:%M:%S}")
    try:
        import torch
        print(f"torch {torch.__version__} | CUDA 可用: {torch.cuda.is_available()} | CPU 线程: {torch.get_num_threads()}")
    except ImportError:
        print("未安装 torch：依赖 torch 的实验会失败，请先运行 env/setup.sh")
    print(f"共 {len(labs)} 个实验\n")
    results = []
    for path in labs:
        rel = os.path.relpath(path, ROOT)
        code, dt, mem, text, killed = run(path)
        if killed:
            status = "TIMEOUT"
        elif code != 0:
            status = "FAIL"
        elif "[SKIP]" in text:
            status = "SKIP"
        elif dt > TIME_LIMIT or mem > MEM_LIMIT_MB:
            status = "WARN"
        else:
            status = "PASS"
        results.append((rel, status, dt, mem))
        print(f"  [{status:7s}] {rel:58s} {dt:7.1f}s  峰值内存 {mem:7.0f}MB")
        if status in ("FAIL", "TIMEOUT"):
            print("    " + "\n    ".join(text.strip().splitlines()[-15:]))
        if a.save_outputs:
            od = os.path.join(os.path.dirname(path), "outputs")
            os.makedirs(od, exist_ok=True)
            with open(os.path.join(od, os.path.basename(path)[:-3] + ".txt"), "w", encoding="utf-8") as f:
                f.write(f"# 实测输出：{rel}\n# 运行时间：{datetime.datetime.now():%Y-%m-%d %H:%M}，"
                        f"耗时 {dt:.1f}s，峰值内存 {mem:.0f}MB，状态 {status}\n"
                        f"# 环境：Python {platform.python_version()}，{platform.machine()}，"
                        f"{os.cpu_count()} 逻辑核（不同机器上的计时数字会不同，趋势应一致）\n\n")
                f.write(text)
    n = {s: sum(1 for r in results if r[1] == s) for s in ("PASS", "SKIP", "WARN", "FAIL", "TIMEOUT")}
    print(f"\n汇总：PASS {n['PASS']}  SKIP {n['SKIP']}  WARN {n['WARN']}  FAIL {n['FAIL']}  TIMEOUT {n['TIMEOUT']}"
          f"  | 总耗时 {sum(r[2] for r in results):.0f}s  | 最大单实验内存 {max(r[3] for r in results):.0f}MB")
    sys.exit(1 if n["FAIL"] or n["TIMEOUT"] else 0)


if __name__ == "__main__":
    main()
