"""[M08-L02] 专家并行（Expert Parallelism, EP）：All-to-All 成本、热点专家与专家 GEMM 的算术强度

目标：估算 EP 下 dispatch/combine 两次 All-to-All 的数据量和时间；用蒙特卡洛模拟路由偏斜导致的
      "最忙 rank"拖慢整步；计算推理 decode 时每个专家分到的 token 数与专家 GEMM 的算术强度，
      理解 MegaScale-Infer 等"注意力与 FFN 分离部署"工作的动机。
先预测：
  1. decode batch=256、256 个专家、top-8，每个专家平均分到几个 token？专家 GEMM 是访存还是算力受限？
  2. EP 从节点内 8 卡扩到跨节点 64 卡，All-to-All 时间怎么变？
可调参数：--experts、--topk、--hidden、--ffn、--tokens、--ep（列表）、--zipf（路由偏斜）
暴露的问题：All-to-All 瓶颈、热点专家、decode 时 FFN 访存受限 → PROBLEM_BANK P21、P22
对应论文：DeepSeek-V3（EP 与 DeepEP）；MegaScale-Infer（2504.02263）；Tutel；MegaBlocks
真实框架对照：deepseek-ai/DeepEP（normal / low-latency 两类 kernel）；
              Megatron-LM megatron/core/transformer/moe/token_dispatcher.py
"""
import argparse

import numpy as np


def a2a_time(bytes_per_rank, ep, gpn, bw_in, bw_out, alpha):
    """All-to-All：每 rank 把 (ep-1)/ep 的数据发出去；跨节点部分走慢链路。"""
    if ep <= gpn:
        return alpha * (ep - 1) + bytes_per_rank * (ep - 1) / ep / bw_in
    remote = (ep - gpn) / ep
    local = (gpn - 1) / ep
    return alpha * (ep - 1) + bytes_per_rank * max(remote / bw_out, local / bw_in)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experts", type=int, default=256)
    ap.add_argument("--topk", type=int, default=8)
    ap.add_argument("--hidden", type=int, default=7168)
    ap.add_argument("--ffn", type=int, default=2048, help="每个专家的中间维度（DeepSeek-V3: 2048）")
    ap.add_argument("--tokens", type=int, default=4096, help="每个 rank 每步的 token 数（训练）")
    ap.add_argument("--ep", type=int, nargs="+", default=[8, 16, 32, 64])
    ap.add_argument("--zipf", type=float, default=1.1)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    gpn, bw_in, bw_out, alpha = 8, 160e9, 50e9, 10e-6     # 假设：NVLink 有效 160GB/s，IB 每卡 50GB/s

    print("== 训练：每层 dispatch + combine 的 All-to-All（BF16）==")
    per_rank = a.tokens * a.topk * a.hidden * 2              # 每 rank 发出的 token 副本字节
    for ep in a.ep:
        t = 2 * a2a_time(per_rank, ep, gpn, bw_in, bw_out, alpha)
        print(f"  EP={ep:3d}: 每 rank 发出 {per_rank / 2 ** 20:7.1f} MB × 2 次，理论 {t * 1e3:6.2f} ms/层")

    print(f"\n== 热点专家：zipf={a.zipf} 偏斜路由下，最忙 rank 的接收量 / 平均 ==")
    for ep in a.ep:
        p = 1 / np.arange(1, a.experts + 1) ** a.zipf
        p = rng.permutation(p / p.sum())                     # 热门专家随机分布在各 rank
        counts = rng.multinomial(a.tokens * ep * a.topk, p)
        per_rank_load = counts.reshape(ep, -1).sum(1)
        uni = rng.multinomial(a.tokens * ep * a.topk, np.full(a.experts, 1 / a.experts)).reshape(ep, -1).sum(1)
        print(f"  EP={ep:3d}: 偏斜 {per_rank_load.max() / per_rank_load.mean():4.2f}×   "
              f"均匀路由 {uni.max() / uni.mean():4.2f}×   → 整步时间由最忙 rank 决定")

    print("\n== 推理 decode：每个专家分到的 token 与 GEMM 算术强度 ==")
    print(f"  {'batch':>6s} {'每专家token':>11s} {'AI(FLOP/B)':>10s}  H100 屋脊点≈295")
    for b in [32, 256, 1024, 8192]:
        n = b * a.topk / a.experts
        flops = 2 * n * a.hidden * a.ffn * 3                 # SwiGLU 三个矩阵
        bytes_ = 3 * a.hidden * a.ffn * 2 + 2 * n * (a.hidden * 2 + a.ffn * 3) * 2
        ai = flops / bytes_
        print(f"  {b:6d} {n:11.1f} {ai:10.1f}  {'访存受限' if ai < 295 else '算力受限'}")
    print("\n[小结] MoE 把稠密 FFN 换成稀疏专家后，训练时通信从 AllReduce 变为两次 All-to-All，跨节点时成瓶颈；"
          "\n       路由偏斜让最忙 rank 拖慢全体。推理 decode 时每个专家只分到少量 token，专家 GEMM 严重访存受限，"
          "\n       所以 MegaScale-Infer 把注意力与专家分开部署，用大规模聚合 token 提高专家的批大小。"
          "\n[问题库] P21 负载不均与 All-to-All；P22 MoE 推理 FFN 访存受限")


if __name__ == "__main__":
    main()
