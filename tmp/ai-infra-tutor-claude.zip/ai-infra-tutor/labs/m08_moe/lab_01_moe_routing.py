"""[M08-L01] MoE 路由与负载均衡：容量因子、丢 token、辅助损失与无辅助损失偏置

目标：观察 top-k 路由在偏斜输入下的负载不均；理解容量因子（capacity factor）如何导致丢 token；
      训练一个小路由器，比较"无均衡""Switch 辅助损失""DeepSeek-V3 无辅助损失偏置调整"三种策略。
先预测：
  1. 64 个专家、top-2、容量因子 1.0，若最热专家收到 3 倍平均负载，丢弃的 token 比例大约多少？
  2. 辅助损失权重越大越好吗？
可调参数：--experts、--topk、--tokens、--cf（容量因子列表）、--steps
暴露的问题：负载不均 → 专家并行中的慢 rank 与丢 token → PROBLEM_BANK P21
对应论文：GShard（容量与丢弃）；Switch Transformers（辅助损失 α·E·Σ f_i·P_i）；
          DeepSeek-V3（2412.19437，auxiliary-loss-free 的偏置项 b_i）
真实框架对照：Megatron-LM megatron/core/transformer/moe/router.py、moe_utils.py
"""
import argparse

import torch


def route(logits, k, bias=None):
    scores = torch.softmax(logits, dim=-1)
    sel = scores + (bias if bias is not None else 0)       # 偏置只影响"选谁"，不影响门控权重
    idx = sel.topk(k, dim=-1).indices
    return scores, idx


def load_stats(idx, E, cf, k):
    T = idx.shape[0]
    load = torch.bincount(idx.reshape(-1), minlength=E).float()
    cap = int(cf * T * k / E)
    dropped = (load - cap).clamp(min=0).sum().item() / (T * k)
    return load, load.max().item() / load.mean().item(), dropped


def train_router(strategy, E, k, T, d, steps, seed=0):
    """路由打分 = x@W（随主任务学习）+ c（专家固有偏好，初始偏向前 1/8 的专家）。
    主任务只约束 x@W；c 只能被均衡机制修正——模拟"数据/初始化带来的系统性偏好"。
    亲和度采用 DeepSeek-V3 的 sigmoid 形式，偏置 b 只参与 top-k 选择。"""
    g = torch.Generator().manual_seed(seed)
    W = (torch.randn(d, E, generator=g) * 0.1).requires_grad_(True)
    c = torch.zeros(E); c[: E // 8] = 2.0
    c.requires_grad_(True)
    target = torch.randn(d, E, generator=g) * 0.1
    opt = torch.optim.Adam([W, c], lr=1e-2)
    bias = torch.zeros(E)
    for _ in range(steps):
        x = torch.randn(T, d, generator=g)
        aff = torch.sigmoid(x @ W + c)                    # 亲和度
        sel = aff + (bias if strategy == "bias" else 0)
        idx = sel.topk(k, dim=-1).indices
        task = ((x @ W - x @ target) ** 2).mean()          # 主任务损失（不涉及 c）
        loss = task
        if strategy == "aux":
            f = torch.bincount(idx.reshape(-1), minlength=E).float() * E / (T * k)   # 归一化分配比例
            P = (aff / aff.sum(-1, keepdim=True)).mean(0)                           # 平均路由概率
            loss = loss + 0.01 * (f * P).sum()
        opt.zero_grad(); loss.backward(); opt.step()
        if strategy == "bias":                            # DeepSeek-V3：过载减偏置、欠载加偏置，步长 γ
            load = torch.bincount(idx.reshape(-1), minlength=E).float()
            bias -= 1e-3 * torch.sign(load - load.mean())
    x = torch.randn(T, d, generator=g)
    aff = torch.sigmoid(x @ W + c).detach()
    idx = (aff + (bias if strategy == "bias" else 0)).topk(k, dim=-1).indices
    return idx, task.item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experts", type=int, default=64)
    ap.add_argument("--topk", type=int, default=2)
    ap.add_argument("--tokens", type=int, default=4096)
    ap.add_argument("--cf", type=float, nargs="+", default=[1.0, 1.25, 2.0])
    ap.add_argument("--steps", type=int, default=300)
    a = ap.parse_args()
    E, k, T = a.experts, a.topk, a.tokens
    torch.manual_seed(0)
    print(f"== 偏斜路由下的负载（E={E}, top-{k}, {T} tokens）==")
    for skew in [0.0, 1.0, 2.0]:
        logits = torch.randn(T, E) + skew * torch.linspace(1, 0, E)    # skew 越大越偏向前面的专家
        _, idx = route(logits, k)
        for cf in a.cf:
            load, imb, drop = load_stats(idx, E, cf, k)
            print(f"  偏斜={skew:.1f} 容量因子={cf:4.2f}: 最大/平均负载={imb:5.2f}  丢弃 token 比例={drop:6.2%}")

    print(f"\n== 训练路由器 {a.steps} 步后的均衡程度 ==")
    for name, st in [("无均衡", "none"), ("Switch 辅助损失", "aux"), ("无辅助损失偏置(DeepSeek-V3)", "bias")]:
        idx, task = train_router(st, E, k, 1024, 32, a.steps)
        _, imb, drop = load_stats(idx, E, 1.25, k)
        print(f"  {name:28s} 最大/平均={imb:5.2f}  丢弃(cf=1.25)={drop:6.2%}  主任务损失={task:.2e}")
    print("\n[小结] 容量因子越大丢得越少，但显存和计算按容量预留，会浪费；辅助损失能均衡负载，但它的梯度会"
          "\n       干扰主任务；DeepSeek-V3 的偏置法只改'选谁'不改梯度。负载不均直接变成专家并行中的慢 rank。"
          "\n[问题库] P21 MoE 负载不均与 All-to-All 瓶颈")


if __name__ == "__main__":
    main()
