# M08 MoE 系统：专家并行、负载均衡、All-to-All 瓶颈

- **对应任务**：D4-T08（讲义 + L01、L02）
- **先修**：M05、M07
- **预计学时**：0.8 小时（7 天计划中与实验合并为 45 分钟，建议之后补读 `gshard`、`dsv3`）
- **学习目标**：
  1. 解释 MoE（Mixture of Experts）的路由、top-k、容量因子和 token 丢弃。
  2. 比较三种负载均衡方法：容量限制、辅助损失、DeepSeek-V3 的无辅助损失偏置。
  3. 估算专家并行（EP）下 dispatch/combine 两次 All-to-All 的数据量，并解释热点专家为什么会拖慢整步。
  4. 计算 decode 时每个专家分到的 token 数和专家 GEMM 的算术强度，理解 MegaScale-Infer 一类“注意力与 FFN 分离部署”的动机。

## 1. 核心讲义

### 1.1 MoE 的基本结构

把 Transformer 中的 FFN 换成 E 个“专家”（每个专家是一个小 FFN），再加一个**路由器**（router/gate）：对每个 token 计算 E 个专家的打分，选出得分最高的 k 个（top-k），把 token 送给它们计算，再按门控权重加权求和。参数量随 E 增长，但每个 token 只激活 k 个专家，计算量基本不变——这就是“稀疏激活”。DeepSeek-V3 每层有 256 个路由专家和 1 个共享专家，每个 token 激活 8 个路由专家（见其公开的 config）。

### 1.2 负载均衡

路由器很容易偏向少数专家：被选得多的专家学得更好、更容易被选中，形成正反馈。后果有两个：

- **丢 token**：为了让每个专家的输入有固定形状，通常设定**容量** `C = cf × T × k / E`（cf 为容量因子，T 为 token 数），超过容量的 token 被丢弃（直接走残差）。
- **慢 rank**：专家并行时，热门专家所在的 GPU 要处理更多 token，整步时间由最忙的 rank 决定。

均衡方法：

1. **辅助损失**（Switch Transformer）：`α · E · Σᵢ fᵢ · Pᵢ`，fᵢ 是专家 i 实际分到的 token 比例，Pᵢ 是平均路由概率。它鼓励均匀分配，但这个损失的梯度会干扰主任务。
2. **无辅助损失偏置**（DeepSeek-V3）：给每个专家维护一个偏置 bᵢ，**只在选 top-k 时**加到打分上；过载的专家减小偏置，欠载的增大。偏置不参与门控权重和梯度，因此不干扰主任务。
3. **更大的容量因子**：少丢 token，但按容量预留的显存和计算会浪费。

### 1.3 专家并行与 All-to-All

EP 把 E 个专家分布到多个 rank 上。每层 MoE 需要两次 All-to-All：**dispatch**（把 token 发给专家所在的 rank）和 **combine**（把结果送回）。每个 rank 发出的数据量约为 `token 数 × k × h × 字节数`，与 EP 的大小基本无关；但 EP 跨节点后，大部分流量要走慢速网络。DeepEP 提供了两类 kernel：面向训练和 prefill 的高吞吐版本，以及面向 decode 的低延迟版本。

### 1.4 推理中的 MoE：专家 GEMM 受访存限制

decode 时 batch=256、256 个专家、top-8：每个专家平均只分到 `256 × 8 / 256 = 8` 个 token。专家 GEMM 的算术强度约等于它分到的 token 数（M01 的 GEMV 规律），只有约 8 FLOP/B，远低于 H100 的屋脊点 295。所以 MoE 推理的瓶颈在于**读专家权重**。MegaScale-Infer 等工作把注意力和专家分开部署：注意力端多副本并行，把大量 token 汇集到专家端，让每个专家的批更大（结合 ping-pong 流水线隐藏通信）。

## 2. 实验

### M08-L01 MoE 路由与负载均衡（`lab_01_moe_routing.py`）

- **先预测**：(1) 64 个专家、top-2、容量因子 1.0，若最热专家收到 3 倍平均负载，大约丢多少 token？(2) 辅助损失的权重越大越好吗？
- **实测输出摘要**：
  - 偏斜路由（4096 个 token）：无偏斜时最大/平均负载为 1.16，cf=1.0 丢 3.4%、cf=1.25 不丢；偏斜度为 2.0 时最大/平均为 3.87，cf=1.0 丢 45%、cf=2.0 仍丢 18%。
  - 训练路由器 300 步（专家有固定的系统性偏好）：**不均衡**时最大/平均为 8.94，丢 84%；**Switch 辅助损失**为 1.28，丢 0.15%，但主任务损失从 2.7e-14 升到 2.4e-9（被干扰）；**DeepSeek-V3 偏置法**为 1.41，丢 0.63%，主任务损失不受影响。
- **开发说明**：第一版直接把偏置加到 softmax 分数上（量级约 1/64），步长 1e-3 累计 300 步可达 0.3，偏置完全压过了分数，负载反而更不均；第一版的“偏斜”加在 W 上，乘以零均值输入后也不会形成稳定偏好。改用 DeepSeek-V3 的 sigmoid 亲和度、并把偏斜建模为路由器上的固定偏好项后，三种方法的差异才清楚显现。**算法的超参数与打分的尺度必须匹配**——复现论文时这是常见的坑。
- **扫描建议**：`--experts 256 --topk 8`；`--steps 1000`；修改代码中辅助损失的权重 0.01 → 0.1，观察主任务损失的变化。
- **真实框架对照**：Megatron-LM `megatron/core/transformer/moe/router.py`、`moe_utils.py`。
- **暴露的问题**：[P21](../../research/PROBLEM_BANK.md#p21)。

### M08-L02 专家并行（`lab_02_expert_parallel.py`）

- **先预测**：(1) decode batch=256、256 个专家、top-8 时，每个专家平均分到几个 token？专家 GEMM 受访存还是算力限制？(2) EP 从节点内 8 卡扩到 64 卡，All-to-All 时间怎样变化？
- **实测输出摘要**（DeepSeek-V3 规模：h=7168，专家中间维 2048）：训练时每 rank 每层发出 448MB × 2 次；EP=8（节点内）约 5.3ms/层，EP=64 约 17.7ms/层（跨节点）。zipf=1.1 的偏斜路由下，最忙 rank 的接收量是平均值的 2.2 倍（EP=8）到 13.4 倍（EP=64），均匀路由时只有 1.01 倍。decode 时 batch=32、256、1024、8192 对应每专家 1、8、32、256 个 token，算术强度约 1、8、31、207，**全部受访存限制**。
- **扫描建议**：`--zipf 0.5 1.5`；`--experts 64 --topk 2`（较早的 MoE 设计）。
- **真实框架对照**：deepseek-ai/DeepEP；Megatron-LM `megatron/core/transformer/moe/token_dispatcher.py`。
- **暴露的问题**：[P21](../../research/PROBLEM_BANK.md#p21)、[P22](../../research/PROBLEM_BANK.md#p22)。

## 3. 常见误区

- “MoE 的计算量随专家数增长”：计算量取决于 k，参数量和显存随 E 增长。
- “均衡就是让每个专家拿到一样多的 token”：还要考虑专家所在 rank 的负载、跨节点流量，以及不能牺牲模型质量。
- “EP 越大越好”：跨节点的 All-to-All 很贵，而且热点放大。

## 4. 论文与延伸阅读

- 必读：`gshard`（arXiv 2006.16668）、`dsv3`（arXiv 2412.19437，重点读 DeepSeekMoE、负载均衡、DualPipe 和 FP8 部分）。
- 选读：`switch`、`dsmoe`、`tutel`、`megablocks`（用块稀疏矩阵乘避免丢 token）；前沿：`megascaleinfer`、`janus`、`step3`。
- 资源：deepseek-ai/DeepEP、deepseek-ai/DualPipe 的 README。

## 5. 自测题

Q-M08-L1-01 ~ Q-M08-L4-01；动手练习见 `exercises.md`。
