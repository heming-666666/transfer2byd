"""[M10-L02] 小型 GPT（随机权重）上实测：有/无 KV Cache 的生成、prefill 与 decode 的耗时

目标：亲手实现带 KV Cache 的自回归生成，验证与无 Cache 版本输出逐 token 一致；
      测量每个 token 的耗时随位置的变化、prefill 与 decode 的单 token 成本差异，以及批量 decode 的吞吐。
先预测：
  1. 不用 KV Cache，生成第 t 个 token 的耗时与 t 是什么关系？用了之后呢？
  2. prefill 512 个 token 的总时间，和 decode 512 次（每次 1 个 token）相比，谁快？快多少倍？
可调参数：--layers、--d、--heads、--vocab、--prompt、--gen、--batch（列表）
说明：权重随机初始化，不下载任何模型；只研究系统行为，不关心生成内容。
暴露的问题：decode 逐 token 串行、小 batch 硬件利用率低 → PROBLEM_BANK P01、P05
对应论文：Orca（迭代级调度的动机）；vLLM；FlexGen
真实框架对照：karpathy/nanoGPT model.py（无 KV Cache 的 generate）；
              GeeeekExplorer/nano-vllm（带 KV Cache 的最小推理引擎）
"""
import argparse
import time

import torch
import torch.nn as nn
import torch.nn.functional as F


class Block(nn.Module):
    def __init__(self, d, h):
        super().__init__()
        self.h, self.ln1, self.ln2 = h, nn.LayerNorm(d), nn.LayerNorm(d)
        self.qkv, self.proj = nn.Linear(d, 3 * d), nn.Linear(d, d)
        self.mlp = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))

    def forward(self, x, cache=None):
        B, T, D = x.shape
        q, k, v = self.qkv(self.ln1(x)).split(D, dim=-1)
        q, k, v = (t.view(B, T, self.h, D // self.h).transpose(1, 2) for t in (q, k, v))
        if cache is not None:
            if "k" in cache:                                   # 拼接历史 K/V
                k = torch.cat([cache["k"], k], dim=2); v = torch.cat([cache["v"], v], dim=2)
            cache["k"], cache["v"] = k, v
        # 因果掩码：只有 prefill（T>1）需要；decode 时新 token 可以看到全部历史
        y = F.scaled_dot_product_attention(q, k, v, is_causal=(T > 1))
        x = x + self.proj(y.transpose(1, 2).reshape(B, T, D))
        return x + self.mlp(self.ln2(x))


class TinyGPT(nn.Module):
    def __init__(self, vocab, d, h, layers, max_len=2048):
        super().__init__()
        self.tok, self.pos = nn.Embedding(vocab, d), nn.Embedding(max_len, d)
        self.blocks = nn.ModuleList(Block(d, h) for _ in range(layers))
        self.head = nn.Linear(d, vocab, bias=False)

    def forward(self, idx, caches=None, start=0):
        x = self.tok(idx) + self.pos(torch.arange(start, start + idx.shape[1]))
        for i, b in enumerate(self.blocks):
            x = b(x, None if caches is None else caches[i])
        return self.head(x[:, -1])


@torch.no_grad()
def generate(model, prompt, n, use_cache):
    idx, times = prompt, []
    caches = [{} for _ in model.blocks] if use_cache else None
    t0 = time.perf_counter()
    logits = model(idx, caches)                                 # prefill
    prefill = time.perf_counter() - t0
    for _ in range(n):
        nxt = logits.argmax(-1, keepdim=True)
        idx = torch.cat([idx, nxt], dim=1)
        t0 = time.perf_counter()
        logits = model(nxt, caches, start=idx.shape[1] - 1) if use_cache else model(idx)
        times.append(time.perf_counter() - t0)
    return idx, prefill, times


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", type=int, default=4)
    ap.add_argument("--d", type=int, default=256)
    ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--vocab", type=int, default=2000)
    ap.add_argument("--prompt", type=int, default=256)
    ap.add_argument("--gen", type=int, default=256)
    ap.add_argument("--batch", type=int, nargs="+", default=[1, 4, 16, 64])
    a = ap.parse_args()
    torch.manual_seed(0)
    model = TinyGPT(a.vocab, a.d, a.heads, a.layers).eval()
    prompt = torch.randint(0, a.vocab, (1, a.prompt))
    generate(model, prompt[:, :16], 4, True)                    # 预热

    out_c, pre_c, t_c = generate(model, prompt, a.gen, True)
    out_n, pre_n, t_n = generate(model, prompt, a.gen, False)
    print(f"== {a.layers} 层、d={a.d}、prompt={a.prompt}、生成 {a.gen} 个 token ==")
    print(f"  有/无 KV Cache 生成结果一致：{torch.equal(out_c, out_n)}")
    q = max(1, a.gen // 4)
    for name, ts in [("有 Cache", t_c), ("无 Cache", t_n)]:
        segs = [sum(ts[i:i + q]) / len(ts[i:i + q]) * 1e3 for i in range(0, a.gen, q)]
        print(f"  {name}: 每 token 平均耗时（按生成进度四等分）" + " → ".join(f"{s:.2f}ms" for s in segs)
              + f"   总计 {sum(ts):.2f}s")
    print(f"\n  prefill {a.prompt} token：{pre_c * 1e3:.1f} ms（{pre_c / a.prompt * 1e3:.3f} ms/token）"
          f"  vs decode 平均 {sum(t_c) / len(t_c) * 1e3:.2f} ms/token → 单 token 成本相差 "
          f"{(sum(t_c) / len(t_c)) / (pre_c / a.prompt):.0f}×")

    print("\n== 批量 decode 的吞吐（每条序列已有 prompt 长度的 KV）==")
    for b in a.batch:
        p = torch.randint(0, a.vocab, (b, a.prompt))
        _, _, ts = generate(model, p, 32, True)
        step = sum(ts[4:]) / len(ts[4:])
        print(f"  batch={b:3d}: 每步 {step * 1e3:6.2f} ms，吞吐 {b / step:8.0f} tok/s")
    print("\n[小结] KV Cache 把每步计算从 O(t) 次重复前向变成只算新 token；prefill 一次处理很多 token，"
          "\n       单 token 成本远低于 decode。小 batch 时每步耗时增长远慢于 batch，吞吐随 batch 上升——"
          "\n       这正是 continuous batching 要尽量多凑请求的原因（M11）。但 batch 继续增大时，本机 CPU 很快"
          "\n       转为算力受限（CPU 屋脊点只有约 12 FLOP/B，见 M01-L01），吞吐不再增长甚至下降；GPU 的屋脊点"
          "\n       高一个数量级以上，饱和点出现在大得多的 batch。用 M01 的 roofline 解释你看到的拐点。"
          "\n[问题库] P01 decode 访存受限；P05 prefill/decode 特性差异")


if __name__ == "__main__":
    main()
