# M10 推理基础：prefill 与 decode、KV Cache 及其显存、访存瓶颈

- **对应任务**：D5-T02（讲义）、D5-T03（L01）、D5-T04（L02）
- **先修**：M01、M04
- **预计学时**：1.2 小时
- **学习目标**：
  1. 解释自回归生成的两个阶段：prefill（一次处理整段 prompt）和 decode（每步生成一个 token），以及它们的瓶颈为何不同。
  2. 给出任意模型的结构参数，算出每 token 的 KV Cache 字节数（MHA / GQA / MLA）和单卡最大并发数。
  3. 用 roofline 估算 TTFT 与 TPOT 的下界，说明 batch 增大时 KV 读取怎样逐渐取代权重读取成为主导。
  4. 手写带 KV Cache 的生成循环，并验证它与不带 Cache 的结果逐 token 一致。

## 1. 核心讲义

### 1.1 两个阶段

- **prefill**：把长度为 s 的 prompt 一次性送进模型，算出最后一个位置的 logits，并为每一层、每个位置生成 K、V。计算是 `[s, h] × [h, h']` 的大矩阵乘，算术强度高，**受算力限制**；TTFT 主要由它决定。
- **decode**：每步只输入上一步生成的 1 个 token，但要用到所有历史 token 的 K、V。线性层是 `[b, h] × [h, h']`（b 为 batch），算术强度约为 b；注意力要读取所有历史 KV，**受访存限制**；TPOT 主要由它决定。

**KV Cache**：如果不缓存，生成第 t 个 token 时要把前 t 个 token 全部重新前向一遍，总计算量为 `O(t²)`；缓存每层每个位置的 K、V 后，每步只需计算新 token，但要占用显存。

### 1.2 KV Cache 有多大

```
每 token KV 字节 = 2 (K 和 V) × 层数 L × KV 头数 × 头维 d × 每元素字节
```

- **MHA**（多头注意力）：KV 头数 = 注意力头数。Llama-2-7B：2 × 32 × 32 × 128 × 2B = 512KB/token，4K 上下文每条序列 2GB。
- **GQA**（分组查询注意力）：多个 Q 头共享一组 KV。Llama-3-8B 有 8 个 KV 头：128KB/token，比 MHA 小 4 倍。
- **MLA**（多头潜在注意力，DeepSeek-V2/V3）：每层只缓存一个压缩的潜向量（`kv_lora_rank + qk_rope_head_dim` = 512 + 64 维），DeepSeek-V3 为 61 × 576 × 2B ≈ 68.6KB/token——对于一个 671B 参数的模型来说非常小。

单卡最大并发 ≈ （显存 × 90% − 权重）/ 每条序列的 KV。80GB 卡、4K 上下文：Llama-2-7B 约 27 条，Llama-3-8B 约 104 条，Qwen2.5-7B（4 个 KV 头）约 241 条（L01）。**KV Cache 是并发数的上限，也就是吞吐的上限。**

### 1.3 用 roofline 估算延迟

- `TTFT ≥ max( (2N·s + 4·L·s²·h) / 峰值算力 ,  权重字节 / 带宽 )`：prompt 稍长就受算力限制。
- `TPOT ≥ max( (权重字节 + b × 每条序列 KV 字节) / 带宽 ,  2N·b / 峰值算力 )`：几乎总是受访存限制。

Llama-3-8B、H100、4K 上下文时：batch=1，TPOT ≥ 4.9ms，KV 只占读取量的 3%；batch=64，TPOT ≥ 15ms，KV 占 68%。**batch 增大时瓶颈从“读权重”转为“读 KV”**——此后再增大 batch 就不再“免费”，这也是 KV 压缩、GQA/MLA 越来越重要的原因。

### 1.4 一个容易忽略的点：prefill 与 decode 会互相干扰

两个阶段放在同一个 batch 里时，一个长 prompt 的 prefill 会让同批的 decode 等待（TPOT 抖动），而只做 decode 又会让新请求的 TTFT 变长。M11 的分块 prefill 和 PD 分离就是为了解决这个矛盾。

## 2. 实验

### M10-L01 KV Cache 计算器（`lab_01_kv_cache_calc.py`）

- **先预测**：(1) Llama-3-8B 在 8K 上下文下每条序列的 KV 有多大？比 Llama-2-7B 小几倍？(2) decode 时 batch 从 1 增到 64，TPOT 增加多少？吞吐增加多少？
- **实测输出摘要**：每 token KV：Llama-2-7B 512KB，Llama-3-8B 128KB，Qwen2.5-7B 56KB，Llama-3-70B 320KB，DeepSeek-V3（MLA）68.6KB。128K 上下文时 Llama-2-7B 每条序列需要 64GB。单卡 4K 并发：27 / 104 / 241 条。Llama-3-8B 在 H100 上：TTFT 下界在 prompt=512、2048、8192 时为 8.4、35.4、168ms（受算力限制）；TPOT 下界在 batch=1、8、32、64 时为 4.9、6.1、9.9、15.0ms，吞吐上限从 203 增到 4257 tok/s。
- **说明**：模型结构参数取自公开的 config 或论文（Qwen2.5-7B 与 DeepSeek-V3 在线查看了 Hugging Face 上的 config.json，Llama-3 依据其论文 Table 3），**没有下载任何权重**。Llama-2-7B 的参数见 `SOURCES.md` 的待核实列表。
- **扫描建议**：`--ctx 1024 8192 262144`；在 `MODELS` 中加入你感兴趣的模型（只需要 config 里的几个数字）。
- **暴露的问题**：[P01](../../research/PROBLEM_BANK.md#p01)、[P02](../../research/PROBLEM_BANK.md#p02)、[P07](../../research/PROBLEM_BANK.md#p07)。

### M10-L02 小型 GPT 的 KV Cache（`lab_02_tiny_gpt_kvcache.py`）

- **先预测**：(1) 不用 KV Cache 时，生成第 t 个 token 的耗时与 t 是什么关系？用了之后呢？(2) prefill 512 个 token 与 decode 512 次相比，谁快？快多少倍？
- **实测输出摘要**（4 层、d=256、prompt=256，随机权重）：有/无 Cache 的生成结果**逐 token 一致**。有 Cache 时每 token 约 0.7~0.8ms，基本不随位置变化；无 Cache 时从 7.4ms 增到 12.7ms，总耗时 2.53s，是有 Cache 时（0.19s）的 13 倍。prefill 256 个 token 共 10.5ms（0.041ms/token），decode 平均 0.75ms/token，**单 token 成本相差 18 倍**。批量 decode：batch=1、4、16 时吞吐为 1145、3561、5302 tok/s，batch=64 时降到 3457 tok/s。
- **解读**：batch 从 1 到 16 时，每步耗时只从 0.87ms 增到 3.0ms，吞吐提高约 4.6 倍——这就是连续批处理要尽量多凑请求的原因。batch=64 时吞吐下降，是因为本机 CPU 的屋脊点只有约 11 FLOP/B（M01-L01），很快就转为受算力限制；GPU 的屋脊点高一个数量级以上，饱和点出现在大得多的 batch。**开发这个实验时，我原本在小结里写了“吞吐近似线性上升”，实测推翻了这个说法，随后按实测结果改写了解释。**
- **代码要点**：`Block.forward` 中把新的 K、V 拼接到缓存后面；prefill 时使用因果掩码，decode 时新 token 可以看到全部历史，不需要掩码；位置编码要从 `start` 开始计数。
- **扫描建议**：`--d 512 --layers 8`；`--batch 1 2 4 8 16 32`，找出本机的吞吐拐点，再用 M01 的屋脊点解释它。
- **真实框架对照**：karpathy/nanoGPT `model.py`（不带 KV Cache 的 `generate`）；GeeeekExplorer/nano-vllm（带 KV Cache 和分页的最小推理引擎）。
- **暴露的问题**：[P01](../../research/PROBLEM_BANK.md#p01)、[P05](../../research/PROBLEM_BANK.md#p05)。

## 3. 常见误区

- “推理只要算力强就快”：decode 看显存带宽和容量。
- “KV Cache 随参数量增长”：它取决于层数、KV 头数、头维和上下文长度；GQA/MLA 可以让大模型的 KV 比小模型还小。
- “prefill 和 decode 可以用同一种优化”：它们的瓶颈不同，需要不同的调度和 kernel。

## 4. 论文与延伸阅读

- 本模块的论文在 M11 精读（`orca`、`vllm`）。选读：`flexgen`（用 offload 换吞吐）、`cpinfer`（百万 token 推理的上下文并行）。
- 资源：kipply《Transformer Inference Arithmetic》及其中英双语版；Lilian Weng《Large Transformer Model Inference Optimization》；NVIDIA《Mastering LLM Techniques: Inference Optimization》；ZOMI《大模型推理整体知识》（B 站）。

## 5. 自测题

Q-M10-L1-01 ~ Q-M10-L4-01；动手练习见 `exercises.md`。
