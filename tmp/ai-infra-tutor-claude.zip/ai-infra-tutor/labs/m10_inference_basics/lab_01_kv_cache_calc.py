"""[M10-L01] KV Cache 计算器 + prefill/decode 的 roofline 延迟估算

目标：会算每 token 的 KV Cache 字节数（MHA / GQA / MLA），由此推出单卡最大并发；
      用 roofline 估算 TTFT（prefill，算力受限）与 TPOT（decode，访存受限），理解二者的不同瓶颈。
先预测：
  1. Llama-3-8B（GQA，8 个 KV 头）在 8K 上下文下每条序列的 KV 有多大？比 Llama-2-7B（MHA）小几倍？
  2. decode 时 batch 从 1 增到 64，TPOT 增加多少？吞吐增加多少？
可调参数：--ctx（上下文长度列表）、--gpu-mem、--batch
暴露的问题：KV Cache 决定并发上限；decode 访存受限 → PROBLEM_BANK P01、P02、P07
对应论文：vLLM/PagedAttention（KV 显存管理）；DeepSeek-V2/V3（MLA 压缩 KV）；
          Splitwise / DistServe（prefill 与 decode 特性不同）
说明：模型结构参数取自各模型公开的 config.json（见 SOURCES.md 的核验记录），不需要下载任何权重。
"""
import argparse

# name: (层数, 隐藏维, KV 头数, 头维, 参数量, 类型)；MLA 的"KV 维"= kv_lora_rank + qk_rope_head_dim
MODELS = {
    "Llama-2-7B (MHA)": (32, 4096, 32, 128, 6.7e9, "mha"),
    "Llama-3-8B (GQA-8)": (32, 4096, 8, 128, 8.0e9, "gqa"),
    "Qwen2.5-7B (GQA-4)": (28, 3584, 4, 128, 7.6e9, "gqa"),
    "Llama-3-70B (GQA-8)": (80, 8192, 8, 128, 70.6e9, "gqa"),
    "DeepSeek-V3 (MLA)": (61, 7168, 1, 512 + 64, 671e9, "mla"),
}
PEAK, BW = 989e12, 3.35e12        # H100 SXM BF16 稠密峰值、HBM 带宽


def kv_bytes_per_token(L, kvh, d, kind, b=2):
    if kind == "mla":
        return L * d * b               # MLA 每层只缓存一个压缩潜向量（K、V 共享）
    return 2 * L * kvh * d * b         # K 和 V


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ctx", type=int, nargs="+", default=[4096, 32768, 131072])
    ap.add_argument("--gpu-mem", type=float, default=80e9)
    ap.add_argument("--batch", type=int, nargs="+", default=[1, 8, 32, 64])
    a = ap.parse_args()
    print("== 每 token / 每序列 KV Cache（BF16）==")
    print(f"  {'模型':22s} {'KB/token':>9s} " + " ".join(f"{'ctx=' + str(c):>12s}" for c in a.ctx))
    for name, (L, h, kvh, d, N, kind) in MODELS.items():
        per = kv_bytes_per_token(L, kvh, d, kind)
        print(f"  {name:22s} {per / 1024:9.1f} " + " ".join(f"{per * c / 2 ** 30:10.2f}GB" for c in a.ctx))

    print(f"\n== 单卡 {a.gpu_mem / 1e9:.0f}GB 能容纳的 4K 上下文并发数（权重 BF16，预留 10% 给激活/碎片）==")
    for name in ["Llama-2-7B (MHA)", "Llama-3-8B (GQA-8)", "Qwen2.5-7B (GQA-4)"]:
        L, h, kvh, d, N, kind = MODELS[name]
        free = a.gpu_mem * 0.9 - 2 * N
        print(f"  {name:22s} 剩余 {free / 1e9:5.1f}GB → 最多 {int(free // (kv_bytes_per_token(L, kvh, d, kind) * 4096)):4d} 条")

    name = "Llama-3-8B (GQA-8)"
    L, h, kvh, d, N, kind = MODELS[name]
    per = kv_bytes_per_token(L, kvh, d, kind)
    print(f"\n== {name} 在 H100 上的 roofline 延迟估算 ==")
    for prompt in [512, 2048, 8192]:
        flops = 2 * N * prompt + 4 * L * prompt * prompt * h        # 线性层 + 注意力（QK^T 与 PV）
        t = max(flops / PEAK, 2 * N / BW)
        print(f"  TTFT(prompt={prompt:5d}) ≥ {t * 1e3:7.2f} ms（{'算力' if flops / PEAK > 2 * N / BW else '访存'}受限）")
    for b in a.batch:
        ctx = 4096
        bytes_ = 2 * N + b * per * ctx                             # 每步读一遍权重 + 全部 KV
        flops = 2 * N * b
        t = max(bytes_ / BW, flops / PEAK)
        print(f"  TPOT(batch={b:3d}, ctx=4K) ≥ {t * 1e3:6.2f} ms，吞吐 ≤ {b / t:7.0f} tok/s，"
              f"KV 占读取量 {b * per * ctx / bytes_:5.1%}")
    print("\n[小结] prefill 一次处理整段 prompt，是大矩阵乘，算力受限；decode 每步只算 1 个 token，却要读全部权重"
          "\n       和 KV，访存受限。batch 增大时 KV 读取逐渐取代权重读取成为主导——GQA/MLA、KV 量化、"
          "\n       PagedAttention 都在这条线上做文章。"
          "\n[问题库] P01 decode 访存受限；P02 KV Cache 并发上限；P07 长上下文")


if __name__ == "__main__":
    main()
