# 实验总表

运行方式：在教学包根目录执行 `<venv>/bin/python labs/<模块>/<实验>.py`（默认参数即可）；一键冒烟测试用 `python labs/run_all.py`。每个实验的实际输出保存在 `labs/<模块>/outputs/<实验>.txt`，不能执行代码的教学 agent 可以直接引用这些输出。

“任务”列对应 `CURRICULUM.md` 里的任务编号；“问题库”列对应 `research/PROBLEM_BANK.md`；耗时与内存为构建机实测值（16 逻辑核、8 线程，WSL2）。

| 任务 | 实验 | 知识点 | 运行命令 | 需求 | 耗时 | 峰值内存 | 对应论文 | 问题库 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| D1-T03 | M00-L01 推理服务指标 | TTFT/TPOT/goodput/MFU | `python labs/m00_overview/lab_01_serving_metrics.py` | CPU，仅标准库 | <1s | 0.2GB | distserve、sarathiserve | P05、P30 |
| D1-T04 | M00-L02 成本估算 | 6ND、decode 吞吐与显存上限 | `python labs/m00_overview/lab_02_cost_model.py` | CPU，仅标准库 | <1s | 0.2GB | megascale、megatron3d | P01、P02、P18 |
| D1-T06 | M01-L01 Roofline | 算术强度、屋脊点、本机实测 | `python labs/m01_hardware/lab_01_roofline.py` | CPU，torch+numpy | ~2s | 0.9GB | roofline、datamove | P01、P11 |
| D1-T07 | M01-L02 存储层次 | 缓存层次、跨步访问 | `python labs/m01_hardware/lab_02_memory_hierarchy.py` | CPU，numpy | <1s | 0.4GB | fa1、datamove | P01、P12 |
| D1-T10 | M02-L01 张量与存储 | stride/view/contiguous、框架开销 | `python labs/m02_pytorch_runtime/lab_01_tensor_storage.py` | CPU，torch | ~2s | 0.4GB | pytorch19 | P11 |
| D1-T10 | M02-L02 迷你 autograd | 计算图、反向传播、saved tensors | `python labs/m02_pytorch_runtime/lab_02_mini_autograd.py` | CPU，torch+numpy | ~1s | 0.2GB | pytorch19 | P14 |
| D1-T10 | M02-L03 profiler | 小算子开销、线程数 | `python labs/m02_pytorch_runtime/lab_03_profiler.py` | CPU，torch | ~3s | 0.4GB | pt2 | P11、P29 |
| D2-T03 | M03-L01 分块矩阵乘 | 访存量 2N³/T、tile 与片上容量 | `python labs/m03_kernels/lab_01_tiled_matmul.py` | CPU，numpy | <1s | 0.2GB | triton、tvm、ansor | P12、P13 |
| D2-T04 | M03-L02 算子融合 | 逐元素算子访存、融合的下界 | `python labs/m03_kernels/lab_02_operator_fusion.py` | CPU，torch | ~3s | 1.2GB | pt2、tvm | P12 |
| D2-T05 | M03-L03 FlashAttention | 在线 softmax、IO 模型 | `python labs/m03_kernels/lab_03_flash_attention.py` | CPU，torch | ~1s | 0.3GB | fa1、fa2 | P07、P13 |
| 选做 | M03-L04 Triton softmax | 块编程、融合 kernel | `python labs/m03_kernels/lab_04_triton_softmax_gpu.py` | **GPU**（无 GPU 时 SKIP） | — | — | triton | P13 |
| D2-T08 | M04-L01 显存账本 | 16Ψ、ZeRO、激活值公式 | `python labs/m04_memory_precision/lab_01_memory_ledger.py` | CPU，torch | ~2s | 0.4GB | zero、seqpar | P14、P20 |
| D2-T09 | M04-L02 混合精度 | 舍入、下溢、累加、FP8 vs INT8 | `python labs/m04_memory_precision/lab_02_mixed_precision.py` | CPU，torch | ~1s | 0.2GB | mpt、fp8fmt、dsv3 | P15 |
| D2-T10 | M04-L03 激活重计算 | 从零实现 checkpoint | `python labs/m04_memory_precision/lab_03_activation_checkpoint.py` | CPU，torch | ~2s | 0.7GB | sublinear、seqpar | P14 |
| D3-T03 | M05-L01 Ring AllReduce | ReduceScatter + AllGather | `python labs/m05_collectives/lab_01_ring_allreduce.py` | CPU，numpy | <1s | 0.2GB | patarasuk、horovod | P23 |
| D3-T04 | M05-L02 α-β 模型 | Ring/树/递归倍增/分层 | `python labs/m05_collectives/lab_02_alpha_beta.py` | CPU，仅标准库 | <1s | 0.2GB | patarasuk、nccl | P23 |
| D3-T05 | M05-L03 gloo 集合通信 | 多进程、algbw/busbw | `python labs/m05_collectives/lab_03_gloo_collectives.py` | CPU，torch（gloo，4 进程） | ~5s | 0.9GB | ddp | P23、P16 |
| D3-T07 | M06-L01 手写 DDP | AllReduce 平均、分桶 | `python labs/m06_data_parallel/lab_01_ddp_bucketing.py` | CPU，torch（gloo，4 进程） | ~4s | 0.3GB | ddp | P17 |
| D3-T08 | M06-L02 ZeRO 模拟器 | 分片优化器、显存与通信 | `python labs/m06_data_parallel/lab_02_zero_sim.py` | CPU，torch | ~1s | 0.2GB | zero、fsdp、zeropp | P16、P14 |
| D3-T09 | M06-L03 重叠模拟器 | 桶大小的 U 形曲线 | `python labs/m06_data_parallel/lab_03_overlap_sim.py` | CPU，仅标准库 | <1s | 0.2GB | ddp、horovod | P17 |
| D4-T03 | M07-L01 张量并行 | 列切/行切、通信计算比 | `python labs/m07_model_parallel/lab_01_tensor_parallel.py` | CPU，torch | ~1s | 0.3GB | megatron、seqpar | P19 |
| D4-T04 | M07-L02 流水线调度 | GPipe/1F1B/交错式气泡 | `python labs/m07_model_parallel/lab_02_pipeline_sim.py` | CPU，仅标准库 | <1s | 0.2GB | gpipe、pipedream、megatron3d、zerobubble | P18 |
| D4-T05 | M07-L03 配置搜索 | 3D 并行性能模型 | `python labs/m07_model_parallel/lab_03_parallel_config_search.py` | CPU，仅标准库 | <1s | 0.2GB | megatron3d、alpa | P19 |
| D4-T06 | M07-L04 上下文并行 | Ring Attention、zigzag、Ulysses | `python labs/m07_model_parallel/lab_04_context_parallel.py` | CPU，torch | ~1s | 0.2GB | ringattn、ulysses、usp | P20、P07 |
| D4-T08 | M08-L01 MoE 路由 | 容量因子、辅助损失、偏置法 | `python labs/m08_moe/lab_01_moe_routing.py` | CPU，torch | ~3s | 0.3GB | gshard、switch、dsv3 | P21 |
| D4-T08 | M08-L02 专家并行 | All-to-All、热点、专家 GEMM 强度 | `python labs/m08_moe/lab_02_expert_parallel.py` | CPU，numpy | <1s | 0.2GB | dsv3、megascaleinfer | P21、P22 |
| D4-T09 | M09-L01 故障与 checkpoint | ETTR、Young/Daly | `python labs/m09_training_ops/lab_01_failure_checkpoint.py` | CPU，仅标准库 | <1s | 0.2GB | megascale、gemini_ckpt、byterobust | P24 |
| D4-T09 | M09-L02 慢节点 | 极值统计、稳健 z-score 检测 | `python labs/m09_training_ops/lab_02_straggler.py` | CPU，numpy | <1s | 0.2GB | megascale、reliability | P25 |
| D5-T03 | M10-L01 KV Cache 计算器 | MHA/GQA/MLA、roofline 延迟 | `python labs/m10_inference_basics/lab_01_kv_cache_calc.py` | CPU，仅标准库 | <1s | 0.2GB | vllm、dsv3、splitwise | P01、P02、P07 |
| D5-T04 | M10-L02 小型 GPT | 有无 KV Cache、prefill vs decode | `python labs/m10_inference_basics/lab_02_tiny_gpt_kvcache.py` | CPU，torch | ~5s | 0.7GB | orca、vllm | P01、P05 |
| D5-T06 | M11-L01 分页 KV 分配器 | 块表、引用计数、写时复制 | `python labs/m11_serving/lab_01_paged_kv_allocator.py` | CPU，仅标准库 | <1s | 0.2GB | vllm、jenga | P02 |
| D5-T07 | M11-L02 调度模拟器 | 静态/连续批、分块 prefill、抢占 | `python labs/m11_serving/lab_02_continuous_batching_sim.py` | CPU，仅标准库 | <1s | 0.2GB | orca、vllm、sarathiserve | P05、P03、P30 |
| D5-T08 | M11-L03 前缀缓存 | 前缀树、LRU、thinking token 污染 | `python labs/m11_serving/lab_03_radix_prefix_cache.py` | CPU，仅标准库 | ~8s | 0.2GB | sglang、marconi | P04、P03 |
| D5-T09 | M11-L04 PD 分离 | goodput、P:D 配比、KV 传输 | `python labs/m11_serving/lab_04_pd_disaggregation.py` | CPU，仅标准库 | ~1s | 0.2GB | distserve、splitwise、mooncake | P06、P05 |
| 选做 | M11-L05 vLLM 实测 | 真实引擎的吞吐与 TTFT | `python labs/m11_serving/lab_05_vllm_benchmark_gpu.py` | **GPU**（无 GPU 时 SKIP；运行时下载 Qwen/Qwen2.5-0.5B-Instruct） | — | — | vllm | P05、P29 |
| D6-T03 | M12-L01 投机解码 | 拒绝采样、接受率、大 batch 失效 | `python labs/m12_inference_accel/lab_01_speculative_decoding.py` | CPU，numpy | ~2s | 0.2GB | specdec、specsample、eagle | P08 |
| D6-T04 | M12-L02 量化 | 离群值、LLM.int8、SmoothQuant、W4、AWQ | `python labs/m12_inference_accel/lab_02_quantization.py` | CPU，torch | ~1s | 0.3GB | llmint8、smoothquant、gptq、awq | P09 |
| D6-T05 | M12-L03 KV 压缩 | 窗口/StreamingLLM/H2O、KIVI 量化 | `python labs/m12_inference_accel/lab_03_kv_compression.py` | CPU，torch | ~1s | 0.2GB | streamingllm、h2o、kivi | P10 |
| D6-T08 | M13-L01 图 IR 与 pass | 常量折叠、CSE、DCE、融合 | `python labs/m13_compiler/lab_01_graph_ir_passes.py` | CPU，numpy | <1s | 0.2GB | tvm、pt2 | P12 |
| D6-T08 | M13-L02 torch.compile 前端 | fx、图断裂、重编译 | `python labs/m13_compiler/lab_02_torch_compile_capture.py` | CPU，torch | ~4s | 0.4GB | pt2 | P12 |
| D6-T08 | M13-L03 自动调优 | 网格/随机/代价模型搜索 | `python labs/m13_compiler/lab_03_autotune.py` | CPU，numpy | ~7s | 0.2GB | tvm、ansor | P13 |
| D7-T03 | M14-L01 rollout 长尾 | 同步/异步/部分 rollout | `python labs/m14_rl_systems/lab_01_rollout_longtail.py` | CPU，numpy | <1s | 0.2GB | hybridflow、areal | P26、P28 |
| D7-T03 | M14-L02 资源配比 | 共置 vs 分离、权重同步 | `python labs/m14_rl_systems/lab_02_resource_allocation.py` | CPU，仅标准库 | <1s | 0.2GB | hybridflow、openrlhf、streamrl | P27、P26 |
| D7-T06 | M15-L01 benchmark 方法学 | 预热、A/A 测试、交错测量、bootstrap | `python labs/m15_research_methods/lab_01_benchmark_methodology.py` | CPU，torch | ~2s | 0.2GB | — | P29 |
| D7-T06 | M15-L02 论文图表 | 吞吐-延迟曲线、CDF、分解、消融 | `python labs/m15_research_methods/lab_02_paper_figures.py` | CPU，matplotlib（可选） | ~1s | 0.2GB | distserve、sarathiserve | P29 |

共 45 个实验：43 个 CPU 实验（必做），2 个 GPU 选做实验（各有 CPU 替代）。全部 CPU 实验合计约 70 秒、单个实验内存峰值不超过 1.2GB。
