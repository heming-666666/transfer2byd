"""[M05-L01] Ring AllReduce 模拟器：逐步执行 ReduceScatter + AllGather

目标：用 N 个"虚拟 rank"（numpy 数组）逐步模拟 Ring AllReduce，验证结果正确，
      统计每个 rank 发送的数据量 2(N-1)/N·S，并与"汇聚到根再广播"的朴素算法对比。
先预测：
  1. N 从 2 增大到 64，Ring 中每个 rank 发送的字节数怎么变？朴素算法中根节点呢？
  2. Ring 一共需要几步（通信轮数）？这对小消息意味着什么？
可调参数：--ranks（2~64）、--size（每个 rank 的元素数）、--trace（打印每一步）
暴露的问题：带宽最优 ≠ 延迟最优；小消息时轮数主导 → PROBLEM_BANK P23
对应论文：Patarasuk & Yuan 2009（带宽最优 AllReduce）；Horovod（把 ring-allreduce 引入深度学习）
真实框架对照：NVIDIA/nccl src/device/all_reduce.h（runRing）；nccl-tests 的 busbw 公式
"""
import argparse

import numpy as np


def ring_allreduce(bufs, trace=False):
    n = len(bufs)
    chunks = [np.array_split(b.copy(), n) for b in bufs]   # 每个 rank 把数据切成 n 块
    sent = [0] * n
    # 阶段 1：ReduceScatter。第 s 步，rank r 把第 (r - s) 块发给 r+1，后者累加
    for s in range(n - 1):
        msgs = [(r, (r - s) % n, chunks[r][(r - s) % n].copy()) for r in range(n)]
        for r, c, data in msgs:
            dst = (r + 1) % n
            chunks[dst][c] += data
            sent[r] += data.nbytes
        if trace:
            print(f"  RS step {s}: rank r 发送块 (r-{s}) mod {n}")
    # 此时 rank r 拥有第 (r+1) 块的完整和
    # 阶段 2：AllGather。第 s 步，rank r 把第 (r + 1 - s) 块（已完整）发给 r+1，后者覆盖
    for s in range(n - 1):
        msgs = [(r, (r + 1 - s) % n, chunks[r][(r + 1 - s) % n].copy()) for r in range(n)]
        for r, c, data in msgs:
            chunks[(r + 1) % n][c] = data
            sent[r] += data.nbytes
        if trace:
            print(f"  AG step {s}: rank r 发送块 (r+1-{s}) mod {n}")
    return [np.concatenate(c) for c in chunks], sent, 2 * (n - 1)


def naive_allreduce(bufs):
    n = len(bufs)
    total = sum(bufs)                       # 所有 rank 把数据发给 rank 0
    sent = [bufs[0].nbytes] * n
    sent[0] = (n - 1) * bufs[0].nbytes       # rank 0 再把结果发给其余 n-1 个 rank
    return [total.copy() for _ in range(n)], sent, 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, nargs="+", default=[2, 4, 8, 16, 64])
    ap.add_argument("--size", type=int, default=1 << 16)
    ap.add_argument("--trace", action="store_true")
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    print(f"== 每个 rank {a.size} 个 float32（{a.size * 4 / 2 ** 20:.2f} MB）==")
    print(f"  {'N':>3s} {'正确':>4s} {'ring 每rank发送':>16s} {'理论2(N-1)/N·S':>16s} {'ring轮数':>8s} "
          f"{'朴素根节点发送':>14s}")
    for n in a.ranks:
        bufs = [rng.standard_normal(a.size).astype(np.float32) for _ in range(n)]
        ref = np.sum(bufs, axis=0)
        out, sent, steps = ring_allreduce(bufs, trace=a.trace and n <= 4)
        ok = all(np.allclose(o, ref, atol=1e-3) for o in out)
        _, nsent, _ = naive_allreduce(bufs)
        S = bufs[0].nbytes
        print(f"  {n:3d} {str(ok):>4s} {max(sent) / 2 ** 20:13.2f} MB {2 * (n - 1) / n * S / 2 ** 20:13.2f} MB "
              f"{steps:8d} {max(nsent) / 2 ** 20:11.2f} MB")
    print("\n  nccl-tests 定义：algbw = S / t；busbw = algbw × 2(N-1)/N，用来和链路带宽直接比较。")
    print("\n[小结] Ring 让每个 rank 的发送量与 N 基本无关（趋近 2S），所以带宽最优；但轮数 2(N-1)"
          "\n       随 N 线性增长，小消息时延迟项主导——这是 Tree / 分层算法存在的理由（见 lab_02）。"
          "\n[问题库] P23 集合通信算法选择与拓扑感知")


if __name__ == "__main__":
    main()
