"""[M05-L03] 用 torch.distributed（gloo 后端）在单机多进程上实测集合通信

目标：会写最小的多进程分布式程序（init_process_group / all_reduce / all_gather / reduce_scatter /
      all_to_all），验证语义，并按 nccl-tests 的方式计算 algbw / busbw。
先预测：
  1. 4 个进程各持有 [rank]*4，all_reduce(SUM) 后每个进程得到什么？reduce_scatter 呢？
  2. 消息从 4KB 增到 64MB，busbw 怎样变化？为什么小消息 busbw 很低？
可调参数：--world（2~8）、--sizes（元素数）
说明：gloo 走本机回环网络，数值只用来观察趋势，不代表 NCCL/NVLink 性能。
      进程组用文件方式初始化（临时目录），不需要占用固定端口。
暴露的问题：小消息的延迟主导；集合通信语义是并行策略的基础 → PROBLEM_BANK P23
对应论文：PyTorch Distributed（VLDB'20）
真实框架对照：torch/distributed/distributed_c10d.py；NVIDIA/nccl-tests src/common.cu（busbw 计算）
"""
import argparse
import os
import tempfile
import time

import torch
import torch.distributed as dist
import torch.multiprocessing as mp

BUS_FACTOR = {"all_reduce": lambda n: 2 * (n - 1) / n, "all_gather": lambda n: (n - 1) / n,
              "reduce_scatter": lambda n: (n - 1) / n, "all_to_all": lambda n: (n - 1) / n}


def semantics(rank, world):
    x = torch.full((world,), float(rank))
    y = x.clone(); dist.all_reduce(y)
    gathered = [torch.empty(world) for _ in range(world)]; dist.all_gather(gathered, x)
    rs = torch.empty(1); dist.reduce_scatter(rs, list(torch.arange(world, dtype=torch.float32).chunk(world)))
    a2a_in = torch.arange(world, dtype=torch.float32) + 10 * rank
    a2a_out = torch.empty(world); dist.all_to_all_single(a2a_out, a2a_in)
    return y.tolist(), [g[0].item() for g in gathered], rs.item(), a2a_out.tolist()


def bench(op, n_elem, world, reps=5):
    x = torch.ones(n_elem)
    if op == "all_reduce":
        fn = lambda: dist.all_reduce(x)
    elif op == "all_gather":       # 新版 torch 叫 all_gather_single，旧版叫 all_gather_into_tensor
        out = torch.empty(n_elem * world)
        ag = getattr(dist, "all_gather_single", None) or dist.all_gather_into_tensor
        fn = lambda: ag(out, x)
    elif op == "reduce_scatter":
        big = torch.ones(n_elem * world); out = torch.empty(n_elem)
        rs = getattr(dist, "reduce_scatter_single", None) or dist.reduce_scatter_tensor
        fn = lambda: rs(out, big)
    else:
        out = torch.empty(n_elem); fn = lambda: dist.all_to_all_single(out, x)
    fn(); dist.barrier()
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    dist.barrier()
    return (time.perf_counter() - t0) / reps


def worker(rank, world, init_file, sizes, q):
    os.environ.setdefault("GLOO_SOCKET_IFNAME", "lo")      # 只用本机回环
    dist.init_process_group("gloo", init_method=f"file://{init_file}", rank=rank, world_size=world)
    torch.set_num_threads(1)
    res = {"sem": semantics(rank, world), "bench": {}}
    for op in BUS_FACTOR:
        for n in sizes:
            try:
                res["bench"][(op, n)] = bench(op, n, world)
            except RuntimeError as e:                       # 个别算子在 gloo 上不受支持时如实记录
                res["bench"][(op, n)] = f"不支持: {str(e)[:40]}"
    q.put((rank, res))
    dist.destroy_process_group()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--world", type=int, default=4)
    ap.add_argument("--sizes", type=int, nargs="+", default=[1024, 65536, 1 << 20, 1 << 24])
    a = ap.parse_args()
    ctx = mp.get_context("spawn")
    q = ctx.Queue()
    with tempfile.TemporaryDirectory() as d:
        init_file = os.path.join(d, "pg_init")
        procs = [ctx.Process(target=worker, args=(r, a.world, init_file, a.sizes, q)) for r in range(a.world)]
        for p in procs:
            p.start()
        results = dict(q.get() for _ in procs)
        for p in procs:
            p.join()
    print(f"== 语义验证（world={a.world}，rank r 的输入为 [r]*{a.world}）==")
    for r in range(a.world):
        ar, ag, rs, a2a = results[r]["sem"]
        print(f"  rank {r}: all_reduce={ar}  all_gather 首元素={ag}  reduce_scatter={rs}  all_to_all={a2a}")
    print("\n== 性能（gloo/回环，rank0 计时）==")
    print(f"  {'算子':16s} {'大小':>9s} {'耗时':>10s} {'algbw GB/s':>11s} {'busbw GB/s':>11s}")
    for (op, n), t in results[0]["bench"].items():
        if isinstance(t, str):
            print(f"  {op:16s} {n * 4 / 1024:7.0f}KB  {t}")
            continue
        # nccl-tests 约定：all_gather 取输出总大小，reduce_scatter 取输入总大小，其余取单 rank 大小
        S = n * 4 * (a.world if op in ("all_gather", "reduce_scatter") else 1)
        algbw = S / t / 1e9
        print(f"  {op:16s} {n * 4 / 1024:7.0f}KB {t * 1e3:8.2f}ms {algbw:11.3f} {algbw * BUS_FACTOR[op](a.world):11.3f}")
    print("\n[小结] 小消息耗时几乎不随大小变化（延迟主导），大消息时 busbw 逐渐逼近链路带宽上限。"
          "\n       all_to_all 是 MoE 专家并行的核心通信（M08），all_gather/reduce_scatter 是 ZeRO-3/FSDP 的核心（M06）。"
          "\n[问题库] P23 集合通信；P16 ZeRO-3 通信")


if __name__ == "__main__":
    main()
