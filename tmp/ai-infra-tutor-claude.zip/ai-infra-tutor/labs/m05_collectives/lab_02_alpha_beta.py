"""[M05-L02] α-β 通信成本模型：Ring vs Tree vs 递归倍增 vs 分层 AllReduce

目标：用 T = α·(轮数) + β·(每 rank 传输字节) 估算不同 AllReduce 算法的耗时，
      找出小消息/大消息的最优算法与交叉点；理解节点内 NVLink 与节点间 InfiniBand 带宽差异的影响。
先预测：
  1. 256 个 GPU 做 1KB 的 AllReduce，Ring 和 Tree 谁快？1GB 呢？
  2. 节点内 8 卡 NVLink、节点间 IB 的集群上，"先节点内 ReduceScatter、再节点间 AllReduce、
     再节点内 AllGather"的分层算法能比扁平 Ring 快多少？
可调参数：--alpha-us、--bw-intra、--bw-inter（GB/s）、--gpus-per-node、--nodes
暴露的问题：算法选择依赖消息大小与拓扑 → PROBLEM_BANK P23
对应论文：Patarasuk & Yuan 2009；Demystifying NCCL（2507.04786）；Collective Communication for 100k+ GPUs
真实框架对照：NCCL 的 tuning（src/graph/tuning.cc 按 α-β 模型选择 Ring/Tree 与协议 LL/LL128/Simple）
"""
import argparse
import math


def ring(n, S, a, bw):
    return 2 * (n - 1) * a + 2 * (n - 1) / n * S / bw


def tree_naive(n, S, a, bw):
    # 不流水的二叉树：reduce 与 broadcast 各 log2(n) 层，每层整块传 S
    return 2 * math.ceil(math.log2(n)) * (a + S / bw)


def tree_pipelined(n, S, a, bw):
    # 流水线二叉树：把 S 切成 k 块，共 (2·log2 n + k - 1) 个流水步；内部节点每步要接收两个
    # 子节点各 S/k 的数据，所以每步耗时 α + 2S/(k·bw)。选最优 k。渐近带宽项 2S/bw，与 Ring 同量级。
    # NCCL 的"双二叉树"让每个节点在一棵树里是叶子、在另一棵里是内部节点，以平衡链路负载。
    d = 2 * math.ceil(math.log2(n))
    return min((d + k - 1) * (a + 2 * S / k / bw) for k in [2 ** i for i in range(0, 21)])


def recursive_doubling(n, S, a, bw):
    # 每轮交换全部数据：log2(n) 轮，每轮 S 字节（适合小消息）
    return math.ceil(math.log2(n)) * (a + S / bw)


def hierarchical(g, nodes, S, a, bw_in, bw_out):
    t = (g - 1) * a + (g - 1) / g * S / bw_in            # 节点内 ReduceScatter
    t += ring(nodes, S / g, a * 2, bw_out)               # 节点间对 1/g 的数据做 AllReduce（跨节点 α 更大）
    t += (g - 1) * a + (g - 1) / g * S / bw_in            # 节点内 AllGather
    return t


def fmt(t):
    return f"{t * 1e6:9.1f}us" if t < 1e-3 else f"{t * 1e3:9.2f}ms"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alpha-us", type=float, default=5.0)
    ap.add_argument("--bw-intra", type=float, default=300.0, help="节点内单向有效带宽 GB/s（NVLink 量级）")
    ap.add_argument("--bw-inter", type=float, default=25.0, help="节点间每 GPU 有效带宽 GB/s（200Gb IB ≈ 25GB/s）")
    ap.add_argument("--gpus-per-node", type=int, default=8)
    ap.add_argument("--nodes", type=int, default=32)
    a = ap.parse_args()
    al = a.alpha_us * 1e-6
    n = a.gpus_per_node * a.nodes
    sizes = [2 ** k for k in range(10, 31, 4)]
    bw = a.bw_inter * 1e9                                 # 扁平算法受最慢链路限制
    print(f"== 扁平算法，{n} GPU，α={a.alpha_us}us，瓶颈带宽 {a.bw_inter} GB/s ==")
    print(f"  {'消息':>8s} {'Ring':>11s} {'朴素树':>11s} {'流水线树':>11s} {'递归倍增':>11s} {'分层':>11s}  最优")
    for S in sizes:
        r = {"Ring": ring(n, S, al, bw), "朴素树": tree_naive(n, S, al, bw),
             "流水线树": tree_pipelined(n, S, al, bw),
             "递归倍增": recursive_doubling(n, S, al, bw),
             "分层": hierarchical(a.gpus_per_node, a.nodes, S, al, a.bw_intra * 1e9, bw)}
        best = min(r, key=r.get)
        label = f"{S // 2 ** 20}MB" if S >= 2 ** 20 else f"{S // 1024}KB"
        print(f"  {label:>8s} " + " ".join(f"{fmt(v):>11s}" for v in r.values()) + f"  {best}")

    print("\n== Ring 与流水线树的交叉点（随 GPU 数变化）==")
    for g in [8, 64, 512, 4096]:
        lo, hi = 1.0, 2.0 ** 36
        if ring(g, hi, al, bw) > tree_pipelined(g, hi, al, bw):
            print(f"  N={g:5d}: 在 64GB 以内流水线树始终更快")
            continue
        for _ in range(80):                                # 二分找 ring(S) = tree(S)
            mid = (lo * hi) ** 0.5
            lo, hi = (mid, hi) if ring(g, mid, al, bw) > tree_pipelined(g, mid, al, bw) else (lo, mid)
        print(f"  N={g:5d}: 消息 < {lo / 2 ** 20:9.2f} MB 时流水线树更快")
    print("\n[小结] 小消息看 α（轮数），大消息看 β（字节数）；GPU 越多，Ring 的延迟劣势越明显。"
          "\n       分层算法让慢速的节点间链路只承载 1/g 的数据。真实 NCCL 还要考虑协议、通道数、拓扑。"
          "\n[问题库] P23 集合通信算法选择与拓扑感知")


if __name__ == "__main__":
    main()
