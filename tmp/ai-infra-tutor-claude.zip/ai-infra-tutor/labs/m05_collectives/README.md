# M05 集合通信：原语、Ring 与 Tree、α-β 模型、NCCL、NVLink / InfiniBand / RDMA

- **对应任务**：D3-T02（讲义）、D3-T03~T05（L01~L03）
- **先修**：M01
- **预计学时**：1.8 小时
- **学习目标**：
  1. 说清 AllReduce、AllGather、ReduceScatter、Broadcast、Reduce、All-to-All 的输入输出语义，以及它们分别出现在哪种并行策略里。
  2. 推导 Ring AllReduce 每个 rank 的发送量为 `2(N−1)/N · S`、通信轮数为 `2(N−1)`。
  3. 用 α-β 模型 `T = α·轮数 + β·字节数` 比较 Ring、树、递归倍增、分层算法，判断小消息与大消息的最优选择。
  4. 解释 nccl-tests 中 algbw 与 busbw 的区别，会写最小的 `torch.distributed` 多进程程序。

## 1. 核心讲义

### 1.1 集合通信原语

设有 N 个 rank（进程/GPU），每个 rank 持有一个大小为 S 的张量：

| 原语 | 结果 | 典型用途 |
| --- | --- | --- |
| AllReduce | 每个 rank 都得到所有输入之和 | DDP 梯度同步；张量并行的行切分输出 |
| ReduceScatter | 求和后切成 N 份，rank i 只得到第 i 份 | ZeRO-2/3 与 FSDP 的梯度；序列并行 |
| AllGather | 把每个 rank 的一份拼起来，每个 rank 都得到全部 | ZeRO-3/FSDP 前向和反向前收集参数；序列并行 |
| Broadcast | rank 0 的数据发给所有 rank | 初始化权重；RL 中把新权重同步给推理端 |
| All-to-All | rank i 把第 j 份发给 rank j | MoE 专家并行的分发与合并；Ulysses 序列并行 |

一个重要等式：**AllReduce = ReduceScatter + AllGather**。ZeRO 正是利用它，在不增加通信量的前提下把优化器的更新拆到各个 rank 上（M06）。

### 1.2 Ring AllReduce：带宽最优

把 N 个 rank 排成一个环，每个 rank 把数据切成 N 块：

1. **ReduceScatter 阶段**（N−1 步）：第 s 步，rank r 把第 `(r−s) mod N` 块发给 r+1，接收方累加。N−1 步后，每个 rank 恰好拥有某一块的完整和。
2. **AllGather 阶段**（N−1 步）：再转 N−1 步，把完整的块传给所有人。

每步每个 rank 发送 `S/N`，共 `2(N−1)` 步，总发送量 `2(N−1)/N · S`，**几乎与 N 无关**（趋近 2S）。Patarasuk 和 Yuan 证明了这是带宽最优的。代价是轮数 `2(N−1)` 随 N 线性增长：小消息时，每轮的固定延迟 α 会主导总时间。

### 1.3 α-β 成本模型

```
T = α × (通信轮数) + β × (每个 rank 发送的字节数)，β = 1 / 带宽
```

| 算法 | 轮数 | 每 rank 字节数 | 适用 |
| --- | --- | --- | --- |
| Ring | 2(N−1) | 2(N−1)/N · S | 大消息、N 不太大 |
| 朴素二叉树（reduce + broadcast） | 2 log₂N | 每层都传整块 S | 小消息 |
| 流水线树（把 S 切成 k 片） | 2 log₂N + k − 1 | 渐近 2S | 中大消息、N 很大 |
| 递归倍增 | log₂N | 每轮 S | 很小的消息 |
| 分层（节点内 RS → 节点间 AR → 节点内 AG） | 节点内 + 节点间 | 慢链路上只传 S/g | 节点内快、节点间慢的集群 |

NCCL 内部会按消息大小、拓扑和 GPU 数，在 Ring、Tree（双二叉树）以及不同协议（LL、LL128、Simple）之间自动选择。它的调优正是基于类似的 α-β 模型。

### 1.4 硬件互连

- **节点内**：NVLink/NVSwitch（H100 每卡 NVLink 双向总带宽约 900GB/s）；没有 NVLink 的机器只能走 PCIe。
- **节点间**：InfiniBand 或 RoCE（基于以太网的 RDMA），常见每卡配一块 200~400Gb/s 的网卡（约 25~50GB/s），比节点内慢一个数量级。
- **RDMA**（远程直接内存访问）：网卡直接读写远端内存，绕过 CPU 和操作系统内核；GPUDirect RDMA 进一步让网卡直接访问 GPU 显存。
- **结论**：通信量大的并行（张量并行、专家并行的 All-to-All）尽量放在节点内；跨节点的通信尽量少、尽量与计算重叠。

### 1.5 algbw 与 busbw

nccl-tests 报告两种带宽：

- `algbw = S / t`：从用户角度看的“算法带宽”。
- `busbw = algbw × 修正因子`：AllReduce 的修正因子为 `2(N−1)/N`，AllGather/ReduceScatter 为 `(N−1)/N`。busbw 可以直接和链路的峰值带宽比较，判断硬件是否被跑满。

## 2. 实验

### M05-L01 Ring AllReduce 模拟器（`lab_01_ring_allreduce.py`）

- **先预测**：(1) N 从 2 增到 64，Ring 中每个 rank 发送的字节数怎样变？朴素算法的根节点呢？(2) Ring 一共要几轮？这对小消息意味着什么？
- **实测输出摘要**（每 rank 0.25MB）：所有 N 下结果都正确。每 rank 发送量：N=2 时 0.25MB，N=4 时 0.38MB，N=16 时 0.47MB，N=64 时 0.49MB，与理论 `2(N−1)/N·S` 完全一致；轮数从 2 增到 126。朴素算法的根节点在 N=64 时要发 15.75MB。
- **扫描建议**：`--ranks 4 --trace` 打印每一步，对照讲义 1.2 手动核对；`--size 1024` 想一想小消息时轮数的影响。
- **真实框架对照**：NVIDIA/nccl `src/device/all_reduce.h`（`runRing`）；nccl-tests 的 busbw 计算。
- **暴露的问题**：[P23](../../research/PROBLEM_BANK.md#p23)。

### M05-L02 α-β 成本模型（`lab_02_alpha_beta.py`）

- **先预测**：(1) 256 个 GPU 做 1KB 的 AllReduce，Ring 和树谁快？1GB 呢？(2) 节点内 NVLink、节点间 IB 时，分层算法能比扁平 Ring 快多少？
- **实测输出摘要**（256 GPU，α=5μs，瓶颈带宽 25GB/s，节点内 300GB/s）：1KB~16KB 时递归倍增最快（约 40μs，Ring 要 2.55ms）；256KB 时递归倍增与流水线树接近；4MB 时流水线树最快（0.73ms）；64MB 以上分层算法最快（1GB 时 17.4ms，扁平 Ring 88ms，快约 5 倍）。Ring 与流水线树的交叉点：8 卡时约 0.22MB，64 卡 16MB，512 卡 836MB，4096 卡约 41GB——GPU 越多，Ring 的延迟劣势越明显。
- **开发说明**：这个实验的第一版把流水线树的带宽项写成了 S/bw（忽略了二叉树内部节点每步要同时接收两个子节点的数据），导致树在所有消息大小下都胜出；修正为每步 `α + 2S/(k·bw)` 后，交叉点才符合直觉。**模型里一个系数的错误就会颠倒结论**——这正是系统论文需要用真实测量校准模型的原因。
- **扫描建议**：`--alpha-us 1 20`、`--bw-inter 50 100`、`--gpus-per-node 4`。
- **真实框架对照**：NCCL `src/graph/tuning.cc`（按算法、协议估算时间并选择）。
- **暴露的问题**：[P23](../../research/PROBLEM_BANK.md#p23)。

### M05-L03 用 gloo 实测集合通信（`lab_03_gloo_collectives.py`）

- **先预测**：(1) 4 个进程各持有 `[rank]*4`，all_reduce(SUM) 后每个进程得到什么？reduce_scatter 呢？(2) 消息从 4KB 增到 64MB，busbw 怎样变化？
- **实测输出摘要**：语义验证全部正确（all_reduce 得到 `[6,6,6,6]`；对输入 `[0,1,2,3]` 做 reduce_scatter，rank r 得到 4r；all_to_all 实现“转置”）。性能（gloo，本机回环）：all_reduce 4KB 耗时 0.9ms（busbw 0.007GB/s，完全被延迟主导），64MB 时 busbw 约 2.7GB/s；all_to_all 64MB 时 busbw 约 2.7GB/s。
- **说明**：gloo 走本机回环网络，数字只用来观察趋势，不代表 NCCL/NVLink 的性能（后者高出两到三个数量级）。进程组使用文件方式初始化，不占用固定端口。
- **扫描建议**：`--world 2 8`；`--sizes 256 4096 65536 1048576 16777216`，画 busbw 随消息大小的曲线，找出“延迟区”和“带宽区”的分界。
- **真实框架对照**：`torch/distributed/distributed_c10d.py`；NVIDIA/nccl-tests。
- **暴露的问题**：[P23](../../research/PROBLEM_BANK.md#p23)、[P16](../../research/PROBLEM_BANK.md#p16)。

## 3. 常见误区

- “Ring 的通信量随 N 线性增长”：每 rank 的字节数趋近 2S，与 N 无关；随 N 增长的是轮数（延迟）。
- “带宽够大就没有通信问题”：小消息由 α 主导，大规模集群里还会遇到拥塞、慢链路和拓扑不对称。
- “busbw 就是网卡速度”：busbw 是按算法折算后的值，用来和链路峰值比较。
- “All-to-All 和 AllReduce 一样容易优化”：All-to-All 每对 rank 之间都要通信，对拓扑和负载均衡非常敏感（M08）。

## 4. 论文与延伸阅读

- 必读：`patarasuk`（*Bandwidth optimal all-reduce algorithms for clusters of workstations*，JPDC 2009，DOI 10.1016/j.jpdc.2008.09.002）。
- 选读：`horovod`（把 Ring AllReduce 引入深度学习）；前沿：`nccl`（*Demystifying NCCL*）、`comm100k`（10 万卡规模的集合通信）、`tritondist`（在 Triton 中编写通信与计算重叠的 kernel）。
- 资源：stas00/ml-engineering 中的网络章节；GPU MODE 中的 NCCL 讲座。

## 5. 自测题

Q-M05-L1-01 ~ Q-M05-L4-01；动手练习见 `exercises.md`。
