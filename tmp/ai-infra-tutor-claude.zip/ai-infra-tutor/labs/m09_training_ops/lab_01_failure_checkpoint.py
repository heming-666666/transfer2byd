"""[M09-L01] 大规模训练的故障与 checkpoint：蒙特卡洛估算有效训练时间比（ETTR）

目标：给定集群规模、单卡平均无故障时间（MTBF）、checkpoint 保存开销和重启开销，
      模拟一个月的训练，得到 ETTR = 有效训练时间 / 总时间；扫描 checkpoint 间隔，
      与 Young/Daly 近似最优间隔 τ* ≈ sqrt(2·δ·M)（M=作业级 MTBF）对照；比较"远端存储"与"内存/对等 checkpoint"。
先预测：
  1. 16384 张卡、单卡 MTBF 5 万小时，整个作业平均多久故障一次？
  2. checkpoint 保存从 5 分钟降到 10 秒，最优间隔和 ETTR 怎么变？
可调参数：--gpus、--mtbf-h（单卡）、--save-s、--restart-s、--days
暴露的问题：故障频率随规模线性增长；恢复速度决定有效算力 → PROBLEM_BANK P24
对应论文：MegaScale（NSDI'24）；Llama 3 技术报告（54 天 466 次中断）；GEMINI（SOSP'23，内存 checkpoint）；
          ByteCheckpoint（NSDI'25）；Robust LLM Training Infrastructure at ByteDance（SOSP'25）
"""
import argparse
import math
import random


def simulate(total_s, job_mtbf_s, interval_s, save_s, restart_s, seed=0):
    rng = random.Random(seed)
    t = useful = 0.0
    next_fail = rng.expovariate(1 / job_mtbf_s)
    since_ckpt = 0.0
    n_fail = 0
    while t < total_s:
        # 训练一段 interval，然后保存 checkpoint（保存期间阻塞训练，简化）
        seg_end = t + (interval_s - since_ckpt) + save_s
        if next_fail < seg_end:                             # 段内发生故障：丢失自上次 checkpoint 以来的进度
            t = next_fail + restart_s
            since_ckpt = 0.0
            n_fail += 1
            next_fail = t + rng.expovariate(1 / job_mtbf_s)
            continue
        useful += interval_s - since_ckpt
        since_ckpt = 0.0
        t = seg_end
    return min(useful / total_s, 1.0), n_fail


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpus", type=int, default=16384)
    ap.add_argument("--mtbf-h", type=float, default=50000, help="单卡（含其所在节点部件）平均无故障小时数，假设值")
    ap.add_argument("--save-s", type=float, nargs="+", default=[300, 30, 5])
    ap.add_argument("--restart-s", type=float, default=600)
    ap.add_argument("--days", type=float, default=30)
    a = ap.parse_args()
    M = a.mtbf_h * 3600 / a.gpus                            # 作业级 MTBF：任何一张卡故障都会中断作业
    total = a.days * 86400
    print(f"== {a.gpus} GPU，单卡 MTBF {a.mtbf_h:.0f}h → 作业平均 {M / 3600:.2f} 小时故障一次，"
          f"{a.days:.0f} 天约 {total / M:.0f} 次 ==")
    for save in a.save_s:
        opt = math.sqrt(2 * save * M)
        print(f"\n-- 保存开销 {save:.0f}s（Young/Daly 最优间隔 ≈ {opt / 60:.1f} 分钟），重启 {a.restart_s:.0f}s --")
        best = (0, 0)
        for mins in [2, 5, 10, 20, 30, 60, 120, 240]:
            ettr = sum(simulate(total, M, mins * 60, save, a.restart_s, seed=s)[0] for s in range(5)) / 5
            best = max(best, (ettr, mins))
            print(f"  间隔 {mins:4d} 分钟：ETTR = {ettr:6.1%}")
        print(f"  模拟最优 ≈ {best[1]} 分钟（ETTR {best[0]:.1%}）")
    print("\n== 再把重启从 600s 降到 60s（热备节点 + 内存 checkpoint，ByteRobust 一类思路）==")
    ettr = sum(simulate(total, M, max(60, math.sqrt(2 * 5 * M)), 5, 60, seed=s)[0] for s in range(5)) / 5
    print(f"  保存 5s、重启 60s：ETTR = {ettr:.1%}")
    print("\n[小结] 规模越大，故障越频繁；ETTR 同时受保存开销（决定能多频繁地存）和重启开销（每次故障的固定损失）制约。"
          "\n       这就是异步/内存 checkpoint、热备替换、快速故障定位成为大规模训练基础设施核心的原因。"
          "\n[问题库] P24 大规模训练故障与 checkpoint 开销")


if __name__ == "__main__":
    main()
