"""[M09-L02] 慢节点（straggler）：同步训练中"最慢的那个决定一切"

目标：模拟同步数据并行中每个 rank 的步时间 = 基准 ×（1 + 随机抖动），整步时间取最大值；
      观察规模增大时期望最大值的增长（极值统计）；注入一个持续变慢（fail-slow）的 GPU，
      用每 rank 计时的 z-score 做检测，并评估"剔除并替换"带来的收益。
先预测：
  1. 每个 rank 有 3% 的随机抖动，1 万个 rank 时整步比单卡慢多少？
  2. 1 张卡降频到 70% 速度，整个作业慢多少？
可调参数：--ranks（列表）、--jitter、--slow-factor、--steps
暴露的问题：慢节点检测与缓解 → PROBLEM_BANK P25
对应论文：MegaScale（慢节点检测）；Understanding Stragglers in Large Model Training Using What-if Analysis（OSDI'25）；
          Revisiting Reliability in Large-Scale ML Research Clusters（2410.21680）
真实框架对照：Megatron-LM 的 --log-straggler 选项（megatron/training/ 中的 straggler detector）
"""
import argparse

import numpy as np


def step_times(n, steps, jitter, rng, slow_rank=None, slow_factor=1.0):
    t = 1.0 + np.abs(rng.normal(0, jitter, size=(steps, n)))     # 抖动只会让步变慢
    if slow_rank is not None:
        t[:, slow_rank] /= slow_factor
    return t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, nargs="+", default=[8, 64, 512, 4096, 16384])
    ap.add_argument("--jitter", type=float, default=0.03)
    ap.add_argument("--slow-factor", type=float, default=0.7)
    ap.add_argument("--steps", type=int, default=200)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    print(f"== 随机抖动 {a.jitter:.0%}：整步时间（取各 rank 最大值）随规模增长 ==")
    for n in a.ranks:
        t = step_times(n, a.steps, a.jitter, rng)
        print(f"  N={n:6d}: 平均每 rank {t.mean():.3f}，整步 {t.max(axis=1).mean():.3f} "
              f"→ 同步损失 {t.max(axis=1).mean() / t.mean() - 1:6.1%}")

    n = 4096
    slow = int(rng.integers(n))
    t = step_times(n, a.steps, a.jitter, rng, slow_rank=slow, slow_factor=a.slow_factor)
    print(f"\n== 注入 fail-slow：rank {slow} 速度降为 {a.slow_factor:.0%}（N={n}）==")
    print(f"  整步时间 {t.max(axis=1).mean():.3f}（无慢卡时约 {step_times(n, a.steps, a.jitter, rng).max(axis=1).mean():.3f}）")
    # 检测：用窗口内每个 rank 的平均步时，算稳健 z-score（中位数/MAD）
    window = t[-50:].mean(axis=0)
    med = np.median(window); mad = np.median(np.abs(window - med)) * 1.4826
    z = (window - med) / mad
    flagged = np.where(z > 6)[0]
    print(f"  稳健 z-score>6 的 rank：{flagged.tolist()}（真实慢卡 {slow}）")
    t2 = np.delete(t, flagged, axis=1)
    print(f"  剔除后整步 {t2.max(axis=1).mean():.3f}，提速 {t.max(axis=1).mean() / t2.max(axis=1).mean():.2f}×")
    print("\n  注意：真实系统中 rank 的计时会被集合通信'同步'——快的 rank 会在 AllReduce 里等慢的，"
          "\n  所以必须测'计算段'而非整步时间，或像 MegaScale 那样在通信库里打点。")
    print("\n[小结] 同步训练的步时间是最大值，规模越大越容易被尾部拖累；一张持续变慢的卡就能让上万卡一起降速。"
          "\n       检测难点在于区分'自己慢'和'在等别人'，以及区分硬件问题与数据/负载不均（OSDI'25 的发现）。"
          "\n[问题库] P25 慢节点检测与缓解")


if __name__ == "__main__":
    main()
