"""[M07-L04] 序列/上下文并行：Ring Attention 与 DeepSpeed-Ulysses

目标：用 N 个虚拟 rank 实现 Ring Attention（KV 块在环上传递 + 在线 softmax），验证与完整注意力一致；
      统计通信量；观察因果掩码下各 rank 的计算负载不均，以及 zigzag 切分如何修复；
      对比 Ulysses（All-to-All 把序列切分转换为头切分）的通信量与约束。
先预测：
  1. 因果注意力下按顺序把序列切成 N 段，最后一个 rank 的计算量是第一个的几倍？
  2. Ulysses 要求头数能被 N 整除，GQA 只有 8 个 KV 头时，N 最多能开到多少？
可调参数：--ranks、--seq、--d、--heads
暴露的问题：长序列训练的通信与负载均衡 → PROBLEM_BANK P20、P07
对应论文：Ring Attention（2310.01889）；DeepSpeed-Ulysses（2309.14509）；USP（2405.07719）；
          LoongTrain（2406.18485）；Context Parallelism for Million-Token Inference（2411.01783）
真实框架对照：zhuzilin/ring-flash-attention（zigzag_ring_flash_attn.py）；
              feifeibear/long-context-attention；Megatron-LM 的 context_parallel 选项（依赖 TransformerEngine）
"""
import argparse
import math

import torch


def full_attention(q, k, v, causal):
    s = q @ k.T / math.sqrt(q.shape[1])
    if causal:
        s = s.masked_fill(torch.ones_like(s, dtype=torch.bool).triu(1), -float("inf"))
    return torch.softmax(s, dim=-1) @ v


def ring_attention(q, k, v, n, causal, order):
    """order[r] = rank r 负责的序列块编号列表。每轮每个 rank 拿到环上传来的一份 KV，更新在线 softmax。"""
    S, d = q.shape
    blk = S // (n * len(order[0]))
    idx = [torch.cat([torch.arange(c * blk, (c + 1) * blk) for c in order[r]]) for r in range(n)]
    out = torch.empty_like(q)
    work = [0] * n                                         # 实际计算的 (q,k) 元素对数
    for r in range(n):
        qi, pos_q = q[idx[r]], idx[r]
        m = torch.full((len(pos_q), 1), -float("inf")); l = torch.zeros(len(pos_q), 1); o = torch.zeros(len(pos_q), d)
        for step in range(n):                              # 第 step 轮收到 rank (r - step) 的 KV
            src = (r - step) % n
            kj, vj, pos_k = k[idx[src]], v[idx[src]], idx[src]
            s = qi @ kj.T / math.sqrt(d)
            if causal:
                mask = pos_k[None, :] > pos_q[:, None]
                if mask.all():
                    continue                               # 整块被掩码：跳过计算（负载不均的来源）
                s = s.masked_fill(mask, -float("inf"))
                work[r] += int((~mask).sum())
            else:
                work[r] += s.numel()
            m_new = torch.maximum(m, s.max(1, keepdim=True).values)
            p = torch.exp(s - m_new); p = torch.nan_to_num(p)
            c = torch.exp(m - m_new); c = torch.nan_to_num(c)
            l = l * c + p.sum(1, keepdim=True); o = o * c + p @ vj; m = m_new
        out[idx[r]] = o / l
    return out, work


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, default=4)
    ap.add_argument("--seq", type=int, default=512)
    ap.add_argument("--d", type=int, default=64)
    ap.add_argument("--heads", type=int, default=32)
    a = ap.parse_args()
    n = a.ranks
    torch.manual_seed(0)
    q, k, v = (torch.randn(a.seq, a.d, dtype=torch.float64) for _ in range(3))
    seq_order = [[r] for r in range(n)]                         # 顺序切分
    zigzag = [[r, 2 * n - 1 - r] for r in range(n)]             # 每个 rank 拿一头一尾两块
    print(f"== Ring Attention 正确性（N={n}，seq={a.seq}）==")
    for causal in [False, True]:
        ref = full_attention(q, k, v, causal)
        for name, order in [("顺序切分", seq_order), ("zigzag", zigzag)]:
            out, work = ring_attention(q, k, v, n, causal, order)
            tot = sum(work)
            print(f"  {'因果' if causal else '双向'} {name:6s} max|差|={(out - ref).abs().max().item():.1e}  "
                  f"各rank计算量占比={[f'{w / tot:.0%}' for w in work]}  最慢/平均={max(work) / (tot / n):.2f}")

    print("\n== 通信量对比（每层前向，每 rank 收发，BF16；s=序列总长，h=隐藏维度）==")
    s, h = 131072, 8192
    for N in [4, 8, 16]:
        ring = (N - 1) * 2 * (s // N) * h * 2                   # 传 N-1 次本地 KV（K 和 V）
        ulysses = 4 * (N - 1) / N * (s // N) * h * 2             # Q,K,V 各一次 + 输出一次 All-to-All
        print(f"  N={N:2d}: Ring {ring / 2 ** 30:6.2f} GB（可与块计算重叠）  "
              f"Ulysses {ulysses / 2 ** 30:6.2f} GB（All-to-All，需 头数 % N == 0）")
    print(f"  头数={a.heads}：Ulysses 的 N 最大为 {a.heads}；若 KV 头只有 8 个（GQA），K/V 的切分上限就是 8，"
          f"\n  这正是 USP/LoongTrain 把 Ulysses（头维）和 Ring（序列维）组合成 2D 的动机。")
    print("\n[小结] Ring 的通信量与 N 无关地≈'每 rank 收到全部 KV'，靠与计算重叠来隐藏；因果掩码使顺序切分"
          "\n       严重不均，zigzag 让每个 rank 拿到等量工作。Ulysses 通信更少但受头数限制。"
          "\n[问题库] P20 长序列训练的通信与负载均衡；P07 长上下文")


if __name__ == "__main__":
    main()
