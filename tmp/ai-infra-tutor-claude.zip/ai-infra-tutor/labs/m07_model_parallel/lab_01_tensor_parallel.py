"""[M07-L01] 张量并行（Tensor Parallelism, TP）：Megatron 式列切分 + 行切分

目标：在单进程中用 t 个"虚拟 rank"实现 Megatron MLP 与注意力的张量并行，验证前向输出和
      参数梯度与不切分时一致；计算每层的通信量与通信/计算比，理解为什么 TP 通常只放在节点内。
先预测：
  1. MLP 的第一个矩阵 A 按列切、第二个矩阵 B 按行切，前向需要几次 AllReduce？为什么 GeLU 不需要通信？
  2. hidden=8192、t=8 时，每层每 token 的通信字节和计算 FLOPs 之比大约是多少？
可调参数：--tp、--hidden、--heads、--seq
暴露的问题：TP 通信量随 batch×seq×hidden 增长，跨节点时成为瓶颈 → PROBLEM_BANK P19
对应论文：Megatron-LM（1909.08053 图 3）；Reducing Activation Recomputation（序列并行 SP）
真实框架对照：Megatron-LM megatron/core/tensor_parallel/layers.py
              （ColumnParallelLinear / RowParallelLinear）、mappings.py（f/g 共轭算子）
"""
import argparse

import torch


def mlp_ref(x, A, B):
    return torch.nn.functional.gelu(x @ A) @ B


def mlp_tp(x, A, B, t):
    As = A.chunk(t, dim=1)            # 列切分：每个 rank 得到 A 的一部分列
    Bs = B.chunk(t, dim=0)            # 行切分：与 A 的列对应
    partial = [torch.nn.functional.gelu(x @ Ai) @ Bi for Ai, Bi in zip(As, Bs)]  # 各 rank 独立计算
    return sum(partial)               # 这里的求和 = 一次 AllReduce（Megatron 中的 g 算子）


def attn_ref(x, Wq, Wk, Wv, Wo, heads):
    s, h = x.shape
    d = h // heads
    q, k, v = (x @ W for W in (Wq, Wk, Wv))
    q, k, v = (t.view(s, heads, d).transpose(0, 1) for t in (q, k, v))
    o = torch.softmax(q @ k.transpose(1, 2) / d ** 0.5, dim=-1) @ v
    return o.transpose(0, 1).reshape(s, h) @ Wo


def attn_tp(x, Wq, Wk, Wv, Wo, heads, t):
    """按头切分：每个 rank 负责 heads/t 个头，Q/K/V 列切，输出投影 Wo 行切，最后 AllReduce。"""
    out = 0
    for r in range(t):
        cols = slice(r * x.shape[1] // t, (r + 1) * x.shape[1] // t)
        out = out + attn_ref_part(x, Wq[:, cols], Wk[:, cols], Wv[:, cols], Wo[cols, :], heads // t)
    return out


def attn_ref_part(x, Wq, Wk, Wv, Wo, local_heads):
    s = x.shape[0]
    d = Wq.shape[1] // local_heads
    q, k, v = (x @ W for W in (Wq, Wk, Wv))
    q, k, v = (t.view(s, local_heads, d).transpose(0, 1) for t in (q, k, v))
    o = torch.softmax(q @ k.transpose(1, 2) / d ** 0.5, dim=-1) @ v
    return o.transpose(0, 1).reshape(s, -1) @ Wo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tp", type=int, default=4)
    ap.add_argument("--hidden", type=int, default=256)
    ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--seq", type=int, default=64)
    a = ap.parse_args()
    torch.manual_seed(0)
    h = a.hidden
    x = torch.randn(a.seq, h, dtype=torch.float64)
    A = torch.randn(h, 4 * h, dtype=torch.float64, requires_grad=True)
    B = torch.randn(4 * h, h, dtype=torch.float64, requires_grad=True)

    print(f"== MLP 张量并行（t={a.tp}）==")
    y_ref = mlp_ref(x, A, B); y_ref.sum().backward()
    gA, gB = A.grad.clone(), B.grad.clone(); A.grad = B.grad = None
    y_tp = mlp_tp(x, A, B, a.tp); y_tp.sum().backward()
    print(f"  前向 max|差| = {(y_ref - y_tp).abs().max().item():.2e}")
    print(f"  dA max|差| = {(gA - A.grad).abs().max().item():.2e}，dB max|差| = {(gB - B.grad).abs().max().item():.2e}")

    print(f"\n== 注意力张量并行（按头切分，{a.heads} 头 / t={a.tp}）==")
    W = [torch.randn(h, h, dtype=torch.float64) / h ** 0.5 for _ in range(4)]
    print(f"  前向 max|差| = {(attn_ref(x, *W, a.heads) - attn_tp(x, *W, a.heads, a.tp)).abs().max().item():.2e}")

    print("\n== 每层通信 vs 计算（BF16，一个 Transformer 层，前向+反向）==")
    print(f"  {'hidden':>6s} {'t':>3s} {'每token通信字节':>14s} {'每token每卡FLOPs':>16s} {'FLOPs/字节':>10s}")
    for hid in [4096, 8192, 16384]:
        for t in [2, 8]:
            # 前向 2 次 AllReduce + 反向 2 次，每次消息 h×2 字节/token，Ring 每卡收发 2(t-1)/t 倍
            comm = 4 * 2 * (t - 1) / t * hid * 2
            flops = 3 * 2 * 12 * hid * hid / t          # 前向 2·12h²（注意力投影 4h² + MLP 8h²），反向 ×2
            print(f"  {hid:6d} {t:3d} {comm:14.0f} {flops:16.3e} {flops / comm:10.0f}")
    print("  对比：H100 BF16 989 TFLOPS，NVLink ~450GB/s 单向 → 需要 >2200 FLOP/B 才能藏住通信；"
          "\n        跨节点 IB ~25-50GB/s/卡 → 需要 >20000 FLOP/B。")
    print("\n[小结] 列切+行切让中间的非线性无需通信，每个 MLP/注意力块前向只需 1 次 AllReduce。"
          "\n       但 FLOPs/字节 ≈ h/t 量级，t 越大越不划算，跨节点几乎一定被通信拖垮，所以 TP≤8 放在节点内。"
          "\n[问题库] P19 并行配置搜索；P23 通信拓扑")


if __name__ == "__main__":
    main()
