"""[M07-L02] 流水线并行调度模拟器：GPipe / 1F1B / 交错式 1F1B（interleaved）

目标：生成各调度在每个 stage 上的执行顺序，按依赖关系做离散事件模拟，画出 ASCII 时间线，
      计算气泡率（bubble ratio）与每个 stage 的峰值在途微批数（决定激活显存），并与公式对照：
      GPipe/1F1B 气泡 = (p-1)/(m+p-1)（占总时间），交错式约为 (p-1)/(v·m + p-1)。
先预测：
  1. p=4、m=8 时，GPipe 和 1F1B 的气泡率一样吗？峰值激活一样吗？
  2. 交错式把每个 stage 拆成 v=2 个虚拟 stage，气泡减少多少？代价是什么？
可调参数：--p（stage 数）、--m（微批数，需为 p 的倍数）、--v（交错块数）、--fb（反向/前向耗时比）
暴露的问题：气泡、阶段不均衡、激活显存 → PROBLEM_BANK P18
对应论文：GPipe（1811.06965）；PipeDream（1F1B）；Megatron 3D（交错式，SC'21）；
          Zero Bubble（2401.10241，拆分 B/W 进一步消除气泡）；DeepSeek-V3（DualPipe）
真实框架对照：Megatron-LM megatron/core/pipeline_parallel/schedules.py
             （forward_backward_pipelining_with_interleaving）
"""
import argparse


def schedule(kind, p, m, v):
    """返回每个设备的操作序列 [(F|B, 微批, 块号)]。块号 c 对应虚拟 stage c*p + s。"""
    plans = []
    for s in range(p):
        if kind == "gpipe":
            ops = [("F", i, 0) for i in range(m)] + [("B", i, 0) for i in reversed(range(m))]
        elif kind == "1f1b":
            warm = min(p - s - 1, m)
            ops = [("F", i, 0) for i in range(warm)]
            f, b = warm, 0
            while b < m:
                if f < m:
                    ops.append(("F", f, 0)); f += 1
                ops.append(("B", b, 0)); b += 1
        else:  # 交错式：沿用 Megatron 的微批/块编号规则（要求 m % p == 0）
            total = m * v

            def fwd_id(k):
                return ("F", (k // (p * v)) * p + k % p, (k // p) % v)

            def bwd_id(k):
                return ("B", (k // (p * v)) * p + k % p, v - 1 - (k // p) % v)
            warm = min((p - s - 1) * 2 + (v - 1) * p, total)
            ops = [fwd_id(k) for k in range(warm)]
            f, b = warm, 0
            while b < total:
                if f < total:
                    ops.append(fwd_id(f)); f += 1
                ops.append(bwd_id(b)); b += 1
        plans.append(ops)
    return plans


def simulate(plans, p, v, fb):
    tf, tb = 1.0 / v, fb / v                 # 每个块只含 1/v 的层
    done, free, pos = {}, [0.0] * p, [0] * p
    timeline = [[] for _ in range(p)]
    last_vs = p * v - 1
    while any(pos[s] < len(plans[s]) for s in range(p)):
        progressed = False
        for s in range(p):
            if pos[s] >= len(plans[s]):
                continue
            op, mb, c = plans[s][pos[s]]
            vs = c * p + s
            if op == "F":
                dep = ("F", mb, vs - 1) if vs > 0 else None
            else:
                dep = ("B", mb, vs + 1) if vs < last_vs else ("F", mb, vs)
            if dep is not None and dep not in done:
                continue
            start = max(free[s], done.get(dep, 0.0))
            end = start + (tf if op == "F" else tb)
            done[(op, mb, vs)] = end
            free[s] = end
            timeline[s].append((start, end, op, mb, c))
            pos[s] += 1
            progressed = True
        if not progressed:
            raise RuntimeError("调度死锁：检查 m 是否为 p 的倍数")
    return timeline


def report(kind, p, m, v, fb, draw):
    tl = simulate(schedule(kind, p, m, v), p, v, fb)
    makespan = max(e for row in tl for (_, e, *_r) in row)
    busy = m * (1 + fb)                      # 每个设备的有效工作量
    bubble = 1 - busy / makespan
    peaks = []
    for row in tl:
        live = peak = 0
        for (_, _, op, _, _) in row:
            live += 1 if op == "F" else -1
            peak = max(peak, live)
        peaks.append(peak / v)               # 以"完整微批的激活"为单位
    theo = (p - 1) / (v * m + p - 1) if kind == "interleaved" else (p - 1) / (m + p - 1)
    name = f"{kind}(v={v})" if kind == "interleaved" else kind
    print(f"  {name:16s} 总时长={makespan:6.2f}  气泡率={bubble:6.1%}  理论≈{theo:6.1%}  "
          f"各stage峰值在途微批={[round(x, 1) for x in peaks]}")
    if draw:
        scale = 2 * v
        for s, row in enumerate(tl):
            line = [" "] * int(makespan * scale + 1)
            for (st, en, op, mb, c) in row:
                ch = str(mb % 10) if op == "F" else "abcdefghij"[mb % 10]
                for x in range(int(st * scale), int(en * scale)):
                    line[x] = ch
            print(f"    stage{s} |{''.join(line)}|")
        print("    （数字=前向的微批号，字母=反向的微批号，空格=气泡；交错式中同一微批在每个设备上出现 v 次，对应不同块）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--p", type=int, default=4)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--v", type=int, default=2)
    ap.add_argument("--fb", type=float, default=2.0, help="反向耗时/前向耗时")
    a = ap.parse_args()
    print(f"== p={a.p} stage，m={a.m} 微批，B/F={a.fb} ==")
    for kind in ["gpipe", "1f1b", "interleaved"]:
        report(kind, a.p, a.m, a.v if kind == "interleaved" else 1, a.fb, draw=True)
    print("\n== 扫描：微批数 m 对气泡率的影响（p=8）==")
    for m in [8, 16, 32, 64]:
        print(f"  -- m={m}")
        report("1f1b", 8, m, 1, a.fb, draw=False)
        report("interleaved", 8, m, 4, a.fb, draw=False)
    print("\n[小结] 1F1B 与 GPipe 气泡相同，但峰值激活从 m 降到 p-s；交错式把气泡再降 v 倍，代价是 v 倍的"
          "\n       点对点通信次数。增大 m 能摊薄气泡，但全局 batch 受收敛性约束——这是真实系统的矛盾。"
          "\n[问题库] P18 流水线气泡与阶段不均衡")


if __name__ == "__main__":
    main()
