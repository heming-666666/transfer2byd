"""[M07-L03] 3D 并行配置搜索：在显存约束下估算每种 (DP, TP, PP, 微批, 重计算) 的迭代时间

目标：把 M04 的显存账本、M05 的通信模型、M07-L02 的气泡公式组合成一个简易性能模型，
      枚举所有合法配置并排序；体会 Megatron 论文中的经验法则（TP 放节点内、PP 跨节点、DP 最外层）。
先预测：
  1. 70B 模型、64 张 80GB 卡、seq=4096、全局 batch=512 序列，最优配置大概是什么？
  2. 把 GPU 数翻倍而全局 batch 不变，最优配置会怎样变？
可调参数：--model、--gpus、--gbs（全局 batch，序列数）、--seq、--top
暴露的问题：配置空间巨大、性能模型不准时需要搜索/学习 → PROBLEM_BANK P19
对应论文：Megatron 3D 并行（SC'21，§3 的经验法则）；Alpa（2201.12023，自动并行）
注意：这是教学用的粗模型，系数（效率、重叠率）是假设值，用于比较趋势，不用于精确预测。
"""
import argparse
import itertools

MODELS = {"7b": (32, 4096, 32, 11008), "13b": (40, 5120, 40, 13824), "70b": (80, 8192, 64, 28672)}
PEAK, EFF = 989e12, 0.55          # H100 BF16 峰值与假设的 GEMM 效率
BW_INTRA, BW_INTER, MEM = 300e9, 25e9, 80e9
GPUS_PER_NODE = 8


def evaluate(L, h, a, f, s, gbs, n, tp, pp, mbs, rc):
    dp = n // (tp * pp)
    if dp * tp * pp != n or L % pp or a % tp or gbs % (dp * mbs) or tp > GPUS_PER_NODE:
        return None
    psi = L * (4 * h * h + 3 * h * f) + 2 * 32000 * h
    m = gbs // (dp * mbs)                                  # 每个流水线的微批数
    # 显存：ZeRO-1 模型状态 + 激活（1F1B 下 stage0 有 pp 个在途微批）
    states = (4 + 12 / dp) * psi / (tp * pp)
    per_layer = {"none": s * mbs * h * (34 + 5 * a * s / h) / tp,
                 "selective": s * mbs * h * 34 / tp,
                 "full": 2 * s * mbs * h / tp}[rc]
    act = per_layer * (L / pp) * min(pp, m)
    mem = states + act + 4e9                               # 4GB 预留给框架/碎片/临时 buffer
    if mem > MEM:
        return None
    # 时间：计算（完全重算多一次前向）× 气泡因子 + 未隐藏的 TP 通信 + DP 梯度同步（假设一半被隐藏）
    tokens = gbs * s
    flops = (8 if rc == "full" else 6) * psi * tokens + 12 * L * s * s * h * gbs * (4 / 3 if rc == "full" else 1)
    eff = EFF * (0.85 if tp * mbs * s < 4096 * 2 else 1.0)  # 切得太碎时 GEMM 效率下降（假设）
    t_comp = flops / n / (PEAK * eff)
    bubble = (pp - 1) / m
    tp_bytes = 0 if tp == 1 else 4 * 2 * (tp - 1) / tp * mbs * s * h * 2 * (L / pp) * m
    t_tp = tp_bytes / BW_INTRA * 0.7                       # 假设 30% 能与计算重叠
    t_dp = 0 if dp == 1 else 2 * (dp - 1) / dp * 2 * psi / (tp * pp) / BW_INTER * 0.5
    t = t_comp * (1 + bubble) + t_tp + t_dp
    mfu = 6 * psi * tokens / n / PEAK / t
    return dict(dp=dp, tp=tp, pp=pp, mbs=mbs, rc=rc, m=m, mem=mem / 1e9, t=t, mfu=mfu,
                parts=(t_comp, t_comp * bubble, t_tp, t_dp))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="70b", choices=MODELS)
    ap.add_argument("--gpus", type=int, default=64)
    ap.add_argument("--gbs", type=int, default=512)
    ap.add_argument("--seq", type=int, default=4096)
    ap.add_argument("--top", type=int, default=8)
    a = ap.parse_args()
    L, h, heads, f = MODELS[a.model]
    res, tried = [], 0
    for tp, pp, mbs, rc in itertools.product([1, 2, 4, 8], [1, 2, 4, 8, 16], [1, 2, 4], ["none", "selective", "full"]):
        tried += 1
        r = evaluate(L, h, heads, f, a.seq, a.gbs, a.gpus, tp, pp, mbs, rc)
        if r:
            res.append(r)
    res.sort(key=lambda r: r["t"])
    print(f"== {a.model}，{a.gpus} GPU，gbs={a.gbs}，seq={a.seq}：枚举 {tried} 种，合法 {len(res)} 种 ==")
    print(f"  {'DP':>3s} {'TP':>3s} {'PP':>3s} {'mbs':>3s} {'重算':>9s} {'m':>4s} {'显存GB':>7s} "
          f"{'迭代s':>7s} {'MFU':>6s}  分解(计算/气泡/TP通信/DP通信 s)")
    for r in res[:a.top]:
        p = r["parts"]
        print(f"  {r['dp']:3d} {r['tp']:3d} {r['pp']:3d} {r['mbs']:3d} {r['rc']:>9s} {r['m']:4d} {r['mem']:7.1f} "
              f"{r['t']:7.2f} {r['mfu']:6.1%}  {p[0]:.2f}/{p[1]:.2f}/{p[2]:.2f}/{p[3]:.2f}")
    if res:
        print(f"  最差的合法配置：迭代 {res[-1]['t']:.2f}s（是最优的 {res[-1]['t'] / res[0]['t']:.1f} 倍）")
    print("\n[小结] 好配置通常 TP 在节点内、PP 适中以保证 m 远大于 PP、能不重算就不重算。"
          "\n       模型里每个系数都会改变排序——真实系统用 profiling 校准或自动搜索（Alpa、Galvatron 等）。"
          "\n[问题库] P19 3D/4D 并行配置搜索")


if __name__ == "__main__":
    main()
