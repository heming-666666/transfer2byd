# M07 模型并行：张量并行、流水线并行、序列/上下文并行、3D 并行配置

- **对应任务**：D4-T02（讲义）、D4-T03~T06（L01~L04）、D4-T07（★`megatron`、★`megatron3d`）
- **先修**：M05、M06
- **预计学时**：3.2 小时
- **学习目标**：
  1. 写出 Megatron 式 MLP 与注意力的张量并行切法，指出前向、反向各需要几次 AllReduce。
  2. 推导 GPipe/1F1B 的气泡率 `(p−1)/(m+p−1)`，说明 1F1B 相比 GPipe 改进了什么、交错式又改进了什么。
  3. 解释序列并行、上下文并行（Ring Attention）、Ulysses 的区别和各自的约束。
  4. 给定模型规模、GPU 数和显存，能列出合法的 (DP, TP, PP) 配置并说明取舍。

## 1. 核心讲义

### 1.1 为什么需要模型并行

ZeRO-3 解决了“模型状态放不下”，但单层计算仍在一张卡上完成，而且每层都要 AllGather 全部参数。当单层很大、或者需要在几千张卡上扩展时，就需要把**计算本身**切开。常见的切法有三个维度：

| 维度 | 切什么 | 通信 | 通常放在 |
| --- | --- | --- | --- |
| 张量并行 TP | 每层的权重矩阵 | 每层若干次 AllReduce（量大、频繁） | 节点内（NVLink） |
| 流水线并行 PP | 按层切成 stage | 相邻 stage 之间点对点发送激活（量小） | 跨节点 |
| 数据并行 DP（含 ZeRO） | 数据 | 每步一次梯度同步（可重叠） | 最外层 |

再加上**序列/上下文并行**（切序列维度）和**专家并行**（切 MoE 专家，M08），就是所谓的 4D/5D 并行。

### 1.2 张量并行（Megatron-LM）

MLP：`Y = GeLU(X·A)·B`。

- 把 A **按列**切成 `[A1, ..., At]`：每个 rank 算 `GeLU(X·Ai)`。因为 GeLU 是逐元素的，**不需要通信**。
- 把 B **按行**切成对应的 `[B1; ...; Bt]`：每个 rank 算 `GeLU(X·Ai)·Bi`，得到部分和。
- 最后一次 **AllReduce** 求和得到 Y。

注意力按**头**切分：每个 rank 负责 `heads/t` 个头，Q/K/V 投影按列切，输出投影按行切，同样只需一次 AllReduce。所以每个 Transformer 层前向 2 次 AllReduce、反向 2 次。Megatron 用一对共轭算子 f/g 描述：f 前向恒等、反向 AllReduce；g 前向 AllReduce、反向恒等。

**通信计算比**：每 token 每层的 FLOPs 约为 `24h²/t`（前向），通信约为 `4·2(t−1)/t·h·2` 字节（前向加反向）。比值约为 `h/t` 量级——t 越大越不划算，跨节点几乎一定被通信拖垮，所以 **TP ≤ 8，放在节点内**。

**序列并行（Sequence Parallelism, SP）**：TP 只切了线性层，LayerNorm、dropout 等仍在每个 rank 上完整执行，激活值被复制 t 份。SP 把这些操作沿序列维切开，并把 AllReduce 拆成 ReduceScatter + AllGather（通信量不变），激活显存因此也除以 t（`seqpar`）。

### 1.3 流水线并行

把 L 层切成 p 个 stage，每个 stage 放在不同的卡上；把一个 batch 切成 m 个 micro-batch 依次流入。

- **GPipe**：先做完全部 m 个前向，再做全部反向。开始和结束各有一段空闲（气泡）。设前向时间为 F、反向为 B，气泡占比为 `(p−1)/(m+p−1)`。缺点：每个 stage 要同时保存 m 个 micro-batch 的激活。
- **1F1B**（PipeDream 提出，Megatron 采用其同步版本）：stage s 先做 `p−s−1` 个前向（warmup），之后前向、反向交替进行。**气泡与 GPipe 相同**，但每个 stage 同时在途的激活最多只有 `p−s` 个，显存大幅下降。
- **交错式 1F1B**（`megatron3d`）：每张卡持有 v 个不相邻的“虚拟 stage”（例如卡 0 持有第 0 层和第 4 层所在的块），气泡缩小约 v 倍，代价是点对点通信次数增加 v 倍。
- **零气泡**（`zerobubble`）：把反向拆成“对输入求梯度”（B，在关键路径上）和“对权重求梯度”（W，可以推迟），用 W 填补气泡。DeepSeek-V3 的 **DualPipe** 采用双向流水线，并把计算与通信重叠。

**矛盾**：增大 m 可以摊薄气泡，但 m = 全局 batch / (DP × micro-batch)，而全局 batch 受收敛性约束。规模越大，DP 越大，m 越小，气泡越难压缩——这是大规模训练里的真实矛盾。

### 1.4 序列 / 上下文并行

长序列（几十万 token）时，单条样本的激活就放不下一张卡。

- **Ring Attention / 上下文并行（CP）**：每个 rank 持有序列的一段 Q、K、V；K/V 块沿环传递，每个 rank 用在线 softmax（M03）逐块累加。每个 rank 最终收到全部 K/V，通信量约为 `(N−1)` 份本地 KV，但可以与块计算重叠。**因果掩码**会导致负载不均：按顺序切分时，最后一个 rank 的工作量最大。zigzag 切分（每个 rank 拿一头一尾两块）可以修复。
- **DeepSpeed-Ulysses**：用 All-to-All 把“按序列切分”转换成“按头切分”，各 rank 对自己的头做完整注意力，再 All-to-All 换回来。通信量更小，但 rank 数不能超过头数（GQA 下还受 KV 头数限制）。
- **USP / LoongTrain**：把 Ulysses（头维度）和 Ring（序列维度）组合成二维。

### 1.5 3D 并行配置的经验法则（`megatron3d` §3）

1. TP 放在节点内，t ≤ 每节点 GPU 数。
2. 模型放不下时用 PP 跨节点；保证 m ≫ p，使气泡可控，必要时用交错式。
3. 剩余的 GPU 用于 DP（配合 ZeRO-1 节省优化器显存）。
4. micro-batch 越大，GEMM 效率越高，但激活显存越大、m 越小——需要权衡。

自动并行（`alpa`）把这个选择形式化为“算子间（流水线）+ 算子内（张量/数据）”两层搜索问题，用整数线性规划和动态规划求解。

## 2. 实验

### M07-L01 张量并行（`lab_01_tensor_parallel.py`）

- **先预测**：(1) A 按列切、B 按行切时，前向需要几次 AllReduce？为什么 GeLU 不需要通信？(2) hidden=8192、t=8 时，每 token 的 FLOPs/通信字节比大约是多少？
- **实测输出摘要**：MLP 张量并行的前向输出与 dA、dB 梯度都与不切分时完全一致（误差 0）；按头切分的注意力误差约 9e-16。FLOPs/字节：h=4096 时，t=2 为 18432、t=8 为 2633；h=8192、t=8 为 5266。对照：要在 H100 上藏住通信，NVLink 需要 > 2200 FLOP/B，跨节点 IB 需要 > 20000 FLOP/B。
- **解读**：节点内 t=8 尚可接受；跨节点做 TP 时比值远低于要求，必然被通信拖慢。
- **真实框架对照**：NVIDIA/Megatron-LM `megatron/core/tensor_parallel/layers.py`（`ColumnParallelLinear` / `RowParallelLinear`）、`mappings.py`（f/g 算子）；huggingface/picotron 的 `tensor_parallel.py`（不到 300 行）。
- **暴露的问题**：[P19](../../research/PROBLEM_BANK.md#p19)。

### M07-L02 流水线调度模拟器（`lab_02_pipeline_sim.py`）

- **先预测**：(1) p=4、m=8 时，GPipe 和 1F1B 的气泡率一样吗？峰值激活一样吗？(2) 交错式 v=2 能减少多少气泡？代价是什么？
- **实测输出摘要**（B/F=2）：GPipe 与 1F1B 的总时长都是 33.0、气泡率 27.3%（理论值相同）；GPipe 每个 stage 峰值在途 8 个 micro-batch，1F1B 为 `[4, 3, 2, 1]`；交错式 v=2 时总时长 28.5、气泡率 15.8%。p=8 时，m 从 8 增到 64，1F1B 的气泡率从 46.7% 降到 9.9%，交错式 v=4 从 17.9% 降到 2.7%。**所有模拟值都与理论公式完全吻合。**程序还会打印 ASCII 时间线，数字是前向的 micro-batch 编号，字母是反向，空格是气泡。
- **扫描建议**：`--fb 1 3`（改变反向/前向比例）；`--p 16 --m 64 --v 2`。
- **真实框架对照**：Megatron-LM `megatron/core/pipeline_parallel/schedules.py`；PyTorch `torch.distributed.pipelining`；deepseek-ai/DualPipe。
- **暴露的问题**：[P18](../../research/PROBLEM_BANK.md#p18)。

### M07-L03 3D 并行配置搜索（`lab_03_parallel_config_search.py`）

- **先预测**：(1) 70B 模型、64 张 80GB 卡、seq=4096、全局 batch=512 时，最优配置大概是什么？(2) GPU 数翻倍而全局 batch 不变，最优配置会怎样变？
- **实测输出摘要**：枚举 180 种，满足显存约束的有 54 种。最优为 DP=2、TP=2、PP=16、mbs=1、选择性重计算，迭代 32.9s（MFU 47.3%）；前几名都使用选择性重计算（完全不重算放不下）；最差的合法配置慢 1.8 倍。输出里给出每种配置的时间分解（计算 / 气泡 / TP 通信 / DP 通信）。
- **注意**：这是教学用的粗模型，GEMM 效率、重叠率等系数都是假设值。改一个系数，排序就可能变化——请在练习中亲自验证，并思考“性能模型不准时应该怎么办”（真实系统会用 profiling 校准或自动搜索）。
- **暴露的问题**：[P19](../../research/PROBLEM_BANK.md#p19)。

### M07-L04 Ring Attention 与 Ulysses（`lab_04_context_parallel.py`）

- **先预测**：(1) 因果注意力下按顺序把序列切成 N 段，最后一个 rank 的计算量是第一个的几倍？(2) GQA 只有 8 个 KV 头时，Ulysses 的 N 最多能开到多少？
- **实测输出摘要**（N=4，seq=512）：双向和因果两种情况下，Ring Attention 与完整注意力的误差都约为 1e-15。因果 + 顺序切分时，各 rank 的计算量占比为 6%、19%、31%、44%，最慢 rank 是平均值的 1.75 倍；zigzag 切分后为 25%×4，比值 1.00。通信量（s=131072、h=8192、每层前向）：N=16 时 Ring 每 rank 3.75GB，Ulysses 0.47GB。
- **真实框架对照**：zhuzilin/ring-flash-attention（`zigzag_ring_flash_attn.py`）；feifeibear/long-context-attention（USP）；Megatron-LM 的 context parallel 选项。
- **暴露的问题**：[P20](../../research/PROBLEM_BANK.md#p20)、[P07](../../research/PROBLEM_BANK.md#p07)。

## 3. 常见误区

- “1F1B 的气泡比 GPipe 小”：气泡相同，改善的是显存。
- “TP 越大越好”：通信计算比随 t 变差，跨节点 TP 几乎总是糟糕的选择。
- “ZeRO-3 和 TP 一样都切了权重”：ZeRO-3 计算时仍要拼回完整权重，本质是数据并行；TP 是真正切开了计算。
- “PP 的 stage 按层数平均切就行”：embedding 和输出层让首尾 stage 更重；激活显存在 stage 之间也不均衡（BPipe 论文观察到阶段间显存相差超过 25GiB）。

## 4. 论文与延伸阅读

- 必读：★`megatron`、★`megatron3d`、`seqpar`、`gpipe`、`pipedream`、`alpa`、`ringattn`、`ulysses`。
- 选读：`pipedream2bw`、`zerobubble`；前沿：`usp`、`loongtrain`、`bytescale`、`optimus`。
- 资源：Hugging Face *Ultra-Scale Playbook* 的张量、上下文、流水线并行章节；huggingface/picotron（支持 `--use_cpu` 的 4D 并行教学实现）；李沐《Megatron LM 论文精读》（B 站）；罗西的 Megatron 源码解析系列（博客园）。

## 5. 自测题

Q-M07-L1-01 ~ Q-M07-L4-01；动手练习见 `exercises.md`。
