"""[M11-L02] 推理调度模拟器：静态批处理 vs 连续批处理（continuous batching）vs 分块 prefill（chunked prefill）

目标：用离散事件模拟比较三种调度在相同负载下的 TTFT、TPOT、最长卡顿（max inter-token latency）
      和吞吐；观察 KV 容量不足时的抢占（preemption，按重算处理）。
先预测：
  1. 静态批处理为什么吞吐低？（提示：短请求要陪长请求"空转"，新请求要等整批结束）
  2. 连续批处理中，一个 2000 token 的 prompt 插进来时，正在 decode 的请求会发生什么？
  3. 分块 prefill 的 token 预算设大设小，各自损害哪个指标？
可调参数：--rate（请求/秒，列表）、--n、--kv-cap（KV 容量 token 数）、--budget（chunked 的每步 token 预算）
暴露的问题：prefill 与 decode 互相干扰、TTFT/TPOT 取舍、抢占重算的浪费 → PROBLEM_BANK P05、P03、P30
对应论文：Orca（OSDI'22，迭代级调度）；vLLM；Sarathi / Sarathi-Serve（分块 prefill）
真实框架对照：vllm-project/vllm vllm/v1/core/sched/scheduler.py（V1 统一按 token 预算调度）
迭代耗时模型（假设，类比 8B 模型在单卡 H100）：t = 5ms + 0.03ms×prefill token 数 + 0.04ms×decode 序列数
"""
import argparse
import random


def it_time(prefill_tokens, n_decode):
    return 5.0 + 0.03 * prefill_tokens + 0.04 * n_decode


def workload(n, rate, seed=0):
    rng = random.Random(seed)
    t, reqs = 0.0, []
    for i in range(n):
        t += rng.expovariate(rate) * 1000                    # 毫秒
        reqs.append({"id": i, "arr": t, "P": rng.randint(64, 2048), "O": rng.randint(16, 512)})
    return reqs


def run_static(reqs, B=32, wait=50.0):
    t, i, toks = 0.0, 0, {}
    while i < len(reqs):
        t = max(t, reqs[i]["arr"])
        j = i
        while j < len(reqs) and j - i < B and reqs[j]["arr"] <= t + wait:
            j += 1
        batch = reqs[i:j]
        t = max(t, batch[-1]["arr"])
        t += it_time(sum(r["P"] for r in batch), 0)             # 整批 prefill
        for r in batch:
            toks[r["id"]] = [t]
        for step in range(1, max(r["O"] for r in batch)):      # 按最长输出解码，结束的请求占位空转
            t += it_time(0, len(batch))
            for r in batch:
                if step < r["O"]:
                    toks[r["id"]].append(t)
        i = j
    return toks, 0


def run_dynamic(reqs, kv_cap, chunked, budget=512, max_seqs=256):
    t, nxt, waiting, running, toks, preempt = 0.0, 0, [], [], {}, 0
    while nxt < len(reqs) or waiting or running:
        while nxt < len(reqs) and reqs[nxt]["arr"] <= t:
            r = dict(reqs[nxt]); r["done_p"] = 0; r["gen"] = 0
            waiting.append(r); nxt += 1
        if not waiting and not running:
            t = reqs[nxt]["arr"]; continue
        used = sum(r["P"] + r["gen"] for r in running)
        # 抢占：KV 不够容纳下一步增长时，踢掉最新加入的请求（重算：已生成的 token 并入 prompt 重新 prefill）
        while running and used + len(running) > kv_cap:
            v = running.pop(); preempt += 1
            used -= v["P"] + v["gen"]
            v["P"] += v["gen"]; v["O"] -= v["gen"]; v["gen"] = 0; v["done_p"] = 0
            waiting.insert(0, v)
        decodes = [r for r in running if r["done_p"] >= r["P"]]
        if chunked:                                            # 先放全部 decode，再用剩余预算塞 prefill 块
            room, plan = budget - len(decodes), []
            for r in running + waiting:
                if room <= 0:
                    break
                if r["done_p"] < r["P"] and (r in running or used + r["P"] <= kv_cap) and len(running) < max_seqs:
                    if r in waiting:
                        waiting.remove(r); running.append(r); used += r["P"]
                    c = min(room, r["P"] - r["done_p"]); plan.append((r, c)); room -= c
            dt = it_time(sum(c for _, c in plan), len(decodes))
        else:                                                  # 有新请求且放得下就先做整段 prefill（decode 暂停）
            plan = []
            while waiting and used + waiting[0]["P"] <= kv_cap and len(running) < max_seqs:
                r = waiting.pop(0); running.append(r); used += r["P"]; plan.append((r, r["P"]))
            if plan:
                decodes = []
            dt = it_time(sum(c for _, c in plan), len(decodes))
        t += dt
        for r, c in plan:
            r["done_p"] += c
            if r["done_p"] >= r["P"]:                          # prefill 完成即产出一个 token
                toks.setdefault(r["id"], []).append(t); r["gen"] += 1
        for r in decodes:
            toks.setdefault(r["id"], []).append(t); r["gen"] += 1
        running = [r for r in running if not (r["done_p"] >= r["P"] and r["gen"] >= r["O"])]
    return toks, preempt


def pct(xs, p):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(p / 100 * len(xs)))]


def summarize(name, reqs, toks, preempt):
    ttft = [toks[r["id"]][0] - r["arr"] for r in reqs]
    tpot = [(toks[r["id"]][-1] - toks[r["id"]][0]) / max(1, len(toks[r["id"]]) - 1) for r in reqs]
    stall = [max([b - a for a, b in zip(toks[r["id"]], toks[r["id"]][1:])] or [0]) for r in reqs]
    span = max(v[-1] for v in toks.values()) - reqs[0]["arr"]
    n_tok = sum(len(v) for v in toks.values())
    print(f"  {name:10s} TTFT p50/p99={pct(ttft, 50):7.0f}/{pct(ttft, 99):7.0f}ms  "
          f"TPOT p50/p99={pct(tpot, 50):5.1f}/{pct(tpot, 99):5.1f}ms  最长卡顿p99={pct(stall, 99):6.0f}ms  "
          f"吞吐={n_tok / span * 1000:6.0f}tok/s  抢占={preempt}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rate", type=float, nargs="+", default=[2, 6, 10])
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--kv-cap", type=int, default=120_000)
    ap.add_argument("--budget", type=int, default=512)
    a = ap.parse_args()
    for rate in a.rate:
        reqs = workload(a.n, rate)
        print(f"\n== 到达率 {rate} req/s，{a.n} 个请求，KV 容量 {a.kv_cap} token ==")
        summarize("静态批", reqs, *run_static(reqs))
        summarize("连续批", reqs, *run_dynamic(reqs, a.kv_cap, chunked=False))
        summarize(f"分块({a.budget})", reqs, *run_dynamic(reqs, a.kv_cap, chunked=True, budget=a.budget))
    reqs = workload(a.n, a.rate[-1])
    print(f"\n== 分块 prefill 的预算扫描（到达率 {a.rate[-1]}）==")
    for b in [128, 512, 2048, 8192]:
        summarize(f"budget={b}", reqs, *run_dynamic(reqs, a.kv_cap, chunked=True, budget=b))
    cap = a.kv_cap // 5
    print(f"\n== KV 紧张：容量降到 {cap} token（到达率 {a.rate[-1]}），观察抢占与重算 ==")
    summarize("连续批", reqs, *run_dynamic(reqs, cap, chunked=False))
    summarize(f"分块({a.budget})", reqs, *run_dynamic(reqs, cap, chunked=True, budget=a.budget))
    print("\n[小结] 连续批处理在每次迭代接纳/释放请求，吞吐远高于静态批；但整段 prefill 插队会让正在 decode 的请求"
          "\n       卡顿（最长卡顿高）。分块 prefill 用 token 预算把 prefill 切碎、与 decode 同批，平滑 TPOT；"
          "\n       预算太小则 prefill 变慢、TTFT 上升。KV 不足时的抢占要重算，白白浪费算力。"
          "\n[问题库] P05 prefill/decode 干扰；P03 抢占重算；P30 SLO 感知调度")


if __name__ == "__main__":
    main()
