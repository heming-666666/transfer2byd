# M11 推理服务系统：连续批处理、PagedAttention、前缀缓存、分块 prefill、PD 分离、SLO 调度

- **对应任务**：D5-T05（讲义）、D5-T06~T09（L01~L04）、D5-T10（★`orca`、★`vllm`）、D5-T11（★`distserve`）；L05 为 GPU 选做
- **先修**：M10
- **预计学时**：3.6 小时
- **学习目标**：
  1. 解释迭代级调度（continuous batching）为什么比静态批处理吞吐高得多。
  2. 实现分页 KV 分配器（块表、引用计数、写时复制），说明它消除了哪类显存浪费。
  3. 实现前缀树缓存，分析多轮对话、推理模型等负载下命中率的变化。
  4. 比较“整段 prefill 插队”“分块 prefill”“PD 分离”在 TTFT、TPOT、最长卡顿和 goodput 上的取舍，并能为给定负载选择 P:D 配比。

## 1. 核心讲义

### 1.1 从请求级到迭代级调度（Orca）

**静态批处理**：凑够一批请求，一起 prefill、一起 decode，直到最长的请求结束才接纳下一批。问题有两个：短请求要陪长请求“空转”；新到的请求要等整批结束才能开始，TTFT 很长。

**迭代级调度**（Orca，OSDI'22）：调度的粒度从“一批请求”变成“一次模型迭代”。每次迭代都可以加入新请求、移除已完成的请求。由于不同请求的长度不同，Orca 还提出了**选择性批处理**：注意力按请求分别计算，线性层把所有请求的 token 拼在一起计算。今天几乎所有推理引擎都采用这种“连续批处理”。

### 1.2 PagedAttention：像操作系统一样管理 KV（vLLM）

早期系统按“最大长度”为每个请求预留一段连续的 KV 显存，造成三种浪费：**预留浪费**（请求还没生成到那么长）、**内部碎片**（最终也用不完）、**外部碎片**（连续空间不够）。vLLM（SOSP'23）借鉴虚拟内存的分页思想：

- 把 KV 显存切成固定大小的**块**（例如每块 16 个 token）；
- 每个请求维护一张**块表**（逻辑块 → 物理块），按需分配；
- **引用计数 + 写时复制**：并行采样、beam search 或共享前缀时，多个序列共享同一组物理块，只有写入共享块时才复制。

浪费被限制在每个序列的最后一个块内。代价：注意力 kernel 要按块表间接寻址（PagedAttention kernel），块越小，寻址越零散。

### 1.3 前缀缓存与 RadixAttention（SGLang）

很多请求共享相同的前缀：系统提示、few-shot 示例、多轮对话的历史。把已经算过的 KV 保留下来，新请求命中时就跳过这部分 prefill。SGLang 用**基数树**（radix tree）组织所有缓存的 token 序列，支持最长前缀匹配和按 LRU 驱逐叶子，并在调度时优先处理命中率高的请求。vLLM 的自动前缀缓存（APC）用块的哈希实现类似功能。

**真实工程问题**（见 P04、P03）：
- 推理模型的 thinking token 通常不会出现在下一轮的 prompt 中，但默认会被插入缓存，成为永远不会命中的死分支（sglang issue #22373 估算 50 个并发对话可产生 65~80GB 无用 KV）。
- agentic 负载下，前缀缓存条目被驱逐会导致大量重复 prefill；vllm issue #37003 记录到 13.9 万~56.3 万个冗余 prefill token，而抢占计数器始终为 0——**常用的监控指标看不到这种浪费**。

### 1.4 prefill 与 decode 的干扰：分块 prefill（Sarathi-Serve）

一个 2000 token 的 prompt 插进来，整段 prefill 要占用一次很长的迭代，同批的 decode 请求全部卡住（最长卡顿暴增）。**分块 prefill**：每次迭代设定一个 token 预算，先放入所有 decode（每个 1 个 token），剩下的预算用来处理 prefill 的一小块。这样每次迭代的耗时稳定，TPOT 平滑；预算太小时 prefill 被切得太碎，TTFT 上升。vLLM V1 的调度器就是按 token 预算统一处理 prefill 与 decode 的。

### 1.5 PD 分离（DistServe、Splitwise、Mooncake）

把 prefill 和 decode 放到**不同的 GPU 池**里：prefill 池只做 prefill（受算力限制，可以用大批量和适合 prefill 的并行配置），完成后把 KV 传给 decode 池；decode 池只做 decode（受访存限制，可以用大批量），不受 prefill 干扰。

- **好处**：TPOT 稳定；两类阶段可以分别扩缩容、使用不同的并行策略甚至不同的硬件。
- **代价**：KV 传输（需要高速网络，或像 Mooncake 那样以 KV 为中心设计分布式缓存池）；P:D 配比是固定的，负载变化时某一池会先饱和。
- **goodput**（DistServe）：在满足 TTFT 与 TPOT SLO 的前提下每秒完成的请求数。DistServe 的核心工作就是在给定 SLO 下搜索最大化每 GPU goodput 的配置。

工业界的编排系统（NVIDIA Dynamo、llm-d）在此基础上加入 KV 感知的路由（把请求发给已经缓存了其前缀的实例）、KV 跨层级管理和动态的 P/D 资源调整。

### 1.6 SLO 与调度

除了 FCFS（先来先服务），还有优先级调度、最短作业优先（需要预测输出长度）、公平性调度、多模型 GPU 池化（Aegaeon，SOSP'25）、实例间迁移（Llumnix，OSDI'24）。不同调度策略在吞吐、尾延迟、公平性之间各有取舍（P30）。

## 2. 实验

### M11-L01 分页 KV 分配器（`lab_01_paged_kv_allocator.py`）

- **先预测**：(1) 请求长度在 [16, 2048] 均匀分布、按 2048 预分配，平均浪费多少显存？块大小 16 时呢？(2) 并行采样 n=4、共享同一个 1000 token 的 prompt，分页加共享比各自复制省多少块？
- **实测输出摘要**：连续预分配浪费 50.1%，20 万 token 的容量只能容纳 97 条；分页、块大小 16 时内部碎片只有 0.73%，可容纳约 194 条（翻倍）；块大小 256 时碎片 11%。并行采样：prompt 占 63 块，4 路各生成 200 token 后共占 114 块，各自复制需要 300 块，**节省 62%**；共享块的引用计数为 4；全部释放后空闲块恢复为 12500/12500。
- **代码要点**：`Sequence.append` 在最后一块写满时申请新块，最后一块被共享时触发写时复制；`fork` 只增加引用计数。
- **真实框架对照**：vllm-project/vllm `vllm/v1/core/block_pool.py`、`kv_cache_manager.py`；GeeeekExplorer/nano-vllm 的 block manager。
- **暴露的问题**：[P02](../../research/PROBLEM_BANK.md#p02)。

### M11-L02 调度模拟器（`lab_02_continuous_batching_sim.py`）

- **先预测**：(1) 静态批处理为什么吞吐低？(2) 一个 2000 token 的 prompt 插进来时，正在 decode 的请求会怎样？(3) 分块 prefill 的预算设大、设小，各自损害哪个指标？
- **实测输出摘要**（300 个请求，prompt 64~2048，输出 16~512；迭代耗时模型为假设值）：

  | 到达率 | 调度 | TTFT P99 | TPOT P99 | 最长卡顿 P99 | 吞吐 |
  | --- | --- | --- | --- | --- | --- |
  | 10 req/s | 静态批 | 9991ms | 6.3ms | 6ms | 1879 tok/s |
  | 10 req/s | 连续批 | 124ms | 13.1ms | **312ms** | 2352 tok/s |
  | 10 req/s | 分块(512) | 182ms | 11.3ms | **21ms** | 2353 tok/s |

  预算扫描（10 req/s）：128 时 TTFT P99 升到 687ms，但最长卡顿只有 9ms；8192 时 TTFT 123ms，最长卡顿 111ms。KV 容量降到 2.4 万 token 时：连续批抢占 917 次、吞吐降到 1219 tok/s，TTFT P99 超过 30 秒；分块 prefill 抢占 307 次、吞吐 1948 tok/s。
- **解读**：连续批处理的 TTFT 比静态批低两个数量级；整段 prefill 插队让最长卡顿高达 312ms，分块 prefill 把它压到 21ms；KV 紧张时抢占重算会严重浪费算力。
- **开发说明**：第一版默认的 KV 容量太大，一次抢占都没有触发，所以专门加了“KV 紧张”场景。
- **扫描建议**：`--rate 4 8 12 14`；`--kv-cap 40000`；`--budget 256 1024`。
- **真实框架对照**：vllm-project/vllm `vllm/v1/core/sched/scheduler.py`。
- **暴露的问题**：[P05](../../research/PROBLEM_BANK.md#p05)、[P03](../../research/PROBLEM_BANK.md#p03)、[P30](../../research/PROBLEM_BANK.md#p30)。

### M11-L03 前缀缓存（`lab_03_radix_prefix_cache.py`）

- **先预测**：(1) 多轮对话中，缓存容量只有总 token 量的 10% 时，命中率大约多少？(2) 推理模型的多轮对话中，“只缓存 prompt”和“缓存 prompt + 输出（含 thinking）”哪个命中率高？总是如此吗？
- **实测输出摘要**：

  | 负载 | 容量 2 万 token | 容量 8 万 | 容量 32 万 |
  | --- | --- | --- | --- |
  | 共享系统提示（两种策略相同） | 86.5% | 86.5% | 86.5% |
  | 多轮对话：缓存 prompt+输出 / 只缓存 prompt | 33.9% / 30.9% | 86.0% / 74.5% | 86.0% / 74.5% |
  | 推理模型多轮（thinking 600）：缓存 prompt+输出 / 只缓存 prompt | **16.4% / 31.1%** | 52.9% / 74.5% | 74.5% / 74.5% |

- **解读**：普通多轮对话中，缓存输出能让下一轮命中上一轮的回答；推理模型的 thinking 不会进入下一轮 prompt，插入它们只会制造死分支、挤掉有用条目，容量小时损害明显（命中率减半）；容量足够大时两种策略一样。**更好的策略需要理解负载语义**（按 token 类型、按会话感知驱逐），这是开放问题。
- **真实框架对照**：sgl-project/sglang `python/sglang/srt/mem_cache/radix_cache.py`（`cache_finished_req`、`evict`）。
- **暴露的问题**：[P04](../../research/PROBLEM_BANK.md#p04)、[P03](../../research/PROBLEM_BANK.md#p03)。

### M11-L04 PD 分离（`lab_04_pd_disaggregation.py`）

- **先预测**：(1) TPOT SLO 很严格（如 12ms）时，哪种部署更好？TTFT SLO 很严格时呢？(2) KV 传输带宽从 50GB/s 降到 0.5GB/s，PD 分离还划算吗？
- **实测输出摘要**（4 张 GPU；SLO：TTFT ≤ 1s 且 TPOT ≤ 12ms；SLO 达成率 / goodput）：

  | 到达率 | 混合 ×4（分块 512） | 1P3D | 2P2D | 3P1D |
  | --- | --- | --- | --- | --- |
  | 16 | 100% / 14.5 | 73% / 10.0 | 100% / 14.6 | 100% / 14.5 |
  | 32 | 78% / 21.0 | 6% / 1.0 | 100% / 25.6 | 100% / 26.6 |
  | 40 | 33% / 10.4 | 5% / 0.8 | 44% / 11.9 | **100% / 31.6** |

  换成输出更长的负载（prompt 256~1024，输出 512~2048）后，到达率 24 时 3P1D 只有 14% 达标，而 1P3D 和混合部署都是 100%——**最优配比反过来了**。KV 传输带宽 50、10、2GB/s 时 3P1D 都是 100% 达标；降到 0.5GB/s（每请求传输约 546ms）时降到 79%。
- **解读**：这组默认负载以 prefill 为主（平均 prompt 约 2176 token、输出约 208 token），所以需要更多 prefill 卡；长输出负载需要更多 decode 卡。混合部署在高负载下 TPOT 撑不住。**最优 P:D 配比取决于负载，负载随时间变化时，静态配比必然在某些时段失效**——这就是动态调整 P/D 资源成为研究热点的原因。
- **开发说明**：默认参数第一版的负载太轻，所有部署方式都 100% 达标，看不出差别；随后提高到达率并加入长输出负载和带宽扫描。
- **暴露的问题**：[P06](../../research/PROBLEM_BANK.md#p06)、[P05](../../research/PROBLEM_BANK.md#p05)。

### M11-L05【选做·需 GPU】vLLM 实测（`lab_05_vllm_benchmark_gpu.py`）

在 GPU 环境中（`bash env/setup.sh --gpu`）用 vLLM 跑 `Qwen/Qwen2.5-0.5B-Instruct`（运行时才会从 Hugging Face 下载约 1GB 的权重，是否运行由你决定），测量不同并发下的吞吐和 TTFT，再把测得的数字代回 L02 的迭代耗时模型做校准。没有 GPU 时脚本打印 SKIP。

## 3. 常见误区

- “PagedAttention 让推理更快”：它主要节省显存，从而允许更大的 batch，吞吐提升是间接的。
- “前缀缓存命中率越高越好，所以应该缓存一切”：要考虑哪些 KV 将来会被复用（L03 的推理模型例子）。
- “PD 分离总是更好”：负载低、SLO 宽松时，混合部署加分块 prefill 往往足够，而且没有 KV 传输开销。
- “吞吐高就是好系统”：要在 SLO 下比较 goodput。

## 4. 论文与延伸阅读

- 必读：★`orca`（OSDI'22）、★`vllm`（arXiv 2309.06180）、`sglang`（arXiv 2312.07104）、`sarathiserve`（arXiv 2403.02310）、★`distserve`（arXiv 2401.09670）、`mooncake`（arXiv 2407.00079）。
- 选读：`sarathi`、`splitwise`、`llumnix`、`tetriinfer`、`dejavu`、`cachegen`；前沿：`flashinfer`、`lmcache`、`nanoflow`、`jenga`、`marconi`、`memserve`、`kvsurvey`、`kunserve`。
- 资源：vLLM 官方博客《Inside vLLM》（基于 V1 引擎的源码导读）；vLLM 文档“优化与调参”；SGLang 博客 *Unified Radix Cache*；NVIDIA Dynamo 架构文档；llm-d 项目主页；腾讯云 vLLM 源码分析（中文，质量一般，作入门参考）。

## 5. 自测题

Q-M11-L1-01 ~ Q-M11-L4-01；动手练习见 `exercises.md`。
