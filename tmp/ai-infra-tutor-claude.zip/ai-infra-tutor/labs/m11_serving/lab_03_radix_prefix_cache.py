"""[M11-L03] 前缀缓存（prefix caching）：前缀树 + LRU 驱逐，三种真实负载下的命中率

目标：实现一个 token 级前缀树（RadixAttention 中 radix 树的未压缩版本），支持最长前缀匹配、插入、
      按 LRU 驱逐叶子；在"共享系统提示""多轮对话""推理模型多轮对话"三种负载下测命中率随容量的变化；
      复现 SGLang issue #22373 描述的问题：推理模型的 thinking token 不会出现在下一轮 prompt 中，
      却被插入缓存，成为永远不会命中的"死分支"，挤占有用条目。
先预测：
  1. 多轮对话里，缓存容量只有总 token 量的 10% 时，命中率大约多少？
  2. 推理模型多轮对话中，"只缓存 prompt"和"缓存 prompt+输出（含 thinking）"哪个命中率高？总是如此吗？
可调参数：--caps（容量，token 数列表）、--sessions、--turns
暴露的问题：前缀缓存命中率在 agentic/推理负载下下降；驱逐策略需要理解负载语义 → PROBLEM_BANK P04、P03
对应论文：SGLang（2312.07104，RadixAttention）；Marconi（MLSys'25，混合模型的前缀缓存）；
          工程证据：sgl-project/sglang issue #22373、vllm-project/vllm issue #37003
真实框架对照：sgl-project/sglang python/sglang/srt/mem_cache/radix_cache.py（cache_finished_req、evict）
"""
import argparse
import heapq
import itertools
import random


class Node:
    __slots__ = ("children", "parent", "tok", "last")

    def __init__(self, parent, tok):
        self.children, self.parent, self.tok, self.last = {}, parent, tok, 0


class PrefixCache:
    def __init__(self, cap):
        self.root, self.cap, self.size, self.clock = Node(None, None), cap, 0, 0

    def match(self, toks):
        node, n = self.root, 0
        self.clock += 1
        for t in toks:
            if t not in node.children:
                break
            node = node.children[t]; node.last = self.clock; n += 1
        return n

    def insert(self, toks):
        node = self.root
        self.clock += 1
        for t in toks:
            if t not in node.children:
                node.children[t] = Node(node, t); self.size += 1
            node = node.children[t]; node.last = self.clock
        self.evict()

    def evict(self):
        if self.size <= self.cap:
            return
        heap, stack = [], [self.root]
        while stack:                                           # 收集所有叶子
            n = stack.pop()
            stack.extend(n.children.values())
            if not n.children and n is not self.root:
                heapq.heappush(heap, (n.last, id(n), n))
        while self.size > self.cap and heap:                   # 驱逐最久未用的叶子，父节点变叶子后入堆
            _, _, n = heapq.heappop(heap)
            p = n.parent
            del p.children[n.tok]; self.size -= 1
            if not p.children and p is not self.root:
                heapq.heappush(heap, (p.last, id(p), p))


fresh = itertools.count(1)


def new(k):
    return [next(fresh) for _ in range(k)]


def wl_system_prompt(rng, n=400):
    sys_p = new(800)
    return [(sys_p + new(rng.randint(50, 200)), new(100), []) for _ in range(n)]


def wl_multiturn(rng, sessions, turns, think=0):
    """返回 [(prompt, answer, thinking)]，按会话随机交错。think>0 表示推理模型：输出含 thinking，下一轮不带。"""
    hist = {s: new(300) for s in range(sessions)}             # 每个会话自己的系统提示/背景
    order = [s for s in range(sessions) for _ in range(turns)]
    rng.shuffle(order)
    out = []
    for s in order:
        prompt = hist[s] + new(rng.randint(30, 80))            # 历史 + 新的用户消息
        thinking, answer = new(think), new(rng.randint(60, 150))
        out.append((prompt, answer, thinking))
        hist[s] = prompt + answer                              # 下一轮历史只包含最终回答
    return out


def hit_rate(reqs, cap, policy):
    c = PrefixCache(cap)
    hit = total = 0
    for prompt, answer, thinking in reqs:
        hit += c.match(prompt); total += len(prompt)
        if policy == "prompt+output":
            c.insert(prompt + thinking + answer)               # SGLang 默认：输出 token 全部插入
        else:
            c.insert(prompt)                                   # issue #22373 提议：有 thinking 时只缓存 prompt
    return hit / total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--caps", type=int, nargs="+", default=[5000, 20000, 80000, 320000])
    ap.add_argument("--sessions", type=int, default=60)
    ap.add_argument("--turns", type=int, default=6)
    a = ap.parse_args()
    rng = random.Random(0)
    loads = {
        "共享系统提示": wl_system_prompt(rng),
        "多轮对话": wl_multiturn(rng, a.sessions, a.turns),
        "推理模型多轮(thinking=600)": wl_multiturn(rng, a.sessions, a.turns, think=600),
    }
    for name, reqs in loads.items():
        tot = sum(len(p) for p, _, _ in reqs)
        print(f"\n== {name}：{len(reqs)} 个请求，prompt 共 {tot} token ==")
        for cap in a.caps:
            r1 = hit_rate(reqs, cap, "prompt+output")
            r2 = hit_rate(reqs, cap, "prompt-only")
            print(f"  容量 {cap:7d}：缓存 prompt+输出 命中率 {r1:6.1%}   只缓存 prompt 命中率 {r2:6.1%}")
    print("\n[小结] 共享前缀负载下命中率很高；多轮对话里缓存输出能让下一轮命中'上一轮的回答'。推理模型的 thinking"
          "\n       不会进入下一轮 prompt，插入它们只会制造死分支、挤掉有用条目——容量小时损害明显；但只缓存 prompt"
          "\n       又会丢掉对回答的复用。更好的策略需要理解负载语义（如按 token 类型/会话感知驱逐），这是开放问题。"
          "\n[问题库] P04 前缀缓存命中率；P03 驱逐导致的重复 prefill")


if __name__ == "__main__":
    main()
