"""[M11-L04] Prefill/Decode 分离（PD disaggregation）vs 混合部署：在 SLO 约束下比较 goodput

目标：在 4 张 GPU 上比较"每卡都做 prefill+decode（分块 prefill）"与"P 张卡专做 prefill、D 张卡专做 decode，
      中间传输 KV"两种部署；以同时满足 TTFT 与 TPOT SLO 的请求速率（goodput）为指标，寻找最佳 P:D 配比。
先预测：
  1. TPOT SLO 很严格（如 12ms）时，哪种部署更好？TTFT SLO 很严格时呢？
  2. KV 传输带宽从 50GB/s 降到 5GB/s，PD 分离还划算吗？
可调参数：--rates（req/s 列表）、--slo-ttft、--slo-tpot（ms）、--kv-bw（GB/s）
暴露的问题：PD 分离的资源配比、KV 传输开销 → PROBLEM_BANK P06、P05
对应论文：DistServe（2401.09670，goodput 与配比搜索）；Splitwise（2311.18677）；Mooncake（2407.00079）；
          TetriInfer；工程实现：NVIDIA Dynamo、llm-d、vLLM/SGLang 的 PD 分离
迭代耗时模型同 lab_02（假设）：t = 5ms + 0.03ms×prefill token + 0.04ms×decode 序列；每 token KV 128KB（Llama-3-8B）
"""
import argparse
import random


def it_time(p, d):
    return 5.0 + 0.03 * p + 0.04 * d


def workload(n, rate, p_rng=(256, 4096), o_rng=(32, 384), seed=0):
    rng = random.Random(seed)
    t, out = 0.0, []
    for i in range(n):
        t += rng.expovariate(rate) * 1000
        out.append({"id": i, "arr": t, "P": rng.randint(*p_rng), "O": rng.randint(*o_rng)})
    return out


def decode_gpu(items):
    """items: [(ready_time, req, first_token_time)] → {id: 末 token 时间}。连续 decode，新请求下一步加入。"""
    items = sorted(items, key=lambda x: x[0])
    t, i, run, last = 0.0, 0, [], {}
    while i < len(items) or run:
        if not run and items[i][0] > t:
            t = items[i][0]
        while i < len(items) and items[i][0] <= t:
            run.append([items[i][1], 1]); i += 1
        t += it_time(0, len(run))
        for r in run:
            r[1] += 1
            if r[1] >= r[0]["O"]:
                last[r[0]["id"]] = t
        run = [r for r in run if r[1] < r[0]["O"]]
    return last


def colocated(reqs, gpus, budget=512):
    """每卡独立的分块 prefill 调度，请求轮询分配。"""
    res = {}
    for g in range(gpus):
        mine = reqs[g::gpus]
        t, i, run = 0.0, 0, []
        while i < len(mine) or run:
            if not run and mine[i]["arr"] > t:
                t = mine[i]["arr"]
            while i < len(mine) and mine[i]["arr"] <= t:
                run.append({"r": mine[i], "done": 0, "gen": 0}); i += 1
            dec = [x for x in run if x["done"] >= x["r"]["P"]]
            room, plan = budget - len(dec), []
            for x in run:
                if x["done"] < x["r"]["P"] and room > 0:
                    c = min(room, x["r"]["P"] - x["done"]); plan.append((x, c)); room -= c
            t += it_time(sum(c for _, c in plan), len(dec))
            for x, c in plan:
                x["done"] += c
                if x["done"] >= x["r"]["P"]:
                    x["gen"] = 1; res[x["r"]["id"]] = [t, t]
            for x in dec:
                x["gen"] += 1; res[x["r"]["id"]][1] = t
            run = [x for x in run if not (x["done"] >= x["r"]["P"] and x["gen"] >= x["r"]["O"])]
    return res


def disaggregated(reqs, n_p, n_d, kv_bw, budget=8192):
    free, first = [0.0] * n_p, {}
    queue = list(reqs)
    while queue:                                           # prefill 池：空闲 GPU 取走所有已到达请求（受 token 预算限制）
        g = min(range(n_p), key=lambda k: free[k])
        t = max(free[g], queue[0]["arr"])
        batch, tok = [], 0
        while queue and queue[0]["arr"] <= t and (not batch or tok + queue[0]["P"] <= budget):
            tok += queue[0]["P"]; batch.append(queue.pop(0))
        free[g] = t + it_time(tok, 0)
        for r in batch:
            first[r["id"]] = free[g]
    per_d = [[] for _ in range(n_d)]
    for k, r in enumerate(reqs):                            # KV 传输后进入 decode 池（轮询）
        ready = first[r["id"]] + r["P"] * 128 * 1024 / (kv_bw * 1e9) * 1000
        per_d[k % n_d].append((ready, r, first[r["id"]]))
    res = {}
    for items in per_d:
        last = decode_gpu(items)
        for _, r, f in items:
            res[r["id"]] = [f, last[r["id"]]]
    return res


def goodput(reqs, res, slo_ttft, slo_tpot):
    ok = 0
    for r in reqs:
        f, l = res[r["id"]]
        if f - r["arr"] <= slo_ttft and (l - f) / max(1, r["O"] - 1) <= slo_tpot:
            ok += 1
    span = max(v[1] for v in res.values()) - reqs[0]["arr"]
    return ok / len(reqs), ok / span * 1000


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rates", type=float, nargs="+", default=[16, 24, 32, 40])
    ap.add_argument("--n", type=int, default=400)
    ap.add_argument("--slo-ttft", type=float, default=1000)
    ap.add_argument("--slo-tpot", type=float, default=12)
    ap.add_argument("--kv-bw", type=float, default=50)
    a = ap.parse_args()
    configs = [("混合x4(分块512)", None), ("1P3D", (1, 3)), ("2P2D", (2, 2)), ("3P1D", (3, 1))]
    print(f"== 4 GPU；SLO: TTFT≤{a.slo_ttft:.0f}ms 且 TPOT≤{a.slo_tpot:.0f}ms；KV 传输 {a.kv_bw}GB/s ==")
    print(f"  {'到达率':>6s} " + " ".join(f"{c[0]:>18s}" for c in configs) + "   （SLO 达成率 / goodput req/s）")
    for rate in a.rates:
        reqs = workload(a.n, rate)
        row = []
        for name, pd in configs:
            res = colocated(reqs, 4) if pd is None else disaggregated(reqs, pd[0], pd[1], a.kv_bw)
            frac, gp = goodput(reqs, res, a.slo_ttft, a.slo_tpot)
            row.append(f"{frac:6.0%}/{gp:5.1f}")
        print(f"  {rate:6.1f} " + " ".join(f"{x:>18s}" for x in row))
    print("\n== 换成输出更长的负载（prompt 256~1024，输出 512~2048，如长回答/推理模型）==")
    for rate in [8, 16, 24]:
        reqs = workload(a.n, rate, p_rng=(256, 1024), o_rng=(512, 2048))
        row = []
        for name, pd in configs:
            res = colocated(reqs, 4) if pd is None else disaggregated(reqs, pd[0], pd[1], a.kv_bw)
            frac, gp = goodput(reqs, res, a.slo_ttft, a.slo_tpot)
            row.append(f"{frac:6.0%}/{gp:5.1f}")
        print(f"  {rate:6.1f} " + " ".join(f"{x:>18s}" for x in row))
    reqs = workload(a.n, a.rates[-1])
    print(f"\n== KV 传输带宽的影响（原负载，到达率 {a.rates[-1]}，3P1D）==")
    for bw in [50, 10, 2, 0.5]:
        frac, gp = goodput(reqs, disaggregated(reqs, 3, 1, bw), a.slo_ttft, a.slo_tpot)
        xfer = sum(r["P"] * 128 * 1024 / (bw * 1e9) * 1000 for r in reqs) / len(reqs)
        print(f"  {bw:5.1f} GB/s：平均每请求 KV 传输 {xfer:7.1f} ms  SLO 达成率 {frac:5.0%}  goodput {gp:5.1f} req/s")
    print("  （传输时间摊到上百个输出 token 上，对 TPOT 影响小；但它直接推迟第 2 个 token，影响交互体验，"
          "\n   且传输占用的网络/显存在真实系统中会与其他流量竞争——本模拟未建模这些。）")
    print("\n[小结] PD 分离让 decode 不受 prefill 干扰，TPOT 稳定；代价是 KV 传输与 P/D 配比僵化——配比不对时"
          "\n       某一池先饱和（1P3D 在 prefill 重的负载下崩溃）。最优 P:D 取决于 prompt/输出长度之比和 SLO；"
          "\n       负载低或 SLO 宽松时，混合部署 + 分块 prefill 往往足够。"
          "\n       负载随时间变化时如何动态调整 P:D（以及 KV 放哪里、怎么传）正是 Mooncake/Dynamo/llm-d 等在解决的问题。"
          "\n[问题库] P06 PD 分离的资源配比与 KV 传输；P05 prefill/decode 干扰")


if __name__ == "__main__":
    main()
