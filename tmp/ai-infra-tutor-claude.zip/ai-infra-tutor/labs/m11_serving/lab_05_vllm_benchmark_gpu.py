"""[M11-L05]【选做·需 GPU】在真实推理引擎 vLLM 上测 TTFT / TPOT / 吞吐，并与 M11 模拟器对照

目标：用 vLLM 的离线 API 跑一个小模型，测量不同并发下的吞吐与延迟，检验 lab_02 模拟器的结论
      （连续批处理吞吐随并发上升、长 prompt 插入影响 decode 延迟）。
建议模型（本教学包不下载，运行时由 vLLM 从 Hugging Face 获取，需要你自行决定是否下载）：
  Qwen/Qwen2.5-0.5B-Instruct（约 1GB，单张 8GB 以上显存即可）
先预测：并发从 1 增到 64，输出吞吐提高几倍？每个请求的平均延迟变化多少？
可调参数：--model、--concurrency（列表）、--prompt-len、--max-tokens
CPU 替代：labs/m11_serving/lab_02_continuous_batching_sim.py（同样的现象，用模拟器观察）。
         没有 GPU 或未安装 vllm 时本脚本只打印说明并以 0 退出（run_all 记为 SKIP）。
依赖：env/requirements-gpu.txt 中的 vllm（需与 CUDA 版本匹配，见 env/README 的安装说明）
暴露的问题：真实系统与模拟器的差距在哪里 → PROBLEM_BANK P05、P29
对应论文：vLLM（2309.06180）；Sarathi-Serve
真实框架对照：vllm-project/vllm benchmarks/（官方 benchmark 脚本）
"""
import argparse
import sys
import time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-0.5B-Instruct")
    ap.add_argument("--concurrency", type=int, nargs="+", default=[1, 8, 32, 64])
    ap.add_argument("--prompt-len", type=int, default=512)
    ap.add_argument("--max-tokens", type=int, default=128)
    a = ap.parse_args()
    try:
        import torch
        from vllm import LLM, SamplingParams
        ok = torch.cuda.is_available()
    except ImportError:
        ok = False
    if not ok:
        print("[SKIP] 需要 NVIDIA GPU + vllm。CPU 替代实验：m11 lab_02（调度模拟器）。"
              f"\n       建议模型：{a.model}（运行时才会下载，本教学包不包含任何权重）。")
        sys.exit(0)
    llm = LLM(model=a.model, gpu_memory_utilization=0.85)
    sp = SamplingParams(max_tokens=a.max_tokens, ignore_eos=True, temperature=0.0)
    prompt = "hello " * a.prompt_len
    for c in a.concurrency:
        t0 = time.perf_counter()
        outs = llm.generate([prompt] * c, sp, use_tqdm=False)
        dt = time.perf_counter() - t0
        n_out = sum(len(o.outputs[0].token_ids) for o in outs)
        m = outs[0].metrics                                 # 不同 vLLM 版本字段可能不同，缺失时跳过
        ttft = (m.first_token_time - m.arrival_time) if m and getattr(m, "first_token_time", None) else float("nan")
        print(f"  并发 {c:3d}: 总耗时 {dt:6.2f}s，输出吞吐 {n_out / dt:8.0f} tok/s，首请求 TTFT {ttft * 1e3:7.1f} ms")
    print("[小结] 对照 lab_02：吞吐随并发上升直到显存/算力饱和；把这里的数字代回模拟器的迭代耗时模型做校准。")


if __name__ == "__main__":
    main()
