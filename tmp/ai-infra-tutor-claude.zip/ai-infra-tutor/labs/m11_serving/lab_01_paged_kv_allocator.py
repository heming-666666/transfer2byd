"""[M11-L01] 从零实现分页 KV Cache 分配器（PagedAttention 的内存管理部分）

目标：实现块池（block pool）+ 每序列块表（block table）+ 引用计数 + 写时复制（copy-on-write），
      支持追加 token、并行采样 fork、释放；与"按最大长度连续预分配"比较显存浪费与可容纳的并发数。
先预测：
  1. 请求输出长度在 [16, 2048] 均匀分布、按 2048 预分配，平均浪费多少显存？块大小 16 时呢？
  2. 并行采样 n=4（共享同一个 1000 token 的 prompt），分页 + 共享比各自复制省多少块？
可调参数：--block（块大小，token 数）、--capacity（总块数）、--requests、--max-len
暴露的问题：KV 显存是并发上限；块大小影响碎片与 kernel 效率 → PROBLEM_BANK P02
对应论文：vLLM / PagedAttention（2309.06180）；Jenga（异构 embedding 的分配器，SOSP'25）
真实框架对照：vllm-project/vllm vllm/v1/core/block_pool.py、kv_cache_manager.py（V1 引擎）
"""
import argparse
import random


class BlockPool:
    def __init__(self, n_blocks):
        self.free = list(range(n_blocks))[::-1]
        self.ref = [0] * n_blocks

    def alloc(self):
        if not self.free:
            raise MemoryError("KV 块耗尽（真实系统会触发抢占：换出或丢弃后重算）")
        b = self.free.pop(); self.ref[b] = 1
        return b

    def incref(self, b):
        self.ref[b] += 1

    def decref(self, b):
        self.ref[b] -= 1
        if self.ref[b] == 0:
            self.free.append(b)


class Sequence:
    def __init__(self, pool, block_size):
        self.pool, self.bs, self.table, self.n = pool, block_size, [], 0

    def append(self, k=1):
        for _ in range(k):
            if self.n % self.bs == 0:                       # 最后一块满了（或还没有块）→ 申请新块
                self.table.append(self.pool.alloc())
            elif self.pool.ref[self.table[-1]] > 1:          # 最后一块被共享 → 写时复制
                old = self.table[-1]
                self.table[-1] = self.pool.alloc()           # （真实实现还要拷贝块内已有的 KV）
                self.pool.decref(old)
            self.n += 1

    def fork(self):
        child = Sequence(self.pool, self.bs)
        child.table, child.n = list(self.table), self.n
        for b in self.table:
            self.pool.incref(b)                              # 共享全部块，只增加引用计数
        return child

    def free(self):
        for b in self.table:
            self.pool.decref(b)
        self.table, self.n = [], 0


def contiguous_waste(lengths, max_len):
    return 1 - sum(lengths) / (len(lengths) * max_len)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--block", type=int, nargs="+", default=[1, 16, 64, 256])
    ap.add_argument("--capacity", type=int, default=200_000, help="KV 容量（token 数）")
    ap.add_argument("--requests", type=int, default=2000)
    ap.add_argument("--max-len", type=int, default=2048)
    a = ap.parse_args()
    rng = random.Random(0)
    lengths = [rng.randint(16, a.max_len) for _ in range(a.requests)]

    print(f"== 显存浪费：{a.requests} 个请求，长度均匀分布于 [16, {a.max_len}] ==")
    print(f"  连续预分配（按最大长度 {a.max_len}）：浪费 {contiguous_waste(lengths, a.max_len):.1%}，"
          f"容量 {a.capacity} token 可同时容纳 {a.capacity // a.max_len} 条")
    avg = sum(lengths) / len(lengths)
    for bs in a.block:
        waste = sum((-l) % bs for l in lengths) / sum(lengths + [(-l) % bs for l in lengths])
        print(f"  分页 block={bs:4d}：内部碎片 {waste:6.2%}，平均可同时容纳约 "
              f"{int(a.capacity / (avg + bs / 2))} 条")

    print("\n== 功能验证：追加、fork、写时复制、释放 ==")
    bs = 16
    pool = BlockPool(a.capacity // bs)
    total = len(pool.free)
    parent = Sequence(pool, bs); parent.append(1000)        # 1000 token 的 prompt → 63 块
    used_prompt = total - len(pool.free)
    kids = [parent.fork() for _ in range(3)]                 # 并行采样 n=4（parent + 3 个 child）
    for s in [parent] + kids:
        s.append(200)                                        # 各自生成 200 token
    used_shared = total - len(pool.free)
    used_copy = 4 * ((1200 + bs - 1) // bs)
    print(f"  prompt 1000 token 占 {used_prompt} 块；4 路采样各生成 200 token 后共占 {used_shared} 块，"
          f"若各自复制需 {used_copy} 块（节省 {1 - used_shared / used_copy:.0%}）")
    print(f"  共享块引用计数示例：块 {parent.table[0]} 的 ref = {pool.ref[parent.table[0]]}")
    for s in [parent] + kids:
        s.free()
    print(f"  全部释放后空闲块 {len(pool.free)} / {total}（应相等）")
    try:
        big = Sequence(BlockPool(4), bs); big.append(100)
    except MemoryError as e:
        print(f"  容量不足时：{e}")
    print("\n[小结] 分页让 KV 只按实际长度占用，碎片被限制在每条序列最后一块；块表 + 引用计数让 fork/前缀共享"
          "\n       几乎零成本。块越小碎片越少，但块表更长、attention kernel 访存更零散——这是块大小的取舍。"
          "\n[问题库] P02 KV Cache 是并发上限")


if __name__ == "__main__":
    main()
