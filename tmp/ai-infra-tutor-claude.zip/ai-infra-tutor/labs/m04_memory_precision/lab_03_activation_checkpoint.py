"""[M04-L03] 激活重计算（activation checkpointing）：用算力换显存

目标：从零实现一个 checkpoint（前向只存输入，反向时重算），用 saved_tensors_hooks 统计
      为反向保存的字节数，对比"不重算 / 每层重算 / 每 k 层重算"的显存与耗时。
先预测：
  1. 每层都重算时，保存的激活降为原来的几分之一？前向+反向耗时增加约多少（理论值）？
  2. 每 √L 层设一个检查点（Chen et al. 2016），显存与重算开销如何？
可调参数：--layers、--width、--batch、--every（检查点间隔列表）
暴露的问题：重算策略的选择是显存-时间的权衡；自动选择是研究问题 → PROBLEM_BANK P14
对应论文：Training Deep Nets with Sublinear Memory Cost（1604.06174）；
          Reducing Activation Recomputation（选择性重计算）
真实框架对照：torch/utils/checkpoint.py；Megatron-LM megatron/core/tensor_parallel/random.py（CheckpointFunction）
"""
import argparse
import time

import torch
import torch.nn as nn


class Checkpoint(torch.autograd.Function):
    """前向在 no_grad 下运行子网络，只保存输入；反向时用 enable_grad 重算再求梯度。"""

    @staticmethod
    def forward(ctx, run_fn, x, *params):
        ctx.run_fn = run_fn
        ctx.save_for_backward(x)
        with torch.no_grad():
            return run_fn(x)

    @staticmethod
    def backward(ctx, grad_out):
        (x,) = ctx.saved_tensors
        x = x.detach().requires_grad_(True)
        params = [p for p in ctx.run_fn.parameters()]
        with torch.enable_grad():
            y = ctx.run_fn(x)                              # 重算前向
        grads = torch.autograd.grad(y, [x] + params, grad_out)
        return (None, grads[0], *grads[1:])


def build(layers, width):
    torch.manual_seed(0)
    return nn.ModuleList(nn.Sequential(nn.Linear(width, 4 * width), nn.GELU(), nn.Linear(4 * width, width))
                         for _ in range(layers))


def forward(blocks, x, every):
    if every == 0:
        for b in blocks:
            x = x + b(x)
        return x
    for i in range(0, len(blocks), every):
        seg = nn.Sequential(*blocks[i:i + every])

        def run(inp, seg=seg):
            for b in seg:
                inp = inp + b(inp)
            return inp
        run.parameters = seg.parameters
        x = Checkpoint.apply(run, x, *seg.parameters())
    return x


def run_once(blocks, x, every):
    params = {p.data_ptr() for p in blocks.parameters()}
    saved = {}

    def pack(t):
        if t.data_ptr() not in params:                     # 不统计参数本身
            saved[t.data_ptr()] = t.numel() * t.element_size()
        return t
    for p in blocks.parameters():
        p.grad = None
    t0 = time.perf_counter()
    with torch.autograd.graph.saved_tensors_hooks(pack, lambda t: t):
        out = forward(blocks, x, every)
    out.square().mean().backward()
    dt = time.perf_counter() - t0
    return sum(saved.values()), dt, [p.grad.clone() for p in blocks.parameters()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", type=int, default=16)
    ap.add_argument("--width", type=int, default=256)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--every", type=int, nargs="+", default=[0, 1, 4, 16])
    a = ap.parse_args()
    blocks = build(a.layers, a.width)
    x = torch.randn(a.batch, a.width)
    run_once(blocks, x, 0)                                 # 预热
    base = [run_once(blocks, x, 0) for _ in range(3)]
    base_mem, base_g = base[0][0], base[0][2]
    base_t = sorted(r[1] for r in base)[1]
    print(f"== {a.layers} 层 MLP 块，width={a.width}，batch={a.batch} ==")
    print(f"  {'检查点间隔':>8s} {'保存激活(MB)':>12s} {'相对':>6s} {'耗时(ms)':>9s} {'相对':>6s} {'梯度一致':>8s}")
    for e in a.every:
        run_once(blocks, x, e)                             # 每种配置单独预热（首次运行有额外开销）
        runs = [run_once(blocks, x, e) for _ in range(3)]
        mem, g = runs[0][0], runs[0][2]
        dt = sorted(r[1] for r in runs)[1]                 # 取中位数
        same = all(torch.allclose(u, v, atol=1e-5) for u, v in zip(g, base_g))
        label = "不重算" if e == 0 else f"每{e}层"
        print(f"  {label:>8s} {mem / 2 ** 20:12.2f} {mem / base_mem:6.2f} {dt * 1e3:9.1f} "
              f"{dt / base_t:6.2f} {str(same):>8s}")
    print("\n  注：'每k层'时，段内激活在反向时临时重建（峰值另计 1 段），表中统计的是跨段常驻部分。")
    print("\n[小结] 每层重算把常驻激活降到每层只剩输入，代价是多做约一次前向（理论 +33%：前向 1 份、反向 2 份）。"
          "\n       间隔越大，常驻越少但段内峰值越高；选择性重计算只重算'便宜但占显存'的部分。"
          "\n[问题库] P14 显存墙与重计算策略")


if __name__ == "__main__":
    main()
