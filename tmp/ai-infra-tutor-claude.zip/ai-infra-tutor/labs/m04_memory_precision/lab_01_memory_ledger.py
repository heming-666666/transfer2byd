"""[M04-L01] 训练显存账本：参数 / 梯度 / 优化器状态 / 激活值

目标：能估算任意 Transformer 训练时每张卡的显存，并说明 ZeRO、张量并行、激活重计算各省掉哪一项；
      再在一个小模型上实测参数/梯度/Adam 状态的字节数，验证账本公式。
先预测：
  1. 7B 模型用 BF16 混合精度 + Adam 训练，仅"模型状态"就要多少 GB？单张 80GB 卡放得下吗？
  2. 序列长度从 2K 增到 32K，激活值显存增加多少倍？（提示：注意力分数项随 s² 增长）
可调参数：--model（7b/13b/70b）、--seq、--mbs（micro batch）、--tp、--dp
暴露的问题：显存墙；长序列激活爆炸 → PROBLEM_BANK P14、P20
对应论文：ZeRO（16Ψ 字节账本）；Reducing Activation Recomputation（Korthikanti et al.，
          每层激活 sbh(34 + 5as/h) 字节公式）；Megatron 3D 并行
"""
import argparse

import torch

MODELS = {  # Llama 风格：层数 L、隐藏 h、头数 a、FFN f、词表 V
    "7b": dict(L=32, h=4096, a=32, f=11008, V=32000),
    "13b": dict(L=40, h=5120, a=40, f=13824, V=32000),
    "70b": dict(L=80, h=8192, a=64, f=28672, V=32000),
}


def n_params(c):
    # 注意力 4h²（QKV+O，按 MHA 估算）+ SwiGLU MLP 3hf，外加输入/输出嵌入
    return c["L"] * (4 * c["h"] ** 2 + 3 * c["h"] * c["f"]) + 2 * c["V"] * c["h"]


def model_states(psi, zero, dp):
    """混合精度 Adam：BF16 参数 2 + BF16 梯度 2 + FP32 主权重 4 + m 4 + v 4 = 16 字节/参数。"""
    if zero == 0:
        return 16 * psi
    if zero == 1:
        return 4 * psi + 12 * psi / dp
    if zero == 2:
        return 2 * psi + 14 * psi / dp
    return 16 * psi / dp


def activations(c, s, b, tp, mode):
    """Korthikanti et al. 2022 表 2：每层激活字节（BF16）。"""
    h, a, L = c["h"], c["a"], c["L"]
    if mode == "none":            # 无并行、无重计算
        per = s * b * h * (34 + 5 * a * s / h)
    elif mode == "tp+sp":         # 张量并行 + 序列并行
        per = s * b * h * (34 + 5 * a * s / h) / tp
    elif mode == "tp+sp+selective":  # 再加选择性重计算（只重算注意力 softmax 部分）
        per = s * b * h * 34 / tp
    else:                         # 完全重计算：只存每层输入
        per = 2 * s * b * h / tp
    return per * L


def gb(x):
    return x / 2 ** 30


def measure_small():
    print("\n== 实测：小模型的模型状态字节（FP32 训练 + Adam）==")
    m = torch.nn.Sequential(torch.nn.Linear(512, 2048), torch.nn.GELU(), torch.nn.Linear(2048, 512))
    opt = torch.optim.Adam(m.parameters())
    m(torch.randn(8, 512)).sum().backward()
    opt.step()
    P = sum(p.numel() for p in m.parameters())
    pb = sum(p.numel() * p.element_size() for p in m.parameters())
    gbytes = sum(p.grad.numel() * p.grad.element_size() for p in m.parameters())
    ob = sum(v.numel() * v.element_size() for st in opt.state.values() for v in st.values() if torch.is_tensor(v) and v.dim() > 0)
    print(f"  参数 {P:,} 个：参数 {pb:,} B + 梯度 {gbytes:,} B + Adam 状态 {ob:,} B "
          f"= {(pb + gbytes + ob) / P:.1f} 字节/参数（FP32 训练：4+4+8=16）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="7b", choices=MODELS)
    ap.add_argument("--seq", type=int, nargs="+", default=[2048, 8192, 32768])
    ap.add_argument("--mbs", type=int, default=1)
    ap.add_argument("--tp", type=int, default=8)
    ap.add_argument("--dp", type=int, default=8)
    a = ap.parse_args()
    c = MODELS[a.model]
    psi = n_params(c)
    print(f"== {a.model}: 参数量 ≈ {psi / 1e9:.2f}B ==")
    print("-- 模型状态（每卡）--")
    for z in range(4):
        print(f"  ZeRO-{z} (dp={a.dp}): {gb(model_states(psi, z, a.dp)):8.1f} GB")
    print(f"  注：若再叠加张量并行 tp={a.tp}，每卡模型状态再除以 tp")

    print(f"\n-- 激活值（mbs={a.mbs}，全部 {c['L']} 层，每卡）--")
    print(f"  {'seq':>6s} {'无优化':>10s} {'TP+SP':>10s} {'+选择重算':>10s} {'完全重算':>10s}")
    for s in a.seq:
        row = [gb(activations(c, s, a.mbs, a.tp, m)) for m in ["none", "tp+sp", "tp+sp+selective", "full"]]
        print(f"  {s:6d} " + " ".join(f"{v:10.1f}" for v in row) + "  GB")
    measure_small()
    print("\n[小结] 模型状态里优化器占 12/16；ZeRO 按 DP 切分它们。激活值里 5as/h 项随 s² 增长，"
          "\n       长序列时远超 34 项——FlashAttention 不存 softmax 矩阵、选择性重计算都针对这一项。"
          "\n[问题库] P14 显存墙；P20 长序列训练")


if __name__ == "__main__":
    main()
