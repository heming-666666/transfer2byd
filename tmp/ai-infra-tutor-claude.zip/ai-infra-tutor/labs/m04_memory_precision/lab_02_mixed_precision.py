"""[M04-L02] 混合精度的数值问题：舍入、下溢、累加误差、FP8 缩放粒度

目标：亲眼看到 FP16/BF16 为什么需要 FP32 主权重、loss scaling 和 FP32 累加；
      理解 FP8 训练中缩放粒度（per-tensor vs per-block）对离群值的影响。
先预测：
  1. 在 FP16 里 1.0 + 1e-4 等于几？BF16 呢？
  2. 张量里有一个 1000 倍的离群值时，per-tensor FP8 量化会让其余元素的误差怎样变化？
可调参数：--block（FP8 分块大小，DeepSeek-V3 用 1×128 / 128×128）、--outlier
暴露的问题：低精度训练的稳定性与缩放粒度 → PROBLEM_BANK P15
对应论文：Mixed Precision Training（1710.03740）；FP8 Formats（2209.05433）；
          DeepSeek-V3（细粒度 FP8 量化）；Scaling FP8 training to trillion-token LLMs
"""
import argparse

import torch


def demo_rounding():
    print("== 1. 小更新被舍掉（为什么需要 FP32 主权重）==")
    for dt in [torch.float16, torch.bfloat16, torch.float32]:
        one = torch.tensor(1.0, dtype=dt)
        print(f"  {str(dt):15s} eps={torch.finfo(dt).eps:.2e}  1+1e-4 = {(one + 1e-4).item():.6f}"
              f"  max={torch.finfo(dt).max:.3e}  最小正规数={torch.finfo(dt).tiny:.2e}")
    # 用 FP16 权重直接做 SGD：每步更新 lr*grad = 1e-4，权重停在原地
    w16 = torch.tensor(1.0, dtype=torch.float16); w32 = torch.tensor(1.0)
    for _ in range(1000):
        w16 -= torch.tensor(1e-4, dtype=torch.float16); w32 -= 1e-4
    print(f"  1000 步、每步减 1e-4：FP16 权重={w16.item():.4f}（应为 0.9），FP32 主权重={w32.item():.4f}")


def demo_underflow():
    print("\n== 2. 梯度下溢与 loss scaling ==")
    g = torch.tensor([1e-3, 1e-5, 1e-7, 1e-9])
    print(f"  原始梯度       {g.tolist()}")
    print(f"  直接转 FP16    {g.half().float().tolist()}")
    S = 65536.0
    print(f"  ×{S:.0f} 后转 FP16 再 ÷S {(g * S).half().float().div(S).tolist()}")
    print(f"  转 BF16（指数位与 FP32 相同，无需 scaling）{g.bfloat16().float().tolist()}")


def demo_accumulate():
    print("\n== 3. 累加精度（为什么 GEMM 要用 FP32 累加器）==")
    x = torch.full((10000,), 1e-3)
    acc16 = torch.tensor(0.0, dtype=torch.float16)
    for v in x.half():
        acc16 = acc16 + v
    print(f"  10000 个 1e-3 求和：FP16 逐个累加={acc16.item():.4f}  FP32={x.sum().item():.4f}（真值 10）")


def fp8_quant(x, block):
    """E4M3 量化：按块计算 scale = amax/448，量化后再反量化，返回重建结果。"""
    fmax = torch.finfo(torch.float8_e4m3fn).max      # 448
    flat = x.reshape(-1, block) if block else x.reshape(1, -1)
    scale = flat.abs().amax(dim=1, keepdim=True).clamp(min=1e-12) / fmax
    q = (flat / scale).to(torch.float8_e4m3fn)
    return (q.float() * scale).reshape(x.shape)


def int8_quant(x, block):
    """对称 INT8 均匀量化（对照组）：刻度是线性的，离群值会直接拉大量化步长。"""
    flat = x.reshape(-1, block) if block else x.reshape(1, -1)
    scale = flat.abs().amax(dim=1, keepdim=True).clamp(min=1e-12) / 127
    return ((flat / scale).round().clamp(-127, 127) * scale).reshape(x.shape)


def demo_fp8(block, outliers):
    print("\n== 4. 缩放粒度 vs 离群值：FP8(E4M3，浮点刻度) 对照 INT8（均匀刻度）==")
    torch.manual_seed(0)
    x = torch.randn(64, 1024)
    mask = torch.ones_like(x, dtype=torch.bool); mask[3, 7] = False
    print(f"  {'离群倍数':>8s} {'格式':6s} {'粒度':16s} {'其余元素相对误差':>14s} {'被量化成0':>10s}")
    for k in [1.0] + outliers:
        t = x.clone(); t[3, 7] *= k                          # 单个离群值
        for fmt, fn in [("FP8", fp8_quant), ("INT8", int8_quant)]:
            for gran, blk in [("per-tensor", 0), (f"per-block({block})", block)]:
                r = fn(t, blk)
                rel = ((r - t)[mask].norm() / t[mask].norm()).item()
                zero = ((r == 0) & (t != 0))[mask].float().mean().item()
                print(f"  {k:8.0e} {fmt:6s} {gran:16s} {rel:14.4f} {zero:10.2%}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--block", type=int, default=128)
    ap.add_argument("--outlier", type=float, nargs="+", default=[1e3, 1e5])
    a = ap.parse_args()
    demo_rounding()
    demo_underflow()
    demo_accumulate()
    demo_fp8(a.block, a.outlier)
    print("\n[小结] FP16 范围窄需要 loss scaling；BF16 范围宽但精度低，仍需 FP32 主权重与累加。"
          "\n       INT8 的刻度是均匀的，一个离群值就让其余元素误差暴涨；FP8 有指数位，对缩放不敏感，"
          "\n       直到小值跌出可表示范围（E4M3 最小次正规数 2^-9）被量化成 0。细粒度（per-block）缩放"
          "\n       把离群值的影响限制在一个块内——这正是 DeepSeek-V3 采用 1×128/128×128 分块缩放的原因。"
          "\n[问题库] P15 低精度训练稳定性与缩放粒度")


if __name__ == "__main__":
    main()
