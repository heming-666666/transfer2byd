# 实验代码汇总（ALL_CODE）

> 由 `tools/build_bundle.py` 从 `labs/` 源码自动生成，**请勿手工编辑**。每个实验附构建机的实测输出（`labs/<模块>/outputs/<实验>.txt`，计时数字因机器而异，趋势应一致）。供不能读取文件的教学 agent 使用：讲到哪个模块，就把对应一节发给它。

## M00 定位：AI Infra 的版图、关键指标与学习路线（`labs/m00_overview/`）

### `labs/m00_overview/lab_01_serving_metrics.py`

```python
"""[M00-L01] 从请求时间线计算推理服务指标：TTFT / TPOT / 吞吐 / goodput / MFU

目标：拿到一份"每个 token 何时产出"的时间线后，能自己算出论文里常见的指标，
      并理解为什么系统论文越来越多地报告 goodput（满足 SLO 的请求吞吐）而不是原始吞吐。
先预测：
  1. 负载从低到高时，平均 TPOT 和 P99 TPOT 哪个涨得更快？
  2. 原始 token 吞吐上升时，goodput 一定上升吗？
可调参数：--load（0.2~1.5，服务器繁忙程度）、--n（请求数）、--slo-ttft、--slo-tpot
暴露的问题：吞吐与延迟的取舍、尾延迟 → PROBLEM_BANK P05、P30
对应论文：DistServe（goodput 定义）、Sarathi-Serve（TTFT/TPOT 取舍）
"""
import argparse
import random
import statistics


def percentile(xs, p):
    xs = sorted(xs)
    k = (len(xs) - 1) * p / 100
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def synth_trace(n, load, seed=0):
    """生成合成时间线：每个请求的到达时间和每个输出 token 的产出时刻（秒）。
    简化模型：排队时间随 load 非线性增长（M/M/1 风格 1/(1-rho)），decode 步长随批大小线性增长。"""
    rng = random.Random(seed)
    rho = min(load, 0.97)
    t, trace = 0.0, []
    for _ in range(n):
        t += rng.expovariate(10.0)                     # 平均每秒 10 个请求
        prompt = rng.randint(128, 2048)
        out = rng.randint(16, 512)
        queue = rng.expovariate(1.0) * 0.05 * rho / (1 - rho)   # 排队延迟
        prefill = prompt * 2e-5 * (1 + load)                   # prefill 与 prompt 长度成正比
        step = 0.012 * (1 + 1.5 * load)                        # 批越大，每步 decode 越慢
        first = t + queue + prefill
        toks = [first]
        for _ in range(out - 1):
            # 偶发的 prefill 插队会让某些 decode 步变长（尾延迟的来源之一）
            stall = 0.08 * load if rng.random() < 0.02 * load else 0.0
            toks.append(toks[-1] + step * rng.uniform(0.9, 1.1) + stall)
        trace.append({"arrive": t, "prompt": prompt, "tokens": toks})
    return trace


def metrics(trace, slo_ttft, slo_tpot):
    ttft = [r["tokens"][0] - r["arrive"] for r in trace]
    tpot = [(r["tokens"][-1] - r["tokens"][0]) / max(len(r["tokens"]) - 1, 1) for r in trace]
    span = max(r["tokens"][-1] for r in trace) - min(r["arrive"] for r in trace)
    n_tok = sum(len(r["tokens"]) for r in trace)
    ok = sum(1 for a, b in zip(ttft, tpot) if a <= slo_ttft and b <= slo_tpot)
    return {
        "TTFT p50/p99 (ms)": (percentile(ttft, 50) * 1e3, percentile(ttft, 99) * 1e3),
        "TPOT mean/p99 (ms)": (statistics.mean(tpot) * 1e3, percentile(tpot, 99) * 1e3),
        "吞吐 (output tok/s)": n_tok / span,
        "请求吞吐 (req/s)": len(trace) / span,
        "goodput (满足SLO req/s)": ok / span,
        "SLO 达成率": ok / len(trace),
    }


def mfu(n_params, tokens_per_s, peak_flops, training):
    """MFU = 实际有效 FLOPs / 峰值。训练每 token ≈ 6N FLOPs（前向 2N + 反向 4N），推理 ≈ 2N。"""
    per_tok = (6 if training else 2) * n_params
    return per_tok * tokens_per_s / peak_flops


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=400)
    ap.add_argument("--load", type=float, nargs="+", default=[0.2, 0.6, 0.9, 1.2])
    ap.add_argument("--slo-ttft", type=float, default=0.5, help="秒")
    ap.add_argument("--slo-tpot", type=float, default=0.04, help="秒")
    a = ap.parse_args()

    print("== 不同负载下的服务指标（合成时间线）==")
    for load in a.load:
        m = metrics(synth_trace(a.n, load), a.slo_ttft, a.slo_tpot)
        print(f"\n-- load={load}")
        for k, v in m.items():
            print(f"  {k:24s} " + (f"{v[0]:9.1f} / {v[1]:9.1f}" if isinstance(v, tuple) else f"{v:9.3f}"))

    print("\n== MFU 估算 ==")
    # H100 SXM BF16 稠密峰值约 989 TFLOPS（NVIDIA 官方规格，不含稀疏）
    peak = 989e12
    for name, n, tps, tr in [("7B 训练, 每卡 3000 tok/s", 7e9, 3000, True),
                             ("70B 训练, 每卡 400 tok/s", 70e9, 400, True),
                             ("7B 推理 decode, 每卡 2500 tok/s", 7e9, 2500, False)]:
        print(f"  {name:32s} MFU = {mfu(n, tps, peak, tr) * 100:5.1f}%")
    print("\n[小结] 负载升高时 P99 先于均值恶化；吞吐还在涨时 goodput 可能已经下降。"
          "\n       decode 的 MFU 很低是常态：它受访存限制而不是算力限制（见 M01、M10）。"
          "\n[问题库] P05 prefill/decode 干扰与 TTFT-TPOT 取舍；P30 SLO 感知调度")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m00_overview/outputs/lab_01_serving_metrics.txt`）：

```text
# 实测输出：m00_overview/lab_01_serving_metrics.py
# 运行时间：2026-10-18 21:29，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 不同负载下的服务指标（合成时间线）==

-- load=0.2
  TTFT p50/p99 (ms)             37.1 /      87.4
  TPOT mean/p99 (ms)            15.7 /      16.0
  吞吐 (output tok/s)         2267.009
  请求吞吐 (req/s)                 8.781
  goodput (满足SLO req/s)        8.781
  SLO 达成率                      1.000

-- load=0.6
  TTFT p50/p99 (ms)             89.1 /     354.7
  TPOT mean/p99 (ms)            23.4 /      24.8
  吞吐 (output tok/s)         2099.760
  请求吞吐 (req/s)                 8.133
  goodput (满足SLO req/s)        8.133
  SLO 达成率                      1.000

-- load=0.9
  TTFT p50/p99 (ms)            362.3 /    2022.5
  TPOT mean/p99 (ms)            29.5 /      31.9
  吞吐 (output tok/s)         1978.921
  请求吞吐 (req/s)                 7.665
  goodput (满足SLO req/s)        4.810
  SLO 达成率                      0.627

-- load=1.2
  TTFT p50/p99 (ms)           1201.6 /    7141.3
  TPOT mean/p99 (ms)            35.9 /      39.2
  吞吐 (output tok/s)         1712.969
  请求吞吐 (req/s)                 6.635
  goodput (满足SLO req/s)        1.576
  SLO 达成率                      0.237

== MFU 估算 ==
  7B 训练, 每卡 3000 tok/s             MFU =  12.7%
  70B 训练, 每卡 400 tok/s             MFU =  17.0%
  7B 推理 decode, 每卡 2500 tok/s      MFU =   3.5%

[小结] 负载升高时 P99 先于均值恶化；吞吐还在涨时 goodput 可能已经下降。
       decode 的 MFU 很低是常态：它受访存限制而不是算力限制（见 M01、M10）。
[问题库] P05 prefill/decode 干扰与 TTFT-TPOT 取舍；P30 SLO 感知调度
```

### `labs/m00_overview/lab_02_cost_model.py`

```python
"""[M00-L02] 训练与推理的"信封背面"成本估算

目标：用 6ND 法则估算训练所需 GPU·小时和费用；用吞吐估算推理每百万 token 成本；
      理解 MFU 与批大小对成本的杠杆作用。
先预测：
  1. 把 7B 模型训练 2T token，在 MFU=40% 的 H100 上大约要多少 GPU·小时？
  2. 推理批大小从 1 提到 64，每百万 token 成本大概降多少倍？为什么不会无限下降？
可调参数：--params（参数量）、--tokens（训练 token 数）、--mfu（0.2~0.6）、--gpu-price（$/GPU·h）
暴露的问题：MFU 每提高 1 个百分点都对应真金白银 → PROBLEM_BANK P18、P01
对应论文：MegaScale（MFU 55.2%）、Megatron 3D 并行（SC'21）
"""
import argparse

# 公开规格（NVIDIA 官方数据表；BF16 稠密，不含稀疏加速）
GPUS = {
    "A100-80G": {"flops": 312e12, "hbm_bw": 2.0e12, "mem": 80e9},
    "H100-SXM": {"flops": 989e12, "hbm_bw": 3.35e12, "mem": 80e9},
}


def train_cost(params, tokens, gpu, mfu, price):
    flops = 6 * params * tokens                     # 前向 2N + 反向 4N（每 token）
    gpu_sec = flops / (GPUS[gpu]["flops"] * mfu)
    return flops, gpu_sec / 3600, gpu_sec / 3600 * price


def decode_tokens_per_s(params, batch, gpu, kv_bytes_per_seq):
    """非常粗的 decode 吞吐模型：每步需读一遍全部权重 + 所有序列的 KV；
    每步时间 = max(访存时间, 计算时间)。这是 roofline 思想的直接应用（见 M01、M10）。"""
    g = GPUS[gpu]
    bytes_step = 2 * params + batch * kv_bytes_per_seq   # BF16 权重 2 字节/参数
    flops_step = 2 * params * batch
    t = max(bytes_step / g["hbm_bw"], flops_step / g["flops"])
    return batch / t, bytes_step / g["hbm_bw"] > flops_step / g["flops"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--params", type=float, default=7e9)
    ap.add_argument("--tokens", type=float, default=2e12)
    ap.add_argument("--gpu", default="H100-SXM", choices=GPUS)
    ap.add_argument("--mfu", type=float, nargs="+", default=[0.2, 0.4, 0.55])
    ap.add_argument("--gpu-price", type=float, default=2.5, help="美元/GPU·小时（假设值，可改）")
    a = ap.parse_args()

    print(f"== 训练：{a.params / 1e9:.0f}B 参数 × {a.tokens / 1e12:.1f}T token on {a.gpu} ==")
    for m in a.mfu:
        flops, gh, usd = train_cost(a.params, a.tokens, a.gpu, m, a.gpu_price)
        print(f"  MFU={m:.2f}: 总 FLOPs={flops:.2e}  GPU·h={gh:,.0f}  "
              f"费用≈${usd:,.0f}  (1024 卡需 {gh / 1024 / 24:.1f} 天)")

    # Llama-2-7B 风格（32 层、MHA 32 头×128 维）在 4096 长度下每序列 KV ≈ 2·32·4096·4096·2B = 2.1GB
    kv_per_seq = 2 * 32 * 4096 * 4096 * 2
    print(f"\n== 推理 decode：每序列 KV={kv_per_seq / 1e9:.2f} GB（4096 上下文）==")
    print(f"  {'batch':>5s} {'tok/s':>9s} {'$/1M tok':>9s}  瓶颈        显存是否放得下")
    for b in [1, 4, 16, 32, 64, 128]:
        tps, mem_bound = decode_tokens_per_s(a.params, b, a.gpu, kv_per_seq)
        usd = a.gpu_price / 3600 / tps * 1e6
        fits = 2 * a.params + b * kv_per_seq <= GPUS[a.gpu]["mem"]
        print(f"  {b:5d} {tps:9.0f} {usd:9.3f}  {'访存' if mem_bound else '算力':6s}     {'是' if fits else '否 (OOM)'}")
    print("\n[小结] 训练成本与 MFU 成反比；推理成本随批增大而下降，但很快会被 KV Cache 显存卡住。"
          "\n       这就是 PagedAttention、GQA/MLA、KV 量化等工作的动机（M10~M12）。"
          "\n[问题库] P01 decode 访存受限；P02 KV Cache 是并发上限；P18 训练效率损失")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m00_overview/outputs/lab_02_cost_model.txt`）：

```text
# 实测输出：m00_overview/lab_02_cost_model.py
# 运行时间：2026-10-18 21:29，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 训练：7B 参数 × 2.0T token on H100-SXM ==
  MFU=0.20: 总 FLOPs=8.40e+22  GPU·h=117,964  费用≈$294,911  (1024 卡需 4.8 天)
  MFU=0.40: 总 FLOPs=8.40e+22  GPU·h=58,982  费用≈$147,455  (1024 卡需 2.4 天)
  MFU=0.55: 总 FLOPs=8.40e+22  GPU·h=42,896  费用≈$107,240  (1024 卡需 1.7 天)

== 推理 decode：每序列 KV=2.15 GB（4096 上下文）==
  batch     tok/s  $/1M tok  瓶颈        显存是否放得下
      1       207     3.347  访存         是
      4       593     1.171  访存         是
     16      1108     0.627  访存         是
     32      1296     0.536  访存         否 (OOM)
     64      1416     0.491  访存         否 (OOM)
    128      1484     0.468  访存         否 (OOM)

[小结] 训练成本与 MFU 成反比；推理成本随批增大而下降，但很快会被 KV Cache 显存卡住。
       这就是 PagedAttention、GQA/MLA、KV 量化等工作的动机（M10~M12）。
[问题库] P01 decode 访存受限；P02 KV Cache 是并发上限；P18 训练效率损失
```

## M01 硬件与性能模型：GPU 架构、存储层次、算术强度与 Roofline（`labs/m01_hardware/`）

### `labs/m01_hardware/lab_01_roofline.py`

```python
"""[M01-L01] Roofline：理论分析 + 在本机 CPU 上实测

目标：会计算算子的算术强度（Arithmetic Intensity, AI = FLOPs / 访存字节），
      用 Roofline 判断它在某硬件上是算力受限还是带宽受限；并在本机实测"屋顶"。
先预测：
  1. 4096×4096 的 GEMM 和 batch=1 的 decode GEMV（1×4096 乘 4096×4096），在 H100 上谁是访存受限？
  2. 你的 CPU 上，矩阵越大 GFLOPS 越高还是越低？到哪里饱和？
可调参数：--sizes（实测 GEMM 尺寸）、--copy-mb（带宽测试数据量）、--threads
暴露的问题：decode/逐元素算子天然访存受限 → PROBLEM_BANK P01、P11
对应论文：Roofline（Williams et al., CACM 2009）；Data Movement Is All You Need（MLSys'21）
"""
import argparse
import time

import numpy as np
import torch

HW = {  # 峰值算力（FLOP/s）与带宽（B/s），NVIDIA 官方数据表，BF16 稠密
    "A100": (312e12, 2.0e12),
    "H100": (989e12, 3.35e12),
}


def gemm_ai(m, n, k, bytes_per=2):
    flops = 2 * m * n * k
    traffic = bytes_per * (m * k + k * n + m * n)    # 理想情况：每个矩阵只读/写一次
    return flops, traffic, flops / traffic


def analyze():
    cases = {
        "GEMM 4096^3 (训练/prefill)": gemm_ai(4096, 4096, 4096),
        "GEMM 512x4096x4096 (prefill 512 token)": gemm_ai(512, 4096, 4096),
        "GEMV 1x4096x4096 (decode batch=1)": gemm_ai(1, 4096, 4096),
        "GEMM 32x4096x4096 (decode batch=32)": gemm_ai(32, 4096, 4096),
        # 逐元素：读 1 写 1，每元素 1 FLOP
        "elementwise add 16M": (16e6, 2 * 2 * 16e6, 16e6 / (4 * 16e6)),
    }
    print(f"{'算子':40s} {'AI(FLOP/B)':>10s}  " + "  ".join(f"{h:>18s}" for h in HW))
    for name, (f, t, ai) in cases.items():
        row = []
        for peak, bw in HW.values():
            ridge = peak / bw                      # 屋脊点：AI 超过它才可能算力受限
            attain = min(peak, ai * bw)
            row.append(f"{'算力' if ai >= ridge else '访存'} {attain / peak * 100:5.1f}%峰值")
        print(f"{name:40s} {ai:10.1f}  " + "  ".join(f"{r:>18s}" for r in row))
    for h, (peak, bw) in HW.items():
        print(f"  {h} 屋脊点 = {peak / bw:.0f} FLOP/B")


def bench(fn, reps=5):
    fn()                                           # 预热
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); ts.append(time.perf_counter() - t0)
    return min(ts)


def measure(sizes, copy_mb):
    print("\n== 本机实测：GEMM 吞吐（torch.matmul, fp32）==")
    best = 0
    for n in sizes:
        a, b = torch.randn(n, n), torch.randn(n, n)
        t = bench(lambda: a @ b)
        gf = 2 * n ** 3 / t / 1e9
        best = max(best, gf)
        print(f"  n={n:5d}  {t * 1e3:8.2f} ms  {gf:8.1f} GFLOP/s  AI(fp32)={gemm_ai(n, n, n, 4)[2]:.0f}")
    print("\n== 本机实测：内存带宽（大数组拷贝，读+写）==")
    src = np.ones(int(copy_mb * 2 ** 20 // 8))
    dst = np.empty_like(src)
    t = bench(lambda: np.copyto(dst, src))
    bw = 2 * src.nbytes / t
    print(f"  拷贝 {copy_mb} MB: {bw / 1e9:.1f} GB/s")
    print(f"\n本机屋脊点 ≈ {best * 1e9 / bw:.1f} FLOP/B（峰值 GEMM {best:.0f} GFLOP/s ÷ 带宽 {bw / 1e9:.1f} GB/s）")
    v = torch.randn(4096); W = torch.randn(4096, 4096)
    t = bench(lambda: W @ v)
    print(f"  GEMV 4096x4096: {2 * 4096 * 4096 / t / 1e9:.1f} GFLOP/s，"
          f"有效带宽 {4 * 4096 * 4096 / t / 1e9:.1f} GB/s（权重读取主导）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", type=int, nargs="+", default=[64, 256, 512, 1024, 2048])
    ap.add_argument("--copy-mb", type=int, default=256)
    ap.add_argument("--threads", type=int, default=0, help="0=默认")
    a = ap.parse_args()
    if a.threads:
        torch.set_num_threads(a.threads)
    print(f"torch 线程数 = {torch.get_num_threads()}")
    print("== 理论 Roofline 分析 ==")
    analyze()
    measure(a.sizes, a.copy_mb)
    print("\n[小结] GEMV 的 AI≈1 FLOP/B，远低于任何硬件的屋脊点，所以 decode 阶段算力大量闲置。"
          "\n       把多个请求合批（batch）是提高 AI 的最直接手段（M10、M11）。"
          "\n[问题库] P01 decode 访存受限；P11 小算子开销")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m01_hardware/outputs/lab_01_roofline.txt`）：

```text
# 实测输出：m01_hardware/lab_01_roofline.py
# 运行时间：2026-10-18 21:29，耗时 1.6s，峰值内存 853MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

torch 线程数 = 8
== 理论 Roofline 分析 ==
算子                                       AI(FLOP/B)                A100                H100
GEMM 4096^3 (训练/prefill)                     1365.3         算力 100.0%峰值         算力 100.0%峰值
GEMM 512x4096x4096 (prefill 512 token)        409.6         算力 100.0%峰值         算力 100.0%峰值
GEMV 1x4096x4096 (decode batch=1)               1.0         访存   0.6%峰值         访存   0.3%峰值
GEMM 32x4096x4096 (decode batch=32)            31.5         访存  20.2%峰值         访存  10.7%峰值
elementwise add 16M                             0.2         访存   0.2%峰值         访存   0.1%峰值
  A100 屋脊点 = 156 FLOP/B
  H100 屋脊点 = 295 FLOP/B

== 本机实测：GEMM 吞吐（torch.matmul, fp32）==
  n=   64      0.01 ms      59.5 GFLOP/s  AI(fp32)=11
  n=  256      0.11 ms     313.6 GFLOP/s  AI(fp32)=43
  n=  512      0.74 ms     361.5 GFLOP/s  AI(fp32)=85
  n= 1024      3.95 ms     543.1 GFLOP/s  AI(fp32)=171
  n= 2048     31.69 ms     542.2 GFLOP/s  AI(fp32)=341

== 本机实测：内存带宽（大数组拷贝，读+写）==
  拷贝 256 MB: 51.1 GB/s

本机屋脊点 ≈ 10.6 FLOP/B（峰值 GEMM 543 GFLOP/s ÷ 带宽 51.1 GB/s）
  GEMV 4096x4096: 53.8 GFLOP/s，有效带宽 107.5 GB/s（权重读取主导）

[小结] GEMV 的 AI≈1 FLOP/B，远低于任何硬件的屋脊点，所以 decode 阶段算力大量闲置。
       把多个请求合批（batch）是提高 AI 的最直接手段（M10、M11）。
[问题库] P01 decode 访存受限；P11 小算子开销
```

### `labs/m01_hardware/lab_02_memory_hierarchy.py`

```python
"""[M01-L02] 存储层次：工作集大小与访问模式如何决定有效带宽

目标：观察缓存层次（L1/L2/L3/DRAM）对带宽的影响，以及顺序访问与跨步访问的差异。
      GPU 上的 SRAM(shared memory)/L2/HBM 层次与之同理，FlashAttention 正是利用这一点。
先预测：
  1. 工作集从 16KB 增到 1GB，求和带宽会怎样变化？拐点大致在哪？
  2. 步长（stride）从 1 增到 16（每次跳过若干 float64），有效带宽下降多少？为什么？
可调参数：--max-mb、--strides、--reps
暴露的问题：数据搬运而非计算往往才是瓶颈 → PROBLEM_BANK P01、P12
对应论文：FlashAttention（IO 感知）；Data Movement Is All You Need
"""
import argparse
import time

import numpy as np


def bandwidth(arr, reps):
    arr.sum()                                       # 预热，载入缓存
    t0 = time.perf_counter()
    for _ in range(reps):
        arr.sum()
    dt = (time.perf_counter() - t0) / reps
    return arr.nbytes / dt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-mb", type=int, default=512)
    ap.add_argument("--strides", type=int, nargs="+", default=[1, 2, 4, 8, 16])
    ap.add_argument("--reps", type=int, default=0, help="0=自动")
    a = ap.parse_args()

    print("== 工作集大小 vs 求和带宽（顺序读）==")
    kb = 16
    while kb <= a.max_mb * 1024:
        n = kb * 1024 // 8
        arr = np.ones(n)
        reps = a.reps or max(3, int(2e8 // arr.nbytes))   # 小数组多重复几次，减少计时噪声
        bw = bandwidth(arr, reps)
        bar = "#" * int(bw / 2e9)
        print(f"  {kb / 1024:9.3f} MB  {bw / 1e9:7.1f} GB/s  {bar[:60]}")
        kb *= 4

    print("\n== 跨步访问（总读取元素数相同）==")
    base = np.ones(16 * 2 ** 20)                    # 128MB，远大于缓存
    n_read = len(base) // max(a.strides)
    for s in a.strides:
        view = base[: n_read * s : s]               # 读取 n_read 个元素，间隔 s
        t0 = time.perf_counter()
        for _ in range(5):
            view.sum()
        dt = (time.perf_counter() - t0) / 5
        useful = n_read * 8 / dt
        print(f"  stride={s:3d}: 有效带宽 {useful / 1e9:6.1f} GB/s"
              f"（每 64B 缓存行只用到 {min(8, max(1, 8 // s))}/8 个元素）")
    print("\n[小结] 工作集超出缓存后带宽骤降；跨步访问浪费缓存行。GPU 上对应的是"
          "\n       合并访存（coalescing）和分块（tiling）：让数据在片上 SRAM 里被反复使用。"
          "\n[问题库] P01 访存受限；P12 算子融合与数据复用")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m01_hardware/outputs/lab_02_memory_hierarchy.txt`）：

```text
# 实测输出：m01_hardware/lab_02_memory_hierarchy.py
# 运行时间：2026-10-18 21:29，耗时 0.3s，峰值内存 411MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 工作集大小 vs 求和带宽（顺序读）==
      0.016 MB     27.1 GB/s  #############
      0.062 MB     42.2 GB/s  #####################
      0.250 MB     53.1 GB/s  ##########################
      1.000 MB     54.4 GB/s  ###########################
      4.000 MB     52.5 GB/s  ##########################
     16.000 MB     30.2 GB/s  ###############
     64.000 MB     25.3 GB/s  ############
    256.000 MB     24.6 GB/s  ############

== 跨步访问（总读取元素数相同）==
  stride=  1: 有效带宽   33.2 GB/s（每 64B 缓存行只用到 8/8 个元素）
  stride=  2: 有效带宽   25.2 GB/s（每 64B 缓存行只用到 4/8 个元素）
  stride=  4: 有效带宽   10.2 GB/s（每 64B 缓存行只用到 2/8 个元素）
  stride=  8: 有效带宽    4.5 GB/s（每 64B 缓存行只用到 1/8 个元素）
  stride= 16: 有效带宽    2.3 GB/s（每 64B 缓存行只用到 1/8 个元素）

[小结] 工作集超出缓存后带宽骤降；跨步访问浪费缓存行。GPU 上对应的是
       合并访存（coalescing）和分块（tiling）：让数据在片上 SRAM 里被反复使用。
[问题库] P01 访存受限；P12 算子融合与数据复用
```

## M02 PyTorch 运行时：张量与存储、autograd、算子分发、异步执行、profiler（`labs/m02_pytorch_runtime/`）

### `labs/m02_pytorch_runtime/lab_01_tensor_storage.py`

```python
"""[M02-L01] 张量 = 存储(Storage) + 视图元数据(shape/stride/offset)

目标：理解 view / transpose / contiguous 的本质，知道何时会发生隐式拷贝；
      观察"框架开销区"：张量很小时，耗时由算子分发而非计算决定。
先预测：
  1. x.t() 之后 is_contiguous() 是什么？x.t().contiguous() 会不会分配新内存？
  2. 对 10 个元素做 add 和对 1000 万个元素做 add，单次耗时差多少倍？为什么不是 100 万倍？
可调参数：--sizes（开销测试的张量大小）、--reps
暴露的问题：小算子被框架开销主导（overhead-bound） → PROBLEM_BANK P11
对应论文：PyTorch（NeurIPS'19）；Making Deep Learning Go Brrrr（Horace He 博客，二手来源）
真实框架对照：PyTorch c10/core/TensorImpl.h（sizes/strides/storage_offset 字段），
              aten/src/ATen/native/TensorShape.cpp（view/transpose 的实现）
"""
import argparse
import time

import torch


def describe(name, t):
    print(f"  {name:22s} shape={tuple(t.shape)!s:12s} stride={t.stride()!s:10s} "
          f"offset={t.storage_offset():2d} contiguous={t.is_contiguous()!s:5s} "
          f"data_ptr={t.untyped_storage().data_ptr() % 100000:5d}")


def storage_demo():
    print("== 视图共享存储 ==")
    x = torch.arange(12, dtype=torch.float32).reshape(3, 4)
    describe("x", x)
    describe("x.t()", x.t())
    describe("x[1:, ::2]", x[1:, ::2])
    describe("x.t().contiguous()", x.t().contiguous())
    y = x.view(4, 3)
    y[0, 0] = 100.0
    print(f"  改 y[0,0] 后 x[0,0] = {x[0, 0].item()}（共享存储，所以被改了）")
    try:
        x.t().view(12)
    except RuntimeError as e:
        print(f"  x.t().view(12) 报错：{str(e)[:70]}...")
    print("  x.t().reshape(12) 可以：reshape 在需要时会自动拷贝")


def overhead_demo(sizes, reps):
    print("\n== 框架开销 vs 计算：单次 add 耗时 ==")
    print(f"  {'元素数':>10s} {'单次(us)':>10s} {'ns/元素':>10s}  判断")
    floor = None
    for n in sizes:
        a, b = torch.randn(n), torch.randn(n)
        for _ in range(10):
            a + b
        t0 = time.perf_counter()
        for _ in range(reps):
            a + b
        dt = (time.perf_counter() - t0) / reps
        floor = floor or dt                          # 最小张量的耗时 ≈ 固定开销
        regime = "开销主导" if dt < 2 * floor else ("过渡（数据仍在缓存）" if n * 12 < 32 * 2 ** 20 else "带宽主导")
        print(f"  {n:10d} {dt * 1e6:10.2f} {dt / n * 1e9:10.3f}  {regime}")


def copy_cost_demo():
    print("\n== 非连续张量的隐式拷贝代价 ==")
    x = torch.randn(4096, 4096)
    for name, fn in [("x.contiguous()（已连续，无拷贝）", lambda: x.contiguous()),
                     ("x.t().contiguous()（转置后拷贝）", lambda: x.t().contiguous()),
                     ("x.t() @ v（matmul 可直接处理转置）", lambda: x.t() @ torch.ones(4096))]:
        fn()
        t0 = time.perf_counter()
        for _ in range(5):
            fn()
        print(f"  {name:40s} {(time.perf_counter() - t0) / 5 * 1e3:8.2f} ms")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", type=int, nargs="+", default=[10, 1000, 100_000, 10_000_000])
    ap.add_argument("--reps", type=int, default=200)
    a = ap.parse_args()
    storage_demo()
    overhead_demo(a.sizes, a.reps)
    copy_cost_demo()
    print("\n[小结] 小张量的耗时几乎与大小无关，说明时间花在 Python→C++ 分发、类型推导、"
          "\n       内存分配上。GPU 上还要加上 kernel launch（约数 us）。CUDA Graphs、算子融合、"
          "\n       torch.compile 都是在消除这类开销。"
          "\n[问题库] P11 框架/launch 开销导致 GPU 空闲")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m02_pytorch_runtime/outputs/lab_01_tensor_storage.txt`）：

```text
# 实测输出：m02_pytorch_runtime/lab_01_tensor_storage.py
# 运行时间：2026-10-18 21:29，耗时 2.1s，峰值内存 358MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 视图共享存储 ==
  x                      shape=(3, 4)       stride=(4, 1)     offset= 0 contiguous=True  data_ptr=60736
  x.t()                  shape=(4, 3)       stride=(1, 4)     offset= 0 contiguous=False data_ptr=60736
  x[1:, ::2]             shape=(2, 2)       stride=(4, 2)     offset= 4 contiguous=False data_ptr=60736
  x.t().contiguous()     shape=(4, 3)       stride=(3, 1)     offset= 0 contiguous=True  data_ptr=98368
  改 y[0,0] 后 x[0,0] = 100.0（共享存储，所以被改了）
  x.t().view(12) 报错：view size is not compatible with input tensor's size and stride (at le...
  x.t().reshape(12) 可以：reshape 在需要时会自动拷贝

== 框架开销 vs 计算：单次 add 耗时 ==
         元素数     单次(us)      ns/元素  判断
          10       0.87     87.017  开销主导
        1000       0.80      0.797  开销主导
      100000       6.40      0.064  过渡（数据仍在缓存）
    10000000    3817.16      0.382  带宽主导

== 非连续张量的隐式拷贝代价 ==
  x.contiguous()（已连续，无拷贝）                      0.00 ms
  x.t().contiguous()（转置后拷贝）                   28.25 ms
  x.t() @ v（matmul 可直接处理转置）                    1.05 ms

[小结] 小张量的耗时几乎与大小无关，说明时间花在 Python→C++ 分发、类型推导、
       内存分配上。GPU 上还要加上 kernel launch（约数 us）。CUDA Graphs、算子融合、
       torch.compile 都是在消除这类开销。
[问题库] P11 框架/launch 开销导致 GPU 空闲
```

### `labs/m02_pytorch_runtime/lab_02_mini_autograd.py`

```python
"""[M02-L02] 100 行实现反向模式自动微分（reverse-mode autograd），并与 torch.autograd 对照

目标：理解计算图、拓扑排序、反向传播和"为反向保存的激活值"（saved tensors）——
      后者正是训练显存的主要来源之一（M04）。
先预测：
  1. 前向计算 y = relu(x @ W1) @ W2，反向需要保存哪些中间张量？
  2. 如果前向用 torch.no_grad()，显存会少掉哪些部分？
可调参数：--batch、--hidden、--steps
暴露的问题：激活值必须保存到反向 → 显存墙 → PROBLEM_BANK P14
对应论文：PyTorch（NeurIPS'19）；CMU 10-414 DLSys 课程 needle 框架（作业形式）
真实框架对照：torch/csrc/autograd/engine.cpp（反向执行引擎）、torch/autograd/function.py
"""
import argparse

import numpy as np
import torch


class T:
    """最小张量：保存值、梯度、父节点和本地反向函数。"""

    def __init__(self, data, parents=(), backward=None, name=""):
        self.data, self.grad = np.asarray(data, dtype=np.float64), None
        self.parents, self._backward, self.name = parents, backward, name

    def __matmul__(self, o):
        out = T(self.data @ o.data, (self, o), name="matmul")
        # 反向需要两个输入 -> 它们被"保存"下来（显存开销）
        out._backward = lambda g: (g @ o.data.T, self.data.T @ g)
        return out

    def relu(self):
        mask = self.data > 0
        out = T(self.data * mask, (self,), name="relu")
        out._backward = lambda g: (g * mask,)            # 只需保存 mask
        return out

    def mse(self, target):
        diff = self.data - target
        out = T((diff ** 2).mean(), (self,), name="mse")
        out._backward = lambda g: (g * 2 * diff / diff.size,)
        return out

    def backward(self):
        order, seen = [], set()

        def topo(v):                                       # DFS 拓扑排序
            if id(v) not in seen:
                seen.add(id(v))
                for p in v.parents:
                    topo(p)
                order.append(v)
        topo(self)
        self.grad = np.ones_like(self.data)
        for v in reversed(order):
            if v._backward is None:
                continue
            for p, g in zip(v.parents, v._backward(v.grad)):
                p.grad = g if p.grad is None else p.grad + g


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--steps", type=int, default=50)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    X = rng.normal(size=(a.batch, 16)); Y = rng.normal(size=(a.batch, 1))
    W1 = rng.normal(size=(16, a.hidden)) * 0.3; W2 = rng.normal(size=(a.hidden, 1)) * 0.3

    # 1) 梯度正确性：和 torch 对照
    w1, w2 = T(W1, name="W1"), T(W2, name="W2")
    loss = (T(X) @ w1).relu().__matmul__(w2).mse(Y)
    loss.backward()
    tw1 = torch.tensor(W1, requires_grad=True); tw2 = torch.tensor(W2, requires_grad=True)
    tl = ((torch.relu(torch.tensor(X) @ tw1) @ tw2 - torch.tensor(Y)) ** 2).mean()
    tl.backward()
    print("== 与 torch.autograd 对照 ==")
    print(f"  loss: mini={loss.data:.6f} torch={tl.item():.6f}")
    print(f"  max|dW1 差| = {np.abs(w1.grad - tw1.grad.numpy()).max():.2e}")
    print(f"  max|dW2 差| = {np.abs(w2.grad - tw2.grad.numpy()).max():.2e}")

    # 2) 观察 torch 为反向保存了什么
    print("\n== torch 为反向保存的张量（saved_tensors_hooks）==")
    saved = []
    with torch.autograd.graph.saved_tensors_hooks(lambda t: saved.append(t) or t, lambda t: t):
        h = torch.relu(torch.tensor(X) @ tw1)
        out = ((h @ tw2 - torch.tensor(Y)) ** 2).mean()
    for t in saved:
        print(f"  shape={tuple(t.shape)!s:10s} dtype={t.dtype} bytes={t.numel() * t.element_size()}")
    print(f"  合计 {sum(t.numel() * t.element_size() for t in saved)} 字节；参数本身 "
          f"{(W1.size + W2.size) * 8} 字节")

    # 3) 用 mini autograd 训练几步
    print("\n== 用 mini autograd 训练 ==")
    for s in range(a.steps):
        w1, w2 = T(W1), T(W2)
        loss = (T(X) @ w1).relu().__matmul__(w2).mse(Y)
        loss.backward()
        W1 -= 0.05 * w1.grad; W2 -= 0.05 * w2.grad
        if s % max(1, a.steps // 5) == 0 or s == a.steps - 1:
            print(f"  step {s:3d} loss={loss.data:.4f}")
    print("\n[小结] 反向传播要用到前向的中间结果，所以训练显存≈参数+梯度+优化器状态+激活值。"
          "\n       激活值随 batch×seq 线性增长，是激活重计算（M04-L03）的动机。"
          "\n[问题库] P14 训练显存墙")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m02_pytorch_runtime/outputs/lab_02_mini_autograd.txt`）：

```text
# 实测输出：m02_pytorch_runtime/lab_02_mini_autograd.py
# 运行时间：2026-10-18 21:29，耗时 1.0s，峰值内存 235MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 与 torch.autograd 对照 ==
  loss: mini=3.204288 torch=3.204288
  max|dW1 差| = 2.71e-16
  max|dW2 差| = 4.44e-16

== torch 为反向保存的张量（saved_tensors_hooks）==
  shape=(32, 16)   dtype=torch.float64 bytes=4096
  shape=(32, 64)   dtype=torch.float64 bytes=16384
  shape=(64, 1)    dtype=torch.float64 bytes=512
  shape=(32, 64)   dtype=torch.float64 bytes=16384
  shape=(32, 1)    dtype=torch.float64 bytes=256
  合计 37632 字节；参数本身 8704 字节

== 用 mini autograd 训练 ==
  step   0 loss=3.2043
  step  10 loss=1.8821
  step  20 loss=0.2674
  step  30 loss=0.0311
  step  40 loss=0.0109
  step  49 loss=0.0050

[小结] 反向传播要用到前向的中间结果，所以训练显存≈参数+梯度+优化器状态+激活值。
       激活值随 batch×seq 线性增长，是激活重计算（M04-L03）的动机。
[问题库] P14 训练显存墙
```

### `labs/m02_pytorch_runtime/lab_03_profiler.py`

```python
"""[M02-L03] 用 torch.profiler 找出时间花在哪

目标：学会读 profiler 表格（Self CPU、CPU total、调用次数），区分"算子多而小"和"算子少而大"；
      理解异步执行：GPU 上 Python 返回 ≠ kernel 完成（CPU 上用线程数实验类比）。
先预测：
  1. 一个由 200 个小 Linear 串起来的网络和一个等 FLOPs 的大 Linear，谁更快？
  2. profiler 表里，哪个算子的 Self CPU 时间最高？
可调参数：--depth、--width、--batch
暴露的问题：小算子/框架开销；需要 profiler 才能定位 → PROBLEM_BANK P11、P29
对应论文：PyTorch 2（ASPLOS'24，动机部分讨论了 eager 模式开销）
真实框架对照：torch/profiler/profiler.py；GPU 上用 Nsight Systems（nsys）看 CUDA stream 时间线
"""
import argparse
import time

import torch
import torch.nn as nn
from torch.profiler import ProfilerActivity, profile


def timeit(fn, reps=20):
    for _ in range(3):
        fn()
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    return (time.perf_counter() - t0) / reps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--depth", type=int, default=200)
    ap.add_argument("--width", type=int, default=64)
    ap.add_argument("--batch", type=int, default=32)
    a = ap.parse_args()
    torch.manual_seed(0)

    deep = nn.Sequential(*[nn.Sequential(nn.Linear(a.width, a.width), nn.GELU()) for _ in range(a.depth)])
    # 等 FLOPs 的宽网络：depth*w^2 = W^2 -> W = w*sqrt(depth)
    W = int(a.width * a.depth ** 0.5)
    wide = nn.Sequential(nn.Linear(W, W), nn.GELU())
    x_deep, x_wide = torch.randn(a.batch, a.width), torch.randn(a.batch, W)
    flops_deep = 2 * a.batch * a.width ** 2 * a.depth
    flops_wide = 2 * a.batch * W * W

    with torch.no_grad():
        td, tw = timeit(lambda: deep(x_deep)), timeit(lambda: wide(x_wide))
    print("== 等 FLOPs 的深窄网络 vs 浅宽网络（推理）==")
    print(f"  深窄 {a.depth}×Linear({a.width}): {td * 1e3:7.2f} ms  {flops_deep / td / 1e9:7.1f} GFLOP/s  "
          f"算子数≈{2 * a.depth}")
    print(f"  浅宽 1×Linear({W}):        {tw * 1e3:7.2f} ms  {flops_wide / tw / 1e9:7.1f} GFLOP/s  算子数=2")
    print(f"  每个小算子平均 {td / (2 * a.depth) * 1e6:.1f} us")

    print("\n== profiler：深窄网络前向+反向 ==")
    deep.zero_grad()
    with profile(activities=[ProfilerActivity.CPU], record_shapes=False) as prof:
        deep(x_deep).sum().backward()
    print(prof.key_averages().table(sort_by="self_cpu_time_total", row_limit=8, max_name_column_width=30))

    print("== 线程数的影响（CPU 并行度 ≈ GPU 的 SM 占用）==")
    big = torch.randn(1024, 1024)
    for n in [1, 2, 4, torch.get_num_threads()]:
        torch.set_num_threads(n)
        t = timeit(lambda: big @ big, reps=5)
        print(f"  threads={n:2d}: matmul 1024^3 {t * 1e3:7.2f} ms")
    print("\n[小结] 同样的 FLOPs，拆成很多小算子会慢很多：每个算子都有固定的分发/启动开销，"
          "\n       而且小矩阵乘喂不饱硬件。profiler 的 Self CPU 列告诉你开销在哪。"
          "\n[问题库] P11 框架开销；P29 benchmark 方法学")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m02_pytorch_runtime/outputs/lab_03_profiler.txt`）：

```text
# 实测输出：m02_pytorch_runtime/lab_03_profiler.py
# 运行时间：2026-10-18 21:29，耗时 4.8s，峰值内存 379MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

USDT:2026-10-18 21:29:35 615:615 SyncActivityProfilerHandler.cpp:39] profiler_start
USDT:2026-10-18 21:29:35 615:615 SyncActivityProfilerHandler.cpp:46] profiler_stop
== 等 FLOPs 的深窄网络 vs 浅宽网络（推理）==
  深窄 200×Linear(64):    4.35 ms     12.1 GFLOP/s  算子数≈400
  浅宽 1×Linear(905):           0.16 ms    335.8 GFLOP/s  算子数=2
  每个小算子平均 10.9 us

== profiler：深窄网络前向+反向 ==
------------------------------  ------------  ------------  ------------  ------------  ------------  ------------  
                          Name    Self CPU %      Self CPU   CPU total %     CPU total  CPU time avg    # of Calls  
------------------------------  ------------  ------------  ------------  ------------  ------------  ------------  
                   aten::addmm        28.98%      13.804ms        29.92%      14.250ms      71.250us           200  
                    aten::gelu        25.10%      11.954ms        25.10%      11.954ms      59.771us           200  
                      aten::mm        24.57%      11.701ms        24.69%      11.758ms      29.470us           399  
           aten::gelu_backward         8.96%       4.269ms         8.96%       4.269ms      21.345us           200  
                       aten::t         1.85%     883.376us         3.41%       1.623ms       1.625us           999  
autograd::engine::evaluate_...         1.49%     709.588us        30.46%      14.507ms      72.534us           200  
                AddmmBackward0         1.29%     615.326us        27.71%      13.198ms      65.992us           200  
                     aten::sum         1.11%     528.337us         1.34%     638.476us       3.176us           201  
------------------------------  ------------  ------------  ------------  ------------  ------------  ------------  
Self CPU time total: 47.634ms

== 线程数的影响（CPU 并行度 ≈ GPU 的 SM 占用）==
  threads= 1: matmul 1024^3   15.93 ms
  threads= 2: matmul 1024^3    8.18 ms
  threads= 4: matmul 1024^3    4.34 ms
  threads= 8: matmul 1024^3    5.06 ms

[小结] 同样的 FLOPs，拆成很多小算子会慢很多：每个算子都有固定的分发/启动开销，
       而且小矩阵乘喂不饱硬件。profiler 的 Self CPU 列告诉你开销在哪。
[问题库] P11 框架开销；P29 benchmark 方法学
```

## M03 算子与 Kernel：矩阵乘分块、算子融合、Triton 入门、FlashAttention 的 IO 感知（`labs/m03_kernels/`）

### `labs/m03_kernels/lab_01_tiled_matmul.py`

```python
"""[M03-L01] 矩阵乘分块（tiling）：为什么分块能把访存降一个数量级

目标：用"片上缓存可容纳 M 个元素"的抽象模型，计算朴素/分块矩阵乘从慢速内存（HBM/DRAM）
      搬运的数据量，理解 tile 大小与算术强度的关系；再实测 numpy 分块实现验证正确性。
先预测：
  1. N=1024 时朴素三重循环（无缓存复用）要从慢速内存读多少元素？分块 T=64 时呢？
  2. tile 翻倍，访存量怎么变？tile 能无限大吗？受什么限制？
可调参数：--n、--tiles、--sram-kb（片上存储容量，H100 每个 SM 共享内存最多 228KB）
暴露的问题：kernel 性能取决于数据复用；tile 选择是调优问题 → PROBLEM_BANK P13
对应论文：Triton（MAPL'19，以 block 为编程单位）；TVM / Ansor（自动搜索 tile）
真实框架对照：NVIDIA/cutlass include/cutlass/gemm/ 的 threadblock tile 配置；
              Triton 官方教程 03-matrix-multiplication.py
"""
import argparse
import time

import numpy as np


def traffic_naive(n):
    # C[i,j] = sum_k A[i,k]B[k,j]：每个 C 元素读 A 的一行 + B 的一列，没有复用
    return 2 * n ** 3 + n * n


def traffic_tiled(n, t):
    # C 按 t×t 分块；每个 C 块需要读 (n/t) 个 A 块 + (n/t) 个 B 块，每块 t^2 元素
    blocks = (n // t) ** 2
    return blocks * (2 * (n // t) * t * t) + n * n   # = 2n^3/t + n^2


def tiled_matmul(A, B, t):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=A.dtype)
    for i in range(0, n, t):
        for j in range(0, n, t):
            acc = np.zeros((t, t), dtype=A.dtype)       # 对应寄存器/共享内存里的累加器
            for k in range(0, n, t):
                acc += A[i:i + t, k:k + t] @ B[k:k + t, j:j + t]   # 两个 tile 在"片上"相乘
            C[i:i + t, j:j + t] = acc
    return C


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1024)
    ap.add_argument("--tiles", type=int, nargs="+", default=[8, 16, 32, 64, 128, 256])
    ap.add_argument("--sram-kb", type=int, default=228)
    a = ap.parse_args()
    n = a.n
    flops = 2 * n ** 3
    print(f"== 访存模型（N={n}，fp16 每元素 2 字节，片上容量 {a.sram_kb}KB）==")
    base = traffic_naive(n)
    print(f"  朴素：读写 {base:.3e} 元素，AI = {flops / (2 * base):6.2f} FLOP/B")
    for t in a.tiles:
        tr = traffic_tiled(n, t)
        need_kb = 3 * t * t * 2 / 1024                  # A、B、C 三个 tile 同时在片上
        ok = "放得下" if need_kb <= a.sram_kb else "放不下!"
        print(f"  T={t:4d}：读写 {tr:.3e} 元素（{base / tr:6.1f}× 更少），"
              f"AI = {flops / (2 * tr):7.1f} FLOP/B，片上需 {need_kb:7.1f}KB {ok}")

    print("\n== numpy 分块实现：正确性与耗时（python 循环有开销，仅用于理解）==")
    m = 512
    A = np.random.default_rng(0).standard_normal((m, m)).astype(np.float32)
    B = np.random.default_rng(1).standard_normal((m, m)).astype(np.float32)
    ref = A @ B
    for t in [16, 64, 128, 512]:
        t0 = time.perf_counter()
        C = tiled_matmul(A, B, t)
        dt = time.perf_counter() - t0
        print(f"  T={t:4d}: {dt * 1e3:8.1f} ms  max误差={np.abs(C - ref).max():.2e}  "
              f"python 循环次数={(m // t) ** 3}")
    print("\n[小结] 访存量 ≈ 2N³/T：tile 越大复用越多，但受片上存储容量、寄存器数和并行度限制。"
          "\n       numpy 版里 T 太小时被 Python 循环开销拖慢——对应 GPU 上 tile 太小导致 launch/调度开销。"
          "\n[问题库] P13 自动调优与可移植性；P12 数据复用")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m03_kernels/outputs/lab_01_tiled_matmul.txt`）：

```text
# 实测输出：m03_kernels/lab_01_tiled_matmul.py
# 运行时间：2026-10-18 21:29，耗时 0.3s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 访存模型（N=1024，fp16 每元素 2 字节，片上容量 228KB）==
  朴素：读写 2.149e+09 元素，AI =   0.50 FLOP/B
  T=   8：读写 2.695e+08 元素（   8.0× 更少），AI =     4.0 FLOP/B，片上需     0.4KB 放得下
  T=  16：读写 1.353e+08 元素（  15.9× 更少），AI =     7.9 FLOP/B，片上需     1.5KB 放得下
  T=  32：读写 6.816e+07 元素（  31.5× 更少），AI =    15.8 FLOP/B，片上需     6.0KB 放得下
  T=  64：读写 3.460e+07 元素（  62.1× 更少），AI =    31.0 FLOP/B，片上需    24.0KB 放得下
  T= 128：读写 1.783e+07 元素（ 120.5× 更少），AI =    60.2 FLOP/B，片上需    96.0KB 放得下
  T= 256：读写 9.437e+06 元素（ 227.7× 更少），AI =   113.8 FLOP/B，片上需   384.0KB 放不下!

== numpy 分块实现：正确性与耗时（python 循环有开销，仅用于理解）==
  T=  16:     79.9 ms  max误差=5.34e-05  python 循环次数=32768
  T=  64:      3.6 ms  max误差=5.34e-05  python 循环次数=512
  T= 128:      1.8 ms  max误差=4.58e-05  python 循环次数=64
  T= 512:      0.9 ms  max误差=0.00e+00  python 循环次数=1

[小结] 访存量 ≈ 2N³/T：tile 越大复用越多，但受片上存储容量、寄存器数和并行度限制。
       numpy 版里 T 太小时被 Python 循环开销拖慢——对应 GPU 上 tile 太小导致 launch/调度开销。
[问题库] P13 自动调优与可移植性；P12 数据复用
```

### `labs/m03_kernels/lab_02_operator_fusion.py`

```python
"""[M03-L02] 算子融合（operator fusion）：省掉中间结果的读写

目标：对比 bias+GELU+残差+缩放 这一串逐元素算子在"每步单独执行"和"融合为一次遍历"时的
      访存量与耗时；理解为什么逐元素算子融合几乎总是划算的。
先预测：
  1. 5 个逐元素算子串联，未融合时读写了多少次整张量？融合后呢？
  2. 实测加速比会接近理论访存比吗？为什么可能达不到？
可调参数：--rows、--cols、--reps
暴露的问题：融合机会需要编译器发现；动态形状/图断裂会阻止融合 → PROBLEM_BANK P12
对应论文：PyTorch 2（TorchInductor 自动融合）；TVM（算子融合规则）；FlashAttention（极致融合）
真实框架对照：torch/_inductor/scheduler.py（融合决策）；Liger-Kernel 中手写的融合 Triton kernel
说明：本机没有 C 编译器，torch.compile/Triton 无法在 CPU 上生成真正的融合 kernel。因此用两种方式量化：
  (a) 逐算子计时，看每个算子的耗时是否与其读写量成正比；
  (b) 实测"读 2 张量写 1 张量"的单遍遍历耗时，作为理想融合 kernel 的下界（融合 kernel 也只需这一遍）。
  另外给出"框架层面按块拼凑"的版本作为反例：它并不能带来融合收益。
"""
import argparse
import time

import torch


def unfused(x, b, r):
    y = x + b                       # 读 x,b 写 y
    y = torch.nn.functional.gelu(y)  # 读 y 写 y'
    y = y + r                       # 读 y',r 写 y''
    y = y * 0.5                     # 读写
    return y.clamp_(-10, 10)        # 读写（原地）


def fused_blocked(x, b, r, block=4096):
    """模拟融合 kernel：按行块处理，块足够小能留在缓存里，每个元素只从 DRAM 读/写一次。"""
    out = torch.empty_like(x)
    rows = max(1, block // x.shape[1])          # 每块包含的行数
    for i in range(0, x.shape[0], rows):
        sl = slice(i, i + rows)
        y = x[sl] + b
        y = torch.nn.functional.gelu(y)
        y.add_(r[sl]).mul_(0.5).clamp_(-10, 10)
        out[sl] = y
    return out


def timeit(fn, reps):
    fn()
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    return (time.perf_counter() - t0) / reps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=8192)
    ap.add_argument("--cols", type=int, default=4096)
    ap.add_argument("--reps", type=int, default=5)
    a = ap.parse_args()
    torch.manual_seed(0)
    x = torch.randn(a.rows, a.cols); r = torch.randn(a.rows, a.cols); b = torch.randn(a.cols)
    nbytes = x.numel() * 4

    # 理论访存（以"整张量读或写一次"为单位）
    unfused_io = 2 + 2 + 3 + 2 + 2          # 每步读写次数之和（bias 很小忽略）
    fused_io = 3                            # 读 x、读 r、写 out
    print(f"== 理论访存：张量 {nbytes / 2 ** 20:.0f} MB ==")
    print(f"  未融合：约 {unfused_io} 次整张量读写 = {unfused_io * nbytes / 2 ** 30:.2f} GB")
    print(f"  融合：  约 {fused_io} 次整张量读写 = {fused_io * nbytes / 2 ** 30:.2f} GB"
          f"（理论上限加速 {unfused_io / fused_io:.1f}×）")

    ref = unfused(x, b, r)
    out = fused_blocked(x, b, r, block=64 * 1024)
    print(f"\n  结果一致性 max|差| = {(ref - out).abs().max().item():.2e}")
    print("\n== (a) 逐算子计时 ==")
    y = x + b
    ops = [("x + b        (读2写1)", lambda: x + b),
           ("gelu(y)      (读1写1)", lambda: torch.nn.functional.gelu(y)),
           ("y + r        (读2写1)", lambda: y + r),
           ("y * 0.5      (读1写1)", lambda: y * 0.5),
           ("clamp_       (读1写1)", lambda: y.clamp_(-10, 10))]
    for name, fn in ops:
        t = timeit(fn, a.reps)
        print(f"  {name} {t * 1e3:7.1f} ms")
    t_u = timeit(lambda: unfused(x, b, r), a.reps)
    print(f"  整串未融合            {t_u * 1e3:7.1f} ms  有效带宽 {unfused_io * nbytes / t_u / 1e9:6.1f} GB/s")

    print("\n== (b) 理想融合 kernel 的下界：单遍 读 x、r 写 out ==")
    buf = torch.empty_like(x)
    t_1 = timeit(lambda: torch.add(x, r, out=buf), a.reps)
    print(f"  单遍遍历 {t_1 * 1e3:7.1f} ms → 融合后最多可快 {t_u / t_1:4.2f}×（若 GELU 计算不成为新瓶颈）")

    print("\n== 反例：框架层面按块拼凑（每块内仍是多个独立算子）==")
    for blk in [16 * 1024, 4 * 1024 * 1024]:
        t_f = timeit(lambda: fused_blocked(x, b, r, block=blk), a.reps)
        print(f"  block={blk // 1024:5d}K元素 {t_f * 1e3:7.1f} ms  相对未融合 {t_u / t_f:4.2f}×")
    print("\n[小结] 逐元素算子受访存限制，耗时大致正比于读写遍数；真正的融合必须发生在单个 kernel"
          "\n       内部（数据留在寄存器里），在 Python/框架层面切块拼凑得不到收益，块小时反而被开销拖慢。"
          "\n       这正是 TorchInductor/XLA/TVM 自动生成融合 kernel 的价值。GELU 在 CPU 上计算较重，"
          "\n       说明'访存受限'的判断要结合具体硬件（GPU 上它仍是访存受限）。"
          "\n[问题库] P12 融合机会与编译器自动化的边界")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m03_kernels/outputs/lab_02_operator_fusion.txt`）：

```text
# 实测输出：m03_kernels/lab_02_operator_fusion.py
# 运行时间：2026-10-18 21:29，耗时 3.1s，峰值内存 1191MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 理论访存：张量 128 MB ==
  未融合：约 11 次整张量读写 = 1.38 GB
  融合：  约 3 次整张量读写 = 0.38 GB（理论上限加速 3.7×）

  结果一致性 max|差| = 0.00e+00

== (a) 逐算子计时 ==
  x + b        (读2写1)    11.2 ms
  gelu(y)      (读1写1)    12.9 ms
  y + r        (读2写1)    11.9 ms
  y * 0.5      (读1写1)    10.4 ms
  clamp_       (读1写1)     3.9 ms
  整串未融合               53.7 ms  有效带宽   27.5 GB/s

== (b) 理想融合 kernel 的下界：单遍 读 x、r 写 out ==
  单遍遍历     6.4 ms → 融合后最多可快 8.40×（若 GELU 计算不成为新瓶颈）

== 反例：框架层面按块拼凑（每块内仍是多个独立算子）==
  block=   16K元素   114.4 ms  相对未融合 0.47×
  block= 4096K元素    37.5 ms  相对未融合 1.43×

[小结] 逐元素算子受访存限制，耗时大致正比于读写遍数；真正的融合必须发生在单个 kernel
       内部（数据留在寄存器里），在 Python/框架层面切块拼凑得不到收益，块小时反而被开销拖慢。
       这正是 TorchInductor/XLA/TVM 自动生成融合 kernel 的价值。GELU 在 CPU 上计算较重，
       说明'访存受限'的判断要结合具体硬件（GPU 上它仍是访存受限）。
[问题库] P12 融合机会与编译器自动化的边界
```

### `labs/m03_kernels/lab_03_flash_attention.py`

```python
"""[M03-L03] FlashAttention 的核心：分块 + 在线 softmax（online softmax）

目标：从零实现分块注意力，验证与标准注意力数值一致；用 IO 模型比较标准注意力与
      FlashAttention 对 HBM 的访问量，理解"不把 N×N 矩阵写回 HBM"带来的收益。
先预测：
  1. 标准注意力需要在 HBM 中存储多大的中间矩阵？N=8192、fp16 时是多少 MB（每个头）？
  2. 在线 softmax 遇到更大的新最大值时，之前累加的结果该怎么修正？
可调参数：--n（序列长度）、--d（头维度）、--block（分块大小）、--sram-kb
暴露的问题：长上下文下注意力的显存与访存；kernel 需要随硬件重写 → PROBLEM_BANK P07、P13
对应论文：FlashAttention（2205.14135）定理 2 的 IO 复杂度 Θ(N²d²/M)；FlashAttention-2/3
真实框架对照：Dao-AILab/flash-attention csrc/flash_attn/src/flash_fwd_kernel.h；
              Triton 官方教程 06-fused-attention.py
"""
import argparse
import math
import time

import torch


def standard_attention(q, k, v):
    s = q @ k.T / math.sqrt(q.shape[-1])     # N×N 分数矩阵（写回 HBM）
    p = torch.softmax(s, dim=-1)             # 再读、再写 N×N
    return p @ v


def flash_attention(q, k, v, block):
    """单头前向。外层遍历 Q 块，内层遍历 K/V 块，维护行最大值 m、行和 l、输出累加 o。"""
    n, d = q.shape
    scale = 1 / math.sqrt(d)
    out = torch.empty_like(q)
    for i in range(0, n, block):
        qi = q[i:i + block] * scale
        m = torch.full((qi.shape[0], 1), -float("inf"))
        l = torch.zeros(qi.shape[0], 1)
        o = torch.zeros(qi.shape[0], d)
        for j in range(0, n, block):
            s = qi @ k[j:j + block].T                       # 只在"片上"出现 block×block
            m_new = torch.maximum(m, s.max(dim=1, keepdim=True).values)
            p = torch.exp(s - m_new)
            corr = torch.exp(m - m_new)                     # 旧结果按新最大值重新缩放
            l = l * corr + p.sum(dim=1, keepdim=True)
            o = o * corr + p @ v[j:j + block]
            m = m_new
        out[i:i + block] = o / l
    return out


def io_model(n, d, sram_bytes, bytes_per=2):
    std = bytes_per * (4 * n * d + 4 * n * n)        # 读 QKV 写 O + 写 S、读 S、写 P、读 P
    m = sram_bytes / bytes_per
    blk = max(1, int(m // (4 * d)))                   # FA1 论文中 Bc = ceil(M / 4d)
    passes = math.ceil(n / blk)                       # K/V 被完整读取的次数
    flash = bytes_per * (2 * n * d + passes * 2 * n * d)
    return std, flash, blk


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1024)
    ap.add_argument("--d", type=int, default=64)
    ap.add_argument("--block", type=int, default=128)
    ap.add_argument("--sram-kb", type=int, default=192)
    a = ap.parse_args()
    torch.manual_seed(0)
    q, k, v = (torch.randn(a.n, a.d) for _ in range(3))

    ref = standard_attention(q, k, v)
    t0 = time.perf_counter(); out = flash_attention(q, k, v, a.block); dt = time.perf_counter() - t0
    print("== 正确性 ==")
    print(f"  N={a.n}, d={a.d}, block={a.block}: max|差| = {(ref - out).abs().max().item():.2e}"
          f"  （分块实现耗时 {dt * 1e3:.1f} ms，CPU 上不追求速度）")
    q2 = q.clone(); q2[0] *= 50                       # 制造很大的分数，检验数值稳定
    print(f"  大数值输入下 max|差| = {(standard_attention(q2, k, v) - flash_attention(q2, k, v, a.block)).abs().max().item():.2e}")

    print(f"\n== HBM 访问量模型（fp16，片上 {a.sram_kb}KB，每个头）==")
    print(f"  {'N':>6s} {'S矩阵MB':>9s} {'标准(MB)':>10s} {'Flash(MB)':>10s} {'比值':>6s}")
    for n in [1024, 4096, 8192, 32768, 131072]:
        std, fl, blk = io_model(n, a.d, a.sram_kb * 1024)
        print(f"  {n:6d} {2 * n * n / 2 ** 20:9.1f} {std / 2 ** 20:10.1f} {fl / 2 ** 20:10.1f} {std / fl:6.1f}×")
    print(f"  （片上块大小 Bc = {io_model(1024, a.d, a.sram_kb * 1024)[2]}）")
    print("\n[小结] FlashAttention 计算量不变（甚至略多），但不再把 N×N 矩阵写回 HBM，"
          "\n       显存从 O(N²) 降为 O(N)。它说明：在访存受限的世界里，'重算'可以比'存储'便宜。"
          "\n[问题库] P07 长上下文；P13 kernel 随硬件演进需要重写（FA3 针对 Hopper）")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m03_kernels/outputs/lab_03_flash_attention.txt`）：

```text
# 实测输出：m03_kernels/lab_03_flash_attention.py
# 运行时间：2026-10-18 21:29，耗时 1.0s，峰值内存 249MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 正确性 ==
  N=1024, d=64, block=128: max|差| = 2.68e-07  （分块实现耗时 6.4 ms，CPU 上不追求速度）
  大数值输入下 max|差| = 2.38e-06

== HBM 访问量模型（fp16，片上 192KB，每个头）==
       N     S矩阵MB     标准(MB)  Flash(MB)     比值
    1024       2.0        8.5        1.0    8.5×
    4096      32.0      130.0       12.0   10.8×
    8192     128.0      516.0       46.0   11.2×
   32768    2048.0     8208.0      696.0   11.8×
  131072   32768.0   131136.0    10976.0   11.9×
  （片上块大小 Bc = 384）

[小结] FlashAttention 计算量不变（甚至略多），但不再把 N×N 矩阵写回 HBM，
       显存从 O(N²) 降为 O(N)。它说明：在访存受限的世界里，'重算'可以比'存储'便宜。
[问题库] P07 长上下文；P13 kernel 随硬件演进需要重写（FA3 针对 Hopper）
```

### `labs/m03_kernels/lab_04_triton_softmax_gpu.py`

```python
"""[M03-L04]【选做·需 GPU】用 Triton 写一个融合 softmax kernel

目标：体验以"块（block）"为单位的 GPU 编程：一个 program 处理一行，读一次、在片上算完
      max/exp/sum/除法、写一次。与 torch.softmax 和"未融合手写 softmax"比较带宽。
先预测：未融合手写 softmax（5 个算子）比融合 kernel 慢几倍？
可调参数：--rows、--cols
CPU 替代：labs/m03_kernels/lab_02_operator_fusion.py（融合的访存分析）与 lab_03（在线 softmax）。
         没有 GPU 时本脚本只打印说明并以 0 退出（run_all 记为 SKIP）。
依赖：env/requirements-gpu.txt 中的 triton（随 CUDA 版 torch 一起安装）
暴露的问题：手写 kernel 的开发成本与可移植性 → PROBLEM_BANK P13
对应论文：Triton（MAPL'19）
真实框架对照：triton-lang/triton python/tutorials/02-fused-softmax.py
"""
import argparse
import sys

import torch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=4096)
    ap.add_argument("--cols", type=int, default=2048)
    a = ap.parse_args()
    try:
        import triton
        import triton.language as tl
    except ImportError:
        triton = None
    if triton is None or not torch.cuda.is_available():
        print("[SKIP] 需要 NVIDIA GPU + triton。CPU 替代实验：m03 lab_02（融合访存分析）、lab_03（在线 softmax）。")
        sys.exit(0)

    @triton.jit
    def softmax_kernel(out_ptr, in_ptr, stride, n_cols, BLOCK: tl.constexpr):
        row = tl.program_id(0)                          # 每个 program 负责一行
        offs = tl.arange(0, BLOCK)
        mask = offs < n_cols
        x = tl.load(in_ptr + row * stride + offs, mask=mask, other=-float("inf"))
        x = x - tl.max(x, axis=0)                       # 数值稳定
        num = tl.exp(x)
        y = num / tl.sum(num, axis=0)
        tl.store(out_ptr + row * stride + offs, y, mask=mask)

    def triton_softmax(x):
        out = torch.empty_like(x)
        BLOCK = triton.next_power_of_2(x.shape[1])
        softmax_kernel[(x.shape[0],)](out, x, x.stride(0), x.shape[1], BLOCK=BLOCK)
        return out

    def naive_softmax(x):
        m = x.max(dim=1, keepdim=True).values
        z = x - m
        num = torch.exp(z)
        return num / num.sum(dim=1, keepdim=True)

    x = torch.randn(a.rows, a.cols, device="cuda")
    assert torch.allclose(triton_softmax(x), torch.softmax(x, dim=1), atol=1e-6)
    nbytes = 2 * x.numel() * x.element_size()           # 理想：读一次写一次
    for name, fn in [("triton 融合", triton_softmax), ("torch.softmax", lambda t: torch.softmax(t, 1)),
                     ("手写未融合", naive_softmax)]:
        ms = triton.testing.do_bench(lambda: fn(x))
        print(f"  {name:14s} {ms:7.3f} ms  有效带宽 {nbytes / ms / 1e6:7.1f} GB/s")
    print("[小结] 融合 kernel 接近一次读写的带宽上限；未融合版本因多次 HBM 往返明显更慢。")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m03_kernels/outputs/lab_04_triton_softmax_gpu.txt`）：

```text
# 实测输出：m03_kernels/lab_04_triton_softmax_gpu.py
# 运行时间：2026-10-18 21:29，耗时 1.0s，峰值内存 220MB，状态 SKIP
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

[SKIP] 需要 NVIDIA GPU + triton。CPU 替代实验：m03 lab_02（融合访存分析）、lab_03（在线 softmax）。
```

## M04 显存与精度：显存账本、混合精度（FP16/BF16/FP8）、激活重计算、offload（`labs/m04_memory_precision/`）

### `labs/m04_memory_precision/lab_01_memory_ledger.py`

```python
"""[M04-L01] 训练显存账本：参数 / 梯度 / 优化器状态 / 激活值

目标：能估算任意 Transformer 训练时每张卡的显存，并说明 ZeRO、张量并行、激活重计算各省掉哪一项；
      再在一个小模型上实测参数/梯度/Adam 状态的字节数，验证账本公式。
先预测：
  1. 7B 模型用 BF16 混合精度 + Adam 训练，仅"模型状态"就要多少 GB？单张 80GB 卡放得下吗？
  2. 序列长度从 2K 增到 32K，激活值显存增加多少倍？（提示：注意力分数项随 s² 增长）
可调参数：--model（7b/13b/70b）、--seq、--mbs（micro batch）、--tp、--dp
暴露的问题：显存墙；长序列激活爆炸 → PROBLEM_BANK P14、P20
对应论文：ZeRO（16Ψ 字节账本）；Reducing Activation Recomputation（Korthikanti et al.，
          每层激活 sbh(34 + 5as/h) 字节公式）；Megatron 3D 并行
"""
import argparse

import torch

MODELS = {  # Llama 风格：层数 L、隐藏 h、头数 a、FFN f、词表 V
    "7b": dict(L=32, h=4096, a=32, f=11008, V=32000),
    "13b": dict(L=40, h=5120, a=40, f=13824, V=32000),
    "70b": dict(L=80, h=8192, a=64, f=28672, V=32000),
}


def n_params(c):
    # 注意力 4h²（QKV+O，按 MHA 估算）+ SwiGLU MLP 3hf，外加输入/输出嵌入
    return c["L"] * (4 * c["h"] ** 2 + 3 * c["h"] * c["f"]) + 2 * c["V"] * c["h"]


def model_states(psi, zero, dp):
    """混合精度 Adam：BF16 参数 2 + BF16 梯度 2 + FP32 主权重 4 + m 4 + v 4 = 16 字节/参数。"""
    if zero == 0:
        return 16 * psi
    if zero == 1:
        return 4 * psi + 12 * psi / dp
    if zero == 2:
        return 2 * psi + 14 * psi / dp
    return 16 * psi / dp


def activations(c, s, b, tp, mode):
    """Korthikanti et al. 2022 表 2：每层激活字节（BF16）。"""
    h, a, L = c["h"], c["a"], c["L"]
    if mode == "none":            # 无并行、无重计算
        per = s * b * h * (34 + 5 * a * s / h)
    elif mode == "tp+sp":         # 张量并行 + 序列并行
        per = s * b * h * (34 + 5 * a * s / h) / tp
    elif mode == "tp+sp+selective":  # 再加选择性重计算（只重算注意力 softmax 部分）
        per = s * b * h * 34 / tp
    else:                         # 完全重计算：只存每层输入
        per = 2 * s * b * h / tp
    return per * L


def gb(x):
    return x / 2 ** 30


def measure_small():
    print("\n== 实测：小模型的模型状态字节（FP32 训练 + Adam）==")
    m = torch.nn.Sequential(torch.nn.Linear(512, 2048), torch.nn.GELU(), torch.nn.Linear(2048, 512))
    opt = torch.optim.Adam(m.parameters())
    m(torch.randn(8, 512)).sum().backward()
    opt.step()
    P = sum(p.numel() for p in m.parameters())
    pb = sum(p.numel() * p.element_size() for p in m.parameters())
    gbytes = sum(p.grad.numel() * p.grad.element_size() for p in m.parameters())
    ob = sum(v.numel() * v.element_size() for st in opt.state.values() for v in st.values() if torch.is_tensor(v) and v.dim() > 0)
    print(f"  参数 {P:,} 个：参数 {pb:,} B + 梯度 {gbytes:,} B + Adam 状态 {ob:,} B "
          f"= {(pb + gbytes + ob) / P:.1f} 字节/参数（FP32 训练：4+4+8=16）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="7b", choices=MODELS)
    ap.add_argument("--seq", type=int, nargs="+", default=[2048, 8192, 32768])
    ap.add_argument("--mbs", type=int, default=1)
    ap.add_argument("--tp", type=int, default=8)
    ap.add_argument("--dp", type=int, default=8)
    a = ap.parse_args()
    c = MODELS[a.model]
    psi = n_params(c)
    print(f"== {a.model}: 参数量 ≈ {psi / 1e9:.2f}B ==")
    print("-- 模型状态（每卡）--")
    for z in range(4):
        print(f"  ZeRO-{z} (dp={a.dp}): {gb(model_states(psi, z, a.dp)):8.1f} GB")
    print(f"  注：若再叠加张量并行 tp={a.tp}，每卡模型状态再除以 tp")

    print(f"\n-- 激活值（mbs={a.mbs}，全部 {c['L']} 层，每卡）--")
    print(f"  {'seq':>6s} {'无优化':>10s} {'TP+SP':>10s} {'+选择重算':>10s} {'完全重算':>10s}")
    for s in a.seq:
        row = [gb(activations(c, s, a.mbs, a.tp, m)) for m in ["none", "tp+sp", "tp+sp+selective", "full"]]
        print(f"  {s:6d} " + " ".join(f"{v:10.1f}" for v in row) + "  GB")
    measure_small()
    print("\n[小结] 模型状态里优化器占 12/16；ZeRO 按 DP 切分它们。激活值里 5as/h 项随 s² 增长，"
          "\n       长序列时远超 34 项——FlashAttention 不存 softmax 矩阵、选择性重计算都针对这一项。"
          "\n[问题库] P14 显存墙；P20 长序列训练")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m04_memory_precision/outputs/lab_01_memory_ledger.txt`）：

```text
# 实测输出：m04_memory_precision/lab_01_memory_ledger.py
# 运行时间：2026-10-18 21:29，耗时 1.8s，峰值内存 345MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 7b: 参数量 ≈ 6.74B ==
-- 模型状态（每卡）--
  ZeRO-0 (dp=8):    100.4 GB
  ZeRO-1 (dp=8):     34.5 GB
  ZeRO-2 (dp=8):     23.5 GB
  ZeRO-3 (dp=8):     12.6 GB
  注：若再叠加张量并行 tp=8，每卡模型状态再除以 tp

-- 激活值（mbs=1，全部 32 层，每卡）--
     seq        无优化      TP+SP      +选择重算       完全重算
    2048       28.5        3.6        1.1        0.1  GB
    8192      354.0       44.2        4.2        0.2  GB
   32768     5256.0      657.0       17.0        1.0  GB

== 实测：小模型的模型状态字节（FP32 训练 + Adam）==
  参数 2,099,712 个：参数 8,398,848 B + 梯度 8,398,848 B + Adam 状态 16,797,696 B = 16.0 字节/参数（FP32 训练：4+4+8=16）

[小结] 模型状态里优化器占 12/16；ZeRO 按 DP 切分它们。激活值里 5as/h 项随 s² 增长，
       长序列时远超 34 项——FlashAttention 不存 softmax 矩阵、选择性重计算都针对这一项。
[问题库] P14 显存墙；P20 长序列训练
```

### `labs/m04_memory_precision/lab_02_mixed_precision.py`

```python
"""[M04-L02] 混合精度的数值问题：舍入、下溢、累加误差、FP8 缩放粒度

目标：亲眼看到 FP16/BF16 为什么需要 FP32 主权重、loss scaling 和 FP32 累加；
      理解 FP8 训练中缩放粒度（per-tensor vs per-block）对离群值的影响。
先预测：
  1. 在 FP16 里 1.0 + 1e-4 等于几？BF16 呢？
  2. 张量里有一个 1000 倍的离群值时，per-tensor FP8 量化会让其余元素的误差怎样变化？
可调参数：--block（FP8 分块大小，DeepSeek-V3 用 1×128 / 128×128）、--outlier
暴露的问题：低精度训练的稳定性与缩放粒度 → PROBLEM_BANK P15
对应论文：Mixed Precision Training（1710.03740）；FP8 Formats（2209.05433）；
          DeepSeek-V3（细粒度 FP8 量化）；Scaling FP8 training to trillion-token LLMs
"""
import argparse

import torch


def demo_rounding():
    print("== 1. 小更新被舍掉（为什么需要 FP32 主权重）==")
    for dt in [torch.float16, torch.bfloat16, torch.float32]:
        one = torch.tensor(1.0, dtype=dt)
        print(f"  {str(dt):15s} eps={torch.finfo(dt).eps:.2e}  1+1e-4 = {(one + 1e-4).item():.6f}"
              f"  max={torch.finfo(dt).max:.3e}  最小正规数={torch.finfo(dt).tiny:.2e}")
    # 用 FP16 权重直接做 SGD：每步更新 lr*grad = 1e-4，权重停在原地
    w16 = torch.tensor(1.0, dtype=torch.float16); w32 = torch.tensor(1.0)
    for _ in range(1000):
        w16 -= torch.tensor(1e-4, dtype=torch.float16); w32 -= 1e-4
    print(f"  1000 步、每步减 1e-4：FP16 权重={w16.item():.4f}（应为 0.9），FP32 主权重={w32.item():.4f}")


def demo_underflow():
    print("\n== 2. 梯度下溢与 loss scaling ==")
    g = torch.tensor([1e-3, 1e-5, 1e-7, 1e-9])
    print(f"  原始梯度       {g.tolist()}")
    print(f"  直接转 FP16    {g.half().float().tolist()}")
    S = 65536.0
    print(f"  ×{S:.0f} 后转 FP16 再 ÷S {(g * S).half().float().div(S).tolist()}")
    print(f"  转 BF16（指数位与 FP32 相同，无需 scaling）{g.bfloat16().float().tolist()}")


def demo_accumulate():
    print("\n== 3. 累加精度（为什么 GEMM 要用 FP32 累加器）==")
    x = torch.full((10000,), 1e-3)
    acc16 = torch.tensor(0.0, dtype=torch.float16)
    for v in x.half():
        acc16 = acc16 + v
    print(f"  10000 个 1e-3 求和：FP16 逐个累加={acc16.item():.4f}  FP32={x.sum().item():.4f}（真值 10）")


def fp8_quant(x, block):
    """E4M3 量化：按块计算 scale = amax/448，量化后再反量化，返回重建结果。"""
    fmax = torch.finfo(torch.float8_e4m3fn).max      # 448
    flat = x.reshape(-1, block) if block else x.reshape(1, -1)
    scale = flat.abs().amax(dim=1, keepdim=True).clamp(min=1e-12) / fmax
    q = (flat / scale).to(torch.float8_e4m3fn)
    return (q.float() * scale).reshape(x.shape)


def int8_quant(x, block):
    """对称 INT8 均匀量化（对照组）：刻度是线性的，离群值会直接拉大量化步长。"""
    flat = x.reshape(-1, block) if block else x.reshape(1, -1)
    scale = flat.abs().amax(dim=1, keepdim=True).clamp(min=1e-12) / 127
    return ((flat / scale).round().clamp(-127, 127) * scale).reshape(x.shape)


def demo_fp8(block, outliers):
    print("\n== 4. 缩放粒度 vs 离群值：FP8(E4M3，浮点刻度) 对照 INT8（均匀刻度）==")
    torch.manual_seed(0)
    x = torch.randn(64, 1024)
    mask = torch.ones_like(x, dtype=torch.bool); mask[3, 7] = False
    print(f"  {'离群倍数':>8s} {'格式':6s} {'粒度':16s} {'其余元素相对误差':>14s} {'被量化成0':>10s}")
    for k in [1.0] + outliers:
        t = x.clone(); t[3, 7] *= k                          # 单个离群值
        for fmt, fn in [("FP8", fp8_quant), ("INT8", int8_quant)]:
            for gran, blk in [("per-tensor", 0), (f"per-block({block})", block)]:
                r = fn(t, blk)
                rel = ((r - t)[mask].norm() / t[mask].norm()).item()
                zero = ((r == 0) & (t != 0))[mask].float().mean().item()
                print(f"  {k:8.0e} {fmt:6s} {gran:16s} {rel:14.4f} {zero:10.2%}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--block", type=int, default=128)
    ap.add_argument("--outlier", type=float, nargs="+", default=[1e3, 1e5])
    a = ap.parse_args()
    demo_rounding()
    demo_underflow()
    demo_accumulate()
    demo_fp8(a.block, a.outlier)
    print("\n[小结] FP16 范围窄需要 loss scaling；BF16 范围宽但精度低，仍需 FP32 主权重与累加。"
          "\n       INT8 的刻度是均匀的，一个离群值就让其余元素误差暴涨；FP8 有指数位，对缩放不敏感，"
          "\n       直到小值跌出可表示范围（E4M3 最小次正规数 2^-9）被量化成 0。细粒度（per-block）缩放"
          "\n       把离群值的影响限制在一个块内——这正是 DeepSeek-V3 采用 1×128/128×128 分块缩放的原因。"
          "\n[问题库] P15 低精度训练稳定性与缩放粒度")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m04_memory_precision/outputs/lab_02_mixed_precision.txt`）：

```text
# 实测输出：m04_memory_precision/lab_02_mixed_precision.py
# 运行时间：2026-10-18 21:29，耗时 1.0s，峰值内存 237MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 1. 小更新被舍掉（为什么需要 FP32 主权重）==
  torch.float16   eps=9.77e-04  1+1e-4 = 1.000000  max=6.550e+04  最小正规数=6.10e-05
  torch.bfloat16  eps=7.81e-03  1+1e-4 = 1.000000  max=3.390e+38  最小正规数=1.18e-38
  torch.float32   eps=1.19e-07  1+1e-4 = 1.000100  max=3.403e+38  最小正规数=1.18e-38
  1000 步、每步减 1e-4：FP16 权重=1.0000（应为 0.9），FP32 主权重=0.9000

== 2. 梯度下溢与 loss scaling ==
  原始梯度       [0.0010000000474974513, 9.999999747378752e-06, 1.0000000116860974e-07, 9.999999717180685e-10]
  直接转 FP16    [0.0010004043579101562, 1.0013580322265625e-05, 1.1920928955078125e-07, 0.0]
  ×65536 后转 FP16 再 ÷S [0.0010004043579101562, 9.998679161071777e-06, 1.00000761449337e-07, 1.000444171950221e-09]
  转 BF16（指数位与 FP32 相同，无需 scaling）[0.00099945068359375, 1.0013580322265625e-05, 1.0011717677116394e-07, 9.968061931431293e-10]

== 3. 累加精度（为什么 GEMM 要用 FP32 累加器）==
  10000 个 1e-3 求和：FP16 逐个累加=4.0000  FP32=10.0000（真值 10）

== 4. 缩放粒度 vs 离群值：FP8(E4M3，浮点刻度) 对照 INT8（均匀刻度）==
      离群倍数 格式     粒度                     其余元素相对误差      被量化成0
     1e+00 FP8    per-tensor               0.0265      0.00%
     1e+00 FP8    per-block(128)           0.0257      0.00%
     1e+00 INT8   per-tensor               0.0104      1.43%
     1e+00 INT8   per-block(128)           0.0065      0.87%
     1e+03 FP8    per-tensor               0.0265      0.06%
     1e+03 FP8    per-block(128)           0.0257      0.00%
     1e+03 INT8   per-tensor               0.8857     92.41%
     1e+03 INT8   per-block(128)           0.0389      1.05%
     1e+05 FP8    per-tensor               0.0569      7.86%
     1e+05 FP8    per-block(128)           0.0258      0.02%
     1e+05 INT8   per-tensor               1.0000    100.00%
     1e+05 INT8   per-block(128)           0.0442      1.06%

[小结] FP16 范围窄需要 loss scaling；BF16 范围宽但精度低，仍需 FP32 主权重与累加。
       INT8 的刻度是均匀的，一个离群值就让其余元素误差暴涨；FP8 有指数位，对缩放不敏感，
       直到小值跌出可表示范围（E4M3 最小次正规数 2^-9）被量化成 0。细粒度（per-block）缩放
       把离群值的影响限制在一个块内——这正是 DeepSeek-V3 采用 1×128/128×128 分块缩放的原因。
[问题库] P15 低精度训练稳定性与缩放粒度
```

### `labs/m04_memory_precision/lab_03_activation_checkpoint.py`

```python
"""[M04-L03] 激活重计算（activation checkpointing）：用算力换显存

目标：从零实现一个 checkpoint（前向只存输入，反向时重算），用 saved_tensors_hooks 统计
      为反向保存的字节数，对比"不重算 / 每层重算 / 每 k 层重算"的显存与耗时。
先预测：
  1. 每层都重算时，保存的激活降为原来的几分之一？前向+反向耗时增加约多少（理论值）？
  2. 每 √L 层设一个检查点（Chen et al. 2016），显存与重算开销如何？
可调参数：--layers、--width、--batch、--every（检查点间隔列表）
暴露的问题：重算策略的选择是显存-时间的权衡；自动选择是研究问题 → PROBLEM_BANK P14
对应论文：Training Deep Nets with Sublinear Memory Cost（1604.06174）；
          Reducing Activation Recomputation（选择性重计算）
真实框架对照：torch/utils/checkpoint.py；Megatron-LM megatron/core/tensor_parallel/random.py（CheckpointFunction）
"""
import argparse
import time

import torch
import torch.nn as nn


class Checkpoint(torch.autograd.Function):
    """前向在 no_grad 下运行子网络，只保存输入；反向时用 enable_grad 重算再求梯度。"""

    @staticmethod
    def forward(ctx, run_fn, x, *params):
        ctx.run_fn = run_fn
        ctx.save_for_backward(x)
        with torch.no_grad():
            return run_fn(x)

    @staticmethod
    def backward(ctx, grad_out):
        (x,) = ctx.saved_tensors
        x = x.detach().requires_grad_(True)
        params = [p for p in ctx.run_fn.parameters()]
        with torch.enable_grad():
            y = ctx.run_fn(x)                              # 重算前向
        grads = torch.autograd.grad(y, [x] + params, grad_out)
        return (None, grads[0], *grads[1:])


def build(layers, width):
    torch.manual_seed(0)
    return nn.ModuleList(nn.Sequential(nn.Linear(width, 4 * width), nn.GELU(), nn.Linear(4 * width, width))
                         for _ in range(layers))


def forward(blocks, x, every):
    if every == 0:
        for b in blocks:
            x = x + b(x)
        return x
    for i in range(0, len(blocks), every):
        seg = nn.Sequential(*blocks[i:i + every])

        def run(inp, seg=seg):
            for b in seg:
                inp = inp + b(inp)
            return inp
        run.parameters = seg.parameters
        x = Checkpoint.apply(run, x, *seg.parameters())
    return x


def run_once(blocks, x, every):
    params = {p.data_ptr() for p in blocks.parameters()}
    saved = {}

    def pack(t):
        if t.data_ptr() not in params:                     # 不统计参数本身
            saved[t.data_ptr()] = t.numel() * t.element_size()
        return t
    for p in blocks.parameters():
        p.grad = None
    t0 = time.perf_counter()
    with torch.autograd.graph.saved_tensors_hooks(pack, lambda t: t):
        out = forward(blocks, x, every)
    out.square().mean().backward()
    dt = time.perf_counter() - t0
    return sum(saved.values()), dt, [p.grad.clone() for p in blocks.parameters()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", type=int, default=16)
    ap.add_argument("--width", type=int, default=256)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--every", type=int, nargs="+", default=[0, 1, 4, 16])
    a = ap.parse_args()
    blocks = build(a.layers, a.width)
    x = torch.randn(a.batch, a.width)
    run_once(blocks, x, 0)                                 # 预热
    base = [run_once(blocks, x, 0) for _ in range(3)]
    base_mem, base_g = base[0][0], base[0][2]
    base_t = sorted(r[1] for r in base)[1]
    print(f"== {a.layers} 层 MLP 块，width={a.width}，batch={a.batch} ==")
    print(f"  {'检查点间隔':>8s} {'保存激活(MB)':>12s} {'相对':>6s} {'耗时(ms)':>9s} {'相对':>6s} {'梯度一致':>8s}")
    for e in a.every:
        run_once(blocks, x, e)                             # 每种配置单独预热（首次运行有额外开销）
        runs = [run_once(blocks, x, e) for _ in range(3)]
        mem, g = runs[0][0], runs[0][2]
        dt = sorted(r[1] for r in runs)[1]                 # 取中位数
        same = all(torch.allclose(u, v, atol=1e-5) for u, v in zip(g, base_g))
        label = "不重算" if e == 0 else f"每{e}层"
        print(f"  {label:>8s} {mem / 2 ** 20:12.2f} {mem / base_mem:6.2f} {dt * 1e3:9.1f} "
              f"{dt / base_t:6.2f} {str(same):>8s}")
    print("\n  注：'每k层'时，段内激活在反向时临时重建（峰值另计 1 段），表中统计的是跨段常驻部分。")
    print("\n[小结] 每层重算把常驻激活降到每层只剩输入，代价是多做约一次前向（理论 +33%：前向 1 份、反向 2 份）。"
          "\n       间隔越大，常驻越少但段内峰值越高；选择性重计算只重算'便宜但占显存'的部分。"
          "\n[问题库] P14 显存墙与重计算策略")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m04_memory_precision/outputs/lab_03_activation_checkpoint.txt`）：

```text
# 实测输出：m04_memory_precision/lab_03_activation_checkpoint.py
# 运行时间：2026-10-18 21:29，耗时 2.4s，峰值内存 674MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 16 层 MLP 块，width=256，batch=256 ==
     检查点间隔     保存激活(MB)     相对    耗时(ms)     相对     梯度一致
       不重算        36.00   1.00      41.5   1.04     True
       每1层         4.00   0.11      57.2   1.44     True
       每4层         1.00   0.03      50.5   1.27     True
      每16层         0.25   0.01      51.4   1.29     True

  注：'每k层'时，段内激活在反向时临时重建（峰值另计 1 段），表中统计的是跨段常驻部分。

[小结] 每层重算把常驻激活降到每层只剩输入，代价是多做约一次前向（理论 +33%：前向 1 份、反向 2 份）。
       间隔越大，常驻越少但段内峰值越高；选择性重计算只重算'便宜但占显存'的部分。
[问题库] P14 显存墙与重计算策略
```

## M05 集合通信：原语、Ring 与 Tree、α-β 模型、NCCL、NVLink / InfiniBand / RDMA（`labs/m05_collectives/`）

### `labs/m05_collectives/lab_01_ring_allreduce.py`

```python
"""[M05-L01] Ring AllReduce 模拟器：逐步执行 ReduceScatter + AllGather

目标：用 N 个"虚拟 rank"（numpy 数组）逐步模拟 Ring AllReduce，验证结果正确，
      统计每个 rank 发送的数据量 2(N-1)/N·S，并与"汇聚到根再广播"的朴素算法对比。
先预测：
  1. N 从 2 增大到 64，Ring 中每个 rank 发送的字节数怎么变？朴素算法中根节点呢？
  2. Ring 一共需要几步（通信轮数）？这对小消息意味着什么？
可调参数：--ranks（2~64）、--size（每个 rank 的元素数）、--trace（打印每一步）
暴露的问题：带宽最优 ≠ 延迟最优；小消息时轮数主导 → PROBLEM_BANK P23
对应论文：Patarasuk & Yuan 2009（带宽最优 AllReduce）；Horovod（把 ring-allreduce 引入深度学习）
真实框架对照：NVIDIA/nccl src/device/all_reduce.h（runRing）；nccl-tests 的 busbw 公式
"""
import argparse

import numpy as np


def ring_allreduce(bufs, trace=False):
    n = len(bufs)
    chunks = [np.array_split(b.copy(), n) for b in bufs]   # 每个 rank 把数据切成 n 块
    sent = [0] * n
    # 阶段 1：ReduceScatter。第 s 步，rank r 把第 (r - s) 块发给 r+1，后者累加
    for s in range(n - 1):
        msgs = [(r, (r - s) % n, chunks[r][(r - s) % n].copy()) for r in range(n)]
        for r, c, data in msgs:
            dst = (r + 1) % n
            chunks[dst][c] += data
            sent[r] += data.nbytes
        if trace:
            print(f"  RS step {s}: rank r 发送块 (r-{s}) mod {n}")
    # 此时 rank r 拥有第 (r+1) 块的完整和
    # 阶段 2：AllGather。第 s 步，rank r 把第 (r + 1 - s) 块（已完整）发给 r+1，后者覆盖
    for s in range(n - 1):
        msgs = [(r, (r + 1 - s) % n, chunks[r][(r + 1 - s) % n].copy()) for r in range(n)]
        for r, c, data in msgs:
            chunks[(r + 1) % n][c] = data
            sent[r] += data.nbytes
        if trace:
            print(f"  AG step {s}: rank r 发送块 (r+1-{s}) mod {n}")
    return [np.concatenate(c) for c in chunks], sent, 2 * (n - 1)


def naive_allreduce(bufs):
    n = len(bufs)
    total = sum(bufs)                       # 所有 rank 把数据发给 rank 0
    sent = [bufs[0].nbytes] * n
    sent[0] = (n - 1) * bufs[0].nbytes       # rank 0 再把结果发给其余 n-1 个 rank
    return [total.copy() for _ in range(n)], sent, 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, nargs="+", default=[2, 4, 8, 16, 64])
    ap.add_argument("--size", type=int, default=1 << 16)
    ap.add_argument("--trace", action="store_true")
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    print(f"== 每个 rank {a.size} 个 float32（{a.size * 4 / 2 ** 20:.2f} MB）==")
    print(f"  {'N':>3s} {'正确':>4s} {'ring 每rank发送':>16s} {'理论2(N-1)/N·S':>16s} {'ring轮数':>8s} "
          f"{'朴素根节点发送':>14s}")
    for n in a.ranks:
        bufs = [rng.standard_normal(a.size).astype(np.float32) for _ in range(n)]
        ref = np.sum(bufs, axis=0)
        out, sent, steps = ring_allreduce(bufs, trace=a.trace and n <= 4)
        ok = all(np.allclose(o, ref, atol=1e-3) for o in out)
        _, nsent, _ = naive_allreduce(bufs)
        S = bufs[0].nbytes
        print(f"  {n:3d} {str(ok):>4s} {max(sent) / 2 ** 20:13.2f} MB {2 * (n - 1) / n * S / 2 ** 20:13.2f} MB "
              f"{steps:8d} {max(nsent) / 2 ** 20:11.2f} MB")
    print("\n  nccl-tests 定义：algbw = S / t；busbw = algbw × 2(N-1)/N，用来和链路带宽直接比较。")
    print("\n[小结] Ring 让每个 rank 的发送量与 N 基本无关（趋近 2S），所以带宽最优；但轮数 2(N-1)"
          "\n       随 N 线性增长，小消息时延迟项主导——这是 Tree / 分层算法存在的理由（见 lab_02）。"
          "\n[问题库] P23 集合通信算法选择与拓扑感知")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m05_collectives/outputs/lab_01_ring_allreduce.txt`）：

```text
# 实测输出：m05_collectives/lab_01_ring_allreduce.py
# 运行时间：2026-10-18 21:29，耗时 0.3s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 每个 rank 65536 个 float32（0.25 MB）==
    N   正确     ring 每rank发送     理论2(N-1)/N·S   ring轮数        朴素根节点发送
    2 True          0.25 MB          0.25 MB        2        0.25 MB
    4 True          0.38 MB          0.38 MB        6        0.75 MB
    8 True          0.44 MB          0.44 MB       14        1.75 MB
   16 True          0.47 MB          0.47 MB       30        3.75 MB
   64 True          0.49 MB          0.49 MB      126       15.75 MB

  nccl-tests 定义：algbw = S / t；busbw = algbw × 2(N-1)/N，用来和链路带宽直接比较。

[小结] Ring 让每个 rank 的发送量与 N 基本无关（趋近 2S），所以带宽最优；但轮数 2(N-1)
       随 N 线性增长，小消息时延迟项主导——这是 Tree / 分层算法存在的理由（见 lab_02）。
[问题库] P23 集合通信算法选择与拓扑感知
```

### `labs/m05_collectives/lab_02_alpha_beta.py`

```python
"""[M05-L02] α-β 通信成本模型：Ring vs Tree vs 递归倍增 vs 分层 AllReduce

目标：用 T = α·(轮数) + β·(每 rank 传输字节) 估算不同 AllReduce 算法的耗时，
      找出小消息/大消息的最优算法与交叉点；理解节点内 NVLink 与节点间 InfiniBand 带宽差异的影响。
先预测：
  1. 256 个 GPU 做 1KB 的 AllReduce，Ring 和 Tree 谁快？1GB 呢？
  2. 节点内 8 卡 NVLink、节点间 IB 的集群上，"先节点内 ReduceScatter、再节点间 AllReduce、
     再节点内 AllGather"的分层算法能比扁平 Ring 快多少？
可调参数：--alpha-us、--bw-intra、--bw-inter（GB/s）、--gpus-per-node、--nodes
暴露的问题：算法选择依赖消息大小与拓扑 → PROBLEM_BANK P23
对应论文：Patarasuk & Yuan 2009；Demystifying NCCL（2507.04786）；Collective Communication for 100k+ GPUs
真实框架对照：NCCL 的 tuning（src/graph/tuning.cc 按 α-β 模型选择 Ring/Tree 与协议 LL/LL128/Simple）
"""
import argparse
import math


def ring(n, S, a, bw):
    return 2 * (n - 1) * a + 2 * (n - 1) / n * S / bw


def tree_naive(n, S, a, bw):
    # 不流水的二叉树：reduce 与 broadcast 各 log2(n) 层，每层整块传 S
    return 2 * math.ceil(math.log2(n)) * (a + S / bw)


def tree_pipelined(n, S, a, bw):
    # 流水线二叉树：把 S 切成 k 块，共 (2·log2 n + k - 1) 个流水步；内部节点每步要接收两个
    # 子节点各 S/k 的数据，所以每步耗时 α + 2S/(k·bw)。选最优 k。渐近带宽项 2S/bw，与 Ring 同量级。
    # NCCL 的"双二叉树"让每个节点在一棵树里是叶子、在另一棵里是内部节点，以平衡链路负载。
    d = 2 * math.ceil(math.log2(n))
    return min((d + k - 1) * (a + 2 * S / k / bw) for k in [2 ** i for i in range(0, 21)])


def recursive_doubling(n, S, a, bw):
    # 每轮交换全部数据：log2(n) 轮，每轮 S 字节（适合小消息）
    return math.ceil(math.log2(n)) * (a + S / bw)


def hierarchical(g, nodes, S, a, bw_in, bw_out):
    t = (g - 1) * a + (g - 1) / g * S / bw_in            # 节点内 ReduceScatter
    t += ring(nodes, S / g, a * 2, bw_out)               # 节点间对 1/g 的数据做 AllReduce（跨节点 α 更大）
    t += (g - 1) * a + (g - 1) / g * S / bw_in            # 节点内 AllGather
    return t


def fmt(t):
    return f"{t * 1e6:9.1f}us" if t < 1e-3 else f"{t * 1e3:9.2f}ms"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alpha-us", type=float, default=5.0)
    ap.add_argument("--bw-intra", type=float, default=300.0, help="节点内单向有效带宽 GB/s（NVLink 量级）")
    ap.add_argument("--bw-inter", type=float, default=25.0, help="节点间每 GPU 有效带宽 GB/s（200Gb IB ≈ 25GB/s）")
    ap.add_argument("--gpus-per-node", type=int, default=8)
    ap.add_argument("--nodes", type=int, default=32)
    a = ap.parse_args()
    al = a.alpha_us * 1e-6
    n = a.gpus_per_node * a.nodes
    sizes = [2 ** k for k in range(10, 31, 4)]
    bw = a.bw_inter * 1e9                                 # 扁平算法受最慢链路限制
    print(f"== 扁平算法，{n} GPU，α={a.alpha_us}us，瓶颈带宽 {a.bw_inter} GB/s ==")
    print(f"  {'消息':>8s} {'Ring':>11s} {'朴素树':>11s} {'流水线树':>11s} {'递归倍增':>11s} {'分层':>11s}  最优")
    for S in sizes:
        r = {"Ring": ring(n, S, al, bw), "朴素树": tree_naive(n, S, al, bw),
             "流水线树": tree_pipelined(n, S, al, bw),
             "递归倍增": recursive_doubling(n, S, al, bw),
             "分层": hierarchical(a.gpus_per_node, a.nodes, S, al, a.bw_intra * 1e9, bw)}
        best = min(r, key=r.get)
        label = f"{S // 2 ** 20}MB" if S >= 2 ** 20 else f"{S // 1024}KB"
        print(f"  {label:>8s} " + " ".join(f"{fmt(v):>11s}" for v in r.values()) + f"  {best}")

    print("\n== Ring 与流水线树的交叉点（随 GPU 数变化）==")
    for g in [8, 64, 512, 4096]:
        lo, hi = 1.0, 2.0 ** 36
        if ring(g, hi, al, bw) > tree_pipelined(g, hi, al, bw):
            print(f"  N={g:5d}: 在 64GB 以内流水线树始终更快")
            continue
        for _ in range(80):                                # 二分找 ring(S) = tree(S)
            mid = (lo * hi) ** 0.5
            lo, hi = (mid, hi) if ring(g, mid, al, bw) > tree_pipelined(g, mid, al, bw) else (lo, mid)
        print(f"  N={g:5d}: 消息 < {lo / 2 ** 20:9.2f} MB 时流水线树更快")
    print("\n[小结] 小消息看 α（轮数），大消息看 β（字节数）；GPU 越多，Ring 的延迟劣势越明显。"
          "\n       分层算法让慢速的节点间链路只承载 1/g 的数据。真实 NCCL 还要考虑协议、通道数、拓扑。"
          "\n[问题库] P23 集合通信算法选择与拓扑感知")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m05_collectives/outputs/lab_02_alpha_beta.txt`）：

```text
# 实测输出：m05_collectives/lab_02_alpha_beta.py
# 运行时间：2026-10-18 21:29，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 扁平算法，256 GPU，α=5.0us，瓶颈带宽 25.0 GB/s ==
        消息        Ring         朴素树        流水线树        递归倍增          分层  最优
       1KB      2.55ms      80.7us      81.3us      40.3us     690.0us  递归倍增
      16KB      2.55ms      90.5us      96.1us      45.2us     690.3us  递归倍增
     256KB      2.57ms     247.8us     175.3us     123.9us     694.1us  递归倍增
       4MB      2.88ms      2.76ms     727.8us      1.38ms     755.1us  流水线树
      64MB      7.90ms     43.03ms      6.71ms     21.51ms      1.73ms  分层
    1024MB     88.11ms    687.27ms     91.05ms    343.64ms     17.36ms  分层

== Ring 与流水线树的交叉点（随 GPU 数变化）==
  N=    8: 消息 <      0.22 MB 时流水线树更快
  N=   64: 消息 <     16.21 MB 时流水线树更快
  N=  512: 消息 <    835.84 MB 时流水线树更快
  N= 4096: 消息 <  41412.35 MB 时流水线树更快

[小结] 小消息看 α（轮数），大消息看 β（字节数）；GPU 越多，Ring 的延迟劣势越明显。
       分层算法让慢速的节点间链路只承载 1/g 的数据。真实 NCCL 还要考虑协议、通道数、拓扑。
[问题库] P23 集合通信算法选择与拓扑感知
```

### `labs/m05_collectives/lab_03_gloo_collectives.py`

```python
"""[M05-L03] 用 torch.distributed（gloo 后端）在单机多进程上实测集合通信

目标：会写最小的多进程分布式程序（init_process_group / all_reduce / all_gather / reduce_scatter /
      all_to_all），验证语义，并按 nccl-tests 的方式计算 algbw / busbw。
先预测：
  1. 4 个进程各持有 [rank]*4，all_reduce(SUM) 后每个进程得到什么？reduce_scatter 呢？
  2. 消息从 4KB 增到 64MB，busbw 怎样变化？为什么小消息 busbw 很低？
可调参数：--world（2~8）、--sizes（元素数）
说明：gloo 走本机回环网络，数值只用来观察趋势，不代表 NCCL/NVLink 性能。
      进程组用文件方式初始化（临时目录），不需要占用固定端口。
暴露的问题：小消息的延迟主导；集合通信语义是并行策略的基础 → PROBLEM_BANK P23
对应论文：PyTorch Distributed（VLDB'20）
真实框架对照：torch/distributed/distributed_c10d.py；NVIDIA/nccl-tests src/common.cu（busbw 计算）
"""
import argparse
import os
import tempfile
import time

import torch
import torch.distributed as dist
import torch.multiprocessing as mp

BUS_FACTOR = {"all_reduce": lambda n: 2 * (n - 1) / n, "all_gather": lambda n: (n - 1) / n,
              "reduce_scatter": lambda n: (n - 1) / n, "all_to_all": lambda n: (n - 1) / n}


def semantics(rank, world):
    x = torch.full((world,), float(rank))
    y = x.clone(); dist.all_reduce(y)
    gathered = [torch.empty(world) for _ in range(world)]; dist.all_gather(gathered, x)
    rs = torch.empty(1); dist.reduce_scatter(rs, list(torch.arange(world, dtype=torch.float32).chunk(world)))
    a2a_in = torch.arange(world, dtype=torch.float32) + 10 * rank
    a2a_out = torch.empty(world); dist.all_to_all_single(a2a_out, a2a_in)
    return y.tolist(), [g[0].item() for g in gathered], rs.item(), a2a_out.tolist()


def bench(op, n_elem, world, reps=5):
    x = torch.ones(n_elem)
    if op == "all_reduce":
        fn = lambda: dist.all_reduce(x)
    elif op == "all_gather":       # 新版 torch 叫 all_gather_single，旧版叫 all_gather_into_tensor
        out = torch.empty(n_elem * world)
        ag = getattr(dist, "all_gather_single", None) or dist.all_gather_into_tensor
        fn = lambda: ag(out, x)
    elif op == "reduce_scatter":
        big = torch.ones(n_elem * world); out = torch.empty(n_elem)
        rs = getattr(dist, "reduce_scatter_single", None) or dist.reduce_scatter_tensor
        fn = lambda: rs(out, big)
    else:
        out = torch.empty(n_elem); fn = lambda: dist.all_to_all_single(out, x)
    fn(); dist.barrier()
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    dist.barrier()
    return (time.perf_counter() - t0) / reps


def worker(rank, world, init_file, sizes, q):
    os.environ.setdefault("GLOO_SOCKET_IFNAME", "lo")      # 只用本机回环
    dist.init_process_group("gloo", init_method=f"file://{init_file}", rank=rank, world_size=world)
    torch.set_num_threads(1)
    res = {"sem": semantics(rank, world), "bench": {}}
    for op in BUS_FACTOR:
        for n in sizes:
            try:
                res["bench"][(op, n)] = bench(op, n, world)
            except RuntimeError as e:                       # 个别算子在 gloo 上不受支持时如实记录
                res["bench"][(op, n)] = f"不支持: {str(e)[:40]}"
    q.put((rank, res))
    dist.destroy_process_group()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--world", type=int, default=4)
    ap.add_argument("--sizes", type=int, nargs="+", default=[1024, 65536, 1 << 20, 1 << 24])
    a = ap.parse_args()
    ctx = mp.get_context("spawn")
    q = ctx.Queue()
    with tempfile.TemporaryDirectory() as d:
        init_file = os.path.join(d, "pg_init")
        procs = [ctx.Process(target=worker, args=(r, a.world, init_file, a.sizes, q)) for r in range(a.world)]
        for p in procs:
            p.start()
        results = dict(q.get() for _ in procs)
        for p in procs:
            p.join()
    print(f"== 语义验证（world={a.world}，rank r 的输入为 [r]*{a.world}）==")
    for r in range(a.world):
        ar, ag, rs, a2a = results[r]["sem"]
        print(f"  rank {r}: all_reduce={ar}  all_gather 首元素={ag}  reduce_scatter={rs}  all_to_all={a2a}")
    print("\n== 性能（gloo/回环，rank0 计时）==")
    print(f"  {'算子':16s} {'大小':>9s} {'耗时':>10s} {'algbw GB/s':>11s} {'busbw GB/s':>11s}")
    for (op, n), t in results[0]["bench"].items():
        if isinstance(t, str):
            print(f"  {op:16s} {n * 4 / 1024:7.0f}KB  {t}")
            continue
        # nccl-tests 约定：all_gather 取输出总大小，reduce_scatter 取输入总大小，其余取单 rank 大小
        S = n * 4 * (a.world if op in ("all_gather", "reduce_scatter") else 1)
        algbw = S / t / 1e9
        print(f"  {op:16s} {n * 4 / 1024:7.0f}KB {t * 1e3:8.2f}ms {algbw:11.3f} {algbw * BUS_FACTOR[op](a.world):11.3f}")
    print("\n[小结] 小消息耗时几乎不随大小变化（延迟主导），大消息时 busbw 逐渐逼近链路带宽上限。"
          "\n       all_to_all 是 MoE 专家并行的核心通信（M08），all_gather/reduce_scatter 是 ZeRO-3/FSDP 的核心（M06）。"
          "\n[问题库] P23 集合通信；P16 ZeRO-3 通信")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m05_collectives/outputs/lab_03_gloo_collectives.txt`）：

```text
# 实测输出：m05_collectives/lab_03_gloo_collectives.py
# 运行时间：2026-10-18 21:29，耗时 5.5s，峰值内存 905MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 语义验证（world=4，rank r 的输入为 [r]*4）==
  rank 0: all_reduce=[6.0, 6.0, 6.0, 6.0]  all_gather 首元素=[0.0, 1.0, 2.0, 3.0]  reduce_scatter=0.0  all_to_all=[0.0, 10.0, 20.0, 30.0]
  rank 1: all_reduce=[6.0, 6.0, 6.0, 6.0]  all_gather 首元素=[0.0, 1.0, 2.0, 3.0]  reduce_scatter=4.0  all_to_all=[1.0, 11.0, 21.0, 31.0]
  rank 2: all_reduce=[6.0, 6.0, 6.0, 6.0]  all_gather 首元素=[0.0, 1.0, 2.0, 3.0]  reduce_scatter=8.0  all_to_all=[2.0, 12.0, 22.0, 32.0]
  rank 3: all_reduce=[6.0, 6.0, 6.0, 6.0]  all_gather 首元素=[0.0, 1.0, 2.0, 3.0]  reduce_scatter=12.0  all_to_all=[3.0, 13.0, 23.0, 33.0]

== 性能（gloo/回环，rank0 计时）==
  算子                      大小         耗时  algbw GB/s  busbw GB/s
  all_reduce             4KB     0.90ms       0.005       0.007
  all_reduce           256KB     1.09ms       0.241       0.362
  all_reduce          4096KB     3.19ms       1.313       1.970
  all_reduce         65536KB    37.20ms       1.804       2.706
  all_gather             4KB     0.73ms       0.022       0.017
  all_gather           256KB     0.98ms       1.070       0.803
  all_gather          4096KB     8.65ms       1.939       1.454
  all_gather         65536KB   167.56ms       1.602       1.202
  reduce_scatter         4KB     1.00ms       0.016       0.012
  reduce_scatter       256KB     1.43ms       0.734       0.551
  reduce_scatter      4096KB    11.74ms       1.429       1.072
  reduce_scatter     65536KB   222.38ms       1.207       0.905
  all_to_all             4KB     0.42ms       0.010       0.007
  all_to_all           256KB     0.42ms       0.630       0.472
  all_to_all          4096KB     1.42ms       2.954       2.216
  all_to_all         65536KB    18.43ms       3.641       2.731

[小结] 小消息耗时几乎不随大小变化（延迟主导），大消息时 busbw 逐渐逼近链路带宽上限。
       all_to_all 是 MoE 专家并行的核心通信（M08），all_gather/reduce_scatter 是 ZeRO-3/FSDP 的核心（M06）。
[问题库] P23 集合通信；P16 ZeRO-3 通信
```

## M06 数据并行：DDP、梯度分桶、通信与计算重叠、ZeRO 1/2/3、FSDP（`labs/m06_data_parallel/`）

### `labs/m06_data_parallel/lab_01_ddp_bucketing.py`

```python
"""[M06-L01] 手写数据并行（DDP）：梯度 AllReduce 与分桶（bucketing）

目标：用 gloo 多进程实现最小 DDP：每个 rank 算自己那份数据的梯度，AllReduce 求平均后更新；
      验证结果与单进程大批量训练一致；比较"逐参数 AllReduce"与"按桶 AllReduce"的通信次数与耗时；
      最后用官方 DistributedDataParallel 对照。
先预测：
  1. 4 个 rank 各 16 条样本的 DDP，与单进程 64 条样本训练，参数会完全一样吗？
  2. 模型有 50 个参数张量，逐参数 AllReduce 要发起多少次通信？桶大小 1MB 时呢？
可调参数：--world、--layers、--width、--bucket-mb（列表）
暴露的问题：通信次数（α 开销）与重叠时机的取舍 → PROBLEM_BANK P17
对应论文：PyTorch Distributed（VLDB'20，梯度分桶与重叠，默认桶 25MB）
真实框架对照：torch/nn/parallel/distributed.py；torch/csrc/distributed/c10d/reducer.cpp（Reducer 分桶）
"""
import argparse
import os
import tempfile
import time

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
import torch.nn as nn


def make_model(layers, width):
    torch.manual_seed(0)
    return nn.Sequential(*[m for _ in range(layers) for m in (nn.Linear(width, width), nn.Tanh())])


def make_data(n, width):
    g = torch.Generator().manual_seed(1)
    return torch.randn(n, width, generator=g), torch.randn(n, width, generator=g)


def allreduce_grads(model, world, bucket_bytes):
    """bucket_bytes=0：逐参数通信；否则把梯度拼成扁平桶再通信。返回通信次数。"""
    grads = [p.grad for p in model.parameters()][::-1]        # 反向时梯度从后往前就绪
    calls = 0
    if bucket_bytes == 0:
        for g in grads:
            dist.all_reduce(g); g /= world; calls += 1
        return calls
    bucket, size = [], 0
    for i, g in enumerate(grads):
        bucket.append(g); size += g.numel() * g.element_size()
        if size >= bucket_bytes or i == len(grads) - 1:
            flat = torch.cat([b.reshape(-1) for b in bucket])
            dist.all_reduce(flat); flat /= world; calls += 1
            off = 0
            for b in bucket:                                   # 拆回各参数
                b.copy_(flat[off:off + b.numel()].view_as(b)); off += b.numel()
            bucket, size = [], 0
    return calls


def worker(rank, world, init_file, a, q):
    os.environ.setdefault("GLOO_SOCKET_IFNAME", "lo")
    dist.init_process_group("gloo", init_method=f"file://{init_file}", rank=rank, world_size=world)
    torch.set_num_threads(1)
    X, Y = make_data(a.batch * world, a.width)
    xs, ys = X[rank::world], Y[rank::world]                    # 数据切分
    res = {}
    for bucket_mb in a.bucket_mb:
        model = make_model(a.layers, a.width)
        opt = torch.optim.SGD(model.parameters(), lr=0.05)
        t_comm = 0.0
        for _ in range(a.steps):
            opt.zero_grad()
            nn.functional.mse_loss(model(xs), ys).backward()
            t0 = time.perf_counter()
            calls = allreduce_grads(model, world, int(bucket_mb * 2 ** 20))
            t_comm += time.perf_counter() - t0
            opt.step()
        res[bucket_mb] = (calls, t_comm / a.steps, [p.detach().numpy().copy() for p in model.parameters()])
    # 官方 DDP 对照
    model = make_model(a.layers, a.width)
    ddp = nn.parallel.DistributedDataParallel(model, bucket_cap_mb=25)
    opt = torch.optim.SGD(ddp.parameters(), lr=0.05)
    for _ in range(a.steps):
        opt.zero_grad(); nn.functional.mse_loss(ddp(xs), ys).backward(); opt.step()
    res["ddp"] = [p.detach().numpy().copy() for p in model.parameters()]  # numpy 按值序列化，避免共享内存句柄失效
    if rank == 0:
        q.put(res)
    dist.destroy_process_group()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--world", type=int, default=4)
    ap.add_argument("--layers", type=int, default=25)
    ap.add_argument("--width", type=int, default=128)
    ap.add_argument("--batch", type=int, default=16, help="每个 rank 的样本数")
    ap.add_argument("--steps", type=int, default=5)
    ap.add_argument("--bucket-mb", type=float, nargs="+", default=[0, 0.25, 1, 25])
    a = ap.parse_args()

    # 单进程基准：全部样本一起训练
    model = make_model(a.layers, a.width)
    opt = torch.optim.SGD(model.parameters(), lr=0.05)
    X, Y = make_data(a.batch * a.world, a.width)
    for _ in range(a.steps):
        opt.zero_grad(); nn.functional.mse_loss(model(X), Y).backward(); opt.step()
    ref = [p.detach() for p in model.parameters()]
    n_par = sum(p.numel() for p in ref)

    ctx = mp.get_context("spawn"); q = ctx.Queue()
    with tempfile.TemporaryDirectory() as d:
        ps = [ctx.Process(target=worker, args=(r, a.world, os.path.join(d, "init"), a, q)) for r in range(a.world)]
        [p.start() for p in ps]
        res = q.get()
        [p.join() for p in ps]
    print(f"== {a.world} 个 rank，{len(ref)} 个参数张量，共 {n_par * 4 / 2 ** 20:.2f} MB 梯度 ==")
    print(f"  {'桶大小':>8s} {'通信次数/步':>10s} {'通信耗时/步':>11s} {'与单进程最大差':>14s}")
    for b in a.bucket_mb:
        calls, t, params = res[b]
        diff = max(abs(u - v.numpy()).max() for u, v in zip(params, ref))
        print(f"  {('逐参数' if b == 0 else f'{b}MB'):>8s} {calls:10d} {t * 1e3:9.2f}ms {diff:14.2e}")
    diff = max(abs(u - v.numpy()).max() for u, v in zip(res["ddp"], ref))
    print(f"  官方 DDP(25MB) 与单进程最大差 {diff:.2e}")
    print("\n[小结] 数据并行在数学上等价于大批量训练（损失按均值归约时梯度取平均）。分桶减少通信次数，"
          "\n       摊薄每次通信的固定延迟；官方 DDP 还会在反向过程中、桶一满就异步发起通信以重叠计算（lab_03）。"
          "\n[问题库] P17 梯度同步的分桶与重叠调参")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m06_data_parallel/outputs/lab_01_ddp_bucketing.txt`）：

```text
# 实测输出：m06_data_parallel/lab_01_ddp_bucketing.py
# 运行时间：2026-10-18 21:29，耗时 4.3s，峰值内存 333MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 4 个 rank，50 个参数张量，共 1.57 MB 梯度 ==
       桶大小     通信次数/步      通信耗时/步        与单进程最大差
       逐参数         50     52.63ms       7.45e-09
    0.25MB          7      9.02ms       7.45e-09
       1MB          2      3.85ms       7.45e-09
      25MB          1      2.66ms       7.45e-09
  官方 DDP(25MB) 与单进程最大差 7.45e-09

[小结] 数据并行在数学上等价于大批量训练（损失按均值归约时梯度取平均）。分桶减少通信次数，
       摊薄每次通信的固定延迟；官方 DDP 还会在反向过程中、桶一满就异步发起通信以重叠计算（lab_03）。
[问题库] P17 梯度同步的分桶与重叠调参
```

### `labs/m06_data_parallel/lab_02_zero_sim.py`

```python
"""[M06-L02] ZeRO-1/2/3 模拟器：在单进程里用 N 个虚拟 rank 实现分片优化器

目标：亲手实现 ZeRO 的核心步骤——梯度 ReduceScatter、只更新本 rank 的分片、参数 AllGather；
      验证与普通数据并行（DDP）训练结果一致，并统计每个 rank 的显存与通信量。
先预测：
  1. ZeRO-1/2 每步通信量和 DDP 相比是多少？ZeRO-3 呢？
  2. N=8 时，每个 rank 的 Adam 状态是 DDP 的几分之一？
可调参数：--ranks、--steps、--hidden
暴露的问题：ZeRO-3 的额外 AllGather 若不能与计算重叠就会拖慢训练 → PROBLEM_BANK P16
对应论文：ZeRO（1910.02054）；PyTorch FSDP（VLDB'23）；ZeRO++（2306.10209，压缩通信）
真实框架对照：deepspeed/runtime/zero/stage_1_and_2.py、stage3.py；
              torch/distributed/fsdp/_fully_shard/（FSDP2）
"""
import argparse

import torch


def model_fn(flat, x, shapes):
    """把扁平参数向量还原成两层 MLP 再前向（模拟 ZeRO-3 中"用到时再拼回完整参数"）。"""
    ws, off = [], 0
    for s in shapes:
        n = s[0] * s[1]; ws.append(flat[off:off + n].view(s)); off += n
    return torch.tanh(x @ ws[0]) @ ws[1]


def adam_update(p, g, st, lr=1e-2, b1=0.9, b2=0.999, eps=1e-8):
    st["t"] += 1
    st["m"].mul_(b1).add_(g, alpha=1 - b1)
    st["v"].mul_(b2).addcmul_(g, g, value=1 - b2)
    mh = st["m"] / (1 - b1 ** st["t"]); vh = st["v"] / (1 - b2 ** st["t"])
    p -= lr * mh / (vh.sqrt() + eps)


def grads_per_rank(flat, data, shapes):
    gs = []
    for x, y in data:
        p = flat.detach().clone().requires_grad_(True)
        ((model_fn(p, x, shapes) - y) ** 2).mean().backward()
        gs.append(p.grad)
    return gs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, default=8)
    ap.add_argument("--steps", type=int, default=10)
    ap.add_argument("--hidden", type=int, default=256)
    a = ap.parse_args()
    N = a.ranks
    torch.manual_seed(0)
    shapes = [(64, a.hidden), (a.hidden, 8)]
    P = sum(s[0] * s[1] for s in shapes)
    P += (-P) % N                                       # 补齐到 N 的整数倍，便于均分
    init = torch.randn(P) * 0.1
    data = [(torch.randn(16, 64), torch.randn(16, 8)) for _ in range(N)]

    # 基线：DDP —— 每个 rank 持有完整参数与完整 Adam 状态，梯度 AllReduce
    ddp = init.clone(); st = {"m": torch.zeros(P), "v": torch.zeros(P), "t": 0}
    for _ in range(a.steps):
        g = torch.stack(grads_per_rank(ddp, data, shapes)).mean(0)   # AllReduce(平均)
        adam_update(ddp, g, st)

    # ZeRO：rank r 只负责分片 r 的优化器状态（ZeRO-1/2）或连参数也只存分片（ZeRO-3）
    shard = P // N
    params = [init[r * shard:(r + 1) * shard].clone() for r in range(N)]
    states = [{"m": torch.zeros(shard), "v": torch.zeros(shard), "t": 0} for _ in range(N)]
    for _ in range(a.steps):
        full = torch.cat(params)                                     # AllGather 参数
        gs = grads_per_rank(full, data, shapes)
        for r in range(N):                                           # ReduceScatter 梯度
            g_shard = torch.stack([g[r * shard:(r + 1) * shard] for g in gs]).mean(0)
            adam_update(params[r], g_shard, states[r])
    diff = (torch.cat(params) - ddp).abs().max().item()
    print(f"== {N} 个虚拟 rank，参数 {P} 个，训练 {a.steps} 步 ==")
    print(f"  ZeRO 分片训练 vs DDP 最大参数差 = {diff:.2e}（应接近 0）")

    B = 2  # BF16 字节；混合精度下的显存/通信账本，单位：Ψ 的倍数
    print("\n== 每 rank 显存（混合精度 Adam，单位：字节/参数 × Ψ）==")
    rows = {"DDP": 2 + 2 + 12, "ZeRO-1": 2 + 2 + 12 / N, "ZeRO-2": 2 + (2 + 12) / N, "ZeRO-3": 16 / N}
    for k, v in rows.items():
        print(f"  {k:7s} {v:6.2f}Ψ")
    print("\n== 每 rank 每步通信量（单位：Ψ 个 BF16 元素，Ring 算法近似）==")
    comm = {"DDP": "AllReduce(梯度) = 2Ψ", "ZeRO-1/2": "ReduceScatter(梯度) Ψ + AllGather(参数) Ψ = 2Ψ",
            "ZeRO-3": "前向 AllGather Ψ + 反向 AllGather Ψ + ReduceScatter Ψ = 3Ψ"}
    for k, v in comm.items():
        print(f"  {k:9s} {v}")
    print(f"\n  具体到本例：Ψ={P}，BF16 时 ZeRO-3 每步每 rank 约收发 {3 * P * B * (N - 1) / N / 1024:.1f} KB")
    print("\n[小结] ZeRO-1/2 在不增加通信量的前提下把优化器状态/梯度切成 N 份；ZeRO-3 再切参数，"
          "\n       代价是多 50% 通信且每层都要在用之前 AllGather——能否与计算重叠决定了它的实际速度。"
          "\n[问题库] P16 ZeRO-3/FSDP 通信重叠；P14 显存墙")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m06_data_parallel/outputs/lab_02_zero_sim.txt`）：

```text
# 实测输出：m06_data_parallel/lab_02_zero_sim.py
# 运行时间：2026-10-18 21:29，耗时 1.1s，峰值内存 236MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 8 个虚拟 rank，参数 18432 个，训练 10 步 ==
  ZeRO 分片训练 vs DDP 最大参数差 = 0.00e+00（应接近 0）

== 每 rank 显存（混合精度 Adam，单位：字节/参数 × Ψ）==
  DDP      16.00Ψ
  ZeRO-1    5.50Ψ
  ZeRO-2    3.75Ψ
  ZeRO-3    2.00Ψ

== 每 rank 每步通信量（单位：Ψ 个 BF16 元素，Ring 算法近似）==
  DDP       AllReduce(梯度) = 2Ψ
  ZeRO-1/2  ReduceScatter(梯度) Ψ + AllGather(参数) Ψ = 2Ψ
  ZeRO-3    前向 AllGather Ψ + 反向 AllGather Ψ + ReduceScatter Ψ = 3Ψ

  具体到本例：Ψ=18432，BF16 时 ZeRO-3 每步每 rank 约收发 94.5 KB

[小结] ZeRO-1/2 在不增加通信量的前提下把优化器状态/梯度切成 N 份；ZeRO-3 再切参数，
       代价是多 50% 通信且每层都要在用之前 AllGather——能否与计算重叠决定了它的实际速度。
[问题库] P16 ZeRO-3/FSDP 通信重叠；P14 显存墙
```

### `labs/m06_data_parallel/lab_03_overlap_sim.py`

```python
"""[M06-L03] 反向计算与梯度通信的重叠：分桶大小的离散事件模拟

目标：模拟反向传播逐层产出梯度、桶满即在通信流上发起 AllReduce 的过程，
      扫描桶大小，找到最优点；理解"桶太小 α 开销大、桶太大重叠不足"。
先预测：
  1. 桶大小从 1MB 增到 1GB，单步时间会单调变化吗？
  2. 若总通信时间大于总反向计算时间，再怎么调桶大小，单步时间至少是多少？
可调参数：--layers、--layer-mb、--layer-ms、--bw（GB/s）、--alpha-us、--world
暴露的问题：重叠调参依赖模型与网络，自动化调参是研究点 → PROBLEM_BANK P17
对应论文：PyTorch Distributed（VLDB'20 图 7/8 讨论桶大小）；Horovod（Tensor Fusion）
"""
import argparse


def simulate(layer_bytes, layer_ms, bucket_bytes, world, bw, alpha):
    """返回 (单步时间 ms, 通信次数, 暴露的通信时间 ms)。前向时间不计入（对所有配置相同）。"""
    t, comm_free, size, calls = 0.0, 0.0, 0, 0
    ring = 2 * (world - 1) / world

    def launch(nbytes, ready):
        nonlocal comm_free, calls
        start = max(ready, comm_free)                  # 通信流串行：等上一次通信完成
        comm_free = start + alpha + ring * nbytes / bw
        calls += 1
    for lb, lm in zip(layer_bytes, layer_ms):          # 反向：从最后一层到第一层
        t += lm
        size += lb
        if size >= bucket_bytes:
            launch(size, t); size = 0
    if size:
        launch(size, t)
    step = max(t, comm_free)
    return step, calls, step - t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", type=int, default=48)
    ap.add_argument("--layer-mb", type=float, default=24.0, help="每层大张量梯度合计 MB")
    ap.add_argument("--small-per-layer", type=int, default=6, help="每层的小张量个数（bias/norm 等，各 16KB）")
    ap.add_argument("--layer-ms", type=float, default=2.5, help="每层反向计算时间")
    ap.add_argument("--bw", type=float, default=25.0, help="GB/s")
    ap.add_argument("--alpha-us", type=float, default=200.0, help="每次集合通信的固定开销")
    ap.add_argument("--world", type=int, default=64)
    a = ap.parse_args()
    # 每层 = 4 个大张量 + 若干小张量；反向计算时间按张量均摊（简化）
    per = [a.layer_mb * 2 ** 20 / 4] * 4 + [16 * 1024] * a.small_per_layer
    lb = per * a.layers
    lm = [a.layer_ms / len(per)] * len(lb)
    bw, al = a.bw * 1e9 / 1e3, a.alpha_us / 1e3        # 换算到 字节/ms 与 ms
    comp = sum(lm)
    comm_total = 2 * (a.world - 1) / a.world * sum(lb) / bw
    print(f"== {len(lb)} 个梯度张量；反向计算 {comp:.0f} ms；梯度共 {sum(lb) / 2 ** 30:.2f} GB；"
          f"纯通信（无 α）{comm_total:.0f} ms ==")
    print(f"  {'桶大小':>9s} {'单步(ms)':>9s} {'通信次数':>8s} {'暴露通信(ms)':>12s}")
    best = None
    for mb in [0, 1, 4, 16, 25, 64, 256, 1024, 4096]:
        step, calls, exposed = simulate(lb, lm, mb * 2 ** 20, a.world, bw, al)
        best = min(best or (step, mb), (step, mb))
        print(f"  {('逐张量' if mb == 0 else f'{mb}MB'):>9s} {step:9.1f} {calls:8d} {exposed:12.1f}")
    print(f"  最优桶 ≈ {best[1]} MB，单步 {best[0]:.1f} ms；下界 = max(计算, 通信) = {max(comp, comm_total):.1f} ms")

    print("\n== 网络变慢时（带宽 / 4）==")
    for mb in [25, 256]:
        step, calls, exposed = simulate(lb, lm, mb * 2 ** 20, a.world, bw / 4, al)
        print(f"  {mb:5d}MB 单步 {step:7.1f} ms，暴露通信 {exposed:6.1f} ms")
    print("\n[小结] 桶太小：通信次数多，α 累积；桶太大：要等很多层算完才发起通信，最后一个桶无法被隐藏。"
          "\n       通信总量超过计算总量时，重叠只能把时间压到通信时间——需要压缩通信或换并行策略。"
          "\n[问题库] P17 分桶与重叠调参；P16 ZeRO-3 通信重叠")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m06_data_parallel/outputs/lab_03_overlap_sim.txt`）：

```text
# 实测输出：m06_data_parallel/lab_03_overlap_sim.py
# 运行时间：2026-10-18 21:29，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 480 个梯度张量；反向计算 120 ms；梯度共 1.13 GB；纯通信（无 α）95 ms ==
        桶大小    单步(ms)     通信次数     暴露通信(ms)
        逐张量     191.7      480         71.7
        1MB     134.3      193         14.3
        4MB     134.3      193         14.3
       16MB     121.3       65          1.3
       25MB     121.9       39          1.9
       64MB     124.1       18          4.1
      256MB     137.7        5         17.7
     1024MB     201.6        2         81.6
     4096MB     215.7        1         95.7
  最优桶 ≈ 16 MB，单步 121.3 ms；下界 = max(计算, 通信) = 120.0 ms

== 网络变慢时（带宽 / 4）==
     25MB 单步   392.5 ms，暴露通信  272.5 ms
    256MB 单步   408.7 ms，暴露通信  288.7 ms

[小结] 桶太小：通信次数多，α 累积；桶太大：要等很多层算完才发起通信，最后一个桶无法被隐藏。
       通信总量超过计算总量时，重叠只能把时间压到通信时间——需要压缩通信或换并行策略。
[问题库] P17 分桶与重叠调参；P16 ZeRO-3 通信重叠
```

## M07 模型并行：张量并行、流水线并行、序列/上下文并行、3D 并行配置（`labs/m07_model_parallel/`）

### `labs/m07_model_parallel/lab_01_tensor_parallel.py`

```python
"""[M07-L01] 张量并行（Tensor Parallelism, TP）：Megatron 式列切分 + 行切分

目标：在单进程中用 t 个"虚拟 rank"实现 Megatron MLP 与注意力的张量并行，验证前向输出和
      参数梯度与不切分时一致；计算每层的通信量与通信/计算比，理解为什么 TP 通常只放在节点内。
先预测：
  1. MLP 的第一个矩阵 A 按列切、第二个矩阵 B 按行切，前向需要几次 AllReduce？为什么 GeLU 不需要通信？
  2. hidden=8192、t=8 时，每层每 token 的通信字节和计算 FLOPs 之比大约是多少？
可调参数：--tp、--hidden、--heads、--seq
暴露的问题：TP 通信量随 batch×seq×hidden 增长，跨节点时成为瓶颈 → PROBLEM_BANK P19
对应论文：Megatron-LM（1909.08053 图 3）；Reducing Activation Recomputation（序列并行 SP）
真实框架对照：Megatron-LM megatron/core/tensor_parallel/layers.py
              （ColumnParallelLinear / RowParallelLinear）、mappings.py（f/g 共轭算子）
"""
import argparse

import torch


def mlp_ref(x, A, B):
    return torch.nn.functional.gelu(x @ A) @ B


def mlp_tp(x, A, B, t):
    As = A.chunk(t, dim=1)            # 列切分：每个 rank 得到 A 的一部分列
    Bs = B.chunk(t, dim=0)            # 行切分：与 A 的列对应
    partial = [torch.nn.functional.gelu(x @ Ai) @ Bi for Ai, Bi in zip(As, Bs)]  # 各 rank 独立计算
    return sum(partial)               # 这里的求和 = 一次 AllReduce（Megatron 中的 g 算子）


def attn_ref(x, Wq, Wk, Wv, Wo, heads):
    s, h = x.shape
    d = h // heads
    q, k, v = (x @ W for W in (Wq, Wk, Wv))
    q, k, v = (t.view(s, heads, d).transpose(0, 1) for t in (q, k, v))
    o = torch.softmax(q @ k.transpose(1, 2) / d ** 0.5, dim=-1) @ v
    return o.transpose(0, 1).reshape(s, h) @ Wo


def attn_tp(x, Wq, Wk, Wv, Wo, heads, t):
    """按头切分：每个 rank 负责 heads/t 个头，Q/K/V 列切，输出投影 Wo 行切，最后 AllReduce。"""
    out = 0
    for r in range(t):
        cols = slice(r * x.shape[1] // t, (r + 1) * x.shape[1] // t)
        out = out + attn_ref_part(x, Wq[:, cols], Wk[:, cols], Wv[:, cols], Wo[cols, :], heads // t)
    return out


def attn_ref_part(x, Wq, Wk, Wv, Wo, local_heads):
    s = x.shape[0]
    d = Wq.shape[1] // local_heads
    q, k, v = (x @ W for W in (Wq, Wk, Wv))
    q, k, v = (t.view(s, local_heads, d).transpose(0, 1) for t in (q, k, v))
    o = torch.softmax(q @ k.transpose(1, 2) / d ** 0.5, dim=-1) @ v
    return o.transpose(0, 1).reshape(s, -1) @ Wo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tp", type=int, default=4)
    ap.add_argument("--hidden", type=int, default=256)
    ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--seq", type=int, default=64)
    a = ap.parse_args()
    torch.manual_seed(0)
    h = a.hidden
    x = torch.randn(a.seq, h, dtype=torch.float64)
    A = torch.randn(h, 4 * h, dtype=torch.float64, requires_grad=True)
    B = torch.randn(4 * h, h, dtype=torch.float64, requires_grad=True)

    print(f"== MLP 张量并行（t={a.tp}）==")
    y_ref = mlp_ref(x, A, B); y_ref.sum().backward()
    gA, gB = A.grad.clone(), B.grad.clone(); A.grad = B.grad = None
    y_tp = mlp_tp(x, A, B, a.tp); y_tp.sum().backward()
    print(f"  前向 max|差| = {(y_ref - y_tp).abs().max().item():.2e}")
    print(f"  dA max|差| = {(gA - A.grad).abs().max().item():.2e}，dB max|差| = {(gB - B.grad).abs().max().item():.2e}")

    print(f"\n== 注意力张量并行（按头切分，{a.heads} 头 / t={a.tp}）==")
    W = [torch.randn(h, h, dtype=torch.float64) / h ** 0.5 for _ in range(4)]
    print(f"  前向 max|差| = {(attn_ref(x, *W, a.heads) - attn_tp(x, *W, a.heads, a.tp)).abs().max().item():.2e}")

    print("\n== 每层通信 vs 计算（BF16，一个 Transformer 层，前向+反向）==")
    print(f"  {'hidden':>6s} {'t':>3s} {'每token通信字节':>14s} {'每token每卡FLOPs':>16s} {'FLOPs/字节':>10s}")
    for hid in [4096, 8192, 16384]:
        for t in [2, 8]:
            # 前向 2 次 AllReduce + 反向 2 次，每次消息 h×2 字节/token，Ring 每卡收发 2(t-1)/t 倍
            comm = 4 * 2 * (t - 1) / t * hid * 2
            flops = 3 * 2 * 12 * hid * hid / t          # 前向 2·12h²（注意力投影 4h² + MLP 8h²），反向 ×2
            print(f"  {hid:6d} {t:3d} {comm:14.0f} {flops:16.3e} {flops / comm:10.0f}")
    print("  对比：H100 BF16 989 TFLOPS，NVLink ~450GB/s 单向 → 需要 >2200 FLOP/B 才能藏住通信；"
          "\n        跨节点 IB ~25-50GB/s/卡 → 需要 >20000 FLOP/B。")
    print("\n[小结] 列切+行切让中间的非线性无需通信，每个 MLP/注意力块前向只需 1 次 AllReduce。"
          "\n       但 FLOPs/字节 ≈ h/t 量级，t 越大越不划算，跨节点几乎一定被通信拖垮，所以 TP≤8 放在节点内。"
          "\n[问题库] P19 并行配置搜索；P23 通信拓扑")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m07_model_parallel/outputs/lab_01_tensor_parallel.txt`）：

```text
# 实测输出：m07_model_parallel/lab_01_tensor_parallel.py
# 运行时间：2026-10-18 21:29，耗时 1.0s，峰值内存 254MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== MLP 张量并行（t=4）==
  前向 max|差| = 0.00e+00
  dA max|差| = 0.00e+00，dB max|差| = 0.00e+00

== 注意力张量并行（按头切分，8 头 / t=4）==
  前向 max|差| = 8.88e-16

== 每层通信 vs 计算（BF16，一个 Transformer 层，前向+反向）==
  hidden   t     每token通信字节    每token每卡FLOPs   FLOPs/字节
    4096   2          32768        6.040e+08      18432
    4096   8          57344        1.510e+08       2633
    8192   2          65536        2.416e+09      36864
    8192   8         114688        6.040e+08       5266
   16384   2         131072        9.664e+09      73728
   16384   8         229376        2.416e+09      10533
  对比：H100 BF16 989 TFLOPS，NVLink ~450GB/s 单向 → 需要 >2200 FLOP/B 才能藏住通信；
        跨节点 IB ~25-50GB/s/卡 → 需要 >20000 FLOP/B。

[小结] 列切+行切让中间的非线性无需通信，每个 MLP/注意力块前向只需 1 次 AllReduce。
       但 FLOPs/字节 ≈ h/t 量级，t 越大越不划算，跨节点几乎一定被通信拖垮，所以 TP≤8 放在节点内。
[问题库] P19 并行配置搜索；P23 通信拓扑
```

### `labs/m07_model_parallel/lab_02_pipeline_sim.py`

```python
"""[M07-L02] 流水线并行调度模拟器：GPipe / 1F1B / 交错式 1F1B（interleaved）

目标：生成各调度在每个 stage 上的执行顺序，按依赖关系做离散事件模拟，画出 ASCII 时间线，
      计算气泡率（bubble ratio）与每个 stage 的峰值在途微批数（决定激活显存），并与公式对照：
      GPipe/1F1B 气泡 = (p-1)/(m+p-1)（占总时间），交错式约为 (p-1)/(v·m + p-1)。
先预测：
  1. p=4、m=8 时，GPipe 和 1F1B 的气泡率一样吗？峰值激活一样吗？
  2. 交错式把每个 stage 拆成 v=2 个虚拟 stage，气泡减少多少？代价是什么？
可调参数：--p（stage 数）、--m（微批数，需为 p 的倍数）、--v（交错块数）、--fb（反向/前向耗时比）
暴露的问题：气泡、阶段不均衡、激活显存 → PROBLEM_BANK P18
对应论文：GPipe（1811.06965）；PipeDream（1F1B）；Megatron 3D（交错式，SC'21）；
          Zero Bubble（2401.10241，拆分 B/W 进一步消除气泡）；DeepSeek-V3（DualPipe）
真实框架对照：Megatron-LM megatron/core/pipeline_parallel/schedules.py
             （forward_backward_pipelining_with_interleaving）
"""
import argparse


def schedule(kind, p, m, v):
    """返回每个设备的操作序列 [(F|B, 微批, 块号)]。块号 c 对应虚拟 stage c*p + s。"""
    plans = []
    for s in range(p):
        if kind == "gpipe":
            ops = [("F", i, 0) for i in range(m)] + [("B", i, 0) for i in reversed(range(m))]
        elif kind == "1f1b":
            warm = min(p - s - 1, m)
            ops = [("F", i, 0) for i in range(warm)]
            f, b = warm, 0
            while b < m:
                if f < m:
                    ops.append(("F", f, 0)); f += 1
                ops.append(("B", b, 0)); b += 1
        else:  # 交错式：沿用 Megatron 的微批/块编号规则（要求 m % p == 0）
            total = m * v

            def fwd_id(k):
                return ("F", (k // (p * v)) * p + k % p, (k // p) % v)

            def bwd_id(k):
                return ("B", (k // (p * v)) * p + k % p, v - 1 - (k // p) % v)
            warm = min((p - s - 1) * 2 + (v - 1) * p, total)
            ops = [fwd_id(k) for k in range(warm)]
            f, b = warm, 0
            while b < total:
                if f < total:
                    ops.append(fwd_id(f)); f += 1
                ops.append(bwd_id(b)); b += 1
        plans.append(ops)
    return plans


def simulate(plans, p, v, fb):
    tf, tb = 1.0 / v, fb / v                 # 每个块只含 1/v 的层
    done, free, pos = {}, [0.0] * p, [0] * p
    timeline = [[] for _ in range(p)]
    last_vs = p * v - 1
    while any(pos[s] < len(plans[s]) for s in range(p)):
        progressed = False
        for s in range(p):
            if pos[s] >= len(plans[s]):
                continue
            op, mb, c = plans[s][pos[s]]
            vs = c * p + s
            if op == "F":
                dep = ("F", mb, vs - 1) if vs > 0 else None
            else:
                dep = ("B", mb, vs + 1) if vs < last_vs else ("F", mb, vs)
            if dep is not None and dep not in done:
                continue
            start = max(free[s], done.get(dep, 0.0))
            end = start + (tf if op == "F" else tb)
            done[(op, mb, vs)] = end
            free[s] = end
            timeline[s].append((start, end, op, mb, c))
            pos[s] += 1
            progressed = True
        if not progressed:
            raise RuntimeError("调度死锁：检查 m 是否为 p 的倍数")
    return timeline


def report(kind, p, m, v, fb, draw):
    tl = simulate(schedule(kind, p, m, v), p, v, fb)
    makespan = max(e for row in tl for (_, e, *_r) in row)
    busy = m * (1 + fb)                      # 每个设备的有效工作量
    bubble = 1 - busy / makespan
    peaks = []
    for row in tl:
        live = peak = 0
        for (_, _, op, _, _) in row:
            live += 1 if op == "F" else -1
            peak = max(peak, live)
        peaks.append(peak / v)               # 以"完整微批的激活"为单位
    theo = (p - 1) / (v * m + p - 1) if kind == "interleaved" else (p - 1) / (m + p - 1)
    name = f"{kind}(v={v})" if kind == "interleaved" else kind
    print(f"  {name:16s} 总时长={makespan:6.2f}  气泡率={bubble:6.1%}  理论≈{theo:6.1%}  "
          f"各stage峰值在途微批={[round(x, 1) for x in peaks]}")
    if draw:
        scale = 2 * v
        for s, row in enumerate(tl):
            line = [" "] * int(makespan * scale + 1)
            for (st, en, op, mb, c) in row:
                ch = str(mb % 10) if op == "F" else "abcdefghij"[mb % 10]
                for x in range(int(st * scale), int(en * scale)):
                    line[x] = ch
            print(f"    stage{s} |{''.join(line)}|")
        print("    （数字=前向的微批号，字母=反向的微批号，空格=气泡；交错式中同一微批在每个设备上出现 v 次，对应不同块）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--p", type=int, default=4)
    ap.add_argument("--m", type=int, default=8)
    ap.add_argument("--v", type=int, default=2)
    ap.add_argument("--fb", type=float, default=2.0, help="反向耗时/前向耗时")
    a = ap.parse_args()
    print(f"== p={a.p} stage，m={a.m} 微批，B/F={a.fb} ==")
    for kind in ["gpipe", "1f1b", "interleaved"]:
        report(kind, a.p, a.m, a.v if kind == "interleaved" else 1, a.fb, draw=True)
    print("\n== 扫描：微批数 m 对气泡率的影响（p=8）==")
    for m in [8, 16, 32, 64]:
        print(f"  -- m={m}")
        report("1f1b", 8, m, 1, a.fb, draw=False)
        report("interleaved", 8, m, 4, a.fb, draw=False)
    print("\n[小结] 1F1B 与 GPipe 气泡相同，但峰值激活从 m 降到 p-s；交错式把气泡再降 v 倍，代价是 v 倍的"
          "\n       点对点通信次数。增大 m 能摊薄气泡，但全局 batch 受收敛性约束——这是真实系统的矛盾。"
          "\n[问题库] P18 流水线气泡与阶段不均衡")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m07_model_parallel/outputs/lab_02_pipeline_sim.txt`）：

```text
# 实测输出：m07_model_parallel/lab_02_pipeline_sim.py
# 运行时间：2026-10-18 21:29，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== p=4 stage，m=8 微批，B/F=2.0 ==
  gpipe            总时长= 33.00  气泡率= 27.3%  理论≈ 27.3%  各stage峰值在途微批=[8.0, 8.0, 8.0, 8.0]
    stage0 |0011223344556677                  hhhhggggffffeeeeddddccccbbbbaaaa |
    stage1 |  0011223344556677            hhhhggggffffeeeeddddccccbbbbaaaa     |
    stage2 |    0011223344556677      hhhhggggffffeeeeddddccccbbbbaaaa         |
    stage3 |      0011223344556677hhhhggggffffeeeeddddccccbbbbaaaa             |
    （数字=前向的微批号，字母=反向的微批号，空格=气泡；交错式中同一微批在每个设备上出现 v 次，对应不同块）
  1f1b             总时长= 33.00  气泡率= 27.3%  理论≈ 27.3%  各stage峰值在途微批=[4.0, 3.0, 2.0, 1.0]
    stage0 |00112233            aaaa44bbbb55cccc66dddd77eeee  ffff  gggg  hhhh |
    stage1 |  001122        aaaa33bbbb44cccc55dddd66eeee77ffff  gggg  hhhh     |
    stage2 |    0011    aaaa22bbbb33cccc44dddd55eeee66ffff77gggg  hhhh         |
    stage3 |      00aaaa11bbbb22cccc33dddd44eeee55ffff66gggg77hhhh             |
    （数字=前向的微批号，字母=反向的微批号，空格=气泡；交错式中同一微批在每个设备上出现 v 次，对应不同块）
  interleaved(v=2) 总时长= 28.50  气泡率= 15.8%  理论≈ 15.8%  各stage峰值在途微批=[5.5, 4.5, 3.5, 2.5]
    stage0 |0011223300112233445566      aaaa77bbbb  44cccc55dddd66aaaa77bbbbcccc  dddd  eeee  ffff  gggg  hhhheeeeffffgggghhhh |
    stage1 |  001122330011223344    aaaa55bbbb66cccc77dddd44aaaa55bbbb66cccc77dddd  eeee  ffff  gggg  hhhheeeeffffgggghhhh     |
    stage2 |    00112233001122  aaaa33bbbb44cccc55dddd66aaaa77bbbb44cccc55dddd66eeee77ffff  gggg  hhhheeeeffffgggghhhh         |
    stage3 |      0011223300aaaa11bbbb22cccc33dddd44aaaa55bbbb66cccc77dddd44eeee55ffff66gggg77hhhheeeeffffgggghhhh             |
    （数字=前向的微批号，字母=反向的微批号，空格=气泡；交错式中同一微批在每个设备上出现 v 次，对应不同块）

== 扫描：微批数 m 对气泡率的影响（p=8）==
  -- m=8
  1f1b             总时长= 45.00  气泡率= 46.7%  理论≈ 46.7%  各stage峰值在途微批=[8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0]
  interleaved(v=4) 总时长= 29.25  气泡率= 17.9%  理论≈ 17.9%  各stage峰值在途微批=[8.0, 8.0, 8.0, 8.0, 7.8, 7.2, 6.8, 6.2]
  -- m=16
  1f1b             总时长= 69.00  气泡率= 30.4%  理论≈ 30.4%  各stage峰值在途微批=[8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0]
  interleaved(v=4) 总时长= 53.25  气泡率=  9.9%  理论≈  9.9%  各stage峰值在途微批=[9.8, 9.2, 8.8, 8.2, 7.8, 7.2, 6.8, 6.2]
  -- m=32
  1f1b             总时长=117.00  气泡率= 17.9%  理论≈ 17.9%  各stage峰值在途微批=[8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0]
  interleaved(v=4) 总时长=101.25  气泡率=  5.2%  理论≈  5.2%  各stage峰值在途微批=[9.8, 9.2, 8.8, 8.2, 7.8, 7.2, 6.8, 6.2]
  -- m=64
  1f1b             总时长=213.00  气泡率=  9.9%  理论≈  9.9%  各stage峰值在途微批=[8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0]
  interleaved(v=4) 总时长=197.25  气泡率=  2.7%  理论≈  2.7%  各stage峰值在途微批=[9.8, 9.2, 8.8, 8.2, 7.8, 7.2, 6.8, 6.2]

[小结] 1F1B 与 GPipe 气泡相同，但峰值激活从 m 降到 p-s；交错式把气泡再降 v 倍，代价是 v 倍的
       点对点通信次数。增大 m 能摊薄气泡，但全局 batch 受收敛性约束——这是真实系统的矛盾。
[问题库] P18 流水线气泡与阶段不均衡
```

### `labs/m07_model_parallel/lab_03_parallel_config_search.py`

```python
"""[M07-L03] 3D 并行配置搜索：在显存约束下估算每种 (DP, TP, PP, 微批, 重计算) 的迭代时间

目标：把 M04 的显存账本、M05 的通信模型、M07-L02 的气泡公式组合成一个简易性能模型，
      枚举所有合法配置并排序；体会 Megatron 论文中的经验法则（TP 放节点内、PP 跨节点、DP 最外层）。
先预测：
  1. 70B 模型、64 张 80GB 卡、seq=4096、全局 batch=512 序列，最优配置大概是什么？
  2. 把 GPU 数翻倍而全局 batch 不变，最优配置会怎样变？
可调参数：--model、--gpus、--gbs（全局 batch，序列数）、--seq、--top
暴露的问题：配置空间巨大、性能模型不准时需要搜索/学习 → PROBLEM_BANK P19
对应论文：Megatron 3D 并行（SC'21，§3 的经验法则）；Alpa（2201.12023，自动并行）
注意：这是教学用的粗模型，系数（效率、重叠率）是假设值，用于比较趋势，不用于精确预测。
"""
import argparse
import itertools

MODELS = {"7b": (32, 4096, 32, 11008), "13b": (40, 5120, 40, 13824), "70b": (80, 8192, 64, 28672)}
PEAK, EFF = 989e12, 0.55          # H100 BF16 峰值与假设的 GEMM 效率
BW_INTRA, BW_INTER, MEM = 300e9, 25e9, 80e9
GPUS_PER_NODE = 8


def evaluate(L, h, a, f, s, gbs, n, tp, pp, mbs, rc):
    dp = n // (tp * pp)
    if dp * tp * pp != n or L % pp or a % tp or gbs % (dp * mbs) or tp > GPUS_PER_NODE:
        return None
    psi = L * (4 * h * h + 3 * h * f) + 2 * 32000 * h
    m = gbs // (dp * mbs)                                  # 每个流水线的微批数
    # 显存：ZeRO-1 模型状态 + 激活（1F1B 下 stage0 有 pp 个在途微批）
    states = (4 + 12 / dp) * psi / (tp * pp)
    per_layer = {"none": s * mbs * h * (34 + 5 * a * s / h) / tp,
                 "selective": s * mbs * h * 34 / tp,
                 "full": 2 * s * mbs * h / tp}[rc]
    act = per_layer * (L / pp) * min(pp, m)
    mem = states + act + 4e9                               # 4GB 预留给框架/碎片/临时 buffer
    if mem > MEM:
        return None
    # 时间：计算（完全重算多一次前向）× 气泡因子 + 未隐藏的 TP 通信 + DP 梯度同步（假设一半被隐藏）
    tokens = gbs * s
    flops = (8 if rc == "full" else 6) * psi * tokens + 12 * L * s * s * h * gbs * (4 / 3 if rc == "full" else 1)
    eff = EFF * (0.85 if tp * mbs * s < 4096 * 2 else 1.0)  # 切得太碎时 GEMM 效率下降（假设）
    t_comp = flops / n / (PEAK * eff)
    bubble = (pp - 1) / m
    tp_bytes = 0 if tp == 1 else 4 * 2 * (tp - 1) / tp * mbs * s * h * 2 * (L / pp) * m
    t_tp = tp_bytes / BW_INTRA * 0.7                       # 假设 30% 能与计算重叠
    t_dp = 0 if dp == 1 else 2 * (dp - 1) / dp * 2 * psi / (tp * pp) / BW_INTER * 0.5
    t = t_comp * (1 + bubble) + t_tp + t_dp
    mfu = 6 * psi * tokens / n / PEAK / t
    return dict(dp=dp, tp=tp, pp=pp, mbs=mbs, rc=rc, m=m, mem=mem / 1e9, t=t, mfu=mfu,
                parts=(t_comp, t_comp * bubble, t_tp, t_dp))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="70b", choices=MODELS)
    ap.add_argument("--gpus", type=int, default=64)
    ap.add_argument("--gbs", type=int, default=512)
    ap.add_argument("--seq", type=int, default=4096)
    ap.add_argument("--top", type=int, default=8)
    a = ap.parse_args()
    L, h, heads, f = MODELS[a.model]
    res, tried = [], 0
    for tp, pp, mbs, rc in itertools.product([1, 2, 4, 8], [1, 2, 4, 8, 16], [1, 2, 4], ["none", "selective", "full"]):
        tried += 1
        r = evaluate(L, h, heads, f, a.seq, a.gbs, a.gpus, tp, pp, mbs, rc)
        if r:
            res.append(r)
    res.sort(key=lambda r: r["t"])
    print(f"== {a.model}，{a.gpus} GPU，gbs={a.gbs}，seq={a.seq}：枚举 {tried} 种，合法 {len(res)} 种 ==")
    print(f"  {'DP':>3s} {'TP':>3s} {'PP':>3s} {'mbs':>3s} {'重算':>9s} {'m':>4s} {'显存GB':>7s} "
          f"{'迭代s':>7s} {'MFU':>6s}  分解(计算/气泡/TP通信/DP通信 s)")
    for r in res[:a.top]:
        p = r["parts"]
        print(f"  {r['dp']:3d} {r['tp']:3d} {r['pp']:3d} {r['mbs']:3d} {r['rc']:>9s} {r['m']:4d} {r['mem']:7.1f} "
              f"{r['t']:7.2f} {r['mfu']:6.1%}  {p[0]:.2f}/{p[1]:.2f}/{p[2]:.2f}/{p[3]:.2f}")
    if res:
        print(f"  最差的合法配置：迭代 {res[-1]['t']:.2f}s（是最优的 {res[-1]['t'] / res[0]['t']:.1f} 倍）")
    print("\n[小结] 好配置通常 TP 在节点内、PP 适中以保证 m 远大于 PP、能不重算就不重算。"
          "\n       模型里每个系数都会改变排序——真实系统用 profiling 校准或自动搜索（Alpa、Galvatron 等）。"
          "\n[问题库] P19 3D/4D 并行配置搜索")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m07_model_parallel/outputs/lab_03_parallel_config_search.txt`）：

```text
# 实测输出：m07_model_parallel/lab_03_parallel_config_search.py
# 运行时间：2026-10-18 21:29，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 70b，64 GPU，gbs=512，seq=4096：枚举 180 种，合法 54 种 ==
   DP  TP  PP mbs        重算    m    显存GB     迭代s    MFU  分解(计算/气泡/TP通信/DP通信 s)
    2   2  16   1 selective  256    74.1   32.94  47.3%  30.27/1.77/0.80/0.10
    1   4  16   1 selective  512    46.4   33.56  46.4%  30.27/0.89/2.41/0.00
    2   4   8   1 selective  256    51.3   33.60  46.4%  30.27/0.83/2.41/0.10
    4   4   4   1 selective  128    61.1   33.68  46.3%  30.27/0.71/2.41/0.29
    2   4   8   2 selective  128    74.1   34.43  45.3%  30.27/1.66/2.41/0.10
    1   4  16   2 selective  256    69.2   34.45  45.2%  30.27/1.77/2.41/0.00
    1   8   8   1 selective  512    35.0   36.29  42.9%  30.27/0.41/5.61/0.00
    2   8   4   1 selective  256    39.9   36.33  42.9%  30.27/0.35/5.61/0.10
  最差的合法配置：迭代 59.57s（是最优的 1.8 倍）

[小结] 好配置通常 TP 在节点内、PP 适中以保证 m 远大于 PP、能不重算就不重算。
       模型里每个系数都会改变排序——真实系统用 profiling 校准或自动搜索（Alpa、Galvatron 等）。
[问题库] P19 3D/4D 并行配置搜索
```

### `labs/m07_model_parallel/lab_04_context_parallel.py`

```python
"""[M07-L04] 序列/上下文并行：Ring Attention 与 DeepSpeed-Ulysses

目标：用 N 个虚拟 rank 实现 Ring Attention（KV 块在环上传递 + 在线 softmax），验证与完整注意力一致；
      统计通信量；观察因果掩码下各 rank 的计算负载不均，以及 zigzag 切分如何修复；
      对比 Ulysses（All-to-All 把序列切分转换为头切分）的通信量与约束。
先预测：
  1. 因果注意力下按顺序把序列切成 N 段，最后一个 rank 的计算量是第一个的几倍？
  2. Ulysses 要求头数能被 N 整除，GQA 只有 8 个 KV 头时，N 最多能开到多少？
可调参数：--ranks、--seq、--d、--heads
暴露的问题：长序列训练的通信与负载均衡 → PROBLEM_BANK P20、P07
对应论文：Ring Attention（2310.01889）；DeepSpeed-Ulysses（2309.14509）；USP（2405.07719）；
          LoongTrain（2406.18485）；Context Parallelism for Million-Token Inference（2411.01783）
真实框架对照：zhuzilin/ring-flash-attention（zigzag_ring_flash_attn.py）；
              feifeibear/long-context-attention；Megatron-LM 的 context_parallel 选项（依赖 TransformerEngine）
"""
import argparse
import math

import torch


def full_attention(q, k, v, causal):
    s = q @ k.T / math.sqrt(q.shape[1])
    if causal:
        s = s.masked_fill(torch.ones_like(s, dtype=torch.bool).triu(1), -float("inf"))
    return torch.softmax(s, dim=-1) @ v


def ring_attention(q, k, v, n, causal, order):
    """order[r] = rank r 负责的序列块编号列表。每轮每个 rank 拿到环上传来的一份 KV，更新在线 softmax。"""
    S, d = q.shape
    blk = S // (n * len(order[0]))
    idx = [torch.cat([torch.arange(c * blk, (c + 1) * blk) for c in order[r]]) for r in range(n)]
    out = torch.empty_like(q)
    work = [0] * n                                         # 实际计算的 (q,k) 元素对数
    for r in range(n):
        qi, pos_q = q[idx[r]], idx[r]
        m = torch.full((len(pos_q), 1), -float("inf")); l = torch.zeros(len(pos_q), 1); o = torch.zeros(len(pos_q), d)
        for step in range(n):                              # 第 step 轮收到 rank (r - step) 的 KV
            src = (r - step) % n
            kj, vj, pos_k = k[idx[src]], v[idx[src]], idx[src]
            s = qi @ kj.T / math.sqrt(d)
            if causal:
                mask = pos_k[None, :] > pos_q[:, None]
                if mask.all():
                    continue                               # 整块被掩码：跳过计算（负载不均的来源）
                s = s.masked_fill(mask, -float("inf"))
                work[r] += int((~mask).sum())
            else:
                work[r] += s.numel()
            m_new = torch.maximum(m, s.max(1, keepdim=True).values)
            p = torch.exp(s - m_new); p = torch.nan_to_num(p)
            c = torch.exp(m - m_new); c = torch.nan_to_num(c)
            l = l * c + p.sum(1, keepdim=True); o = o * c + p @ vj; m = m_new
        out[idx[r]] = o / l
    return out, work


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, default=4)
    ap.add_argument("--seq", type=int, default=512)
    ap.add_argument("--d", type=int, default=64)
    ap.add_argument("--heads", type=int, default=32)
    a = ap.parse_args()
    n = a.ranks
    torch.manual_seed(0)
    q, k, v = (torch.randn(a.seq, a.d, dtype=torch.float64) for _ in range(3))
    seq_order = [[r] for r in range(n)]                         # 顺序切分
    zigzag = [[r, 2 * n - 1 - r] for r in range(n)]             # 每个 rank 拿一头一尾两块
    print(f"== Ring Attention 正确性（N={n}，seq={a.seq}）==")
    for causal in [False, True]:
        ref = full_attention(q, k, v, causal)
        for name, order in [("顺序切分", seq_order), ("zigzag", zigzag)]:
            out, work = ring_attention(q, k, v, n, causal, order)
            tot = sum(work)
            print(f"  {'因果' if causal else '双向'} {name:6s} max|差|={(out - ref).abs().max().item():.1e}  "
                  f"各rank计算量占比={[f'{w / tot:.0%}' for w in work]}  最慢/平均={max(work) / (tot / n):.2f}")

    print("\n== 通信量对比（每层前向，每 rank 收发，BF16；s=序列总长，h=隐藏维度）==")
    s, h = 131072, 8192
    for N in [4, 8, 16]:
        ring = (N - 1) * 2 * (s // N) * h * 2                   # 传 N-1 次本地 KV（K 和 V）
        ulysses = 4 * (N - 1) / N * (s // N) * h * 2             # Q,K,V 各一次 + 输出一次 All-to-All
        print(f"  N={N:2d}: Ring {ring / 2 ** 30:6.2f} GB（可与块计算重叠）  "
              f"Ulysses {ulysses / 2 ** 30:6.2f} GB（All-to-All，需 头数 % N == 0）")
    print(f"  头数={a.heads}：Ulysses 的 N 最大为 {a.heads}；若 KV 头只有 8 个（GQA），K/V 的切分上限就是 8，"
          f"\n  这正是 USP/LoongTrain 把 Ulysses（头维）和 Ring（序列维）组合成 2D 的动机。")
    print("\n[小结] Ring 的通信量与 N 无关地≈'每 rank 收到全部 KV'，靠与计算重叠来隐藏；因果掩码使顺序切分"
          "\n       严重不均，zigzag 让每个 rank 拿到等量工作。Ulysses 通信更少但受头数限制。"
          "\n[问题库] P20 长序列训练的通信与负载均衡；P07 长上下文")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m07_model_parallel/outputs/lab_04_context_parallel.txt`）：

```text
# 实测输出：m07_model_parallel/lab_04_context_parallel.py
# 运行时间：2026-10-18 21:30，耗时 1.0s，峰值内存 242MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== Ring Attention 正确性（N=4，seq=512）==
  双向 顺序切分   max|差|=3.9e-16  各rank计算量占比=['25%', '25%', '25%', '25%']  最慢/平均=1.00
  双向 zigzag max|差|=4.2e-16  各rank计算量占比=['25%', '25%', '25%', '25%']  最慢/平均=1.00
  因果 顺序切分   max|差|=1.1e-15  各rank计算量占比=['6%', '19%', '31%', '44%']  最慢/平均=1.75
  因果 zigzag max|差|=1.0e-15  各rank计算量占比=['25%', '25%', '25%', '25%']  最慢/平均=1.00

== 通信量对比（每层前向，每 rank 收发，BF16；s=序列总长，h=隐藏维度）==
  N= 4: Ring   3.00 GB（可与块计算重叠）  Ulysses   1.50 GB（All-to-All，需 头数 % N == 0）
  N= 8: Ring   3.50 GB（可与块计算重叠）  Ulysses   0.88 GB（All-to-All，需 头数 % N == 0）
  N=16: Ring   3.75 GB（可与块计算重叠）  Ulysses   0.47 GB（All-to-All，需 头数 % N == 0）
  头数=32：Ulysses 的 N 最大为 32；若 KV 头只有 8 个（GQA），K/V 的切分上限就是 8，
  这正是 USP/LoongTrain 把 Ulysses（头维）和 Ring（序列维）组合成 2D 的动机。

[小结] Ring 的通信量与 N 无关地≈'每 rank 收到全部 KV'，靠与计算重叠来隐藏；因果掩码使顺序切分
       严重不均，zigzag 让每个 rank 拿到等量工作。Ulysses 通信更少但受头数限制。
[问题库] P20 长序列训练的通信与负载均衡；P07 长上下文
```

## M08 MoE 系统：专家并行、负载均衡、All-to-All 瓶颈（`labs/m08_moe/`）

### `labs/m08_moe/lab_01_moe_routing.py`

```python
"""[M08-L01] MoE 路由与负载均衡：容量因子、丢 token、辅助损失与无辅助损失偏置

目标：观察 top-k 路由在偏斜输入下的负载不均；理解容量因子（capacity factor）如何导致丢 token；
      训练一个小路由器，比较"无均衡""Switch 辅助损失""DeepSeek-V3 无辅助损失偏置调整"三种策略。
先预测：
  1. 64 个专家、top-2、容量因子 1.0，若最热专家收到 3 倍平均负载，丢弃的 token 比例大约多少？
  2. 辅助损失权重越大越好吗？
可调参数：--experts、--topk、--tokens、--cf（容量因子列表）、--steps
暴露的问题：负载不均 → 专家并行中的慢 rank 与丢 token → PROBLEM_BANK P21
对应论文：GShard（容量与丢弃）；Switch Transformers（辅助损失 α·E·Σ f_i·P_i）；
          DeepSeek-V3（2412.19437，auxiliary-loss-free 的偏置项 b_i）
真实框架对照：Megatron-LM megatron/core/transformer/moe/router.py、moe_utils.py
"""
import argparse

import torch


def route(logits, k, bias=None):
    scores = torch.softmax(logits, dim=-1)
    sel = scores + (bias if bias is not None else 0)       # 偏置只影响"选谁"，不影响门控权重
    idx = sel.topk(k, dim=-1).indices
    return scores, idx


def load_stats(idx, E, cf, k):
    T = idx.shape[0]
    load = torch.bincount(idx.reshape(-1), minlength=E).float()
    cap = int(cf * T * k / E)
    dropped = (load - cap).clamp(min=0).sum().item() / (T * k)
    return load, load.max().item() / load.mean().item(), dropped


def train_router(strategy, E, k, T, d, steps, seed=0):
    """路由打分 = x@W（随主任务学习）+ c（专家固有偏好，初始偏向前 1/8 的专家）。
    主任务只约束 x@W；c 只能被均衡机制修正——模拟"数据/初始化带来的系统性偏好"。
    亲和度采用 DeepSeek-V3 的 sigmoid 形式，偏置 b 只参与 top-k 选择。"""
    g = torch.Generator().manual_seed(seed)
    W = (torch.randn(d, E, generator=g) * 0.1).requires_grad_(True)
    c = torch.zeros(E); c[: E // 8] = 2.0
    c.requires_grad_(True)
    target = torch.randn(d, E, generator=g) * 0.1
    opt = torch.optim.Adam([W, c], lr=1e-2)
    bias = torch.zeros(E)
    for _ in range(steps):
        x = torch.randn(T, d, generator=g)
        aff = torch.sigmoid(x @ W + c)                    # 亲和度
        sel = aff + (bias if strategy == "bias" else 0)
        idx = sel.topk(k, dim=-1).indices
        task = ((x @ W - x @ target) ** 2).mean()          # 主任务损失（不涉及 c）
        loss = task
        if strategy == "aux":
            f = torch.bincount(idx.reshape(-1), minlength=E).float() * E / (T * k)   # 归一化分配比例
            P = (aff / aff.sum(-1, keepdim=True)).mean(0)                           # 平均路由概率
            loss = loss + 0.01 * (f * P).sum()
        opt.zero_grad(); loss.backward(); opt.step()
        if strategy == "bias":                            # DeepSeek-V3：过载减偏置、欠载加偏置，步长 γ
            load = torch.bincount(idx.reshape(-1), minlength=E).float()
            bias -= 1e-3 * torch.sign(load - load.mean())
    x = torch.randn(T, d, generator=g)
    aff = torch.sigmoid(x @ W + c).detach()
    idx = (aff + (bias if strategy == "bias" else 0)).topk(k, dim=-1).indices
    return idx, task.item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experts", type=int, default=64)
    ap.add_argument("--topk", type=int, default=2)
    ap.add_argument("--tokens", type=int, default=4096)
    ap.add_argument("--cf", type=float, nargs="+", default=[1.0, 1.25, 2.0])
    ap.add_argument("--steps", type=int, default=300)
    a = ap.parse_args()
    E, k, T = a.experts, a.topk, a.tokens
    torch.manual_seed(0)
    print(f"== 偏斜路由下的负载（E={E}, top-{k}, {T} tokens）==")
    for skew in [0.0, 1.0, 2.0]:
        logits = torch.randn(T, E) + skew * torch.linspace(1, 0, E)    # skew 越大越偏向前面的专家
        _, idx = route(logits, k)
        for cf in a.cf:
            load, imb, drop = load_stats(idx, E, cf, k)
            print(f"  偏斜={skew:.1f} 容量因子={cf:4.2f}: 最大/平均负载={imb:5.2f}  丢弃 token 比例={drop:6.2%}")

    print(f"\n== 训练路由器 {a.steps} 步后的均衡程度 ==")
    for name, st in [("无均衡", "none"), ("Switch 辅助损失", "aux"), ("无辅助损失偏置(DeepSeek-V3)", "bias")]:
        idx, task = train_router(st, E, k, 1024, 32, a.steps)
        _, imb, drop = load_stats(idx, E, 1.25, k)
        print(f"  {name:28s} 最大/平均={imb:5.2f}  丢弃(cf=1.25)={drop:6.2%}  主任务损失={task:.2e}")
    print("\n[小结] 容量因子越大丢得越少，但显存和计算按容量预留，会浪费；辅助损失能均衡负载，但它的梯度会"
          "\n       干扰主任务；DeepSeek-V3 的偏置法只改'选谁'不改梯度。负载不均直接变成专家并行中的慢 rank。"
          "\n[问题库] P21 MoE 负载不均与 All-to-All 瓶颈")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m08_moe/outputs/lab_01_moe_routing.txt`）：

```text
# 实测输出：m08_moe/lab_01_moe_routing.py
# 运行时间：2026-10-18 21:30，耗时 2.5s，峰值内存 310MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 偏斜路由下的负载（E=64, top-2, 4096 tokens）==
  偏斜=0.0 容量因子=1.00: 最大/平均负载= 1.16  丢弃 token 比例= 3.36%
  偏斜=0.0 容量因子=1.25: 最大/平均负载= 1.16  丢弃 token 比例= 0.00%
  偏斜=0.0 容量因子=2.00: 最大/平均负载= 1.16  丢弃 token 比例= 0.00%
  偏斜=1.0 容量因子=1.00: 最大/平均负载= 2.70  丢弃 token 比例=27.43%
  偏斜=1.0 容量因子=1.25: 最大/平均负载= 2.70  丢弃 token 比例=18.25%
  偏斜=1.0 容量因子=2.00: 最大/平均负载= 2.70  丢弃 token 比例= 2.80%
  偏斜=2.0 容量因子=1.00: 最大/平均负载= 3.87  丢弃 token 比例=45.20%
  偏斜=2.0 容量因子=1.25: 最大/平均负载= 3.87  丢弃 token 比例=36.78%
  偏斜=2.0 容量因子=2.00: 最大/平均负载= 3.87  丢弃 token 比例=18.18%

== 训练路由器 300 步后的均衡程度 ==
  无均衡                          最大/平均= 8.94  丢弃(cf=1.25)=84.33%  主任务损失=2.69e-14
  Switch 辅助损失                  最大/平均= 1.28  丢弃(cf=1.25)= 0.15%  主任务损失=2.41e-09
  无辅助损失偏置(DeepSeek-V3)         最大/平均= 1.41  丢弃(cf=1.25)= 0.63%  主任务损失=2.69e-14

[小结] 容量因子越大丢得越少，但显存和计算按容量预留，会浪费；辅助损失能均衡负载，但它的梯度会
       干扰主任务；DeepSeek-V3 的偏置法只改'选谁'不改梯度。负载不均直接变成专家并行中的慢 rank。
[问题库] P21 MoE 负载不均与 All-to-All 瓶颈
```

### `labs/m08_moe/lab_02_expert_parallel.py`

```python
"""[M08-L02] 专家并行（Expert Parallelism, EP）：All-to-All 成本、热点专家与专家 GEMM 的算术强度

目标：估算 EP 下 dispatch/combine 两次 All-to-All 的数据量和时间；用蒙特卡洛模拟路由偏斜导致的
      "最忙 rank"拖慢整步；计算推理 decode 时每个专家分到的 token 数与专家 GEMM 的算术强度，
      理解 MegaScale-Infer 等"注意力与 FFN 分离部署"工作的动机。
先预测：
  1. decode batch=256、256 个专家、top-8，每个专家平均分到几个 token？专家 GEMM 是访存还是算力受限？
  2. EP 从节点内 8 卡扩到跨节点 64 卡，All-to-All 时间怎么变？
可调参数：--experts、--topk、--hidden、--ffn、--tokens、--ep（列表）、--zipf（路由偏斜）
暴露的问题：All-to-All 瓶颈、热点专家、decode 时 FFN 访存受限 → PROBLEM_BANK P21、P22
对应论文：DeepSeek-V3（EP 与 DeepEP）；MegaScale-Infer（2504.02263）；Tutel；MegaBlocks
真实框架对照：deepseek-ai/DeepEP（normal / low-latency 两类 kernel）；
              Megatron-LM megatron/core/transformer/moe/token_dispatcher.py
"""
import argparse

import numpy as np


def a2a_time(bytes_per_rank, ep, gpn, bw_in, bw_out, alpha):
    """All-to-All：每 rank 把 (ep-1)/ep 的数据发出去；跨节点部分走慢链路。"""
    if ep <= gpn:
        return alpha * (ep - 1) + bytes_per_rank * (ep - 1) / ep / bw_in
    remote = (ep - gpn) / ep
    local = (gpn - 1) / ep
    return alpha * (ep - 1) + bytes_per_rank * max(remote / bw_out, local / bw_in)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experts", type=int, default=256)
    ap.add_argument("--topk", type=int, default=8)
    ap.add_argument("--hidden", type=int, default=7168)
    ap.add_argument("--ffn", type=int, default=2048, help="每个专家的中间维度（DeepSeek-V3: 2048）")
    ap.add_argument("--tokens", type=int, default=4096, help="每个 rank 每步的 token 数（训练）")
    ap.add_argument("--ep", type=int, nargs="+", default=[8, 16, 32, 64])
    ap.add_argument("--zipf", type=float, default=1.1)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    gpn, bw_in, bw_out, alpha = 8, 160e9, 50e9, 10e-6     # 假设：NVLink 有效 160GB/s，IB 每卡 50GB/s

    print("== 训练：每层 dispatch + combine 的 All-to-All（BF16）==")
    per_rank = a.tokens * a.topk * a.hidden * 2              # 每 rank 发出的 token 副本字节
    for ep in a.ep:
        t = 2 * a2a_time(per_rank, ep, gpn, bw_in, bw_out, alpha)
        print(f"  EP={ep:3d}: 每 rank 发出 {per_rank / 2 ** 20:7.1f} MB × 2 次，理论 {t * 1e3:6.2f} ms/层")

    print(f"\n== 热点专家：zipf={a.zipf} 偏斜路由下，最忙 rank 的接收量 / 平均 ==")
    for ep in a.ep:
        p = 1 / np.arange(1, a.experts + 1) ** a.zipf
        p = rng.permutation(p / p.sum())                     # 热门专家随机分布在各 rank
        counts = rng.multinomial(a.tokens * ep * a.topk, p)
        per_rank_load = counts.reshape(ep, -1).sum(1)
        uni = rng.multinomial(a.tokens * ep * a.topk, np.full(a.experts, 1 / a.experts)).reshape(ep, -1).sum(1)
        print(f"  EP={ep:3d}: 偏斜 {per_rank_load.max() / per_rank_load.mean():4.2f}×   "
              f"均匀路由 {uni.max() / uni.mean():4.2f}×   → 整步时间由最忙 rank 决定")

    print("\n== 推理 decode：每个专家分到的 token 与 GEMM 算术强度 ==")
    print(f"  {'batch':>6s} {'每专家token':>11s} {'AI(FLOP/B)':>10s}  H100 屋脊点≈295")
    for b in [32, 256, 1024, 8192]:
        n = b * a.topk / a.experts
        flops = 2 * n * a.hidden * a.ffn * 3                 # SwiGLU 三个矩阵
        bytes_ = 3 * a.hidden * a.ffn * 2 + 2 * n * (a.hidden * 2 + a.ffn * 3) * 2
        ai = flops / bytes_
        print(f"  {b:6d} {n:11.1f} {ai:10.1f}  {'访存受限' if ai < 295 else '算力受限'}")
    print("\n[小结] MoE 把稠密 FFN 换成稀疏专家后，训练时通信从 AllReduce 变为两次 All-to-All，跨节点时成瓶颈；"
          "\n       路由偏斜让最忙 rank 拖慢全体。推理 decode 时每个专家只分到少量 token，专家 GEMM 严重访存受限，"
          "\n       所以 MegaScale-Infer 把注意力与专家分开部署，用大规模聚合 token 提高专家的批大小。"
          "\n[问题库] P21 负载不均与 All-to-All；P22 MoE 推理 FFN 访存受限")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m08_moe/outputs/lab_02_expert_parallel.txt`）：

```text
# 实测输出：m08_moe/lab_02_expert_parallel.py
# 运行时间：2026-10-18 21:30，耗时 0.2s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 训练：每层 dispatch + combine 的 All-to-All（BF16）==
  EP=  8: 每 rank 发出   448.0 MB × 2 次，理论   5.28 ms/层
  EP= 16: 每 rank 发出   448.0 MB × 2 次，理论   9.70 ms/层
  EP= 32: 每 rank 发出   448.0 MB × 2 次，理论  14.71 ms/层
  EP= 64: 每 rank 发出   448.0 MB × 2 次，理论  17.70 ms/层

== 热点专家：zipf=1.1 偏斜路由下，最忙 rank 的接收量 / 平均 ==
  EP=  8: 偏斜 2.24×   均匀路由 1.01×   → 整步时间由最忙 rank 决定
  EP= 16: 偏斜 4.85×   均匀路由 1.01×   → 整步时间由最忙 rank 决定
  EP= 32: 偏斜 6.83×   均匀路由 1.01×   → 整步时间由最忙 rank 决定
  EP= 64: 偏斜 13.41×   均匀路由 1.01×   → 整步时间由最忙 rank 决定

== 推理 decode：每个专家分到的 token 与 GEMM 算术强度 ==
   batch    每专家token AI(FLOP/B)  H100 屋脊点≈295
      32         1.0        1.0  访存受限
     256         8.0        7.9  访存受限
    1024        32.0       31.1  访存受限
    8192       256.0      206.8  访存受限

[小结] MoE 把稠密 FFN 换成稀疏专家后，训练时通信从 AllReduce 变为两次 All-to-All，跨节点时成瓶颈；
       路由偏斜让最忙 rank 拖慢全体。推理 decode 时每个专家只分到少量 token，专家 GEMM 严重访存受限，
       所以 MegaScale-Infer 把注意力与专家分开部署，用大规模聚合 token 提高专家的批大小。
[问题库] P21 负载不均与 All-to-All；P22 MoE 推理 FFN 访存受限
```

## M09 大规模训练工程：容错与 checkpoint、慢节点、可观测性（`labs/m09_training_ops/`）

### `labs/m09_training_ops/lab_01_failure_checkpoint.py`

```python
"""[M09-L01] 大规模训练的故障与 checkpoint：蒙特卡洛估算有效训练时间比（ETTR）

目标：给定集群规模、单卡平均无故障时间（MTBF）、checkpoint 保存开销和重启开销，
      模拟一个月的训练，得到 ETTR = 有效训练时间 / 总时间；扫描 checkpoint 间隔，
      与 Young/Daly 近似最优间隔 τ* ≈ sqrt(2·δ·M)（M=作业级 MTBF）对照；比较"远端存储"与"内存/对等 checkpoint"。
先预测：
  1. 16384 张卡、单卡 MTBF 5 万小时，整个作业平均多久故障一次？
  2. checkpoint 保存从 5 分钟降到 10 秒，最优间隔和 ETTR 怎么变？
可调参数：--gpus、--mtbf-h（单卡）、--save-s、--restart-s、--days
暴露的问题：故障频率随规模线性增长；恢复速度决定有效算力 → PROBLEM_BANK P24
对应论文：MegaScale（NSDI'24）；Llama 3 技术报告（54 天 466 次中断）；GEMINI（SOSP'23，内存 checkpoint）；
          ByteCheckpoint（NSDI'25）；Robust LLM Training Infrastructure at ByteDance（SOSP'25）
"""
import argparse
import math
import random


def simulate(total_s, job_mtbf_s, interval_s, save_s, restart_s, seed=0):
    rng = random.Random(seed)
    t = useful = 0.0
    next_fail = rng.expovariate(1 / job_mtbf_s)
    since_ckpt = 0.0
    n_fail = 0
    while t < total_s:
        # 训练一段 interval，然后保存 checkpoint（保存期间阻塞训练，简化）
        seg_end = t + (interval_s - since_ckpt) + save_s
        if next_fail < seg_end:                             # 段内发生故障：丢失自上次 checkpoint 以来的进度
            t = next_fail + restart_s
            since_ckpt = 0.0
            n_fail += 1
            next_fail = t + rng.expovariate(1 / job_mtbf_s)
            continue
        useful += interval_s - since_ckpt
        since_ckpt = 0.0
        t = seg_end
    return min(useful / total_s, 1.0), n_fail


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpus", type=int, default=16384)
    ap.add_argument("--mtbf-h", type=float, default=50000, help="单卡（含其所在节点部件）平均无故障小时数，假设值")
    ap.add_argument("--save-s", type=float, nargs="+", default=[300, 30, 5])
    ap.add_argument("--restart-s", type=float, default=600)
    ap.add_argument("--days", type=float, default=30)
    a = ap.parse_args()
    M = a.mtbf_h * 3600 / a.gpus                            # 作业级 MTBF：任何一张卡故障都会中断作业
    total = a.days * 86400
    print(f"== {a.gpus} GPU，单卡 MTBF {a.mtbf_h:.0f}h → 作业平均 {M / 3600:.2f} 小时故障一次，"
          f"{a.days:.0f} 天约 {total / M:.0f} 次 ==")
    for save in a.save_s:
        opt = math.sqrt(2 * save * M)
        print(f"\n-- 保存开销 {save:.0f}s（Young/Daly 最优间隔 ≈ {opt / 60:.1f} 分钟），重启 {a.restart_s:.0f}s --")
        best = (0, 0)
        for mins in [2, 5, 10, 20, 30, 60, 120, 240]:
            ettr = sum(simulate(total, M, mins * 60, save, a.restart_s, seed=s)[0] for s in range(5)) / 5
            best = max(best, (ettr, mins))
            print(f"  间隔 {mins:4d} 分钟：ETTR = {ettr:6.1%}")
        print(f"  模拟最优 ≈ {best[1]} 分钟（ETTR {best[0]:.1%}）")
    print("\n== 再把重启从 600s 降到 60s（热备节点 + 内存 checkpoint，ByteRobust 一类思路）==")
    ettr = sum(simulate(total, M, max(60, math.sqrt(2 * 5 * M)), 5, 60, seed=s)[0] for s in range(5)) / 5
    print(f"  保存 5s、重启 60s：ETTR = {ettr:.1%}")
    print("\n[小结] 规模越大，故障越频繁；ETTR 同时受保存开销（决定能多频繁地存）和重启开销（每次故障的固定损失）制约。"
          "\n       这就是异步/内存 checkpoint、热备替换、快速故障定位成为大规模训练基础设施核心的原因。"
          "\n[问题库] P24 大规模训练故障与 checkpoint 开销")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m09_training_ops/outputs/lab_01_failure_checkpoint.txt`）：

```text
# 实测输出：m09_training_ops/lab_01_failure_checkpoint.py
# 运行时间：2026-10-18 21:30，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 16384 GPU，单卡 MTBF 50000h → 作业平均 3.05 小时故障一次，30 天约 236 次 ==

-- 保存开销 300s（Young/Daly 最优间隔 ≈ 42.8 分钟），重启 600s --
  间隔    2 分钟：ETTR =  26.6%
  间隔    5 分钟：ETTR =  46.2%
  间隔   10 分钟：ETTR =  60.9%
  间隔   20 分钟：ETTR =  71.0%
  间隔   30 分钟：ETTR =  74.1%
  间隔   60 分钟：ETTR =  73.5%
  间隔  120 分钟：ETTR =  64.3%
  间隔  240 分钟：ETTR =  45.3%
  模拟最优 ≈ 30 分钟（ETTR 74.1%）

-- 保存开销 30s（Young/Daly 最优间隔 ≈ 13.5 分钟），重启 600s --
  间隔    2 分钟：ETTR =  75.5%
  间隔    5 分钟：ETTR =  85.1%
  间隔   10 分钟：ETTR =  87.9%
  间隔   20 分钟：ETTR =  87.7%
  间隔   30 分钟：ETTR =  86.3%
  间隔   60 分钟：ETTR =  80.0%
  间隔  120 分钟：ETTR =  67.8%
  间隔  240 分钟：ETTR =  47.0%
  模拟最优 ≈ 10 分钟（ETTR 87.9%）

-- 保存开销 5s（Young/Daly 最优间隔 ≈ 5.5 分钟），重启 600s --
  间隔    2 分钟：ETTR =  90.7%
  间隔    5 分钟：ETTR =  92.2%
  间隔   10 分钟：ETTR =  91.7%
  间隔   20 分钟：ETTR =  89.6%
  间隔   30 分钟：ETTR =  87.6%
  间隔   60 分钟：ETTR =  80.8%
  间隔  120 分钟：ETTR =  68.6%
  间隔  240 分钟：ETTR =  47.4%
  模拟最优 ≈ 5 分钟（ETTR 92.2%）

== 再把重启从 600s 降到 60s（热备节点 + 内存 checkpoint，ByteRobust 一类思路）==
  保存 5s、重启 60s：ETTR = 96.5%

[小结] 规模越大，故障越频繁；ETTR 同时受保存开销（决定能多频繁地存）和重启开销（每次故障的固定损失）制约。
       这就是异步/内存 checkpoint、热备替换、快速故障定位成为大规模训练基础设施核心的原因。
[问题库] P24 大规模训练故障与 checkpoint 开销
```

### `labs/m09_training_ops/lab_02_straggler.py`

```python
"""[M09-L02] 慢节点（straggler）：同步训练中"最慢的那个决定一切"

目标：模拟同步数据并行中每个 rank 的步时间 = 基准 ×（1 + 随机抖动），整步时间取最大值；
      观察规模增大时期望最大值的增长（极值统计）；注入一个持续变慢（fail-slow）的 GPU，
      用每 rank 计时的 z-score 做检测，并评估"剔除并替换"带来的收益。
先预测：
  1. 每个 rank 有 3% 的随机抖动，1 万个 rank 时整步比单卡慢多少？
  2. 1 张卡降频到 70% 速度，整个作业慢多少？
可调参数：--ranks（列表）、--jitter、--slow-factor、--steps
暴露的问题：慢节点检测与缓解 → PROBLEM_BANK P25
对应论文：MegaScale（慢节点检测）；Understanding Stragglers in Large Model Training Using What-if Analysis（OSDI'25）；
          Revisiting Reliability in Large-Scale ML Research Clusters（2410.21680）
真实框架对照：Megatron-LM 的 --log-straggler 选项（megatron/training/ 中的 straggler detector）
"""
import argparse

import numpy as np


def step_times(n, steps, jitter, rng, slow_rank=None, slow_factor=1.0):
    t = 1.0 + np.abs(rng.normal(0, jitter, size=(steps, n)))     # 抖动只会让步变慢
    if slow_rank is not None:
        t[:, slow_rank] /= slow_factor
    return t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, nargs="+", default=[8, 64, 512, 4096, 16384])
    ap.add_argument("--jitter", type=float, default=0.03)
    ap.add_argument("--slow-factor", type=float, default=0.7)
    ap.add_argument("--steps", type=int, default=200)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    print(f"== 随机抖动 {a.jitter:.0%}：整步时间（取各 rank 最大值）随规模增长 ==")
    for n in a.ranks:
        t = step_times(n, a.steps, a.jitter, rng)
        print(f"  N={n:6d}: 平均每 rank {t.mean():.3f}，整步 {t.max(axis=1).mean():.3f} "
              f"→ 同步损失 {t.max(axis=1).mean() / t.mean() - 1:6.1%}")

    n = 4096
    slow = int(rng.integers(n))
    t = step_times(n, a.steps, a.jitter, rng, slow_rank=slow, slow_factor=a.slow_factor)
    print(f"\n== 注入 fail-slow：rank {slow} 速度降为 {a.slow_factor:.0%}（N={n}）==")
    print(f"  整步时间 {t.max(axis=1).mean():.3f}（无慢卡时约 {step_times(n, a.steps, a.jitter, rng).max(axis=1).mean():.3f}）")
    # 检测：用窗口内每个 rank 的平均步时，算稳健 z-score（中位数/MAD）
    window = t[-50:].mean(axis=0)
    med = np.median(window); mad = np.median(np.abs(window - med)) * 1.4826
    z = (window - med) / mad
    flagged = np.where(z > 6)[0]
    print(f"  稳健 z-score>6 的 rank：{flagged.tolist()}（真实慢卡 {slow}）")
    t2 = np.delete(t, flagged, axis=1)
    print(f"  剔除后整步 {t2.max(axis=1).mean():.3f}，提速 {t.max(axis=1).mean() / t2.max(axis=1).mean():.2f}×")
    print("\n  注意：真实系统中 rank 的计时会被集合通信'同步'——快的 rank 会在 AllReduce 里等慢的，"
          "\n  所以必须测'计算段'而非整步时间，或像 MegaScale 那样在通信库里打点。")
    print("\n[小结] 同步训练的步时间是最大值，规模越大越容易被尾部拖累；一张持续变慢的卡就能让上万卡一起降速。"
          "\n       检测难点在于区分'自己慢'和'在等别人'，以及区分硬件问题与数据/负载不均（OSDI'25 的发现）。"
          "\n[问题库] P25 慢节点检测与缓解")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m09_training_ops/outputs/lab_02_straggler.txt`）：

```text
# 实测输出：m09_training_ops/lab_02_straggler.py
# 运行时间：2026-10-18 21:30，耗时 0.3s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 随机抖动 3%：整步时间（取各 rank 最大值）随规模增长 ==
  N=     8: 平均每 rank 1.024，整步 1.053 → 同步损失   2.9%
  N=    64: 平均每 rank 1.024，整步 1.077 → 同步损失   5.2%
  N=   512: 平均每 rank 1.024，整步 1.098 → 同步损失   7.3%
  N=  4096: 平均每 rank 1.024，整步 1.114 → 同步损失   8.8%
  N= 16384: 平均每 rank 1.024，整步 1.124 → 同步损失   9.8%

== 注入 fail-slow：rank 588 速度降为 70%（N=4096）==
  整步时间 1.463（无慢卡时约 1.114）
  稳健 z-score>6 的 rank：[588]（真实慢卡 588）
  剔除后整步 1.113，提速 1.32×

  注意：真实系统中 rank 的计时会被集合通信'同步'——快的 rank 会在 AllReduce 里等慢的，
  所以必须测'计算段'而非整步时间，或像 MegaScale 那样在通信库里打点。

[小结] 同步训练的步时间是最大值，规模越大越容易被尾部拖累；一张持续变慢的卡就能让上万卡一起降速。
       检测难点在于区分'自己慢'和'在等别人'，以及区分硬件问题与数据/负载不均（OSDI'25 的发现）。
[问题库] P25 慢节点检测与缓解
```

## M10 推理基础：prefill 与 decode、KV Cache 及其显存、访存瓶颈（`labs/m10_inference_basics/`）

### `labs/m10_inference_basics/lab_01_kv_cache_calc.py`

```python
"""[M10-L01] KV Cache 计算器 + prefill/decode 的 roofline 延迟估算

目标：会算每 token 的 KV Cache 字节数（MHA / GQA / MLA），由此推出单卡最大并发；
      用 roofline 估算 TTFT（prefill，算力受限）与 TPOT（decode，访存受限），理解二者的不同瓶颈。
先预测：
  1. Llama-3-8B（GQA，8 个 KV 头）在 8K 上下文下每条序列的 KV 有多大？比 Llama-2-7B（MHA）小几倍？
  2. decode 时 batch 从 1 增到 64，TPOT 增加多少？吞吐增加多少？
可调参数：--ctx（上下文长度列表）、--gpu-mem、--batch
暴露的问题：KV Cache 决定并发上限；decode 访存受限 → PROBLEM_BANK P01、P02、P07
对应论文：vLLM/PagedAttention（KV 显存管理）；DeepSeek-V2/V3（MLA 压缩 KV）；
          Splitwise / DistServe（prefill 与 decode 特性不同）
说明：模型结构参数取自各模型公开的 config.json（见 SOURCES.md 的核验记录），不需要下载任何权重。
"""
import argparse

# name: (层数, 隐藏维, KV 头数, 头维, 参数量, 类型)；MLA 的"KV 维"= kv_lora_rank + qk_rope_head_dim
MODELS = {
    "Llama-2-7B (MHA)": (32, 4096, 32, 128, 6.7e9, "mha"),
    "Llama-3-8B (GQA-8)": (32, 4096, 8, 128, 8.0e9, "gqa"),
    "Qwen2.5-7B (GQA-4)": (28, 3584, 4, 128, 7.6e9, "gqa"),
    "Llama-3-70B (GQA-8)": (80, 8192, 8, 128, 70.6e9, "gqa"),
    "DeepSeek-V3 (MLA)": (61, 7168, 1, 512 + 64, 671e9, "mla"),
}
PEAK, BW = 989e12, 3.35e12        # H100 SXM BF16 稠密峰值、HBM 带宽


def kv_bytes_per_token(L, kvh, d, kind, b=2):
    if kind == "mla":
        return L * d * b               # MLA 每层只缓存一个压缩潜向量（K、V 共享）
    return 2 * L * kvh * d * b         # K 和 V


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ctx", type=int, nargs="+", default=[4096, 32768, 131072])
    ap.add_argument("--gpu-mem", type=float, default=80e9)
    ap.add_argument("--batch", type=int, nargs="+", default=[1, 8, 32, 64])
    a = ap.parse_args()
    print("== 每 token / 每序列 KV Cache（BF16）==")
    print(f"  {'模型':22s} {'KB/token':>9s} " + " ".join(f"{'ctx=' + str(c):>12s}" for c in a.ctx))
    for name, (L, h, kvh, d, N, kind) in MODELS.items():
        per = kv_bytes_per_token(L, kvh, d, kind)
        print(f"  {name:22s} {per / 1024:9.1f} " + " ".join(f"{per * c / 2 ** 30:10.2f}GB" for c in a.ctx))

    print(f"\n== 单卡 {a.gpu_mem / 1e9:.0f}GB 能容纳的 4K 上下文并发数（权重 BF16，预留 10% 给激活/碎片）==")
    for name in ["Llama-2-7B (MHA)", "Llama-3-8B (GQA-8)", "Qwen2.5-7B (GQA-4)"]:
        L, h, kvh, d, N, kind = MODELS[name]
        free = a.gpu_mem * 0.9 - 2 * N
        print(f"  {name:22s} 剩余 {free / 1e9:5.1f}GB → 最多 {int(free // (kv_bytes_per_token(L, kvh, d, kind) * 4096)):4d} 条")

    name = "Llama-3-8B (GQA-8)"
    L, h, kvh, d, N, kind = MODELS[name]
    per = kv_bytes_per_token(L, kvh, d, kind)
    print(f"\n== {name} 在 H100 上的 roofline 延迟估算 ==")
    for prompt in [512, 2048, 8192]:
        flops = 2 * N * prompt + 4 * L * prompt * prompt * h        # 线性层 + 注意力（QK^T 与 PV）
        t = max(flops / PEAK, 2 * N / BW)
        print(f"  TTFT(prompt={prompt:5d}) ≥ {t * 1e3:7.2f} ms（{'算力' if flops / PEAK > 2 * N / BW else '访存'}受限）")
    for b in a.batch:
        ctx = 4096
        bytes_ = 2 * N + b * per * ctx                             # 每步读一遍权重 + 全部 KV
        flops = 2 * N * b
        t = max(bytes_ / BW, flops / PEAK)
        print(f"  TPOT(batch={b:3d}, ctx=4K) ≥ {t * 1e3:6.2f} ms，吞吐 ≤ {b / t:7.0f} tok/s，"
              f"KV 占读取量 {b * per * ctx / bytes_:5.1%}")
    print("\n[小结] prefill 一次处理整段 prompt，是大矩阵乘，算力受限；decode 每步只算 1 个 token，却要读全部权重"
          "\n       和 KV，访存受限。batch 增大时 KV 读取逐渐取代权重读取成为主导——GQA/MLA、KV 量化、"
          "\n       PagedAttention 都在这条线上做文章。"
          "\n[问题库] P01 decode 访存受限；P02 KV Cache 并发上限；P07 长上下文")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m10_inference_basics/outputs/lab_01_kv_cache_calc.txt`）：

```text
# 实测输出：m10_inference_basics/lab_01_kv_cache_calc.py
# 运行时间：2026-10-18 21:30，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 每 token / 每序列 KV Cache（BF16）==
  模型                      KB/token     ctx=4096    ctx=32768   ctx=131072
  Llama-2-7B (MHA)           512.0       2.00GB      16.00GB      64.00GB
  Llama-3-8B (GQA-8)         128.0       0.50GB       4.00GB      16.00GB
  Qwen2.5-7B (GQA-4)          56.0       0.22GB       1.75GB       7.00GB
  Llama-3-70B (GQA-8)        320.0       1.25GB      10.00GB      40.00GB
  DeepSeek-V3 (MLA)           68.6       0.27GB       2.14GB       8.58GB

== 单卡 80GB 能容纳的 4K 上下文并发数（权重 BF16，预留 10% 给激活/碎片）==
  Llama-2-7B (MHA)       剩余  58.6GB → 最多   27 条
  Llama-3-8B (GQA-8)     剩余  56.0GB → 最多  104 条
  Qwen2.5-7B (GQA-4)     剩余  56.8GB → 最多  241 条

== Llama-3-8B (GQA-8) 在 H100 上的 roofline 延迟估算 ==
  TTFT(prompt=  512) ≥    8.42 ms（算力受限）
  TTFT(prompt= 2048) ≥   35.36 ms（算力受限）
  TTFT(prompt= 8192) ≥  168.11 ms（算力受限）
  TPOT(batch=  1, ctx=4K) ≥   4.94 ms，吞吐 ≤     203 tok/s，KV 占读取量  3.2%
  TPOT(batch=  8, ctx=4K) ≥   6.06 ms，吞吐 ≤    1321 tok/s，KV 占读取量 21.2%
  TPOT(batch= 32, ctx=4K) ≥   9.90 ms，吞吐 ≤    3231 tok/s，KV 占读取量 51.8%
  TPOT(batch= 64, ctx=4K) ≥  15.03 ms，吞吐 ≤    4257 tok/s，KV 占读取量 68.2%

[小结] prefill 一次处理整段 prompt，是大矩阵乘，算力受限；decode 每步只算 1 个 token，却要读全部权重
       和 KV，访存受限。batch 增大时 KV 读取逐渐取代权重读取成为主导——GQA/MLA、KV 量化、
       PagedAttention 都在这条线上做文章。
[问题库] P01 decode 访存受限；P02 KV Cache 并发上限；P07 长上下文
```

### `labs/m10_inference_basics/lab_02_tiny_gpt_kvcache.py`

```python
"""[M10-L02] 小型 GPT（随机权重）上实测：有/无 KV Cache 的生成、prefill 与 decode 的耗时

目标：亲手实现带 KV Cache 的自回归生成，验证与无 Cache 版本输出逐 token 一致；
      测量每个 token 的耗时随位置的变化、prefill 与 decode 的单 token 成本差异，以及批量 decode 的吞吐。
先预测：
  1. 不用 KV Cache，生成第 t 个 token 的耗时与 t 是什么关系？用了之后呢？
  2. prefill 512 个 token 的总时间，和 decode 512 次（每次 1 个 token）相比，谁快？快多少倍？
可调参数：--layers、--d、--heads、--vocab、--prompt、--gen、--batch（列表）
说明：权重随机初始化，不下载任何模型；只研究系统行为，不关心生成内容。
暴露的问题：decode 逐 token 串行、小 batch 硬件利用率低 → PROBLEM_BANK P01、P05
对应论文：Orca（迭代级调度的动机）；vLLM；FlexGen
真实框架对照：karpathy/nanoGPT model.py（无 KV Cache 的 generate）；
              GeeeekExplorer/nano-vllm（带 KV Cache 的最小推理引擎）
"""
import argparse
import time

import torch
import torch.nn as nn
import torch.nn.functional as F


class Block(nn.Module):
    def __init__(self, d, h):
        super().__init__()
        self.h, self.ln1, self.ln2 = h, nn.LayerNorm(d), nn.LayerNorm(d)
        self.qkv, self.proj = nn.Linear(d, 3 * d), nn.Linear(d, d)
        self.mlp = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))

    def forward(self, x, cache=None):
        B, T, D = x.shape
        q, k, v = self.qkv(self.ln1(x)).split(D, dim=-1)
        q, k, v = (t.view(B, T, self.h, D // self.h).transpose(1, 2) for t in (q, k, v))
        if cache is not None:
            if "k" in cache:                                   # 拼接历史 K/V
                k = torch.cat([cache["k"], k], dim=2); v = torch.cat([cache["v"], v], dim=2)
            cache["k"], cache["v"] = k, v
        # 因果掩码：只有 prefill（T>1）需要；decode 时新 token 可以看到全部历史
        y = F.scaled_dot_product_attention(q, k, v, is_causal=(T > 1))
        x = x + self.proj(y.transpose(1, 2).reshape(B, T, D))
        return x + self.mlp(self.ln2(x))


class TinyGPT(nn.Module):
    def __init__(self, vocab, d, h, layers, max_len=2048):
        super().__init__()
        self.tok, self.pos = nn.Embedding(vocab, d), nn.Embedding(max_len, d)
        self.blocks = nn.ModuleList(Block(d, h) for _ in range(layers))
        self.head = nn.Linear(d, vocab, bias=False)

    def forward(self, idx, caches=None, start=0):
        x = self.tok(idx) + self.pos(torch.arange(start, start + idx.shape[1]))
        for i, b in enumerate(self.blocks):
            x = b(x, None if caches is None else caches[i])
        return self.head(x[:, -1])


@torch.no_grad()
def generate(model, prompt, n, use_cache):
    idx, times = prompt, []
    caches = [{} for _ in model.blocks] if use_cache else None
    t0 = time.perf_counter()
    logits = model(idx, caches)                                 # prefill
    prefill = time.perf_counter() - t0
    for _ in range(n):
        nxt = logits.argmax(-1, keepdim=True)
        idx = torch.cat([idx, nxt], dim=1)
        t0 = time.perf_counter()
        logits = model(nxt, caches, start=idx.shape[1] - 1) if use_cache else model(idx)
        times.append(time.perf_counter() - t0)
    return idx, prefill, times


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", type=int, default=4)
    ap.add_argument("--d", type=int, default=256)
    ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--vocab", type=int, default=2000)
    ap.add_argument("--prompt", type=int, default=256)
    ap.add_argument("--gen", type=int, default=256)
    ap.add_argument("--batch", type=int, nargs="+", default=[1, 4, 16, 64])
    a = ap.parse_args()
    torch.manual_seed(0)
    model = TinyGPT(a.vocab, a.d, a.heads, a.layers).eval()
    prompt = torch.randint(0, a.vocab, (1, a.prompt))
    generate(model, prompt[:, :16], 4, True)                    # 预热

    out_c, pre_c, t_c = generate(model, prompt, a.gen, True)
    out_n, pre_n, t_n = generate(model, prompt, a.gen, False)
    print(f"== {a.layers} 层、d={a.d}、prompt={a.prompt}、生成 {a.gen} 个 token ==")
    print(f"  有/无 KV Cache 生成结果一致：{torch.equal(out_c, out_n)}")
    q = max(1, a.gen // 4)
    for name, ts in [("有 Cache", t_c), ("无 Cache", t_n)]:
        segs = [sum(ts[i:i + q]) / len(ts[i:i + q]) * 1e3 for i in range(0, a.gen, q)]
        print(f"  {name}: 每 token 平均耗时（按生成进度四等分）" + " → ".join(f"{s:.2f}ms" for s in segs)
              + f"   总计 {sum(ts):.2f}s")
    print(f"\n  prefill {a.prompt} token：{pre_c * 1e3:.1f} ms（{pre_c / a.prompt * 1e3:.3f} ms/token）"
          f"  vs decode 平均 {sum(t_c) / len(t_c) * 1e3:.2f} ms/token → 单 token 成本相差 "
          f"{(sum(t_c) / len(t_c)) / (pre_c / a.prompt):.0f}×")

    print("\n== 批量 decode 的吞吐（每条序列已有 prompt 长度的 KV）==")
    for b in a.batch:
        p = torch.randint(0, a.vocab, (b, a.prompt))
        _, _, ts = generate(model, p, 32, True)
        step = sum(ts[4:]) / len(ts[4:])
        print(f"  batch={b:3d}: 每步 {step * 1e3:6.2f} ms，吞吐 {b / step:8.0f} tok/s")
    print("\n[小结] KV Cache 把每步计算从 O(t) 次重复前向变成只算新 token；prefill 一次处理很多 token，"
          "\n       单 token 成本远低于 decode。小 batch 时每步耗时增长远慢于 batch，吞吐随 batch 上升——"
          "\n       这正是 continuous batching 要尽量多凑请求的原因（M11）。但 batch 继续增大时，本机 CPU 很快"
          "\n       转为算力受限（CPU 屋脊点只有约 12 FLOP/B，见 M01-L01），吞吐不再增长甚至下降；GPU 的屋脊点"
          "\n       高一个数量级以上，饱和点出现在大得多的 batch。用 M01 的 roofline 解释你看到的拐点。"
          "\n[问题库] P01 decode 访存受限；P05 prefill/decode 特性差异")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m10_inference_basics/outputs/lab_02_tiny_gpt_kvcache.txt`）：

```text
# 实测输出：m10_inference_basics/lab_02_tiny_gpt_kvcache.py
# 运行时间：2026-10-18 21:30，耗时 4.9s，峰值内存 722MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 4 层、d=256、prompt=256、生成 256 个 token ==
  有/无 KV Cache 生成结果一致：True
  有 Cache: 每 token 平均耗时（按生成进度四等分）0.74ms → 0.70ms → 0.81ms → 0.74ms   总计 0.19s
  无 Cache: 每 token 平均耗时（按生成进度四等分）7.42ms → 8.82ms → 10.61ms → 12.74ms   总计 2.53s

  prefill 256 token：10.5 ms（0.041 ms/token）  vs decode 平均 0.75 ms/token → 单 token 成本相差 18×

== 批量 decode 的吞吐（每条序列已有 prompt 长度的 KV）==
  batch=  1: 每步   0.87 ms，吞吐     1145 tok/s
  batch=  4: 每步   1.12 ms，吞吐     3561 tok/s
  batch= 16: 每步   3.02 ms，吞吐     5302 tok/s
  batch= 64: 每步  18.51 ms，吞吐     3457 tok/s

[小结] KV Cache 把每步计算从 O(t) 次重复前向变成只算新 token；prefill 一次处理很多 token，
       单 token 成本远低于 decode。小 batch 时每步耗时增长远慢于 batch，吞吐随 batch 上升——
       这正是 continuous batching 要尽量多凑请求的原因（M11）。但 batch 继续增大时，本机 CPU 很快
       转为算力受限（CPU 屋脊点只有约 12 FLOP/B，见 M01-L01），吞吐不再增长甚至下降；GPU 的屋脊点
       高一个数量级以上，饱和点出现在大得多的 batch。用 M01 的 roofline 解释你看到的拐点。
[问题库] P01 decode 访存受限；P05 prefill/decode 特性差异
```

## M11 推理服务系统：连续批处理、PagedAttention、前缀缓存、分块 prefill、PD 分离、SLO 调度（`labs/m11_serving/`）

### `labs/m11_serving/lab_01_paged_kv_allocator.py`

```python
"""[M11-L01] 从零实现分页 KV Cache 分配器（PagedAttention 的内存管理部分）

目标：实现块池（block pool）+ 每序列块表（block table）+ 引用计数 + 写时复制（copy-on-write），
      支持追加 token、并行采样 fork、释放；与"按最大长度连续预分配"比较显存浪费与可容纳的并发数。
先预测：
  1. 请求输出长度在 [16, 2048] 均匀分布、按 2048 预分配，平均浪费多少显存？块大小 16 时呢？
  2. 并行采样 n=4（共享同一个 1000 token 的 prompt），分页 + 共享比各自复制省多少块？
可调参数：--block（块大小，token 数）、--capacity（总块数）、--requests、--max-len
暴露的问题：KV 显存是并发上限；块大小影响碎片与 kernel 效率 → PROBLEM_BANK P02
对应论文：vLLM / PagedAttention（2309.06180）；Jenga（异构 embedding 的分配器，SOSP'25）
真实框架对照：vllm-project/vllm vllm/v1/core/block_pool.py、kv_cache_manager.py（V1 引擎）
"""
import argparse
import random


class BlockPool:
    def __init__(self, n_blocks):
        self.free = list(range(n_blocks))[::-1]
        self.ref = [0] * n_blocks

    def alloc(self):
        if not self.free:
            raise MemoryError("KV 块耗尽（真实系统会触发抢占：换出或丢弃后重算）")
        b = self.free.pop(); self.ref[b] = 1
        return b

    def incref(self, b):
        self.ref[b] += 1

    def decref(self, b):
        self.ref[b] -= 1
        if self.ref[b] == 0:
            self.free.append(b)


class Sequence:
    def __init__(self, pool, block_size):
        self.pool, self.bs, self.table, self.n = pool, block_size, [], 0

    def append(self, k=1):
        for _ in range(k):
            if self.n % self.bs == 0:                       # 最后一块满了（或还没有块）→ 申请新块
                self.table.append(self.pool.alloc())
            elif self.pool.ref[self.table[-1]] > 1:          # 最后一块被共享 → 写时复制
                old = self.table[-1]
                self.table[-1] = self.pool.alloc()           # （真实实现还要拷贝块内已有的 KV）
                self.pool.decref(old)
            self.n += 1

    def fork(self):
        child = Sequence(self.pool, self.bs)
        child.table, child.n = list(self.table), self.n
        for b in self.table:
            self.pool.incref(b)                              # 共享全部块，只增加引用计数
        return child

    def free(self):
        for b in self.table:
            self.pool.decref(b)
        self.table, self.n = [], 0


def contiguous_waste(lengths, max_len):
    return 1 - sum(lengths) / (len(lengths) * max_len)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--block", type=int, nargs="+", default=[1, 16, 64, 256])
    ap.add_argument("--capacity", type=int, default=200_000, help="KV 容量（token 数）")
    ap.add_argument("--requests", type=int, default=2000)
    ap.add_argument("--max-len", type=int, default=2048)
    a = ap.parse_args()
    rng = random.Random(0)
    lengths = [rng.randint(16, a.max_len) for _ in range(a.requests)]

    print(f"== 显存浪费：{a.requests} 个请求，长度均匀分布于 [16, {a.max_len}] ==")
    print(f"  连续预分配（按最大长度 {a.max_len}）：浪费 {contiguous_waste(lengths, a.max_len):.1%}，"
          f"容量 {a.capacity} token 可同时容纳 {a.capacity // a.max_len} 条")
    avg = sum(lengths) / len(lengths)
    for bs in a.block:
        waste = sum((-l) % bs for l in lengths) / sum(lengths + [(-l) % bs for l in lengths])
        print(f"  分页 block={bs:4d}：内部碎片 {waste:6.2%}，平均可同时容纳约 "
              f"{int(a.capacity / (avg + bs / 2))} 条")

    print("\n== 功能验证：追加、fork、写时复制、释放 ==")
    bs = 16
    pool = BlockPool(a.capacity // bs)
    total = len(pool.free)
    parent = Sequence(pool, bs); parent.append(1000)        # 1000 token 的 prompt → 63 块
    used_prompt = total - len(pool.free)
    kids = [parent.fork() for _ in range(3)]                 # 并行采样 n=4（parent + 3 个 child）
    for s in [parent] + kids:
        s.append(200)                                        # 各自生成 200 token
    used_shared = total - len(pool.free)
    used_copy = 4 * ((1200 + bs - 1) // bs)
    print(f"  prompt 1000 token 占 {used_prompt} 块；4 路采样各生成 200 token 后共占 {used_shared} 块，"
          f"若各自复制需 {used_copy} 块（节省 {1 - used_shared / used_copy:.0%}）")
    print(f"  共享块引用计数示例：块 {parent.table[0]} 的 ref = {pool.ref[parent.table[0]]}")
    for s in [parent] + kids:
        s.free()
    print(f"  全部释放后空闲块 {len(pool.free)} / {total}（应相等）")
    try:
        big = Sequence(BlockPool(4), bs); big.append(100)
    except MemoryError as e:
        print(f"  容量不足时：{e}")
    print("\n[小结] 分页让 KV 只按实际长度占用，碎片被限制在每条序列最后一块；块表 + 引用计数让 fork/前缀共享"
          "\n       几乎零成本。块越小碎片越少，但块表更长、attention kernel 访存更零散——这是块大小的取舍。"
          "\n[问题库] P02 KV Cache 是并发上限")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m11_serving/outputs/lab_01_paged_kv_allocator.txt`）：

```text
# 实测输出：m11_serving/lab_01_paged_kv_allocator.py
# 运行时间：2026-10-18 21:30，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 显存浪费：2000 个请求，长度均匀分布于 [16, 2048] ==
  连续预分配（按最大长度 2048）：浪费 50.1%，容量 200000 token 可同时容纳 97 条
  分页 block=   1：内部碎片  0.00%，平均可同时容纳约 195 条
  分页 block=  16：内部碎片  0.73%，平均可同时容纳约 194 条
  分页 block=  64：内部碎片  2.96%，平均可同时容纳约 189 条
  分页 block= 256：内部碎片 11.10%，平均可同时容纳约 173 条

== 功能验证：追加、fork、写时复制、释放 ==
  prompt 1000 token 占 63 块；4 路采样各生成 200 token 后共占 114 块，若各自复制需 300 块（节省 62%）
  共享块引用计数示例：块 0 的 ref = 4
  全部释放后空闲块 12500 / 12500（应相等）
  容量不足时：KV 块耗尽（真实系统会触发抢占：换出或丢弃后重算）

[小结] 分页让 KV 只按实际长度占用，碎片被限制在每条序列最后一块；块表 + 引用计数让 fork/前缀共享
       几乎零成本。块越小碎片越少，但块表更长、attention kernel 访存更零散——这是块大小的取舍。
[问题库] P02 KV Cache 是并发上限
```

### `labs/m11_serving/lab_02_continuous_batching_sim.py`

```python
"""[M11-L02] 推理调度模拟器：静态批处理 vs 连续批处理（continuous batching）vs 分块 prefill（chunked prefill）

目标：用离散事件模拟比较三种调度在相同负载下的 TTFT、TPOT、最长卡顿（max inter-token latency）
      和吞吐；观察 KV 容量不足时的抢占（preemption，按重算处理）。
先预测：
  1. 静态批处理为什么吞吐低？（提示：短请求要陪长请求"空转"，新请求要等整批结束）
  2. 连续批处理中，一个 2000 token 的 prompt 插进来时，正在 decode 的请求会发生什么？
  3. 分块 prefill 的 token 预算设大设小，各自损害哪个指标？
可调参数：--rate（请求/秒，列表）、--n、--kv-cap（KV 容量 token 数）、--budget（chunked 的每步 token 预算）
暴露的问题：prefill 与 decode 互相干扰、TTFT/TPOT 取舍、抢占重算的浪费 → PROBLEM_BANK P05、P03、P30
对应论文：Orca（OSDI'22，迭代级调度）；vLLM；Sarathi / Sarathi-Serve（分块 prefill）
真实框架对照：vllm-project/vllm vllm/v1/core/sched/scheduler.py（V1 统一按 token 预算调度）
迭代耗时模型（假设，类比 8B 模型在单卡 H100）：t = 5ms + 0.03ms×prefill token 数 + 0.04ms×decode 序列数
"""
import argparse
import random


def it_time(prefill_tokens, n_decode):
    return 5.0 + 0.03 * prefill_tokens + 0.04 * n_decode


def workload(n, rate, seed=0):
    rng = random.Random(seed)
    t, reqs = 0.0, []
    for i in range(n):
        t += rng.expovariate(rate) * 1000                    # 毫秒
        reqs.append({"id": i, "arr": t, "P": rng.randint(64, 2048), "O": rng.randint(16, 512)})
    return reqs


def run_static(reqs, B=32, wait=50.0):
    t, i, toks = 0.0, 0, {}
    while i < len(reqs):
        t = max(t, reqs[i]["arr"])
        j = i
        while j < len(reqs) and j - i < B and reqs[j]["arr"] <= t + wait:
            j += 1
        batch = reqs[i:j]
        t = max(t, batch[-1]["arr"])
        t += it_time(sum(r["P"] for r in batch), 0)             # 整批 prefill
        for r in batch:
            toks[r["id"]] = [t]
        for step in range(1, max(r["O"] for r in batch)):      # 按最长输出解码，结束的请求占位空转
            t += it_time(0, len(batch))
            for r in batch:
                if step < r["O"]:
                    toks[r["id"]].append(t)
        i = j
    return toks, 0


def run_dynamic(reqs, kv_cap, chunked, budget=512, max_seqs=256):
    t, nxt, waiting, running, toks, preempt = 0.0, 0, [], [], {}, 0
    while nxt < len(reqs) or waiting or running:
        while nxt < len(reqs) and reqs[nxt]["arr"] <= t:
            r = dict(reqs[nxt]); r["done_p"] = 0; r["gen"] = 0
            waiting.append(r); nxt += 1
        if not waiting and not running:
            t = reqs[nxt]["arr"]; continue
        used = sum(r["P"] + r["gen"] for r in running)
        # 抢占：KV 不够容纳下一步增长时，踢掉最新加入的请求（重算：已生成的 token 并入 prompt 重新 prefill）
        while running and used + len(running) > kv_cap:
            v = running.pop(); preempt += 1
            used -= v["P"] + v["gen"]
            v["P"] += v["gen"]; v["O"] -= v["gen"]; v["gen"] = 0; v["done_p"] = 0
            waiting.insert(0, v)
        decodes = [r for r in running if r["done_p"] >= r["P"]]
        if chunked:                                            # 先放全部 decode，再用剩余预算塞 prefill 块
            room, plan = budget - len(decodes), []
            for r in running + waiting:
                if room <= 0:
                    break
                if r["done_p"] < r["P"] and (r in running or used + r["P"] <= kv_cap) and len(running) < max_seqs:
                    if r in waiting:
                        waiting.remove(r); running.append(r); used += r["P"]
                    c = min(room, r["P"] - r["done_p"]); plan.append((r, c)); room -= c
            dt = it_time(sum(c for _, c in plan), len(decodes))
        else:                                                  # 有新请求且放得下就先做整段 prefill（decode 暂停）
            plan = []
            while waiting and used + waiting[0]["P"] <= kv_cap and len(running) < max_seqs:
                r = waiting.pop(0); running.append(r); used += r["P"]; plan.append((r, r["P"]))
            if plan:
                decodes = []
            dt = it_time(sum(c for _, c in plan), len(decodes))
        t += dt
        for r, c in plan:
            r["done_p"] += c
            if r["done_p"] >= r["P"]:                          # prefill 完成即产出一个 token
                toks.setdefault(r["id"], []).append(t); r["gen"] += 1
        for r in decodes:
            toks.setdefault(r["id"], []).append(t); r["gen"] += 1
        running = [r for r in running if not (r["done_p"] >= r["P"] and r["gen"] >= r["O"])]
    return toks, preempt


def pct(xs, p):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(p / 100 * len(xs)))]


def summarize(name, reqs, toks, preempt):
    ttft = [toks[r["id"]][0] - r["arr"] for r in reqs]
    tpot = [(toks[r["id"]][-1] - toks[r["id"]][0]) / max(1, len(toks[r["id"]]) - 1) for r in reqs]
    stall = [max([b - a for a, b in zip(toks[r["id"]], toks[r["id"]][1:])] or [0]) for r in reqs]
    span = max(v[-1] for v in toks.values()) - reqs[0]["arr"]
    n_tok = sum(len(v) for v in toks.values())
    print(f"  {name:10s} TTFT p50/p99={pct(ttft, 50):7.0f}/{pct(ttft, 99):7.0f}ms  "
          f"TPOT p50/p99={pct(tpot, 50):5.1f}/{pct(tpot, 99):5.1f}ms  最长卡顿p99={pct(stall, 99):6.0f}ms  "
          f"吞吐={n_tok / span * 1000:6.0f}tok/s  抢占={preempt}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rate", type=float, nargs="+", default=[2, 6, 10])
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--kv-cap", type=int, default=120_000)
    ap.add_argument("--budget", type=int, default=512)
    a = ap.parse_args()
    for rate in a.rate:
        reqs = workload(a.n, rate)
        print(f"\n== 到达率 {rate} req/s，{a.n} 个请求，KV 容量 {a.kv_cap} token ==")
        summarize("静态批", reqs, *run_static(reqs))
        summarize("连续批", reqs, *run_dynamic(reqs, a.kv_cap, chunked=False))
        summarize(f"分块({a.budget})", reqs, *run_dynamic(reqs, a.kv_cap, chunked=True, budget=a.budget))
    reqs = workload(a.n, a.rate[-1])
    print(f"\n== 分块 prefill 的预算扫描（到达率 {a.rate[-1]}）==")
    for b in [128, 512, 2048, 8192]:
        summarize(f"budget={b}", reqs, *run_dynamic(reqs, a.kv_cap, chunked=True, budget=b))
    cap = a.kv_cap // 5
    print(f"\n== KV 紧张：容量降到 {cap} token（到达率 {a.rate[-1]}），观察抢占与重算 ==")
    summarize("连续批", reqs, *run_dynamic(reqs, cap, chunked=False))
    summarize(f"分块({a.budget})", reqs, *run_dynamic(reqs, cap, chunked=True, budget=a.budget))
    print("\n[小结] 连续批处理在每次迭代接纳/释放请求，吞吐远高于静态批；但整段 prefill 插队会让正在 decode 的请求"
          "\n       卡顿（最长卡顿高）。分块 prefill 用 token 预算把 prefill 切碎、与 decode 同批，平滑 TPOT；"
          "\n       预算太小则 prefill 变慢、TTFT 上升。KV 不足时的抢占要重算，白白浪费算力。"
          "\n[问题库] P05 prefill/decode 干扰；P03 抢占重算；P30 SLO 感知调度")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m11_serving/outputs/lab_02_continuous_batching_sim.txt`）：

```text
# 实测输出：m11_serving/lab_02_continuous_batching_sim.py
# 运行时间：2026-10-18 21:30，耗时 0.4s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）


== 到达率 2 req/s，300 个请求，KV 容量 120000 token ==
  静态批        TTFT p50/p99=   1171/   2924ms  TPOT p50/p99=  5.2/  5.4ms  最长卡顿p99=     5ms  吞吐=   502tok/s  抢占=0
  连续批        TTFT p50/p99=     39/     91ms  TPOT p50/p99=  5.5/  6.7ms  最长卡顿p99=   108ms  吞吐=   507tok/s  抢占=0
  分块(512)    TTFT p50/p99=     49/    114ms  TPOT p50/p99=  5.4/  6.4ms  最长卡顿p99=    20ms  吞吐=   507tok/s  抢占=0

== 到达率 6 req/s，300 个请求，KV 容量 120000 token ==
  静态批        TTFT p50/p99=   2227/   4185ms  TPOT p50/p99=  5.8/  6.0ms  最长卡顿p99=     6ms  吞吐=  1422tok/s  抢占=0
  连续批        TTFT p50/p99=     44/    116ms  TPOT p50/p99=  6.8/  9.7ms  最长卡顿p99=   163ms  吞吐=  1466tok/s  抢占=0
  分块(512)    TTFT p50/p99=     59/    143ms  TPOT p50/p99=  6.6/  9.1ms  最长卡顿p99=    21ms  吞吐=  1466tok/s  抢占=0

== 到达率 10 req/s，300 个请求，KV 容量 120000 token ==
  静态批        TTFT p50/p99=   5888/   9991ms  TPOT p50/p99=  6.3/  6.3ms  最长卡顿p99=     6ms  吞吐=  1879tok/s  抢占=0
  连续批        TTFT p50/p99=     49/    124ms  TPOT p50/p99=  8.9/ 13.1ms  最长卡顿p99=   312ms  吞吐=  2352tok/s  抢占=0
  分块(512)    TTFT p50/p99=     67/    182ms  TPOT p50/p99=  8.2/ 11.3ms  最长卡顿p99=    21ms  吞吐=  2353tok/s  抢占=0

== 分块 prefill 的预算扫描（到达率 10）==
  budget=128 TTFT p50/p99=    233/    687ms  TPOT p50/p99=  8.3/  9.1ms  最长卡顿p99=     9ms  吞吐=  2341tok/s  抢占=0
  budget=512 TTFT p50/p99=     67/    182ms  TPOT p50/p99=  8.2/ 11.3ms  最长卡顿p99=    21ms  吞吐=  2353tok/s  抢占=0
  budget=2048 TTFT p50/p99=     52/    134ms  TPOT p50/p99=  8.2/ 11.3ms  最长卡顿p99=    67ms  吞吐=  2354tok/s  抢占=0
  budget=8192 TTFT p50/p99=     52/    123ms  TPOT p50/p99=  8.2/ 11.3ms  最长卡顿p99=   111ms  吞吐=  2354tok/s  抢占=0

== KV 紧张：容量降到 24000 token（到达率 10），观察抢占与重算 ==
  连续批        TTFT p50/p99=  13535/  31658ms  TPOT p50/p99= 15.6/ 29.8ms  最长卡顿p99=  1213ms  吞吐=  1219tok/s  抢占=917
  分块(512)    TTFT p50/p99=    443/  21867ms  TPOT p50/p99= 10.0/ 24.7ms  最长卡顿p99=  2374ms  吞吐=  1948tok/s  抢占=307

[小结] 连续批处理在每次迭代接纳/释放请求，吞吐远高于静态批；但整段 prefill 插队会让正在 decode 的请求
       卡顿（最长卡顿高）。分块 prefill 用 token 预算把 prefill 切碎、与 decode 同批，平滑 TPOT；
       预算太小则 prefill 变慢、TTFT 上升。KV 不足时的抢占要重算，白白浪费算力。
[问题库] P05 prefill/decode 干扰；P03 抢占重算；P30 SLO 感知调度
```

### `labs/m11_serving/lab_03_radix_prefix_cache.py`

```python
"""[M11-L03] 前缀缓存（prefix caching）：前缀树 + LRU 驱逐，三种真实负载下的命中率

目标：实现一个 token 级前缀树（RadixAttention 中 radix 树的未压缩版本），支持最长前缀匹配、插入、
      按 LRU 驱逐叶子；在"共享系统提示""多轮对话""推理模型多轮对话"三种负载下测命中率随容量的变化；
      复现 SGLang issue #22373 描述的问题：推理模型的 thinking token 不会出现在下一轮 prompt 中，
      却被插入缓存，成为永远不会命中的"死分支"，挤占有用条目。
先预测：
  1. 多轮对话里，缓存容量只有总 token 量的 10% 时，命中率大约多少？
  2. 推理模型多轮对话中，"只缓存 prompt"和"缓存 prompt+输出（含 thinking）"哪个命中率高？总是如此吗？
可调参数：--caps（容量，token 数列表）、--sessions、--turns
暴露的问题：前缀缓存命中率在 agentic/推理负载下下降；驱逐策略需要理解负载语义 → PROBLEM_BANK P04、P03
对应论文：SGLang（2312.07104，RadixAttention）；Marconi（MLSys'25，混合模型的前缀缓存）；
          工程证据：sgl-project/sglang issue #22373、vllm-project/vllm issue #37003
真实框架对照：sgl-project/sglang python/sglang/srt/mem_cache/radix_cache.py（cache_finished_req、evict）
"""
import argparse
import heapq
import itertools
import random


class Node:
    __slots__ = ("children", "parent", "tok", "last")

    def __init__(self, parent, tok):
        self.children, self.parent, self.tok, self.last = {}, parent, tok, 0


class PrefixCache:
    def __init__(self, cap):
        self.root, self.cap, self.size, self.clock = Node(None, None), cap, 0, 0

    def match(self, toks):
        node, n = self.root, 0
        self.clock += 1
        for t in toks:
            if t not in node.children:
                break
            node = node.children[t]; node.last = self.clock; n += 1
        return n

    def insert(self, toks):
        node = self.root
        self.clock += 1
        for t in toks:
            if t not in node.children:
                node.children[t] = Node(node, t); self.size += 1
            node = node.children[t]; node.last = self.clock
        self.evict()

    def evict(self):
        if self.size <= self.cap:
            return
        heap, stack = [], [self.root]
        while stack:                                           # 收集所有叶子
            n = stack.pop()
            stack.extend(n.children.values())
            if not n.children and n is not self.root:
                heapq.heappush(heap, (n.last, id(n), n))
        while self.size > self.cap and heap:                   # 驱逐最久未用的叶子，父节点变叶子后入堆
            _, _, n = heapq.heappop(heap)
            p = n.parent
            del p.children[n.tok]; self.size -= 1
            if not p.children and p is not self.root:
                heapq.heappush(heap, (p.last, id(p), p))


fresh = itertools.count(1)


def new(k):
    return [next(fresh) for _ in range(k)]


def wl_system_prompt(rng, n=400):
    sys_p = new(800)
    return [(sys_p + new(rng.randint(50, 200)), new(100), []) for _ in range(n)]


def wl_multiturn(rng, sessions, turns, think=0):
    """返回 [(prompt, answer, thinking)]，按会话随机交错。think>0 表示推理模型：输出含 thinking，下一轮不带。"""
    hist = {s: new(300) for s in range(sessions)}             # 每个会话自己的系统提示/背景
    order = [s for s in range(sessions) for _ in range(turns)]
    rng.shuffle(order)
    out = []
    for s in order:
        prompt = hist[s] + new(rng.randint(30, 80))            # 历史 + 新的用户消息
        thinking, answer = new(think), new(rng.randint(60, 150))
        out.append((prompt, answer, thinking))
        hist[s] = prompt + answer                              # 下一轮历史只包含最终回答
    return out


def hit_rate(reqs, cap, policy):
    c = PrefixCache(cap)
    hit = total = 0
    for prompt, answer, thinking in reqs:
        hit += c.match(prompt); total += len(prompt)
        if policy == "prompt+output":
            c.insert(prompt + thinking + answer)               # SGLang 默认：输出 token 全部插入
        else:
            c.insert(prompt)                                   # issue #22373 提议：有 thinking 时只缓存 prompt
    return hit / total


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--caps", type=int, nargs="+", default=[5000, 20000, 80000, 320000])
    ap.add_argument("--sessions", type=int, default=60)
    ap.add_argument("--turns", type=int, default=6)
    a = ap.parse_args()
    rng = random.Random(0)
    loads = {
        "共享系统提示": wl_system_prompt(rng),
        "多轮对话": wl_multiturn(rng, a.sessions, a.turns),
        "推理模型多轮(thinking=600)": wl_multiturn(rng, a.sessions, a.turns, think=600),
    }
    for name, reqs in loads.items():
        tot = sum(len(p) for p, _, _ in reqs)
        print(f"\n== {name}：{len(reqs)} 个请求，prompt 共 {tot} token ==")
        for cap in a.caps:
            r1 = hit_rate(reqs, cap, "prompt+output")
            r2 = hit_rate(reqs, cap, "prompt-only")
            print(f"  容量 {cap:7d}：缓存 prompt+输出 命中率 {r1:6.1%}   只缓存 prompt 命中率 {r2:6.1%}")
    print("\n[小结] 共享前缀负载下命中率很高；多轮对话里缓存输出能让下一轮命中'上一轮的回答'。推理模型的 thinking"
          "\n       不会进入下一轮 prompt，插入它们只会制造死分支、挤掉有用条目——容量小时损害明显；但只缓存 prompt"
          "\n       又会丢掉对回答的复用。更好的策略需要理解负载语义（如按 token 类型/会话感知驱逐），这是开放问题。"
          "\n[问题库] P04 前缀缓存命中率；P03 驱逐导致的重复 prefill")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m11_serving/outputs/lab_03_radix_prefix_cache.txt`）：

```text
# 实测输出：m11_serving/lab_03_radix_prefix_cache.py
# 运行时间：2026-10-18 21:30，耗时 8.2s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）


== 共享系统提示：400 个请求，prompt 共 368937 token ==
  容量    5000：缓存 prompt+输出 命中率  86.5%   只缓存 prompt 命中率  86.5%
  容量   20000：缓存 prompt+输出 命中率  86.5%   只缓存 prompt 命中率  86.5%
  容量   80000：缓存 prompt+输出 命中率  86.5%   只缓存 prompt 命中率  86.5%
  容量  320000：缓存 prompt+输出 命中率  86.5%   只缓存 prompt 命中率  86.5%

== 多轮对话：360 个请求，prompt 共 271402 token ==
  容量    5000：缓存 prompt+输出 命中率   8.0%   只缓存 prompt 命中率   7.6%
  容量   20000：缓存 prompt+输出 命中率  33.9%   只缓存 prompt 命中率  30.9%
  容量   80000：缓存 prompt+输出 命中率  86.0%   只缓存 prompt 命中率  74.5%
  容量  320000：缓存 prompt+输出 命中率  86.0%   只缓存 prompt 命中率  74.5%

== 推理模型多轮(thinking=600)：360 个请求，prompt 共 270853 token ==
  容量    5000：缓存 prompt+输出 命中率   5.0%   只缓存 prompt 命中率   9.4%
  容量   20000：缓存 prompt+输出 命中率  16.4%   只缓存 prompt 命中率  31.1%
  容量   80000：缓存 prompt+输出 命中率  52.9%   只缓存 prompt 命中率  74.5%
  容量  320000：缓存 prompt+输出 命中率  74.5%   只缓存 prompt 命中率  74.5%

[小结] 共享前缀负载下命中率很高；多轮对话里缓存输出能让下一轮命中'上一轮的回答'。推理模型的 thinking
       不会进入下一轮 prompt，插入它们只会制造死分支、挤掉有用条目——容量小时损害明显；但只缓存 prompt
       又会丢掉对回答的复用。更好的策略需要理解负载语义（如按 token 类型/会话感知驱逐），这是开放问题。
[问题库] P04 前缀缓存命中率；P03 驱逐导致的重复 prefill
```

### `labs/m11_serving/lab_04_pd_disaggregation.py`

```python
"""[M11-L04] Prefill/Decode 分离（PD disaggregation）vs 混合部署：在 SLO 约束下比较 goodput

目标：在 4 张 GPU 上比较"每卡都做 prefill+decode（分块 prefill）"与"P 张卡专做 prefill、D 张卡专做 decode，
      中间传输 KV"两种部署；以同时满足 TTFT 与 TPOT SLO 的请求速率（goodput）为指标，寻找最佳 P:D 配比。
先预测：
  1. TPOT SLO 很严格（如 12ms）时，哪种部署更好？TTFT SLO 很严格时呢？
  2. KV 传输带宽从 50GB/s 降到 5GB/s，PD 分离还划算吗？
可调参数：--rates（req/s 列表）、--slo-ttft、--slo-tpot（ms）、--kv-bw（GB/s）
暴露的问题：PD 分离的资源配比、KV 传输开销 → PROBLEM_BANK P06、P05
对应论文：DistServe（2401.09670，goodput 与配比搜索）；Splitwise（2311.18677）；Mooncake（2407.00079）；
          TetriInfer；工程实现：NVIDIA Dynamo、llm-d、vLLM/SGLang 的 PD 分离
迭代耗时模型同 lab_02（假设）：t = 5ms + 0.03ms×prefill token + 0.04ms×decode 序列；每 token KV 128KB（Llama-3-8B）
"""
import argparse
import random


def it_time(p, d):
    return 5.0 + 0.03 * p + 0.04 * d


def workload(n, rate, p_rng=(256, 4096), o_rng=(32, 384), seed=0):
    rng = random.Random(seed)
    t, out = 0.0, []
    for i in range(n):
        t += rng.expovariate(rate) * 1000
        out.append({"id": i, "arr": t, "P": rng.randint(*p_rng), "O": rng.randint(*o_rng)})
    return out


def decode_gpu(items):
    """items: [(ready_time, req, first_token_time)] → {id: 末 token 时间}。连续 decode，新请求下一步加入。"""
    items = sorted(items, key=lambda x: x[0])
    t, i, run, last = 0.0, 0, [], {}
    while i < len(items) or run:
        if not run and items[i][0] > t:
            t = items[i][0]
        while i < len(items) and items[i][0] <= t:
            run.append([items[i][1], 1]); i += 1
        t += it_time(0, len(run))
        for r in run:
            r[1] += 1
            if r[1] >= r[0]["O"]:
                last[r[0]["id"]] = t
        run = [r for r in run if r[1] < r[0]["O"]]
    return last


def colocated(reqs, gpus, budget=512):
    """每卡独立的分块 prefill 调度，请求轮询分配。"""
    res = {}
    for g in range(gpus):
        mine = reqs[g::gpus]
        t, i, run = 0.0, 0, []
        while i < len(mine) or run:
            if not run and mine[i]["arr"] > t:
                t = mine[i]["arr"]
            while i < len(mine) and mine[i]["arr"] <= t:
                run.append({"r": mine[i], "done": 0, "gen": 0}); i += 1
            dec = [x for x in run if x["done"] >= x["r"]["P"]]
            room, plan = budget - len(dec), []
            for x in run:
                if x["done"] < x["r"]["P"] and room > 0:
                    c = min(room, x["r"]["P"] - x["done"]); plan.append((x, c)); room -= c
            t += it_time(sum(c for _, c in plan), len(dec))
            for x, c in plan:
                x["done"] += c
                if x["done"] >= x["r"]["P"]:
                    x["gen"] = 1; res[x["r"]["id"]] = [t, t]
            for x in dec:
                x["gen"] += 1; res[x["r"]["id"]][1] = t
            run = [x for x in run if not (x["done"] >= x["r"]["P"] and x["gen"] >= x["r"]["O"])]
    return res


def disaggregated(reqs, n_p, n_d, kv_bw, budget=8192):
    free, first = [0.0] * n_p, {}
    queue = list(reqs)
    while queue:                                           # prefill 池：空闲 GPU 取走所有已到达请求（受 token 预算限制）
        g = min(range(n_p), key=lambda k: free[k])
        t = max(free[g], queue[0]["arr"])
        batch, tok = [], 0
        while queue and queue[0]["arr"] <= t and (not batch or tok + queue[0]["P"] <= budget):
            tok += queue[0]["P"]; batch.append(queue.pop(0))
        free[g] = t + it_time(tok, 0)
        for r in batch:
            first[r["id"]] = free[g]
    per_d = [[] for _ in range(n_d)]
    for k, r in enumerate(reqs):                            # KV 传输后进入 decode 池（轮询）
        ready = first[r["id"]] + r["P"] * 128 * 1024 / (kv_bw * 1e9) * 1000
        per_d[k % n_d].append((ready, r, first[r["id"]]))
    res = {}
    for items in per_d:
        last = decode_gpu(items)
        for _, r, f in items:
            res[r["id"]] = [f, last[r["id"]]]
    return res


def goodput(reqs, res, slo_ttft, slo_tpot):
    ok = 0
    for r in reqs:
        f, l = res[r["id"]]
        if f - r["arr"] <= slo_ttft and (l - f) / max(1, r["O"] - 1) <= slo_tpot:
            ok += 1
    span = max(v[1] for v in res.values()) - reqs[0]["arr"]
    return ok / len(reqs), ok / span * 1000


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rates", type=float, nargs="+", default=[16, 24, 32, 40])
    ap.add_argument("--n", type=int, default=400)
    ap.add_argument("--slo-ttft", type=float, default=1000)
    ap.add_argument("--slo-tpot", type=float, default=12)
    ap.add_argument("--kv-bw", type=float, default=50)
    a = ap.parse_args()
    configs = [("混合x4(分块512)", None), ("1P3D", (1, 3)), ("2P2D", (2, 2)), ("3P1D", (3, 1))]
    print(f"== 4 GPU；SLO: TTFT≤{a.slo_ttft:.0f}ms 且 TPOT≤{a.slo_tpot:.0f}ms；KV 传输 {a.kv_bw}GB/s ==")
    print(f"  {'到达率':>6s} " + " ".join(f"{c[0]:>18s}" for c in configs) + "   （SLO 达成率 / goodput req/s）")
    for rate in a.rates:
        reqs = workload(a.n, rate)
        row = []
        for name, pd in configs:
            res = colocated(reqs, 4) if pd is None else disaggregated(reqs, pd[0], pd[1], a.kv_bw)
            frac, gp = goodput(reqs, res, a.slo_ttft, a.slo_tpot)
            row.append(f"{frac:6.0%}/{gp:5.1f}")
        print(f"  {rate:6.1f} " + " ".join(f"{x:>18s}" for x in row))
    print("\n== 换成输出更长的负载（prompt 256~1024，输出 512~2048，如长回答/推理模型）==")
    for rate in [8, 16, 24]:
        reqs = workload(a.n, rate, p_rng=(256, 1024), o_rng=(512, 2048))
        row = []
        for name, pd in configs:
            res = colocated(reqs, 4) if pd is None else disaggregated(reqs, pd[0], pd[1], a.kv_bw)
            frac, gp = goodput(reqs, res, a.slo_ttft, a.slo_tpot)
            row.append(f"{frac:6.0%}/{gp:5.1f}")
        print(f"  {rate:6.1f} " + " ".join(f"{x:>18s}" for x in row))
    reqs = workload(a.n, a.rates[-1])
    print(f"\n== KV 传输带宽的影响（原负载，到达率 {a.rates[-1]}，3P1D）==")
    for bw in [50, 10, 2, 0.5]:
        frac, gp = goodput(reqs, disaggregated(reqs, 3, 1, bw), a.slo_ttft, a.slo_tpot)
        xfer = sum(r["P"] * 128 * 1024 / (bw * 1e9) * 1000 for r in reqs) / len(reqs)
        print(f"  {bw:5.1f} GB/s：平均每请求 KV 传输 {xfer:7.1f} ms  SLO 达成率 {frac:5.0%}  goodput {gp:5.1f} req/s")
    print("  （传输时间摊到上百个输出 token 上，对 TPOT 影响小；但它直接推迟第 2 个 token，影响交互体验，"
          "\n   且传输占用的网络/显存在真实系统中会与其他流量竞争——本模拟未建模这些。）")
    print("\n[小结] PD 分离让 decode 不受 prefill 干扰，TPOT 稳定；代价是 KV 传输与 P/D 配比僵化——配比不对时"
          "\n       某一池先饱和（1P3D 在 prefill 重的负载下崩溃）。最优 P:D 取决于 prompt/输出长度之比和 SLO；"
          "\n       负载低或 SLO 宽松时，混合部署 + 分块 prefill 往往足够。"
          "\n       负载随时间变化时如何动态调整 P:D（以及 KV 放哪里、怎么传）正是 Mooncake/Dynamo/llm-d 等在解决的问题。"
          "\n[问题库] P06 PD 分离的资源配比与 KV 传输；P05 prefill/decode 干扰")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m11_serving/outputs/lab_04_pd_disaggregation.txt`）：

```text
# 实测输出：m11_serving/lab_04_pd_disaggregation.py
# 运行时间：2026-10-18 21:30，耗时 0.9s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 4 GPU；SLO: TTFT≤1000ms 且 TPOT≤12ms；KV 传输 50GB/s ==
     到达率        混合x4(分块512)               1P3D               2P2D               3P1D   （SLO 达成率 / goodput req/s）
    16.0         100%/ 14.5          73%/ 10.0         100%/ 14.6         100%/ 14.5
    24.0          99%/ 20.8          10%/  1.4         100%/ 20.9         100%/ 20.9
    32.0          78%/ 21.0           6%/  1.0         100%/ 25.6         100%/ 26.6
    40.0          33%/ 10.4           5%/  0.8          44%/ 11.9         100%/ 31.6

== 换成输出更长的负载（prompt 256~1024，输出 512~2048，如长回答/推理模型）==
     8.0         100%/  7.1         100%/  7.0         100%/  7.0         100%/  6.8
    16.0         100%/ 11.7         100%/ 11.6         100%/ 11.2          38%/  3.7
    24.0         100%/ 14.6         100%/ 14.3         100%/ 13.3          14%/  1.4

== KV 传输带宽的影响（原负载，到达率 40，3P1D）==
   50.0 GB/s：平均每请求 KV 传输     5.5 ms  SLO 达成率  100%  goodput  31.6 req/s
   10.0 GB/s：平均每请求 KV 传输    27.3 ms  SLO 达成率  100%  goodput  31.5 req/s
    2.0 GB/s：平均每请求 KV 传输   136.4 ms  SLO 达成率  100%  goodput  31.2 req/s
    0.5 GB/s：平均每请求 KV 传输   545.6 ms  SLO 达成率   79%  goodput  23.7 req/s
  （传输时间摊到上百个输出 token 上，对 TPOT 影响小；但它直接推迟第 2 个 token，影响交互体验，
   且传输占用的网络/显存在真实系统中会与其他流量竞争——本模拟未建模这些。）

[小结] PD 分离让 decode 不受 prefill 干扰，TPOT 稳定；代价是 KV 传输与 P/D 配比僵化——配比不对时
       某一池先饱和（1P3D 在 prefill 重的负载下崩溃）。最优 P:D 取决于 prompt/输出长度之比和 SLO；
       负载低或 SLO 宽松时，混合部署 + 分块 prefill 往往足够。
       负载随时间变化时如何动态调整 P:D（以及 KV 放哪里、怎么传）正是 Mooncake/Dynamo/llm-d 等在解决的问题。
[问题库] P06 PD 分离的资源配比与 KV 传输；P05 prefill/decode 干扰
```

### `labs/m11_serving/lab_05_vllm_benchmark_gpu.py`

```python
"""[M11-L05]【选做·需 GPU】在真实推理引擎 vLLM 上测 TTFT / TPOT / 吞吐，并与 M11 模拟器对照

目标：用 vLLM 的离线 API 跑一个小模型，测量不同并发下的吞吐与延迟，检验 lab_02 模拟器的结论
      （连续批处理吞吐随并发上升、长 prompt 插入影响 decode 延迟）。
建议模型（本教学包不下载，运行时由 vLLM 从 Hugging Face 获取，需要你自行决定是否下载）：
  Qwen/Qwen2.5-0.5B-Instruct（约 1GB，单张 8GB 以上显存即可）
先预测：并发从 1 增到 64，输出吞吐提高几倍？每个请求的平均延迟变化多少？
可调参数：--model、--concurrency（列表）、--prompt-len、--max-tokens
CPU 替代：labs/m11_serving/lab_02_continuous_batching_sim.py（同样的现象，用模拟器观察）。
         没有 GPU 或未安装 vllm 时本脚本只打印说明并以 0 退出（run_all 记为 SKIP）。
依赖：env/requirements-gpu.txt 中的 vllm（需与 CUDA 版本匹配，见 env/README 的安装说明）
暴露的问题：真实系统与模拟器的差距在哪里 → PROBLEM_BANK P05、P29
对应论文：vLLM（2309.06180）；Sarathi-Serve
真实框架对照：vllm-project/vllm benchmarks/（官方 benchmark 脚本）
"""
import argparse
import sys
import time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen2.5-0.5B-Instruct")
    ap.add_argument("--concurrency", type=int, nargs="+", default=[1, 8, 32, 64])
    ap.add_argument("--prompt-len", type=int, default=512)
    ap.add_argument("--max-tokens", type=int, default=128)
    a = ap.parse_args()
    try:
        import torch
        from vllm import LLM, SamplingParams
        ok = torch.cuda.is_available()
    except ImportError:
        ok = False
    if not ok:
        print("[SKIP] 需要 NVIDIA GPU + vllm。CPU 替代实验：m11 lab_02（调度模拟器）。"
              f"\n       建议模型：{a.model}（运行时才会下载，本教学包不包含任何权重）。")
        sys.exit(0)
    llm = LLM(model=a.model, gpu_memory_utilization=0.85)
    sp = SamplingParams(max_tokens=a.max_tokens, ignore_eos=True, temperature=0.0)
    prompt = "hello " * a.prompt_len
    for c in a.concurrency:
        t0 = time.perf_counter()
        outs = llm.generate([prompt] * c, sp, use_tqdm=False)
        dt = time.perf_counter() - t0
        n_out = sum(len(o.outputs[0].token_ids) for o in outs)
        m = outs[0].metrics                                 # 不同 vLLM 版本字段可能不同，缺失时跳过
        ttft = (m.first_token_time - m.arrival_time) if m and getattr(m, "first_token_time", None) else float("nan")
        print(f"  并发 {c:3d}: 总耗时 {dt:6.2f}s，输出吞吐 {n_out / dt:8.0f} tok/s，首请求 TTFT {ttft * 1e3:7.1f} ms")
    print("[小结] 对照 lab_02：吞吐随并发上升直到显存/算力饱和；把这里的数字代回模拟器的迭代耗时模型做校准。")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m11_serving/outputs/lab_05_vllm_benchmark_gpu.txt`）：

```text
# 实测输出：m11_serving/lab_05_vllm_benchmark_gpu.py
# 运行时间：2026-10-18 21:30，耗时 1.0s，峰值内存 220MB，状态 SKIP
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

[SKIP] 需要 NVIDIA GPU + vllm。CPU 替代实验：m11 lab_02（调度模拟器）。
       建议模型：Qwen/Qwen2.5-0.5B-Instruct（运行时才会下载，本教学包不包含任何权重）。
```

## M12 推理加速：投机解码、量化（LLM.int8、GPTQ、AWQ、SmoothQuant）、KV Cache 压缩（`labs/m12_inference_accel/`）

### `labs/m12_inference_accel/lab_01_speculative_decoding.py`

```python
"""[M12-L01] 投机解码（speculative decoding）：拒绝采样保证无偏 + 加速比模型 + 大 batch 下的收益衰减

目标：实现 Leviathan et al. / Chen et al. 的投机采样（draft 提议 γ 个 token，target 并行验证，
      按 min(1, p/q) 接受，被拒时从 norm(max(0, p-q)) 重采样）；用大量采样验证输出分布与 target 一致；
      用实测接受率 α 计算期望每次验证产出的 token 数 (1-α^(γ+1))/(1-α)，并分析 batch 增大后收益为何下降。
先预测：
  1. 接受率 α=0.8、γ=4、draft 成本是 target 的 5%，理论加速比是多少？
  2. batch 从 1 增大到 128，投机解码的加速比会怎样？为什么？
可调参数：--vocab、--noise（draft 与 target 的差异）、--gamma（列表）、--samples
暴露的问题：投机解码在高并发下收益下降；draft 选择与 γ 自适应 → PROBLEM_BANK P08
对应论文：Fast Inference from Transformers via Speculative Decoding（2211.17192）；
          Accelerating LLM Decoding with Speculative Sampling（2302.01318）；Medusa；EAGLE-1/2/3
真实框架对照：vllm-project/vllm vllm/v1/sample/rejection_sampler.py；vllm/v1/spec_decode/
"""
import argparse

import numpy as np


class ToyLM:
    """一阶马尔可夫"语言模型"：p(next | prev) = softmax(T[prev] / temp)。"""

    def __init__(self, T, temp=1.0):
        self.T, self.temp = T, temp

    def probs(self, prev):
        z = self.T[prev] / self.temp
        e = np.exp(z - z.max())
        return e / e.sum()


def speculative_step(target, draft, prev, gamma, rng):
    """一次"draft 提议 γ 个 + target 验证"，返回产出的 token 列表（至少 1 个）。"""
    toks, qs, ctx = [], [], prev
    for _ in range(gamma):                                  # draft 自回归提议
        q = draft.probs(ctx); t = rng.choice(len(q), p=q)
        toks.append(t); qs.append(q); ctx = t
    out, ctx = [], prev
    for t, q in zip(toks, qs):                              # target 并行算出每个位置的 p（这里逐个算，等价）
        p = target.probs(ctx)
        if rng.random() < min(1.0, p[t] / q[t]):
            out.append(t); ctx = t
        else:
            resid = np.maximum(p - q, 0); resid /= resid.sum()
            out.append(rng.choice(len(p), p=resid))         # 被拒：从残差分布重采样，保证无偏
            return out
    out.append(rng.choice(len(p := target.probs(ctx)), p=p))  # 全部接受：额外白送一个 target token
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vocab", type=int, default=50)
    ap.add_argument("--noise", type=float, nargs="+", default=[0.5, 1.0, 2.0])
    ap.add_argument("--gamma", type=int, nargs="+", default=[1, 2, 4, 8])
    ap.add_argument("--samples", type=int, default=20000)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    T = rng.normal(0, 2, size=(a.vocab, a.vocab))
    target = ToyLM(T)

    print("== 1. 无偏性验证：第一个产出 token 的分布 vs target 分布 ==")
    draft = ToyLM(T + rng.normal(0, 1.0, size=T.shape))
    counts = np.zeros(a.vocab)
    for _ in range(a.samples):
        counts[speculative_step(target, draft, 0, 4, rng)[0]] += 1
    p = target.probs(0)
    tv = 0.5 * np.abs(counts / a.samples - p).sum()
    q = draft.probs(0)
    print(f"  总变差距离 TV(经验, target) = {tv:.4f}（采样噪声量级 ≈ {np.sqrt(a.vocab / a.samples) / 2:.4f}）；"
          f"若直接用 draft 采样 TV = {0.5 * np.abs(q - p).sum():.4f}")

    print("\n== 2. 接受率与每次验证产出的 token 数 ==")
    print(f"  {'draft噪声':>8s} {'α(实测)':>8s} " + " ".join(f"{'γ=' + str(g):>14s}" for g in a.gamma))
    for nz in a.noise:
        draft = ToyLM(T + rng.normal(0, nz, size=T.shape))
        alpha = np.mean([np.minimum(target.probs(s), draft.probs(s)).sum() for s in range(a.vocab)])
        cells = []
        for g in a.gamma:
            prev, made, calls = 0, 0, 0
            while made < 3000:
                out = speculative_step(target, draft, prev, g, rng)
                made += len(out); calls += 1; prev = out[-1]
            theo = (1 - alpha ** (g + 1)) / (1 - alpha)
            cells.append(f"{made / calls:5.2f}(理论{theo:4.2f})")
        print(f"  {nz:8.1f} {alpha:8.3f} " + " ".join(f"{c:>14s}" for c in cells))

    print("\n== 3. 加速比：draft 成本比 c，以及 batch 增大后验证不再'免费' ==")
    alpha, c = 0.8, 0.05
    N, W, BW, PEAK = 8e9, 16e9, 3.35e12, 989e12              # 8B target，BF16 权重 16GB，H100
    for b in [1, 16, 64, 128, 256]:
        base = max(W / BW, 2 * N * b / PEAK)                  # 普通 decode 一步
        best = (1.0, 0)
        for g in range(1, 9):
            verify = max(W / BW, 2 * N * b * (g + 1) / PEAK)  # 一次验证 γ+1 个位置
            t = g * c * base + verify
            tokens = (1 - alpha ** (g + 1)) / (1 - alpha)
            best = max(best, (tokens * base / t, g))
        print(f"  batch={b:4d}: 最佳 γ={best[1]}，加速比 {best[0]:4.2f}×"
              f"{'（验证已算力受限）' if 2 * N * b * 2 / PEAK > W / BW else ''}")
    print("\n[小结] 拒绝采样让投机解码在数学上与 target 采样同分布；收益取决于接受率 α、γ 和 draft 成本。"
          "\n       小 batch 时 decode 访存受限，验证 γ+1 个 token 几乎和验证 1 个一样贵——这是'免费午餐'的来源；"
          "\n       batch 变大后验证变成算力受限，额外的 γ 个位置不再免费，加速比趋于 1 甚至变慢。"
          "\n[问题库] P08 投机解码在大 batch 下收益下降")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m12_inference_accel/outputs/lab_01_speculative_decoding.txt`）：

```text
# 实测输出：m12_inference_accel/lab_01_speculative_decoding.py
# 运行时间：2026-10-18 21:30，耗时 1.8s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 1. 无偏性验证：第一个产出 token 的分布 vs target 分布 ==
  总变差距离 TV(经验, target) = 0.0167（采样噪声量级 ≈ 0.0250）；若直接用 draft 采样 TV = 0.3988

== 2. 接受率与每次验证产出的 token 数 ==
   draft噪声    α(实测)            γ=1            γ=2            γ=4            γ=8
       0.5    0.821   1.81(理论1.82)   2.47(理论2.49)   3.53(理论3.50)   4.46(理论4.63)
       1.0    0.653   1.66(理论1.65)   2.07(理论2.08)   2.47(理论2.54)   2.95(理论2.82)
       2.0    0.402   1.40(理论1.40)   1.57(理论1.56)   1.68(理论1.65)   1.63(理论1.67)

== 3. 加速比：draft 成本比 c，以及 batch 增大后验证不再'免费' ==
  batch=   1: 最佳 γ=8，加速比 3.09×
  batch=  16: 最佳 γ=8，加速比 3.09×
  batch=  64: 最佳 γ=4，加速比 2.62×
  batch= 128: 最佳 γ=2，加速比 1.74×
  batch= 256: 最佳 γ=1，加速比 1.01×（验证已算力受限）

[小结] 拒绝采样让投机解码在数学上与 target 采样同分布；收益取决于接受率 α、γ 和 draft 成本。
       小 batch 时 decode 访存受限，验证 γ+1 个 token 几乎和验证 1 个一样贵——这是'免费午餐'的来源；
       batch 变大后验证变成算力受限，额外的 γ 个位置不再免费，加速比趋于 1 甚至变慢。
[问题库] P08 投机解码在大 batch 下收益下降
```

### `labs/m12_inference_accel/lab_02_quantization.py`

```python
"""[M12-L02] LLM 量化：激活离群值、LLM.int8() 分解、SmoothQuant 平滑、分组 INT4 与 AWQ 式缩放

目标：在带"离群通道"的合成激活上，比较多种量化方案对矩阵乘输出的相对误差与权重显存；
      理解为什么 LLM 的 W8A8 难、weight-only INT4 为什么流行、SmoothQuant/AWQ 各自在"搬运难度"。
先预测：
  1. 激活中 1% 的通道幅值是其他通道的 50 倍，per-tensor INT8 激活量化的误差会怎样？
  2. SmoothQuant 的迁移强度 α 从 0 调到 1，误差先降后升还是单调？
可调参数：--tokens、--din、--dout、--outlier（离群倍数）、--frac（离群通道比例）
暴露的问题：激活离群值让低比特激活量化困难 → PROBLEM_BANK P09
对应论文：LLM.int8()（2208.07339）；SmoothQuant（2211.10438）；GPTQ（2210.17323）；AWQ（2306.00978）；QServe
真实框架对照：mit-han-lab/llm-awq awq/quantize/auto_scale.py；pytorch/ao（torchao 量化 API）
说明：数据是合成的（随机权重 + 人为注入的离群通道），用来复现论文中的现象，不代表具体模型的数值。
"""
import argparse

import torch


def q_sym(x, bits, dim=None, group=None):
    """对称均匀量化后反量化。dim=None 为 per-tensor；dim=k 表示沿该维取 max（per-channel/per-token）。"""
    qmax = 2 ** (bits - 1) - 1
    if group:                                              # 沿输入维分组（weight-only INT4 常用 g=128）
        shp = x.shape
        xg = x.reshape(shp[0], -1, group)
        s = xg.abs().amax(-1, keepdim=True).clamp(min=1e-8) / qmax
        return ((xg / s).round().clamp(-qmax, qmax) * s).reshape(shp)
    s = (x.abs().max() if dim is None else x.abs().amax(dim=dim, keepdim=True)).clamp(min=1e-8) / qmax
    return (x / s).round().clamp(-qmax, qmax) * s


def rel(y, ref):
    return ((y - ref).norm() / ref.norm()).item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tokens", type=int, default=256)
    ap.add_argument("--din", type=int, default=1024)
    ap.add_argument("--dout", type=int, default=1024)
    ap.add_argument("--outlier", type=float, default=50.0)
    ap.add_argument("--frac", type=float, default=0.01)
    a = ap.parse_args()
    torch.manual_seed(0)
    X = torch.randn(a.tokens, a.din)
    out_ch = torch.randperm(a.din)[: max(1, int(a.frac * a.din))]
    X[:, out_ch] *= a.outlier                              # 离群通道：在所有 token 上都大（LLM.int8 论文的观察）
    W = torch.randn(a.din, a.dout) / a.din ** 0.5          # Y = X @ W，W 的行对应输入通道
    Y = X @ W
    print(f"== X: {a.tokens}×{a.din}（{len(out_ch)} 个离群通道 ×{a.outlier}），W: {a.din}×{a.dout} ==")
    res = {}
    res["W8A8 per-tensor"] = rel(q_sym(X, 8) @ q_sym(W, 8), Y)
    res["W8(per-out-ch) A8(per-token)"] = rel(q_sym(X, 8, dim=1) @ q_sym(W, 8, dim=0), Y)
    # LLM.int8()：离群通道（|x|>6）保留高精度，其余走 INT8
    mask = (X.abs() > 6).any(0)
    y_int8 = q_sym(X[:, ~mask], 8, dim=1) @ q_sym(W[~mask], 8, dim=0) + X[:, mask] @ W[mask]
    res[f"LLM.int8() 分解（{int(mask.sum())} 个通道走 FP16）"] = rel(y_int8, Y)
    for alpha in [0.0, 0.25, 0.5, 0.75, 1.0]:              # SmoothQuant：s_j = max|X_j|^α / max|W_j|^(1-α)
        s = X.abs().amax(0).pow(alpha) / W.abs().amax(1).pow(1 - alpha).clamp(min=1e-5)
        res[f"SmoothQuant α={alpha:.2f} + W8A8 per-tensor"] = rel(q_sym(X / s, 8) @ q_sym(W * s[:, None], 8), Y)
    res["W4 per-out-ch（weight-only，激活 FP16）"] = rel(X @ q_sym(W, 4, dim=0), Y)
    res["W4 group=128（weight-only）"] = rel(X @ q_sym(W.T, 4, group=128).T, Y)
    # AWQ 式：按激活幅值放大重要输入通道再量化权重，搜索指数 α（真实 AWQ 在校准集上逐层搜索）
    best = (9e9, 0)
    act = X.abs().mean(0)
    for alpha in [i / 10 for i in range(11)]:
        s = act.pow(alpha).clamp(min=1e-4); s = s / s.mean()
        e = rel((X / s) @ q_sym((W * s[:, None]).T, 4, group=128).T, Y)
        best = min(best, (e, alpha))
    res[f"AWQ 式缩放 + W4 group=128（最佳 α={best[1]:.1f}）"] = best[0]
    for k, v in res.items():
        print(f"  {k:44s} 相对误差 {v:8.4f}")
    nbytes = a.din * a.dout
    print(f"\n  权重显存：FP16 {2 * nbytes / 2 ** 20:.1f}MB，INT8 {nbytes / 2 ** 20:.1f}MB，"
          f"INT4(g128，含 FP16 scale) {(nbytes / 2 + nbytes / 128 * 2) / 2 ** 20:.2f}MB")
    print("\n[小结] 离群通道让 per-tensor 激活量化崩溃；LLM.int8() 用混合精度分解绕开，但 kernel 不规整、速度受损；"
          "\n       SmoothQuant 把量化难度从激活'搬'到权重，α 适中时最好；decode 访存受限，所以只压权重的 W4 方案"
          "\n       直接减少读取字节、最受欢迎，AWQ 通过保护重要通道进一步降误差。"
          "\n[问题库] P09 激活离群值与低比特量化")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m12_inference_accel/outputs/lab_02_quantization.txt`）：

```text
# 实测输出：m12_inference_accel/lab_02_quantization.py
# 运行时间：2026-10-18 21:30，耗时 1.1s，峰值内存 260MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== X: 256×1024（10 个离群通道 ×50.0），W: 1024×1024 ==
  W8A8 per-tensor                              相对误差   0.1047
  W8(per-out-ch) A8(per-token)                 相对误差   0.0436
  LLM.int8() 分解（10 个通道走 FP16）                  相对误差   0.0022
  SmoothQuant α=0.00 + W8A8 per-tensor         相对误差   0.0920
  SmoothQuant α=0.25 + W8A8 per-tensor         相对误差   0.0341
  SmoothQuant α=0.50 + W8A8 per-tensor         相对误差   0.0206
  SmoothQuant α=0.75 + W8A8 per-tensor         相对误差   0.0384
  SmoothQuant α=1.00 + W8A8 per-tensor         相对误差   0.1043
  W4 per-out-ch（weight-only，激活 FP16）           相对误差   0.1417
  W4 group=128（weight-only）                    相对误差   0.1169
  AWQ 式缩放 + W4 group=128（最佳 α=0.3）             相对误差   0.0553

  权重显存：FP16 2.0MB，INT8 1.0MB，INT4(g128，含 FP16 scale) 0.52MB

[小结] 离群通道让 per-tensor 激活量化崩溃；LLM.int8() 用混合精度分解绕开，但 kernel 不规整、速度受损；
       SmoothQuant 把量化难度从激活'搬'到权重，α 适中时最好；decode 访存受限，所以只压权重的 W4 方案
       直接减少读取字节、最受欢迎，AWQ 通过保护重要通道进一步降误差。
[问题库] P09 激活离群值与低比特量化
```

### `labs/m12_inference_accel/lab_03_kv_compression.py`

```python
"""[M12-L03] KV Cache 压缩：驱逐（StreamingLLM / H2O）与量化（KIVI 式）的精度-内存取舍

目标：在带"注意力汇聚点（attention sink）"、"局部性"和"少数重要 token"的合成注意力上，比较：
      仅保留最近窗口、StreamingLLM（sink + 窗口）、H2O（累计注意力最高的 heavy hitter + 窗口）、
      以及 2bit KV 量化（Key 按通道、Value 按 token，KIVI 的做法）对注意力输出的误差。
先预测：
  1. 只保留 25% 的 KV，仅用最近窗口和加上 4 个 sink token，误差差多少？
  2. Key 按 token 量化和按通道量化，哪个误差小？为什么？
可调参数：--n（上下文长度）、--d、--budget（保留比例列表）、--steps（decode 步数）
暴露的问题：KV 压缩的精度损失难以预测、与 PagedAttention/前缀缓存的集成困难 → PROBLEM_BANK P10
对应论文：StreamingLLM（2309.17453）；H2O（2306.14048）；SnapKV；KIVI（2402.02750）；Quest
说明：注意力模式是人为构造的（sink、局部、重要 token 都是注入的），用来演示各方法的假设何时成立。
      真实模型上的结论需在真实注意力上验证——这正是一个可做的研究练习。
"""
import argparse
import math

import torch


def make_data(n, d, steps, seed=0):
    """构造有结构的注意力（分数 = q·k/√d）：
    - sink：前 4 个 token 在 sink 方向上很大，query 也有该分量 → 约占 30% 注意力；
    - 重要 token：随机 2% 的 token 在另一方向上较大 → 约占 25%；
    - 局部性：位置编码为缓慢旋转的二维向量，距离越近分数加成越大（约 256 token 后衰减到 0）；
    - Key 通道离群：4 个固定通道在所有 token 上都有大偏移（KIVI 观察到的现象）。"""
    g = torch.Generator().manual_seed(seed)
    L = n + steps
    K = torch.randn(L, d, generator=g); V = torch.randn(L, d, generator=g)
    Q = torch.randn(steps, d, generator=g)
    e = torch.eye(d)
    sink, imp, r1, r2 = e[8], e[9], e[10], e[11]           # 互相正交的方向
    K[:4] += 8 * sink; Q += 7.6 * sink
    idx = torch.randperm(n, generator=g)[: n // 50] + 4
    K[idx] += 6 * imp; Q += 6.3 * imp
    w = math.pi / (2 * 256)
    pos = torch.arange(L, dtype=torch.float32)
    K += 5 * (torch.cos(pos * w)[:, None] * r1 + torch.sin(pos * w)[:, None] * r2)
    tq = torch.arange(n, L, dtype=torch.float32) + 1
    Q += 5.2 * (torch.cos(tq * w)[:, None] * r1 + torch.sin(tq * w)[:, None] * r2)
    K[:, :4] += 10.0                                        # 通道离群：对所有 key 加同一偏移，softmax 结果不变，但会拉大量化范围
    return Q, K, V


def attend(q, K, V):
    w = torch.softmax(K @ q / math.sqrt(q.shape[0]), dim=0)
    return w @ V, w


def quant(x, bits, dim, group=32):
    """分组非对称（min-max）量化。dim=0：按通道，每 group 个 token 一组（KIVI 对 Key 的做法）；
    dim=1：按 token，每 group 个通道一组（KIVI 对 Value 的做法）。"""
    L, d = x.shape
    if dim == 0:
        xg = x.reshape(L // group, group, d); ax = 1
    else:
        xg = x.reshape(L, d // group, group); ax = 2
    lo, hi = xg.amin(dim=ax, keepdim=True), xg.amax(dim=ax, keepdim=True)
    s = (hi - lo).clamp(min=1e-8) / (2 ** bits - 1)
    return (((xg - lo) / s).round() * s + lo).reshape(L, d)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=2048)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--budget", type=float, nargs="+", default=[0.5, 0.25, 0.1])
    ap.add_argument("--steps", type=int, default=64)
    a = ap.parse_args()
    Q, K, V = make_data(a.n, a.d, a.steps)
    print(f"== 上下文 {a.n}，decode {a.steps} 步，注意力输出相对误差（越小越好）==")
    print(f"  {'方法':26s} " + " ".join(f"{'保留' + str(int(b * 100)) + '%':>9s}" for b in a.budget))
    methods = ["最近窗口", "StreamingLLM(4 sink+窗口)", "H2O(heavy hitter+窗口)"]
    for mname in methods:
        row = []
        for b in a.budget:
            errs, acc = [], torch.zeros(a.n + a.steps)
            for t in range(a.steps):
                L = a.n + t + 1
                q, Kt, Vt = Q[t], K[:L], V[:L]
                ref, w = attend(q, Kt, Vt)
                keep_n = int(b * L)
                if mname == "最近窗口":
                    keep = torch.arange(L - keep_n, L)
                elif mname.startswith("Streaming"):
                    keep = torch.cat([torch.arange(4), torch.arange(L - keep_n + 4, L)])
                else:                                       # H2O：一半预算给累计注意力最高者，一半给最近窗口
                    recent = torch.arange(L - keep_n // 2, L)
                    score = acc[:L].clone(); score[recent] = -1
                    keep = torch.cat([score.topk(keep_n - len(recent)).indices, recent])
                out, _ = attend(q, Kt[keep], Vt[keep])
                errs.append(((out - ref).norm() / ref.norm()).item())
                acc[:L] += w                                # H2O 用"看到当前为止"的累计注意力
            row.append(sum(errs) / len(errs))
        print(f"  {mname:26s} " + " ".join(f"{e:9.4f}" for e in row))

    print("\n== 2bit / 4bit KV 量化（保留全部 token）==")
    L = a.n + a.steps
    for bits in [4, 2]:
        for name, kd, vd, resid in [("K 按 token、V 按 token", 1, 1, 0), ("K 按通道、V 按 token (KIVI)", 0, 1, 0),
                                    ("KIVI + 最近128个全精度", 0, 1, 128)]:   # 分组大小 32
            Kq, Vq = quant(K[:L], bits, kd), quant(V[:L], bits, vd)
            if resid:
                Kq[-resid:], Vq[-resid:] = K[L - resid:L], V[L - resid:L]
            errs = []
            for t in range(a.steps):
                ref, _ = attend(Q[t], K[:L], V[:L]); out, _ = attend(Q[t], Kq, Vq)
                errs.append(((out - ref).norm() / ref.norm()).item())
            print(f"  {bits}bit {name:26s} 误差 {sum(errs) / len(errs):.4f}  KV 体积约为 FP16 的 {bits / 16:.0%}")
    print("\n[小结] 方法的好坏取决于它的假设是否符合注意力模式：sink 存在时 StreamingLLM 远好于纯窗口；重要 token"
          "\n       分散在远处时，按累计注意力保留的 H2O 更好。量化方面：4bit 时 Key 按通道分组（KIVI）更好；2bit 时在这份"
          "\n       合成数据上反而更差——query 在少数结构化方向上的分量很大，会放大这些方向上 Key 的量化误差。"
          "\n       结论依赖真实的 K/Q 分布，需要在真实模型的注意力上重测（见 exercises.md 的 L4 题）。"
          "\n       系统层面的难点：驱逐与分页块、前缀共享冲突；量化需要专门的 attention kernel。"
          "\n[问题库] P10 KV Cache 压缩的精度-内存取舍与系统集成")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m12_inference_accel/outputs/lab_03_kv_compression.txt`）：

```text
# 实测输出：m12_inference_accel/lab_03_kv_compression.py
# 运行时间：2026-10-18 21:30，耗时 1.1s，峰值内存 242MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 上下文 2048，decode 64 步，注意力输出相对误差（越小越好）==
  方法                             保留50%     保留25%     保留10%
  最近窗口                          1.1205    1.2433    1.2728
  StreamingLLM(4 sink+窗口)       0.1986    0.3057    0.3185
  H2O(heavy hitter+窗口)          0.0343    0.0690    0.1326

== 2bit / 4bit KV 量化（保留全部 token）==
  4bit K 按 token、V 按 token        误差 0.1166  KV 体积约为 FP16 的 25%
  4bit K 按通道、V 按 token (KIVI)     误差 0.0978  KV 体积约为 FP16 的 25%
  4bit KIVI + 最近128个全精度           误差 0.0966  KV 体积约为 FP16 的 25%
  2bit K 按 token、V 按 token        误差 0.5684  KV 体积约为 FP16 的 12%
  2bit K 按通道、V 按 token (KIVI)     误差 0.6262  KV 体积约为 FP16 的 12%
  2bit KIVI + 最近128个全精度           误差 0.6295  KV 体积约为 FP16 的 12%

[小结] 方法的好坏取决于它的假设是否符合注意力模式：sink 存在时 StreamingLLM 远好于纯窗口；重要 token
       分散在远处时，按累计注意力保留的 H2O 更好。量化方面：4bit 时 Key 按通道分组（KIVI）更好；2bit 时在这份
       合成数据上反而更差——query 在少数结构化方向上的分量很大，会放大这些方向上 Key 的量化误差。
       结论依赖真实的 K/Q 分布，需要在真实模型的注意力上重测（见 exercises.md 的 L4 题）。
       系统层面的难点：驱逐与分页块、前缀共享冲突；量化需要专门的 attention kernel。
[问题库] P10 KV Cache 压缩的精度-内存取舍与系统集成
```

## M13 编译器：计算图与 IR、算子融合与自动调优、TVM、XLA、torch.compile（`labs/m13_compiler/`）

### `labs/m13_compiler/lab_01_graph_ir_passes.py`

```python
"""[M13-L01] 迷你深度学习编译器：计算图 IR + 常量折叠 / 公共子表达式消除 / 死代码消除 / 逐元素融合

目标：用不到 200 行实现一个能执行的图 IR 和 4 个经典优化 pass，统计优化前后的"kernel 数"与
      中间结果的显存读写量，并用 numpy 解释器验证结果不变。
先预测：
  1. 下面的计算图优化前有几个 kernel？融合后剩几个？
  2. 为什么 matmul 一般不与后面的逐元素算子"随便融合"，而是作为融合组的"锚点"（epilogue fusion）？
可调参数：--n（张量规模）
暴露的问题：融合规则与代价模型的设计、动态形状下的融合 → PROBLEM_BANK P12
对应论文：TVM（1802.04799，算子融合分类）；PyTorch 2（TorchInductor）；MLIR；Ansor
真实框架对照：torch/_inductor/scheduler.py（融合）、torch/fx/passes/；apache/tvm src/relay/transforms/fuse_ops.cc
"""
import argparse

import numpy as np

ELEMENTWISE = {"add", "mul", "gelu", "relu", "scale"}


class Node:
    def __init__(self, op, inputs=(), value=None, name=""):
        self.op, self.inputs, self.value, self.name = op, list(inputs), value, name

    def __repr__(self):
        return f"{self.name}={self.op}({','.join(i.name for i in self.inputs)})"


class Graph:
    def __init__(self):
        self.nodes, self.cnt = [], 0

    def add(self, op, *inputs, value=None):
        self.cnt += 1
        n = Node(op, inputs, value, f"v{self.cnt}")
        self.nodes.append(n)
        return n


def run(graph, outputs, env):
    vals = {}
    impl = {"add": np.add, "mul": np.multiply, "matmul": np.matmul, "relu": lambda x: np.maximum(x, 0),
            "gelu": lambda x: 0.5 * x * (1 + np.tanh(0.79788456 * (x + 0.044715 * x ** 3))),
            "scale": lambda x, c: x * c}
    for n in graph.nodes:
        if n.op == "input":
            vals[n] = env[n.value]
        elif n.op == "const":
            vals[n] = n.value
        elif n.op == "fused":                              # 融合 kernel：在一个循环里依次执行子图
            local = {}
            for sub in n.value:
                args = [local.get(i, vals.get(i)) for i in sub.inputs]
                local[sub] = impl[sub.op](*args)
            vals[n] = local[n.value[-1]]
        else:
            vals[n] = impl[n.op](*[vals[i] for i in n.inputs])
    return [vals[o] for o in outputs]


def users(graph):
    u = {n: [] for n in graph.nodes}
    for n in graph.nodes:
        for i in n.inputs:
            if n not in u[i]:                              # 同一个使用者引用两次（如 add(v, v)）只算一次
                u[i].append(n)
    return u


def constant_fold(g):
    for n in g.nodes:
        if n.op not in ("input", "const", "fused") and n.inputs and all(i.op == "const" for i in n.inputs):
            n.value = run(_single(n), [n], {})[0]          # 在编译期直接算出结果
            n.op, n.inputs = "const", []


def _single(n):
    g = Graph(); g.nodes = list(n.inputs) + [n]
    return g


def cse(g):
    seen, remap = {}, {}
    for n in g.nodes:
        n.inputs = [remap.get(i, i) for i in n.inputs]
        key = (n.op, tuple(id(i) for i in n.inputs), id(n.value) if n.op in ("input", "const") else None)
        if n.op not in ("input", "const") and key in seen:
            remap[n] = seen[key]
        else:
            seen[key] = n
    g.nodes = [n for n in g.nodes if n not in remap]


def dce(g, outputs):
    live, stack = set(), list(outputs)
    while stack:
        n = stack.pop()
        if n not in live:
            live.add(n); stack.extend(n.inputs)
    g.nodes = [n for n in g.nodes if n in live]


def fuse_elementwise(g, outputs):
    """把"只有一个使用者"的逐元素算子链合并成一个 fused 节点（中间结果不再写回显存）。"""
    u = users(g)
    groups, assigned = [], set()
    for n in g.nodes:
        if n.op in ELEMENTWISE and n not in assigned:
            chain = [n]
            while len(u[chain[-1]]) == 1 and u[chain[-1]][0].op in ELEMENTWISE and chain[-1] not in outputs:
                chain.append(u[chain[-1]][0])
            if len(chain) > 1:
                groups.append(chain); assigned.update(chain)
    for chain in groups:
        f = Node("fused", [i for c in chain for i in c.inputs if i not in chain], chain, chain[-1].name + "_f")
        idx = g.nodes.index(chain[-1])
        g.nodes[idx] = f
        g.nodes = [n for n in g.nodes if n not in chain[:-1]]
        for n in g.nodes:                                  # 让下游使用 fused 节点
            n.inputs = [f if i is chain[-1] else i for i in n.inputs]
        outputs[:] = [f if o is chain[-1] else o for o in outputs]


def stats(g, nbytes):
    kernels = [n for n in g.nodes if n.op not in ("input", "const")]
    traffic = sum(nbytes * (len(n.inputs) + 1) for n in kernels)   # 每个 kernel 读输入、写输出
    return len(kernels), traffic


def build():
    g = Graph()
    x, W, b = g.add("input", value="x"), g.add("input", value="W"), g.add("input", value="b")
    c = g.add("mul", g.add("const", value=np.float32(3.0)), g.add("const", value=np.float32(0.5)))  # 可折叠
    h = g.add("add", g.add("matmul", x, W), b)
    a1 = g.add("gelu", h); a2 = g.add("gelu", h)                    # 公共子表达式
    y = g.add("scale", g.add("add", a1, a2), c)
    y = g.add("relu", y)
    g.add("mul", x, x)                                              # 死代码：结果没人用
    return g, [y]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=512)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    env = {"x": rng.standard_normal((a.n, a.n)).astype(np.float32),
           "W": rng.standard_normal((a.n, a.n)).astype(np.float32) / a.n ** 0.5,
           "b": rng.standard_normal(a.n).astype(np.float32)}
    nbytes = a.n * a.n * 4
    g, outs = build()
    ref = run(g, outs, env)[0]
    print("== 原始图 ==")
    print("  " + "; ".join(map(repr, [n for n in g.nodes if n.op not in ("input",)])))
    k, t = stats(g, nbytes)
    print(f"  kernel 数={k}，估算读写={t / 2 ** 20:.0f}MB")
    for name, fn in [("常量折叠", lambda: constant_fold(g)), ("CSE", lambda: cse(g)),
                     ("DCE", lambda: dce(g, outs)), ("逐元素融合", lambda: fuse_elementwise(g, outs))]:
        fn()
        k, t = stats(g, nbytes)
        err = np.abs(run(g, outs, env)[0] - ref).max()
        print(f"  {name:8s} 后：kernel 数={k}，估算读写={t / 2 ** 20:4.0f}MB，结果最大差={err:.1e}")
    print("== 优化后的图 ==")
    print("  " + "; ".join(map(repr, [n for n in g.nodes if n.op not in ("input", "const")])))
    print("\n[小结] 这些 pass 在每个编译器里都有对应物。真实编译器的难点在于：融合要有代价模型（寄存器压力、并行度），"
          "\n       matmul 等算子通常只做 epilogue 融合；动态形状和 Python 控制流会让图捕获本身变难（lab_02）。"
          "\n[问题库] P12 融合机会与编译器自动化的边界")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m13_compiler/outputs/lab_01_graph_ir_passes.txt`）：

```text
# 实测输出：m13_compiler/lab_01_graph_ir_passes.py
# 运行时间：2026-10-18 21:30，耗时 0.2s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 原始图 ==
  v4=const(); v5=const(); v6=mul(v4,v5); v7=matmul(v1,v2); v8=add(v7,v3); v9=gelu(v8); v10=gelu(v8); v11=add(v9,v10); v12=scale(v11,v6); v13=relu(v12); v14=mul(v1,v1)
  kernel 数=9，估算读写=24MB
  常量折叠     后：kernel 数=8，估算读写=  21MB，结果最大差=0.0e+00
  CSE      后：kernel 数=7，估算读写=  19MB，结果最大差=0.0e+00
  DCE      后：kernel 数=6，估算读写=  16MB，结果最大差=0.0e+00
  逐元素融合    后：kernel 数=2，估算读写=   7MB，结果最大差=0.0e+00
== 优化后的图 ==
  v7=matmul(v1,v2); v13_f=fused(v7,v3,v6)

[小结] 这些 pass 在每个编译器里都有对应物。真实编译器的难点在于：融合要有代价模型（寄存器压力、并行度），
       matmul 等算子通常只做 epilogue 融合；动态形状和 Python 控制流会让图捕获本身变难（lab_02）。
[问题库] P12 融合机会与编译器自动化的边界
```

### `labs/m13_compiler/lab_02_torch_compile_capture.py`

```python
"""[M13-L02] torch.fx 与 torch.compile 的前端：图捕获、自定义 pass、图断裂（graph break）与重编译

目标：用 torch.fx 把模型变成可改写的图并写一个替换 pass；用 TorchDynamo（torch.compile 的前端）观察
      Python 控制流、print、数据相关分支造成的图断裂，以及输入形状变化引起的重编译。
      本机没有 C/C++ 编译器，TorchInductor 无法在 CPU 上生成代码；我们用自定义 backend 只做"捕获与计数"，
      并如实报告 inductor 的结果。
先预测：
  1. `if x.sum() > 0:` 这样的分支会让 Dynamo 怎么做？
  2. 同一个函数先后用形状 (8,16)、(9,16)、(10,16) 调用，会编译几次？
可调参数：无（结构固定，便于读代码）
暴露的问题：图断裂与动态形状削弱编译器收益 → PROBLEM_BANK P12
对应论文：PyTorch 2（ASPLOS'24，TorchDynamo/TorchInductor）
真实框架对照：torch/fx/（symbolic_trace、GraphModule）；torch/_dynamo/（eval_frame.py、symbolic_convert.py）
"""
import operator

import torch
import torch.fx as fx
import torch.nn as nn


class Block(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(16, 16)

    def forward(self, x):
        return torch.relu(self.fc(x) + x)


def fx_demo():
    print("== 1. torch.fx：符号追踪得到的图 ==")
    orig = Block()
    gm = fx.symbolic_trace(orig)                           # gm 与 orig 共享参数
    for n in gm.graph.nodes:
        print(f"  {n.op:14s} {str(n.target):30s} args={n.args}")

    # 自定义 pass：把 relu(add(a, b)) 替换为一个"融合算子"（这里用 Python 函数模拟一个融合 kernel）
    def fused_add_relu(a, b):
        return torch.clamp_min(a + b, 0)
    count = 0
    for n in list(gm.graph.nodes):
        if n.op == "call_function" and n.target is torch.relu and n.args[0].op == "call_function" \
                and n.args[0].target is operator.add:
            add = n.args[0]
            with gm.graph.inserting_after(n):
                new = gm.graph.call_function(fused_add_relu, add.args)
            n.replace_all_uses_with(new)
            gm.graph.erase_node(n); gm.graph.erase_node(add); count += 1
    gm.recompile()
    x = torch.randn(4, 16)
    print(f"  替换了 {count} 处 relu(add)；新图结果与原模块一致：{torch.allclose(gm(x), orig(x))}")
    print("  改写后的代码：\n    " + gm.code.strip().replace("\n", "\n    "))


def dynamo_demo():
    print("\n== 2. TorchDynamo：图断裂 ==")
    graphs = []

    def counting_backend(gm, example_inputs):             # 自定义 backend：记录捕获到的每个子图，直接以 eager 执行
        graphs.append(len([n for n in gm.graph.nodes if n.op == "call_function"]))
        return gm.forward

    def f_clean(x):
        return torch.relu(x @ x.T + 1).sum()

    def f_break(x):
        y = x * 2
        print("  （函数内的 print 会触发图断裂）")
        if y.sum() > 0:                                     # 数据相关的分支
            y = y + 1
        else:
            y = y - 1
        return torch.tanh(y).sum()

    torch._dynamo.reset()
    for name, fn in [("无断裂的函数", f_clean), ("含 print 与数据相关分支", f_break)]:
        graphs.clear()
        torch.compile(fn, backend=counting_backend)(torch.randn(8, 16))
        print(f"  {name}：捕获到 {len(graphs)} 个子图，各含算子数 {graphs}")
    try:
        exp = torch._dynamo.explain(f_break)(torch.randn(8, 16))
        print(f"  dynamo.explain：graph_count={exp.graph_count}，graph_break_count={exp.graph_break_count}")
        for br in exp.break_reasons[:3]:
            print(f"    断裂原因：{' '.join(str(br.reason).split())[:100]}")
    except Exception as e:                                  # 不同版本 API 可能变化，如实报告
        print(f"  dynamo.explain 不可用：{type(e).__name__}: {str(e)[:80]}")

    print("\n== 3. 形状变化引起的重编译 ==")
    torch._dynamo.reset()
    graphs.clear()
    cf = torch.compile(f_clean, backend=counting_backend)
    for rows in [8, 9, 10, 11, 8]:
        cf(torch.randn(rows, 16))
        print(f"  输入 ({rows},16) 后累计编译次数 = {len(graphs)}")
    print("  （第二种形状出现时 Dynamo 通常会把该维度标记为动态，之后不再为每个新形状重编译）")


def inductor_demo():
    print("\n== 4. TorchInductor（真正生成融合 kernel 的后端）==")
    try:
        f = torch.compile(lambda x: torch.relu(x * 2 + 1).sum())
        f(torch.randn(64, 64))
        print("  inductor 编译成功（本机具备 C++ 编译器）")
    except Exception as e:
        print(f"  inductor 失败：{type(e).__name__}: {str(e).splitlines()[0][:100]}")
        print("  原因：CPU 后端需要 C++ 编译器生成代码；本环境没有安装。GPU 上 inductor 生成 Triton kernel。")


def main():
    torch.manual_seed(0)
    fx_demo()
    dynamo_demo()
    inductor_demo()
    print("\n[小结] fx 让图可以被程序改写；Dynamo 在字节码层面捕获图，遇到无法追踪的 Python 行为就断开，"
          "\n       断裂越多，编译器能看到的融合范围越小；形状变化会触发重编译或退化为动态形状代码。"
          "\n[问题库] P12 编译器自动化的边界（图断裂、动态形状）")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m13_compiler/outputs/lab_02_torch_compile_capture.txt`）：

```text
# 实测输出：m13_compiler/lab_02_torch_compile_capture.py
# 运行时间：2026-10-18 21:30，耗时 5.2s，峰值内存 388MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 1. torch.fx：符号追踪得到的图 ==
  placeholder    x                              args=()
  call_module    fc                             args=(x,)
  call_function  <built-in function add>        args=(fc, x)
  call_function  <built-in method relu of type object at 0x76fb33fe1300> args=(add,)
  output         output                         args=(relu,)
  替换了 1 处 relu(add)；新图结果与原模块一致：True
  改写后的代码：
    def forward(self, x):
        fc = self.fc(x)
        fused_add_relu = __main___fused_add_relu(fc, x);  fc = x = None
        return fused_add_relu

== 2. TorchDynamo：图断裂 ==
  无断裂的函数：捕获到 1 个子图，各含算子数 [4]
  （函数内的 print 会触发图断裂）
  含 print 与数据相关分支：捕获到 3 个子图，各含算子数 [1, 1, 2]
  （函数内的 print 会触发图断裂）
  dynamo.explain：graph_count=3，graph_break_count=2
    断裂原因：Failed to trace builtin operator Explanation: Dynamo does not know how to trace builtin operator `pr
    断裂原因：generic_jump TensorVariable()

== 3. 形状变化引起的重编译 ==
  输入 (8,16) 后累计编译次数 = 1
  输入 (9,16) 后累计编译次数 = 2
  输入 (10,16) 后累计编译次数 = 2
  输入 (11,16) 后累计编译次数 = 2
  输入 (8,16) 后累计编译次数 = 2
  （第二种形状出现时 Dynamo 通常会把该维度标记为动态，之后不再为每个新形状重编译）

== 4. TorchInductor（真正生成融合 kernel 的后端）==
  inductor 失败：InductorError: InvalidCxxCompiler: No working C++ compiler found in torch._inductor.config.cpp.cxx: (None, 'g++')
  原因：CPU 后端需要 C++ 编译器生成代码；本环境没有安装。GPU 上 inductor 生成 Triton kernel。

[小结] fx 让图可以被程序改写；Dynamo 在字节码层面捕获图，遇到无法追踪的 Python 行为就断开，
       断裂越多，编译器能看到的融合范围越小；形状变化会触发重编译或退化为动态形状代码。
[问题库] P12 编译器自动化的边界（图断裂、动态形状）
```

### `labs/m13_compiler/lab_03_autotune.py`

```python
"""[M13-L03] 自动调优（autotuning）：分块矩阵乘的 tile 搜索——网格、随机、代价模型引导

目标：在本机实测分块矩阵乘（numpy 实现）不同 (BM, BN, BK) 配置的耗时，观察性能地形的崎岖程度；
      比较"全量网格搜索""随机搜索（固定预算）""用少量样本拟合代价模型再挑选"的效率；
      检查最优配置是否随问题规模变化（可移植性问题）。
先预测：
  1. 最快与最慢配置的耗时相差多少倍？
  2. 只允许试 8 个配置时，随机搜索和代价模型引导哪个更可能找到前 10% 的配置？
可调参数：--sizes（矩阵规模列表）、--budget（搜索预算）、--trials
暴露的问题：搜索开销与跨硬件/跨形状的可移植性 → PROBLEM_BANK P13
对应论文：TVM（AutoTVM）；Ansor（2006.06762）；Triton（@triton.autotune）；TileLang
真实框架对照：triton-lang/triton python/triton/runtime/autotuner.py；apache/tvm python/tvm/meta_schedule/
"""
import argparse
import itertools
import os
import random
import time

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")       # 固定单线程：多线程 BLAS 的调度抖动会淹没配置间的差异
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np  # noqa: E402  （必须在设置线程数之后导入）


def blocked_matmul(A, B, bm, bn, bk):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=A.dtype)
    for i in range(0, n, bm):
        for j in range(0, n, bn):
            acc = C[i:i + bm, j:j + bn]
            for k in range(0, n, bk):
                acc += A[i:i + bm, k:k + bk] @ B[k:k + bk, j:j + bn]
    return C


def measure(A, B, cfg, reps=5):
    blocked_matmul(A, B, *cfg)                             # 预热
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); blocked_matmul(A, B, *cfg); ts.append(time.perf_counter() - t0)
    return sorted(ts)[reps // 2]                           # 中位数，抗干扰


def features(cfg, n):
    """对数空间的特征：log(循环次数) 反映 Python/调用开销，log(访存量) 反映数据复用。"""
    bm, bn, bk = cfg
    loops = (n // bm) * (n // bn) * (n // bk)
    traffic = n ** 3 * (1 / bn + 1 / bm) + n * n * (n // bk)     # 读 A、B 的次数 + C 的读改写
    return [1.0, np.log(loops), np.log(traffic)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", type=int, nargs="+", default=[256, 512])
    ap.add_argument("--budget", type=int, default=8)
    ap.add_argument("--trials", type=int, default=50)
    a = ap.parse_args()
    tiles = [16, 32, 64, 128, 256]
    best_cfg = {}
    for n in a.sizes:
        rng = np.random.default_rng(0)
        A = rng.standard_normal((n, n)).astype(np.float32); B = rng.standard_normal((n, n)).astype(np.float32)
        space = [c for c in itertools.product(tiles, tiles, tiles) if max(c) <= n]
        t = {c: measure(A, B, c) for c in space}
        order = sorted(space, key=t.get)
        best_cfg[n] = order[0]
        print(f"\n== N={n}：{len(space)} 个配置全量实测（单线程，每配置 5 次取中位数；网格搜索耗时 {sum(t.values()) * 6:.1f}s）==")
        for c in order[:3]:
            print(f"  最快 {c}: {t[c] * 1e3:8.2f} ms")
        print(f"  最慢 {order[-1]}: {t[order[-1]] * 1e3:8.2f} ms（相差 {t[order[-1]] / t[order[0]]:.0f}×）")
        top10 = set(order[: max(1, len(order) // 10)])
        r = random.Random(0)
        hit_rand = sum(bool(top10 & set(r.sample(space, a.budget))) for _ in range(a.trials)) / a.trials
        hit_model = 0
        for trial in range(a.trials):                      # 代价模型：先随机测一半预算，最小二乘拟合，再按预测挑另一半
            sample = r.sample(space, a.budget // 2)
            X = np.array([features(c, n) for c in sample]); y = np.log([t[c] for c in sample])
            w, *_ = np.linalg.lstsq(X, y, rcond=None)
            pred = sorted(space, key=lambda c: np.dot(features(c, n), w))
            picked = sample + [c for c in pred if c not in sample][: a.budget - len(sample)]
            hit_model += bool(top10 & set(picked))
        print(f"  预算 {a.budget} 次：随机搜索命中前10%的概率 {hit_rand:.0%}；代价模型引导 {hit_model / a.trials:.0%}")
    if len(a.sizes) > 1:
        print(f"\n== 可移植性：各规模的最优配置 {best_cfg} ==")
        n = a.sizes[-1]
        rng = np.random.default_rng(0)
        A = rng.standard_normal((n, n)).astype(np.float32); B = rng.standard_normal((n, n)).astype(np.float32)
        t_own, t_other = measure(A, B, best_cfg[n]), measure(A, B, best_cfg[a.sizes[0]])
        print(f"  在 N={n} 上用 N={a.sizes[0]} 的最优配置：{t_other * 1e3:.2f} ms vs 自己的最优 {t_own * 1e3:.2f} ms"
              f"（慢 {t_other / t_own:.2f}×）")
    print("\n[小结] 配置空间里好坏相差悬殊且不光滑；全量搜索代价高，随机搜索在小预算下不稳定，"
          "\n       简单代价模型就能显著提高命中率——Ansor/MetaSchedule 用学习到的代价模型做同样的事。"
          "\n       最优配置随形状与硬件变化，所以 Triton 按 key（形状）缓存调优结果，换 GPU 往往要重调。"
          "\n[问题库] P13 自动调优的搜索开销与可移植性")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m13_compiler/outputs/lab_03_autotune.txt`）：

```text
# 实测输出：m13_compiler/lab_03_autotune.py
# 运行时间：2026-10-18 21:30，耗时 6.9s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）


== N=256：125 个配置全量实测（单线程，每配置 5 次取中位数；网格搜索耗时 0.7s）==
  最快 (128, 256, 256):     0.26 ms
  最快 (128, 256, 128):     0.27 ms
  最快 (256, 256, 256):     0.28 ms
  最慢 (16, 16, 16):     8.20 ms（相差 31×）
  预算 8 次：随机搜索命中前10%的概率 52%；代价模型引导 90%

== N=512：125 个配置全量实测（单线程，每配置 5 次取中位数；网格搜索耗时 5.9s）==
  最快 (256, 256, 256):     2.33 ms
  最快 (256, 128, 256):     2.40 ms
  最快 (128, 256, 256):     2.53 ms
  最慢 (16, 16, 16):    68.68 ms（相差 30×）
  预算 8 次：随机搜索命中前10%的概率 56%；代价模型引导 90%

== 可移植性：各规模的最优配置 {256: (128, 256, 256), 512: (256, 256, 256)} ==
  在 N=512 上用 N=256 的最优配置：2.55 ms vs 自己的最优 2.29 ms（慢 1.11×）

[小结] 配置空间里好坏相差悬殊且不光滑；全量搜索代价高，随机搜索在小预算下不稳定，
       简单代价模型就能显著提高命中率——Ansor/MetaSchedule 用学习到的代价模型做同样的事。
       最优配置随形状与硬件变化，所以 Triton 按 key（形状）缓存调优结果，换 GPU 往往要重调。
[问题库] P13 自动调优的搜索开销与可移植性
```

## M14 RL 后训练系统：rollout 与训练的资源配比、权重同步、长尾生成、异步与陈旧度（`labs/m14_rl_systems/`）

### `labs/m14_rl_systems/lab_01_rollout_longtail.py`

```python
"""[M14-L01] RL 后训练的 rollout 长尾：同步、一步异步（one-step off-policy）、部分 rollout 的对比

目标：用离散时间模拟 GRPO/PPO 一类 RL 训练中"生成（rollout）→ 训练 → 权重同步"的循环，
      回复长度服从重尾分布；比较三种调度的每步耗时、rollout 阶段 GPU 利用率和样本陈旧度（staleness）。
先预测：
  1. 一个 batch 里最长回复是中位数的 20 倍时，同步 rollout 阶段的平均 GPU 利用率大约多少？
  2. 一步异步把每步时间压到 max(rollout, train)，代价是什么？
可调参数：--prompts、--n（每 prompt 采样数）、--sigma（长度分布重尾程度）、--max-len、--cap（部分 rollout 截断长度）
暴露的问题：长尾导致 GPU 空闲；异步带来陈旧度 → PROBLEM_BANK P26、P28
对应论文：HybridFlow/verl（2409.19256）；AReaL（2505.24298，全异步 + 陈旧度控制）；
          RollPacker（2509.21009，长尾 rollout）；StreamRL；Laminar；Kimi k1.5 的 partial rollout
真实框架对照：verl-project/verl 的 one_step_off_policy recipe；areal-project/AReaL；THUDM/slime
"""
import argparse

import numpy as np

STEP_BASE, STEP_PER_SEQ = 0.020, 0.0001          # decode 一步：20ms + 0.1ms×并发序列数（假设）
TRAIN_PER_TOKEN = 2e-6                          # 训练每 token 耗时（假设，按全部 GPU 摊薄后）


def rollout(lengths, cap=None):
    """连续批 decode：所有序列同时开始，逐个完成后释放槽位。返回 (耗时, 平均利用率, 每条完成的 token 数)。
    第 s 步的并发数 = 长度 > s 的序列数，所以 Σ_s 并发数 = Σ 完成 token 数，耗时有闭式解。"""
    done = np.minimum(lengths, cap) if cap else np.asarray(lengths)
    steps = int(done.max())
    t = steps * STEP_BASE + STEP_PER_SEQ * done.sum()
    util = done.sum() / (steps * len(done))       # 相对于"所有槽位一直满载"
    return t, util, done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompts", type=int, default=64)
    ap.add_argument("--n", type=int, default=8)
    ap.add_argument("--sigma", type=float, default=1.0, help="对数正态的 σ，越大尾越重")
    ap.add_argument("--max-len", type=int, default=16384)
    ap.add_argument("--cap", type=int, default=4096)
    ap.add_argument("--steps", type=int, default=20)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    B = a.prompts * a.n
    sample = lambda: np.clip(rng.lognormal(np.log(800), a.sigma, size=B), 16, a.max_len).astype(int)
    L = sample()
    print(f"== 每步 {B} 条回复：中位数 {np.median(L):.0f}，P99 {np.percentile(L, 99):.0f}，最长 {L.max()} "
          f"（最长/中位 = {L.max() / np.median(L):.1f}×）==")

    sync_t, util_sum, async_t, async_split, part_t, stale = 0, 0, 0, 0, 0, []
    carry = np.array([], dtype=int)                       # 部分 rollout：上一步没写完的剩余长度
    for _ in range(a.steps):
        L = sample()
        tr, util, done = rollout(L)
        train = TRAIN_PER_TOKEN * done.sum() * 8          # ×8：前向+反向+参考模型等的粗略系数
        sync_t += tr + train + 1.0                        # +1s 权重同步（假设）
        util_sum += util
        async_t += max(tr, train) + 1.0                   # 一步异步·理想重叠（不考虑 GPU 被划分）
        async_split += max(2 * tr, 2 * train) + 1.0       # 一步异步·GPU 按 1:1 划分：两边各自变慢一倍（配比见 lab_02）
        # 部分 rollout：每步最多生成 cap 个 token，没写完的序列留到下一步继续（其前半段由旧策略生成）
        lens = np.concatenate([carry, L])[:B]
        tp, _, donep = rollout(lens, cap=a.cap)
        carry = (lens - donep)[lens > donep]
        stale.extend([1] * len(carry))
        part_t += tp + TRAIN_PER_TOKEN * donep.sum() * 8 + 1.0
    print(f"  同步（生成→训练→同步）：平均每步 {sync_t / a.steps:6.1f}s，rollout 阶段 GPU 利用率 {util_sum / a.steps:5.1%}")
    print(f"  一步异步（理想重叠）：  平均每步 {async_t / a.steps:6.1f}s，样本陈旧度 = 1 个版本（全部样本）")
    print(f"  一步异步（GPU 1:1 划分）：平均每步 {async_split / a.steps:6.1f}s——划分比例不对时可能比同步还慢")
    print(f"  部分 rollout(cap={a.cap})：平均每步 {part_t / a.steps:6.1f}s，"
          f"跨步续写的样本 {len(stale)} 条（{len(stale) / (B * a.steps):.1%}），这些样本混合了新旧策略")
    print("\n== 长度分布的重尾程度对同步利用率的影响 ==")
    for sg in [0.3, 0.6, 1.0, 1.4]:
        L = np.clip(rng.lognormal(np.log(800), sg, size=B), 16, a.max_len).astype(int)
        tr, util, _ = rollout(L)
        print(f"  σ={sg}: 最长/中位={L.max() / np.median(L):5.1f}×  rollout {tr:6.1f}s  利用率 {util:5.1%}")
    print("\n[小结] 同步 RL 的 rollout 阶段被最长的回复决定，后半程只有少数序列在跑，GPU 大量空闲；"
          "\n       一步异步/全异步用陈旧度换吞吐，需要算法侧（重要性采样修正、陈旧度上限）配合；"
          "\n       部分 rollout 把长尾切开分摊到多步，但让一条样本由多个策略版本生成。"
          "\n[问题库] P26 rollout 长尾；P28 异步 RL 的陈旧度与吞吐")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m14_rl_systems/outputs/lab_01_rollout_longtail.txt`）：

```text
# 实测输出：m14_rl_systems/lab_01_rollout_longtail.py
# 运行时间：2026-10-18 21:30，耗时 0.2s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 每步 512 条回复：中位数 765，P99 6648，最长 16384 （最长/中位 = 21.4×）==
  同步（生成→训练→同步）：平均每步  356.1s，rollout 阶段 GPU 利用率  9.7%
  一步异步（理想重叠）：  平均每步  345.3s，样本陈旧度 = 1 个版本（全部样本）
  一步异步（GPU 1:1 划分）：平均每步  689.6s——划分比例不对时可能比同步还慢
  部分 rollout(cap=4096)：平均每步  156.1s，跨步续写的样本 607 条（5.9%），这些样本混合了新旧策略

== 长度分布的重尾程度对同步利用率的影响 ==
  σ=0.3: 最长/中位=  2.6×  rollout   83.6s  利用率 40.1%
  σ=0.6: 最长/中位=  5.6×  rollout  141.5s  利用率 21.1%
  σ=1.0: 最长/中位= 16.1×  rollout  328.5s  利用率  9.7%
  σ=1.4: 最长/中位= 23.6×  rollout  413.6s  利用率 10.2%

[小结] 同步 RL 的 rollout 阶段被最长的回复决定，后半程只有少数序列在跑，GPU 大量空闲；
       一步异步/全异步用陈旧度换吞吐，需要算法侧（重要性采样修正、陈旧度上限）配合；
       部分 rollout 把长尾切开分摊到多步，但让一条样本由多个策略版本生成。
[问题库] P26 rollout 长尾；P28 异步 RL 的陈旧度与吞吐
```

### `labs/m14_rl_systems/lab_02_resource_allocation.py`

```python
"""[M14-L02] RL 训练的资源配比：共置（colocated，分时复用）vs 分离（disaggregated，按比例划分 GPU）

目标：在固定 GPU 总数下，估算两种部署方式的每步耗时：
      - 共置：全部 GPU 先做 rollout，再切换到训练（需要卸载/重载权重与优化器、重切分），再切回；
      - 分离：Gr 张卡专做 rollout、Gt 张卡专做训练，流水重叠（一步异步），每步通过网络同步权重。
      扫描划分比例，观察最优比例如何随平均回复长度（推理模型越来越长）而变化。
先预测：
  1. 平均回复从 1K token 增到 8K token，最优的 rollout:训练 GPU 比例会怎样变化？
  2. 权重同步带宽从 100GB/s 降到 10GB/s，对哪种部署影响更大？
可调参数：--gpus、--params（模型参数量）、--resp（平均回复长度列表）、--sync-bw（GB/s）
暴露的问题：rollout/训练的资源配比、权重同步开销 → PROBLEM_BANK P27、P26
对应论文：HybridFlow/verl（共置与 3D-HybridEngine 重切分）；OpenRLHF（Ray 分离部署）；
          StreamRL（2504.15930，分离 + 流式）；AReaL；工程证据：verl PR #7864（权重同步前 full GC 导致变慢）
注意：吞吐系数为教学用假设值，只用于比较趋势。
"""
import argparse


def rollout_time(tokens, gpus, resp):
    # 生成吞吐：每卡 2000 tok/s 为基准；回复越长，每步要读的 KV 越多、显存允许的并发越小，
    # 单 token 成本随长度上升（假设：吞吐 ∝ 1/(1 + resp/4000)）
    return tokens / (2000 / (1 + resp / 4000) * gpus)


def train_time(tokens, gpus, resp):
    # 训练吞吐：每卡 6000 tok/s 为基准，注意力的二次项让长序列略慢（假设：∝ 1/(1 + resp/32000)）
    return tokens / (6000 / (1 + resp / 32000) * gpus)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpus", type=int, default=64)
    ap.add_argument("--params", type=float, default=7e9)
    ap.add_argument("--samples", type=int, default=1024, help="每步样本数")
    ap.add_argument("--resp", type=int, nargs="+", default=[1000, 4000, 8000])
    ap.add_argument("--sync-bw", type=float, nargs="+", default=[100, 10])
    a = ap.parse_args()
    wbytes = 2 * a.params                                      # BF16 权重
    for bw in a.sync_bw:
        sync = wbytes / (bw * 1e9)                             # 训练侧 → rollout 侧的一次权重广播（流水化近似）
        switch = 2 * (16 * a.params / a.gpus) / 25e9 + 3.0     # 共置：卸载/重载每卡的模型状态（PCIe ~25GB/s）+ 重切分开销
        print(f"\n== 权重同步带宽 {bw}GB/s：分离部署每步同步 {sync:.2f}s；共置每步切换 {switch:.2f}s ==")
        for resp in a.resp:
            tokens = a.samples * resp
            colo = rollout_time(tokens, a.gpus, resp) + train_time(tokens, a.gpus, resp) + switch
            best = None
            row = []
            for frac in [0.5, 0.625, 0.75, 0.8125, 0.875, 0.9375]:
                gr = int(a.gpus * frac); gt = a.gpus - gr
                t = max(rollout_time(tokens, gr, resp), train_time(tokens, gt, resp)) + sync
                row.append(f"{frac:.0%}:{t:6.1f}s")
                best = min(best or (t, frac), (t, frac))
            print(f"  回复 {resp:5d} tok：共置 {colo:6.1f}s | 分离（rollout 占比:每步）" + "  ".join(row)
                  + f" | 最优占比 {best[1]:.0%}")
    print("\n[小结] 分离部署靠重叠 rollout 与训练省时间，但必须选对比例，且每步付出权重同步；共置没有比例问题，"
          "\n       却要付切换成本并串行执行。在本模型“长回复使 decode 单 token 变贵”的假设下，回复越长最优比例越偏向 rollout——推理模型时代的 RL 系统"
          "\n       因此越来越需要弹性/动态的资源配比，以及更快、更可靠的权重同步。"
          "\n[问题库] P27 权重同步开销与正确性；P26 rollout 长尾")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m14_rl_systems/outputs/lab_02_resource_allocation.txt`）：

```text
# 实测输出：m14_rl_systems/lab_02_resource_allocation.py
# 运行时间：2026-10-18 21:30，耗时 0.1s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）


== 权重同步带宽 100GB/s：分离部署每步同步 0.14s；共置每步切换 3.14s ==
  回复  1000 tok：共置   15.9s | 分离（rollout 占比:每步）50%:  20.1s  62%:  16.1s  75%:  13.5s  81%:  14.8s  88%:  22.1s  94%:  44.1s | 最优占比 75%
  回复  4000 tok：共置   79.1s | 分离（rollout 占比:每步）50%: 128.1s  62%: 102.5s  75%:  85.5s  81%:  78.9s  88%:  96.1s  94%: 192.1s | 最优占比 81%
  回复  8000 tok：共置  221.8s | 分离（rollout 占比:每步）50%: 384.1s  62%: 307.3s  75%: 256.1s  81%: 236.4s  88%: 219.6s  94%: 426.8s | 最优占比 88%

== 权重同步带宽 10GB/s：分离部署每步同步 1.40s；共置每步切换 3.14s ==
  回复  1000 tok：共置   15.9s | 分离（rollout 占比:每步）50%:  21.4s  62%:  17.4s  75%:  14.7s  81%:  16.1s  88%:  23.4s  94%:  45.4s | 最优占比 75%
  回复  4000 tok：共置   79.1s | 分离（rollout 占比:每步）50%: 129.4s  62%: 103.8s  75%:  86.7s  81%:  80.2s  88%:  97.4s  94%: 193.4s | 最优占比 81%
  回复  8000 tok：共置  221.8s | 分离（rollout 占比:每步）50%: 385.4s  62%: 308.6s  75%: 257.4s  81%: 237.7s  88%: 220.8s  94%: 428.1s | 最优占比 88%

[小结] 分离部署靠重叠 rollout 与训练省时间，但必须选对比例，且每步付出权重同步；共置没有比例问题，
       却要付切换成本并串行执行。在本模型“长回复使 decode 单 token 变贵”的假设下，回复越长最优比例越偏向 rollout——推理模型时代的 RL 系统
       因此越来越需要弹性/动态的资源配比，以及更快、更可靠的权重同步。
[问题库] P27 权重同步开销与正确性；P26 rollout 长尾
```

## M15 研究方法：怎样读系统论文、做 benchmark、定义问题和基线、写系统论文（`labs/m15_research_methods/`）

### `labs/m15_research_methods/lab_01_benchmark_methodology.py`

```python
"""[M15-L01] Benchmark 方法学：预热、重复、方差、A/A 测试与 bootstrap 置信区间

目标：用真实计时演示系统论文里常见的测量陷阱：首次运行偏慢、单次测量的噪声、均值被离群点拉偏；
      用 A/A 测试（同一个函数比较两次）估计"噪声能制造多大的假差异"，再用 bootstrap 置信区间判断
      A/B 的差异是否可信；最后给出报告模板。
先预测：
  1. 同一个函数测两次，单次测量的"加速比"可能偏离 1.0 多少？
  2. 报告均值还是中位数？什么时候两者差别大？
可调参数：--n（矩阵规模）、--reps、--boot
暴露的问题：不可复现、不可比较的性能数字 → PROBLEM_BANK P29
对应论文：Hoefler & Belli, "Scientific Benchmarking of Parallel Computing Systems"（SC'15，二手引用，见 SOURCES）；
          MLPerf 的测量规则；各系统论文附录中的实验设置
"""
import argparse
import random
import statistics
import time

import torch


def timeit(fn, reps, warmup):
    for _ in range(warmup):
        fn()
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); ts.append(time.perf_counter() - t0)
    return ts


def interleaved(fa, fb, reps, warmup, rng):
    """A、B 随机交错测量：让漂移（频率变化、其他进程、温度）同等地影响两边。"""
    for _ in range(warmup):
        fa(); fb()
    ta, tb = [], []
    for _ in range(reps):
        order = [(fa, ta), (fb, tb)]
        rng.shuffle(order)
        for fn, out in order:
            t0 = time.perf_counter(); fn(); out.append(time.perf_counter() - t0)
    return ta, tb


def bootstrap_ratio_ci(a, b, boot, rng):
    """中位数之比 median(a)/median(b) 的 95% bootstrap 置信区间。"""
    rs = []
    for _ in range(boot):
        sa = [rng.choice(a) for _ in a]; sb = [rng.choice(b) for _ in b]
        rs.append(statistics.median(sa) / statistics.median(sb))
    rs.sort()
    return rs[int(0.025 * boot)], rs[int(0.975 * boot)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=384)
    ap.add_argument("--reps", type=int, default=40)
    ap.add_argument("--boot", type=int, default=2000)
    a = ap.parse_args()
    rng = random.Random(0)
    torch.manual_seed(0)
    x = torch.randn(a.n, a.n)
    f_a = lambda: (x @ x).relu_()                           # 实现 A
    f_b = lambda: torch.clamp_min(torch.mm(x, x), 0)        # 实现 B：数学等价，开销略有不同

    print("== 1. 首次运行效应（冷启动：内存分配、线程池、缓存）==")
    y = torch.randn(a.n + 1, a.n + 1)                       # 新形状，避免复用之前的分配
    cold = timeit(lambda: y @ y, reps=5, warmup=0)
    print("  前 5 次耗时(ms)：" + ", ".join(f"{t * 1e3:.3f}" for t in cold))

    print("\n== 2. A/A 测试：同一个函数测两组，噪声和漂移能制造多大的'加速' ==")
    a1, a2 = timeit(f_a, a.reps, 5), timeit(f_a, a.reps, 5)
    single = [a1[i] / a2[i] for i in range(min(10, a.reps))]
    print("  (a) 先测完一组再测另一组；逐次配对的'加速比'：" + ", ".join(f"{r:.2f}" for r in single))
    lo, hi = bootstrap_ratio_ci(a1, a2, a.boot, rng)
    ok = "包含 1，未见系统偏差" if lo <= 1 <= hi else "不包含 1 → 存在顺序/漂移效应，先后测量不可信！"
    print(f"      中位数之比 {statistics.median(a1) / statistics.median(a2):.3f}，95% CI [{lo:.3f}, {hi:.3f}]：{ok}")
    b1, b2 = interleaved(f_a, f_a, a.reps, 5, rng)
    lo, hi = bootstrap_ratio_ci(b1, b2, a.boot, rng)
    ok = "包含 1" if lo <= 1 <= hi else "仍不包含 1（噪声很大，需增加重复次数或独占机器）"
    print(f"  (b) 随机交错测量：中位数之比 {statistics.median(b1) / statistics.median(b2):.3f}，"
          f"95% CI [{lo:.3f}, {hi:.3f}]：{ok}")
    print(f"  均值 {statistics.mean(a1) * 1e3:.3f}ms vs 中位数 {statistics.median(a1) * 1e3:.3f}ms，"
          f"最大值 {max(a1) * 1e3:.3f}ms（离群点会拉高均值）")

    print("\n== 3. A/B（随机交错测量）：两个实现，差异是否显著 ==")
    ta, tb = interleaved(f_a, f_b, a.reps, 5, rng)
    lo, hi = bootstrap_ratio_ci(tb, ta, a.boot, rng)
    ratio = statistics.median(tb) / statistics.median(ta)
    verdict = "显著" if (lo > 1 or hi < 1) else "不显著（置信区间包含 1）"
    print(f"  B/A 中位数耗时比 {ratio:.3f}，95% CI [{lo:.3f}, {hi:.3f}] → {verdict}")
    print(f"  A: 中位数 {statistics.median(ta) * 1e3:.3f}ms，IQR "
          f"[{sorted(ta)[a.reps // 4] * 1e3:.3f}, {sorted(ta)[3 * a.reps // 4] * 1e3:.3f}]")

    print("\n== 4. 线程数这类'环境变量'会改变结论 ==")
    for th in [1, torch.get_num_threads()]:
        torch.set_num_threads(th)
        t1, t2 = timeit(f_a, 15, 3), timeit(f_b, 15, 3)
        print(f"  threads={th:2d}: A {statistics.median(t1) * 1e3:.3f}ms  B {statistics.median(t2) * 1e3:.3f}ms")

    print("\n== 报告模板（写进论文的实验设置）==")
    print(f"  硬件/软件：CPU 线程数、torch {torch.__version__}、输入规模 n={a.n}；预热 5 次、重复 {a.reps} 次；"
          "\n  报告中位数与 IQR/95% CI；说明是否固定频率、是否独占机器；给出复现脚本与原始数据。")
    print("\n[小结] 单次测量的'加速'可能完全来自噪声或漂移；先做 A/A 测试确定噪声底，交错测量消除顺序效应，"
          "\n       再用置信区间判断差异。"
          "\n       冷启动、线程数、频率、其他进程都会改变结果——系统论文的实验设置必须把这些写清楚。"
          "\n[问题库] P29 benchmark 方法学")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m15_research_methods/outputs/lab_01_benchmark_methodology.txt`）：

```text
# 实测输出：m15_research_methods/lab_01_benchmark_methodology.py
# 运行时间：2026-10-18 21:30，耗时 1.2s，峰值内存 229MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 1. 首次运行效应（冷启动：内存分配、线程池、缓存）==
  前 5 次耗时(ms)：9.986, 0.392, 0.364, 0.373, 0.364

== 2. A/A 测试：同一个函数测两组，噪声和漂移能制造多大的'加速' ==
  (a) 先测完一组再测另一组；逐次配对的'加速比'：1.80, 1.61, 2.06, 1.49, 1.07, 0.98, 1.97, 2.75, 1.45, 1.46
      中位数之比 1.019，95% CI [0.991, 1.069]：包含 1，未见系统偏差
  (b) 随机交错测量：中位数之比 1.120，95% CI [0.716, 1.427]：包含 1
  均值 0.276ms vs 中位数 0.229ms，最大值 0.612ms（离群点会拉高均值）

== 3. A/B（随机交错测量）：两个实现，差异是否显著 ==
  B/A 中位数耗时比 1.010，95% CI [0.955, 1.041] → 不显著（置信区间包含 1）
  A: 中位数 0.230ms，IQR [0.224, 0.287]

== 4. 线程数这类'环境变量'会改变结论 ==
  threads= 1: A 0.920ms  B 0.887ms
  threads= 8: A 0.348ms  B 0.337ms

== 报告模板（写进论文的实验设置）==
  硬件/软件：CPU 线程数、torch 2.14.1+cpu、输入规模 n=384；预热 5 次、重复 40 次；
  报告中位数与 IQR/95% CI；说明是否固定频率、是否独占机器；给出复现脚本与原始数据。

[小结] 单次测量的'加速'可能完全来自噪声或漂移；先做 A/A 测试确定噪声底，交错测量消除顺序效应，
       再用置信区间判断差异。
       冷启动、线程数、频率、其他进程都会改变结果——系统论文的实验设置必须把这些写清楚。
[问题库] P29 benchmark 方法学
```

### `labs/m15_research_methods/lab_02_paper_figures.py`

```python
"""[M15-L02] 系统论文的标准图表：吞吐-延迟曲线、延迟 CDF、时间分解堆叠柱状图、消融表

目标：用一个可复现的小型调度模拟器生成数据，画出系统论文最常见的三类图，并输出 CSV 原始数据与消融表；
      学会"一张图回答一个问题"：曲线看取舍、CDF 看尾部、分解看瓶颈、消融看每个设计的贡献。
先预测：吞吐-延迟曲线上，"拐点"出现在什么位置？两种调度的曲线会交叉吗？
可调参数：--out（输出目录，默认系统临时目录下的 ai-infra-tutor-figures）、--n
说明：图中文字用英文，避免环境缺少中文字体时出现方块；若未安装 matplotlib，只输出 CSV。
暴露的问题：图表要支撑论点、数据要可复现 → PROBLEM_BANK P29
对应论文：DistServe、Sarathi-Serve、vLLM 的评测章节（可对照它们的图表结构）
"""
import argparse
import csv
import os
import random
import tempfile


def simulate(rate, budget, n, seed=0):
    """极简单卡调度模拟：返回每个请求的 (TTFT, TPOT)，以及时间分解（prefill/decode/idle 秒）。"""
    rng = random.Random(seed)
    t, arr = 0.0, []
    for _ in range(n):
        t += rng.expovariate(rate); arr.append((t, rng.randint(128, 2048), rng.randint(32, 256)))
    now, i, run, res, br = 0.0, 0, [], [], {"prefill": 0.0, "decode": 0.0, "overhead": 0.0, "idle": 0.0}
    while i < len(arr) or run:
        if not run and arr[i][0] > now:
            br["idle"] += arr[i][0] - now; now = arr[i][0]
        while i < len(arr) and arr[i][0] <= now:
            run.append({"arr": arr[i][0], "P": arr[i][1], "O": arr[i][2], "done": 0, "gen": 0, "first": None})
            i += 1
        dec = [r for r in run if r["done"] >= r["P"]]
        room, pre = budget - len(dec), 0
        for r in run:
            if r["done"] < r["P"] and room > 0:
                c = min(room, r["P"] - r["done"]); r["done"] += c; room -= c; pre += c
        br["prefill"] += 0.00003 * pre; br["decode"] += 0.00004 * len(dec); br["overhead"] += 0.005
        now += 0.005 + 0.00003 * pre + 0.00004 * len(dec)    # 迭代耗时模型同 M11-L02
        for r in run:
            if r in dec:
                r["gen"] += 1
            elif r["done"] >= r["P"]:                     # 本次迭代刚完成 prefill，产出第一个 token
                r["first"] = now; r["gen"] = 1
        for r in [r for r in run if r["first"] is not None and r["gen"] >= r["O"]]:
            res.append((r["first"] - r["arr"], (now - r["first"]) / max(1, r["O"] - 1)))
            run.remove(r)
    return res, br


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(tempfile.gettempdir(), "ai-infra-tutor-figures"))
    ap.add_argument("--n", type=int, default=300)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    rates = [2, 4, 6, 8, 10, 12, 14]
    rows = []
    for budget in [256, 2048]:
        for r in rates:
            res, br = simulate(r, budget, a.n)
            ttft = sorted(x[0] for x in res); tpot = sorted(x[1] for x in res)
            rows.append({"budget": budget, "rate": r, "ttft_p50": ttft[len(ttft) // 2], "ttft_p99": ttft[int(.99 * len(ttft))],
                         "tpot_p50": tpot[len(tpot) // 2], "tpot_p99": tpot[int(.99 * len(tpot))], **br})
    path = os.path.join(a.out, "throughput_latency.csv")
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"== 原始数据已写入 {path} ==")
    print(f"  {'budget':>6s} {'rate':>4s} {'TTFT p99(s)':>11s} {'TPOT p99(ms)':>12s}")
    for r in rows:
        print(f"  {r['budget']:6d} {r['rate']:4d} {r['ttft_p99']:11.3f} {r['tpot_p99'] * 1e3:12.2f}")

    print("\n== 消融/敏感性表（rate=14，接近饱和）：逐个打开设计，看每项贡献 ==")
    for name, b in [("基线：budget=8192（近似整段 prefill）", 8192), ("+ 分块 prefill（budget=1024）", 1024),
                    ("+ 更小的块（budget=256）", 256)]:
        res, _ = simulate(14, b, a.n)
        tp = sorted(x[1] for x in res); tt = sorted(x[0] for x in res)
        print(f"  {name:36s} TPOT p99 {tp[int(.99 * len(tp))] * 1e3:6.2f}ms   TTFT p99 {tt[int(.99 * len(tt))]:6.3f}s")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("\n  未安装 matplotlib：只输出 CSV。安装 env/requirements-cpu.txt 后可生成图片。")
        return
    fig, ax = plt.subplots(1, 3, figsize=(14, 4))
    for b, style in [(256, "o-"), (2048, "s--")]:
        sel = [r for r in rows if r["budget"] == b]
        ax[0].plot([r["rate"] for r in sel], [r["tpot_p99"] * 1e3 for r in sel], style, label=f"chunk budget={b}")
    ax[0].set_xlabel("request rate (req/s)"); ax[0].set_ylabel("P99 TPOT (ms)"); ax[0].legend(); ax[0].set_title("Throughput vs latency")
    for b, style in [(256, "-"), (2048, "--")]:
        res, _ = simulate(10, b, a.n)
        xs = sorted(x[0] for x in res)
        ax[1].plot(xs, [i / len(xs) for i in range(len(xs))], style, label=f"budget={b}")
    ax[1].set_xlabel("TTFT (s)"); ax[1].set_ylabel("CDF"); ax[1].legend(); ax[1].set_title("TTFT CDF @ 10 req/s")
    sel = [r for r in rows if r["budget"] == 256]
    bottom = [0] * len(sel)
    for k in ["prefill", "decode", "overhead", "idle"]:
        vals = [r[k] for r in sel]
        ax[2].bar([str(r["rate"]) for r in sel], vals, bottom=bottom, label=k)
        bottom = [x + y for x, y in zip(bottom, vals)]
    ax[2].set_xlabel("request rate"); ax[2].set_ylabel("GPU time (s)"); ax[2].legend(); ax[2].set_title("Time breakdown")
    fig.tight_layout()
    png = os.path.join(a.out, "figures.png")
    fig.savefig(png, dpi=120)
    print(f"\n  图已保存：{png}")
    print("\n[小结] 吞吐-延迟曲线展示取舍与拐点，CDF 展示尾部，分解图说明瓶颈在哪；消融/敏感性表要如实呈现取舍"
          "\n       （本例中更小的块改善 TPOT 却恶化 TTFT，且改善并不单调）。"
          "\n       每张图都要能被一个脚本从原始数据重新生成——这就是可复现性。"
          "\n[问题库] P29 benchmark 方法学与可复现性")


if __name__ == "__main__":
    main()
```

**实测输出**（`labs/m15_research_methods/outputs/lab_02_paper_figures.txt`）：

```text
# 实测输出：m15_research_methods/lab_02_paper_figures.py
# 运行时间：2026-10-18 21:30，耗时 1.2s，峰值内存 219MB，状态 PASS
# 环境：Python 3.12.3，x86_64，16 逻辑核（不同机器上的计时数字会不同，趋势应一致）

== 原始数据已写入 /tmp/ai-infra-tutor-figures/throughput_latency.csv ==
  budget rate TTFT p99(s) TPOT p99(ms)
     256    2       0.149         6.97
     256    4       0.180         8.06
     256    6       0.207         9.62
     256    8       0.241        10.77
     256   10       0.285        12.12
     256   12       0.395        12.96
     256   14       0.720        13.01
    2048    2       0.093         7.08
    2048    4       0.107         8.14
    2048    6       0.126         9.71
    2048    8       0.142        11.05
    2048   10       0.156        12.40
    2048   12       0.171        15.29
    2048   14       0.198        18.54

== 消融/敏感性表（rate=14，接近饱和）：逐个打开设计，看每项贡献 ==
  基线：budget=8192（近似整段 prefill）         TPOT p99  18.57ms   TTFT p99  0.204s
  + 分块 prefill（budget=1024）            TPOT p99  19.44ms   TTFT p99  0.196s
  + 更小的块（budget=256）                   TPOT p99  13.01ms   TTFT p99  0.720s

  图已保存：/tmp/ai-infra-tutor-figures/figures.png

[小结] 吞吐-延迟曲线展示取舍与拐点，CDF 展示尾部，分解图说明瓶颈在哪；消融/敏感性表要如实呈现取舍
       （本例中更小的块改善 TPOT 却恶化 TTFT，且改善并不单调）。
       每张图都要能被一个脚本从原始数据重新生成——这就是可复现性。
[问题库] P29 benchmark 方法学与可复现性
```

