"""[M14-L02] RL 训练的资源配比：共置（colocated，分时复用）vs 分离（disaggregated，按比例划分 GPU）

目标：在固定 GPU 总数下，估算两种部署方式的每步耗时：
      - 共置：全部 GPU 先做 rollout，再切换到训练（需要卸载/重载权重与优化器、重切分），再切回；
      - 分离：Gr 张卡专做 rollout、Gt 张卡专做训练，流水重叠（一步异步），每步通过网络同步权重。
      扫描划分比例，观察最优比例如何随平均回复长度（推理模型越来越长）而变化。
先预测：
  1. 平均回复从 1K token 增到 8K token，最优的 rollout:训练 GPU 比例会怎样变化？
  2. 权重同步带宽从 100GB/s 降到 10GB/s，对哪种部署影响更大？
可调参数：--gpus、--params（模型参数量）、--resp（平均回复长度列表）、--sync-bw（GB/s）
暴露的问题：rollout/训练的资源配比、权重同步开销 → PROBLEM_BANK P27、P26
对应论文：HybridFlow/verl（共置与 3D-HybridEngine 重切分）；OpenRLHF（Ray 分离部署）；
          StreamRL（2504.15930，分离 + 流式）；AReaL；工程证据：verl PR #7864（权重同步前 full GC 导致变慢）
注意：吞吐系数为教学用假设值，只用于比较趋势。
"""
import argparse


def rollout_time(tokens, gpus, resp):
    # 生成吞吐：每卡 2000 tok/s 为基准；回复越长，每步要读的 KV 越多、显存允许的并发越小，
    # 单 token 成本随长度上升（假设：吞吐 ∝ 1/(1 + resp/4000)）
    return tokens / (2000 / (1 + resp / 4000) * gpus)


def train_time(tokens, gpus, resp):
    # 训练吞吐：每卡 6000 tok/s 为基准，注意力的二次项让长序列略慢（假设：∝ 1/(1 + resp/32000)）
    return tokens / (6000 / (1 + resp / 32000) * gpus)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpus", type=int, default=64)
    ap.add_argument("--params", type=float, default=7e9)
    ap.add_argument("--samples", type=int, default=1024, help="每步样本数")
    ap.add_argument("--resp", type=int, nargs="+", default=[1000, 4000, 8000])
    ap.add_argument("--sync-bw", type=float, nargs="+", default=[100, 10])
    a = ap.parse_args()
    wbytes = 2 * a.params                                      # BF16 权重
    for bw in a.sync_bw:
        sync = wbytes / (bw * 1e9)                             # 训练侧 → rollout 侧的一次权重广播（流水化近似）
        switch = 2 * (16 * a.params / a.gpus) / 25e9 + 3.0     # 共置：卸载/重载每卡的模型状态（PCIe ~25GB/s）+ 重切分开销
        print(f"\n== 权重同步带宽 {bw}GB/s：分离部署每步同步 {sync:.2f}s；共置每步切换 {switch:.2f}s ==")
        for resp in a.resp:
            tokens = a.samples * resp
            colo = rollout_time(tokens, a.gpus, resp) + train_time(tokens, a.gpus, resp) + switch
            best = None
            row = []
            for frac in [0.5, 0.625, 0.75, 0.8125, 0.875, 0.9375]:
                gr = int(a.gpus * frac); gt = a.gpus - gr
                t = max(rollout_time(tokens, gr, resp), train_time(tokens, gt, resp)) + sync
                row.append(f"{frac:.0%}:{t:6.1f}s")
                best = min(best or (t, frac), (t, frac))
            print(f"  回复 {resp:5d} tok：共置 {colo:6.1f}s | 分离（rollout 占比:每步）" + "  ".join(row)
                  + f" | 最优占比 {best[1]:.0%}")
    print("\n[小结] 分离部署靠重叠 rollout 与训练省时间，但必须选对比例，且每步付出权重同步；共置没有比例问题，"
          "\n       却要付切换成本并串行执行。在本模型“长回复使 decode 单 token 变贵”的假设下，回复越长最优比例越偏向 rollout——推理模型时代的 RL 系统"
          "\n       因此越来越需要弹性/动态的资源配比，以及更快、更可靠的权重同步。"
          "\n[问题库] P27 权重同步开销与正确性；P26 rollout 长尾")


if __name__ == "__main__":
    main()
