"""[M14-L01] RL 后训练的 rollout 长尾：同步、一步异步（one-step off-policy）、部分 rollout 的对比

目标：用离散时间模拟 GRPO/PPO 一类 RL 训练中"生成（rollout）→ 训练 → 权重同步"的循环，
      回复长度服从重尾分布；比较三种调度的每步耗时、rollout 阶段 GPU 利用率和样本陈旧度（staleness）。
先预测：
  1. 一个 batch 里最长回复是中位数的 20 倍时，同步 rollout 阶段的平均 GPU 利用率大约多少？
  2. 一步异步把每步时间压到 max(rollout, train)，代价是什么？
可调参数：--prompts、--n（每 prompt 采样数）、--sigma（长度分布重尾程度）、--max-len、--cap（部分 rollout 截断长度）
暴露的问题：长尾导致 GPU 空闲；异步带来陈旧度 → PROBLEM_BANK P26、P28
对应论文：HybridFlow/verl（2409.19256）；AReaL（2505.24298，全异步 + 陈旧度控制）；
          RollPacker（2509.21009，长尾 rollout）；StreamRL；Laminar；Kimi k1.5 的 partial rollout
真实框架对照：verl-project/verl 的 one_step_off_policy recipe；areal-project/AReaL；THUDM/slime
"""
import argparse

import numpy as np

STEP_BASE, STEP_PER_SEQ = 0.020, 0.0001          # decode 一步：20ms + 0.1ms×并发序列数（假设）
TRAIN_PER_TOKEN = 2e-6                          # 训练每 token 耗时（假设，按全部 GPU 摊薄后）


def rollout(lengths, cap=None):
    """连续批 decode：所有序列同时开始，逐个完成后释放槽位。返回 (耗时, 平均利用率, 每条完成的 token 数)。
    第 s 步的并发数 = 长度 > s 的序列数，所以 Σ_s 并发数 = Σ 完成 token 数，耗时有闭式解。"""
    done = np.minimum(lengths, cap) if cap else np.asarray(lengths)
    steps = int(done.max())
    t = steps * STEP_BASE + STEP_PER_SEQ * done.sum()
    util = done.sum() / (steps * len(done))       # 相对于"所有槽位一直满载"
    return t, util, done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompts", type=int, default=64)
    ap.add_argument("--n", type=int, default=8)
    ap.add_argument("--sigma", type=float, default=1.0, help="对数正态的 σ，越大尾越重")
    ap.add_argument("--max-len", type=int, default=16384)
    ap.add_argument("--cap", type=int, default=4096)
    ap.add_argument("--steps", type=int, default=20)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    B = a.prompts * a.n
    sample = lambda: np.clip(rng.lognormal(np.log(800), a.sigma, size=B), 16, a.max_len).astype(int)
    L = sample()
    print(f"== 每步 {B} 条回复：中位数 {np.median(L):.0f}，P99 {np.percentile(L, 99):.0f}，最长 {L.max()} "
          f"（最长/中位 = {L.max() / np.median(L):.1f}×）==")

    sync_t, util_sum, async_t, async_split, part_t, stale = 0, 0, 0, 0, 0, []
    carry = np.array([], dtype=int)                       # 部分 rollout：上一步没写完的剩余长度
    for _ in range(a.steps):
        L = sample()
        tr, util, done = rollout(L)
        train = TRAIN_PER_TOKEN * done.sum() * 8          # ×8：前向+反向+参考模型等的粗略系数
        sync_t += tr + train + 1.0                        # +1s 权重同步（假设）
        util_sum += util
        async_t += max(tr, train) + 1.0                   # 一步异步·理想重叠（不考虑 GPU 被划分）
        async_split += max(2 * tr, 2 * train) + 1.0       # 一步异步·GPU 按 1:1 划分：两边各自变慢一倍（配比见 lab_02）
        # 部分 rollout：每步最多生成 cap 个 token，没写完的序列留到下一步继续（其前半段由旧策略生成）
        lens = np.concatenate([carry, L])[:B]
        tp, _, donep = rollout(lens, cap=a.cap)
        carry = (lens - donep)[lens > donep]
        stale.extend([1] * len(carry))
        part_t += tp + TRAIN_PER_TOKEN * donep.sum() * 8 + 1.0
    print(f"  同步（生成→训练→同步）：平均每步 {sync_t / a.steps:6.1f}s，rollout 阶段 GPU 利用率 {util_sum / a.steps:5.1%}")
    print(f"  一步异步（理想重叠）：  平均每步 {async_t / a.steps:6.1f}s，样本陈旧度 = 1 个版本（全部样本）")
    print(f"  一步异步（GPU 1:1 划分）：平均每步 {async_split / a.steps:6.1f}s——划分比例不对时可能比同步还慢")
    print(f"  部分 rollout(cap={a.cap})：平均每步 {part_t / a.steps:6.1f}s，"
          f"跨步续写的样本 {len(stale)} 条（{len(stale) / (B * a.steps):.1%}），这些样本混合了新旧策略")
    print("\n== 长度分布的重尾程度对同步利用率的影响 ==")
    for sg in [0.3, 0.6, 1.0, 1.4]:
        L = np.clip(rng.lognormal(np.log(800), sg, size=B), 16, a.max_len).astype(int)
        tr, util, _ = rollout(L)
        print(f"  σ={sg}: 最长/中位={L.max() / np.median(L):5.1f}×  rollout {tr:6.1f}s  利用率 {util:5.1%}")
    print("\n[小结] 同步 RL 的 rollout 阶段被最长的回复决定，后半程只有少数序列在跑，GPU 大量空闲；"
          "\n       一步异步/全异步用陈旧度换吞吐，需要算法侧（重要性采样修正、陈旧度上限）配合；"
          "\n       部分 rollout 把长尾切开分摊到多步，但让一条样本由多个策略版本生成。"
          "\n[问题库] P26 rollout 长尾；P28 异步 RL 的陈旧度与吞吐")


if __name__ == "__main__":
    main()
