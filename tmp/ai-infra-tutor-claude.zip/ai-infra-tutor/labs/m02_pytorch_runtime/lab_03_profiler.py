"""[M02-L03] 用 torch.profiler 找出时间花在哪

目标：学会读 profiler 表格（Self CPU、CPU total、调用次数），区分"算子多而小"和"算子少而大"；
      理解异步执行：GPU 上 Python 返回 ≠ kernel 完成（CPU 上用线程数实验类比）。
先预测：
  1. 一个由 200 个小 Linear 串起来的网络和一个等 FLOPs 的大 Linear，谁更快？
  2. profiler 表里，哪个算子的 Self CPU 时间最高？
可调参数：--depth、--width、--batch
暴露的问题：小算子/框架开销；需要 profiler 才能定位 → PROBLEM_BANK P11、P29
对应论文：PyTorch 2（ASPLOS'24，动机部分讨论了 eager 模式开销）
真实框架对照：torch/profiler/profiler.py；GPU 上用 Nsight Systems（nsys）看 CUDA stream 时间线
"""
import argparse
import time

import torch
import torch.nn as nn
from torch.profiler import ProfilerActivity, profile


def timeit(fn, reps=20):
    for _ in range(3):
        fn()
    t0 = time.perf_counter()
    for _ in range(reps):
        fn()
    return (time.perf_counter() - t0) / reps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--depth", type=int, default=200)
    ap.add_argument("--width", type=int, default=64)
    ap.add_argument("--batch", type=int, default=32)
    a = ap.parse_args()
    torch.manual_seed(0)

    deep = nn.Sequential(*[nn.Sequential(nn.Linear(a.width, a.width), nn.GELU()) for _ in range(a.depth)])
    # 等 FLOPs 的宽网络：depth*w^2 = W^2 -> W = w*sqrt(depth)
    W = int(a.width * a.depth ** 0.5)
    wide = nn.Sequential(nn.Linear(W, W), nn.GELU())
    x_deep, x_wide = torch.randn(a.batch, a.width), torch.randn(a.batch, W)
    flops_deep = 2 * a.batch * a.width ** 2 * a.depth
    flops_wide = 2 * a.batch * W * W

    with torch.no_grad():
        td, tw = timeit(lambda: deep(x_deep)), timeit(lambda: wide(x_wide))
    print("== 等 FLOPs 的深窄网络 vs 浅宽网络（推理）==")
    print(f"  深窄 {a.depth}×Linear({a.width}): {td * 1e3:7.2f} ms  {flops_deep / td / 1e9:7.1f} GFLOP/s  "
          f"算子数≈{2 * a.depth}")
    print(f"  浅宽 1×Linear({W}):        {tw * 1e3:7.2f} ms  {flops_wide / tw / 1e9:7.1f} GFLOP/s  算子数=2")
    print(f"  每个小算子平均 {td / (2 * a.depth) * 1e6:.1f} us")

    print("\n== profiler：深窄网络前向+反向 ==")
    deep.zero_grad()
    with profile(activities=[ProfilerActivity.CPU], record_shapes=False) as prof:
        deep(x_deep).sum().backward()
    print(prof.key_averages().table(sort_by="self_cpu_time_total", row_limit=8, max_name_column_width=30))

    print("== 线程数的影响（CPU 并行度 ≈ GPU 的 SM 占用）==")
    big = torch.randn(1024, 1024)
    for n in [1, 2, 4, torch.get_num_threads()]:
        torch.set_num_threads(n)
        t = timeit(lambda: big @ big, reps=5)
        print(f"  threads={n:2d}: matmul 1024^3 {t * 1e3:7.2f} ms")
    print("\n[小结] 同样的 FLOPs，拆成很多小算子会慢很多：每个算子都有固定的分发/启动开销，"
          "\n       而且小矩阵乘喂不饱硬件。profiler 的 Self CPU 列告诉你开销在哪。"
          "\n[问题库] P11 框架开销；P29 benchmark 方法学")


if __name__ == "__main__":
    main()
