# M02 PyTorch 运行时：张量与存储、autograd、算子分发、异步执行、profiler

- **对应任务**：D1-T09（讲义）、D1-T10（L01~L03）
- **先修**：M01
- **预计学时**：1.2 小时
- **学习目标**：
  1. 解释张量 = 存储（storage）+ 视图元数据（shape、stride、offset），判断一个操作会不会拷贝数据。
  2. 手写一个最小的反向模式自动微分，说清楚“为反向保存的张量”从哪里来，以及它为什么是训练显存的大头。
  3. 用 `torch.profiler` 找出时间花在哪里，区分“算子多而小”（开销主导）和“算子少而大”（计算或带宽主导）。
  4. 理解 GPU 上的异步执行：Python 返回不代表 kernel 已完成，计时前必须同步。

## 1. 核心讲义

### 1.1 张量的内存布局

一个 `torch.Tensor` 由两部分组成：

- **Storage**：一段连续的一维内存，存放真实数据。
- **视图元数据**：`shape`（各维长度）、`stride`（沿每一维前进一步要跳过多少个元素）、`storage_offset`（从 storage 的第几个元素开始）。

`x` 的形状为 `(3,4)`、stride 为 `(4,1)`；`x.t()` 只是把 shape 和 stride 交换成 `(4,3)` 与 `(1,4)`，**没有拷贝任何数据**，所以它不再“连续”（contiguous）。很多 kernel 只接受连续输入，这时会触发 `.contiguous()` 的隐式拷贝——在 L01 中，对 4096×4096 的矩阵转置后再 `contiguous()` 要 28ms，而 matmul 可以直接处理转置的输入（约 1ms）。

- `view` 只改元数据，要求 stride 兼容；`reshape` 在不兼容时会自动拷贝。
- 切片、`transpose`、`expand` 都是视图；`clone`、`contiguous`（不连续时）、大部分算术运算会产生新存储。

### 1.2 自动微分（autograd）

PyTorch 在前向时构建一张**计算图**：每个由运算得到的张量都记住“我是由谁、经过什么运算得到的”（`grad_fn`）。调用 `loss.backward()` 时，引擎按**拓扑序的逆序**遍历这张图，对每个节点应用链式法则：

```
若 y = f(x)，则 ∂L/∂x = (∂L/∂y) · (∂y/∂x)
```

关键在于：计算 `∂y/∂x` 往往需要前向时的中间值。例如 `y = x @ W` 的反向需要 `x`（求 `∂L/∂W = x^T · g`）和 `W`（求 `∂L/∂x = g · W^T`）；`relu` 的反向只需要一个掩码。这些中间值必须**一直保存到反向用完为止**，这就是**激活值显存**。在 L02 中，一个两层小 MLP 为反向保存了 37.6KB 的张量，而参数本身只有 8.7KB。模型和 batch 变大时，激活值很容易超过参数、梯度、优化器状态的总和（M04 会定量计算）。

### 1.3 算子分发与框架开销

一次 `a + b` 在 PyTorch 里要经过：Python 绑定 → 参数解析 → **dispatcher**（按设备、dtype、是否需要 autograd 等“分发键”选择实现）→ 分配输出内存 → 调用 kernel。这些步骤每次都要做，大约几微秒；在 GPU 上还要加上 kernel 启动（launch）开销，同样是微秒量级。所以：

- 张量很小时，耗时与张量大小几乎无关——这叫**开销主导（overhead-bound）**。L01 中 10 个元素和 1000 个元素的 add 都约 0.9μs。
- 同样的 FLOPs，拆成 400 个小算子比 2 个大算子慢得多：L03 中深窄网络只有 12 GFLOP/s，浅宽网络有 336 GFLOP/s，平均每个小算子约 11μs。

消除开销的手段：**CUDA Graphs**（把一串 kernel 录下来一次性重放，vLLM 的 decode 默认使用）、**算子融合**（M03）、**torch.compile**（M13）。

### 1.4 异步执行与 CUDA stream

在 GPU 上，PyTorch 把 kernel 放入 **CUDA stream**（一个按顺序执行的命令队列）后立即返回，CPU 继续往下执行 Python 代码。好处是 CPU 的调度开销可以和 GPU 计算重叠；坏处是：

- **计时陷阱**：用 `time.time()` 包住一个 GPU 操作，只测到了“提交”的时间。正确做法是先调用 `torch.cuda.synchronize()`，或者使用 `torch.cuda.Event` 计时。
- **隐式同步**：`.item()`、`print(tensor)`、把数据拷回 CPU、某些带数据依赖的操作，会强制 CPU 等 GPU 执行完，打断流水。
- 多个 stream 可以并发执行，例如让通信和计算重叠（M06），这是分布式训练提速的关键。

CPU 上没有 stream，但 L03 的线程数实验可以类比：并行度不足（线程少/SM 占用低）时，大算子也吃不满硬件。

### 1.5 profiler 的读法

`torch.profiler` 的表格里：

- **Self CPU**：算子自身的耗时（不含它调用的子算子）——找开销热点主要看这一列。
- **CPU total**：包含子调用的总耗时。
- **# of Calls**：调用次数——次数多、平均耗时短的，就是融合或 CUDA Graph 的候选。
- GPU 上还有 **Self CUDA** 列；跨进程、跨 stream 的时间线用 Nsight Systems（`nsys`）查看。

## 2. 实验

### M02-L01 张量与存储（`lab_01_tensor_storage.py`）

- **先预测**：(1) `x.t()` 之后 `is_contiguous()` 是什么？`x.t().contiguous()` 会不会分配新内存？(2) 对 10 个元素和 1000 万个元素做 add，单次耗时差多少倍？为什么不是 100 万倍？
- **实测输出摘要**：`x` 与 `x.t()`、切片共享同一块存储（`data_ptr` 相同），`x.t().contiguous()` 换了新地址；修改 `view` 会影响原张量；`x.t().view(12)` 报错，`reshape` 可以执行。单次 add：10 和 1000 个元素都约 0.9μs（开销主导），10 万个元素 6.4μs（数据仍在缓存），1000 万个元素 3.8ms（受带宽限制）。转置后 `contiguous()` 耗时 28ms，matmul 直接处理转置输入约 1ms。
- **解读**：1000 万 / 10 = 100 万倍的数据量，耗时只差约 4000 倍，因为小张量的固定开销占了绝大部分。
- **扫描建议**：`--sizes 10 100 1000 10000 100000 1000000 10000000`，画出“单次耗时 vs 元素数”的双对数图，找到开销区和带宽区的分界。
- **真实框架对照**：PyTorch 源码 `c10/core/TensorImpl.h`（sizes/strides/storage_offset 字段）、`aten/src/ATen/native/TensorShape.cpp`（view/transpose 的实现）。
- **暴露的问题**：[P11](../../research/PROBLEM_BANK.md#p11)。

### M02-L02 迷你 autograd（`lab_02_mini_autograd.py`）

- **先预测**：(1) `y = relu(x @ W1) @ W2` 的反向需要保存哪些中间张量？(2) 前向用 `torch.no_grad()` 时，显存会少掉哪些部分？
- **实测输出摘要**：手写实现与 torch 的梯度差约 1e-16（双精度下完全一致）；torch 为反向保存了 5 个张量，共 37,632 字节，是参数（8,704 字节）的 4.3 倍；用手写 autograd 训练 50 步，loss 从 3.20 降到 0.005。
- **代码要点**：`T.__matmul__` 中的闭包捕获了 `self.data` 和 `o.data`——这正是“保存的激活值”；`backward()` 先用 DFS 做拓扑排序，再逆序累加梯度。
- **扫描建议**：把 `--batch` 从 32 改到 1024，观察保存张量的字节数怎样随 batch 线性增长，而参数字节数不变。
- **真实框架对照**：`torch/csrc/autograd/engine.cpp`（反向执行引擎）、`torch/autograd/function.py`（自定义 `Function`）。CMU 10-414 的 needle 作业会带你实现更完整的版本。
- **暴露的问题**：[P14](../../research/PROBLEM_BANK.md#p14) 训练显存墙。

### M02-L03 profiler（`lab_03_profiler.py`）

- **先预测**：(1) 200 个小 Linear 串成的网络和一个等 FLOPs 的大 Linear，谁更快？(2) profiler 表里哪个算子的 Self CPU 最高？
- **实测输出摘要**：深窄网络 4.35ms（12 GFLOP/s，约 400 个算子），浅宽网络 0.16ms（336 GFLOP/s），**相差约 27 倍**；profiler 中 `aten::addmm`、`aten::gelu`、`aten::mm` 占据前列，调用次数都是 200 左右；matmul 1024³ 在 1/2/4/8 线程下分别为 15.9、8.2、4.3、5.1ms（8 线程反而比 4 线程慢，可能与机器上其他负载或超线程有关——这正说明计时需要重复测量，见 M15）。
- **扫描建议**：`--depth 50 100 200 400 --width 64` 观察开销线性累积；`--width 512` 观察开销占比下降。
- **真实框架对照**：`torch/profiler/profiler.py`；GPU 上用 `nsys profile python train.py` 查看 stream 时间线。
- **暴露的问题**：[P11](../../research/PROBLEM_BANK.md#p11)、[P29](../../research/PROBLEM_BANK.md#p29)。

## 3. 常见误区

- “`view` 和 `reshape` 一样”：前者从不拷贝，不兼容时会报错；后者可能悄悄拷贝。
- “GPU 计时直接用 `time.time()`”：必须先同步。
- “profiler 显示某个算子很慢，就去优化它的 kernel”：先看是 Self 时间长还是调用次数多；调用次数多、平均耗时短，应该融合或用 CUDA Graph。
- “`torch.no_grad()` 只是不算梯度”：它还会让前向不保存激活值，推理时显存因此大幅下降。

## 4. 论文与延伸阅读

- 选读 `pytorch19`：*PyTorch: An Imperative Style, High-Performance Deep Learning Library*（NeurIPS 2019），第 4~5 节讲内存分配器与异步执行的设计。
- `pt2`（D6 精读）的动机部分讨论了 eager 模式的开销。
- 资源：Horace He《Making Deep Learning Go Brrrr》中的 overhead 一节；GPU MODE 第 1 讲（在 PyTorch 中 profile 和集成 CUDA kernel）。

## 5. 自测题

Q-M02-L1-01 ~ Q-M02-L4-01；动手练习见 `exercises.md`。
