"""[M02-L02] 100 行实现反向模式自动微分（reverse-mode autograd），并与 torch.autograd 对照

目标：理解计算图、拓扑排序、反向传播和"为反向保存的激活值"（saved tensors）——
      后者正是训练显存的主要来源之一（M04）。
先预测：
  1. 前向计算 y = relu(x @ W1) @ W2，反向需要保存哪些中间张量？
  2. 如果前向用 torch.no_grad()，显存会少掉哪些部分？
可调参数：--batch、--hidden、--steps
暴露的问题：激活值必须保存到反向 → 显存墙 → PROBLEM_BANK P14
对应论文：PyTorch（NeurIPS'19）；CMU 10-414 DLSys 课程 needle 框架（作业形式）
真实框架对照：torch/csrc/autograd/engine.cpp（反向执行引擎）、torch/autograd/function.py
"""
import argparse

import numpy as np
import torch


class T:
    """最小张量：保存值、梯度、父节点和本地反向函数。"""

    def __init__(self, data, parents=(), backward=None, name=""):
        self.data, self.grad = np.asarray(data, dtype=np.float64), None
        self.parents, self._backward, self.name = parents, backward, name

    def __matmul__(self, o):
        out = T(self.data @ o.data, (self, o), name="matmul")
        # 反向需要两个输入 -> 它们被"保存"下来（显存开销）
        out._backward = lambda g: (g @ o.data.T, self.data.T @ g)
        return out

    def relu(self):
        mask = self.data > 0
        out = T(self.data * mask, (self,), name="relu")
        out._backward = lambda g: (g * mask,)            # 只需保存 mask
        return out

    def mse(self, target):
        diff = self.data - target
        out = T((diff ** 2).mean(), (self,), name="mse")
        out._backward = lambda g: (g * 2 * diff / diff.size,)
        return out

    def backward(self):
        order, seen = [], set()

        def topo(v):                                       # DFS 拓扑排序
            if id(v) not in seen:
                seen.add(id(v))
                for p in v.parents:
                    topo(p)
                order.append(v)
        topo(self)
        self.grad = np.ones_like(self.data)
        for v in reversed(order):
            if v._backward is None:
                continue
            for p, g in zip(v.parents, v._backward(v.grad)):
                p.grad = g if p.grad is None else p.grad + g


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--steps", type=int, default=50)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    X = rng.normal(size=(a.batch, 16)); Y = rng.normal(size=(a.batch, 1))
    W1 = rng.normal(size=(16, a.hidden)) * 0.3; W2 = rng.normal(size=(a.hidden, 1)) * 0.3

    # 1) 梯度正确性：和 torch 对照
    w1, w2 = T(W1, name="W1"), T(W2, name="W2")
    loss = (T(X) @ w1).relu().__matmul__(w2).mse(Y)
    loss.backward()
    tw1 = torch.tensor(W1, requires_grad=True); tw2 = torch.tensor(W2, requires_grad=True)
    tl = ((torch.relu(torch.tensor(X) @ tw1) @ tw2 - torch.tensor(Y)) ** 2).mean()
    tl.backward()
    print("== 与 torch.autograd 对照 ==")
    print(f"  loss: mini={loss.data:.6f} torch={tl.item():.6f}")
    print(f"  max|dW1 差| = {np.abs(w1.grad - tw1.grad.numpy()).max():.2e}")
    print(f"  max|dW2 差| = {np.abs(w2.grad - tw2.grad.numpy()).max():.2e}")

    # 2) 观察 torch 为反向保存了什么
    print("\n== torch 为反向保存的张量（saved_tensors_hooks）==")
    saved = []
    with torch.autograd.graph.saved_tensors_hooks(lambda t: saved.append(t) or t, lambda t: t):
        h = torch.relu(torch.tensor(X) @ tw1)
        out = ((h @ tw2 - torch.tensor(Y)) ** 2).mean()
    for t in saved:
        print(f"  shape={tuple(t.shape)!s:10s} dtype={t.dtype} bytes={t.numel() * t.element_size()}")
    print(f"  合计 {sum(t.numel() * t.element_size() for t in saved)} 字节；参数本身 "
          f"{(W1.size + W2.size) * 8} 字节")

    # 3) 用 mini autograd 训练几步
    print("\n== 用 mini autograd 训练 ==")
    for s in range(a.steps):
        w1, w2 = T(W1), T(W2)
        loss = (T(X) @ w1).relu().__matmul__(w2).mse(Y)
        loss.backward()
        W1 -= 0.05 * w1.grad; W2 -= 0.05 * w2.grad
        if s % max(1, a.steps // 5) == 0 or s == a.steps - 1:
            print(f"  step {s:3d} loss={loss.data:.4f}")
    print("\n[小结] 反向传播要用到前向的中间结果，所以训练显存≈参数+梯度+优化器状态+激活值。"
          "\n       激活值随 batch×seq 线性增长，是激活重计算（M04-L03）的动机。"
          "\n[问题库] P14 训练显存墙")


if __name__ == "__main__":
    main()
