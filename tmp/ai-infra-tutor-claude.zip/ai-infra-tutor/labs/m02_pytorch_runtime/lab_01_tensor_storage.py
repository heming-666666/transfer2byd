"""[M02-L01] 张量 = 存储(Storage) + 视图元数据(shape/stride/offset)

目标：理解 view / transpose / contiguous 的本质，知道何时会发生隐式拷贝；
      观察"框架开销区"：张量很小时，耗时由算子分发而非计算决定。
先预测：
  1. x.t() 之后 is_contiguous() 是什么？x.t().contiguous() 会不会分配新内存？
  2. 对 10 个元素做 add 和对 1000 万个元素做 add，单次耗时差多少倍？为什么不是 100 万倍？
可调参数：--sizes（开销测试的张量大小）、--reps
暴露的问题：小算子被框架开销主导（overhead-bound） → PROBLEM_BANK P11
对应论文：PyTorch（NeurIPS'19）；Making Deep Learning Go Brrrr（Horace He 博客，二手来源）
真实框架对照：PyTorch c10/core/TensorImpl.h（sizes/strides/storage_offset 字段），
              aten/src/ATen/native/TensorShape.cpp（view/transpose 的实现）
"""
import argparse
import time

import torch


def describe(name, t):
    print(f"  {name:22s} shape={tuple(t.shape)!s:12s} stride={t.stride()!s:10s} "
          f"offset={t.storage_offset():2d} contiguous={t.is_contiguous()!s:5s} "
          f"data_ptr={t.untyped_storage().data_ptr() % 100000:5d}")


def storage_demo():
    print("== 视图共享存储 ==")
    x = torch.arange(12, dtype=torch.float32).reshape(3, 4)
    describe("x", x)
    describe("x.t()", x.t())
    describe("x[1:, ::2]", x[1:, ::2])
    describe("x.t().contiguous()", x.t().contiguous())
    y = x.view(4, 3)
    y[0, 0] = 100.0
    print(f"  改 y[0,0] 后 x[0,0] = {x[0, 0].item()}（共享存储，所以被改了）")
    try:
        x.t().view(12)
    except RuntimeError as e:
        print(f"  x.t().view(12) 报错：{str(e)[:70]}...")
    print("  x.t().reshape(12) 可以：reshape 在需要时会自动拷贝")


def overhead_demo(sizes, reps):
    print("\n== 框架开销 vs 计算：单次 add 耗时 ==")
    print(f"  {'元素数':>10s} {'单次(us)':>10s} {'ns/元素':>10s}  判断")
    floor = None
    for n in sizes:
        a, b = torch.randn(n), torch.randn(n)
        for _ in range(10):
            a + b
        t0 = time.perf_counter()
        for _ in range(reps):
            a + b
        dt = (time.perf_counter() - t0) / reps
        floor = floor or dt                          # 最小张量的耗时 ≈ 固定开销
        regime = "开销主导" if dt < 2 * floor else ("过渡（数据仍在缓存）" if n * 12 < 32 * 2 ** 20 else "带宽主导")
        print(f"  {n:10d} {dt * 1e6:10.2f} {dt / n * 1e9:10.3f}  {regime}")


def copy_cost_demo():
    print("\n== 非连续张量的隐式拷贝代价 ==")
    x = torch.randn(4096, 4096)
    for name, fn in [("x.contiguous()（已连续，无拷贝）", lambda: x.contiguous()),
                     ("x.t().contiguous()（转置后拷贝）", lambda: x.t().contiguous()),
                     ("x.t() @ v（matmul 可直接处理转置）", lambda: x.t() @ torch.ones(4096))]:
        fn()
        t0 = time.perf_counter()
        for _ in range(5):
            fn()
        print(f"  {name:40s} {(time.perf_counter() - t0) / 5 * 1e3:8.2f} ms")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", type=int, nargs="+", default=[10, 1000, 100_000, 10_000_000])
    ap.add_argument("--reps", type=int, default=200)
    a = ap.parse_args()
    storage_demo()
    overhead_demo(a.sizes, a.reps)
    copy_cost_demo()
    print("\n[小结] 小张量的耗时几乎与大小无关，说明时间花在 Python→C++ 分发、类型推导、"
          "\n       内存分配上。GPU 上还要加上 kernel launch（约数 us）。CUDA Graphs、算子融合、"
          "\n       torch.compile 都是在消除这类开销。"
          "\n[问题库] P11 框架/launch 开销导致 GPU 空闲")


if __name__ == "__main__":
    main()
