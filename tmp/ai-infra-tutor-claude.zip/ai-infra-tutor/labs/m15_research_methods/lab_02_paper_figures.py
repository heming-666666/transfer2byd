"""[M15-L02] 系统论文的标准图表：吞吐-延迟曲线、延迟 CDF、时间分解堆叠柱状图、消融表

目标：用一个可复现的小型调度模拟器生成数据，画出系统论文最常见的三类图，并输出 CSV 原始数据与消融表；
      学会"一张图回答一个问题"：曲线看取舍、CDF 看尾部、分解看瓶颈、消融看每个设计的贡献。
先预测：吞吐-延迟曲线上，"拐点"出现在什么位置？两种调度的曲线会交叉吗？
可调参数：--out（输出目录，默认系统临时目录下的 ai-infra-tutor-figures）、--n
说明：图中文字用英文，避免环境缺少中文字体时出现方块；若未安装 matplotlib，只输出 CSV。
暴露的问题：图表要支撑论点、数据要可复现 → PROBLEM_BANK P29
对应论文：DistServe、Sarathi-Serve、vLLM 的评测章节（可对照它们的图表结构）
"""
import argparse
import csv
import os
import random
import tempfile


def simulate(rate, budget, n, seed=0):
    """极简单卡调度模拟：返回每个请求的 (TTFT, TPOT)，以及时间分解（prefill/decode/idle 秒）。"""
    rng = random.Random(seed)
    t, arr = 0.0, []
    for _ in range(n):
        t += rng.expovariate(rate); arr.append((t, rng.randint(128, 2048), rng.randint(32, 256)))
    now, i, run, res, br = 0.0, 0, [], [], {"prefill": 0.0, "decode": 0.0, "overhead": 0.0, "idle": 0.0}
    while i < len(arr) or run:
        if not run and arr[i][0] > now:
            br["idle"] += arr[i][0] - now; now = arr[i][0]
        while i < len(arr) and arr[i][0] <= now:
            run.append({"arr": arr[i][0], "P": arr[i][1], "O": arr[i][2], "done": 0, "gen": 0, "first": None})
            i += 1
        dec = [r for r in run if r["done"] >= r["P"]]
        room, pre = budget - len(dec), 0
        for r in run:
            if r["done"] < r["P"] and room > 0:
                c = min(room, r["P"] - r["done"]); r["done"] += c; room -= c; pre += c
        br["prefill"] += 0.00003 * pre; br["decode"] += 0.00004 * len(dec); br["overhead"] += 0.005
        now += 0.005 + 0.00003 * pre + 0.00004 * len(dec)    # 迭代耗时模型同 M11-L02
        for r in run:
            if r in dec:
                r["gen"] += 1
            elif r["done"] >= r["P"]:                     # 本次迭代刚完成 prefill，产出第一个 token
                r["first"] = now; r["gen"] = 1
        for r in [r for r in run if r["first"] is not None and r["gen"] >= r["O"]]:
            res.append((r["first"] - r["arr"], (now - r["first"]) / max(1, r["O"] - 1)))
            run.remove(r)
    return res, br


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(tempfile.gettempdir(), "ai-infra-tutor-figures"))
    ap.add_argument("--n", type=int, default=300)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    rates = [2, 4, 6, 8, 10, 12, 14]
    rows = []
    for budget in [256, 2048]:
        for r in rates:
            res, br = simulate(r, budget, a.n)
            ttft = sorted(x[0] for x in res); tpot = sorted(x[1] for x in res)
            rows.append({"budget": budget, "rate": r, "ttft_p50": ttft[len(ttft) // 2], "ttft_p99": ttft[int(.99 * len(ttft))],
                         "tpot_p50": tpot[len(tpot) // 2], "tpot_p99": tpot[int(.99 * len(tpot))], **br})
    path = os.path.join(a.out, "throughput_latency.csv")
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"== 原始数据已写入 {path} ==")
    print(f"  {'budget':>6s} {'rate':>4s} {'TTFT p99(s)':>11s} {'TPOT p99(ms)':>12s}")
    for r in rows:
        print(f"  {r['budget']:6d} {r['rate']:4d} {r['ttft_p99']:11.3f} {r['tpot_p99'] * 1e3:12.2f}")

    print("\n== 消融/敏感性表（rate=14，接近饱和）：逐个打开设计，看每项贡献 ==")
    for name, b in [("基线：budget=8192（近似整段 prefill）", 8192), ("+ 分块 prefill（budget=1024）", 1024),
                    ("+ 更小的块（budget=256）", 256)]:
        res, _ = simulate(14, b, a.n)
        tp = sorted(x[1] for x in res); tt = sorted(x[0] for x in res)
        print(f"  {name:36s} TPOT p99 {tp[int(.99 * len(tp))] * 1e3:6.2f}ms   TTFT p99 {tt[int(.99 * len(tt))]:6.3f}s")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("\n  未安装 matplotlib：只输出 CSV。安装 env/requirements-cpu.txt 后可生成图片。")
        return
    fig, ax = plt.subplots(1, 3, figsize=(14, 4))
    for b, style in [(256, "o-"), (2048, "s--")]:
        sel = [r for r in rows if r["budget"] == b]
        ax[0].plot([r["rate"] for r in sel], [r["tpot_p99"] * 1e3 for r in sel], style, label=f"chunk budget={b}")
    ax[0].set_xlabel("request rate (req/s)"); ax[0].set_ylabel("P99 TPOT (ms)"); ax[0].legend(); ax[0].set_title("Throughput vs latency")
    for b, style in [(256, "-"), (2048, "--")]:
        res, _ = simulate(10, b, a.n)
        xs = sorted(x[0] for x in res)
        ax[1].plot(xs, [i / len(xs) for i in range(len(xs))], style, label=f"budget={b}")
    ax[1].set_xlabel("TTFT (s)"); ax[1].set_ylabel("CDF"); ax[1].legend(); ax[1].set_title("TTFT CDF @ 10 req/s")
    sel = [r for r in rows if r["budget"] == 256]
    bottom = [0] * len(sel)
    for k in ["prefill", "decode", "overhead", "idle"]:
        vals = [r[k] for r in sel]
        ax[2].bar([str(r["rate"]) for r in sel], vals, bottom=bottom, label=k)
        bottom = [x + y for x, y in zip(bottom, vals)]
    ax[2].set_xlabel("request rate"); ax[2].set_ylabel("GPU time (s)"); ax[2].legend(); ax[2].set_title("Time breakdown")
    fig.tight_layout()
    png = os.path.join(a.out, "figures.png")
    fig.savefig(png, dpi=120)
    print(f"\n  图已保存：{png}")
    print("\n[小结] 吞吐-延迟曲线展示取舍与拐点，CDF 展示尾部，分解图说明瓶颈在哪；消融/敏感性表要如实呈现取舍"
          "\n       （本例中更小的块改善 TPOT 却恶化 TTFT，且改善并不单调）。"
          "\n       每张图都要能被一个脚本从原始数据重新生成——这就是可复现性。"
          "\n[问题库] P29 benchmark 方法学与可复现性")


if __name__ == "__main__":
    main()
