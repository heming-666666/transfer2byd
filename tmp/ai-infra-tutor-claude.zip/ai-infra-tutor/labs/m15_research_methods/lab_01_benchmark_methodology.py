"""[M15-L01] Benchmark 方法学：预热、重复、方差、A/A 测试与 bootstrap 置信区间

目标：用真实计时演示系统论文里常见的测量陷阱：首次运行偏慢、单次测量的噪声、均值被离群点拉偏；
      用 A/A 测试（同一个函数比较两次）估计"噪声能制造多大的假差异"，再用 bootstrap 置信区间判断
      A/B 的差异是否可信；最后给出报告模板。
先预测：
  1. 同一个函数测两次，单次测量的"加速比"可能偏离 1.0 多少？
  2. 报告均值还是中位数？什么时候两者差别大？
可调参数：--n（矩阵规模）、--reps、--boot
暴露的问题：不可复现、不可比较的性能数字 → PROBLEM_BANK P29
对应论文：Hoefler & Belli, "Scientific Benchmarking of Parallel Computing Systems"（SC'15，二手引用，见 SOURCES）；
          MLPerf 的测量规则；各系统论文附录中的实验设置
"""
import argparse
import random
import statistics
import time

import torch


def timeit(fn, reps, warmup):
    for _ in range(warmup):
        fn()
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(); ts.append(time.perf_counter() - t0)
    return ts


def interleaved(fa, fb, reps, warmup, rng):
    """A、B 随机交错测量：让漂移（频率变化、其他进程、温度）同等地影响两边。"""
    for _ in range(warmup):
        fa(); fb()
    ta, tb = [], []
    for _ in range(reps):
        order = [(fa, ta), (fb, tb)]
        rng.shuffle(order)
        for fn, out in order:
            t0 = time.perf_counter(); fn(); out.append(time.perf_counter() - t0)
    return ta, tb


def bootstrap_ratio_ci(a, b, boot, rng):
    """中位数之比 median(a)/median(b) 的 95% bootstrap 置信区间。"""
    rs = []
    for _ in range(boot):
        sa = [rng.choice(a) for _ in a]; sb = [rng.choice(b) for _ in b]
        rs.append(statistics.median(sa) / statistics.median(sb))
    rs.sort()
    return rs[int(0.025 * boot)], rs[int(0.975 * boot)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=384)
    ap.add_argument("--reps", type=int, default=40)
    ap.add_argument("--boot", type=int, default=2000)
    a = ap.parse_args()
    rng = random.Random(0)
    torch.manual_seed(0)
    x = torch.randn(a.n, a.n)
    f_a = lambda: (x @ x).relu_()                           # 实现 A
    f_b = lambda: torch.clamp_min(torch.mm(x, x), 0)        # 实现 B：数学等价，开销略有不同

    print("== 1. 首次运行效应（冷启动：内存分配、线程池、缓存）==")
    y = torch.randn(a.n + 1, a.n + 1)                       # 新形状，避免复用之前的分配
    cold = timeit(lambda: y @ y, reps=5, warmup=0)
    print("  前 5 次耗时(ms)：" + ", ".join(f"{t * 1e3:.3f}" for t in cold))

    print("\n== 2. A/A 测试：同一个函数测两组，噪声和漂移能制造多大的'加速' ==")
    a1, a2 = timeit(f_a, a.reps, 5), timeit(f_a, a.reps, 5)
    single = [a1[i] / a2[i] for i in range(min(10, a.reps))]
    print("  (a) 先测完一组再测另一组；逐次配对的'加速比'：" + ", ".join(f"{r:.2f}" for r in single))
    lo, hi = bootstrap_ratio_ci(a1, a2, a.boot, rng)
    ok = "包含 1，未见系统偏差" if lo <= 1 <= hi else "不包含 1 → 存在顺序/漂移效应，先后测量不可信！"
    print(f"      中位数之比 {statistics.median(a1) / statistics.median(a2):.3f}，95% CI [{lo:.3f}, {hi:.3f}]：{ok}")
    b1, b2 = interleaved(f_a, f_a, a.reps, 5, rng)
    lo, hi = bootstrap_ratio_ci(b1, b2, a.boot, rng)
    ok = "包含 1" if lo <= 1 <= hi else "仍不包含 1（噪声很大，需增加重复次数或独占机器）"
    print(f"  (b) 随机交错测量：中位数之比 {statistics.median(b1) / statistics.median(b2):.3f}，"
          f"95% CI [{lo:.3f}, {hi:.3f}]：{ok}")
    print(f"  均值 {statistics.mean(a1) * 1e3:.3f}ms vs 中位数 {statistics.median(a1) * 1e3:.3f}ms，"
          f"最大值 {max(a1) * 1e3:.3f}ms（离群点会拉高均值）")

    print("\n== 3. A/B（随机交错测量）：两个实现，差异是否显著 ==")
    ta, tb = interleaved(f_a, f_b, a.reps, 5, rng)
    lo, hi = bootstrap_ratio_ci(tb, ta, a.boot, rng)
    ratio = statistics.median(tb) / statistics.median(ta)
    verdict = "显著" if (lo > 1 or hi < 1) else "不显著（置信区间包含 1）"
    print(f"  B/A 中位数耗时比 {ratio:.3f}，95% CI [{lo:.3f}, {hi:.3f}] → {verdict}")
    print(f"  A: 中位数 {statistics.median(ta) * 1e3:.3f}ms，IQR "
          f"[{sorted(ta)[a.reps // 4] * 1e3:.3f}, {sorted(ta)[3 * a.reps // 4] * 1e3:.3f}]")

    print("\n== 4. 线程数这类'环境变量'会改变结论 ==")
    for th in [1, torch.get_num_threads()]:
        torch.set_num_threads(th)
        t1, t2 = timeit(f_a, 15, 3), timeit(f_b, 15, 3)
        print(f"  threads={th:2d}: A {statistics.median(t1) * 1e3:.3f}ms  B {statistics.median(t2) * 1e3:.3f}ms")

    print("\n== 报告模板（写进论文的实验设置）==")
    print(f"  硬件/软件：CPU 线程数、torch {torch.__version__}、输入规模 n={a.n}；预热 5 次、重复 {a.reps} 次；"
          "\n  报告中位数与 IQR/95% CI；说明是否固定频率、是否独占机器；给出复现脚本与原始数据。")
    print("\n[小结] 单次测量的'加速'可能完全来自噪声或漂移；先做 A/A 测试确定噪声底，交错测量消除顺序效应，"
          "\n       再用置信区间判断差异。"
          "\n       冷启动、线程数、频率、其他进程都会改变结果——系统论文的实验设置必须把这些写清楚。"
          "\n[问题库] P29 benchmark 方法学")


if __name__ == "__main__":
    main()
