"""[M12-L03] KV Cache 压缩：驱逐（StreamingLLM / H2O）与量化（KIVI 式）的精度-内存取舍

目标：在带"注意力汇聚点（attention sink）"、"局部性"和"少数重要 token"的合成注意力上，比较：
      仅保留最近窗口、StreamingLLM（sink + 窗口）、H2O（累计注意力最高的 heavy hitter + 窗口）、
      以及 2bit KV 量化（Key 按通道、Value 按 token，KIVI 的做法）对注意力输出的误差。
先预测：
  1. 只保留 25% 的 KV，仅用最近窗口和加上 4 个 sink token，误差差多少？
  2. Key 按 token 量化和按通道量化，哪个误差小？为什么？
可调参数：--n（上下文长度）、--d、--budget（保留比例列表）、--steps（decode 步数）
暴露的问题：KV 压缩的精度损失难以预测、与 PagedAttention/前缀缓存的集成困难 → PROBLEM_BANK P10
对应论文：StreamingLLM（2309.17453）；H2O（2306.14048）；SnapKV；KIVI（2402.02750）；Quest
说明：注意力模式是人为构造的（sink、局部、重要 token 都是注入的），用来演示各方法的假设何时成立。
      真实模型上的结论需在真实注意力上验证——这正是一个可做的研究练习。
"""
import argparse
import math

import torch


def make_data(n, d, steps, seed=0):
    """构造有结构的注意力（分数 = q·k/√d）：
    - sink：前 4 个 token 在 sink 方向上很大，query 也有该分量 → 约占 30% 注意力；
    - 重要 token：随机 2% 的 token 在另一方向上较大 → 约占 25%；
    - 局部性：位置编码为缓慢旋转的二维向量，距离越近分数加成越大（约 256 token 后衰减到 0）；
    - Key 通道离群：4 个固定通道在所有 token 上都有大偏移（KIVI 观察到的现象）。"""
    g = torch.Generator().manual_seed(seed)
    L = n + steps
    K = torch.randn(L, d, generator=g); V = torch.randn(L, d, generator=g)
    Q = torch.randn(steps, d, generator=g)
    e = torch.eye(d)
    sink, imp, r1, r2 = e[8], e[9], e[10], e[11]           # 互相正交的方向
    K[:4] += 8 * sink; Q += 7.6 * sink
    idx = torch.randperm(n, generator=g)[: n // 50] + 4
    K[idx] += 6 * imp; Q += 6.3 * imp
    w = math.pi / (2 * 256)
    pos = torch.arange(L, dtype=torch.float32)
    K += 5 * (torch.cos(pos * w)[:, None] * r1 + torch.sin(pos * w)[:, None] * r2)
    tq = torch.arange(n, L, dtype=torch.float32) + 1
    Q += 5.2 * (torch.cos(tq * w)[:, None] * r1 + torch.sin(tq * w)[:, None] * r2)
    K[:, :4] += 10.0                                        # 通道离群：对所有 key 加同一偏移，softmax 结果不变，但会拉大量化范围
    return Q, K, V


def attend(q, K, V):
    w = torch.softmax(K @ q / math.sqrt(q.shape[0]), dim=0)
    return w @ V, w


def quant(x, bits, dim, group=32):
    """分组非对称（min-max）量化。dim=0：按通道，每 group 个 token 一组（KIVI 对 Key 的做法）；
    dim=1：按 token，每 group 个通道一组（KIVI 对 Value 的做法）。"""
    L, d = x.shape
    if dim == 0:
        xg = x.reshape(L // group, group, d); ax = 1
    else:
        xg = x.reshape(L, d // group, group); ax = 2
    lo, hi = xg.amin(dim=ax, keepdim=True), xg.amax(dim=ax, keepdim=True)
    s = (hi - lo).clamp(min=1e-8) / (2 ** bits - 1)
    return (((xg - lo) / s).round() * s + lo).reshape(L, d)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=2048)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--budget", type=float, nargs="+", default=[0.5, 0.25, 0.1])
    ap.add_argument("--steps", type=int, default=64)
    a = ap.parse_args()
    Q, K, V = make_data(a.n, a.d, a.steps)
    print(f"== 上下文 {a.n}，decode {a.steps} 步，注意力输出相对误差（越小越好）==")
    print(f"  {'方法':26s} " + " ".join(f"{'保留' + str(int(b * 100)) + '%':>9s}" for b in a.budget))
    methods = ["最近窗口", "StreamingLLM(4 sink+窗口)", "H2O(heavy hitter+窗口)"]
    for mname in methods:
        row = []
        for b in a.budget:
            errs, acc = [], torch.zeros(a.n + a.steps)
            for t in range(a.steps):
                L = a.n + t + 1
                q, Kt, Vt = Q[t], K[:L], V[:L]
                ref, w = attend(q, Kt, Vt)
                keep_n = int(b * L)
                if mname == "最近窗口":
                    keep = torch.arange(L - keep_n, L)
                elif mname.startswith("Streaming"):
                    keep = torch.cat([torch.arange(4), torch.arange(L - keep_n + 4, L)])
                else:                                       # H2O：一半预算给累计注意力最高者，一半给最近窗口
                    recent = torch.arange(L - keep_n // 2, L)
                    score = acc[:L].clone(); score[recent] = -1
                    keep = torch.cat([score.topk(keep_n - len(recent)).indices, recent])
                out, _ = attend(q, Kt[keep], Vt[keep])
                errs.append(((out - ref).norm() / ref.norm()).item())
                acc[:L] += w                                # H2O 用"看到当前为止"的累计注意力
            row.append(sum(errs) / len(errs))
        print(f"  {mname:26s} " + " ".join(f"{e:9.4f}" for e in row))

    print("\n== 2bit / 4bit KV 量化（保留全部 token）==")
    L = a.n + a.steps
    for bits in [4, 2]:
        for name, kd, vd, resid in [("K 按 token、V 按 token", 1, 1, 0), ("K 按通道、V 按 token (KIVI)", 0, 1, 0),
                                    ("KIVI + 最近128个全精度", 0, 1, 128)]:   # 分组大小 32
            Kq, Vq = quant(K[:L], bits, kd), quant(V[:L], bits, vd)
            if resid:
                Kq[-resid:], Vq[-resid:] = K[L - resid:L], V[L - resid:L]
            errs = []
            for t in range(a.steps):
                ref, _ = attend(Q[t], K[:L], V[:L]); out, _ = attend(Q[t], Kq, Vq)
                errs.append(((out - ref).norm() / ref.norm()).item())
            print(f"  {bits}bit {name:26s} 误差 {sum(errs) / len(errs):.4f}  KV 体积约为 FP16 的 {bits / 16:.0%}")
    print("\n[小结] 方法的好坏取决于它的假设是否符合注意力模式：sink 存在时 StreamingLLM 远好于纯窗口；重要 token"
          "\n       分散在远处时，按累计注意力保留的 H2O 更好。量化方面：4bit 时 Key 按通道分组（KIVI）更好；2bit 时在这份"
          "\n       合成数据上反而更差——query 在少数结构化方向上的分量很大，会放大这些方向上 Key 的量化误差。"
          "\n       结论依赖真实的 K/Q 分布，需要在真实模型的注意力上重测（见 exercises.md 的 L4 题）。"
          "\n       系统层面的难点：驱逐与分页块、前缀共享冲突；量化需要专门的 attention kernel。"
          "\n[问题库] P10 KV Cache 压缩的精度-内存取舍与系统集成")


if __name__ == "__main__":
    main()
