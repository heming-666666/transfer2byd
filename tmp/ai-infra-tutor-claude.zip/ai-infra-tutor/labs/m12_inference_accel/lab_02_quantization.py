"""[M12-L02] LLM 量化：激活离群值、LLM.int8() 分解、SmoothQuant 平滑、分组 INT4 与 AWQ 式缩放

目标：在带"离群通道"的合成激活上，比较多种量化方案对矩阵乘输出的相对误差与权重显存；
      理解为什么 LLM 的 W8A8 难、weight-only INT4 为什么流行、SmoothQuant/AWQ 各自在"搬运难度"。
先预测：
  1. 激活中 1% 的通道幅值是其他通道的 50 倍，per-tensor INT8 激活量化的误差会怎样？
  2. SmoothQuant 的迁移强度 α 从 0 调到 1，误差先降后升还是单调？
可调参数：--tokens、--din、--dout、--outlier（离群倍数）、--frac（离群通道比例）
暴露的问题：激活离群值让低比特激活量化困难 → PROBLEM_BANK P09
对应论文：LLM.int8()（2208.07339）；SmoothQuant（2211.10438）；GPTQ（2210.17323）；AWQ（2306.00978）；QServe
真实框架对照：mit-han-lab/llm-awq awq/quantize/auto_scale.py；pytorch/ao（torchao 量化 API）
说明：数据是合成的（随机权重 + 人为注入的离群通道），用来复现论文中的现象，不代表具体模型的数值。
"""
import argparse

import torch


def q_sym(x, bits, dim=None, group=None):
    """对称均匀量化后反量化。dim=None 为 per-tensor；dim=k 表示沿该维取 max（per-channel/per-token）。"""
    qmax = 2 ** (bits - 1) - 1
    if group:                                              # 沿输入维分组（weight-only INT4 常用 g=128）
        shp = x.shape
        xg = x.reshape(shp[0], -1, group)
        s = xg.abs().amax(-1, keepdim=True).clamp(min=1e-8) / qmax
        return ((xg / s).round().clamp(-qmax, qmax) * s).reshape(shp)
    s = (x.abs().max() if dim is None else x.abs().amax(dim=dim, keepdim=True)).clamp(min=1e-8) / qmax
    return (x / s).round().clamp(-qmax, qmax) * s


def rel(y, ref):
    return ((y - ref).norm() / ref.norm()).item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tokens", type=int, default=256)
    ap.add_argument("--din", type=int, default=1024)
    ap.add_argument("--dout", type=int, default=1024)
    ap.add_argument("--outlier", type=float, default=50.0)
    ap.add_argument("--frac", type=float, default=0.01)
    a = ap.parse_args()
    torch.manual_seed(0)
    X = torch.randn(a.tokens, a.din)
    out_ch = torch.randperm(a.din)[: max(1, int(a.frac * a.din))]
    X[:, out_ch] *= a.outlier                              # 离群通道：在所有 token 上都大（LLM.int8 论文的观察）
    W = torch.randn(a.din, a.dout) / a.din ** 0.5          # Y = X @ W，W 的行对应输入通道
    Y = X @ W
    print(f"== X: {a.tokens}×{a.din}（{len(out_ch)} 个离群通道 ×{a.outlier}），W: {a.din}×{a.dout} ==")
    res = {}
    res["W8A8 per-tensor"] = rel(q_sym(X, 8) @ q_sym(W, 8), Y)
    res["W8(per-out-ch) A8(per-token)"] = rel(q_sym(X, 8, dim=1) @ q_sym(W, 8, dim=0), Y)
    # LLM.int8()：离群通道（|x|>6）保留高精度，其余走 INT8
    mask = (X.abs() > 6).any(0)
    y_int8 = q_sym(X[:, ~mask], 8, dim=1) @ q_sym(W[~mask], 8, dim=0) + X[:, mask] @ W[mask]
    res[f"LLM.int8() 分解（{int(mask.sum())} 个通道走 FP16）"] = rel(y_int8, Y)
    for alpha in [0.0, 0.25, 0.5, 0.75, 1.0]:              # SmoothQuant：s_j = max|X_j|^α / max|W_j|^(1-α)
        s = X.abs().amax(0).pow(alpha) / W.abs().amax(1).pow(1 - alpha).clamp(min=1e-5)
        res[f"SmoothQuant α={alpha:.2f} + W8A8 per-tensor"] = rel(q_sym(X / s, 8) @ q_sym(W * s[:, None], 8), Y)
    res["W4 per-out-ch（weight-only，激活 FP16）"] = rel(X @ q_sym(W, 4, dim=0), Y)
    res["W4 group=128（weight-only）"] = rel(X @ q_sym(W.T, 4, group=128).T, Y)
    # AWQ 式：按激活幅值放大重要输入通道再量化权重，搜索指数 α（真实 AWQ 在校准集上逐层搜索）
    best = (9e9, 0)
    act = X.abs().mean(0)
    for alpha in [i / 10 for i in range(11)]:
        s = act.pow(alpha).clamp(min=1e-4); s = s / s.mean()
        e = rel((X / s) @ q_sym((W * s[:, None]).T, 4, group=128).T, Y)
        best = min(best, (e, alpha))
    res[f"AWQ 式缩放 + W4 group=128（最佳 α={best[1]:.1f}）"] = best[0]
    for k, v in res.items():
        print(f"  {k:44s} 相对误差 {v:8.4f}")
    nbytes = a.din * a.dout
    print(f"\n  权重显存：FP16 {2 * nbytes / 2 ** 20:.1f}MB，INT8 {nbytes / 2 ** 20:.1f}MB，"
          f"INT4(g128，含 FP16 scale) {(nbytes / 2 + nbytes / 128 * 2) / 2 ** 20:.2f}MB")
    print("\n[小结] 离群通道让 per-tensor 激活量化崩溃；LLM.int8() 用混合精度分解绕开，但 kernel 不规整、速度受损；"
          "\n       SmoothQuant 把量化难度从激活'搬'到权重，α 适中时最好；decode 访存受限，所以只压权重的 W4 方案"
          "\n       直接减少读取字节、最受欢迎，AWQ 通过保护重要通道进一步降误差。"
          "\n[问题库] P09 激活离群值与低比特量化")


if __name__ == "__main__":
    main()
