"""[M12-L01] 投机解码（speculative decoding）：拒绝采样保证无偏 + 加速比模型 + 大 batch 下的收益衰减

目标：实现 Leviathan et al. / Chen et al. 的投机采样（draft 提议 γ 个 token，target 并行验证，
      按 min(1, p/q) 接受，被拒时从 norm(max(0, p-q)) 重采样）；用大量采样验证输出分布与 target 一致；
      用实测接受率 α 计算期望每次验证产出的 token 数 (1-α^(γ+1))/(1-α)，并分析 batch 增大后收益为何下降。
先预测：
  1. 接受率 α=0.8、γ=4、draft 成本是 target 的 5%，理论加速比是多少？
  2. batch 从 1 增大到 128，投机解码的加速比会怎样？为什么？
可调参数：--vocab、--noise（draft 与 target 的差异）、--gamma（列表）、--samples
暴露的问题：投机解码在高并发下收益下降；draft 选择与 γ 自适应 → PROBLEM_BANK P08
对应论文：Fast Inference from Transformers via Speculative Decoding（2211.17192）；
          Accelerating LLM Decoding with Speculative Sampling（2302.01318）；Medusa；EAGLE-1/2/3
真实框架对照：vllm-project/vllm vllm/v1/sample/rejection_sampler.py；vllm/v1/spec_decode/
"""
import argparse

import numpy as np


class ToyLM:
    """一阶马尔可夫"语言模型"：p(next | prev) = softmax(T[prev] / temp)。"""

    def __init__(self, T, temp=1.0):
        self.T, self.temp = T, temp

    def probs(self, prev):
        z = self.T[prev] / self.temp
        e = np.exp(z - z.max())
        return e / e.sum()


def speculative_step(target, draft, prev, gamma, rng):
    """一次"draft 提议 γ 个 + target 验证"，返回产出的 token 列表（至少 1 个）。"""
    toks, qs, ctx = [], [], prev
    for _ in range(gamma):                                  # draft 自回归提议
        q = draft.probs(ctx); t = rng.choice(len(q), p=q)
        toks.append(t); qs.append(q); ctx = t
    out, ctx = [], prev
    for t, q in zip(toks, qs):                              # target 并行算出每个位置的 p（这里逐个算，等价）
        p = target.probs(ctx)
        if rng.random() < min(1.0, p[t] / q[t]):
            out.append(t); ctx = t
        else:
            resid = np.maximum(p - q, 0); resid /= resid.sum()
            out.append(rng.choice(len(p), p=resid))         # 被拒：从残差分布重采样，保证无偏
            return out
    out.append(rng.choice(len(p := target.probs(ctx)), p=p))  # 全部接受：额外白送一个 target token
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vocab", type=int, default=50)
    ap.add_argument("--noise", type=float, nargs="+", default=[0.5, 1.0, 2.0])
    ap.add_argument("--gamma", type=int, nargs="+", default=[1, 2, 4, 8])
    ap.add_argument("--samples", type=int, default=20000)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    T = rng.normal(0, 2, size=(a.vocab, a.vocab))
    target = ToyLM(T)

    print("== 1. 无偏性验证：第一个产出 token 的分布 vs target 分布 ==")
    draft = ToyLM(T + rng.normal(0, 1.0, size=T.shape))
    counts = np.zeros(a.vocab)
    for _ in range(a.samples):
        counts[speculative_step(target, draft, 0, 4, rng)[0]] += 1
    p = target.probs(0)
    tv = 0.5 * np.abs(counts / a.samples - p).sum()
    q = draft.probs(0)
    print(f"  总变差距离 TV(经验, target) = {tv:.4f}（采样噪声量级 ≈ {np.sqrt(a.vocab / a.samples) / 2:.4f}）；"
          f"若直接用 draft 采样 TV = {0.5 * np.abs(q - p).sum():.4f}")

    print("\n== 2. 接受率与每次验证产出的 token 数 ==")
    print(f"  {'draft噪声':>8s} {'α(实测)':>8s} " + " ".join(f"{'γ=' + str(g):>14s}" for g in a.gamma))
    for nz in a.noise:
        draft = ToyLM(T + rng.normal(0, nz, size=T.shape))
        alpha = np.mean([np.minimum(target.probs(s), draft.probs(s)).sum() for s in range(a.vocab)])
        cells = []
        for g in a.gamma:
            prev, made, calls = 0, 0, 0
            while made < 3000:
                out = speculative_step(target, draft, prev, g, rng)
                made += len(out); calls += 1; prev = out[-1]
            theo = (1 - alpha ** (g + 1)) / (1 - alpha)
            cells.append(f"{made / calls:5.2f}(理论{theo:4.2f})")
        print(f"  {nz:8.1f} {alpha:8.3f} " + " ".join(f"{c:>14s}" for c in cells))

    print("\n== 3. 加速比：draft 成本比 c，以及 batch 增大后验证不再'免费' ==")
    alpha, c = 0.8, 0.05
    N, W, BW, PEAK = 8e9, 16e9, 3.35e12, 989e12              # 8B target，BF16 权重 16GB，H100
    for b in [1, 16, 64, 128, 256]:
        base = max(W / BW, 2 * N * b / PEAK)                  # 普通 decode 一步
        best = (1.0, 0)
        for g in range(1, 9):
            verify = max(W / BW, 2 * N * b * (g + 1) / PEAK)  # 一次验证 γ+1 个位置
            t = g * c * base + verify
            tokens = (1 - alpha ** (g + 1)) / (1 - alpha)
            best = max(best, (tokens * base / t, g))
        print(f"  batch={b:4d}: 最佳 γ={best[1]}，加速比 {best[0]:4.2f}×"
              f"{'（验证已算力受限）' if 2 * N * b * 2 / PEAK > W / BW else ''}")
    print("\n[小结] 拒绝采样让投机解码在数学上与 target 采样同分布；收益取决于接受率 α、γ 和 draft 成本。"
          "\n       小 batch 时 decode 访存受限，验证 γ+1 个 token 几乎和验证 1 个一样贵——这是'免费午餐'的来源；"
          "\n       batch 变大后验证变成算力受限，额外的 γ 个位置不再免费，加速比趋于 1 甚至变慢。"
          "\n[问题库] P08 投机解码在大 batch 下收益下降")


if __name__ == "__main__":
    main()
