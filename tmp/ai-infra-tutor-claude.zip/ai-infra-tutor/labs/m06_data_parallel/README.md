# M06 数据并行：DDP、梯度分桶、通信与计算重叠、ZeRO 1/2/3、FSDP

- **对应任务**：D3-T06（讲义）、D3-T07~T09（L01~L03）、D3-T10（★`zero`）、D3-T11（★`ddp`）
- **先修**：M04、M05
- **预计学时**：2.3 小时
- **学习目标**：
  1. 解释数据并行（Data Parallelism, DP）为什么在数学上等价于大批量训练。
  2. 说出 PyTorch DDP 的三个关键设计：梯度分桶、反向传播中重叠通信、广播初始参数。
  3. 写出 ZeRO-1/2/3 每卡的显存与通信量，并画出 ZeRO-3 一个训练步中的通信时序。
  4. 用离散事件模拟解释“桶大小”的 U 形曲线，以及通信量超过计算量时重叠为什么失效。

## 1. 核心讲义

### 1.1 数据并行的基本形式

N 个 rank 各持一份完整模型，各自处理 1/N 的数据，反向后对梯度做 AllReduce 求平均，再各自执行相同的优化器更新。因为损失是样本平均，`∇(平均损失) = 平均(各 rank 的梯度)`，所以结果与单卡用 N 倍 batch 训练**完全一致**（L01 验证，误差约 1e-9）。

缺点：每个 rank 都存一份完整的模型状态（16Ψ 字节），模型一大就放不下；每步要 AllReduce 一次梯度（约 2Ψ 字节）。

### 1.2 PyTorch DDP 的工程设计

论文 `ddp`（VLDB'20）总结了几个关键决策：

1. **梯度分桶（bucketing）**：不逐个参数通信（大量小消息，α 开销大），也不等全部梯度算完再通信（无法重叠），而是把梯度按反向顺序装进固定大小的桶（默认 25MB），桶满就异步发起 AllReduce。
2. **与反向计算重叠**：反向从最后一层往前算，前面的层还在计算时，后面层的桶已经在通信。通信放在单独的 CUDA stream 上。
3. **其他细节**：构造时广播 rank 0 的参数，保证初始一致；处理没有参与前向的参数（`find_unused_parameters`）；用 `no_sync()` 在梯度累积时跳过通信。

### 1.3 ZeRO：消除冗余

ZeRO（Zero Redundancy Optimizer，`zero`）的观察是：数据并行中每个 rank 存的模型状态完全相同，是冗余的。把它们切成 N 份，每个 rank 只负责 1/N：

| 阶段 | 切分内容 | 每卡模型状态 | 每步通信 |
| --- | --- | --- | --- |
| DDP | 无 | 16Ψ | AllReduce 梯度：2Ψ |
| ZeRO-1 | 优化器状态 | 4Ψ + 12Ψ/N | ReduceScatter 梯度 Ψ + AllGather 参数 Ψ = 2Ψ |
| ZeRO-2 | + 梯度 | 2Ψ + 14Ψ/N | 同上，2Ψ |
| ZeRO-3 | + 参数 | 16Ψ/N | 前向 AllGather Ψ + 反向 AllGather Ψ + ReduceScatter Ψ = 3Ψ |

（通信量以“每 rank 收发的元素数”计、Ring 算法近似，系数 `(N−1)/N` 略去。）

ZeRO-1/2 **不增加通信**：本来 AllReduce = ReduceScatter + AllGather，只是把优化器更新放在两步之间、每个 rank 只更新自己那一片。ZeRO-3 多出 50% 通信，而且每一层在使用前都要先 AllGather 参数，用完就释放——能否把 AllGather 提前（prefetch）并与上一层的计算重叠，决定了它的实际速度。DeepSpeed issue #1174 记录过一个例子：ZeRO-3 的前向比 ZeRO-2 慢约 8 倍，原因就是 all-gather 频繁且没有被重叠（见 P16）。

**FSDP**（Fully Sharded Data Parallel，`fsdp`）是 PyTorch 原生的 ZeRO-3 风格实现：把模型按模块包装成“FSDP 单元”，每个单元的参数展平后分片；前向/反向前 AllGather、用后释放，反向后 ReduceScatter。FSDP2 改用 DTensor 表示分片参数（见 PyTorch 官方教程）。

### 1.4 通信与计算重叠的定量分析

反向逐层产生梯度；桶满时在通信 stream 上发起 AllReduce；通信 stream 是串行的。单步时间 ≈ `max(反向结束时间, 最后一次通信结束时间)`：

- **桶太小**：通信次数多，每次都付 α，累计起来很可观；而且大量小消息达不到带宽峰值。
- **桶太大**：要等很多层算完才发出第一次通信；最后一个桶在反向结束后才开始，完全无法被隐藏。
- **通信总量 > 计算总量**：无论怎样调桶，单步时间都至少等于通信时间——这时需要压缩通信（ZeRO++ 的量化通信）、换并行策略，或者增大每卡计算量。

## 2. 实验

### M06-L01 手写 DDP 与分桶（`lab_01_ddp_bucketing.py`）

- **先预测**：(1) 4 个 rank 各 16 条样本的 DDP，与单进程 64 条样本训练，参数会完全一样吗？(2) 50 个参数张量，逐参数 AllReduce 要通信几次？桶大小 1MB 时呢？
- **实测输出摘要**（gloo，4 进程，1.57MB 梯度）：逐参数通信 50 次，每步 52.6ms；0.25MB 桶 7 次、9.0ms；1MB 桶 2 次、3.9ms；25MB 桶 1 次、2.7ms。所有方式以及官方 DDP 与单进程训练的最大参数差都只有 7.5e-9。
- **解读**：通信时间几乎正比于通信次数——gloo 的每次调用固定开销很大，正是 α 主导的情形。
- **开发说明**：第一版把 torch 张量通过多进程队列传回主进程，子进程退出后共享内存句柄失效，主进程报 EOFError；改为传 numpy 数组（按值序列化）后解决。写多进程实验时要注意这类进程间通信的细节。
- **扫描建议**：`--layers 100 --width 64`（更多小张量）；`--bucket-mb 0 0.05 0.1 0.5 2`。
- **真实框架对照**：`torch/nn/parallel/distributed.py`；`torch/csrc/distributed/c10d/reducer.cpp`（分桶与 autograd hook）。
- **暴露的问题**：[P17](../../research/PROBLEM_BANK.md#p17)。

### M06-L02 ZeRO 模拟器（`lab_02_zero_sim.py`）

- **先预测**：(1) ZeRO-1/2 每步通信量和 DDP 相比是多少？ZeRO-3 呢？(2) N=8 时，每个 rank 的 Adam 状态是 DDP 的几分之一？
- **实测输出摘要**：8 个虚拟 rank 分片训练 10 步，与 DDP 的最大参数差为 0（因为 Adam 是逐元素运算，切片更新与整体更新完全等价）。N=8 时每卡模型状态：DDP 16Ψ，ZeRO-1 5.5Ψ，ZeRO-2 3.75Ψ，ZeRO-3 2Ψ；每步通信 DDP 与 ZeRO-1/2 都是 2Ψ，ZeRO-3 是 3Ψ。
- **思考**：如果优化器不是逐元素的（例如 Shampoo、Muon 这类需要整个矩阵的优化器），ZeRO 式的切分会遇到什么问题？（这是一个开放的研究点。）
- **真实框架对照**：deepspeedai/DeepSpeed `deepspeed/runtime/zero/stage_1_and_2.py`、`stage3.py`；PyTorch `torch/distributed/fsdp/`。
- **暴露的问题**：[P16](../../research/PROBLEM_BANK.md#p16)、[P14](../../research/PROBLEM_BANK.md#p14)。

### M06-L03 重叠模拟器（`lab_03_overlap_sim.py`）

- **先预测**：(1) 桶大小从 1MB 增到 1GB，单步时间会单调变化吗？(2) 若通信总量大于反向计算总量，单步时间至少是多少？
- **实测输出摘要**（48 层 × 每层 4 个大张量 + 6 个小张量，共 480 个梯度张量；反向 120ms，纯通信 95ms，α=200μs）：逐张量通信 480 次、单步 191.7ms；1MB 桶 134.3ms；**16MB 桶最优，121.3ms**（接近下界 120ms）；256MB 时 137.7ms；4GB 时 215.7ms。带宽降到 1/4 时，单步约 390~410ms，暴露的通信约 270~290ms。
- **开发说明**：第一版只有大张量、且通信多于计算，所有桶大小的结果几乎一样，看不出取舍；加入真实模型中常见的小张量（bias、norm 参数）、并让通信少于计算后，U 形曲线才出现——**实验设计要让被研究的效应有机会显现**。
- **扫描建议**：`--alpha-us 50 500`；`--small-per-layer 0 20`；`--bw 50 12.5`。
- **暴露的问题**：[P17](../../research/PROBLEM_BANK.md#p17)、[P16](../../research/PROBLEM_BANK.md#p16)。

## 3. 常见误区

- “ZeRO 会改变训练结果”：ZeRO 只改变状态存放的位置，数学上与 DDP 等价（L02 误差为 0）。
- “ZeRO-3 总是最好”：显存够用时 ZeRO-1/2 更快；ZeRO-3 适合模型状态放不下的情况。
- “DDP 的梯度同步在反向结束后才开始”：DDP 在反向过程中就按桶发起通信。
- “桶越大越省通信”：总字节数不变，桶太大会损失重叠。

## 4. 论文与延伸阅读

- 必读：★`ddp`（arXiv 2006.15704）、★`zero`（arXiv 1910.02054）、`fsdp`（arXiv 2304.11277）。
- 选读：`zeropp`（压缩通信）、`zerooffload`、`amsp`（降低 ZeRO 通信开销）。
- 资源：PyTorch 官方 FSDP2 教程；李沐《Zero 论文精读》（B 站）；ZOMI《DP、DDP、FSDP 数据并行原理》（B 站）；Hugging Face *Ultra-Scale Playbook* 的数据并行一章。

## 5. 自测题

Q-M06-L1-01 ~ Q-M06-L4-01；动手练习见 `exercises.md`。
