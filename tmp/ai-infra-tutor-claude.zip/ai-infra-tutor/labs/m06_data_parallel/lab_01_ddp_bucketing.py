"""[M06-L01] 手写数据并行（DDP）：梯度 AllReduce 与分桶（bucketing）

目标：用 gloo 多进程实现最小 DDP：每个 rank 算自己那份数据的梯度，AllReduce 求平均后更新；
      验证结果与单进程大批量训练一致；比较"逐参数 AllReduce"与"按桶 AllReduce"的通信次数与耗时；
      最后用官方 DistributedDataParallel 对照。
先预测：
  1. 4 个 rank 各 16 条样本的 DDP，与单进程 64 条样本训练，参数会完全一样吗？
  2. 模型有 50 个参数张量，逐参数 AllReduce 要发起多少次通信？桶大小 1MB 时呢？
可调参数：--world、--layers、--width、--bucket-mb（列表）
暴露的问题：通信次数（α 开销）与重叠时机的取舍 → PROBLEM_BANK P17
对应论文：PyTorch Distributed（VLDB'20，梯度分桶与重叠，默认桶 25MB）
真实框架对照：torch/nn/parallel/distributed.py；torch/csrc/distributed/c10d/reducer.cpp（Reducer 分桶）
"""
import argparse
import os
import tempfile
import time

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
import torch.nn as nn


def make_model(layers, width):
    torch.manual_seed(0)
    return nn.Sequential(*[m for _ in range(layers) for m in (nn.Linear(width, width), nn.Tanh())])


def make_data(n, width):
    g = torch.Generator().manual_seed(1)
    return torch.randn(n, width, generator=g), torch.randn(n, width, generator=g)


def allreduce_grads(model, world, bucket_bytes):
    """bucket_bytes=0：逐参数通信；否则把梯度拼成扁平桶再通信。返回通信次数。"""
    grads = [p.grad for p in model.parameters()][::-1]        # 反向时梯度从后往前就绪
    calls = 0
    if bucket_bytes == 0:
        for g in grads:
            dist.all_reduce(g); g /= world; calls += 1
        return calls
    bucket, size = [], 0
    for i, g in enumerate(grads):
        bucket.append(g); size += g.numel() * g.element_size()
        if size >= bucket_bytes or i == len(grads) - 1:
            flat = torch.cat([b.reshape(-1) for b in bucket])
            dist.all_reduce(flat); flat /= world; calls += 1
            off = 0
            for b in bucket:                                   # 拆回各参数
                b.copy_(flat[off:off + b.numel()].view_as(b)); off += b.numel()
            bucket, size = [], 0
    return calls


def worker(rank, world, init_file, a, q):
    os.environ.setdefault("GLOO_SOCKET_IFNAME", "lo")
    dist.init_process_group("gloo", init_method=f"file://{init_file}", rank=rank, world_size=world)
    torch.set_num_threads(1)
    X, Y = make_data(a.batch * world, a.width)
    xs, ys = X[rank::world], Y[rank::world]                    # 数据切分
    res = {}
    for bucket_mb in a.bucket_mb:
        model = make_model(a.layers, a.width)
        opt = torch.optim.SGD(model.parameters(), lr=0.05)
        t_comm = 0.0
        for _ in range(a.steps):
            opt.zero_grad()
            nn.functional.mse_loss(model(xs), ys).backward()
            t0 = time.perf_counter()
            calls = allreduce_grads(model, world, int(bucket_mb * 2 ** 20))
            t_comm += time.perf_counter() - t0
            opt.step()
        res[bucket_mb] = (calls, t_comm / a.steps, [p.detach().numpy().copy() for p in model.parameters()])
    # 官方 DDP 对照
    model = make_model(a.layers, a.width)
    ddp = nn.parallel.DistributedDataParallel(model, bucket_cap_mb=25)
    opt = torch.optim.SGD(ddp.parameters(), lr=0.05)
    for _ in range(a.steps):
        opt.zero_grad(); nn.functional.mse_loss(ddp(xs), ys).backward(); opt.step()
    res["ddp"] = [p.detach().numpy().copy() for p in model.parameters()]  # numpy 按值序列化，避免共享内存句柄失效
    if rank == 0:
        q.put(res)
    dist.destroy_process_group()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--world", type=int, default=4)
    ap.add_argument("--layers", type=int, default=25)
    ap.add_argument("--width", type=int, default=128)
    ap.add_argument("--batch", type=int, default=16, help="每个 rank 的样本数")
    ap.add_argument("--steps", type=int, default=5)
    ap.add_argument("--bucket-mb", type=float, nargs="+", default=[0, 0.25, 1, 25])
    a = ap.parse_args()

    # 单进程基准：全部样本一起训练
    model = make_model(a.layers, a.width)
    opt = torch.optim.SGD(model.parameters(), lr=0.05)
    X, Y = make_data(a.batch * a.world, a.width)
    for _ in range(a.steps):
        opt.zero_grad(); nn.functional.mse_loss(model(X), Y).backward(); opt.step()
    ref = [p.detach() for p in model.parameters()]
    n_par = sum(p.numel() for p in ref)

    ctx = mp.get_context("spawn"); q = ctx.Queue()
    with tempfile.TemporaryDirectory() as d:
        ps = [ctx.Process(target=worker, args=(r, a.world, os.path.join(d, "init"), a, q)) for r in range(a.world)]
        [p.start() for p in ps]
        res = q.get()
        [p.join() for p in ps]
    print(f"== {a.world} 个 rank，{len(ref)} 个参数张量，共 {n_par * 4 / 2 ** 20:.2f} MB 梯度 ==")
    print(f"  {'桶大小':>8s} {'通信次数/步':>10s} {'通信耗时/步':>11s} {'与单进程最大差':>14s}")
    for b in a.bucket_mb:
        calls, t, params = res[b]
        diff = max(abs(u - v.numpy()).max() for u, v in zip(params, ref))
        print(f"  {('逐参数' if b == 0 else f'{b}MB'):>8s} {calls:10d} {t * 1e3:9.2f}ms {diff:14.2e}")
    diff = max(abs(u - v.numpy()).max() for u, v in zip(res["ddp"], ref))
    print(f"  官方 DDP(25MB) 与单进程最大差 {diff:.2e}")
    print("\n[小结] 数据并行在数学上等价于大批量训练（损失按均值归约时梯度取平均）。分桶减少通信次数，"
          "\n       摊薄每次通信的固定延迟；官方 DDP 还会在反向过程中、桶一满就异步发起通信以重叠计算（lab_03）。"
          "\n[问题库] P17 梯度同步的分桶与重叠调参")


if __name__ == "__main__":
    main()
