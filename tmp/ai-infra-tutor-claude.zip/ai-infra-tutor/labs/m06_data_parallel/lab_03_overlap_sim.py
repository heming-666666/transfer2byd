"""[M06-L03] 反向计算与梯度通信的重叠：分桶大小的离散事件模拟

目标：模拟反向传播逐层产出梯度、桶满即在通信流上发起 AllReduce 的过程，
      扫描桶大小，找到最优点；理解"桶太小 α 开销大、桶太大重叠不足"。
先预测：
  1. 桶大小从 1MB 增到 1GB，单步时间会单调变化吗？
  2. 若总通信时间大于总反向计算时间，再怎么调桶大小，单步时间至少是多少？
可调参数：--layers、--layer-mb、--layer-ms、--bw（GB/s）、--alpha-us、--world
暴露的问题：重叠调参依赖模型与网络，自动化调参是研究点 → PROBLEM_BANK P17
对应论文：PyTorch Distributed（VLDB'20 图 7/8 讨论桶大小）；Horovod（Tensor Fusion）
"""
import argparse


def simulate(layer_bytes, layer_ms, bucket_bytes, world, bw, alpha):
    """返回 (单步时间 ms, 通信次数, 暴露的通信时间 ms)。前向时间不计入（对所有配置相同）。"""
    t, comm_free, size, calls = 0.0, 0.0, 0, 0
    ring = 2 * (world - 1) / world

    def launch(nbytes, ready):
        nonlocal comm_free, calls
        start = max(ready, comm_free)                  # 通信流串行：等上一次通信完成
        comm_free = start + alpha + ring * nbytes / bw
        calls += 1
    for lb, lm in zip(layer_bytes, layer_ms):          # 反向：从最后一层到第一层
        t += lm
        size += lb
        if size >= bucket_bytes:
            launch(size, t); size = 0
    if size:
        launch(size, t)
    step = max(t, comm_free)
    return step, calls, step - t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", type=int, default=48)
    ap.add_argument("--layer-mb", type=float, default=24.0, help="每层大张量梯度合计 MB")
    ap.add_argument("--small-per-layer", type=int, default=6, help="每层的小张量个数（bias/norm 等，各 16KB）")
    ap.add_argument("--layer-ms", type=float, default=2.5, help="每层反向计算时间")
    ap.add_argument("--bw", type=float, default=25.0, help="GB/s")
    ap.add_argument("--alpha-us", type=float, default=200.0, help="每次集合通信的固定开销")
    ap.add_argument("--world", type=int, default=64)
    a = ap.parse_args()
    # 每层 = 4 个大张量 + 若干小张量；反向计算时间按张量均摊（简化）
    per = [a.layer_mb * 2 ** 20 / 4] * 4 + [16 * 1024] * a.small_per_layer
    lb = per * a.layers
    lm = [a.layer_ms / len(per)] * len(lb)
    bw, al = a.bw * 1e9 / 1e3, a.alpha_us / 1e3        # 换算到 字节/ms 与 ms
    comp = sum(lm)
    comm_total = 2 * (a.world - 1) / a.world * sum(lb) / bw
    print(f"== {len(lb)} 个梯度张量；反向计算 {comp:.0f} ms；梯度共 {sum(lb) / 2 ** 30:.2f} GB；"
          f"纯通信（无 α）{comm_total:.0f} ms ==")
    print(f"  {'桶大小':>9s} {'单步(ms)':>9s} {'通信次数':>8s} {'暴露通信(ms)':>12s}")
    best = None
    for mb in [0, 1, 4, 16, 25, 64, 256, 1024, 4096]:
        step, calls, exposed = simulate(lb, lm, mb * 2 ** 20, a.world, bw, al)
        best = min(best or (step, mb), (step, mb))
        print(f"  {('逐张量' if mb == 0 else f'{mb}MB'):>9s} {step:9.1f} {calls:8d} {exposed:12.1f}")
    print(f"  最优桶 ≈ {best[1]} MB，单步 {best[0]:.1f} ms；下界 = max(计算, 通信) = {max(comp, comm_total):.1f} ms")

    print("\n== 网络变慢时（带宽 / 4）==")
    for mb in [25, 256]:
        step, calls, exposed = simulate(lb, lm, mb * 2 ** 20, a.world, bw / 4, al)
        print(f"  {mb:5d}MB 单步 {step:7.1f} ms，暴露通信 {exposed:6.1f} ms")
    print("\n[小结] 桶太小：通信次数多，α 累积；桶太大：要等很多层算完才发起通信，最后一个桶无法被隐藏。"
          "\n       通信总量超过计算总量时，重叠只能把时间压到通信时间——需要压缩通信或换并行策略。"
          "\n[问题库] P17 分桶与重叠调参；P16 ZeRO-3 通信重叠")


if __name__ == "__main__":
    main()
