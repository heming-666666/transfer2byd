"""[M06-L02] ZeRO-1/2/3 模拟器：在单进程里用 N 个虚拟 rank 实现分片优化器

目标：亲手实现 ZeRO 的核心步骤——梯度 ReduceScatter、只更新本 rank 的分片、参数 AllGather；
      验证与普通数据并行（DDP）训练结果一致，并统计每个 rank 的显存与通信量。
先预测：
  1. ZeRO-1/2 每步通信量和 DDP 相比是多少？ZeRO-3 呢？
  2. N=8 时，每个 rank 的 Adam 状态是 DDP 的几分之一？
可调参数：--ranks、--steps、--hidden
暴露的问题：ZeRO-3 的额外 AllGather 若不能与计算重叠就会拖慢训练 → PROBLEM_BANK P16
对应论文：ZeRO（1910.02054）；PyTorch FSDP（VLDB'23）；ZeRO++（2306.10209，压缩通信）
真实框架对照：deepspeed/runtime/zero/stage_1_and_2.py、stage3.py；
              torch/distributed/fsdp/_fully_shard/（FSDP2）
"""
import argparse

import torch


def model_fn(flat, x, shapes):
    """把扁平参数向量还原成两层 MLP 再前向（模拟 ZeRO-3 中"用到时再拼回完整参数"）。"""
    ws, off = [], 0
    for s in shapes:
        n = s[0] * s[1]; ws.append(flat[off:off + n].view(s)); off += n
    return torch.tanh(x @ ws[0]) @ ws[1]


def adam_update(p, g, st, lr=1e-2, b1=0.9, b2=0.999, eps=1e-8):
    st["t"] += 1
    st["m"].mul_(b1).add_(g, alpha=1 - b1)
    st["v"].mul_(b2).addcmul_(g, g, value=1 - b2)
    mh = st["m"] / (1 - b1 ** st["t"]); vh = st["v"] / (1 - b2 ** st["t"])
    p -= lr * mh / (vh.sqrt() + eps)


def grads_per_rank(flat, data, shapes):
    gs = []
    for x, y in data:
        p = flat.detach().clone().requires_grad_(True)
        ((model_fn(p, x, shapes) - y) ** 2).mean().backward()
        gs.append(p.grad)
    return gs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ranks", type=int, default=8)
    ap.add_argument("--steps", type=int, default=10)
    ap.add_argument("--hidden", type=int, default=256)
    a = ap.parse_args()
    N = a.ranks
    torch.manual_seed(0)
    shapes = [(64, a.hidden), (a.hidden, 8)]
    P = sum(s[0] * s[1] for s in shapes)
    P += (-P) % N                                       # 补齐到 N 的整数倍，便于均分
    init = torch.randn(P) * 0.1
    data = [(torch.randn(16, 64), torch.randn(16, 8)) for _ in range(N)]

    # 基线：DDP —— 每个 rank 持有完整参数与完整 Adam 状态，梯度 AllReduce
    ddp = init.clone(); st = {"m": torch.zeros(P), "v": torch.zeros(P), "t": 0}
    for _ in range(a.steps):
        g = torch.stack(grads_per_rank(ddp, data, shapes)).mean(0)   # AllReduce(平均)
        adam_update(ddp, g, st)

    # ZeRO：rank r 只负责分片 r 的优化器状态（ZeRO-1/2）或连参数也只存分片（ZeRO-3）
    shard = P // N
    params = [init[r * shard:(r + 1) * shard].clone() for r in range(N)]
    states = [{"m": torch.zeros(shard), "v": torch.zeros(shard), "t": 0} for _ in range(N)]
    for _ in range(a.steps):
        full = torch.cat(params)                                     # AllGather 参数
        gs = grads_per_rank(full, data, shapes)
        for r in range(N):                                           # ReduceScatter 梯度
            g_shard = torch.stack([g[r * shard:(r + 1) * shard] for g in gs]).mean(0)
            adam_update(params[r], g_shard, states[r])
    diff = (torch.cat(params) - ddp).abs().max().item()
    print(f"== {N} 个虚拟 rank，参数 {P} 个，训练 {a.steps} 步 ==")
    print(f"  ZeRO 分片训练 vs DDP 最大参数差 = {diff:.2e}（应接近 0）")

    B = 2  # BF16 字节；混合精度下的显存/通信账本，单位：Ψ 的倍数
    print("\n== 每 rank 显存（混合精度 Adam，单位：字节/参数 × Ψ）==")
    rows = {"DDP": 2 + 2 + 12, "ZeRO-1": 2 + 2 + 12 / N, "ZeRO-2": 2 + (2 + 12) / N, "ZeRO-3": 16 / N}
    for k, v in rows.items():
        print(f"  {k:7s} {v:6.2f}Ψ")
    print("\n== 每 rank 每步通信量（单位：Ψ 个 BF16 元素，Ring 算法近似）==")
    comm = {"DDP": "AllReduce(梯度) = 2Ψ", "ZeRO-1/2": "ReduceScatter(梯度) Ψ + AllGather(参数) Ψ = 2Ψ",
            "ZeRO-3": "前向 AllGather Ψ + 反向 AllGather Ψ + ReduceScatter Ψ = 3Ψ"}
    for k, v in comm.items():
        print(f"  {k:9s} {v}")
    print(f"\n  具体到本例：Ψ={P}，BF16 时 ZeRO-3 每步每 rank 约收发 {3 * P * B * (N - 1) / N / 1024:.1f} KB")
    print("\n[小结] ZeRO-1/2 在不增加通信量的前提下把优化器状态/梯度切成 N 份；ZeRO-3 再切参数，"
          "\n       代价是多 50% 通信且每层都要在用之前 AllGather——能否与计算重叠决定了它的实际速度。"
          "\n[问题库] P16 ZeRO-3/FSDP 通信重叠；P14 显存墙")


if __name__ == "__main__":
    main()
