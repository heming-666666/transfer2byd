"""[M13-L01] 迷你深度学习编译器：计算图 IR + 常量折叠 / 公共子表达式消除 / 死代码消除 / 逐元素融合

目标：用不到 200 行实现一个能执行的图 IR 和 4 个经典优化 pass，统计优化前后的"kernel 数"与
      中间结果的显存读写量，并用 numpy 解释器验证结果不变。
先预测：
  1. 下面的计算图优化前有几个 kernel？融合后剩几个？
  2. 为什么 matmul 一般不与后面的逐元素算子"随便融合"，而是作为融合组的"锚点"（epilogue fusion）？
可调参数：--n（张量规模）
暴露的问题：融合规则与代价模型的设计、动态形状下的融合 → PROBLEM_BANK P12
对应论文：TVM（1802.04799，算子融合分类）；PyTorch 2（TorchInductor）；MLIR；Ansor
真实框架对照：torch/_inductor/scheduler.py（融合）、torch/fx/passes/；apache/tvm src/relay/transforms/fuse_ops.cc
"""
import argparse

import numpy as np

ELEMENTWISE = {"add", "mul", "gelu", "relu", "scale"}


class Node:
    def __init__(self, op, inputs=(), value=None, name=""):
        self.op, self.inputs, self.value, self.name = op, list(inputs), value, name

    def __repr__(self):
        return f"{self.name}={self.op}({','.join(i.name for i in self.inputs)})"


class Graph:
    def __init__(self):
        self.nodes, self.cnt = [], 0

    def add(self, op, *inputs, value=None):
        self.cnt += 1
        n = Node(op, inputs, value, f"v{self.cnt}")
        self.nodes.append(n)
        return n


def run(graph, outputs, env):
    vals = {}
    impl = {"add": np.add, "mul": np.multiply, "matmul": np.matmul, "relu": lambda x: np.maximum(x, 0),
            "gelu": lambda x: 0.5 * x * (1 + np.tanh(0.79788456 * (x + 0.044715 * x ** 3))),
            "scale": lambda x, c: x * c}
    for n in graph.nodes:
        if n.op == "input":
            vals[n] = env[n.value]
        elif n.op == "const":
            vals[n] = n.value
        elif n.op == "fused":                              # 融合 kernel：在一个循环里依次执行子图
            local = {}
            for sub in n.value:
                args = [local.get(i, vals.get(i)) for i in sub.inputs]
                local[sub] = impl[sub.op](*args)
            vals[n] = local[n.value[-1]]
        else:
            vals[n] = impl[n.op](*[vals[i] for i in n.inputs])
    return [vals[o] for o in outputs]


def users(graph):
    u = {n: [] for n in graph.nodes}
    for n in graph.nodes:
        for i in n.inputs:
            if n not in u[i]:                              # 同一个使用者引用两次（如 add(v, v)）只算一次
                u[i].append(n)
    return u


def constant_fold(g):
    for n in g.nodes:
        if n.op not in ("input", "const", "fused") and n.inputs and all(i.op == "const" for i in n.inputs):
            n.value = run(_single(n), [n], {})[0]          # 在编译期直接算出结果
            n.op, n.inputs = "const", []


def _single(n):
    g = Graph(); g.nodes = list(n.inputs) + [n]
    return g


def cse(g):
    seen, remap = {}, {}
    for n in g.nodes:
        n.inputs = [remap.get(i, i) for i in n.inputs]
        key = (n.op, tuple(id(i) for i in n.inputs), id(n.value) if n.op in ("input", "const") else None)
        if n.op not in ("input", "const") and key in seen:
            remap[n] = seen[key]
        else:
            seen[key] = n
    g.nodes = [n for n in g.nodes if n not in remap]


def dce(g, outputs):
    live, stack = set(), list(outputs)
    while stack:
        n = stack.pop()
        if n not in live:
            live.add(n); stack.extend(n.inputs)
    g.nodes = [n for n in g.nodes if n in live]


def fuse_elementwise(g, outputs):
    """把"只有一个使用者"的逐元素算子链合并成一个 fused 节点（中间结果不再写回显存）。"""
    u = users(g)
    groups, assigned = [], set()
    for n in g.nodes:
        if n.op in ELEMENTWISE and n not in assigned:
            chain = [n]
            while len(u[chain[-1]]) == 1 and u[chain[-1]][0].op in ELEMENTWISE and chain[-1] not in outputs:
                chain.append(u[chain[-1]][0])
            if len(chain) > 1:
                groups.append(chain); assigned.update(chain)
    for chain in groups:
        f = Node("fused", [i for c in chain for i in c.inputs if i not in chain], chain, chain[-1].name + "_f")
        idx = g.nodes.index(chain[-1])
        g.nodes[idx] = f
        g.nodes = [n for n in g.nodes if n not in chain[:-1]]
        for n in g.nodes:                                  # 让下游使用 fused 节点
            n.inputs = [f if i is chain[-1] else i for i in n.inputs]
        outputs[:] = [f if o is chain[-1] else o for o in outputs]


def stats(g, nbytes):
    kernels = [n for n in g.nodes if n.op not in ("input", "const")]
    traffic = sum(nbytes * (len(n.inputs) + 1) for n in kernels)   # 每个 kernel 读输入、写输出
    return len(kernels), traffic


def build():
    g = Graph()
    x, W, b = g.add("input", value="x"), g.add("input", value="W"), g.add("input", value="b")
    c = g.add("mul", g.add("const", value=np.float32(3.0)), g.add("const", value=np.float32(0.5)))  # 可折叠
    h = g.add("add", g.add("matmul", x, W), b)
    a1 = g.add("gelu", h); a2 = g.add("gelu", h)                    # 公共子表达式
    y = g.add("scale", g.add("add", a1, a2), c)
    y = g.add("relu", y)
    g.add("mul", x, x)                                              # 死代码：结果没人用
    return g, [y]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=512)
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    env = {"x": rng.standard_normal((a.n, a.n)).astype(np.float32),
           "W": rng.standard_normal((a.n, a.n)).astype(np.float32) / a.n ** 0.5,
           "b": rng.standard_normal(a.n).astype(np.float32)}
    nbytes = a.n * a.n * 4
    g, outs = build()
    ref = run(g, outs, env)[0]
    print("== 原始图 ==")
    print("  " + "; ".join(map(repr, [n for n in g.nodes if n.op not in ("input",)])))
    k, t = stats(g, nbytes)
    print(f"  kernel 数={k}，估算读写={t / 2 ** 20:.0f}MB")
    for name, fn in [("常量折叠", lambda: constant_fold(g)), ("CSE", lambda: cse(g)),
                     ("DCE", lambda: dce(g, outs)), ("逐元素融合", lambda: fuse_elementwise(g, outs))]:
        fn()
        k, t = stats(g, nbytes)
        err = np.abs(run(g, outs, env)[0] - ref).max()
        print(f"  {name:8s} 后：kernel 数={k}，估算读写={t / 2 ** 20:4.0f}MB，结果最大差={err:.1e}")
    print("== 优化后的图 ==")
    print("  " + "; ".join(map(repr, [n for n in g.nodes if n.op not in ("input", "const")])))
    print("\n[小结] 这些 pass 在每个编译器里都有对应物。真实编译器的难点在于：融合要有代价模型（寄存器压力、并行度），"
          "\n       matmul 等算子通常只做 epilogue 融合；动态形状和 Python 控制流会让图捕获本身变难（lab_02）。"
          "\n[问题库] P12 融合机会与编译器自动化的边界")


if __name__ == "__main__":
    main()
