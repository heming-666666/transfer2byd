"""[M13-L03] 自动调优（autotuning）：分块矩阵乘的 tile 搜索——网格、随机、代价模型引导

目标：在本机实测分块矩阵乘（numpy 实现）不同 (BM, BN, BK) 配置的耗时，观察性能地形的崎岖程度；
      比较"全量网格搜索""随机搜索（固定预算）""用少量样本拟合代价模型再挑选"的效率；
      检查最优配置是否随问题规模变化（可移植性问题）。
先预测：
  1. 最快与最慢配置的耗时相差多少倍？
  2. 只允许试 8 个配置时，随机搜索和代价模型引导哪个更可能找到前 10% 的配置？
可调参数：--sizes（矩阵规模列表）、--budget（搜索预算）、--trials
暴露的问题：搜索开销与跨硬件/跨形状的可移植性 → PROBLEM_BANK P13
对应论文：TVM（AutoTVM）；Ansor（2006.06762）；Triton（@triton.autotune）；TileLang
真实框架对照：triton-lang/triton python/triton/runtime/autotuner.py；apache/tvm python/tvm/meta_schedule/
"""
import argparse
import itertools
import os
import random
import time

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")       # 固定单线程：多线程 BLAS 的调度抖动会淹没配置间的差异
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np  # noqa: E402  （必须在设置线程数之后导入）


def blocked_matmul(A, B, bm, bn, bk):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=A.dtype)
    for i in range(0, n, bm):
        for j in range(0, n, bn):
            acc = C[i:i + bm, j:j + bn]
            for k in range(0, n, bk):
                acc += A[i:i + bm, k:k + bk] @ B[k:k + bk, j:j + bn]
    return C


def measure(A, B, cfg, reps=5):
    blocked_matmul(A, B, *cfg)                             # 预热
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); blocked_matmul(A, B, *cfg); ts.append(time.perf_counter() - t0)
    return sorted(ts)[reps // 2]                           # 中位数，抗干扰


def features(cfg, n):
    """对数空间的特征：log(循环次数) 反映 Python/调用开销，log(访存量) 反映数据复用。"""
    bm, bn, bk = cfg
    loops = (n // bm) * (n // bn) * (n // bk)
    traffic = n ** 3 * (1 / bn + 1 / bm) + n * n * (n // bk)     # 读 A、B 的次数 + C 的读改写
    return [1.0, np.log(loops), np.log(traffic)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sizes", type=int, nargs="+", default=[256, 512])
    ap.add_argument("--budget", type=int, default=8)
    ap.add_argument("--trials", type=int, default=50)
    a = ap.parse_args()
    tiles = [16, 32, 64, 128, 256]
    best_cfg = {}
    for n in a.sizes:
        rng = np.random.default_rng(0)
        A = rng.standard_normal((n, n)).astype(np.float32); B = rng.standard_normal((n, n)).astype(np.float32)
        space = [c for c in itertools.product(tiles, tiles, tiles) if max(c) <= n]
        t = {c: measure(A, B, c) for c in space}
        order = sorted(space, key=t.get)
        best_cfg[n] = order[0]
        print(f"\n== N={n}：{len(space)} 个配置全量实测（单线程，每配置 5 次取中位数；网格搜索耗时 {sum(t.values()) * 6:.1f}s）==")
        for c in order[:3]:
            print(f"  最快 {c}: {t[c] * 1e3:8.2f} ms")
        print(f"  最慢 {order[-1]}: {t[order[-1]] * 1e3:8.2f} ms（相差 {t[order[-1]] / t[order[0]]:.0f}×）")
        top10 = set(order[: max(1, len(order) // 10)])
        r = random.Random(0)
        hit_rand = sum(bool(top10 & set(r.sample(space, a.budget))) for _ in range(a.trials)) / a.trials
        hit_model = 0
        for trial in range(a.trials):                      # 代价模型：先随机测一半预算，最小二乘拟合，再按预测挑另一半
            sample = r.sample(space, a.budget // 2)
            X = np.array([features(c, n) for c in sample]); y = np.log([t[c] for c in sample])
            w, *_ = np.linalg.lstsq(X, y, rcond=None)
            pred = sorted(space, key=lambda c: np.dot(features(c, n), w))
            picked = sample + [c for c in pred if c not in sample][: a.budget - len(sample)]
            hit_model += bool(top10 & set(picked))
        print(f"  预算 {a.budget} 次：随机搜索命中前10%的概率 {hit_rand:.0%}；代价模型引导 {hit_model / a.trials:.0%}")
    if len(a.sizes) > 1:
        print(f"\n== 可移植性：各规模的最优配置 {best_cfg} ==")
        n = a.sizes[-1]
        rng = np.random.default_rng(0)
        A = rng.standard_normal((n, n)).astype(np.float32); B = rng.standard_normal((n, n)).astype(np.float32)
        t_own, t_other = measure(A, B, best_cfg[n]), measure(A, B, best_cfg[a.sizes[0]])
        print(f"  在 N={n} 上用 N={a.sizes[0]} 的最优配置：{t_other * 1e3:.2f} ms vs 自己的最优 {t_own * 1e3:.2f} ms"
              f"（慢 {t_other / t_own:.2f}×）")
    print("\n[小结] 配置空间里好坏相差悬殊且不光滑；全量搜索代价高，随机搜索在小预算下不稳定，"
          "\n       简单代价模型就能显著提高命中率——Ansor/MetaSchedule 用学习到的代价模型做同样的事。"
          "\n       最优配置随形状与硬件变化，所以 Triton 按 key（形状）缓存调优结果，换 GPU 往往要重调。"
          "\n[问题库] P13 自动调优的搜索开销与可移植性")


if __name__ == "__main__":
    main()
