"""[M13-L02] torch.fx 与 torch.compile 的前端：图捕获、自定义 pass、图断裂（graph break）与重编译

目标：用 torch.fx 把模型变成可改写的图并写一个替换 pass；用 TorchDynamo（torch.compile 的前端）观察
      Python 控制流、print、数据相关分支造成的图断裂，以及输入形状变化引起的重编译。
      本机没有 C/C++ 编译器，TorchInductor 无法在 CPU 上生成代码；我们用自定义 backend 只做"捕获与计数"，
      并如实报告 inductor 的结果。
先预测：
  1. `if x.sum() > 0:` 这样的分支会让 Dynamo 怎么做？
  2. 同一个函数先后用形状 (8,16)、(9,16)、(10,16) 调用，会编译几次？
可调参数：无（结构固定，便于读代码）
暴露的问题：图断裂与动态形状削弱编译器收益 → PROBLEM_BANK P12
对应论文：PyTorch 2（ASPLOS'24，TorchDynamo/TorchInductor）
真实框架对照：torch/fx/（symbolic_trace、GraphModule）；torch/_dynamo/（eval_frame.py、symbolic_convert.py）
"""
import operator

import torch
import torch.fx as fx
import torch.nn as nn


class Block(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Linear(16, 16)

    def forward(self, x):
        return torch.relu(self.fc(x) + x)


def fx_demo():
    print("== 1. torch.fx：符号追踪得到的图 ==")
    orig = Block()
    gm = fx.symbolic_trace(orig)                           # gm 与 orig 共享参数
    for n in gm.graph.nodes:
        print(f"  {n.op:14s} {str(n.target):30s} args={n.args}")

    # 自定义 pass：把 relu(add(a, b)) 替换为一个"融合算子"（这里用 Python 函数模拟一个融合 kernel）
    def fused_add_relu(a, b):
        return torch.clamp_min(a + b, 0)
    count = 0
    for n in list(gm.graph.nodes):
        if n.op == "call_function" and n.target is torch.relu and n.args[0].op == "call_function" \
                and n.args[0].target is operator.add:
            add = n.args[0]
            with gm.graph.inserting_after(n):
                new = gm.graph.call_function(fused_add_relu, add.args)
            n.replace_all_uses_with(new)
            gm.graph.erase_node(n); gm.graph.erase_node(add); count += 1
    gm.recompile()
    x = torch.randn(4, 16)
    print(f"  替换了 {count} 处 relu(add)；新图结果与原模块一致：{torch.allclose(gm(x), orig(x))}")
    print("  改写后的代码：\n    " + gm.code.strip().replace("\n", "\n    "))


def dynamo_demo():
    print("\n== 2. TorchDynamo：图断裂 ==")
    graphs = []

    def counting_backend(gm, example_inputs):             # 自定义 backend：记录捕获到的每个子图，直接以 eager 执行
        graphs.append(len([n for n in gm.graph.nodes if n.op == "call_function"]))
        return gm.forward

    def f_clean(x):
        return torch.relu(x @ x.T + 1).sum()

    def f_break(x):
        y = x * 2
        print("  （函数内的 print 会触发图断裂）")
        if y.sum() > 0:                                     # 数据相关的分支
            y = y + 1
        else:
            y = y - 1
        return torch.tanh(y).sum()

    torch._dynamo.reset()
    for name, fn in [("无断裂的函数", f_clean), ("含 print 与数据相关分支", f_break)]:
        graphs.clear()
        torch.compile(fn, backend=counting_backend)(torch.randn(8, 16))
        print(f"  {name}：捕获到 {len(graphs)} 个子图，各含算子数 {graphs}")
    try:
        exp = torch._dynamo.explain(f_break)(torch.randn(8, 16))
        print(f"  dynamo.explain：graph_count={exp.graph_count}，graph_break_count={exp.graph_break_count}")
        for br in exp.break_reasons[:3]:
            print(f"    断裂原因：{' '.join(str(br.reason).split())[:100]}")
    except Exception as e:                                  # 不同版本 API 可能变化，如实报告
        print(f"  dynamo.explain 不可用：{type(e).__name__}: {str(e)[:80]}")

    print("\n== 3. 形状变化引起的重编译 ==")
    torch._dynamo.reset()
    graphs.clear()
    cf = torch.compile(f_clean, backend=counting_backend)
    for rows in [8, 9, 10, 11, 8]:
        cf(torch.randn(rows, 16))
        print(f"  输入 ({rows},16) 后累计编译次数 = {len(graphs)}")
    print("  （第二种形状出现时 Dynamo 通常会把该维度标记为动态，之后不再为每个新形状重编译）")


def inductor_demo():
    print("\n== 4. TorchInductor（真正生成融合 kernel 的后端）==")
    try:
        f = torch.compile(lambda x: torch.relu(x * 2 + 1).sum())
        f(torch.randn(64, 64))
        print("  inductor 编译成功（本机具备 C++ 编译器）")
    except Exception as e:
        print(f"  inductor 失败：{type(e).__name__}: {str(e).splitlines()[0][:100]}")
        print("  原因：CPU 后端需要 C++ 编译器生成代码；本环境没有安装。GPU 上 inductor 生成 Triton kernel。")


def main():
    torch.manual_seed(0)
    fx_demo()
    dynamo_demo()
    inductor_demo()
    print("\n[小结] fx 让图可以被程序改写；Dynamo 在字节码层面捕获图，遇到无法追踪的 Python 行为就断开，"
          "\n       断裂越多，编译器能看到的融合范围越小；形状变化会触发重编译或退化为动态形状代码。"
          "\n[问题库] P12 编译器自动化的边界（图断裂、动态形状）")


if __name__ == "__main__":
    main()
