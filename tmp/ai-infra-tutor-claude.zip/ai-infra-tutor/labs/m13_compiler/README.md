# M13 编译器：计算图与 IR、算子融合与自动调优、TVM、XLA、torch.compile

- **对应任务**：D6-T07（讲义）、D6-T08（L01~L03）、D6-T09（★`pt2`）
- **先修**：M02、M03
- **预计学时**：1.8 小时
- **学习目标**：
  1. 解释深度学习编译器的分层：图捕获 → 高层 IR 上的图优化 → 低层 IR 上的调度与代码生成。
  2. 实现常量折叠、公共子表达式消除（CSE）、死代码消除（DCE）和逐元素融合四个 pass。
  3. 说出 TorchDynamo、AOTAutograd、TorchInductor 的分工，解释图断裂和重编译的来源。
  4. 设计一个自动调优实验，比较网格搜索、随机搜索和代价模型引导搜索。

## 1. 核心讲义

### 1.1 为什么需要深度学习编译器

M02 和 M03 告诉我们：eager 模式下，每个算子单独启动、中间结果写回显存，开销和访存浪费都很大；而手写融合 kernel 的成本很高，还要随硬件反复重写。编译器的目标是**自动**完成：

1. **图捕获**：把 Python 程序变成计算图（静态图框架天然就有；PyTorch 需要 TorchDynamo 这样的工具）。
2. **图优化**（高层 IR）：常量折叠、CSE、DCE、代数化简、布局变换、**算子融合**。
3. **调度与代码生成**（低层 IR）：为融合后的算子选择循环顺序、分块、向量化、并行方式，生成 CUDA/Triton/LLVM 代码；用**自动调优**在候选中挑最快的。

### 1.2 代表性系统

- **TVM**（OSDI'18）：Relay 高层 IR 加 TE/TIR 低层 IR；把“算什么”（compute）和“怎么算”（schedule）分开，借鉴了 Halide 的思想。AutoTVM 用模板加学习得到的代价模型搜索调度；Ansor（OSDI'20）不需要模板，自动生成搜索空间。
- **XLA**：TensorFlow/JAX 的编译器，HLO 作为 IR，擅长整图融合与跨设备分片（GSPMD）。
- **MLIR**：可扩展的多层 IR 基础设施，许多新编译器建立在它之上。
- **PyTorch 2 / torch.compile**（ASPLOS'24）：
  - **TorchDynamo**：在 Python 字节码层面拦截函数执行，把能追踪的部分提取成 FX 图；遇到无法追踪的 Python 行为（例如 print、数据相关的控制流、不支持的库调用）就**断开图**（graph break），断点前后分别编译，中间回到 eager 执行。
  - **AOTAutograd**：提前生成反向图，使前向和反向都能被优化。
  - **TorchInductor**：默认后端，GPU 上生成 Triton kernel，CPU 上生成 C++/OpenMP 代码。
  - **Guard 与重编译**：编译结果附带一组 guard（输入形状、类型等）；guard 不满足时重新编译。形状变化时，Dynamo 会把对应维度标记为动态，生成对符号形状通用的代码。

### 1.3 自动调优

同一个算子，不同的 tile 大小、循环顺序、流水级数，性能可以相差几十倍，而且最优选择随输入形状和硬件变化。搜索方法：

- 网格搜索：全面但昂贵；
- 随机搜索：便宜但在小预算下不稳定；
- 代价模型引导：先测少量样本、拟合一个预测耗时的模型，再用模型挑选候选（Ansor、MetaSchedule 使用学习得到的代价模型；Triton 的 `@triton.autotune` 则在给定的候选配置中实测选最快，并按 key 缓存结果）。

## 2. 实验

### M13-L01 迷你编译器：图 IR 与优化 pass（`lab_01_graph_ir_passes.py`）

- **先预测**：(1) 示例计算图优化前有几个 kernel？融合后剩几个？(2) 为什么 matmul 一般不和后面的逐元素算子随便融合，而是作为融合组的“锚点”？
- **实测输出摘要**：原始图 9 个 kernel、估算读写 24MB；常量折叠后 8 个；CSE 后 7 个（两个相同的 gelu 合并）；DCE 后 6 个（删掉无人使用的 `x*x`）；逐元素融合后只剩 **2 个**（matmul + 一个融合 kernel），估算读写 7MB。每一步的结果与原图完全一致。
- **开发说明**：第一版融合后剩 3 个 kernel：CSE 之后出现 `add(v9, v9)`，同一个使用者被计算了两次，`users()` 认为 v9 有两个使用者，链条在这里断开。修正为“同一个使用者只计一次”后，结果符合预期。**编译器 pass 的正确性往往取决于这类边界情况。**
- **真实框架对照**：`torch/fx/passes/`、`torch/_inductor/scheduler.py`；apache/tvm `src/relay/transforms/fuse_ops.cc`。
- **暴露的问题**：[P12](../../research/PROBLEM_BANK.md#p12)。

### M13-L02 torch.compile 的前端（`lab_02_torch_compile_capture.py`）

- **先预测**：(1) `if x.sum() > 0:` 这样的分支会让 Dynamo 怎么做？(2) 同一个函数先后用形状 (8,16)、(9,16)、(10,16) 调用，会编译几次？
- **实测输出摘要**：fx 符号追踪得到 5 个节点；自定义 pass 把 `relu(add(a, b))` 替换为一个“融合函数”，结果与原模块一致，并打印改写后的 Python 代码。Dynamo：无断裂的函数捕获 1 个子图；含 print 和数据相关分支的函数捕获 3 个子图，`dynamo.explain` 报告 graph_count=3、graph_break_count=2，断裂原因分别是无法追踪的内置函数（print）和数据相关的跳转。形状变化：输入 (8,16) 后编译 1 次，(9,16) 后 2 次，之后的 (10,16)、(11,16)、(8,16) 都不再重编译——第二次时该维度被标记为动态。Inductor：报 `InvalidCxxCompiler`，因为本机没有 C++ 编译器。
- **说明**：本机缺少 C++ 编译器，无法体验 Inductor 的代码生成，实验改用只做捕获和计数的自定义 backend，并如实报告 Inductor 的错误。在 GPU 环境（Inductor 生成 Triton kernel）或安装了 g++ 的机器上可以运行完整流程。
- **真实框架对照**：`torch/fx/`；`torch/_dynamo/`（`eval_frame.py`、`symbolic_convert.py`）；`torch/_inductor/`。
- **暴露的问题**：[P12](../../research/PROBLEM_BANK.md#p12)。

### M13-L03 自动调优（`lab_03_autotune.py`）

- **先预测**：(1) 最快与最慢配置相差多少倍？(2) 只允许试 8 个配置时，随机搜索和代价模型引导哪个更可能找到前 10% 的配置？
- **实测输出摘要**（numpy 分块矩阵乘，单线程，每个配置 5 次取中位数）：N=256 时最快 (128,256,256) 0.26ms，最慢 (16,16,16) 8.2ms，相差约 31 倍；N=512 时相差约 30 倍。预算 8 次时，随机搜索命中前 10% 的概率约 52~56%，**对数空间的线性代价模型引导约 90%**。把 N=256 的最优配置用在 N=512 上，比 N=512 自己的最优慢约 1.1 倍。
- **开发说明**：第一版用多线程 BLAS、每个配置测 2 次，同一配置前后两次测量相差约 5 倍，排名完全不可信；固定单线程并取中位数后才稳定。代价模型最初在线性空间拟合，在 N=512 上命中率反而低于随机搜索；改成在对数空间拟合（耗时相差几十倍，是乘性的）后才有效。
- **真实框架对照**：triton-lang/triton `python/triton/runtime/autotuner.py`；apache/tvm `python/tvm/meta_schedule/`。
- **暴露的问题**：[P13](../../research/PROBLEM_BANK.md#p13)。

## 3. 常见误区

- “torch.compile 一定更快”：图断裂多、形状频繁变化、算子本身受算力限制（大 GEMM）时，收益有限甚至为负（编译时间）。
- “编译器会自动做所有融合”：复杂算子（注意力）通常仍由手写 kernel 提供（FlashAttention、FlexAttention 用模板生成变体）。
- “自动调优的结果可以直接复用”：换形状、换硬件往往需要重新调优。

## 4. 论文与延伸阅读

- 必读：`tvm`（arXiv 1802.04799）、★`pt2`（ASPLOS'24，DOI 10.1145/3620665.3640366）。
- 选读：`ansor`、`mlir`；前沿：`flexattn`、`tilelang`、`thunderkittens`。
- 资源：PyTorch 官方 torch.compile 文档；GPU MODE 第 29 讲（Triton 内部机制）；openmlsys 第 4 章（AI 编译器与运行时）。

## 5. 自测题

Q-M13-L1-01 ~ Q-M13-L4-01；动手练习见 `exercises.md`。
