#!/usr/bin/env python3
"""环境自检：打印 Python/PyTorch/硬件信息与关键库，并扫描 labs/ 给出"哪些实验能做"的能力表。

用法：python env/check_env.py          （在教学包根目录，用安装好的虚拟环境里的 python 运行）
判断依据：扫描每个实验源码中的 import 与文件名（*_gpu.py 为 GPU 选做），不实际运行实验。
"""
import importlib
import os
import platform
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def version(mod):
    try:
        m = importlib.import_module(mod)
        return getattr(m, "__version__", "已安装")
    except Exception:
        return None


def mem_gb():
    try:
        with open("/proc/meminfo") as f:
            return int(re.search(r"MemTotal:\s+(\d+)", f.read()).group(1)) / 2 ** 20
    except OSError:
        return float("nan")


def main():
    print("== 基本信息 ==")
    print(f"  Python      {platform.python_version()}  ({sys.executable})")
    print(f"  系统        {platform.platform()}")
    print(f"  CPU 逻辑核  {os.cpu_count()}    内存 {mem_gb():.1f} GB")
    ok_py = sys.version_info >= (3, 12)
    print(f"  Python>=3.12 {'是' if ok_py else '否（numpy 2.5.4 需要 3.12+）'}")

    libs = {k: version(k) for k in ["torch", "numpy", "matplotlib", "triton", "vllm"]}
    print("\n== 关键库 ==")
    for k, v in libs.items():
        print(f"  {k:11s} {v or '未安装'}")
    cuda = gloo = False
    if libs["torch"]:
        import torch
        cuda = torch.cuda.is_available()
        gloo = torch.distributed.is_available() and torch.distributed.is_gloo_available()
        extra = ""
        if cuda:
            p = torch.cuda.get_device_properties(0)
            extra = f"（{p.name}，{p.total_memory / 2 ** 30:.0f}GB）"
        print(f"  CUDA 可用   {cuda}{extra}")
        print(f"  gloo 后端   {gloo}（单机多进程模拟分布式所需）")
        print(f"  torch 线程  {torch.get_num_threads()}")
    cxx = shutil.which("g++") or shutil.which("c++") or shutil.which("clang++")
    print(f"  C++ 编译器  {cxx or '未找到（torch.compile 的 inductor CPU 后端不可用，M13-L02 会如实报告）'}")

    print("\n== 实验能力表 ==")
    rows, counts = [], {"可运行": 0, "需GPU": 0, "缺依赖": 0}
    labdir = os.path.join(ROOT, "labs")
    for mod in sorted(d for d in os.listdir(labdir) if d.startswith("m")):
        for f in sorted(os.listdir(os.path.join(labdir, mod))):
            if not (f.startswith("lab_") and f.endswith(".py")):
                continue
            src = open(os.path.join(labdir, mod, f), encoding="utf-8").read()
            need = [m for m in ["torch", "numpy", "matplotlib"] if re.search(rf"^\s*(import|from) {m}\b", src, re.M)]
            missing = [m for m in need if not libs[m]]
            if "torch.distributed" in src and not gloo:
                missing.append("gloo")
            if f.endswith("_gpu.py"):
                st = "可运行" if cuda and not missing else "需GPU"
            else:
                st = "缺依赖" if missing else "可运行"
            counts[st] += 1
            rows.append((f"{mod}/{f}", st, ",".join(need) or "仅标准库", ",".join(missing)))
    for name, st, need, miss in rows:
        print(f"  [{st:4s}] {name:56s} 依赖: {need:18s} {('缺: ' + miss) if miss else ''}")
    print(f"\n汇总：可运行 {counts['可运行']}，需 GPU {counts['需GPU']}，缺依赖 {counts['缺依赖']}")
    if counts["缺依赖"]:
        print("缺依赖时请运行：bash env/setup.sh（见 env/README.md 的常见问题）")
    if counts["需GPU"]:
        print("GPU 选做实验都有 CPU 替代版本，见各实验 docstring 与 labs/INDEX.md。")


if __name__ == "__main__":
    main()
