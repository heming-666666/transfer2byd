# 环境说明与常见问题

## 已验证组合

| 项目 | 版本 |
| --- | --- |
| 操作系统 | Linux x86_64（WSL2，内核 6.18） |
| Python | 3.12.3 |
| PyTorch | 2.14.1+cpu（PyTorch 官方 CPU 索引） |
| numpy / matplotlib | 2.5.4 / 3.11.2 |
| 安装工具 | uv 0.13.1 |

在这个组合下，43 个 CPU 实验全部通过，2 个 GPU 选做实验按预期显示 SKIP（运行记录见 `README.md` 末尾的自检结果）。GPU 扩展（`requirements-gpu.txt`）**没有在构建机上验证**，因为构建机没有 GPU。

## 安装

```bash
bash env/setup.sh              # CPU 环境，默认装到 ~/.cache/ai-infra-tutor-claude/venv
AIT_VENV=./.venv bash env/setup.sh   # 想放到教学包目录里也可以
bash env/setup.sh --gpu        # 可选：另建 GPU 环境
```

脚本可以重复执行：环境已存在时会复用，依赖已满足时会直接跳过。它不需要 root，也不会修改系统 Python。

## 常见安装失败与处理

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| `python3 -m venv` 报 `ensurepip is not available` | 系统 Python 缺少 venv 组件（Debian/Ubuntu 上很常见） | 安装 `python3-venv`（需要管理员权限），或者安装 uv（单文件，不需要 root）后重新运行脚本 |
| `numpy==2.5.4` 找不到匹配版本 | Python 版本低于 3.12 | 用 uv：`uv venv --python 3.12` 会准备好合适的 Python；或换用 3.12+ |
| 下载 torch 时 `operation timed out` | 轮子约 190MB，uv 默认的读取超时太短 | 脚本已经把 `UV_HTTP_TIMEOUT` 默认设为 600 秒；仍然失败时，重新运行即可续用缓存。网络本身的问题请交给负责网络的人处理，不要随意改代理 |
| 装上了 2GB 以上的 CUDA 版 torch | 同时指定了 PyPI 和 PyTorch 两个索引，uv 会优先查 `--extra-index-url` | 按脚本的做法分两步装：torch **只**从 CPU 索引装，其余依赖从 PyPI 装 |
| `torch.compile` 报 `InvalidCxxCompiler` | inductor 的 CPU 后端需要 C++ 编译器 | 属于预期情况：M13-L02 会如实报告并改用"只捕获、不生成代码"的后端。想体验代码生成，可以安装 g++，或在 GPU 上运行 |
| gloo 实验卡住或报网络接口错误 | gloo 找不到合适的网卡 | 脚本内已经设置 `GLOO_SOCKET_IFNAME=lo`（只走本机回环）；不要换成其他网卡 |
| GPU 环境中 `vllm` 与 torch 版本冲突 | vllm 0.32.0 锁定 torch==2.13.0 | GPU 依赖必须装在独立环境里（`--gpu` 会自动这样做），不要装进 CPU 环境 |
| `flash-attn` 编译很久或者失败 | 需要 CUDA 工具链在本地编译 | 它是可选依赖，本教学包的实验并不需要；FlashAttention 的原理用 M03-L03 的 CPU 实现来学 |

## 资源需求

- CPU 实验：单个实验不超过 5 分钟（实测最长约 8 秒），峰值内存不超过 4GB（实测最大约 1.2GB）。全部 43 个实验跑一遍约 70 秒（8 线程）。
- 磁盘：CPU 环境约 1GB。
- 不需要下载任何模型权重或数据集：所有模型都是随机初始化的小模型，模型结构参数取自公开的 config 或论文，直接写在代码里。
