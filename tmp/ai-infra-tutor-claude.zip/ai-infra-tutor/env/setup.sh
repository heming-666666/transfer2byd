#!/usr/bin/env bash
# AI Infra 教学包 · 环境安装脚本（可重复执行；不需要 root；不修改系统 Python）
#
# 用法（在教学包根目录）：
#   bash env/setup.sh            # 创建/更新 CPU 环境（全部必做实验）
#   bash env/setup.sh --gpu      # 另建 GPU 扩展环境（选做实验，需要 NVIDIA GPU；未在构建机上验证）
# 环境变量：
#   AIT_VENV      CPU 虚拟环境位置，默认 ~/.cache/ai-infra-tutor-claude/venv
#   AIT_VENV_GPU  GPU 虚拟环境位置，默认 ~/.cache/ai-infra-tutor-claude/venv-gpu
#   AIT_PYTHON    使用 uv 时请求的 Python 版本，默认 3.12（numpy 2.5.4 要求 >= 3.12）
# 安装方式：优先 uv（更快、可在缺少 venv/ensurepip 的系统上工作）；没有 uv 时用 python3 -m venv + pip。
# 网络失败时脚本只报告出错的步骤并退出，不会改动任何网络或代理设置。
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${AIT_VENV:-$HOME/.cache/ai-infra-tutor-claude/venv}"
VENV_GPU="${AIT_VENV_GPU:-$HOME/.cache/ai-infra-tutor-claude/venv-gpu}"
PYVER="${AIT_PYTHON:-3.12}"
TORCH_CPU_INDEX="https://download.pytorch.org/whl/cpu"
export UV_HTTP_TIMEOUT="${UV_HTTP_TIMEOUT:-600}"     # torch 轮子约 190MB，慢速网络下默认 30s 超时不够

MODE="cpu"
[[ "${1:-}" == "--gpu" ]] && MODE="gpu"

step() { printf '\n==> %s\n' "$*"; }
fail() { printf '\n[失败] %s\n' "$*" >&2; exit 1; }

UV="$(command -v uv || true)"

make_venv() {   # $1 = 路径
  local dir="$1"
  if [[ -x "$dir/bin/python" ]]; then
    echo "复用已有环境：$dir"
    return
  fi
  mkdir -p "$(dirname "$dir")"
  if [[ -n "$UV" ]]; then
    "$UV" venv --python "$PYVER" "$dir" || fail "uv 创建虚拟环境失败（可能需要联网下载 Python $PYVER）"
  else
    python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)' \
      || fail "需要 Python >= 3.12（numpy 2.5.4 的要求）。可安装 uv 后重试：https://docs.astral.sh/uv/"
    python3 -m venv "$dir" || fail "python3 -m venv 失败：系统缺少 venv/ensurepip 模块。安装 python3-venv，或安装 uv 后重试"
  fi
}

pip_install() {  # $1 = venv，其余为参数
  local dir="$1"; shift
  if [[ -n "$UV" ]]; then
    "$UV" pip install --python "$dir/bin/python" "$@"
  else
    "$dir/bin/python" -m pip install --disable-pip-version-check "$@"
  fi
}

if [[ "$MODE" == "cpu" ]]; then
  step "1/4 创建 CPU 虚拟环境：$VENV"
  make_venv "$VENV"
  step "2/4 从 PyTorch CPU 索引安装 torch 2.14.1（只用这个索引，避免装上 CUDA 版）"
  pip_install "$VENV" --index-url "$TORCH_CPU_INDEX" "torch==2.14.1" \
    || fail "安装 torch 失败（见上方错误；常见原因：下载超时、Python 版本不匹配）"
  step "3/4 从 PyPI 安装其余锁定依赖"
  pip_install "$VENV" -r "$HERE/requirements-cpu.txt" || fail "安装 requirements-cpu.txt 失败"
  step "4/4 环境自检"
  "$VENV/bin/python" -I "$HERE/check_env.py"
  printf '\n完成。之后运行实验请使用：\n  %s labs/run_all.py\n或先激活环境：source "%s/bin/activate"\n' \
    "$VENV/bin/python" "$VENV"
else
  step "1/3 创建 GPU 虚拟环境：$VENV_GPU（与 CPU 环境分开：vllm 0.32.0 锁定 torch==2.13.0）"
  command -v nvidia-smi >/dev/null || echo "警告：未找到 nvidia-smi，本机可能没有 NVIDIA 驱动；安装后 GPU 实验仍会 SKIP"
  make_venv "$VENV_GPU"
  step "2/3 安装 requirements-gpu.txt（会拉取 CUDA 版 torch 与 triton，体积数 GB）"
  pip_install "$VENV_GPU" -r "$HERE/requirements-gpu.txt" || fail "安装 GPU 依赖失败（见 env/README.md 的排错说明）"
  pip_install "$VENV_GPU" "numpy==2.5.4" "matplotlib==3.11.2" || true
  step "3/3 环境自检"
  "$VENV_GPU/bin/python" -I "$HERE/check_env.py"
fi
