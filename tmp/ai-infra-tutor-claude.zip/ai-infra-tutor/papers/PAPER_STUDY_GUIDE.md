# 论文学习指南

> - **元数据**：所有论文的标题、作者、首次公开年份、链接都经过 arXiv API / Crossref / Semantic Scholar 核验（2026-10-18），完整清单见 `reading_list.csv`、`references.bib`，核验记录见 `SOURCES.md` 第 4 节。
> - **数字**：下文引用的实验数字都摘自论文摘要（arXiv 摘要是从核验时缓存的 API 响应中提取的；Orca 与 PyTorch 2 在线查看了官方页面和检索结果）。精读时请以论文正文为准。
> - **年份**：“首次公开年份”指 arXiv 首个版本或正式发表的较早者，不一定等于会议年份。
> - **精读问题**：每篇 3 题，编号 `Q-P-<id>-<n>`，参考答案要点在 `exercises/answers/papers.md`（作答前不得查看）。★ 表示 7 天计划内精读的 13 篇。

## 1. 系统论文的精读方法

### 1.1 三遍阅读法（与 M15 讲义一致）

| 遍数 | 用时 | 做什么 | 产出 |
| --- | --- | --- | --- |
| 第一遍 | 10~15 分钟 | 标题、摘要、引言最后的贡献列表、所有图表、结论 | 用三句话说清：问题、方法、效果；决定是否精读 |
| 第二遍 | 约 1 小时 | 读完正文，跳过证明和实现细节 | **系统架构图**；**实验设置复述表**；没看懂的问题列表 |
| 第三遍 | 2~4 小时 | 假装自己要重新实现 | 每个设计决策的“为什么”；论文**没有说出的假设**；200 字总结 + 1 个质疑点 |

### 1.2 怎样画系统架构图

1. 先画**组件**（方框）：例如调度器、KV 管理器、worker、存储。
2. 再画**数据流**（实线箭头）：请求、token、KV、梯度、参数怎样在组件之间流动，标出数据量级。
3. 最后画**控制流**（虚线箭头）：谁决定什么、何时触发。
4. 在图上标出论文的**新组件**（用颜色区分），对比基线系统的架构图——差异就是论文的贡献。

### 1.3 怎样复述实验设置

每篇论文都填写下面这张表（`notes_template.md` 中有空表）：

| 项目 | 内容 |
| --- | --- |
| 硬件 | GPU 型号与数量、节点内互连、节点间网络 |
| 模型 | 规模、结构（MHA/GQA、稠密/MoE） |
| 负载 | 数据集或 trace、请求长度分布、到达过程 |
| 基线 | 哪些系统、哪个版本、是否调优 |
| 指标 | 吞吐、延迟、goodput、MFU、显存 |
| 主要结论 | 一句话 |

### 1.4 怎样找出论文没有说出的假设

逐条追问：

- **负载**：如果请求长度分布、到达过程变了，结论还成立吗？
- **规模**：在 8 卡上成立的结论，在 1000 卡上成立吗？反过来呢？
- **硬件**：依赖 NVLink、高带宽网络或者某代 GPU 的特性吗？
- **基线**：基线是不是最新版本、有没有调过参？
- **指标**：有没有只报告平均值而不报告尾延迟？有没有忽略系统开销（例如编译时间、调度器 CPU 开销）？
- **适用范围**：方法对 MoE、长上下文、多模态是否同样有效？

这些问题的答案往往就是**下一篇论文的选题**，请写进问题卡片（`research/problem_card_template.md`）。

## 2. 论文演化图谱

### 2.1 推理服务

```text
Orca（迭代级调度，OSDI'22）
 └→ vLLM / PagedAttention（KV 分页管理，SOSP'23）
     ├→ SGLang / RadixAttention（前缀复用，NeurIPS'24）
     │    └→ Marconi（混合模型的前缀缓存）、LMCache / CacheBlend（跨实例 KV 复用）
     ├→ Sarathi → Sarathi-Serve（分块 prefill，OSDI'24）
     │    └→ POD-Attention、NanoFlow（单卡内重叠 prefill/decode 与资源）
     └→ DistServe / Splitwise（PD 分离，OSDI'24 / ISCA'24）
          └→ Mooncake（以 KV 为中心的分离架构）→ Dynamo / llm-d（工业编排）
               └→ MegaScale-Infer（注意力与 FFN 分离，面向 MoE）
```

### 2.2 流水线并行

```text
GPipe（同步，micro-batch + 重计算）
 └→ PipeDream（1F1B，异步 + 权重暂存）→ PipeDream-2BW
     └→ Megatron 同步 1F1B → 交错式 1F1B（SC'21）
         └→ Zero Bubble（拆分 B/W，ICLR'24）→ DualPipe（DeepSeek-V3，双向 + 计算通信重叠）
```

### 2.3 数据并行与显存

```text
Horovod（Ring AllReduce 进入深度学习）→ PyTorch DDP（分桶与重叠，VLDB'20）
 └→ ZeRO 1/2/3（SC'20）→ ZeRO-Offload / ZeRO-Infinity → ZeRO++（压缩通信）
     └→ PyTorch FSDP（VLDB'23）→ FSDP2（基于 DTensor）
Mixed Precision Training（FP16）→ BF16 → FP8 格式 → DeepSeek-V3 细粒度 FP8 → MXFP4 / NVFP4
Sublinear Memory（重计算）→ 选择性重计算 + 序列并行（Korthikanti et al.）
```

### 2.4 长序列与注意力

```text
FlashAttention → FlashAttention-2 → FlashAttention-3（Hopper）
 ├→ Ring Attention / 上下文并行 ──┐
 ├→ DeepSpeed-Ulysses ────────────┴→ USP / LoongTrain（2D 序列并行）
 └→ FlashInfer（推理服务的注意力引擎）、FlexAttention（编译器生成变体）
```

### 2.5 MoE

```text
GShard（top-2、容量、辅助损失）→ Switch Transformer（top-1）→ DeepSpeed-MoE、Tutel、MegaBlocks
 └→ DeepSeek-V3（细粒度专家、无辅助损失均衡、DeepEP）→ MegaScale-Infer、Step-3、JANUS（推理侧分离）
```

### 2.6 推理加速

```text
投机解码（Leviathan；Chen）→ Medusa（多头）→ EAGLE → EAGLE-2（动态树）→ EAGLE-3
LLM.int8()（离群值）→ SmoothQuant（W8A8）/ GPTQ（二阶 W4）/ AWQ（激活感知 W4）→ QServe（W4A8KV4）
StreamingLLM（sink）/ H2O（重要 token）→ SnapKV、Quest；KIVI（KV 2bit）
```

### 2.7 RL 后训练系统

```text
InstructGPT（RLHF 流程）→ DeepSpeed-Chat → OpenRLHF（Ray 分离部署）
 └→ HybridFlow / verl（混合控制器 + 3D-HybridEngine，EuroSys'25）
     └→ AReaL（全异步）、StreamRL、RLHFuse、AsyncFlow、ROLL Flash、Laminar、RollPacker（长尾）
```

## 3. 必读论文（36 篇，按模块与推荐顺序）

---

### M01 硬件与性能模型

#### ★ `roofline` — *Roofline: an insightful visual performance model for multicore architectures*
- Williams, Waterman, Patterson；CACM，2009；DOI：https://doi.org/10.1145/1498765.1498785 ；代码：无
- **一句话贡献**：用“算术强度 × 带宽”与“峰值算力”两条线，给出一个直观、可画图的性能上界模型，告诉你瓶颈在哪里、该优化什么。
- **问题与动机**：多核处理器种类繁多、性能特征各异，程序员和架构师缺少一个简单的模型来判断程序受计算还是受访存限制，以及离上限还有多远。
- **核心设计**：以算术强度（论文中称为 operational intensity）为横轴、可达性能为纵轴，画出由内存带宽斜线和峰值算力水平线组成的“屋顶”；再加入“天花板”（ceilings）表示缺少某种优化时的上限（例如没有 SIMD、没有利用 NUMA）。
- **关键实验**：在当时的几种多核平台上，用几个科学计算 kernel 说明模型如何指导优化。
- **局限与后续**：只有一条带宽线，不考虑缓存层次、延迟和开销；后续出现了分层 Roofline、考虑通信的 Roofline 等扩展。
- **与其他论文的关系**：是 FlashAttention 的 IO 分析、*Data Movement Is All You Need*、本课程 M01/M10 一切“访存受限”判断的基础。
- **对应实验**：M01-L01、M10-L01。
- **精读问题**：
  - Q-P-roofline-1：为什么用“可达性能 vs 算术强度”的对数坐标作图？它让哪些结论一目了然？
  - Q-P-roofline-2：论文中的“天花板”（ceilings）是什么？在 GPU 上它们分别对应什么（举两例）？
  - Q-P-roofline-3：Roofline 不能解释哪些现象？举出 M02 或 M11 实验中的一个例子。

---

### M03 算子与 Kernel

#### `triton` — *Triton: an intermediate language and compiler for tiled neural network computations*
- Tillet, Kung, Cox；MAPL@PLDI，2019；DOI：https://doi.org/10.1145/3315508.3329973 ；代码：https://github.com/triton-lang/triton
- **一句话贡献**：以“块（tile）”为基本单位的编程语言和编译器，让研究者不用手写 CUDA 就能写出高效的 GPU kernel。
- **问题与动机**：深度学习中不断出现新算子，厂商库覆盖不到；手写 CUDA 需要处理线程划分、共享内存、同步，门槛很高。
- **核心设计**：语言层面用块级的数据和运算表达计算；中间表示（Triton-IR）上做块级的优化；编译器自动处理合并访存、共享内存分配、线程内的并行化。
- **关键实验**：在矩阵乘和卷积等算子上与厂商库比较（具体数字请在精读时从正文提取）。
- **局限与后续**：对 Hopper 等新架构特性的利用需要编译器持续跟进；ThunderKittens、TileLang 等新 DSL 在探索更底层的控制。
- **关系**：TorchInductor 在 GPU 上生成 Triton kernel（`pt2`）；FlashAttention 有 Triton 版本的教程实现。
- **对应实验**：M03-L04（GPU 选做）、M03-L01。
- **精读问题**：
  - Q-P-triton-1：Triton 的编程单位（块）与 CUDA 的编程单位（线程）有什么不同？这让哪些工作从程序员转移给了编译器？
  - Q-P-triton-2：写一个 Triton kernel 时，你仍然需要自己决定哪些事情？
  - Q-P-triton-3：为什么说 Triton 降低了“新算子”的研究门槛？这对系统研究意味着什么？

#### ★ `fa1` — *FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness*
- Tri Dao 等；首次公开 2022（NeurIPS 2022）；https://arxiv.org/abs/2205.14135 ；代码：https://github.com/Dao-AILab/flash-attention
- **一句话贡献**：通过分块与重计算，让精确注意力不再把 N×N 矩阵写回 HBM，显存从 O(N²) 降到 O(N)，并显著提速。
- **问题与动机**：注意力的时间和显存随序列长度平方增长；已有的近似注意力减少了 FLOPs，但常常不提速，因为它们忽略了**访存（IO）**才是 GPU 上的主要开销。
- **核心设计**：(1) 分块：把 Q、K、V 分块搬进 SRAM，用在线 softmax 逐块累加；(2) 重计算：反向时用保存的归一化统计量重新计算注意力概率，不存 N×N 矩阵；(3) IO 复杂度分析：证明 HBM 访问量为 Θ(N²d²/M)，并给出下界。还提出了块稀疏版本。
- **关键实验**（摘要）：BERT-large（序列 512）端到端训练比 MLPerf 1.1 记录快 15%；GPT-2（序列 1K）快 3 倍；Long Range Arena（1K~4K）快 2.4 倍；更长的上下文带来更好的模型质量（GPT-2 困惑度降低 0.7）。
- **局限与后续**：只达到理论峰值的一小部分（FA2 摘要指出约 25~40%）；需要为每种新硬件重写；FA2 改进并行划分，FA3 利用 Hopper 的异步与 FP8。
- **关系**：基于 Roofline 的 IO 思想；是 Ring Attention、FlashInfer、FlexAttention 的基础。
- **对应实验**：M03-L03、M04-L01（激活显存中的 `5as/h` 项）。
- **精读问题**：
  - Q-P-fa1-1：为什么减少 FLOPs 的近似注意力常常不能提速，而 FlashAttention 没减少 FLOPs 却能提速？
  - Q-P-fa1-2：写出在线 softmax 合并两个块的公式，并说明反向传播为什么只需要保存每行的统计量。
  - Q-P-fa1-3：IO 复杂度 Θ(N²d²/M) 中的 M 是什么？它对块大小的选择有什么启示？

#### `fa2` — *FlashAttention-2: Faster Attention with Better Parallelism and Work Partitioning*
- Tri Dao；首次公开 2023（ICLR 2024）；https://arxiv.org/abs/2307.08691 ；代码：同上
- **一句话贡献**：通过减少非矩阵乘运算、在序列维度上并行、改进 warp 间的工作划分，把 FlashAttention 再提速约 2 倍。
- **问题与动机**（摘要）：FlashAttention 只达到理论峰值 FLOPs 的 25~40%，原因是线程块与 warp 之间的工作划分不佳。
- **核心设计**：(1) 调整算法，减少非矩阵乘的 FLOPs（矩阵乘有 Tensor Core 加速，其他运算没有）；(2) 即使对单个头，也把计算分到多个线程块上，提高占用率；(3) 在线程块内重新分配 warp 的工作，减少通过共享内存的通信。
- **关键实验**（摘要）：约 2 倍于 FlashAttention，在 A100 上达到理论峰值 FLOPs 的 50~73%；端到端训练 GPT 类模型时每张 A100 达到 225 TFLOPs/s（72% MFU）。
- **局限与后续**：针对 Ampere 优化，在 Hopper 上未充分利用新特性 → FA3。
- **对应实验**：M03-L03。
- **精读问题**：
  - Q-P-fa2-1：为什么“减少非矩阵乘 FLOPs”在 GPU 上很重要？
  - Q-P-fa2-2：在序列长度维度并行解决了什么场景下的问题（提示：batch 和头数都小时）？
  - Q-P-fa2-3：从 FA1 到 FA2，算法的数学没变，变的是什么？这说明 kernel 优化的哪一类工作最重要？

---

### M04 显存与精度

#### `mpt` — *Mixed Precision Training*
- Micikevicius 等；首次公开 2017（ICLR 2018）；https://arxiv.org/abs/1710.03740 ；相关实现：https://github.com/NVIDIA/apex （非论文官方代码）
- **一句话贡献**：用 FP16 存储权重、激活和梯度，同时用三个技巧保持与 FP32 相同的精度，显存减半并利用 Tensor Core 加速。
- **核心设计**：(1) 保留一份 FP32 主权重用于更新；(2) loss scaling 防止小梯度下溢；(3) 用 FP32 累加 FP16 乘积。
- **关键实验**（摘要）：在参数量超过 1 亿的大模型和大数据集上有效，显存消耗降低近一半；论文覆盖了多种任务和网络结构。
- **局限与后续**：FP16 的范围问题催生了 BF16；更低精度（FP8、FP4）需要更细粒度的缩放（`fp8fmt`、`dsv3`、`mxfp4`、`nvfp4`）。
- **对应实验**：M04-L02。
- **精读问题**：
  - Q-P-mpt-1：三个技巧分别解决什么数值问题？去掉任意一个会怎样？
  - Q-P-mpt-2：loss scaling 为什么不影响最终的权重更新（在没有溢出的情况下）？
  - Q-P-mpt-3：BF16 出现后，这三个技巧中哪个变得不必要、哪个仍然需要？

#### `sublinear` — *Training Deep Nets with Sublinear Memory Cost*
- Tianqi Chen 等；2016；https://arxiv.org/abs/1604.06174 ；相关实现：PyTorch `torch/utils/checkpoint.py`
- **一句话贡献**：系统地提出用重计算换显存，把 n 层网络的训练显存降到 O(√n)。
- **核心设计**：在计算图中选择检查点，只保存检查点处的激活，反向时从检查点重算；给出每 √n 层设检查点的策略，以及在一般计算图上的规划算法。
- **关键实验**（摘要）：把 1000 层残差网络在 ImageNet 上的显存从 48G 降到 7G，额外运行时间只有 30%。
- **局限与后续**：均匀检查点不考虑各层显存和计算的差异；选择性重计算（`seqpar`）和自动重计算规划是后续方向。
- **对应实验**：M04-L03。
- **精读问题**：
  - Q-P-sublinear-1：为什么每 √n 层设一个检查点时，显存是 O(√n)？写出推导。
  - Q-P-sublinear-2：重计算的额外开销为什么大约是“再做一次前向”？
  - Q-P-sublinear-3：在 Transformer 中，哪些激活最值得重算、哪些最不值得？（对照 `seqpar`）

---

### M05 集合通信

#### `patarasuk` — *Bandwidth optimal all-reduce algorithms for clusters of workstations*
- Patarasuk, Yuan；JPDC，2009；DOI：https://doi.org/10.1016/j.jpdc.2008.09.002 ；工业实现参照：https://github.com/NVIDIA/nccl
- **一句话贡献**：给出 AllReduce 通信量的下界，并证明基于环（ring）的算法能达到这个下界，即带宽最优。
- **核心设计**：分析每个节点至少要发送和接收的数据量；在树形拓扑上构造逻辑环，使每条链路只被使用一次方向，达到 `2(N−1)/N · S` 的通信量。
- **局限与后续**：没有考虑延迟项（轮数 2(N−1)）；大规模时树形、分层算法在延迟上更有优势；NCCL 在此基础上结合拓扑做了大量工程优化。
- **对应实验**：M05-L01、M05-L02。
- **精读问题**：
  - Q-P-patarasuk-1：为什么每个节点至少要发送约 `(N−1)/N · S` 的数据才能完成 ReduceScatter？
  - Q-P-patarasuk-2：“带宽最优”与“延迟最优”有什么区别？Ring 在哪方面不是最优？
  - Q-P-patarasuk-3：在 GPU 集群（节点内 NVLink、节点间 IB）上，直接套用扁平 Ring 有什么问题？

---

### M06 数据并行与 ZeRO

#### ★ `ddp` — *PyTorch Distributed: Experiences on Accelerating Data Parallel Training*
- Shen Li 等；首次公开 2020（VLDB 2020）；https://arxiv.org/abs/2006.15704 ；代码：https://github.com/pytorch/pytorch （`torch/nn/parallel/distributed.py`）
- **一句话贡献**：总结 PyTorch DDP 的设计与工程经验：梯度分桶、通信与计算重叠、跳过梯度同步，使数据并行接近线性扩展。
- **核心设计**：(1) 把梯度按反向顺序装入桶，桶满即异步发起 AllReduce；(2) 通过 autograd hook 在反向过程中触发通信，与计算重叠；(3) `no_sync` 跳过梯度累积期间的同步；以及参数广播、未使用参数的处理。
- **关键实验**（摘要）：配置得当时，在 256 张 GPU 上接近线性扩展；论文还比较了 NCCL 与 Gloo、不同桶大小的影响。
- **局限与后续**：每卡保存完整模型状态，模型变大后放不下 → ZeRO、FSDP。
- **对应实验**：M06-L01、M06-L03。
- **精读问题**：
  - Q-P-ddp-1：为什么桶要按“反向顺序”组织？如果按参数定义顺序会怎样？
  - Q-P-ddp-2：不同 rank 上桶的通信顺序必须一致，为什么？不一致会发生什么？
  - Q-P-ddp-3：论文中桶大小对性能的影响呈现什么规律？与 M06-L03 的模拟结果对照。

#### ★ `zero` — *ZeRO: Memory Optimizations Toward Training Trillion Parameter Models*
- Rajbhandari 等；首次公开 2019（SC 2020）；https://arxiv.org/abs/1910.02054 ；代码：https://github.com/deepspeedai/DeepSpeed
- **一句话贡献**：通过把数据并行中冗余的优化器状态、梯度、参数切分到各卡上，在保持数据并行易用性的同时大幅降低每卡显存。
- **问题与动机**：数据并行每卡都存完整的模型状态（混合精度 Adam 下 16Ψ 字节），模型并行又难用且跨节点扩展差。
- **核心设计**：ZeRO-DP 的三个阶段（切优化器状态 / 梯度 / 参数），以及 ZeRO-R（激活值分片、固定大小的缓冲区、显存碎片整理）。论文给出了每个阶段的显存与通信量分析。
- **关键实验**（摘要）：在 400 张 GPU 上训练超过 1000 亿参数的模型，获得超线性加速，吞吐达 15 PetaFLOPs；模型规模提高 8 倍、可达性能提高 10 倍；不使用模型并行也能训练最多 130 亿参数的模型。
- **局限与后续**：ZeRO-3 的通信增加 50%，而且需要预取与重叠才能高效；ZeRO-Offload/Infinity 进一步利用 CPU 和 NVMe；ZeRO++ 压缩通信。
- **对应实验**：M06-L02、M04-L01。
- **精读问题**：
  - Q-P-zero-1：为什么 ZeRO-1/2 的通信量与数据并行相同？请用 ReduceScatter 与 AllGather 解释。
  - Q-P-zero-2：论文为什么能获得“超线性”加速？
  - Q-P-zero-3：ZeRO 与 Megatron 式张量并行能否组合？各自适合什么规模？

#### `fsdp` — *PyTorch FSDP: Experiences on Scaling Fully Sharded Data Parallel*
- Yanli Zhao 等；首次公开 2023（VLDB 2023）；https://arxiv.org/abs/2304.11277 ；代码：https://github.com/pytorch/pytorch
- **一句话贡献**：在 PyTorch 中原生实现 ZeRO-3 风格的全分片数据并行，并与张量实现、分发器、显存分配器协同设计。
- **核心设计**：把模块包装成 FSDP 单元，参数展平后分片；前向/反向前 AllGather、用后释放，反向后 ReduceScatter；支持混合分片（节点内全分片、节点间复制）、延迟初始化、通信与计算重叠的控制。
- **关键实验**（摘要）：性能与 DDP 相当，同时支持大得多的模型，TFLOPS 近线性扩展。
- **对应实验**：M06-L02。
- **精读问题**：
  - Q-P-fsdp-1：为什么要把一个 FSDP 单元内的参数“展平”成一个大张量再分片？
  - Q-P-fsdp-2：混合分片（hybrid sharding）解决了什么问题？
  - Q-P-fsdp-3：FSDP 为什么需要与 CUDA 缓存分配器协同设计？（提示：频繁的分配和释放）

---

### M07 模型并行

#### ★ `megatron` — *Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism*
- Shoeybi 等；2019；https://arxiv.org/abs/1909.08053 ；代码：https://github.com/NVIDIA/Megatron-LM
- **一句话贡献**：只需在 PyTorch 中插入少量通信算子，就实现了高效的层内（张量）模型并行。
- **核心设计**：MLP 的第一个矩阵按列切、第二个按行切；注意力按头切；每层前向与反向各两次 AllReduce（f/g 共轭算子）；还讨论了 BERT 中 LayerNorm 的位置对扩展到大模型的影响。
- **关键实验**（摘要）：用 512 张 GPU 训练 83 亿参数的模型，整体持续 15.1 PetaFLOPs，相对单卡基线（39 TeraFLOPs，峰值的 30%）的扩展效率为 76%；训练了 83 亿参数的 GPT-2 类模型和 39 亿参数的 BERT 类模型，在 WikiText103 等任务上取得当时的最好结果。
- **局限与后续**：张量并行的通信量大，只适合节点内；跨节点需要流水线并行 → `megatron3d`；激活被复制 → 序列并行（`seqpar`）。
- **对应实验**：M07-L01。
- **精读问题**：
  - Q-P-megatron-1：如果把 MLP 的第一个矩阵按行切，会多出什么通信？为什么？
  - Q-P-megatron-2：f 和 g 两个共轭算子在前向、反向分别做什么？
  - Q-P-megatron-3：76% 的扩展效率是怎样计算的？基线为什么只有峰值的 30%？

#### ★ `megatron3d` — *Efficient Large-Scale Language Model Training on GPU Clusters Using Megatron-LM*
- Narayanan 等；首次公开 2021（SC 2021）；https://arxiv.org/abs/2104.04473 ；代码：同上
- **一句话贡献**：系统研究张量、流水线、数据三种并行的组合（PTD-P），提出交错式流水线调度，把万亿参数模型的训练做到高效。
- **核心设计**：分析三种并行的通信与计算特性，给出组合原则（张量并行放节点内、流水线跨节点、数据并行在最外层）；提出交错式 1F1B 调度；以及计算优化（算子融合）、通信优化（scatter/gather 减少跨节点流量）。
- **关键实验**（摘要）：交错式调度在显存相近的前提下提高 10% 以上的吞吐；在 3072 张 GPU 上以 502 PetaFLOP/s 训练 1 万亿参数模型，每卡达到理论峰值的 52%。
- **局限与后续**：配置靠经验法则；气泡与全局 batch 的矛盾仍在；后续有零气泡、自动并行（`alpa`）等。
- **对应实验**：M07-L02、M07-L03。
- **精读问题**：
  - Q-P-megatron3d-1：推导交错式调度的气泡率，并说明它的通信代价。
  - Q-P-megatron3d-2：论文给出的三条并行组合原则分别基于什么观察？
  - Q-P-megatron3d-3：为什么 micro-batch 大小同时影响 GEMM 效率、显存和气泡？

#### `seqpar` — *Reducing Activation Recomputation in Large Transformer Models*
- Korthikanti 等；首次公开 2022（MLSys 2023）；https://arxiv.org/abs/2205.05198 ；代码：https://github.com/NVIDIA/Megatron-LM
- **一句话贡献**：用序列并行和选择性重计算，在几乎不增加计算的前提下大幅减少激活显存。
- **核心设计**：给出 Transformer 每层激活显存的公式 `sbh(34 + 5as/h)`；序列并行把张量并行没有切到的 LayerNorm、dropout 等沿序列维切开；选择性重计算只重算注意力中占显存多、计算少的部分。
- **关键实验**（摘要）：激活显存减少 5 倍，重计算带来的执行时间开销减少 90% 以上；在 2240 张 A100 上训练 5300 亿参数的 GPT-3 类模型，MFU 达到 54.2%，比使用完全重计算时的 42.1% 快 29%。
- **对应实验**：M04-L01、M04-L03。
- **精读问题**：
  - Q-P-seqpar-1：`34` 和 `5as/h` 两项分别来自哪些张量？
  - Q-P-seqpar-2：序列并行为什么不增加通信量？
  - Q-P-seqpar-3：为什么选择性重计算的计算开销很小，却能省下大量显存？

#### `gpipe` — *GPipe: Efficient Training of Giant Neural Networks using Pipeline Parallelism*
- Yanping Huang 等；首次公开 2018（NeurIPS 2019）；https://arxiv.org/abs/1811.06965 ；第三方 PyTorch 实现：https://github.com/kakaobrain/torchgpipe
- **一句话贡献**：用 micro-batch 流水线加重计算，使任意由层序列组成的网络都能高效地扩展到多个加速器上，并保持同步训练的语义。
- **核心设计**：把模型切成若干 stage，把 batch 切成 micro-batch 依次流入；反向在所有前向之后进行；用重计算降低激活显存。
- **关键实验**（摘要）：训练 5.57 亿参数的 AmoebaNet，ImageNet top-1 达到 84.4%；训练 60 亿参数、128 层的多语言翻译 Transformer（覆盖 100 多种语言），质量超过所有双语模型。
- **局限与后续**：气泡；每个 stage 要保存 m 个 micro-batch 的激活 → 1F1B。
- **对应实验**：M07-L02。
- **精读问题**：
  - Q-P-gpipe-1：推导 GPipe 的气泡比例。
  - Q-P-gpipe-2：GPipe 为什么必须配合重计算？
  - Q-P-gpipe-3：同步流水线与 PipeDream 的异步流水线在训练语义上有什么区别？

#### `pipedream` — *PipeDream: Fast and Efficient Pipeline Parallel DNN Training*
- Narayanan 等；首次公开 2018（SOSP 2019）；https://arxiv.org/abs/1806.03377 ；代码：https://github.com/msr-fiddle/pipedream
- **一句话贡献**：提出 1F1B 调度和权重暂存，让流水线并行在不停顿的情况下保持较高利用率，并自动划分 stage。
- **核心设计**：1F1B 交替调度；权重暂存（weight stashing）保证同一个 micro-batch 的前向和反向使用同一版本的权重；基于 profiling 的自动划分（可以结合数据并行复制 stage）。
- **关键实验**（摘要）：相对数据并行最多减少 95% 的通信，并让通信与计算完全重叠；在五种 DNN、两个集群上，达到目标精度的时间最多快 5 倍。
- **局限与后续**：异步更新带来权重版本不一致（陈旧度）；Megatron 采用同步版的 1F1B；PipeDream-2BW 改进显存。
- **对应实验**：M07-L02。
- **精读问题**：
  - Q-P-pipedream-1：权重暂存解决什么问题？代价是什么？
  - Q-P-pipedream-2：为什么流水线并行比数据并行通信少？
  - Q-P-pipedream-3：1F1B 降低了峰值激活显存，用 M07-L02 的输出说明。

#### `alpa` — *Alpa: Automating Inter- and Intra-Operator Parallelism for Distributed Deep Learning*
- Lianmin Zheng 等；首次公开 2022（OSDI 2022）；https://arxiv.org/abs/2201.12023 ；代码：https://github.com/alpa-projects/alpa （已归档）
- **一句话贡献**：把并行策略分成算子间（流水线）和算子内（张量/数据）两个层次，自动搜索执行计划。
- **核心设计**：在算子内层次用整数线性规划选择每个算子的切分方式，在算子间层次用动态规划划分 stage 并把 stage 映射到设备网格；运行时负责两级并行的编排。
- **关键实验**（摘要）：生成的并行计划与手工调优的系统相当甚至更好，即使在那些系统专门设计的模型上；还能推广到结构异构、没有人工方案的模型。
- **局限与后续**：搜索开销与代价模型的准确性；仓库已归档，思想被后续的自动并行工作继承。
- **对应实验**：M07-L03。
- **精读问题**：
  - Q-P-alpa-1：为什么要把并行分成两个层次，而不是一起搜索？
  - Q-P-alpa-2：算子内层次的整数线性规划优化的目标是什么？
  - Q-P-alpa-3：自动并行系统的结论依赖哪些代价估计？它们在什么情况下会不准？

#### `ringattn` — *Ring Attention with Blockwise Transformers for Near-Infinite Context*
- Hao Liu、Matei Zaharia、Pieter Abbeel；首次公开 2023（ICLR）；https://arxiv.org/abs/2310.01889 ；代码：https://github.com/haoliuhl/ringattention
- **一句话贡献**：把序列分布到多个设备上，K/V 块沿环传递并与分块注意力计算完全重叠，使可训练的上下文长度随设备数线性增长。
- **核心设计**：分块计算注意力和前馈层；每个设备持有一段序列；每一步把本地 K/V 块发给下一个设备，同时用收到的块计算；用在线 softmax 合并。
- **关键实验**（摘要）：可训练和推理的序列长度达到以往显存高效 Transformer 的“设备数倍”，不需要近似、也不增加额外的通信与计算开销；在语言建模和强化学习任务上支持数百万 token 的上下文。
- **局限与后续**：因果掩码导致负载不均（zigzag 切分）；块计算必须足够长才能藏住通信；与 Ulysses 组合 → USP。
- **对应实验**：M07-L04。
- **精读问题**：
  - Q-P-ringattn-1：通信能被计算完全隐藏的条件是什么？用块大小、带宽、算力写出不等式。
  - Q-P-ringattn-2：因果掩码下为什么会负载不均？论文之后的工作怎样解决？
  - Q-P-ringattn-3：Ring Attention 与 FlashAttention 有什么共同的数学基础？

#### `ulysses` — *DeepSpeed Ulysses: System Optimizations for Enabling Training of Extreme Long Sequence Transformer Models*
- Sam Ade Jacobs 等；2023；https://arxiv.org/abs/2309.14509 ；代码：https://github.com/deepspeedai/DeepSpeed
- **一句话贡献**：用两次 All-to-All 在“按序列切分”和“按头切分”之间切换，实现通信量不随序列长度增长而爆炸的序列并行。
- **核心设计**：注意力前把 Q、K、V 从序列切分转为头切分，各设备对自己的头做完整注意力，再转回来；序列长度和设备数等比例增大时，每个设备的通信量保持不变。
- **关键实验**（摘要）：在 4 倍序列长度下，训练速度是当时最好基线的 2.5 倍。
- **局限与后续**：并行度受头数限制（GQA 下受 KV 头数限制）；USP、LoongTrain 把它与 Ring 组合。
- **对应实验**：M07-L04。
- **精读问题**：
  - Q-P-ulysses-1：为什么序列长度和设备数等比例增大时，Ulysses 每个设备的通信量不变？
  - Q-P-ulysses-2：Ulysses 的并行度上限是什么？GQA 让这个问题变好还是变坏？
  - Q-P-ulysses-3：比较 Ulysses 与 Ring Attention 的通信量（用 M07-L04 的输出说明）。

---

### M08 MoE 系统

#### `gshard` — *GShard: Scaling Giant Models with Conditional Computation and Automatic Sharding*
- Lepikhin 等；首次公开 2020（ICLR 2021）；https://arxiv.org/abs/2006.16668 ；代码：未核实到官方代码
- **一句话贡献**：用轻量的切分注解 API 加 XLA 的 SPMD 编译器，把稀疏门控 MoE Transformer 扩展到 6000 亿参数。
- **核心设计**：top-2 门控、专家容量与超出容量的丢弃、局部分组分发、辅助负载均衡损失；用户只需给少量张量加切分注解，编译器自动生成分布式程序。
- **关键实验**（摘要）：6000 亿参数的多语言翻译 MoE 模型在 2048 个 TPU v3 上用 4 天训练完成，从 100 种语言翻译到英语的质量远超以往。
- **局限与后续**：容量与丢弃影响质量；Switch Transformer 简化为 top-1；DeepSeek-V3 用无辅助损失的偏置法均衡负载。
- **对应实验**：M08-L01。
- **精读问题**：
  - Q-P-gshard-1：GShard 的辅助损失是怎样定义的？为什么需要它？
  - Q-P-gshard-2：专家容量和丢 token 的机制是什么？丢掉的 token 会怎样？
  - Q-P-gshard-3：SPMD 自动切分让用户只写“注解”，它的局限是什么？

#### `dsv3` — *DeepSeek-V3 Technical Report*
- DeepSeek-AI；技术报告，首次公开 2024；https://arxiv.org/abs/2412.19437 ；代码与相关库：https://github.com/deepseek-ai/DeepSeek-V3 （另有 DualPipe、DeepEP、DeepGEMM、FlashMLA）
- **一句话贡献**：在模型、算法、系统三个层面协同设计，以较低成本训练出 6710 亿总参数（每 token 激活 370 亿）的 MoE 模型。
- **核心设计**（摘要与报告）：MLA 与 DeepSeekMoE 架构；无辅助损失的负载均衡策略；多 token 预测训练目标；FP8 混合精度训练（细粒度缩放）；DualPipe 流水线调度与跨节点 All-to-All 通信优化；推理部署中的 PD 分离与冗余专家。
- **关键数字**（摘要）：671B 总参数、37B 激活参数；在 14.8 万亿 token 上预训练。
- **局限与后续**：报告中的许多工程细节依赖特定硬件与集群；复现成本高；推理侧的 MoE 部署引出 MegaScale-Infer 等工作。
- **对应实验**：M08-L01、M08-L02、M04-L02。
- **精读问题**：
  - Q-P-dsv3-1：无辅助损失负载均衡怎样调整偏置？为什么说它不干扰主任务？
  - Q-P-dsv3-2：FP8 训练中为什么要细粒度（分块）缩放？哪些算子仍保持较高精度？
  - Q-P-dsv3-3：DualPipe 相对 1F1B 改进了什么？它怎样处理跨节点 All-to-All 的通信？

---

### M09 大规模训练工程

#### `megascale` — *MegaScale: Scaling Large Language Model Training to More Than 10,000 GPUs*
- Ziheng Jiang 等；首次公开 2024（NSDI 2024）；https://arxiv.org/abs/2402.15627 ；代码：无公开代码
- **一句话贡献**：分享在一万张以上 GPU 上训练大模型的生产系统的设计与工程经验，覆盖效率与稳定性两方面。
- **核心设计**：算法与系统协同（例如并行 Transformer 块、滑动窗口注意力等模型改动）、计算与通信重叠、数据管道与网络调优；稳定性方面有故障检测与快速恢复、性能诊断工具（低开销地记录每个 rank 的事件）、慢节点定位。
- **关键实验**（摘要）：在 12288 张 GPU 上训练 1750 亿参数模型，MFU 达到 55.2%，是 Megatron-LM 的 1.34 倍。
- **局限与后续**：大量经验依赖特定集群；ByteRobust（SOSP'25）延续了稳定性方向。
- **对应实验**：M09-L01、M09-L02、M00-L02。
- **精读问题**：
  - Q-P-megascale-1：论文中哪些优化是“算法改动”，哪些是“系统优化”？它们分别提升了什么？
  - Q-P-megascale-2：论文怎样定位慢节点和故障？为什么需要专门的工具？
  - Q-P-megascale-3：55.2% 的 MFU 与 `megatron3d` 的 52% 能直接比较吗？列出需要对齐的条件。

---

### M11 推理服务系统

#### ★ `orca` — *Orca: A Distributed Serving System for Transformer-Based Generative Models*
- Gyeong-In Yu、Joo Seong Jeong、Geon-Woo Kim、Soojeong Kim、Byung-Gon Chun；OSDI 2022；https://www.usenix.org/conference/osdi22/presentation/yu （无 arXiv 版）；代码：无公开代码
- **一句话贡献**：提出迭代级调度和选择性批处理，开创了今天所有 LLM 推理引擎都在使用的“连续批处理”。
- **问题与动机**：请求级调度要等整批请求都结束才接纳新请求，早结束的请求白白占用资源，新请求等待时间长。
- **核心设计**：(1) 迭代级调度：每次模型迭代都重新决定批里有哪些请求；(2) 选择性批处理：长度不同的请求在注意力部分分开计算，在其他算子上合并成一批；以及分布式执行与流水线并行。
- **关键实验**（官方页面摘要）：在 GPT-3 175B 上，相同延迟下吞吐是 NVIDIA FasterTransformer 的 36.9 倍。
- **局限与后续**：KV 显存按最大长度预留，浪费严重 → vLLM；prefill 与 decode 的干扰 → Sarathi-Serve、DistServe。
- **对应实验**：M11-L02、M10-L02。
- **精读问题**：
  - Q-P-orca-1：为什么请求级调度在生成任务中特别低效？
  - Q-P-orca-2：选择性批处理中，为什么注意力不能直接批处理，而线性层可以？
  - Q-P-orca-3：Orca 没有解决的 KV 显存问题，具体表现是什么？

#### ★ `vllm` — *Efficient Memory Management for Large Language Model Serving with PagedAttention*
- Woosuk Kwon 等；首次公开 2023（SOSP 2023）；https://arxiv.org/abs/2309.06180 ；代码：https://github.com/vllm-project/vllm
- **一句话贡献**：借鉴操作系统的分页虚拟内存管理 KV Cache，几乎消除显存浪费，并支持请求内外的 KV 共享。
- **核心设计**：PagedAttention（KV 分块存储、按块表访问的注意力 kernel）；块管理器（按需分配、引用计数、写时复制）；支持并行采样、beam search 等的共享；抢占时的换出（swap）与重算（recompute）。
- **关键实验**（摘要）：KV 显存近零浪费；在相同延迟下，吞吐是 FasterTransformer、Orca 等系统的 2~4 倍。
- **局限与后续**：块表间接寻址的 kernel 开销；前缀共享的自动化（SGLang、APC）；块大小在异构模型中的问题（Jenga）。
- **对应实验**：M11-L01、M11-L02。
- **精读问题**：
  - Q-P-vllm-1：连续预分配有哪三种浪费？PagedAttention 分别怎样消除？
  - Q-P-vllm-2：写时复制在什么场景下触发？为什么它让并行采样几乎免费？
  - Q-P-vllm-3：抢占时选择换出还是重算，各自的代价是什么？在什么情况下哪种更好？

#### `sglang` — *SGLang: Efficient Execution of Structured Language Model Programs*
- Lianmin Zheng 等；首次公开 2023（NeurIPS 2024）；https://arxiv.org/abs/2312.07104 ；代码：https://github.com/sgl-project/sglang
- **一句话贡献**：前端语言加运行时的协同设计；运行时用 RadixAttention 在多次调用间自动复用 KV Cache。
- **核心设计**：RadixAttention（用基数树管理所有请求的 KV，最长前缀匹配、LRU 驱逐、缓存感知调度）；用压缩有限状态机加速结构化输出；面向 API 模型的投机执行。
- **关键实验**（摘要）：在智能体控制、逻辑推理、few-shot、JSON 解码、RAG、多轮对话等任务上，吞吐最高是当时最好推理系统的 6.4 倍。
- **局限与后续**：推理模型、agentic 负载下的缓存污染（sglang #22373）；混合架构（SSM、滑动窗口注意力）的前缀缓存（Marconi、Unified Radix Cache）。
- **对应实验**：M11-L03。
- **精读问题**：
  - Q-P-sglang-1：为什么用基数树而不是哈希表管理前缀？各有什么优缺点？
  - Q-P-sglang-2：缓存感知调度怎样提高命中率？它可能带来什么公平性问题？
  - Q-P-sglang-3：LRU 驱逐在推理模型多轮对话中为什么效果不好？（对照 M11-L03）

#### `sarathiserve` — *Taming Throughput-Latency Tradeoff in LLM Inference with Sarathi-Serve*
- Amey Agrawal 等；首次公开 2024（OSDI 2024）；https://arxiv.org/abs/2403.02310 ；代码：https://github.com/microsoft/sarathi-serve
- **一句话贡献**：用分块 prefill 和“不停顿”的调度，在高吞吐与低 TPOT 之间取得更好的平衡。
- **核心设计**：把 prefill 切成块，与正在进行的 decode 组成同一批；每次迭代有 token 预算，保证 decode 不被长 prefill 阻塞（stall-free）。
- **关键实验**（摘要）：Mistral-7B 单张 A100 上服务容量是 vLLM 的 2.6 倍；Yi-34B 两张 A100 上最高 3.7 倍；Falcon-180B 配合流水线并行时，端到端服务容量最高提升 5.6 倍。
- **局限与后续**：块太小会降低 prefill 效率、拉长 TTFT；与 PD 分离的取舍。
- **对应实验**：M11-L02、M15-L02。
- **精读问题**：
  - Q-P-sarathiserve-1：分块 prefill 为什么能消除 decode 的“停顿”？
  - Q-P-sarathiserve-2：token 预算怎样选择？太大和太小分别损害哪个指标？
  - Q-P-sarathiserve-3：“服务容量”这个指标是怎样定义的？与 goodput 有什么关系？

#### ★ `distserve` — *DistServe: Disaggregating Prefill and Decoding for Goodput-optimized Large Language Model Serving*
- Yinmin Zhong 等；首次公开 2024（OSDI 2024）；https://arxiv.org/abs/2401.09670 ；代码：https://github.com/LLMServe/DistServe
- **一句话贡献**：把 prefill 和 decode 分到不同 GPU 上，分别优化资源分配和并行策略，以最大化每 GPU 的 goodput。
- **核心设计**：明确提出 goodput（满足 TTFT 与 TPOT SLO 的请求速率）作为优化目标；分析 prefill 与 decode 的干扰和资源耦合；按集群带宽决定两类实例的放置，搜索各自的并行配置与数量配比。
- **关键实验**（摘要）：在多种模型、应用和延迟要求下，与当时最好的系统相比，DistServe 能服务 7.4 倍的请求，或者满足严格 12.6 倍的 SLO，同时让 90% 以上的请求满足延迟约束。
- **局限与后续**：配比是离线搜索的，负载变化时需要调整；KV 传输依赖高带宽网络 → Mooncake、Dynamo、llm-d。
- **对应实验**：M11-L04、M00-L01。
- **精读问题**：
  - Q-P-distserve-1：goodput 与吞吐有什么区别？为什么它更适合作为优化目标？
  - Q-P-distserve-2：prefill 与 decode 放在一起时，有哪两类“耦合”？
  - Q-P-distserve-3：论文怎样搜索 prefill 与 decode 实例的配比与并行配置？负载变化时会怎样？

#### `mooncake` — *Mooncake: A KVCache-centric Disaggregated Architecture for LLM Serving*
- Ruoyu Qin 等；首次公开 2024（ACM TOS）；https://arxiv.org/abs/2407.00079 ；代码：https://github.com/kvcache-ai/Mooncake
- **一句话贡献**：月之暗面 Kimi 的服务平台：以 KV Cache 为中心，把 GPU 集群中闲置的 CPU、DRAM、SSD 组成分布式 KV 缓存池，实现 PD 分离与跨请求复用。
- **核心设计**：KV 为中心的调度器在吞吐与 SLO 之间权衡；面向长上下文与过载场景，基于预测的提前拒绝策略。
- **关键实验**（摘要）：在部分模拟场景下吞吐最多提高 525%（满足 SLO）；在真实负载下让 Kimi 多处理 75% 的请求。
- **对应实验**：M11-L04、M11-L03。
- **精读问题**：
  - Q-P-mooncake-1：为什么说 Mooncake 是“以 KV Cache 为中心”的？与 DistServe 的出发点有何不同？
  - Q-P-mooncake-2：过载时为什么要“提前拒绝”请求？预测错了会怎样？
  - Q-P-mooncake-3：把 KV 存在 CPU 内存和 SSD 上，对 TTFT 有什么影响？什么时候值得？

---

### M12 推理加速

#### ★ `specdec` — *Fast Inference from Transformers via Speculative Decoding*
- Yaniv Leviathan、Matan Kalman、Yossi Matias；首次公开 2022（ICML 2023）；https://arxiv.org/abs/2211.17192 ；代码：无官方代码
- **一句话贡献**：用小模型提议、大模型并行验证，加上新的采样方法，在不改变输出分布的前提下加速自回归解码。
- **核心设计**：投机采样的接受/拒绝规则与残差分布重采样；期望加速比的理论分析（接受率 α、提议长度 γ、成本比 c）。
- **关键实验**（摘要）：在 T5-XXL 上相对标准 T5X 实现加速 2~3 倍，输出完全相同。
- **局限与后续**：需要合适的 draft 模型；大 batch 下收益下降；Medusa、EAGLE 改进 draft。
- **对应实验**：M12-L01。
- **精读问题**：
  - Q-P-specdec-1：证明投机采样输出的分布等于 target 的分布。
  - Q-P-specdec-2：推导期望每次验证产出的 token 数。
  - Q-P-specdec-3：论文的加速分析隐含了什么关于硬件的假设？在什么条件下失效？

#### `eagle` — *EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty*
- Yuhui Li 等；首次公开 2024（ICML 2024）；https://arxiv.org/abs/2401.15077 ；代码：https://github.com/SafeAILab/EAGLE
- **一句话贡献**：在特征层（倒数第二层隐藏状态）而不是 token 层做自回归预测，并输入提前一步的 token 以消除不确定性，大幅提高接受率。
- **关键实验**（摘要）：在 LLaMA2-Chat 70B 上延迟加速 2.7~3.5 倍、吞吐翻倍，同时保持生成文本的分布不变；评测覆盖 Vicuna、LLaMA2-Chat 系列和 Mixtral 8x7B。
- **局限与后续**：需要为每个目标模型训练 draft 头；EAGLE-2 用动态草稿树；EAGLE-3 融合多层特征。
- **对应实验**：M12-L01。
- **精读问题**：
  - Q-P-eagle-1：为什么在特征层预测比在 token 层预测更容易？
  - Q-P-eagle-2：“特征不确定性”指什么？EAGLE 怎样处理？
  - Q-P-eagle-3：EAGLE 与 Medusa 的主要区别是什么？

#### `llmint8` — *LLM.int8(): 8-bit Matrix Multiplication for Transformers at Scale*
- Tim Dettmers 等；首次公开 2022（NeurIPS 2022）；https://arxiv.org/abs/2208.07339 ；代码：https://github.com/bitsandbytes-foundation/bitsandbytes
- **一句话贡献**：发现大模型中的“涌现离群特征”，提出向量级量化加混合精度分解，使 1750 亿参数模型能直接用 INT8 推理而不损失精度。
- **关键实验**（摘要）：推理显存减半，同时保持全精度的效果；1750 亿参数的 16/32 位检查点可以加载、转换为 INT8 并直接使用。
- **局限与后续**：混合精度分解的计算路径不规整，速度受影响 → SmoothQuant 等方案追求纯 INT8 计算。
- **对应实验**：M12-L02。
- **精读问题**：
  - Q-P-llmint8-1：离群特征有什么特点（出现在哪些维度、随模型规模怎样变化）？
  - Q-P-llmint8-2：混合精度分解怎样工作？为什么只有很少的维度走 FP16？
  - Q-P-llmint8-3：为什么 LLM.int8() 能省显存却不一定提速？

#### `gptq` — *GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers*
- Elias Frantar 等；首次公开 2022（ICLR 2023）；https://arxiv.org/abs/2210.17323 ；代码：https://github.com/IST-DASLab/gptq
- **一句话贡献**：基于近似二阶信息的一次性权重量化方法，能在几个 GPU 小时内把千亿参数模型量化到 3~4 bit。
- **关键实验**（摘要）：约 4 个 GPU 小时把 1750 亿参数的 GPT 模型量化到每个权重 3 或 4 bit，精度损失可以忽略；压缩收益是以往一次性量化方法的两倍以上；首次让 1750 亿参数模型在单张 GPU 上做生成推理。
- **对应实验**：M12-L02（练习 Q-M12-L3-02 实现简化版）。
- **精读问题**：
  - Q-P-gptq-1：GPTQ 怎样利用 Hessian 信息补偿量化误差？
  - Q-P-gptq-2：为什么逐列量化、并把误差传到后面的列是有效的？
  - Q-P-gptq-3：GPTQ 为什么需要校准数据？校准数据的选择会怎样影响结果？

#### ★ `awq` — *AWQ: Activation-aware Weight Quantization for LLM Compression and Acceleration*
- Ji Lin 等；首次公开 2023（MLSys 2024）；https://arxiv.org/abs/2306.00978 ；代码：https://github.com/mit-han-lab/llm-awq
- **一句话贡献**：只需保护约 1% 的重要权重通道（按激活幅值判断）就能大幅降低量化误差；用等价缩放代替混合精度，硬件友好。
- **关键实验**（摘要）：配套的 TinyChat 推理框架在桌面和移动 GPU 上比 Hugging Face FP16 实现快 3 倍以上，并能在移动 GPU 上部署 70B 的 Llama-2。
- **局限与后续**：仅量化权重（W4A16）；QServe 进一步做 W4A8KV4。
- **对应实验**：M12-L02。
- **精读问题**：
  - Q-P-awq-1：为什么按激活幅值而不是权重幅值判断重要通道？
  - Q-P-awq-2：缩放为什么能降低重要通道的量化误差？缩放系数怎样搜索？
  - Q-P-awq-3：AWQ 与 GPTQ 都是 W4 量化，主要区别是什么？

#### `smoothquant` — *SmoothQuant: Accurate and Efficient Post-Training Quantization for Large Language Models*
- Guangxuan Xiao 等；首次公开 2022（ICML 2023）；https://arxiv.org/abs/2211.10438 ；代码：https://github.com/mit-han-lab/smoothquant
- **一句话贡献**：用数学等价的缩放把激活的量化难度迁移给权重，实现无需训练的 W8A8 量化。
- **关键实验**（摘要）：适用于 OPT、BLOOM、GLM、MT-NLG、Llama、Falcon、Mistral、Mixtral 等模型；最高 1.56 倍加速、显存减半，精度损失可以忽略；可以在单个节点内部署 5300 亿参数的模型。
- **对应实验**：M12-L02。
- **精读问题**：
  - Q-P-smoothquant-1：写出 SmoothQuant 的等价变换，并说明 α 的含义。
  - Q-P-smoothquant-2：为什么激活难量化而权重容易量化？
  - Q-P-smoothquant-3：迁移强度 α 太大会怎样？（对照 M12-L02 的 U 形曲线）

---

### M13 编译器

#### `tvm` — *TVM: An Automated End-to-End Optimizing Compiler for Deep Learning*
- Tianqi Chen 等；首次公开 2018（OSDI 2018）；https://arxiv.org/abs/1802.04799 ；代码：https://github.com/apache/tvm
- **一句话贡献**：同时做图级和算子级优化、并用学习得到的代价模型自动调优的端到端深度学习编译器，提供跨硬件的性能可移植性。
- **核心设计**：图级算子融合；张量表达式与调度原语（借鉴 Halide 的计算/调度分离）；映射到硬件原语、隐藏访存延迟；基于机器学习的代价模型加速调度搜索。
- **关键实验**（摘要）：在低功耗 CPU、移动 GPU、服务器 GPU 上，性能可以与手工调优的库竞争；还能面向基于 FPGA 的新加速器。
- **局限与后续**：调度模板需要人工编写 → Ansor 自动生成搜索空间；MetaSchedule、TensorIR 等后续工作。
- **对应实验**：M13-L01、M13-L03。
- **精读问题**：
  - Q-P-tvm-1：为什么要把“计算”和“调度”分开表达？
  - Q-P-tvm-2：TVM 的代价模型解决了什么问题？用什么特征？
  - Q-P-tvm-3：图级融合的规则怎样分类算子（例如单射、可规约、复杂可融合）？

#### ★ `pt2` — *PyTorch 2: Faster Machine Learning Through Dynamic Python Bytecode Transformation and Graph Compilation*
- Jason Ansel 等；ASPLOS 2024；DOI：https://doi.org/10.1145/3620665.3640366 （无 arXiv 版）；代码：https://github.com/pytorch/pytorch
- **一句话贡献**：介绍 torch.compile 背后的 TorchDynamo（Python 字节码层面的图捕获）和 TorchInductor（默认编译后端），在保持 eager 编程体验的同时获得编译带来的加速。
- **核心设计**：TorchDynamo 拦截 Python 帧的执行、把 PyTorch 运算提取成 FX 图、无法处理时断开图并回退；guard 机制与动态形状；AOTAutograd 生成反向图；TorchInductor 在 GPU 上生成 Triton、在 CPU 上生成 C++。
- **关键实验**（摘要）：TorchDynamo 比以往方法更稳健地捕获计算图且开销很小；TorchInductor 在 NVIDIA A100 上对 180 多个真实模型取得推理 2.27 倍、训练 1.41 倍的几何平均加速，优于其他六种编译器。
- **局限与后续**：图断裂和重编译削弱收益；编译时间；分布式与编译的结合（例如与 FSDP2 配合）。
- **对应实验**：M13-L02、M02-L03。
- **精读问题**：
  - Q-P-pt2-1：TorchDynamo 为什么选择在字节码层面工作，而不是像 TorchScript 那样追踪或解析源码？
  - Q-P-pt2-2：guard 是什么？它与重编译有什么关系？
  - Q-P-pt2-3：几何平均加速 2.27 倍意味着什么？为什么用几何平均？

---

### M14 RL 后训练系统

#### ★ `hybridflow` — *HybridFlow: A Flexible and Efficient RLHF Framework*
- Guangming Sheng 等；首次公开 2024（EuroSys 2025）；https://arxiv.org/abs/2409.19256 ；代码：https://github.com/verl-project/verl （原 volcengine/verl）
- **一句话贡献**：用“单控制器 + 多控制器”的混合编程模型灵活表达 RLHF 数据流，并用 3D-HybridEngine 在训练与生成之间高效地重切分模型。
- **核心设计**：单控制器管理节点间的数据流（灵活地组合 actor、critic、参考模型、奖励模型），多控制器负责节点内的分布式计算（高效）；3D-HybridEngine 在训练与生成两个阶段之间对 actor 做零冗余的重切分，减少通信；支持多种模型放置策略。
- **关键实验**（摘要）：运行多种 RLHF 算法时，吞吐是当时最好基线的 1.53~20.57 倍。
- **局限与后续**：同步执行的长尾问题；异步 RL（AReaL、StreamRL 等）；权重同步的工程问题（verl 的 issue 与 PR）。
- **对应实验**：M14-L01、M14-L02。
- **精读问题**：
  - Q-P-hybridflow-1：为什么单控制器灵活、多控制器高效？HybridFlow 怎样兼得？
  - Q-P-hybridflow-2：训练和生成阶段为什么需要不同的并行布局？重切分的开销来自哪里？
  - Q-P-hybridflow-3：1.53~20.57 倍的跨度很大，说明了什么？精读时应怎样检查基线和场景？

---

## 4. 选读论文（42 篇）

按模块列出；阅读时先做第一遍速读，与选题相关的再精读。代码链接只列出经 GitHub API 核验过的仓库。

| 模块 | id | 标题 | 首次公开 | 发表处 | 论文链接 | 代码 |
| --- | --- | --- | --- | --- | --- | --- |
| M00 | `mlsysfrontier` | MLSys: The New Frontier of Machine Learning Systems | 2019 | arXiv 预印本 | https://arxiv.org/abs/1904.03257 | — |
| M01 | `datamove` | Data Movement Is All You Need: A Case Study on Optimizing Transformers | 2020 | MLSys | https://arxiv.org/abs/2007.00072 | — |
| M02 | `pytorch19` | PyTorch: An Imperative Style, High-Performance Deep Learning Library | 2019 | NeurIPS | https://arxiv.org/abs/1912.01703 | https://github.com/pytorch/pytorch |
| M03 | `fa3` | FlashAttention-3: Fast and Accurate Attention with Asynchrony and Low-precision | 2024 | NeurIPS | https://arxiv.org/abs/2407.08608 | https://github.com/Dao-AILab/flash-attention |
| M04 | `zerooffload` | ZeRO-Offload: Democratizing Billion-Scale Model Training | 2021 | USENIX ATC | https://arxiv.org/abs/2101.06840 | https://github.com/deepspeedai/DeepSpeed |
| M04 | `zeroinf` | ZeRO-Infinity: Breaking the GPU Memory Wall for Extreme Scale Deep Learning | 2021 | SC | https://arxiv.org/abs/2104.07857 | https://github.com/deepspeedai/DeepSpeed |
| M04 | `fp8fmt` | FP8 Formats for Deep Learning | 2022 | arXiv 预印本 | https://arxiv.org/abs/2209.05433 | https://github.com/NVIDIA/TransformerEngine |
| M05 | `horovod` | Horovod: fast and easy distributed deep learning in TensorFlow | 2018 | arXiv 预印本 | https://arxiv.org/abs/1802.05799 | https://github.com/horovod/horovod（已归档） |
| M06 | `amsp` | AMSP: Reducing Communication Overhead of ZeRO for Efficient LLM Training | 2023 | arXiv 预印本 | https://arxiv.org/abs/2311.00257 | — |
| M06 | `zeropp` | ZeRO++: Extremely Efficient Collective Communication for Giant Model Training | 2023 | arXiv 预印本 | https://arxiv.org/abs/2306.10209 | https://github.com/deepspeedai/DeepSpeed |
| M07 | `pipedream2bw` | Memory-Efficient Pipeline-Parallel DNN Training | 2020 | ICML | https://arxiv.org/abs/2006.09503 | — |
| M07 | `zerobubble` | Zero Bubble Pipeline Parallelism | 2023 | ICLR | https://arxiv.org/abs/2401.10241 | https://github.com/sail-sg/zero-bubble-pipeline-parallelism |
| M08 | `switch` | Switch Transformers: Scaling to Trillion Parameter Models with Simple and Efficient Sparsity | 2021 | JMLR | https://arxiv.org/abs/2101.03961 | — |
| M08 | `dsmoe` | DeepSpeed-MoE: Advancing Mixture-of-Experts Inference and Training to Power Next-Generation AI Scale | 2022 | ICML | https://arxiv.org/abs/2201.05596 | https://github.com/deepspeedai/DeepSpeed |
| M08 | `tutel` | Tutel: Adaptive Mixture-of-Experts at Scale | 2022 | MLSys | https://arxiv.org/abs/2206.03382 | https://github.com/microsoft/Tutel |
| M08 | `megablocks` | MegaBlocks: Efficient Sparse Training with Mixture-of-Experts | 2022 | MLSys | https://arxiv.org/abs/2211.15841 | https://github.com/databricks/megablocks |
| M09 | `bamboo` | Bamboo: Making Preemptible Instances Resilient for Affordable Training of Large DNNs | 2022 | NSDI | https://arxiv.org/abs/2204.12013 | — |
| M09 | `oobleck` | Oobleck: Resilient Distributed Training of Large Models Using Pipeline Templates | 2023 | SOSP | https://arxiv.org/abs/2309.08125 | — |
| M09 | `gemini_ckpt` | GEMINI: Fast Failure Recovery in Distributed Training with In-Memory Checkpoints | 2023 | SOSP | https://doi.org/10.1145/3600006.3613145 | — |
| M09 | `llama3` | The Llama 3 Herd of Models | 2024 | 技术报告 | https://arxiv.org/abs/2407.21783 | — |
| M09 | `acme` | Characterization of Large Language Model Development in the Datacenter | 2024 | NSDI | https://arxiv.org/abs/2403.07648 | — |
| M09 | `bytecheckpoint` | ByteCheckpoint: A Unified Checkpointing System for Large Foundation Model Development | 2024 | NSDI | https://arxiv.org/abs/2407.20143 | — |
| M10 | `flexgen` | FlexGen: High-Throughput Generative Inference of Large Language Models with a Single GPU | 2023 | ICML | https://arxiv.org/abs/2303.06865 | https://github.com/FMInference/FlexLLMGen（已归档） |
| M11 | `sarathi` | SARATHI: Efficient LLM Inference by Piggybacking Decodes with Chunked Prefills | 2023 | arXiv 预印本 | https://arxiv.org/abs/2308.16369 | https://github.com/microsoft/sarathi-serve |
| M11 | `splitwise` | Splitwise: Efficient generative LLM inference using phase splitting | 2023 | ISCA | https://arxiv.org/abs/2311.18677 | https://github.com/mutinifni/splitwise-sim |
| M11 | `llumnix` | Llumnix: Dynamic Scheduling for Large Language Model Serving | 2024 | OSDI | https://arxiv.org/abs/2406.03243 | https://github.com/llumnix-project/llumnix-ray |
| M11 | `tetriinfer` | Inference without Interference: Disaggregate LLM Inference for Mixed Downstream Workloads | 2024 | arXiv 预印本 | https://arxiv.org/abs/2401.11181 | — |
| M11 | `dejavu` | DéjàVu: KV-cache Streaming for Fast, Fault-tolerant Generative LLM Serving | 2024 | ICML | https://arxiv.org/abs/2403.01876 | — |
| M12 | `cachegen` | CacheGen: KV Cache Compression and Streaming for Fast Large Language Model Serving | 2023 | SIGCOMM | https://arxiv.org/abs/2310.07240 | https://github.com/UChi-JCL/CacheGen |
| M12 | `specsample` | Accelerating Large Language Model Decoding with Speculative Sampling | 2023 | arXiv 预印本 | https://arxiv.org/abs/2302.01318 | — |
| M12 | `h2o` | H$_2$O: Heavy-Hitter Oracle for Efficient Generative Inference of Large Language Models | 2023 | NeurIPS | https://arxiv.org/abs/2306.14048 | https://github.com/FMInference/H2O |
| M12 | `streamingllm` | Efficient Streaming Language Models with Attention Sinks | 2023 | ICLR | https://arxiv.org/abs/2309.17453 | https://github.com/mit-han-lab/streaming-llm |
| M12 | `medusa` | Medusa: Simple LLM Inference Acceleration Framework with Multiple Decoding Heads | 2024 | ICML | https://arxiv.org/abs/2401.10774 | https://github.com/FasterDecoding/Medusa |
| M12 | `eagle2` | EAGLE-2: Faster Inference of Language Models with Dynamic Draft Trees | 2024 | EMNLP | https://arxiv.org/abs/2406.16858 | https://github.com/SafeAILab/EAGLE |
| M12 | `kivi` | KIVI: A Tuning-Free Asymmetric 2bit Quantization for KV Cache | 2024 | ICML | https://arxiv.org/abs/2402.02750 | https://github.com/jy-yuan/KIVI |
| M12 | `snapkv` | SnapKV: LLM Knows What You are Looking for Before Generation | 2024 | NeurIPS | https://arxiv.org/abs/2404.14469 | https://github.com/FasterDecoding/SnapKV |
| M13 | `ansor` | Ansor: Generating High-Performance Tensor Programs for Deep Learning | 2020 | OSDI | https://arxiv.org/abs/2006.06762 | https://github.com/apache/tvm |
| M13 | `mlir` | MLIR: A Compiler Infrastructure for the End of Moore's Law | 2020 | arXiv 预印本 | https://arxiv.org/abs/2002.11054 | — |
| M14 | `instructgpt` | Training language models to follow instructions with human feedback | 2022 | NeurIPS | https://arxiv.org/abs/2203.02155 | — |
| M14 | `dschat` | DeepSpeed-Chat: Easy, Fast and Affordable RLHF Training of ChatGPT-like Models at All Scales | 2023 | arXiv 预印本 | https://arxiv.org/abs/2308.01320 | https://github.com/deepspeedai/DeepSpeed |
| M14 | `openrlhf` | OpenRLHF: An Easy-to-use, Scalable and High-performance RLHF Framework | 2024 | arXiv 预印本 | https://arxiv.org/abs/2405.11143 | https://github.com/OpenRLHF/OpenRLHF |
| M14 | `dsr1` | DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement Learning | 2025 | Nature | https://arxiv.org/abs/2501.12948 | — |

## 5. 最近两年的前沿论文（46 篇）

其中 35 篇首次公开于 2024-10 之后；另有 11 篇首次公开于 2024 年 5~9 月、但之后才正式发表或被广泛采用的工作（`cacheblend`、`dynamollm`、`fp8trillion`、`loongtrain`、`memserve`、`nanoflow`、`optimus`、`qserve`、`quest`、`rlhfuse`、`usp`）。前沿工作结论尚未经过时间检验，引用时请注意版本（arXiv 可能有多个修订版）。

| 模块 | id | 标题 | 首次公开 | 发表处 | 论文链接 | 代码 |
| --- | --- | --- | --- | --- | --- | --- |
| M03 | `thunderkittens` | ThunderKittens: Simple, Fast, and Adorable AI Kernels | 2024 | arXiv 预印本 | https://arxiv.org/abs/2410.20399 | https://github.com/HazyResearch/ThunderKittens |
| M03 | `tilelang` | TileLang: A Composable Tiled Programming Model for AI Systems | 2025 | arXiv 预印本 | https://arxiv.org/abs/2504.17577 | https://github.com/tile-ai/tilelang |
| M04 | `fp8trillion` | Scaling FP8 training to trillion-token LLMs | 2024 | ICLR | https://arxiv.org/abs/2409.12517 | — |
| M04 | `mxfp4` | Training LLMs with MXFP4 | 2025 | AISTATS | https://arxiv.org/abs/2502.20586 | — |
| M04 | `nvfp4` | Pretraining Large Language Models with NVFP4 | 2025 | arXiv 预印本 | https://arxiv.org/abs/2509.25149 | https://github.com/NVIDIA/TransformerEngine |
| M05 | `nccl` | Demystifying NCCL: An In-depth Analysis of GPU Communication Protocols and Algorithms | 2025 | HOTI | https://arxiv.org/abs/2507.04786 | https://github.com/NVIDIA/nccl |
| M05 | `comm100k` | Collective Communication for 100k+ GPUs | 2025 | arXiv 预印本 | https://arxiv.org/abs/2510.20171 | — |
| M05 | `tritondist` | Triton-distributed: Programming Overlapping Kernels on Distributed AI Systems with the Triton Compiler | 2025 | arXiv 预印本 | https://arxiv.org/abs/2504.19442 | — |
| M07 | `usp` | USP: A Unified Sequence Parallelism Approach for Long Context Generative AI | 2024 | arXiv 预印本 | https://arxiv.org/abs/2405.07719 | https://github.com/feifeibear/long-context-attention |
| M07 | `loongtrain` | LoongTrain: Efficient Training of Long-Sequence LLMs with Head-Context Parallelism | 2024 | arXiv 预印本 | https://arxiv.org/abs/2406.18485 | https://github.com/InternLM/InternEvo |
| M08 | `megascaleinfer` | MegaScale-Infer: Serving Mixture-of-Experts at Scale with Disaggregated Expert Parallelism | 2025 | arXiv 预印本 | https://arxiv.org/abs/2504.02263 | — |
| M08 | `janus` | Janus: Disaggregating Attention and Experts for Scalable MoE Inference | 2025 | arXiv 预印本 | https://arxiv.org/abs/2512.13525 | — |
| M08 | `step3` | Step-3 is Large yet Affordable: Model-system Co-design for Cost-effective Decoding | 2025 | arXiv 预印本 | https://arxiv.org/abs/2507.19427 | — |
| M09 | `reliability` | Revisiting Reliability in Large-Scale Machine Learning Research Clusters | 2024 | ISCA | https://arxiv.org/abs/2410.21680 | — |
| M09 | `optimus` | Optimus: Accelerating Large-Scale Multi-Modal LLM Training by Bubble Exploitation | 2024 | USENIX ATC | https://arxiv.org/abs/2408.03505 | — |
| M09 | `bytescale` | ByteScale: Efficient Scaling of LLM Training with a 2048K Context Length on More Than 12,000 GPUs | 2025 | SIGCOMM | https://arxiv.org/abs/2502.21231 | — |
| M09 | `byterobust` | Robust LLM Training Infrastructure at ByteDance | 2025 | SOSP | https://arxiv.org/abs/2509.16293 | — |
| M10 | `cpinfer` | Context Parallelism for Scalable Million-Token Inference | 2024 | MLSys | https://arxiv.org/abs/2411.01783 | — |
| M11 | `nanoflow` | NanoFlow: Towards Optimal Large Language Model Serving Throughput | 2024 | arXiv 预印本 | https://arxiv.org/abs/2408.12757 | https://github.com/efeslab/Nanoflow |
| M11 | `podattn` | POD-Attention: Unlocking Full Prefill-Decode Overlap for Faster LLM Inference | 2024 | ASPLOS | https://arxiv.org/abs/2410.18038 | — |
| M11 | `dynamollm` | DynamoLLM: Designing LLM Inference Clusters for Performance and Energy Efficiency | 2024 | ISCA | https://arxiv.org/abs/2408.00741 | — |
| M11 | `kunserve` | KunServe: Parameter-centric Memory Management for Efficient Memory Overloading Handling in LLM Serving | 2024 | EuroSys | https://arxiv.org/abs/2412.18169 | — |
| M11 | `fastswitch` | FastSwitch: Optimizing Context Switching Efficiency in Fairness-aware Large Language Model Serving | 2024 | arXiv 预印本 | https://arxiv.org/abs/2411.18424 | — |
| M11 | `marconi` | Marconi: Prefix Caching for the Era of Hybrid LLMs | 2024 | MLSys | https://arxiv.org/abs/2411.19379 | — |
| M11 | `memserve` | MemServe: Context Caching for Disaggregated LLM Serving with Elastic Memory Pool | 2024 | arXiv 预印本 | https://arxiv.org/abs/2406.17565 | — |
| M11 | `microserving` | A System for Microserving of LLMs | 2024 | arXiv 预印本 | https://arxiv.org/abs/2412.12488 | — |
| M11 | `flashinfer` | FlashInfer: Efficient and Customizable Attention Engine for LLM Inference Serving | 2025 | MLSys | https://arxiv.org/abs/2501.01005 | https://github.com/flashinfer-ai/flashinfer |
| M11 | `lmcache` | LMCache: An Efficient KV Cache Layer for Enterprise-Scale LLM Inference | 2025 | arXiv 预印本 | https://arxiv.org/abs/2510.09665 | https://github.com/LMCache/LMCache |
| M11 | `jenga` | Jenga: Effective Memory Management for Serving LLM with Heterogeneity | 2025 | SOSP | https://arxiv.org/abs/2503.18292 | — |
| M11 | `nexus` | Nexus:Proactive Intra-GPU Disaggregation of Prefill and Decode in LLM Serving | 2025 | arXiv 预印本 | https://arxiv.org/abs/2507.06608 | — |
| M11 | `kvsurvey` | From Tensor Buffer to Distributed Memory Hierarchy: A Survey of KV Cache Management for LLM Serving | 2026 | arXiv 预印本 | https://arxiv.org/abs/2607.02574 | — |
| M11 | `pdmoe_survey` | Towards Efficient Large Language Model Serving: A Survey on System-Aware KV Cache Optimization | 2026 | ACL | https://arxiv.org/abs/2607.08057 | — |
| M12 | `cacheblend` | CacheBlend: Fast Large Language Model Serving for RAG with Cached Knowledge Fusion | 2024 | ACM TOCS | https://arxiv.org/abs/2405.16444 | — |
| M12 | `qserve` | QServe: W4A8KV4 Quantization and System Co-design for Efficient LLM Serving | 2024 | MLSys | https://arxiv.org/abs/2405.04532 | https://github.com/mit-han-lab/omniserve |
| M12 | `quest` | Quest: Query-Aware Sparsity for Efficient Long-Context LLM Inference | 2024 | ICML | https://arxiv.org/abs/2406.10774 | https://github.com/mit-han-lab/Quest |
| M12 | `eagle3` | EAGLE-3: Scaling up Inference Acceleration of Large Language Models via Training-Time Test | 2025 | NeurIPS | https://arxiv.org/abs/2503.01840 | https://github.com/SafeAILab/EAGLE |
| M13 | `flexattn` | Flex Attention: A Programming Model for Generating Optimized Attention Kernels | 2024 | arXiv 预印本 | https://arxiv.org/abs/2412.05496 | https://github.com/pytorch/pytorch |
| M14 | `rlhfuse` | Optimizing RLHF Training for Large Language Models with Stage Fusion | 2024 | NSDI | https://arxiv.org/abs/2409.13221 | — |
| M14 | `asyncrlhf` | Asynchronous RLHF: Faster and More Efficient Off-Policy RL for Language Models | 2024 | ICLR | https://arxiv.org/abs/2410.18252 | — |
| M14 | `areal` | AReaL: A Large-Scale Asynchronous Reinforcement Learning System for Language Reasoning | 2025 | NeurIPS | https://arxiv.org/abs/2505.24298 | https://github.com/areal-project/AReaL |
| M14 | `streamrl` | StreamRL: Scalable, Heterogeneous, and Elastic RL for LLMs with Disaggregated Stream Generation | 2025 | arXiv 预印本 | https://arxiv.org/abs/2504.15930 | — |
| M14 | `asyncflow` | AsyncFlow: An Asynchronous Streaming RL Framework for Efficient LLM Post-Training | 2025 | arXiv 预印本 | https://arxiv.org/abs/2507.01663 | — |
| M14 | `rollflash` | Part II: ROLL Flash -- Accelerating RLVR and Agentic Training with Asynchrony | 2025 | arXiv 预印本 | https://arxiv.org/abs/2510.11345 | — |
| M14 | `rollpacker` | RollPacker: Mitigating Long-Tail Rollouts for Fast, Synchronous RL Post-Training | 2025 | arXiv 预印本 | https://arxiv.org/abs/2509.21009 | — |
| M14 | `laminar` | Laminar: A Scalable Asynchronous RL Post-Training Framework | 2025 | EuroSys | https://arxiv.org/abs/2510.12633 | — |
| M15 | `llmservingsim2` | LLMServingSim 2.0: A Unified Simulator for Heterogeneous and Disaggregated LLM Serving Infrastructure | 2026 | ISPASS | https://arxiv.org/abs/2602.23036 | — |

## 6. 读完之后

- 每篇精读论文用 `notes_template.md` 写笔记，保存到 `papers/notes/<id>.md`（由学习者创建）。
- 把第三遍中找到的“未说出的假设”写成问题卡片，放进 `progress/LEARNER_PROGRESS.md` 的问题卡片区，选题研讨时使用。
