# 学习资源清单

> 只收录 `SOURCES.md` 中**已核实**的资源（核验日期 2026-10-18）。推荐度：★★★ 强烈推荐 · ★★ 推荐 · ★ 参考。“阶段”对应 `CURRICULUM.md` 的天数与模块。star 数和最后推送时间是核验当天的值。

## 1. 主线教材与课程（先选一两个作为主线，其余按需查阅）

| 资源 | 链接 | 推荐度 | 阶段 | 说明 |
| --- | --- | --- | --- | --- |
| Hugging Face *The Ultra-Scale Playbook* | https://huggingface.co/spaces/nanotron/ultrascale-playbook | ★★★ | D3~D4（M04~M07） | 从单卡到数千卡训练的完整讲解，含大量实测；与 M06/M07 互为补充 |
| *How to Scale Your Model*（Google DeepMind） | https://jax-ml.github.io/scaling-book/ | ★★★ | D1、D4、D5 | Roofline、并行与推理的“信封背面”计算，每章有习题；以 TPU 为主，另有 GPU 一章 |
| stas00/ml-engineering | https://github.com/stas00/ml-engineering | ★★ | 全程查阅 | 大模型训练与推理的工程手册（硬件、网络、调试、容错） |
| CMU 10-414/714 Deep Learning Systems | https://dlsyscourse.org/lectures/ | ★★ | D1~D2 | 从零实现自动微分与框架（needle） |
| CMU 15-442/642 Machine Learning Systems | https://mlsyscourse.org/ | ★★★ | 全程 | 覆盖自动微分、GPU、并行、编译、LLM 服务的系统课程 |
| CMU 15-779 Advanced ML Systems（LLM Edition） | https://www.cs.cmu.edu/~zhihaoj2/15-779/ | ★★ | D4~D7 | 面向 LLM 的进阶系统课，有论文阅读要求 |
| Stanford CS336 Language Modeling from Scratch | https://cs336.stanford.edu/spring2025 | ★★ | D2~D3 之后 | 作业量大；作业 2 涉及 Triton 版 FlashAttention-2 与分布式训练 |
| MIT 6.5940 EfficientML.ai | https://efficientml.ai | ★★ | D6（M12） | 量化、剪枝、LLM 部署 |
| UC Berkeley CS267 | https://sites.google.com/lbl.gov/cs267-spr2025 | ★ | M05 之后 | 并行计算基础（通信、并行算法），偏 HPC |
| 《机器学习系统：设计和实现》（openmlsys）第 2 版 | https://openmlsys.github.io/ | ★★ | 全程（中文） | 中英双语在线书，含编译器、训练系统、模型服务、RL 系统、集群管理 |
| Infrasys-AI/AISystem（ZOMI《AI 系统》） | https://github.com/Infrasys-AI/AISystem | ★★ | 全程（中文） | 中文课程讲义与 PPT，配套 B 站视频 |

## 2. 按模块的实践资源

### 2.1 GPU 与 kernel（M01、M03）
| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| srush/GPU-Puzzles | https://github.com/srush/GPU-Puzzles | ★★★ | 在线 CUDA 入门练习，不需要本地 GPU |
| gpu-mode/Triton-Puzzles（原 srush/Triton-Puzzles） | https://github.com/gpu-mode/Triton-Puzzles | ★★★ | Triton 练习 |
| gpu-mode/lectures + YouTube 录像 | https://github.com/gpu-mode/lectures ；https://www.youtube.com/@GPUMODE | ★★★ | 讲座覆盖 profiling、CUDA、Triton、FlashAttention、NCCL 等 |
| Christian Mills 的 GPU MODE 课程笔记 | https://christianjmills.com/series/notes/cuda-mode-notes.html | ★★ | 英文文字笔记 |
| Triton 官方教程 | https://triton-lang.org/main/getting-started/tutorials/index.html | ★★★ | 向量加、融合 softmax、矩阵乘、融合注意力 |
| Horace He, *Making Deep Learning Go Brrrr* | https://horace.io/brrr_intro.html | ★★★ | 计算、访存、开销三分法 |
| BBuf/how-to-optim-algorithm-in-cuda | https://github.com/BBuf/how-to-optim-algorithm-in-cuda | ★★ | 中文 CUDA 优化笔记与 CUDA-MODE 中文笔记 |
| xlite-dev/LeetCUDA | https://github.com/xlite-dev/LeetCUDA | ★★ | CUDA kernel 练习集 |
| Dao-AILab/flash-attention | https://github.com/Dao-AILab/flash-attention | ★★ | FlashAttention 源码（进阶） |
| linkedin/Liger-Kernel | https://github.com/linkedin/Liger-Kernel | ★ | 可读的融合 Triton kernel |

### 2.2 训练系统（M04~M09）
| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| huggingface/picotron | https://github.com/huggingface/picotron | ★★★ | 4D 并行教学实现，每个并行文件不到 300 行，支持 CPU 运行 |
| karpathy/nanoGPT | https://github.com/karpathy/nanoGPT | ★★★ | 最小的 GPT 训练代码 |
| karpathy/llm.c | https://github.com/karpathy/llm.c | ★★ | 用 C/CUDA 从零训练 GPT-2 |
| PyTorch 官方 FSDP2 教程 | https://docs.pytorch.org/tutorials/intermediate/FSDP_tutorial.html | ★★ | `fully_shard` 用法与原理 |
| LambdaLabsML/distributed-training-guide | https://github.com/LambdaLabsML/distributed-training-guide | ★★ | 从单卡到 FSDP + TP 的分章节指南 |
| pytorch/torchtitan | https://github.com/pytorch/torchtitan | ★★ | PyTorch 原生的大规模训练参考实现（进阶读源码） |
| NVIDIA/Megatron-LM | https://github.com/NVIDIA/Megatron-LM | ★★ | 张量/流水线并行的工业实现（读 `megatron/core/`） |
| deepspeedai/DeepSpeed | https://github.com/deepspeedai/DeepSpeed | ★★ | ZeRO 的实现 |
| deepseek-ai/DualPipe、deepseek-ai/DeepEP | https://github.com/deepseek-ai/DualPipe ；https://github.com/deepseek-ai/DeepEP | ★ | DeepSeek-V3 的流水线调度与专家并行通信库 |
| Lilian Weng, *How to Train Really Large Models on Many GPUs?* | https://lilianweng.github.io/posts/2021-09-25-train-large/ | ★★ | 并行与显存技术综述 |
| 李沐《Megatron LM 论文精读》《Zero 论文精读》（B 站） | https://www.bilibili.com/video/BV1nB4y1R7Yz/ ；https://www.bilibili.com/video/BV1tY411g7ZT/ | ★★ | 中文逐段精读 |
| ZOMI《DP、DDP、FSDP 数据并行原理》（B 站）、ZOMI《完全分片数据并行 FSDP》（博客园） | https://www.bilibili.com/video/BV1JK411S7gL/ ；https://www.cnblogs.com/ZOMI/articles/18562942 | ★★ | 中文讲解 |
| 罗西的思考《模型并行分布式训练 Megatron》系列（博客园） | https://www.cnblogs.com/rossiXYZ/p/15871062.html | ★ | 中文源码解析；代码版本较旧，读时注意对照当前源码 |

### 2.3 推理系统（M10~M12）
| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| GeeeekExplorer/nano-vllm | https://github.com/GeeeekExplorer/nano-vllm | ★★★ | 约千行的最小 vLLM 式推理引擎，适合读懂分页与连续批处理 |
| vLLM 博客 *Inside vLLM* | https://vllm.ai/blog/2025-09-05-anatomy-of-vllm | ★★★ | 基于 V1 引擎的源码导读 |
| vLLM 文档：优化与调参 | https://docs.vllm.ai/en/latest/configuration/optimization.html | ★★ | 抢占、分块 prefill 等参数 |
| kipply, *Transformer Inference Arithmetic*（中英双语版） | https://kipply.github.io/blog/transformer-inference-arithmetic/ ；https://rickliang-jy.github.io/Time-to-First-Token-Chinese/blogs/transformer-inference-arithmetic/index.html | ★★★ | 推理的显存与延迟估算（中文版为 AI 翻译，以英文原文为准） |
| Lilian Weng, *Large Transformer Model Inference Optimization* | https://lilianweng.github.io/posts/2023-01-10-inference-optimization/ | ★★ | 推理优化综述 |
| NVIDIA《Mastering LLM Techniques: Inference Optimization》《LLM Inference Benchmarking》 | https://developer.nvidia.com/blog/mastering-llm-techniques-inference-optimization/ ；https://developer.nvidia.com/blog/llm-benchmarking-fundamental-concepts/ | ★★ | 工程视角的概览与 benchmark 概念 |
| SGLang 博客 *Unified Radix Cache* | https://www.sglang.io/blog/unified-radix-cache | ★★ | 混合模型的前缀缓存 |
| NVIDIA Dynamo 架构文档、llm-d | https://docs.dynamo.nvidia.com/dynamo/v-0-9-0/design-docs/overall-architecture ；https://llm-d.ai/ | ★ | 分布式推理编排（PD 分离、KV 感知路由） |
| vllm-project/vllm、sgl-project/sglang | https://github.com/vllm-project/vllm ；https://github.com/sgl-project/sglang | ★★ | 主流推理引擎（进阶读源码） |
| ZOMI《大模型推理整体知识》（B 站） | https://www.bilibili.com/video/BV1dyqDYvEv2/ | ★★ | 中文推理系列第一集 |
| 腾讯云《从源码剖析 vLLM 的显存管理与连续批处理》 | https://cloud.tencent.com/developer/article/2714056 | ★ | 中文入门参考；作者匿名、有营销式表述，质量一般 |

### 2.4 编译器（M13）
| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| triton-lang/triton、apache/tvm | https://github.com/triton-lang/triton ；https://github.com/apache/tvm | ★★ | 编译器源码 |
| tile-ai/tilelang、HazyResearch/ThunderKittens | https://github.com/tile-ai/tilelang ；https://github.com/HazyResearch/ThunderKittens | ★ | 新一代 kernel DSL（前沿） |

### 2.5 RL 后训练系统（M14）
| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| verl-project/verl（原 volcengine/verl） | https://github.com/verl-project/verl | ★★★ | HybridFlow 的实现，issue 区是 P26/P27 的重要证据来源 |
| OpenRLHF/OpenRLHF | https://github.com/OpenRLHF/OpenRLHF | ★★ | 基于 Ray 的分离部署 |
| areal-project/AReaL（原 inclusionAI/AReaL）、THUDM/slime | https://github.com/areal-project/AReaL ；https://github.com/THUDM/slime | ★★ | 异步 RL 系统 |

### 2.6 研究方法（M15）
| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| 李沐《如何读论文》（B 站） | https://www.bilibili.com/video/BV1H44y1t75x/ | ★★★ | 三遍阅读法 |
| mli/paper-reading | https://github.com/mli/paper-reading | ★★ | 李沐论文精读视频索引 |
| MLSys 2025、SOSP 2025 录用列表 | https://mlsys.org/Conferences/2025/AcceptedPapers ；https://sigops.org/s/conferences/sosp/2025/accepted.html | ★★ | 了解研究热点 |

## 3. 论文列表与导航

| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| AmberLJC/LLMSys-PaperList | https://github.com/AmberLJC/LLMSys-PaperList | ★★★ | LLM 系统论文分类列表，更新活跃 |
| xlite-dev/Awesome-LLM-Inference | https://github.com/xlite-dev/Awesome-LLM-Inference | ★★ | 推理论文与代码 |
| byungsoo-oh/ml-systems-papers | https://github.com/byungsoo-oh/ml-systems-papers | ★★ | ML 系统论文（训练/推理分类） |
| mental2008/awesome-papers | https://github.com/mental2008/awesome-papers | ★★ | 按会议整理的阅读笔记（含 OSDI'25、SOSP'25） |
| lambda7xx/awesome-AI-system | https://github.com/lambda7xx/awesome-AI-system | ★ | 论文与代码对照 |
| Shenggan/awesome-distributed-ml | https://github.com/Shenggan/awesome-distributed-ml | ★ | 分布式训练与推理 |
| gpu-mode/resource-stream | https://github.com/gpu-mode/resource-stream | ★ | GPU 编程资料流 |
| HuaizhengZhang/AI-Infra-from-Zero-to-Hero（原 Awesome-System-for-Machine-Learning） | https://github.com/HuaizhengZhang/AI-Infra-from-Zero-to-Hero | ★ | AI Infra 资源汇总 |

## 4. 中文资料补充（已核实）

| 资源 | 链接 | 推荐度 | 说明 |
| --- | --- | --- | --- |
| Infrasys-AI/AIInfra（原 chenzomi12/AIFoundation） | https://github.com/Infrasys-AI/AIInfra | ★★ | ZOMI 的大模型系统讲义 |
| openmlsys/openmlsys | https://github.com/openmlsys/openmlsys | ★★ | openmlsys 在线书源码 |
| caomaolufei/AIInfraGuide | https://github.com/caomaolufei/AIInfraGuide | ★ | 中文 AI Infra 学习指南（含 nano-vllm 源码解读、面试准备） |
| CalvinXKY/InfraTech | https://github.com/CalvinXKY/InfraTech | ★ | 中文 Infra 知识与 notebook 练习 |
| liguodongiot/llm-action | https://github.com/liguodongiot/llm-action | ★ | 偏工程实战的中文资料 |

知乎上有大量 AI Infra 的中文文章（学习路线、vLLM 源码、Megatron 源码、ZeRO 显存分析等），但核验时站点拒绝了自动访问，所以只列在 `SOURCES.md` 的待核实列表中；可以自行阅读，作为辅助材料。

## 5. 附录：全部已核实的 GitHub 仓库

| 类别 | 仓库 | star | 最后推送 | 许可证 | 状态 |
| --- | --- | ---: | --- | --- | --- |
| RL 后训练 | [verl-project/verl](https://github.com/verl-project/verl)（原 volcengine/verl） | 23914 | 2026-10-18 | Apache-2.0 | 活跃 |
| RL 后训练 | [OpenRLHF/OpenRLHF](https://github.com/OpenRLHF/OpenRLHF) | 10095 | 2026-10-05 | Apache-2.0 | 活跃 |
| RL 后训练 | [THUDM/slime](https://github.com/THUDM/slime) | 8681 | 2026-10-17 | Apache-2.0 | 活跃 |
| RL 后训练 | [areal-project/AReaL](https://github.com/areal-project/AReaL)（原 inclusionAI/AReaL） | 5841 | 2026-10-16 | Apache-2.0 | 活跃 |
| 中文书/课程 | [Infrasys-AI/AISystem](https://github.com/Infrasys-AI/AISystem)（原 chenzomi12/AISystem） | 17999 | 2025-09-03 | Apache-2.0 | 活跃 |
| 中文书/课程 | [Infrasys-AI/AIInfra](https://github.com/Infrasys-AI/AIInfra) | 8436 | 2025-12-22 | Apache-2.0 | 活跃 |
| 中文书/课程 | [openmlsys/openmlsys](https://github.com/openmlsys/openmlsys)（原 openmlsys/openmlsys-zh） | 4869 | 2026-03-15 | 无 | 活跃 |
| 中文教程 | [liguodongiot/llm-action](https://github.com/liguodongiot/llm-action) | 25179 | 2026-10-14 | Apache-2.0 | 活跃 |
| 中文教程 | [xlite-dev/LeetCUDA](https://github.com/xlite-dev/LeetCUDA) | 12088 | 2026-10-18 | GPL-3.0 | 活跃 |
| 中文教程 | [CalvinXKY/InfraTech](https://github.com/CalvinXKY/InfraTech) | 4189 | 2026-09-20 | 无 | 活跃 |
| 中文教程 | [BBuf/how-to-optim-algorithm-in-cuda](https://github.com/BBuf/how-to-optim-algorithm-in-cuda) | 3317 | 2026-10-11 | 无 | 活跃 |
| 中文教程 | [caomaolufei/AIInfraGuide](https://github.com/caomaolufei/AIInfraGuide) | 2787 | 2026-10-12 | 无 | 活跃 |
| 中文教程 | [hzspyy/llm-infra](https://github.com/hzspyy/llm-infra) | 0 | 2026-09-29 | 无 | 活跃 |
| 中文论文精读 | [mli/paper-reading](https://github.com/mli/paper-reading) | 33977 | 2025-03-22 | Apache-2.0 | 活跃 |
| 低精度/量化 | [mit-han-lab/llm-awq](https://github.com/mit-han-lab/llm-awq) | 3651 | 2025-07-17 | MIT | 活跃 |
| 低精度/量化 | [NVIDIA/TransformerEngine](https://github.com/NVIDIA/TransformerEngine) | 3585 | 2026-10-16 | Apache-2.0 | 活跃 |
| 低精度/量化 | [pytorch/ao](https://github.com/pytorch/ao) | 3005 | 2026-10-16 | NOASSERTION | 活跃 |
| 在线书 | [stas00/ml-engineering](https://github.com/stas00/ml-engineering) | 19541 | 2026-10-16 | CC-BY-SA-4.0 | 活跃 |
| 在线书 | [jax-ml/scaling-book](https://github.com/jax-ml/scaling-book) | 1487 | 2026-10-11 | MIT | 活跃 |
| 推理系统 | [vllm-project/vllm](https://github.com/vllm-project/vllm) | 94050 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [sgl-project/sglang](https://github.com/sgl-project/sglang) | 37269 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [NVIDIA/TensorRT-LLM](https://github.com/NVIDIA/TensorRT-LLM) | 14847 | 2026-10-18 | NOASSERTION | 活跃 |
| 推理系统 | [LMCache/LMCache](https://github.com/LMCache/LMCache) | 12107 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [ai-dynamo/dynamo](https://github.com/ai-dynamo/dynamo) | 8328 | 2026-10-18 | NOASSERTION | 活跃 |
| 推理系统 | [kvcache-ai/Mooncake](https://github.com/kvcache-ai/Mooncake) | 6824 | 2026-10-18 | Apache-2.0 | 活跃 |
| 推理系统 | [llm-d/llm-d](https://github.com/llm-d/llm-d) | 4856 | 2026-10-18 | Apache-2.0 | 活跃 |
| 教学实现 | [karpathy/nanoGPT](https://github.com/karpathy/nanoGPT) | 63897 | 2025-11-12 | MIT | 活跃 |
| 教学实现 | [karpathy/llm.c](https://github.com/karpathy/llm.c) | 31173 | 2025-06-26 | MIT | 活跃 |
| 教学实现 | [pytorch/examples](https://github.com/pytorch/examples) | 24072 | 2025-09-01 | BSD-3-Clause | 活跃 |
| 教学实现 | [GeeeekExplorer/nano-vllm](https://github.com/GeeeekExplorer/nano-vllm) | 15951 | 2026-04-26 | MIT | 活跃 |
| 教学实现 | [srush/GPU-Puzzles](https://github.com/srush/GPU-Puzzles) | 12539 | 2024-09-01 | MIT | 活跃 |
| 教学实现 | [gpu-mode/Triton-Puzzles](https://github.com/gpu-mode/Triton-Puzzles)（原 srush/Triton-Puzzles） | 2643 | 2026-04-01 | Apache-2.0 | 活跃 |
| 教学实现 | [huggingface/picotron](https://github.com/huggingface/picotron) | 2326 | 2025-08-26 | Apache-2.0 | 活跃 |
| 教学实现 | [srush/LLM-Training-Puzzles](https://github.com/srush/LLM-Training-Puzzles) | 1198 | 2024-01-10 | MIT | 活跃 |
| 教学实现 | [LambdaLabsML/distributed-training-guide](https://github.com/LambdaLabsML/distributed-training-guide) | 633 | 2025-10-22 | MIT | 活跃 |
| 算子/Kernel | [Dao-AILab/flash-attention](https://github.com/Dao-AILab/flash-attention) | 25154 | 2026-10-18 | BSD-3-Clause | 活跃 |
| 算子/Kernel | [deepseek-ai/FlashMLA](https://github.com/deepseek-ai/FlashMLA) | 13087 | 2026-10-15 | MIT | 活跃 |
| 算子/Kernel | [NVIDIA/cutlass](https://github.com/NVIDIA/cutlass) | 10617 | 2026-10-15 | NOASSERTION | 活跃 |
| 算子/Kernel | [deepseek-ai/DeepGEMM](https://github.com/deepseek-ai/DeepGEMM) | 8979 | 2026-10-14 | MIT | 活跃 |
| 算子/Kernel | [flashinfer-ai/flashinfer](https://github.com/flashinfer-ai/flashinfer) | 6681 | 2026-10-18 | Apache-2.0 | 活跃 |
| 算子/Kernel | [linkedin/Liger-Kernel](https://github.com/linkedin/Liger-Kernel) | 6664 | 2026-10-17 | BSD-2-Clause | 活跃 |
| 算子/Kernel | [HazyResearch/ThunderKittens](https://github.com/HazyResearch/ThunderKittens) | 3757 | 2026-09-12 | MIT | 活跃 |
| 编译器/DSL | [mlc-ai/mlc-llm](https://github.com/mlc-ai/mlc-llm) | 23251 | 2026-10-06 | Apache-2.0 | 活跃 |
| 编译器/DSL | [triton-lang/triton](https://github.com/triton-lang/triton) | 20397 | 2026-10-17 | MIT | 活跃 |
| 编译器/DSL | [apache/tvm](https://github.com/apache/tvm) | 13844 | 2026-10-18 | Apache-2.0 | 活跃 |
| 编译器/DSL | [tile-ai/tilelang](https://github.com/tile-ai/tilelang) | 8646 | 2026-10-16 | NOASSERTION | 活跃 |
| 训练框架 | [deepspeedai/DeepSpeed](https://github.com/deepspeedai/DeepSpeed) | 43241 | 2026-10-18 | Apache-2.0 | 活跃 |
| 训练框架 | [hpcaitech/ColossalAI](https://github.com/hpcaitech/ColossalAI) | 41430 | 2026-10-15 | Apache-2.0 | 活跃 |
| 训练框架 | [NVIDIA/Megatron-LM](https://github.com/NVIDIA/Megatron-LM) | 18186 | 2026-10-18 | NOASSERTION | 活跃 |
| 训练框架 | [pytorch/torchtitan](https://github.com/pytorch/torchtitan) | 5818 | 2026-10-18 | BSD-3-Clause | 活跃 |
| 训练框架 | [deepseek-ai/DualPipe](https://github.com/deepseek-ai/DualPipe) | 3018 | 2026-01-14 | MIT | 活跃 |
| 训练框架 | [huggingface/nanotron](https://github.com/huggingface/nanotron) | 2843 | 2026-10-08 | Apache-2.0 | 活跃 |
| 训练框架 | [zhuzilin/ring-flash-attention](https://github.com/zhuzilin/ring-flash-attention) | 1065 | 2025-09-10 | MIT | 活跃 |
| 训练框架 | [feifeibear/long-context-attention](https://github.com/feifeibear/long-context-attention) | 696 | 2026-09-16 | Apache-2.0 | 活跃 |
| 训练框架 | [sail-sg/zero-bubble-pipeline-parallelism](https://github.com/sail-sg/zero-bubble-pipeline-parallelism) | 467 | 2025-05-07 | NOASSERTION | 活跃 |
| 课程作业 | [gpu-mode/lectures](https://github.com/gpu-mode/lectures) | 6878 | 2026-09-09 | Apache-2.0 | 活跃 |
| 课程作业 | [stanford-cs336/assignment1-basics](https://github.com/stanford-cs336/assignment1-basics) | 3032 | 2026-04-07 | MIT | 活跃 |
| 课程作业 | [dlsyscourse/hw1](https://github.com/dlsyscourse/hw1) | 2 | 2025-09-25 | 无 | 活跃 |
| 通信 | [deepseek-ai/DeepEP](https://github.com/deepseek-ai/DeepEP) | 10288 | 2026-10-16 | MIT | 活跃 |
| 通信 | [NVIDIA/nccl](https://github.com/NVIDIA/nccl) | 5172 | 2026-10-16 | NOASSERTION | 活跃 |
| 通信 | [NVIDIA/nccl-tests](https://github.com/NVIDIA/nccl-tests) | 1675 | 2026-10-05 | BSD-3-Clause | 活跃 |
| 论文/资源列表 | [xlite-dev/Awesome-LLM-Inference](https://github.com/xlite-dev/Awesome-LLM-Inference) | 5531 | 2026-08-14 | GPL-3.0 | 活跃 |
| 论文/资源列表 | [HuaizhengZhang/AI-Infra-from-Zero-to-Hero](https://github.com/HuaizhengZhang/AI-Infra-from-Zero-to-Hero)（原 HuaizhengZhang/Awesome-System-for-Machine-Learning） | 4435 | 2025-07-25 | MIT | 活跃 |
| 论文/资源列表 | [gpu-mode/resource-stream](https://github.com/gpu-mode/resource-stream) | 2378 | 2026-06-15 | MIT | 活跃 |
| 论文/资源列表 | [AmberLJC/LLMSys-PaperList](https://github.com/AmberLJC/LLMSys-PaperList) | 2297 | 2026-10-17 | 无 | 活跃 |
| 论文/资源列表 | [byungsoo-oh/ml-systems-papers](https://github.com/byungsoo-oh/ml-systems-papers) | 657 | 2026-10-17 | 无 | 活跃 |
| 论文/资源列表 | [lambda7xx/awesome-AI-system](https://github.com/lambda7xx/awesome-AI-system) | 380 | 2026-05-14 | 无 | 活跃 |
| 论文/资源列表 | [Shenggan/awesome-distributed-ml](https://github.com/Shenggan/awesome-distributed-ml) | 281 | 2024-10-08 | 无 | 活跃 |
| 论文/资源列表 | [mental2008/awesome-papers](https://github.com/mental2008/awesome-papers) | 232 | 2026-10-06 | MIT | 活跃 |
| 论文/资源列表 | [ModelTC/awesome-lm-system](https://github.com/ModelTC/awesome-lm-system) | 57 | 2023-12-17 | Apache-2.0 | 活跃 |
| 论文代码(alpa) | [alpa-projects/alpa](https://github.com/alpa-projects/alpa) | 3177 | 2023-12-09 | Apache-2.0 | 已归档 |
| 论文代码(cachegen) | [UChi-JCL/CacheGen](https://github.com/UChi-JCL/CacheGen) | 172 | 2024-10-09 | 无 | 活跃 |
| 论文代码(distserve) | [LLMServe/DistServe](https://github.com/LLMServe/DistServe) | 844 | 2025-04-06 | Apache-2.0 | 活跃 |
| 论文代码(dsv3) | [deepseek-ai/DeepSeek-V3](https://github.com/deepseek-ai/DeepSeek-V3) | 104506 | 2025-08-28 | MIT | 活跃 |
| 论文代码(eagle) | [SafeAILab/EAGLE](https://github.com/SafeAILab/EAGLE) | 2555 | 2026-02-20 | NOASSERTION | 活跃 |
| 论文代码(flexgen) | [FMInference/FlexLLMGen](https://github.com/FMInference/FlexLLMGen) | 9344 | 2024-10-28 | Apache-2.0 | 已归档 |
| 论文代码(gpipe) | [kakaobrain/torchgpipe](https://github.com/kakaobrain/torchgpipe) | 866 | 2024-07-25 | BSD-3-Clause | 活跃 |
| 论文代码(gptq) | [IST-DASLab/gptq](https://github.com/IST-DASLab/gptq) | 2386 | 2024-03-27 | Apache-2.0 | 活跃 |
| 论文代码(h2o) | [FMInference/H2O](https://github.com/FMInference/H2O) | 535 | 2024-08-01 | 无 | 活跃 |
| 论文代码(horovod) | [horovod/horovod](https://github.com/horovod/horovod) | 14679 | 2026-09-17 | NOASSERTION | 已归档 |
| 论文代码(kivi) | [jy-yuan/KIVI](https://github.com/jy-yuan/KIVI) | 435 | 2025-11-20 | MIT | 活跃 |
| 论文代码(llmint8) | [bitsandbytes-foundation/bitsandbytes](https://github.com/bitsandbytes-foundation/bitsandbytes) | 8526 | 2026-09-07 | MIT | 活跃 |
| 论文代码(llumnix) | [llumnix-project/llumnix-ray](https://github.com/llumnix-project/llumnix-ray)（原 AlibabaPAI/llumnix） | 561 | 2026-03-12 | Apache-2.0 | 活跃 |
| 论文代码(loongtrain) | [InternLM/InternEvo](https://github.com/InternLM/InternEvo) | 421 | 2025-08-21 | Apache-2.0 | 活跃 |
| 论文代码(medusa) | [FasterDecoding/Medusa](https://github.com/FasterDecoding/Medusa) | 2775 | 2024-06-25 | Apache-2.0 | 活跃 |
| 论文代码(megablocks) | [databricks/megablocks](https://github.com/databricks/megablocks) | 1598 | 2026-03-25 | Apache-2.0 | 活跃 |
| 论文代码(megascale) | [volcengine/veScale](https://github.com/volcengine/veScale) | 1043 | 2026-03-03 | Apache-2.0 | 活跃 |
| 论文代码(mpt) | [NVIDIA/apex](https://github.com/NVIDIA/apex) | 9004 | 2026-10-12 | BSD-3-Clause | 活跃 |
| 论文代码(nanoflow) | [efeslab/Nanoflow](https://github.com/efeslab/Nanoflow) | 976 | 2026-03-29 | 无 | 活跃 |
| 论文代码(pipedream) | [msr-fiddle/pipedream](https://github.com/msr-fiddle/pipedream) | 395 | 2022-11-04 | MIT | 活跃 |
| 论文代码(podattn) | [microsoft/vattention](https://github.com/microsoft/vattention) | 525 | 2026-08-24 | MIT | 活跃 |
| 论文代码(pytorch19) | [pytorch/pytorch](https://github.com/pytorch/pytorch) | 104841 | 2026-10-18 | NOASSERTION | 活跃 |
| 论文代码(qserve) | [mit-han-lab/omniserve](https://github.com/mit-han-lab/omniserve) | 864 | 2025-03-06 | Apache-2.0 | 活跃 |
| 论文代码(quest) | [mit-han-lab/Quest](https://github.com/mit-han-lab/Quest) | 411 | 2025-07-10 | MIT | 活跃 |
| 论文代码(ringattn) | [haoliuhl/ringattention](https://github.com/haoliuhl/ringattention) | 774 | 2025-10-13 | Apache-2.0 | 活跃 |
| 论文代码(sarathiserve) | [microsoft/sarathi-serve](https://github.com/microsoft/sarathi-serve) | 534 | 2026-01-08 | Apache-2.0 | 活跃 |
| 论文代码(smoothquant) | [mit-han-lab/smoothquant](https://github.com/mit-han-lab/smoothquant) | 1698 | 2024-07-12 | MIT | 活跃 |
| 论文代码(snapkv) | [FasterDecoding/SnapKV](https://github.com/FasterDecoding/SnapKV) | 336 | 2025-07-10 | Apache-2.0 | 活跃 |
| 论文代码(splitwise) | [mutinifni/splitwise-sim](https://github.com/mutinifni/splitwise-sim) | 167 | 2024-04-25 | MIT | 活跃 |
| 论文代码(streamingllm) | [mit-han-lab/streaming-llm](https://github.com/mit-han-lab/streaming-llm) | 7274 | 2024-07-11 | MIT | 活跃 |
| 论文代码(tutel) | [microsoft/Tutel](https://github.com/microsoft/Tutel) | 1028 | 2026-10-04 | MIT | 活跃 |

共 101 个仓库（按最终仓库名去重），数据为 2026-10-18 通过 GitHub REST API 实时查询的结果，原始响应保存在 `downloads/github-20261018/`（工作区内，不随教学包分发）。