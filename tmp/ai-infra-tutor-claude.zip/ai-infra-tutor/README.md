# AI Infra 渐进学习教学包（ai-infra-tutor）

一套**即插即用**的 AI Infra（机器学习系统）教学包：交给任何一个新的 agent，它读完 `START_PROMPT.md` 就能给你上课——布置题目并在作业单里用红色批改、带你跑实验、带读论文，同时持续积累可以写成论文的问题。

- **学习量**：7 天 × 每天 5 小时，共 **76 个编号任务**（`D1-T01` ~ `D7-T09`），覆盖 16 个模块（M00~M15）。
- **实验**：45 个单文件实验（43 个 CPU 必做 + 2 个 GPU 选做），全部 CPU 实验在构建机上实际运行通过；不下载任何模型权重。
- **练习**：265 道带编号的题目（诊断 8、L1/L2 91、L3/L4 58、论文精读 108），参考答案单独存放；每次练习都在 `workbook/` 的专门文件里作答和批改。
- **论文**：124 篇核验过元数据的论文（必读 36、选读 42、前沿 46），给出 arXiv/DOI 链接与核验过的 GitHub 代码链接。
- **研究**：30 个研究问题，标注证据级别（论文证据 / 工程讨论 / 推测）和最小可行实验；附选题与写作路线。

## 3 步上手

**第 1 步：安装环境**（不需要 root，不修改系统 Python；默认装到 `~/.cache/ai-infra-tutor-claude/venv`）

```bash
cd ai-infra-tutor
bash env/setup.sh                                      # 优先使用 uv；没有 uv 时用 venv + pip
~/.cache/ai-infra-tutor-claude/venv/bin/python labs/run_all.py   # 冒烟测试（约 70 秒）
```

已验证组合与常见安装问题见 `env/README.md`。

**第 2 步：把 `START_PROMPT.md` 发给一个新的 agent**

- agent 能读写文件（例如 Claude Code、Codex 等编程 agent）：让它在本目录下工作，把 `START_PROMPT.md` 的全文作为第一条消息发给它。
- agent 只能接收文本：发送 `BUNDLE_SINGLE_FILE.md`；讲到某个模块时，再把 `labs/<模块>/README.md`（讲义）和 `labs/ALL_CODE.md` 中对应的一节（代码与实测输出）发给它；批改前，在**自己作答之后**把 `exercises/answers/` 中对应的答案文件发给它。

**第 3 步：开始对话**

对 agent 说“开始上课”。它会读取 `progress/LEARNER_PROGRESS.md`，从 `D1-T01`（环境检查 + 10 分钟诊断测验）开始。之后随时可以用这些命令：`/进度`、`/下一课`、`/出题 M06 L2`、`/检查`、`/读论文 vllm`、`/问题雷达`、`/选题`、`/复习`、`/跳过 <任务编号>`。

换一个新的 agent 继续上课时，把教学包目录（包含你更新过的 `progress/` 与 `workbook/`）一起交给它即可。

## 目录结构

```text
ai-infra-tutor/
├── README.md                     # 本文件
├── START_PROMPT.md               # 【核心 1】发给新教学 agent 的完整提示词
├── BUNDLE_SINGLE_FILE.md         # 单文件打包版（tools/build_bundle.py 生成）
├── CURRICULUM.md                 # 7 天 × 5 小时任务表（76 个任务编号）、模块依赖图、学习目标
├── SOURCES.md                    # 调研日志：检索词、核验方法与结果、待核实列表
├── env/                          # 【核心 2】环境依赖
│   ├── requirements-cpu.txt      #   锁定版本（Python 3.12 + torch 2.14.1+cpu）
│   ├── requirements-gpu.txt      #   可选 GPU 扩展（独立环境；未在构建机验证）
│   ├── environment.yml           #   conda 等价版本
│   ├── setup.sh                  #   可重复执行的安装脚本
│   ├── check_env.py              #   自检与实验能力表
│   └── README.md                 #   已验证组合与常见安装问题
├── labs/                         # 【核心 3】实验
│   ├── INDEX.md                  #   实验总表（任务编号、命令、耗时、内存、论文、问题）
│   ├── ALL_CODE.md               #   全部源码 + 实测输出（自动生成）
│   ├── run_all.py                #   一键冒烟测试（检查耗时 ≤ 300s、内存 ≤ 4GB）
│   └── mXX_<主题>/               #   16 个模块：README.md（讲义）、lab_XX_*.py、exercises.md、outputs/
├── exercises/
│   ├── question_bank.md          #   题库（L1~L4 + 诊断题）
│   ├── rubric.md                 #   计分、批改流程、错误类型、红色批改格式
│   └── answers/                  #   参考答案（DIAG、M00~M15、papers）
├── workbook/                     # 作业单：README、模板、批改示例；你的作业单也放在这里
├── papers/                       # 【核心 4】论文学习
│   ├── PAPER_STUDY_GUIDE.md      #   36 篇必读精读指南、演化图谱、选读与前沿清单
│   ├── reading_list.csv          #   124 篇论文元数据（含 arXiv 与 GitHub 链接）
│   ├── references.bib
│   └── notes_template.md
├── resources/RESOURCES.md        # 已核实的课程、博客、仓库、中文资料
├── research/
│   ├── PROBLEM_BANK.md           #   30 个研究问题
│   ├── problem_card_template.md
│   └── THESIS_ROADMAP.md         #   选题 → 基线 → 测量 → 方案 → 实验 → 写作
├── progress/LEARNER_PROGRESS.md  # 学习进度与能力画像（教学 agent 每次课后更新）
└── tools/                        # 构建与核验脚本（作业单生成、打包自检、论文/仓库核验）
```

## 模拟首次对话（构建者自行模拟）

> 说明：下面是构建者按 `START_PROMPT.md` 自行模拟的一轮首次对话，用来检查提示词是否足以让 agent 开始教学；作业单使用 `tools/new_worksheet.py --task D1-T01` 实际生成。**这不是由一个独立的新 agent 实际运行得到的记录**（构建时没有得到使用子 agent 的授权）。建议你第一次使用时观察 agent 是否按这个流程进行。

**学生**：开始上课。

**教学 agent**：（读取 `progress/LEARNER_PROGRESS.md`：状态“未开始”）你好！这门课一共 7 天、每天约 5 小时，分成 76 个编号任务，每天以一份作业单和一次“问题雷达”结束。现在进行 **D1-T01：环境安装 + 诊断测验**（预计 30 分钟），这是第 1 天 11 个任务中的第 1 个。
请先在教学包根目录运行 `bash env/setup.sh`，然后把最后的“实验能力表”贴给我。

**学生**：（粘贴）汇总：可运行 43，需 GPU 2，缺依赖 0。

**教学 agent**：环境没问题：43 个 CPU 实验都能跑，2 个 GPU 实验是选做，各有 CPU 替代版本。接下来是 10 分钟的诊断测验，它不计分，只用来调整学习节奏。我已经生成了 `workbook/D1-T01_诊断测验.md`，一共 8 题，最后一题请写上你的硬件条件、每天能投入的时间、感兴趣的方向和论文目标。请在每题的“【你的答案】”下面作答，完成后告诉我“已作答 D1-T01”。

**学生**：已作答 D1-T01。（第 2 题写了 `x.grad = 2`；第 7 题写了“因为模型很大”；第 8 题写了“只有笔记本 CPU，每天 5 小时，对推理服务感兴趣，目标是毕业论文”。）

**教学 agent**：（在作业单中逐题写入红色批改，例如第 2 题：<span style="color:red">**【批改】部分掌握**　结果应该是一个与 x 同形状的张量。提示：y 对 x 的每个元素求导分别是什么？</span>；第 7 题：<span style="color:red">**【批改】部分掌握**　“模型大”只是一部分原因。提示：生成第 t 个 token 时需要用到前面哪些 token？这让各个 token 能不能同时计算？</span>）
诊断结果：Python 基础与数值常识已掌握；autograd 的张量语义、自回归生成的机制是部分掌握。我据此调整了学习路径并写进了进度文件：
1. D1-T09（M02 讲义）的 autograd 部分会多讲 10 分钟，并且先做 M02-L02 的迷你 autograd；
2. 你对推理服务感兴趣，D5（推理基础与服务系统）会多花时间在问题雷达上，D4-T10 的训练侧研讨可以简短一些；
3. 只有 CPU：所有必做实验都能完成，GPU 选做实验先跳过（标记为 ⏭️，以后有 GPU 再做）。
D1-T01 已完成 ✅。下一个任务是 **D1-T02：M00 讲义——AI Infra 版图与关键指标**（25 分钟，第 1 天第 2/11 个任务）。
先问你一个问题：如果让你评价一个聊天机器人服务“快不快”，你会测量哪些时间？

**学生**：……（D1-T02 开始）

## 交付前自检结果

| 验收项 | 结果 | 实际记录 |
| --- | --- | --- |
| 在全新虚拟环境中执行 `env/setup.sh`，然后 `run_all.py` 全部通过 | ✅ 通过 | 2026-10-18 在全新的 `~/.cache/ai-infra-tutor-claude/venv` 中运行 `setup.sh`，退出码 0；随后 `run_all.py --save-outputs`：PASS 43、SKIP 2（GPU 选做）、WARN 0、FAIL 0，总耗时 71 秒，单个实验最大内存 1.2GB |
| `check_env.py` 在纯 CPU 机器上正确输出能力表 | ✅ 通过 | 构建机无 GPU、无 C++ 编译器：输出“可运行 43，需 GPU 2，缺依赖 0”，并提示 inductor CPU 后端不可用 |
| 把 `START_PROMPT.md` 或 `BUNDLE_SINGLE_FILE.md` 发给全新 agent 后，能完成诊断并开始第一课 | ⚠️ 部分验证 | 构建者自行模拟了一轮首次对话（见上节），诊断作业单由脚本实际生成；**没有用独立的新 agent 实测**（构建时未获授权使用子 agent），建议首次使用时观察 |
| 每个模块都有实验、练习、论文和问题库条目，交叉引用一致，没有失效的相对链接 | ✅ 通过 | `tools/build_bundle.py` 检查：76 个任务编号与进度文件一致；265 道题都有参考答案；文档中引用的题号、问题编号、论文 id、相对链接、锚点、文件路径全部存在；每个模块至少 2 个 CPU 实验，且都链接了论文与问题库（检查本身用注入错误的方式验证过能报错） |
| 论文和资源的链接都已核实；未核实的只出现在 `SOURCES.md` 的待核实列表里 | ✅ 通过（有说明） | 124 篇论文经 arXiv API / Crossref / Semantic Scholar 核验，另有 21 篇补充引用经 Semantic Scholar 核验；101 个仓库经 GitHub API 核验；课程、博客、中文资料逐个访问或在线查看。14 篇知乎文章等无法打开的条目只放在待核实列表。说明：问题库引用的 GitHub issue 只看过检索摘要，已在问题库和 `SOURCES.md` 中注明 |
| 题库的参考答案与题目分开存放 | ✅ 通过 | 题目在 `exercises/question_bank.md`、各模块 `exercises.md`、论文指南中；答案只在 `exercises/answers/`；单文件打包版不含答案 |
| `ALL_CODE.md` 与 `labs/` 源码一致；zip 包解压后可直接使用 | ✅ 通过 | `build_bundle.py` 重新生成后比对一致；zip 解压到临时目录后运行 `run_all.py` 的结果见下方打包记录 |
| 不包含任何密钥、token、cookie 或个人隐私信息 | ✅ 通过 | 按常见密钥格式和个人信息模式扫描全部文本文件，未发现问题；教学包中没有任何账号或凭据 |

**打包记录**（2026-10-18，`python3 tools/build_bundle.py --zip ../ai-infra-tutor-claude.zip --test-zip <venv>/bin/python`）：zip 共 183 个文件、约 683KB（顶层目录名为 `ai-infra-tutor/`，不包含学习者自己的作业单）；解压到临时目录后运行 `labs/run_all.py`，退出码 0，PASS 43、SKIP 2、WARN 0、FAIL 0，总耗时 67 秒，单个实验最大内存约 1.2GB。

## 已知局限

- **没有 GPU 实测**：GPU 选做实验（Triton softmax、vLLM 实测）和 `requirements-gpu.txt` 没有在构建机上运行过。
- **inductor 代码生成未演示**：构建机没有 C++ 编译器，M13-L02 只演示了图捕获、图断裂和重编译，并如实报告 inductor 报错。
- **模拟器的系数是假设值**：M00、M07-L03、M11、M14 的耗时模型用于比较趋势，不能用于精确预测；讲义中已在每个实验处注明，并记录了开发过程中发现并修正的建模错误。
- **合成数据**：M12 的量化与 KV 压缩实验使用合成数据复现论文现象，其中 2bit KV 量化的结论与论文不一致，已如实说明并留作研究练习。
- **会议年份**：`reading_list.csv` 的“年份”是首次公开年份，不一定等于会议年份（原因见 `SOURCES.md` 第 2 节）。
