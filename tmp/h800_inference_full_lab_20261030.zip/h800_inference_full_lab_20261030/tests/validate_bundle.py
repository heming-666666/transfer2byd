"""Static syntax, local links, pinned CLI fields, 4/8 GPU profiles, secrets and dry-run validation."""
import ast,json,re,shlex,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def call(cmd,cwd):
    r=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,timeout=30)
    if r.returncode:raise AssertionError(str(cmd)+'\n'+r.stdout+'\n'+r.stderr)
    return r.stdout
def main():
    counts={}
    code_roots=['sglang_lab/scripts','sglang_lab/tests','vllm_addon/scripts','vllm_addon/tests','vllm_addon/third_party','shared/scripts','tests']
    py=[p for base in code_roots for p in (ROOT/base).rglob('*.py')]
    for p in py:ast.parse(p.read_text(),filename=str(p))
    counts['python_ast_files']=len(py)
    for base in ['sglang_lab','vllm_addon']:
        call(['bash','-n',str(ROOT/base/'scripts/bootstrap_offline.sh')],ROOT)
    counts['bootstrap_shell_scripts']=2
    inputs=[ROOT/'references.json',ROOT/'docs/experiments.json']
    for base in ['sglang_lab/config','vllm_addon/config','shared/fixtures']:
        inputs.extend((ROOT/base).glob('*.json'))
    inputs.extend(ROOT/base/'data/reports/deployment_status.template.json' for base in ['sglang_lab','vllm_addon'])
    for p in inputs:json.loads(p.read_text())
    md=list(ROOT.glob('*.md'))
    for base in ['sglang_lab','vllm_addon','shared']:
        md.append(ROOT/base/'00_README.md');md.extend((ROOT/base/'docs').glob('*.md'))
    links=blocks=0
    for p in md:
        if 'references/upstream' in p.as_posix():continue
        for url in re.findall(r'\]\(([^)]+)\)',p.read_text()):
            if url.startswith(('http://','https://','#','mailto:')):continue
            f=url.split('#',1)[0]
            if not (p.parent/f).exists():raise AssertionError((str(p.relative_to(ROOT)),f))
            links+=1
        for code in re.findall(r'```bash\n(.*?)```',p.read_text(),re.S):
            r=subprocess.run(['bash','-n'],input=code,text=True,capture_output=True)
            if r.returncode:raise AssertionError((p,r.stderr))
            blocks+=1
        for code in re.findall(r'```python\n(.*?)```',p.read_text(),re.S):
            ast.parse(code,filename=str(p))
    counts.update(markdown_files=len(md),local_links=links,bash_blocks=blocks)
    # Check flags appearing after documented Python script entrypoints without running GPU commands.
    documented_flags=0
    script_flags={}
    for folder in ['sglang_lab','vllm_addon','shared']:
        for p in (ROOT/folder/'scripts').glob('*.py'):
            flags=set()
            for node in ast.walk(ast.parse(p.read_text())):
                if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='add_argument':
                    flags.update(x.value for x in node.args if isinstance(x,ast.Constant) and isinstance(x.value,str) and x.value.startswith('--'))
            script_flags[(folder,p.name)]=flags
    for p in md:
        if 'references/upstream' in p.as_posix():continue
        for code in re.findall(r'```bash\n(.*?)```',p.read_text(),re.S):
            for line in re.sub(r'\\\n\s*',' ',code).splitlines():
                try:tokens=shlex.split(line,comments=True)
                except ValueError:continue
                for idx,token in enumerate(tokens):
                    match=re.search(r'(?:^|/)scripts/([^/]+\.py)$',token)
                    if not match:continue
                    folder='shared' if 'shared/' in token else 'vllm_addon' if 'vllm_addon/' in token else 'sglang_lab' if 'sglang_lab/' in token else ('vllm_addon' if 'vllm_addon' in p.parts else 'sglang_lab')
                    key=(folder,match[1])
                    if key not in script_flags:continue
                    for flag in tokens[idx+1:]:
                        if flag in ('|','&&',';'):break
                        if flag.startswith('--'):
                            assert flag.split('=',1)[0] in script_flags[key],(str(p.relative_to(ROOT)),key,flag,'unknown documented flag')
                            documented_flags+=1
    counts['documented_script_flags']=documented_flags
    # Extract real field names; reject removed no_cli aliases (e.g. disable-cuda-graph/sampling-backend).
    fields={};folder=ROOT/'sglang_lab/references/upstream/python/sglang/srt/arg_groups/fields'
    for f in folder.glob('*.py'):
        source=f.read_text()
        for n in ast.walk(ast.parse(source)):
            if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name):
                seg=ast.get_source_segment(source,n.annotation)
                fields['--'+n.target.id.replace('_','-')]='no_cli=True' not in seg
    total=0
    benchmark_flag_checks=0
    for framework in ['sglang_lab','vllm_addon']:
        with tempfile.TemporaryDirectory() as tmp:
            dst=Path(tmp)/framework
            for name in ['scripts','config']:
                shutil.copytree(ROOT/framework/name,dst/name,ignore=shutil.ignore_patterns('__pycache__','settings.json','secrets.json','client.json','*.env'))
            call([sys.executable,'scripts/configure.py','--lan-ip','127.0.0.1'],dst)
            secret=(dst/'config/secrets.json').read_text();call([sys.executable,'scripts/configure.py','--lan-ip','127.0.0.1'],dst)
            assert secret==(dst/'config/secrets.json').read_text()
            cfg=json.loads((dst/'config/settings.json').read_text());cfg['kv_scale_path']='config/kv_scales.prepared.json';(dst/'config/settings.json').write_text(json.dumps(cfg))
            ps=json.loads((dst/'config/profiles.json').read_text())
            for name,p in ps.items():
                output=call([sys.executable,'scripts/run.py','engine','--profile',name,'--dry-run'],dst);total+=1
                for val in json.loads(secret).values():assert val not in output
                if framework=='sglang_lab':
                    cmd=json.loads(output)['command']
                    for flag in [x for x in cmd if x.startswith('--')]:
                        assert fields.get(flag),(name,flag,'not a public CLI field at v0.5.22')
            for cards in [4,8]:assert f'{cards}g_baseline' in ps
            call([sys.executable,'scripts/benchmark.py','--profile','8g_baseline','--dry-run'],dst)
            source_files=([ROOT/'sglang_lab/references/upstream/python/sglang/benchmark/serving.py'] if framework=='sglang_lab' else
                [ROOT/'vllm_addon/references/upstream/vllm/benchmarks/serve.py',ROOT/'vllm_addon/references/upstream/vllm/benchmarks/datasets/datasets.py'])
            bench_flags=set()
            for source in source_files:
                for node in ast.walk(ast.parse(source.read_text())):
                    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='add_argument':
                        bench_flags.update(x.value for x in node.args if isinstance(x,ast.Constant) and isinstance(x.value,str) and x.value.startswith('--'))
            for manifest in (dst/'data/results/benchmarks').glob('*/manifest.json'):
                for flag in json.loads(manifest.read_text())['command']:
                    if flag.startswith('--'):
                        assert flag in bench_flags,(framework,flag,'not in pinned official benchmark parser')
                        benchmark_flag_checks+=1
            if framework=='sglang_lab':call([sys.executable,'scripts/run.py','pd-router','--dry-run'],dst)
            else:call([sys.executable,'scripts/run.py','pd-proxy','--dry-run'],dst)
    counts['profiles_dry_run']=total;counts['sglang_pinned_cli_fields']=len(fields)
    counts['official_benchmark_flag_checks']=benchmark_flag_checks
    for folder in ['sglang_lab','vllm_addon','shared']:
        skip={'engine_entry','router_entry','gpu_probe','lab_http','common','client_lib'}
        for p in (ROOT/folder/'scripts').glob('*.py'):
            if p.stem in skip:continue
            call([sys.executable,str(p),'--help'],ROOT/folder)
    counts.update(passed=True,gpu_model_tests='NOT_RUN_NO_H800_IN_THIS_WORKSPACE');print(json.dumps(counts,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
