"""CPU correctness tests for SLO denominator, joint predicates, cache refcounts and trace semantics."""
import array,base64,contextlib,json,sqlite3,subprocess,sys,tempfile,threading,time,unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'shared/scripts'))
from slo_bench import summarize,evaluate_slo,percentile
from kv_allocator import Pool
from trace_summary import summarize as trace_summary
from expert_capture import decode
from nsys_sqlite import analyze,union_ns
from sm_probe_report import report as sm_report
class SloTests(unittest.TestCase):
    def test_joint_goodput_includes_failed_requests_and_drain(self):
        rows=[dict(success=True,ttft_ms=100,tpot_ms=20,e2e_ms=500,output_tokens=10),
              dict(success=True,ttft_ms=3000,tpot_ms=10,e2e_ms=500,output_tokens=10),
              dict(success=False)]
        s=summarize(rows,4,dict(ttft_ms=2000,tpot_ms=100,e2e_ms=1000))
        self.assertEqual(s['joint_slo_pass'],1);self.assertEqual(s['request_goodput_rps'],.25)
        self.assertEqual(s['joint_slo_ratio'],1/3);self.assertEqual(s['successful_rps'],.5)
    def test_missing_usage_tpot_fails_slo(self):
        self.assertFalse(evaluate_slo(dict(success=True,ttft_ms=1,tpot_ms=None),dict(ttft_ms=2,tpot_ms=100)))
    def test_marginal_percentiles_do_not_imply_joint(self):
        rows=[dict(success=True,ttft_ms=1,tpot_ms=1) for _ in range(90)]
        rows +=[dict(success=True,ttft_ms=999,tpot_ms=1) for _ in range(5)]
        rows +=[dict(success=True,ttft_ms=1,tpot_ms=999) for _ in range(5)]
        self.assertEqual(percentile([x['ttft_ms'] for x in rows],95),1)
        self.assertEqual(percentile([x['tpot_ms'] for x in rows],95),1)
        self.assertEqual(summarize(rows,10,dict(ttft_ms=100,tpot_ms=100))['joint_slo_ratio'],.9)
    def test_nearest_rank_percentile(self):self.assertEqual(percentile([1,2,3,4],50),2)
class KVTests(unittest.TestCase):
    def test_partial_shared_page_copy_on_write(self):
        p=Pool(4,4);p.create('a');p.append('a',[1,2,3]);p.fork('a','b');p.append('b',[4,5])
        self.assertEqual(p.tokens('a'),[1,2,3]);self.assertEqual(p.tokens('b'),[1,2,3,4,5]);p.check()
    def test_free_every_shared_ref_exactly_once(self):
        p=Pool(4,4);p.create('a');p.append('a',range(4));p.fork('a','b');p.release('a')
        self.assertTrue(p.pages);p.release('b');self.assertFalse(p.pages)
    def test_oom_does_not_corrupt_shared_tail(self):
        p=Pool(1,4);p.create('a');p.append('a',[1]);p.fork('a','b')
        with self.assertRaises(MemoryError):p.append('b',[2])
        p.check();self.assertEqual(p.tokens('a'),[1]);self.assertEqual(p.tokens('b'),[1])
class TraceTests(unittest.TestCase):
    def test_durations_keep_categories_and_exclude_metadata(self):
        x=trace_summary({'traceEvents':[dict(ph='X',name='op',cat='cpu',dur=3),dict(ph='X',name='op',cat='kernel',dur=4),dict(ph='M',name='op',dur=999)]})
        self.assertEqual(len(x),2);self.assertEqual(sum(v['sum_duration_us'] for v in x),7)
class ExpertTests(unittest.TestCase):
    def test_route_tensor_shape_layer_histogram(self):
        a=array.array('i',[0,1,2,3,1,2,3,0]);raw=base64.b64encode(a.tobytes()).decode();tokens,c=decode(raw,2,2)
        self.assertEqual(tokens,2);self.assertEqual(c[0][1],2);self.assertEqual(c[1][3],2)
    def test_invalid_shape_fails(self):
        with self.assertRaises(ValueError):decode(base64.b64encode(b'abc').decode(),2,2)

class NsightTests(unittest.TestCase):
    def test_interval_union_does_not_double_count_overlap(self):
        self.assertEqual(union_ns([(0,10),(5,15),(20,25)]),20)
    def test_schema_kernel_api_stats_and_events(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'trace.sqlite';db=sqlite3.connect(path)
            db.execute('CREATE TABLE StringIds(id INTEGER,value TEXT)');db.executemany('INSERT INTO StringIds VALUES(?,?)',[(1,'gemm'),(2,'cudaLaunchKernel')])
            db.execute('CREATE TABLE CUPTI_ACTIVITY_KIND_KERNEL(start INTEGER,end INTEGER,deviceId INTEGER,globalPid INTEGER,demangledName INTEGER,streamId INTEGER,correlationId INTEGER)')
            db.executemany('INSERT INTO CUPTI_ACTIVITY_KIND_KERNEL VALUES(?,?,?,?,?,?,?)',[(0,10,0,1,1,7,9),(5,15,0,1,1,8,10)])
            db.execute('CREATE TABLE CUPTI_ACTIVITY_KIND_RUNTIME(start INTEGER,end INTEGER,nameId INTEGER)');db.execute('INSERT INTO CUPTI_ACTIVITY_KIND_RUNTIME VALUES(0,3,2)');db.commit();db.close()
            events=Path(t)/'events.jsonl';r=analyze(path,events)
            self.assertEqual(r['kernel_groups'][0]['calls'],2);self.assertEqual(r['kernel_groups'][0]['total_ns'],20)
            self.assertEqual(r['device_kernel_interval_union'][0]['kernel_busy_union_ns'],15)
            self.assertEqual(r['cuda_api_groups'][0]['total_host_wall_ns'],3)
            self.assertEqual(len(events.read_text().splitlines()),2)
class SmTests(unittest.TestCase):
    def test_sm_count_uses_unique_live_sm_not_live_block_count(self):
        r=sm_report([[3,3,0,10],[3,3,2,8],[9,9,5,12]],capacity=132)
        self.assertEqual(r['distinct_recorded_SM_count'],2);self.assertEqual(r['max_concurrent_recorded_SM_count'],2)
        self.assertEqual(r['time_average_recorded_SM_count'],17/12)
    def test_migrated_sm_is_flagged_not_assigned_to_wrong_lane(self):
        r=sm_report([[3,9,0,10]],capacity=132)
        self.assertEqual(r['migrated_blocks'],[0]);self.assertEqual(r['valid_blocks'],0)

class MockSse(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*args):pass
    def do_POST(self):
        self.rfile.read(int(self.headers['Content-Length']));time.sleep(.03)
        events=[{'choices':[{'delta':{'content':'hello'}}]},
                {'choices':[{'delta':{'content':' world'},'finish_reason':'stop'}],'usage':{'completion_tokens':4}}]
        body=(''.join('data: '+json.dumps(e)+'\n\n' for e in events)+'data: [DONE]\n\n').encode()
        self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
class HttpSloTests(unittest.TestCase):
    def test_closed_slo_real_http_sse_and_no_key_in_results(self):
        self.run_slo('closed',3)
    def test_open_loop_client_drops_count_as_failures(self):
        result=self.run_slo('open',4)
        self.assertGreaterEqual(result['failed'],1);self.assertLess(result['joint_slo_ratio'],1)
    def run_slo(self,mode,n):
        with tempfile.TemporaryDirectory() as tmp:
            server=ThreadingHTTPServer(('127.0.0.1',0),MockSse);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                config=Path(tmp)/'client.json';config.write_text(json.dumps(dict(base_url=f'http://127.0.0.1:{server.server_port}/v1',api_key='unit-secret-do-not-save',model='test')))
                out=Path(tmp)/'out'
                r=subprocess.run([sys.executable,str(ROOT/'shared/scripts/slo_bench.py'),'--client-config',str(config),'--mode',mode,
                    '--requests',str(n),'--concurrency','1','--rate','1000','--arrival','constant','--warmup','0','--output',str(out)],capture_output=True,text=True,timeout=20)
                self.assertEqual(r.returncode,0,r.stdout+r.stderr);result=json.loads((out/'summary.json').read_text());self.assertEqual(result['requests'],n)
                self.assertGreater(result['measurement_window']['end_perf_ns'],result['measurement_window']['start_perf_ns'])
                self.assertAlmostEqual(result['measurement_window']['seconds'],result['measurement_seconds'])
                self.assertIn('boot_id',result['clock']['identity'])
                self.assertIn('prompts_sha256',result['workload'])
                self.assertNotIn('unit-secret-do-not-save',''.join(p.read_text() for p in out.glob('*')))
                if mode=='closed':self.assertEqual(result['joint_slo_pass'],n)
                return result
            finally:server.shutdown();server.server_close();thread.join()
if __name__=='__main__':unittest.main(verbosity=2)
