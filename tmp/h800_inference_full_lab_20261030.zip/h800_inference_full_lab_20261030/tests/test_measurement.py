"""CPU/mock HTTP checks for acceptance, clocks, sampled energy and invalid SLO rejection."""
import copy
import json
import math
import re
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'shared/scripts'))
from accept_service import check_service
from energy_report import analyze, integrate
from lab_http import validate_extra
from measurement_clock import anchor, measurement_window, require_same_clock
from resource_monitor import parse_gpus, parse_query
from slo_bench import evaluate_slo, summarize, validate_slo

NS = 1000000000
IDENTITY = dict(hostname='cpu-fixture', boot_id='unit-boot', time_namespace=7, clock='perf_counter_ns')


def fixture():
    metadata = dict(clock=dict(identity=IDENTITY), gpu_indices=[0, 1])
    samples = [dict(perf_ns=t*NS, gpus=[dict(index=i, uuid='GPU-'+str(i), power_watts=100+i*100) for i in [0, 1]]) for t in [1, 2, 3]]
    slo = dict(clock=dict(identity=IDENTITY), measurement_window=dict(start_perf_ns=NS, end_perf_ns=3*NS, seconds=2),
               successful_output_tokens=20, token_usage_complete=True, request_goodput_rps=1)
    return metadata, samples, slo


class ClockTests(unittest.TestCase):
    def test_clock_anchor_window_is_positive_and_utc(self):
        c = anchor()
        w = measurement_window(c, c['perf_ns'], c['perf_ns']+NS)
        self.assertEqual(w['seconds'], 1)
        self.assertIn('+00:00', w['start_utc_estimate'])

    def test_other_host_or_namespace_or_boot_refused(self):
        for key in ['hostname', 'boot_id', 'time_namespace', 'clock']:
            other = dict(IDENTITY)
            other[key] = 'different'
            with self.assertRaises(ValueError):
                require_same_clock(IDENTITY, other)

    def test_unknown_clock_identity_is_not_trusted(self):
        with self.assertRaises(ValueError):
            require_same_clock(dict(IDENTITY, boot_id=None), dict(IDENTITY, boot_id=None))


class EnergyTests(unittest.TestCase):
    def test_constant_power_clipped_to_actual_window(self):
        r = integrate([(0, 100), (10*NS, 100)], 2*NS, 5*NS, 11)
        self.assertEqual(r['observed_energy_j'], 300)
        self.assertEqual(r['coverage_ratio'], 1)

    def test_linear_ramp_interpolates_window_boundaries(self):
        r = integrate([(0, 0), (10*NS, 100)], 2*NS, 4*NS, 11)
        self.assertEqual(r['observed_energy_j'], 60)

    def test_missing_power_never_filled_with_zero_or_bridged(self):
        r = integrate([(0, 100), (NS, None), (2*NS, 100)], 0, 2*NS, 10)
        self.assertEqual(r['coverage_ratio'], 0)
        self.assertEqual(r['observed_energy_j'], 0)

    def test_long_gap_and_nan_power_are_uncovered(self):
        self.assertEqual(integrate([(0, 100), (3*NS, 100)], 0, 3*NS, 2.5)['coverage_ratio'], 0)
        self.assertEqual(integrate([(0, 100), (NS, math.nan)], 0, NS, 2.5)['coverage_ratio'], 0)

    def test_duplicate_or_reversed_time_is_error(self):
        for points in [[(1, 100), (1, 200)], [(2, 100), (1, 200)]]:
            with self.assertRaises(ValueError):
                integrate(points, 0, 3, 2)

    def test_all_gpu_energy_and_token_denominator(self):
        r = analyze(*fixture())
        self.assertTrue(r['coverage_accepted'])
        self.assertEqual(r['full_window_gpu_energy_j'], 600)
        self.assertEqual(r['observed_gpu_joules_per_successful_output_token'], 30)

    def test_missing_one_gpu_makes_full_total_and_ratio_unavailable(self):
        metadata, samples, slo = fixture()
        samples[1]['gpus'].pop()
        r = analyze(metadata, samples, slo)
        self.assertFalse(r['coverage_accepted'])
        self.assertIsNone(r['full_window_gpu_energy_j'])
        self.assertIsNone(r['observed_gpu_joules_per_successful_output_token'])

    def test_missing_usage_does_not_report_joules_per_token(self):
        metadata, samples, slo = fixture()
        slo['token_usage_complete'] = False
        self.assertIsNone(analyze(metadata, samples, slo)['observed_gpu_joules_per_successful_output_token'])

    def test_gpu_uuid_changes_are_not_merged(self):
        metadata, samples, slo = fixture()
        samples[1]['gpus'][0]['uuid'] = 'GPU-replaced'
        with self.assertRaises(ValueError):
            analyze(metadata, samples, slo)

    def test_cross_host_is_rejected_before_integration(self):
        metadata, samples, slo = fixture()
        slo = copy.deepcopy(slo)
        slo['clock']['identity']['hostname'] = 'remote-client'
        with self.assertRaises(ValueError):
            analyze(metadata, samples, slo)

    def test_report_cli_writes_cpu_fixture_and_does_not_overwrite(self):
        metadata, samples, slo = fixture()
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder/'metadata.json').write_text(json.dumps(metadata))
            (folder/'samples.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in samples))
            (folder/'slo.json').write_text(json.dumps(slo))
            cmd = [sys.executable, str(ROOT/'shared/scripts/energy_report.py'), '--resources', str(folder),
                   '--slo-summary', str(folder/'slo.json'), '--output', str(folder/'report.json')]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertEqual(json.loads((folder/'report.json').read_text())['full_window_gpu_energy_j'], 600)
            self.assertNotEqual(subprocess.run(cmd, capture_output=True, timeout=10).returncode, 0)


class QueryTests(unittest.TestCase):
    def test_nvidia_csv_units_and_na(self):
        row = parse_query('0, GPU-test, 1024, 81920, 80, [N/A]\n', [0])[0]
        self.assertEqual(row['memory_used_mib'], 1024)
        self.assertIsNone(row['power_watts'])

    def test_duplicate_indices_or_wrong_card_count_refused(self):
        with self.assertRaises(ValueError):
            parse_gpus('0,0')
        with self.assertRaises(ValueError):
            parse_query('0, GPU-test, 1, 2, 3, 4\n', [0, 1])


class SloValidationTests(unittest.TestCase):
    def test_invalid_nan_negative_bool_or_unknown_slo_refused(self):
        for slo in [dict(ttft_ms=math.nan), dict(ttft_ms=math.inf), dict(ttft_ms=-1), dict(ttft_ms=True),
                    dict(ttft_ms=1, target_joint_ratio=1.1), dict(ttft_ms=1, ttfft_ms=2), dict(note='empty')]:
            with self.subTest(slo=slo), self.assertRaises(ValueError):
                validate_slo(slo)

    def test_no_slo_is_rejected_even_if_all_requests_failed(self):
        with self.assertRaises(ValueError):
            summarize([dict(success=False)], 1, {})

    def test_invalid_latency_cannot_pass(self):
        for x in [math.nan, -1, math.inf, None]:
            self.assertFalse(evaluate_slo(dict(success=True, ttft_ms=x), dict(ttft_ms=100)))

    def test_extra_cannot_break_stream_protocol_or_request_counts(self):
        for extra in [dict(stream=False), dict(model='other'), dict(n=2), dict(max_tokens=5), []]:
            with self.assertRaises(ValueError):
                validate_extra(extra)
        validate_extra(dict(chat_template_kwargs=dict(enable_thinking=False)))

    def test_successful_token_counts_and_length_capping_reported(self):
        r = summarize([dict(success=True, ttft_ms=1, output_tokens=3, length_capped=True)], 2, dict(ttft_ms=10))
        self.assertEqual(r['successful_output_tokens'], 3)
        self.assertTrue(r['token_usage_complete'])
        self.assertEqual(r['length_capped_successes'], 1)
    def test_missing_usage_reports_unknown_token_throughput(self):
        r=summarize([dict(success=True,ttft_ms=1,output_tokens=None)],1,dict(ttft_ms=10))
        self.assertFalse(r['token_usage_complete'])
        self.assertIsNone(r['successful_output_tokens']);self.assertIsNone(r['output_token_throughput'])
        self.assertIsNone(r['joint_good_output_tokens_per_second'])


class AcceptanceHandler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def send(self, data, status=200, stream=False):
        body = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'text/event-stream' if stream else 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.headers.get('Authorization') != 'Bearer unit-secret':
            self.send({}, 401)
        else:
            self.send(dict(data=[dict(id='test')]))

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        self.server.payloads.append(body)
        if self.headers.get('Authorization') != 'Bearer unit-secret':
            self.send({}, 401)
            return
        text = 'KV Cache 保存之前 token 的状态。'
        if len(body['messages']) == 3:
            text = re.search(r'校验码 ([A-F0-9]+)', body['messages'][0]['content']).group(1)
        content = '' if self.server.reasoning_only else text
        if not body['stream']:
            self.send(dict(choices=[dict(message=dict(content=content, reasoning='thinking'), finish_reason='stop')]))
            return
        event = dict(choices=[dict(delta=dict(content=content, reasoning='thinking'), finish_reason='stop')], usage=dict(completion_tokens=10))
        data = 'data: '+json.dumps(event)+'\n\n'
        if not self.server.missing_done:
            data += 'data: [DONE]\n\n'
        self.send(data.encode(), stream=True)


class AcceptanceTests(unittest.TestCase):
    def run_server(self, reasoning_only=False, missing_done=False):
        server = ThreadingHTTPServer(('127.0.0.1', 0), AcceptanceHandler)
        server.payloads = []
        server.reasoning_only = reasoning_only
        server.missing_done = missing_done
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(thread.join)
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        return server, dict(base_url=f'http://127.0.0.1:{server.server_port}/v1', model='test', api_key='unit-secret')

    def test_real_http_401_final_text_and_three_message_replay(self):
        server, client = self.run_server()
        report, history = check_service(client, 64, {}, 5)
        self.assertTrue(report['passed'], report)
        self.assertEqual(len(report['checks']), 6)
        self.assertEqual(len(history), 4)
        self.assertEqual(len(server.payloads[-1]['messages']), 3)
        self.assertNotIn('reasoning', server.payloads[-1]['messages'][1])
        self.assertNotIn('unit-secret', json.dumps(report))

    def test_reasoning_without_final_content_is_not_acceptance(self):
        _, client = self.run_server(reasoning_only=True)
        report, _ = check_service(client, 64, {}, 5)
        self.assertFalse(report['passed'])

    def test_missing_done_is_not_complete_stream(self):
        _, client = self.run_server(missing_done=True)
        report, _ = check_service(client, 64, {}, 5)
        self.assertFalse(report['passed'])
        self.assertTrue(any('missing [DONE]' in c.get('error', '') for c in report['checks']))

    def test_acceptance_cli_stores_conversation_and_no_key(self):
        _, client = self.run_server()
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder/'client.json').write_text(json.dumps(client))
            cmd = [sys.executable, str(ROOT/'shared/scripts/accept_service.py'), '--client-config', str(folder/'client.json'),
                   '--max-tokens', '64', '--output', str(folder/'result')]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            self.assertEqual(r.returncode, 0, r.stdout+r.stderr)
            files = list((folder/'result').glob('*.json'))
            self.assertEqual(len(files), 2)
            self.assertNotIn('unit-secret', ''.join(f.read_text() for f in files))

    def test_slo_cli_does_not_count_reasoning_only_as_success(self):
        _, client = self.run_server(reasoning_only=True)
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder/'client.json').write_text(json.dumps(client))
            cmd = [sys.executable, str(ROOT/'shared/scripts/slo_bench.py'), '--client-config', str(folder/'client.json'),
                   '--requests', '2', '--warmup', '0', '--mode', 'closed', '--output', str(folder/'result')]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            self.assertEqual(r.returncode, 0, r.stdout+r.stderr)
            report = json.loads((folder/'result/summary.json').read_text())
            self.assertEqual(report['success'], 0)
            self.assertEqual(report['joint_slo_pass'], 0)
            self.assertFalse(report['target_met'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
