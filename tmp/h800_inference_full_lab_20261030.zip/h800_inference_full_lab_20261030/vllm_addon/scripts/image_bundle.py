"""Transfer a complete runtime image without contacting a registry on the GPU server."""
import argparse
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(16 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="action", required=True)
    export = sub.add_parser("export")
    export.add_argument("--image", required=True)
    export.add_argument("--out-dir", type=Path, default=Path("storage/images"))
    load = sub.add_parser("load")
    load.add_argument("--manifest", type=Path, required=True)
    a = p.parse_args()
    if a.action == "export":
        metadata = json.loads(subprocess.check_output(["docker", "image", "inspect", a.image], text=True))[0]
        a.out_dir.mkdir(parents=True, exist_ok=True)
        stem = re.sub(r"[^a-zA-Z0-9_.-]", "_", a.image)
        archive = a.out_dir / (stem + ".tar")
        manifest = a.out_dir / (stem + ".manifest.json")
        if archive.exists() or manifest.exists():
            raise SystemExit("目标已存在；选择新的 out-dir，避免覆盖已准备镜像。")
        subprocess.run(["docker", "save", "--output", str(archive), a.image], check=True)
        data = {"created_utc": datetime.now(timezone.utc).isoformat(), "image": a.image,
                "image_id": metadata["Id"], "repo_digests": metadata.get("RepoDigests", []),
                "os": metadata.get("Os"), "architecture": metadata.get("Architecture"),
                "archive": archive.name, "bytes": archive.stat().st_size, "sha256": sha256(archive)}
        manifest.write_text(json.dumps(data, indent=2) + "\n")
        print("一起转移:", archive, manifest)
        return
    data = json.loads(a.manifest.read_text())
    archive = a.manifest.resolve().parent / data["archive"]
    if archive.parent != a.manifest.resolve().parent:
        raise SystemExit("manifest 中的 archive 必须为同目录文件名")
    if archive.stat().st_size != data["bytes"] or sha256(archive) != data["sha256"]:
        raise SystemExit("大小/哈希不匹配；禁止导入不完整镜像。")
    subprocess.run(["docker", "load", "--input", str(archive)], check=True)
    actual = json.loads(subprocess.check_output(["docker", "image", "inspect", data["image"]], text=True))[0]
    if actual["Id"] != data["image_id"]:
        raise SystemExit("导入后 image ID 不匹配")
    print("镜像已导入并核对:", data["image"], data["image_id"])

if __name__ == "__main__":
    main()
