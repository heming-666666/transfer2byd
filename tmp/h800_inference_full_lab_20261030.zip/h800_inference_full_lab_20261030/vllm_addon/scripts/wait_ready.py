"""Poll local engine health or the PD sample proxy; never expose the engine port."""
import argparse
import json
import time
import urllib.request
from common import settings

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--target", choices=["engine", "prefill", "decode", "proxy"], default="engine")
    p.add_argument("--timeout", type=float, default=1800)
    a = p.parse_args()
    cfg = settings()
    key = "pd_proxy_port" if a.target == "proxy" else a.target + "_port"
    suffix = "/healthcheck" if a.target == "proxy" else "/health"
    url = f"http://127.0.0.1:{cfg[key]}{suffix}"
    deadline = time.monotonic() + a.timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                if r.status == 200:
                    print("READY:", a.target, url)
                    return
        except OSError:
            pass
        print("等待就绪:", a.target, flush=True)
        time.sleep(5)
    raise SystemExit("超时；检查 data/logs 中的引擎日志，不要反复重启打断编译。")

if __name__ == "__main__":
    main()
