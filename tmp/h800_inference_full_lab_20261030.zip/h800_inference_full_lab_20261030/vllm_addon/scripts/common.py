"""Shared paths and configuration. No third-party Python dependencies."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL_KEYS = ("lab", "latest", "moe_lab")

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def settings():
    path = ROOT / "config/settings.json"
    if not path.is_file():
        raise SystemExit("先运行 python3 scripts/configure.py，见 docs/02_BASELINE_AND_LAN.md")
    return read_json(path)

def secrets():
    return read_json(ROOT / "config/secrets.json")

def profiles():
    return read_json(ROOT / "config/profiles.json")

def models():
    return read_json(ROOT / "config/models.json")

def absolute(path):
    p = Path(path).expanduser()
    return p.resolve() if p.is_absolute() else (ROOT / p).resolve()

def model_path(key, cfg=None):
    cfg = cfg or settings()
    return absolute(cfg["model_root"]) / models()[key]["directory"]

def write_json(path, value, private=False):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if private and not p.exists():
        p.touch(mode=0o600)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if private:
        p.chmod(0o600)

def docker_base(cfg, name, image, gpus=None, engine_auth=True):
    args = ["docker", "run", "--rm", "--name", name, "--network", "host", "--ipc", "host"]
    if gpus is not None:
        args += ["--gpus", '"device=' + ",".join(map(str, gpus)) + '"']
    args += ["--mount", f"type=bind,src={ROOT},dst=/lab,readonly",
             "--mount", f"type=bind,src={absolute(cfg['model_root'])},dst=/models,readonly",
             "--mount", f"type=bind,src={absolute(cfg.get('cache_root','environments/vllm0320/cache'))},dst=/cache",
             "--env", "HF_HOME=/cache/huggingface",
             "--env", "VLLM_CACHE_ROOT=/cache/vllm"]
    if engine_auth:
        args += ["--env-file", str(ROOT / "config/engine.env")]
    return args

def native_python(cfg):
    return absolute(cfg.get("native_python", "environments/vllm0320/.venv/bin/python3"))

def native_environment(cfg, public=False):
    import os
    env = dict(os.environ)
    cache = absolute(cfg.get("cache_root", "environments/vllm0320/cache"))
    for folder in ["xdg", "config", "torch", "cuda", "tmp"]:
        (cache / folder).mkdir(parents=True, exist_ok=True)
    env.update(HF_HOME=str(cache / "huggingface"), VLLM_CACHE_ROOT=str(cache / "vllm"),
               XDG_CACHE_HOME=str(cache / "xdg"), XDG_CONFIG_HOME=str(cache / "config"),
               TORCH_HOME=str(cache / "torch"), CUDA_CACHE_PATH=str(cache / "cuda"), TMPDIR=str(cache / "tmp"),
               TRITON_CACHE_DIR=str(cache / "triton"), TORCHINDUCTOR_CACHE_DIR=str(cache / "inductor"),
               FLASHINFER_WORKSPACE_BASE=str(cache / "flashinfer"),
               HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1",
               VLLM_NO_USAGE_STATS="1", DO_NOT_TRACK="1", FLASHINFER_NO_DOWNLOAD="1")
    no_proxy=env.get("NO_PROXY",env.get("no_proxy",""))
    env["NO_PROXY"]=",".join(x for x in [no_proxy,"127.0.0.1","localhost",cfg.get("lan_ip","")] if x)
    env["no_proxy"]=env["NO_PROXY"]
    auth = secrets()
    env["VLLM_API_KEY"] = auth["engine_api_key"]
    env["OPENAI_API_KEY"] = auth["public_api_key"] if public else auth["engine_api_key"]
    if cfg.get("local_library_dir"):
        local_lib = str(absolute(cfg["local_library_dir"]))
        env["LD_LIBRARY_PATH"] = local_lib + (":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
    return env
