"""Run using docker exec INSIDE an engine started with --airgap-check."""
import argparse
import json
import os
import time
import urllib.request
from client_lib import chat_once

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--port", type=int, default=8100)
    p.add_argument("--model", default="deepseek-local")
    p.add_argument("--timeout", type=float, default=1800)
    a = p.parse_args()
    base = f"http://127.0.0.1:{a.port}"
    deadline = time.monotonic() + a.timeout
    while True:
        try:
            with urllib.request.urlopen(base + "/health", timeout=3) as r:
                if r.status == 200:
                    break
        except OSError:
            pass
        if time.monotonic() > deadline:
            raise SystemExit("离线引擎未就绪；检查容器日志，不要把缺失依赖当成功。")
        time.sleep(5)
    cfg = {"base_url": base + "/v1", "api_key": os.environ["VLLM_API_KEY"], "model": a.model}
    results = []
    for stream in [False, True]:
        result = chat_once(cfg, [{"role": "user", "content": "用一句话解释 KV Cache。"}],
                           max_tokens=4096, stream=stream)
        if not result["content"]:
            raise SystemExit("没有最终正文；离线功能验收未通过。")
        results.append({"stream": stream, "finish_reason": result["finish_reason"],
                        "usage": result["usage"], "content_characters": len(result["content"]),
                        "metrics": result["metrics"]})
    print(json.dumps({"passed": True, "network_mode_expected": "none (另用 docker inspect 核验)",
                      "model": a.model, "checks": results}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
