"""Foreground launcher. Print commands with --dry-run; stop only this bundle's containers."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import shlex
import subprocess
import signal
import time
from common import ROOT, settings, profiles, models, model_path, docker_base, native_python, native_environment, write_json, read_json
from check_model import inspect_model

BUNDLE = hashlib.sha256(str(ROOT).encode()).hexdigest()[:16]

def validate_profile(profile):
    g=profile['gpus'];tp=profile['tp'];dp=profile['dp'];pp=profile.get('pp',1);pcp=profile.get('pcp',1);dcp=profile.get('dcp',1)
    if any(not isinstance(x,int) or x<1 for x in (tp,dp,pp,pcp,dcp)):raise ValueError('并行维度须为正整数')
    if tp*dp*pp*pcp!=len(g):raise ValueError('vLLM GPU 数=TP×DP×PP×PCP；DCP 不额外乘')
    if len(set(g))!=len(g) or any(not isinstance(x,int) or x<0 for x in g):raise ValueError('GPU 编号无效')
    if pcp==1 and tp%dcp:raise ValueError('PCP1 时 DCP 必须整除 TP')
    if pcp>1 and dcp not in (1,pcp,tp*pcp):raise ValueError('PCP>1 时 DCP 仅支持 1/PCP/TP×PCP')
    if profile.get('expert_parallel') and models()[profile['model']].get('kind')!='moe':raise ValueError('EP 要求 MoE')

def engine_command(cfg, profile, eager=False, tools=False, airgap=False):
    validate_profile(profile)
    role = profile.get("role", "engine")
    image = cfg["pd_image"] if role in ("prefill", "decode") else cfg["docker_image"]
    name = cfg["container_prefix"] + "-" + role
    cmd = docker_base(cfg, name, image, profile["gpus"])
    if airgap:
        cmd[cmd.index("--network") + 1] = "none"
        cmd += ["--env", "VLLM_HOST_IP=127.0.0.1", "--env", "NCCL_SOCKET_IFNAME=lo",
                "--env", "GLOO_SOCKET_IFNAME=lo", "--env", "NCCL_IB_DISABLE=1"]
    cmd += ["--label", "h800ds.bundle=" + BUNDLE,
            "--label", "h800ds.gpus=" + ",".join(map(str, profile["gpus"])),
            "--env", "HF_HUB_OFFLINE=1", "--env", "TRANSFORMERS_OFFLINE=1",
            "--env", "HF_HUB_DISABLE_TELEMETRY=1", "--env", "VLLM_NO_USAGE_STATS=1",
            "--env", "DO_NOT_TRACK=1", "--env", "FLASHINFER_WORKSPACE_BASE=/cache/flashinfer"]
    if profile.get("engram_cpu_offload"):
        cmd += ["--env", "VLLM_USE_V2_MODEL_RUNNER=1",
                "--env", "VLLM_USE_RUST_FRONTEND=1",
                "--env", "PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True",
                "--env", "VLLM_ENGINE_READY_TIMEOUT_S=3600"]
    if role in ("prefill", "decode"):
        cmd += ["--env", "VLLM_NIXL_SIDE_CHANNEL_HOST=127.0.0.1",
                "--env", "VLLM_NIXL_SIDE_CHANNEL_PORT=" + str(profile["side_channel_port"])]
    key = profile["model"]
    metadata = models()[key]
    port = cfg[{"engine": "engine_port", "prefill": "prefill_port", "decode": "decode_port"}[role]]
    cmd += ["--entrypoint", "vllm", image, "serve", "/models/" + metadata["directory"],
            "--served-model-name", cfg["model_alias"], "--host", "127.0.0.1", "--port", str(port),
            "--tensor-parallel-size", str(profile["tp"]), "--data-parallel-size", str(profile["dp"]),
            "--pipeline-parallel-size", str(profile.get("pp",1)),
            "--prefill-context-parallel-size", str(profile.get("pcp",1)),
            "--decode-context-parallel-size", str(profile.get("dcp",1)),
            "--max-model-len", str(profile["max_model_len"]),
            "--max-num-seqs", str(profile["max_num_seqs"]),
            "--max-num-batched-tokens", str(profile["max_num_batched_tokens"]),
            "--gpu-memory-utilization", str(cfg["gpu_memory_utilization"]),
            "--enable-prefix-caching" if profile.get("prefix_caching",True) else "--no-enable-prefix-caching", "--enable-chunked-prefill", "--generation-config", "vllm",
            "--structured-outputs-config", '{"backend":"xgrammar"}']
    if metadata["reasoning_parser"]:
        cmd += ["--reasoning-parser", metadata["reasoning_parser"]]
    if profile.get("expert_parallel"):
        cmd += ["--enable-expert-parallel"]
    if profile.get("attention_backend"):
        cmd += ["--attention-backend", profile["attention_backend"]]
    if key != "latest":
        cmd += ["--dtype", "auto" if key in ("awq","moe") else "bfloat16"]
    if key == "latest":
        cmd += ["--tokenizer-mode", metadata["tokenizer_mode"], "--language-model-only",
                "--engram-config", '{"cpu_offload":true}']
        if tools:
            cmd += ["--tool-call-parser", "deepseek_v41", "--enable-auto-tool-choice"]
    elif tools and metadata.get('tool_call_parser'):
        cmd+=['--tool-call-parser',metadata['tool_call_parser'],'--enable-auto-tool-choice']
    elif tools:
        raise ValueError('此模型未配置工具协议；使用dense --tools或已验收latest')
    if role in ("prefill", "decode"):
        cmd += ["--kv-transfer-config", json.dumps({
            "kv_connector": "NixlConnector",
            "kv_role": "kv_producer" if role == "prefill" else "kv_consumer",
            "kv_load_failure_policy": "fail"}, separators=(",", ":"))]
    for flag,field in [('quantization','quantization'),('kv-cache-dtype','kv_cache_dtype'),('kv-cache-memory-bytes','kv_cache_memory_bytes')]:
        if profile.get(field) is not None:cmd+=['--'+flag,str(profile[field])]
    if profile.get('hf_overrides'):cmd+=['--hf-overrides',json.dumps(profile['hf_overrides'])]
    if metadata.get('trust_remote_code'):cmd+=['--trust-remote-code']
    if profile.get('speculative_config'):
        spec=dict(profile['speculative_config'])
        if profile.get('draft'):spec['model']='/models/'+models()[profile['draft']]['directory']
        cmd+=['--speculative-config',json.dumps(spec)]
    if profile.get('profiler'):
        cmd+=['--profiler-config',json.dumps({'profiler':'torch','torch_profiler_dir':'/cache/traces',
            'capture_torch_profiler':bool(profile.get('capture_profiler',False)),
            'torch_profiler_with_memory':bool(profile.get('memory_profiler',False)),
            'torch_profiler_record_shapes':bool(profile.get('memory_profiler',False))})]
    if eager or profile.get("enforce_eager"):
        cmd += ["--enforce-eager"]
    return cmd

def proxy_command(cfg):
    image = cfg["pd_image"]
    cmd = docker_base(cfg, cfg["container_prefix"] + "-pdproxy", image, gpus=None)
    return cmd + ["--label", "h800ds.bundle=" + BUNDLE,
        "--entrypoint", "python3", image, "/lab/third_party/toy_proxy_server.py",
        "--host", "127.0.0.1", "--port", str(cfg["pd_proxy_port"]),
        "--prefiller-hosts", "127.0.0.1", "--prefiller-ports", str(cfg["prefill_port"]),
        "--decoder-hosts", "127.0.0.1", "--decoder-ports", str(cfg["decode_port"])]

def no_overlap(gpus):
    res = subprocess.run(["docker", "ps", "--filter", "label=h800ds.bundle=" + BUNDLE,
                          "--format", '{{.Names}}|{{.Label "h800ds.gpus"}}'],
                         capture_output=True, text=True, check=True)
    for line in res.stdout.splitlines():
        name, _, visible = line.partition("|")
        used = {int(x) for x in visible.split(",") if x}
        if used.intersection(gpus):
            raise SystemExit("GPU 与本包已有容器重叠：" + name + "；先按 docs/13_OPERATIONS.md 停止旧配置。")

def native_command(cfg, profile, eager=False, tools=False):
    docker_cmd = engine_command(cfg, profile, eager, tools)
    idx = docker_cmd.index("serve")
    argv = [str(native_python(cfg).parent / "vllm"), *docker_cmd[idx:]]
    argv[2] = str(model_path(profile["model"], cfg))
    if profile.get('speculative_config'):
        idx=argv.index('--speculative-config')+1;spec=json.loads(argv[idx])
        if profile.get('draft'):spec['model']=str(model_path(profile['draft'],cfg))
        argv[idx]=json.dumps(spec)
    if profile.get('profiler'):
        idx=argv.index('--profiler-config')+1;pro=json.loads(argv[idx]);from common import absolute
        pro['torch_profiler_dir']=str(absolute(cfg['cache_root'])/'traces');argv[idx]=json.dumps(pro)
    return argv

def process_start(pid):
    try:
        fields = ROOT.__class__(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return None if fields[0] in ("Z", "X") else fields[19]
    except (OSError, IndexError):
        return None

def is_running(record):
    return bool(record.get("bundle") == BUNDLE and record.get("start_ticks") is not None
                and process_start(record.get("proc_pid", record["pid"])) == record.get("start_ticks"))

def native_records():
    folder = ROOT / "data/runtime/processes"
    folder.mkdir(parents=True, exist_ok=True)
    records = []
    for file in folder.glob("*.json"):
        try:
            row = read_json(file)
            if is_running(row):
                records.append((file, row))
        except (OSError, ValueError, KeyError):
            pass
    return records

def register_native(role, profile_name, gpus, cmd):
    for _, row in native_records():
        if row["role"] == role or set(row.get("gpus", [])).intersection(gpus):
            raise SystemExit("本包进程尚在运行或 GPU 重叠：" + row["role"] + "；先执行 run.py stop")
    if os.getpgrp() != os.getpid():
        os.setsid()
    pid = os.getpid()
    proc_stat = (ROOT.__class__("/proc/self/stat").read_text())
    proc_pid = int(proc_stat.split("(", 1)[0].strip())
    start_ticks = proc_stat.rsplit(")", 1)[1].split()[19]
    write_json(ROOT / f"data/runtime/processes/{role}.json", {
        "bundle": BUNDLE, "pid": pid, "proc_pid": proc_pid, "pgid": os.getpgrp(), "start_ticks": start_ticks,
        "pid_namespace": os.stat("/proc/self/ns/pid").st_ino,
        "role": role, "profile": profile_name, "gpus": gpus, "command": cmd})

def stop_native(target):
    for file, row in native_records():
        if target != "all" and row["role"] != target:
            continue
        if row.get("pid_namespace") != os.stat("/proc/self/ns/pid").st_ino:
            raise SystemExit("进程处于另一个 PID namespace；拒绝用当前命名空间的 PID 停止。请到原运行环境处理。")
        if row["pgid"] != row["pid"] or os.getpgid(row["pid"]) != row["pgid"]:
            raise SystemExit("进程组身份不符，停止操作已拒绝；请人工检查 " + str(file))
        os.killpg(row["pgid"], signal.SIGTERM)
        deadline = time.monotonic() + 45
        while is_running(row) and time.monotonic() < deadline:
            time.sleep(0.2)
        if is_running(row):
            raise SystemExit("仍未退出，保留状态供排查；不自动杀其他进程。" + str(file))
        file.unlink(missing_ok=True)
        print("已停止", row["role"])

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="action", required=True)
    e = sub.add_parser("engine")
    e.add_argument("--profile", required=True)
    e.add_argument("--eager", action="store_true")
    e.add_argument("--tools", action="store_true")
    e.add_argument("--capture-profiler", action="store_true", help="Profile CUDA Graph capture on rank0; use graphs_on, not eager")
    e.add_argument("--memory-profiler", action="store_true", help="Record torch profiler memory events and tensor shapes; not a full device allocation snapshot")
    e.add_argument("--airgap-check", action="store_true", help="完全隔离网络，用 docker exec 在容器内验收")
    e.add_argument("--dry-run", action="store_true")
    e.add_argument("--backend", choices=["native", "docker"])
    proxy = sub.add_parser("pd-proxy")
    proxy.add_argument("--dry-run", action="store_true")
    proxy.add_argument("--backend", choices=["native", "docker"])
    g = sub.add_parser("gateway")
    g.add_argument("--mode", choices=["integrated", "pd"], default="integrated")
    sub.add_parser("list")
    stop = sub.add_parser("stop")
    stop.add_argument("target", choices=["engine", "prefill", "decode", "pdproxy", "gateway", "all"])
    stop.add_argument("--backend", choices=["native", "docker"])
    sub.add_parser("status")
    a = p.parse_args()
    cfg = settings()
    backend = getattr(a, "backend", None) or cfg.get("runtime", "native")
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]+", cfg["container_prefix"]):
        p.error("container_prefix 无效")
    if a.action == "list":
        for name, pro in profiles().items():
            validate_profile(pro)
            print(name, json.dumps(pro, ensure_ascii=False))
        return
    if a.action == "gateway":
        cmd = [str(native_python(cfg)), str(ROOT / "scripts/gateway.py"), "--mode", a.mode]
        register_native("gateway", a.mode, [], cmd)
        os.execv(cmd[0], cmd)
    if a.action == "status":
        for _, row in native_records():
            print(json.dumps(row, ensure_ascii=False))
        return
    if a.action == "stop":
        if backend == "native":
            stop_native(a.target)
            return
        # Filter by bundle label, so similarly named containers owned by others are untouched.
        res = subprocess.run(["docker", "ps", "--filter", "label=h800ds.bundle=" + BUNDLE,
                              "--format", "{{.Names}}"], capture_output=True, text=True, check=True)
        wanted = set(res.stdout.splitlines())
        if a.target != "all":
            wanted.intersection_update({cfg["container_prefix"] + "-" + a.target})
        for name in sorted(wanted):
            subprocess.run(["docker", "stop", "--time", "60", name], check=True)
        print("已停止本包所选容器；网关在其终端按 Ctrl+C 停止。")
        return
    pro = None
    if a.action == "engine":
        pro = profiles().get(a.profile)
        if pro is None:
            p.error("未知 profile；运行 python3 scripts/run.py list")
        if a.capture_profiler:
            if a.eager or pro.get('enforce_eager'):
                p.error('--capture-profiler 要求启用CUDA Graph，先选择8g/4g_graphs_on')
            pro=dict(pro,profiler=True,capture_profiler=True)
        if a.memory_profiler:pro=dict(pro,profiler=True,memory_profiler=True)
        if backend == "native" and a.airgap_check:
            p.error("--airgap-check 的 network=none 检验仅适用于可选 Docker 路线，见 17；主线不依赖 Docker")
        cmd = (native_command(cfg, pro, a.eager, a.tools) if backend == "native" else
               engine_command(cfg, pro, a.eager, a.tools, a.airgap_check))
    else:
        if backend == "native":
            cmd = [str(native_python(cfg)), str(ROOT / "third_party/toy_proxy_server.py"),
                   "--host", "127.0.0.1", "--port", str(cfg["pd_proxy_port"]),
                   "--prefiller-hosts", "127.0.0.1", "--prefiller-ports", str(cfg["prefill_port"]),
                   "--decoder-hosts", "127.0.0.1", "--decoder-ports", str(cfg["decode_port"])]
        else:
            cmd = proxy_command(cfg)
    print(shlex.join(cmd), flush=True)  # Secrets live only in the private env file, not argv.
    if a.dry_run:
        return
    if pro:
        result = inspect_model(model_path(pro["model"], cfg), pro["model"])
        if result["errors"]:
            raise SystemExit(json.dumps(result, ensure_ascii=False, indent=2))
        if backend == "docker":
            no_overlap(pro["gpus"])
    if backend == "native":
        if not native_python(cfg).is_file():
            raise SystemExit("缺少项目内 Python；先运行 bash scripts/bootstrap_offline.sh")
        version = subprocess.check_output([str(native_python(cfg)), "-c",
            "from importlib.metadata import version; print(version('vllm'))"], text=True).strip()
        if version.split('+')[0] != "0.32.0":
            raise SystemExit("vLLM 版本必须为 0.32.0，实际=" + version)
        env = native_environment(cfg)
        if pro:
            env["CUDA_VISIBLE_DEVICES"] = ",".join(map(str, pro["gpus"]))
            env["VLLM_HOST_IP"] = "127.0.0.1"
            if pro.get("engram_cpu_offload"):
                env.update(VLLM_USE_V2_MODEL_RUNNER="1", VLLM_USE_RUST_FRONTEND="1", PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True",
                           VLLM_ENGINE_READY_TIMEOUT_S="3600")
            if pro.get("role"):
                env.update(VLLM_NIXL_SIDE_CHANNEL_HOST="127.0.0.1",
                           VLLM_NIXL_SIDE_CHANNEL_PORT=str(pro["side_channel_port"]))
        role = pro.get("role", "engine") if pro else "pdproxy"
        register_native(role, getattr(a, "profile", "pd-proxy"), pro["gpus"] if pro else [], cmd)
        os.execvpe(cmd[0], cmd, env)
    os.execvp(cmd[0], cmd)

if __name__ == "__main__":
    main()
