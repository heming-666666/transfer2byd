"""Run official vLLM bench serve in the pinned image, using the public gateway."""
import argparse
import os
import shlex
import subprocess
from datetime import datetime, timezone
from common import ROOT, settings, models, profiles, docker_base, write_json, native_python, native_environment, model_path

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--profile", required=True, help="记录当前实际已启动的 profile；本脚本不会替你启动引擎")
    p.add_argument("--model", choices=list(models()), default=None)
    p.add_argument("--name", default="run")
    p.add_argument("--input-len", type=int, default=1024)
    p.add_argument("--output-len", type=int, default=256)
    p.add_argument("--requests", type=int, default=128)
    p.add_argument("--rate", default="4")
    p.add_argument("--max-concurrency", type=int)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--backend", choices=["native", "docker"])
    a = p.parse_args()
    cfg = settings()
    if a.profile not in profiles():p.error('未知profile')
    selected_model=profiles()[a.profile]['model']
    if a.model and a.model!=selected_model:p.error('--model必须与当前声明profile一致')
    a.model=selected_model
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_%f")
    import re
    if not re.fullmatch(r"[a-zA-Z0-9_.-]+", a.name):
        p.error("name 只能含字母、数字、下划线、点、短横线")
    out = ROOT / "data/results/benchmarks" / (stamp + "_" + a.name)
    out.mkdir(parents=True, exist_ok=False)
    cmd = docker_base(cfg, cfg["container_prefix"] + "-bench", cfg["docker_image"], engine_auth=False)
    cmd += ["--env-file", str(ROOT / "config/client.env"),
            "--mount", f"type=bind,src={out},dst=/out",
            "--entrypoint", "vllm", cfg["docker_image"], "bench", "serve",
            "--backend", "openai-chat", "--endpoint", "/v1/chat/completions",
            "--base-url", f"http://127.0.0.1:{cfg['public_port']}",
            "--model", cfg["model_alias"], "--tokenizer", "/models/" + models()[a.model]["directory"],
            "--dataset-name", "random", "--random-input-len", str(a.input_len),
            "--random-output-len", str(a.output_len), "--random-range-ratio", "1", "--num-prompts", str(a.requests),
            "--request-rate", str(a.rate), "--seed", "42", "--ignore-eos",
            "--save-result", "--result-dir", "/out", "--result-filename", "metrics.json",
            "--percentile-metrics", "ttft,tpot,itl,e2el", "--metric-percentiles", "50,95,99",
            "--goodput", "ttft:2000", "tpot:100"]
    if a.max_concurrency is not None:
        cmd += ["--max-concurrency", str(a.max_concurrency)]
    backend = a.backend or cfg.get("runtime", "native")
    if backend == "native":
        cmd = [str(native_python(cfg).parent / "vllm"), *cmd[cmd.index("bench"):]]
        cmd = [str(model_path(a.model, cfg)) if x.startswith("/models/") else
               str(out) if x == "/out" else x for x in cmd]
    manifest = {"time_utc": stamp, "arguments": vars(a),
        "declared_profile": profiles().get(a.profile), "settings_without_secrets": cfg,
        "command": cmd, "status": "DRY_RUN" if a.dry_run else "PENDING_EXECUTION",
        "slo_note": "示例 SLO: TTFT<=2000ms 且 TPOT<=100ms；非通用目标。"}
    write_json(out / "manifest.json", manifest)
    print(shlex.join(cmd), flush=True)
    print("结果目录:", out, flush=True)
    if not a.dry_run:
        result = subprocess.run(cmd, env=native_environment(cfg, public=True) if backend == "native" else None)
        manifest["status"] = "COMMAND_EXITED_ZERO" if result.returncode == 0 else "FAILED"
        manifest["returncode"] = result.returncode
        manifest["note"] = "退出码为零后仍须查看 metrics.json 中失败请求数和 SLO；不能仅凭退出码判定性能验收通过。"
        write_json(out / "manifest.json", manifest)
        raise SystemExit(result.returncode)

if __name__ == "__main__":
    main()
