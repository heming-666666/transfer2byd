# vLLM 独立补充包 · 0.32.0 · 默认8卡/对照4卡

此目录可独立阅读与配置，不需要先读SGLang指南。保留了基础启动/鉴权/聊天/离线环境脚本，并补充本次全部新实验。两个框架共用 `../shared/` 权重、数据与公共测量工具，但**不共用venv、密钥或服务端口**。整体解压时保留shared目录。

| 顺序 | 文件 | 内容 |
|---|---|---|
| 01 | [OFFLINE_ENV.md](docs/01_OFFLINE_ENV.md) | 项目内原生环境、完整离线资产 |
| 02 | [BASELINE_AND_LAN.md](docs/02_BASELINE_AND_LAN.md) | 4/8卡模型部署、Key、另一台机器聊天与会话 |
| 03 | [PARALLEL_TP_DP_PP_CP_SP.md](docs/03_PARALLEL_TP_DP_PP_CP_SP.md) | TP/DP/PP/PCP/DCP/SP |
| 04 | [EP_AND_EXPERTS.md](docs/04_EP_AND_EXPERTS.md) | EP、all-to-all、激活top-k |
| 05 | [KV_AND_COMMUNICATION.md](docs/05_KV_AND_COMMUNICATION.md) | NVLink、KV池/块/通信 |
| 06 | [ATTENTION_AND_GRAPH.md](docs/06_ATTENTION_AND_GRAPH.md) | Attention backend与CUDA Graph |
| 07 | [QUANTIZATION.md](docs/07_QUANTIZATION.md) | 权重FP8/AWQ、KV FP8及校准 |
| 08 | [PD.md](docs/08_PD.md) | NIXL P4D4 / P2D2、传输验收 |
| 09 | [SPECULATIVE.md](docs/09_SPECULATIVE.md) | ngram、EAGLE3、DFlash、MTP/DSpark边界 |
| 10 | [PROFILING_SM_KERNEL.md](docs/10_PROFILING_SM_KERNEL.md) | PyTorch、Perfetto、Nsight、SM、CPU与kernel |
| 11 | [BENCH_SLO_GOODPUT.md](docs/11_BENCH_SLO_GOODPUT.md) | 官方性能、联合SLO、goodput |
| 12 | [QUALITY_AND_CONSTRAINTS.md](docs/12_QUALITY_AND_CONSTRAINTS.md) | 模型能力bench、约束JSON/regex/grammar、tools |
| 13 | [OPERATIONS.md](docs/13_OPERATIONS.md) | 停止、离线、迁移、故障 |
| 14 | [SOURCES.md](docs/14_SOURCES.md) | vLLM固定源码与版本差异 |
| 15 | [COMPLETE_RUN.md](docs/15_COMPLETE_RUN.md) | 独立8/4卡验收、SLO/能耗、Graph准备与memory事件 |

默认模型 `lab=DeepSeek-R1-Distill-Qwen-32B`，8卡TP8与4卡TP4；`dense=Qwen3-8B`做小模型机制实验，`moe=Qwen3-30B-A3B-FP8`做EP。较新V4.1-Flash-1017沿用独立条件profile，CPU Engram offload需要大量RAM与该版本实现，不能将它当所有4卡都可跑的基线。

本制作环境没有H800；CPU验证与GPU/内网/PD状态见总根 [90_VALIDATION_REPORT.md](../90_VALIDATION_REPORT.md)。所有真实性能与能力分数待本机验收，源码支持不等于本云机实测。
