"""Meaningful CPU integration checks; never claims CUDA/model verification."""
import contextlib
import importlib
import json
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from gateway import make_server
from client_lib import chat_once
from check_model import inspect_model
from run import engine_command, validate_profile
import run as launcher
import bootstrap_env
from common import read_json

class MockHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *_):
        pass
    def send_json(self, value, status=200):
        data = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        if self.headers.get("Authorization") != "Bearer engine-secret":
            self.send_json({"error": "engine auth failed"}, 401)
        else:
            self.send_json({"data": [{"id": "deepseek-local"}]})
    def do_POST(self):
        if self.headers.get("Authorization") != "Bearer engine-secret":
            self.send_json({"error": "engine auth failed"}, 401)
            return
        data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        self.server.requests.append(data)
        usage = {"prompt_tokens": 8, "completion_tokens": 3, "total_tokens": 11}
        if not data.get("stream"):
            self.send_json({"choices": [{"message": {"content": "你好，缓存！", "reasoning": "模拟推理"}, "finish_reason": "stop"}], "usage": usage})
            return
        events = [
            {"choices": [{"delta": {"reasoning": "模拟推理"}, "finish_reason": None}]},
            {"choices": [{"delta": {"content": "你好，"}, "finish_reason": None}]},
            {"choices": [{"delta": {"content": "缓存！"}, "finish_reason": "stop"}]},
            {"choices": [], "usage": usage}]
        body = b"".join(("data: " + json.dumps(e, ensure_ascii=False) + "\n\n").encode() for e in events)
        body += b"data: [DONE]\n\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        # Deliberately split inside UTF-8 / JSON bytes to test transport buffering.
        for pos in range(0, len(body), 7):
            self.wfile.write(body[pos:pos+7])
            self.wfile.flush()

@contextlib.contextmanager
def running(server):
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        yield server
    finally:
        server.shutdown()
        server.server_close()
        t.join(2)

class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.stack = contextlib.ExitStack()
        backend = ThreadingHTTPServer(("127.0.0.1", 0), MockHandler)
        backend.requests = []
        cls.backend = cls.stack.enter_context(running(backend))
        cfg = read_json(ROOT / "config/settings.example.json")
        cfg.update(public_host="127.0.0.1", public_port=0, engine_port=backend.server_port,
                   decode_port=backend.server_port, pd_proxy_port=backend.server_port)
        cls.cfg = cfg
        cls.gateway = cls.stack.enter_context(running(make_server(cfg, {
            "public_api_key": "public-secret", "engine_api_key": "engine-secret"},
            audit_dir=Path(cls.temp.name) / "audit")))
        cls.client = {"base_url": f"http://127.0.0.1:{cls.gateway.server_port}/v1",
                      "api_key": "public-secret", "model": "deepseek-local"}
    @classmethod
    def tearDownClass(cls):
        cls.stack.close()
        cls.temp.cleanup()
    def call(self, path, key=None, data=None):
        url = self.client["base_url"].rsplit("/v1", 1)[0] + path
        headers = {} if key is None else {"Authorization": "Bearer " + key}
        body = json.dumps(data).encode() if data is not None else None
        try:
            with urllib.request.urlopen(urllib.request.Request(url, body, headers), timeout=5) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()
    def test_documented_smoke_cli_runs_generation(self):
        with tempfile.TemporaryDirectory() as t:
            c=Path(t)/'client.json';c.write_text(json.dumps(self.client));out=Path(t)/'smoke.json'
            r=subprocess.run([sys.executable,str(ROOT/'scripts/smoke_test.py'),'--config',str(c),'--with-generation','--out',str(out)],capture_output=True,text=True,timeout=20)
            self.assertEqual(r.returncode,0,r.stdout+r.stderr)
            report=json.loads(out.read_text());self.assertTrue(report['generation_tested']);self.assertTrue(report['passed'])
    def test_missing_key(self):
        self.assertEqual(self.call("/v1/models")[0], 401)
    def test_wrong_key(self):
        self.assertEqual(self.call("/v1/models", "wrong")[0], 401)
    def test_model_route_uses_private_engine_key(self):
        status, body = self.call("/v1/models", "public-secret")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["data"][0]["id"], "deepseek-local")
    def test_unprotected_vllm_paths_not_exposed(self):
        for path in ["/invocations", "/metrics", "/tokenize", "/v1/models?debug=1"]:
            self.assertEqual(self.call(path, "public-secret")[0], 404)
    def test_internal_kv_request_blocked(self):
        self.assertEqual(self.call("/v1/chat/completions", "public-secret", {
            "model": "deepseek-local", "kv_transfer_params": {"remote_host": "bad"}})[0], 400)
    def test_wrong_model_blocked(self):
        self.assertEqual(self.call("/v1/chat/completions", "public-secret", {"model": "wrong"})[0], 400)
    def test_nonstream_chat(self):
        result = chat_once(self.client, [{"role": "user", "content": "测试"}], stream=False)
        self.assertEqual(result["content"], "你好，缓存！")
        self.assertEqual(result["usage"]["completion_tokens"], 3)
    def test_stream_unicode_reasoning_usage(self):
        chunks = []
        result = chat_once(self.client, [{"role": "user", "content": "测试"}], on_content=chunks.append)
        self.assertEqual("".join(chunks), "你好，缓存！")
        self.assertEqual(result["reasoning"], "模拟推理")
        self.assertEqual(result["finish_reason"], "stop")
        self.assertEqual(result["usage"]["completion_tokens"], 3)
    def test_pd_gateway_models_and_chat(self):
        with running(make_server(self.cfg, {"public_api_key": "public-secret", "engine_api_key": "engine-secret"},
                                mode="pd", audit_dir=Path(self.temp.name) / "pd_audit")) as server:
            cfg = {**self.client, "base_url": f"http://127.0.0.1:{server.server_port}/v1"}
            result = chat_once(cfg, [{"role": "user", "content": "PD route"}])
            self.assertEqual(result["content"], "你好，缓存！")
    def test_cli_saves_and_resumes_without_keys_in_history(self):
        directory = Path(self.temp.name) / "client_test"
        directory.mkdir()
        config = directory / "client.json"
        config.write_text(json.dumps(self.client))
        cmd = [sys.executable, str(ROOT / "scripts/chat.py"), "--config", str(config),
               "--history-dir", str(directory / "conversations"), "--message", "第一轮"]
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        state = next((directory / "conversations").glob("*/conversation.json"))
        subprocess.run(cmd[:-1] + ["第二轮", "--resume", str(state)], check=True, capture_output=True, text=True)
        saved = json.loads(state.read_text())
        self.assertEqual(len(saved["messages"]), 4)
        self.assertNotIn("public-secret", state.read_text())
        self.assertNotIn("reasoning", saved["messages"][-1])
    def test_audit_excludes_keys_and_content(self):
        self.call("/v1/models", "public-secret")
        content = "".join(p.read_text() for p in (Path(self.temp.name) / "audit").glob("*.jsonl"))
        for forbidden in ["public-secret", "engine-secret", "模拟推理", "你好，缓存"]:
            self.assertNotIn(forbidden, content)

class ConfigTests(unittest.TestCase):
    def test_native_command_uses_local_model_and_local_environment(self):
        cfg=read_json(ROOT/'config/settings.example.json')
        profile=read_json(ROOT/'config/profiles.json')['lab_tp2']
        cmd=launcher.native_command(cfg,profile)
        self.assertTrue(cmd[0].startswith(str(ROOT/'environments/')))
        self.assertTrue(cmd[2].startswith(str((ROOT/'../shared/models').resolve())))
        self.assertNotIn('/models/',cmd[2][:9])
        self.assertNotIn('docker',cmd)
    def test_capture_profiler_flag_uses_rank0_capture_config(self):
        c=read_json(ROOT/'config/settings.example.json');ps=read_json(ROOT/'config/profiles.json')
        pro=dict(ps['8g_graphs_on'],profiler=True,capture_profiler=True)
        cmd=launcher.native_command(c,pro);v=json.loads(cmd[cmd.index('--profiler-config')+1])
        self.assertTrue(v['capture_torch_profiler']);self.assertEqual(v['profiler'],'torch')
        self.assertIn('/environments/vllm0320/cache/traces',v['torch_profiler_dir'])
    def test_memory_profiler_enables_memory_and_shape_events(self):
        c=read_json(ROOT/'config/settings.example.json');ps=read_json(ROOT/'config/profiles.json')
        pro=dict(ps['4g_profile'],profiler=True,memory_profiler=True)
        cmd=launcher.native_command(c,pro);v=json.loads(cmd[cmd.index('--profiler-config')+1])
        self.assertTrue(v['torch_profiler_with_memory']);self.assertTrue(v['torch_profiler_record_shapes'])
        self.assertFalse(v['capture_torch_profiler'])
    def test_missing_offline_file_stops_before_install(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'environments').mkdir()
            (root/'environments/OFFLINE_MANIFEST.json').write_text(json.dumps({
                'architecture':'x86_64','files':[{'path':'missing.whl','bytes':100,'sha256':'bad'}]}))
            with mock.patch.object(bootstrap_env,'ROOT',root), mock.patch.object(sys,'argv',['bootstrap_env.py']):
                with self.assertRaises(SystemExit):
                    bootstrap_env.main()
    def test_native_stop_targets_only_its_recorded_process_group(self):
        with tempfile.TemporaryDirectory() as tmp:
            code=("import sys,os; sys.path.insert(0,"+repr(str(ROOT/'scripts'))+"); import run; from pathlib import Path; "
                  "run.ROOT=Path("+repr(tmp)+"); run.BUNDLE='unit-test'; "
                  "run.register_native('engine','fake',[0],['unit-test']); "
                  "os.execv(sys.executable,[sys.executable,'-c','import time; time.sleep(30)'])")
            child=subprocess.Popen([sys.executable,'-c',code])
            try:
                state=Path(tmp)/'data/runtime/processes/engine.json'
                deadline=time.monotonic()+5
                while not state.exists() and time.monotonic()<deadline:
                    time.sleep(.02)
                self.assertTrue(state.exists())
                with mock.patch.object(launcher,'ROOT',Path(tmp)),mock.patch.object(launcher,'BUNDLE','unit-test'):
                    launcher.stop_native('engine')
                child.wait(timeout=5)
                self.assertFalse(state.exists())
            finally:
                if child.poll() is None:
                    child.kill(); child.wait()
    def test_all_profiles_have_valid_gpu_partition(self):
        for profile in read_json(ROOT / "config/profiles.json").values():
            validate_profile(profile)
    def test_pd_pools_disjoint_and_total_eight(self):
        profiles = read_json(ROOT / "config/profiles.json")
        p, d = set(profiles["pd_p4"]["gpus"]), set(profiles["pd_d4"]["gpus"])
        self.assertFalse(p & d)
        self.assertEqual(p | d, set(range(8)))
    def test_latest_is_not_generic_blackwell_fp4_command(self):
        cfg = read_json(ROOT / "config/settings.example.json")
        profile = read_json(ROOT / "config/profiles.json")["latest_tp8"]
        cmd = engine_command(cfg, profile)
        self.assertIn("deepseek_v41", cmd)
        self.assertIn('--engram-config', cmd)
        self.assertNotIn('nvfp4', cmd)
        self.assertIn('127.0.0.1', cmd)
    def test_moe_ep_is_not_dense_dp(self):
        cfg = read_json(ROOT / "config/settings.example.json")
        profiles = read_json(ROOT / "config/profiles.json")
        self.assertIn('--enable-expert-parallel', engine_command(cfg, profiles['moe_dp8_ep']))
        self.assertNotIn('--enable-expert-parallel', engine_command(cfg, profiles['lab_tp2_dp4']))
    def test_model_missing_shard_and_lfs_pointer(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)
            for name in ['config.json', 'tokenizer.json']:
                (p/name).write_text('{}')
            (p/'tokenizer_config.json').write_text('{"chat_template":"hello"}')
            (p/'model.safetensors.index.json').write_text('{"weight_map":{"a":"shard.safetensors"}}')
            self.assertFalse(inspect_model(p,'lab')['files_check_ok'])
            (p/'shard.safetensors').write_text('version https://git-lfs.github.com/spec/v1')
            self.assertFalse(inspect_model(p,'lab')['files_check_ok'])
            (p/'shard.safetensors').write_bytes(b'x'*2048)
            self.assertTrue(inspect_model(p,'lab')['files_check_ok'])

if __name__ == "__main__":
    unittest.main(verbosity=2)
