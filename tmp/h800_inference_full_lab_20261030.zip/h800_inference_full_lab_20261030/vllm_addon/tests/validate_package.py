"""Use the unified static validation; this supplement remains independently readable."""
import runpy
from pathlib import Path
if __name__=='__main__':runpy.run_path(str(Path(__file__).resolve().parents[2]/'tests/validate_bundle.py'),run_name='__main__')
