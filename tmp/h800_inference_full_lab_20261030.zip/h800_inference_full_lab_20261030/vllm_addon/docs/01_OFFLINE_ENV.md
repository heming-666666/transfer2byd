# 01 · 原生离线环境

在 `vllm_addon/` 执行。所有环境放本目录子文件夹；默认不用Docker，不在系统Python装包。要求Linux x86_64、CPython3.12、manylinux/glibc匹配，宿主机driver可加载所选CUDA运行时。

先 `python3 scripts/preflight.py` 保存GPU/driver/拓扑/RAM/cgroup/网络。完整依赖固定vLLM0.32.0、NIXL1.5.0、FlashInfer0.7.0.post1等，入口在 `environments/vllm0320/requirements.in`。与SGLang Torch版本不同，不能共用venv。

准备官方 [python-build-standalone](https://github.com/astral-sh/python-build-standalone/releases) CPython3.12、Linux x86_64 GNU install_only归档及官方SHA256。准备机Linux/Python3.12：

```bash
TASK_PY_ARCHIVE=/absolute/prepared/cpython-3.12-linux-x86_64-install_only.tar.gz
TASK_PY_SHA256=REPLACE_WITH_REAL_OFFICIAL_SHA256
python3.12 scripts/prepare_offline_env.py --python-archive "$TASK_PY_ARCHIVE" \
  --python-sha256 "$TASK_PY_SHA256" --cuda cu130
```

cu130主线要求匹配CUDA13 driver（通常R580+）。此vLLM版本还提供cu129路径，可用独立清洁wheelhouse在准备阶段 `--cuda cu129`，脚本取对应官方vLLM wheel并核对Torch CUDA变体。不能混用cu129/cu130资产，不能把这个路径套给SGLang0.5.22。

无法终端下载时先从可信制品源备齐所有传递依赖wheel，再同一命令加 `--use-existing-wheels`；脚本离线dry-run验证闭包、写lock、resolution及OFFLINE_MANIFEST。PyPI、PyTorch、FlashInfer及其CDN可能并非均可达；GitHub可达不等于其他源可达。

目标机：

```bash
bash scripts/bootstrap_offline.sh
./environments/vllm0320/.venv/bin/python3 -m pip check
./environments/vllm0320/.venv/bin/torchrun --standalone --nproc_per_node=8 scripts/gpu_probe.py
```

4卡nproc4。Python归档/wheel/lock缺失或哈希不同直接失败，不回退联网。移动目录后 `bash scripts/bootstrap_offline.sh --rebuild`；重新configure路径。

GPU kernel仍可能需要本地toolkit/nvcc、头文件或预编译cache。用户态toolkit放 `environments/toolkit/`、动态库放本项目目录并配置local_library_dir；不把驱动装进venv。逐项预热新backend/graph/spec/NIXL，关闭对外下载后真实重新生成，才算该组合离线可用。
