# 13 · 停止、迁移、离线与故障

```bash
python3 scripts/run.py status
python3 scripts/run.py stop engine
python3 scripts/run.py stop all
```

仅操作本包登记的进程组或带本包label的容器；不全局pkill。停止后查GPU显存与端口是否回收，保留异常日志，不删权重/会话。

配置、环境、权重、会话、结果路径相对本目录或../shared；model_root从项目根解析。移动后重新configure模型路径并由Python归档/wheelhouse/lock/manifests重建venv；旧PID登记不是可迁移服务状态。私密config文件600，日志/manifest不写Key。

离线验收需关闭允许下载阶段的外网后重新起模型并实际生成、流式/非流式/多轮、另一内网机器。HF offline变量不足以证明所有kernel库不外连；检查实际联网和缺资源错误。JIT工具链、FlashInfer/cubin/cache、NIXL动态库都应本地齐备。

Docker可选：原launcher支持 `--backend docker`，镜像与PD镜像需先保存tar/digest并导入。Dockerfile.pd只是构建材料，目标Docker不可用时继续native，不要求改全局daemon/driver。`--airgap-check`仅为可选Docker network=none测试，不能用它破坏客户端所需内网；native主线不依赖Docker。

常见：driver不匹配看宿主机；缺wheel看完整闭包；缺nvcc看本地toolkit；OOM区分weights/KV/activation/graph；NCCL看拓扑/P2P/IPC/网卡；API空正文看reasoning预算/template/PD；内网不通看真实IP/监听/ACL。每项写实际错误与下一条诊断，不反复重启打断编译。

`latest_tp8`是V4.1-Flash-1017独立配置，Engram CPU offload需要大量RAM/NUMA/hugepage/带宽条件，8卡总显存足够也不能承诺运行正常；不提供伪造4卡保证。先完成lab和dense基线；前沿模型失败不影响4/8卡其他机制实验。

填写data/reports/deployment_status.json，CPU/GPU/模型/内网/PD/性能/能力分别留证。所有未跑实机项保持NOT_RUN。
