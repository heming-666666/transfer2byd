# 10 · PyTorch、Perfetto、Nsight、SM与CPU时间

可选 [自定义SM/CTA探针](../../shared/docs/09_SM_CTA_PROBE.md) 提供物理SM ID区间原理实验；不同Torch环境须重建各自extension，不共用.so。

先启动 `8g_profile/4g_profile`，其中profiler-config把Torch trace定到本项目cache/traces，关闭graph便于初学观察。ready+网关后：

```bash
python3 ../shared/scripts/profile_capture.py --framework vllm --action capture --requests 6 --max-tokens 128
```

trace目录：`environments/vllm0320/cache/traces/`，多rank分别分析。随后对实际文件运行shared trace_summary，内网Perfetto按公共05准备整套静态UI。

vLLM0.32还有内置CUDA Graph捕获期Profiler（仅rank0），可在启动前启用：

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine \
  --profile "${CARDS}g_graphs_on" --capture-profiler
```

它向profiler-config写 `capture_torch_profiler=true`，结果在配置目录的 `capture_traces/`。这是捕获阶段PyTorch trace，不代表所有rank，也不自动给出纯instantiate API时间；全部rank与CPU API分解仍用Nsight。4卡改CARDS4，不能与eager一起使用。

| 想知道 | 方法 |
|---|---|
| 哪些kernel/多少次/多长 | Nsight Systems node-level CUDA trace + stats/SQLite |
| CPU提交通信多久 | c10d/NVTX/CPU API wall + 对应GPU NCCL stream |
| GPU用了多少SM | 设备SM数、SM active时序、NCU occupancy/实例计数分别报告 |
| 图准备多久 | 从真实engine启动前Nsight采warmup/capture/instantiate/upload |
| 稳态图replay开销 | graphs_off/on同负载，CPU提交与GPU事件分开 |

完整命令、统计脚本、4/8卡示例、计数器权限和定义独立写在 [shared08](../../shared/docs/08_NSIGHT_SM_KERNEL.md)，不依赖SGLang章节。将其中engine末尾命令替换为本目录 `environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile 8g_graphs_on`，输出命名vllm；4卡使用4g。

可先用本vLLM venv跑公共 `gpu_stages.py --cards 8/4`（torchrun对应卡数）认识CPU提交、work.wait、device sync、graph capture/replay。外挂Nsight时加 --no-torch-profiler，避免CUPTI冲突。

kernel总dur在多stream/多GPU下可重叠；CPU API wall可能含阻塞，不能直接叫CPU busy。Nsight SQLite脚本按设备计算kernel活动区间并集并导出逐kernel事件，保留进程/stream/correlation；不做跨进程同号ID猜测。

SM active是时空平均，occupancy是warp槽占用；都不等于某瞬间精确SM整数。root云实例也可能无计数器权限，写UNAVAILABLE_COUNTER_PERMISSION而不按GPU util猜数。NCU会重放/串行化kernel，先对独立GEMM等小复现，不对在线多卡NCCL服务无过滤full profile。最终goodput重新在无Profiler轮测。
