# 14 · vLLM固定源码与差异

- [v0.32.0 release](https://github.com/vllm-project/vllm/releases/tag/v0.32.0)
- [parallel.py](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/config/parallel.py)：TP/PP/DP/PCP/DCP/EP组
- [attention.py](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/config/attention.py)、[backend registry](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/v1/attention/backends/registry.py)
- [cache.py](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/config/cache.py)、[FP8 KV文档](https://github.com/vllm-project/vllm/blob/v0.32.0/docs/features/quantization/quantized_kvcache.md)
- [speculative.py](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/config/speculative.py)：MTP/DSpark/DFlash、匹配与拒绝条件
- [NIXLConnector示例](https://github.com/vllm-project/vllm/tree/v0.32.0/examples/disaggregated)：保留本包third_party来源说明
- [EvalScope v1.14.1](https://github.com/modelscope/evalscope/tree/v1.14.1)、[Harness v0.4.13](https://github.com/EleutherAI/lm-evaluation-harness/tree/v0.4.13)

重要差异：PCP要额外乘world size，DCP不乘；没有本包泛用--sp-size；旧--calculate-kv-scales不再使用；attention枚举大写；DeepSeekR1 parser为deepseek_r1；regex/grammar放structured_outputs；SGLang管理/PD参数不能通用。

每次实验保留本地 `vllm serve --help`、`vllm bench serve --help`、版本freeze与actual argv。源码字段检查不等于GPU/模型数值验证；CPU mock通过不等于H800、NVLink、NIXL或SM计数器已通过。
