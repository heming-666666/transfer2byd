# 04 · EP、all-to-all与专家激活

模型Qwen3-30B-A3B-FP8，8/4卡分别 `8g_ep_off/on`、`4g_ep_off/on`。enable-expert-parallel让MoE专家分布到相应parallel组，不是额外TP×EP倍卡数。实际EP组跨度涉及TP/PCP/DP，需读启动日志并核对rank。

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_ep_on"
```

对照ep_off，保持同模型同负载。trace看dispatch/combine、all-to-all、每rank计算与拖尾。all-to-all backend选择以本机 `vllm serve --help` 和0.32源码为准；不把SGLang `--moe-a2a-backend`直接用于vLLM。新backend另建profile，在launcher增加经验证的参数，保留实际选择日志。

`8g/4g_experts_top8`与`experts_top4`使用相同EP配置，top4通过 `--hf-overrides '{"num_experts_per_tok":4}'`。它改变模型函数/质量，不是无损优化；原checkpoint不覆盖。比较固定任务正确率、latency/goodput与通信；总专家权重仍需常驻，激活变少不代表权重内存同比减少。

SGLang的base64 routed_experts接口不是vLLM通用协议，本包不杜撰同名API。vLLM逐token逐层专家ID捕获需模型/runner明确支持或按固定源码加本地只读hook，单独记录插桩开销；没有捕获能力时报告不可用，不能用GPU利用率猜专家分布。

公共all-to-all/NVLink测试见 [shared通信](../../shared/docs/01_COMMUNICATION.md)。通过：rank配置正确、真实生成与质量回归，量化与backend使用有日志证据。
