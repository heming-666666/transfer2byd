# 15 · vLLM独立完整练习：8/4卡服务、SLO、能耗与归因

本章不依赖SGLang配置或环境。所有命令在 `vllm_addon/`；先完成本框架01–02的离线资产、原生venv、权重、Key、runtime/GPU检查和DeepSeek基线真实聊天。版本仍固定0.32.0。机制测量用Qwen3-8B的graphs_off/on；它的结果不代表DeepSeek模型。

## 1. 正常启动与功能验收

先结束本包旧进程；不能和SGLang占用同一GPU：

```bash
python3 scripts/run.py status
python3 scripts/run.py stop all
```

终端A选卡数并前台运行：

```bash
CARDS=8
python3 scripts/run.py engine --profile "${CARDS}g_graphs_off" --dry-run
python3 scripts/run.py engine --profile "${CARDS}g_graphs_off"
```

4卡用`CARDS=4`。终端B等待引擎ready后启动公共网关：

```bash
python3 scripts/wait_ready.py --target engine
python3 scripts/run.py gateway
```

终端C运行标准库验收，不需要安装OpenAI客户端库：

```bash
python3 ../shared/scripts/accept_service.py --client-config config/client.json \
  --max-tokens 256 --extra-json ../shared/fixtures/qwen3_nonthinking.json \
  --output ../shared/results/vllm_8g_qwen3_graphoff_trial01/acceptance
```

检查六项：无Key401、错Key401、模型别名、非流式最终正文、流式正文及DONE、带三条历史的第二轮校验码记忆。必须有最终正文且finish_reason=stop，reasoning-only或length不算功能通过。结果含acceptance.json及这轮conversation.json；正式长期对话仍用02章客户端/history目录。目录存在则更换trial，不覆盖。

DeepSeek-R1基线不要加Qwen3专用nonthinking参数，max-tokens从4096起并依据实际思考长度/上下文调整。另一台内网机器复制public client配置及标准库脚本部分，在那台机器上运行同一验收；只能发public Key，不能暴露engine/admin凭据。

## 2. 无Profiler闭环

```bash
python3 ../shared/scripts/slo_bench.py --client-config config/client.json \
  --mode closed --requests 64 --concurrency 4 --max-tokens 256 --warmup 4 \
  --extra-json ../shared/fixtures/qwen3_nonthinking.json \
  --output ../shared/results/vllm_8g_qwen3_graphoff_trial01/closed
```

默认prompt小样本仅用于流程。正式比较换固定revision/哈希和足够规模的数据集；检查真实输出token长度、usage完整性、截断、失败。SLO示例不是H800容量承诺。默认goodput要求最终content非空，length截断会单列，能力正确性另做12章基准。

## 3. 同机资源采样和开环

终端D先采样，物理GPU index与profile一致：

```bash
CARDS=8
case "$CARDS" in
  8) H800_GPU_IDS=0,1,2,3,4,5,6,7 ;;
  4) H800_GPU_IDS=0,1,2,3 ;;
  *) exit 2 ;;
esac
python3 ../shared/scripts/resource_monitor.py --gpus "$H800_GPU_IDS" --interval 1 --duration 300 \
  --output "../shared/results/vllm_${CARDS}g_qwen3_graphoff_trial01/resources"
```

终端C看见D打印目录后发压：

```bash
CARDS=8
python3 ../shared/scripts/slo_bench.py --client-config config/client.json \
  --mode open --arrival constant --rate 2 --requests 128 --concurrency 16 \
  --max-tokens 256 --warmup 4 --timeout 180 \
  --extra-json ../shared/fixtures/qwen3_nonthinking.json \
  --output "../shared/results/vllm_${CARDS}g_qwen3_graphoff_trial01/slo"
```

压测全部drain完后再停止D或等其自然结束，最后一个功率点应晚于最后finish。超长drain可能超过300秒，需增加duration，用新trial重跑，不外推补缺测。

```bash
CARDS=8
python3 ../shared/scripts/energy_report.py \
  --resources "../shared/results/vllm_${CARDS}g_qwen3_graphoff_trial01/resources" \
  --slo-summary "../shared/results/vllm_${CARDS}g_qwen3_graphoff_trial01/slo/summary.json" \
  --max-gap 2.5 --min-coverage 0.99 \
  --output "../shared/results/vllm_${CARDS}g_qwen3_graphoff_trial01/energy.json"
```

采样/压测均在GPU主机执行；脚本验证hostname/boot_id/time namespace/单调时钟一致，跨主机拒绝直接积分。另一台客户端可另测远端SLO，不直接与这台GPU的perf_counter_ns对齐。详细字段和覆盖算法见 [公共11](../../shared/docs/11_RESOURCES_ENERGY_CLOCKS.md)，它不依赖SGLang。

保存每卡显存、利用率、功率、query耗时和UUID；功率只代表设备，不含CPU/NIC/插座能耗。缺测不会当0。GPU utilization不是SM占用数，kernel与SM按10章/公共08采集。

## 4. 容量、4卡与graph对照

从2/4/8/16…req/s做率阶梯，接近SLO拐点再细分，每点至少3轮。每一轮使用新目录，固定模型revision、输入/输出长度、SLO、缓存冷暖状态；联合SLO比例用所有计划请求作分母，包含客户端限流丢弃/HTTP失败。不要只比较TTFT和TPOT各自p95。看request_goodput、target_met、失败、队列和尾延迟。

恢复服务改成4卡profile重跑，所有命令CARDS/目录/GPU列表一起改。比较固定负载与各自最大容量两组结果，报告能耗覆盖率和真实token分布。

Graph准备轮次：

```bash
python3 scripts/run.py stop all
CARDS=8
python3 scripts/run.py engine --profile "${CARDS}g_graphs_on" --capture-profiler --memory-profiler
```

capture_torch_profiler只采rank0捕获，输出 `environments/vllm0320/cache/traces/capture_traces/`。memory-profiler开启Torch memory事件和shapes，不能宣称自动得到全设备/全rank allocator snapshot。`--capture-profiler`不能与eager混用；4卡用4g_graphs_on。

正式graph-on成绩需停止服务后**不带两个profiler参数**重启graphs_on，再按相同负载重跑，目录改graphon。捕获轮次不能作稳定运行成绩；graph内存改变KV容量时，另做固定KV容量的公平对照。

steady-state memory/CPU/kernel轮次，先用 `8g_profile/4g_profile --memory-profiler` 启动并运行网关，再：

```bash
python3 ../shared/scripts/profile_capture.py --framework vllm --target engine \
  --action capture --requests 6 --max-tokens 128
```

内网Perfetto按公共05备齐UI资产。Nsight Systems归因CPU API提交/等待、NCCL/kernel次数与耗时；Nsight Compute按kernel抽样看SM/occupancy。不要把各stream时长求和当E2E，或把CPU API墙钟当CPU core实际运行时间。单进程allocator微实验与真实引擎区别见 [公共12](../../shared/docs/12_MEMORY_AND_CAPTURE.md)。

本章测量流程可复用于TP/DP/PP/CP/SP/EP、KV、量化、NIXL PD和投机章节；一次改变一类配置。每轮保留完整命令/profile/版本/模型数据hash、拓扑、原始JSONL、summary和trace，API Key不进报告。实机分数与硬件计数器仍待你的H800执行。
