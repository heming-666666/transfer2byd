# 12 · 能力bench、格式约束与tools

## 模型能力

独立环境/数据/版本与命令见 [shared06](../../shared/docs/06_QUALITY_DATASETS.md)，可独立阅读。本框架只用自己的client.json：

```bash
../shared/environments/evalscope1141/.venv/bin/python3 ../shared/scripts/evalscope_run.py \
  --client-config config/client.json --dataset-config ../shared/fixtures/datasets.json \
  --tasks gsm8k ifeval --limit 10 --max-tokens 4096 \
  --output ../shared/results/vllm_quality_smoke
```

正式limit0、新目录。GSM8K/MATH500数学、MMLU-Pro生成选择题、IFEval指令、CEval中文；classicMMLU/HellaSwag需私有prompt logprobs探针+Harness likelihood入口，不把chat生成分数当原协议。HumanEval/MBPP先生成再隔离VM/sandbox执行；不在root主机无隔离运行代码。

每个量化、top-k、spec/backend对照固定模型/数据commit、fewshot、模板、精度、思考/采样、max_tokens/maxlen、评分器版本、失败/截断。3条原创quality_smoke只验证流程，不命名公开榜单分数。R1预算不足只有reasoning无最终答案必须记失败/截断。

## JSON/正则/语法

先用 `8g_bf16/4g_bf16` Qwen3-8B，structured outputs backend为xgrammar：

```bash
python3 scripts/structured_output.py --mode prompt
python3 scripts/structured_output.py --mode json_object
python3 scripts/structured_output.py --mode json_schema
python3 ../shared/scripts/constraints.py --framework vllm --client-config config/client.json \
  --mode regex --output ../shared/results/vllm_regex.json
python3 ../shared/scripts/constraints.py --framework vllm --client-config config/client.json \
  --mode grammar --output ../shared/results/vllm_grammar.json
```

vLLM扩展为 `structured_outputs={'regex':...}` / `{'grammar':...}`；SDK通过extra_body，HTTP直接为顶层structured_outputs。SGLang的regex/ebnf字段不能照抄。JSON Schema固定answer字符串/topic枚举、required、additionalProperties=false，应用端再次验证。

比较格式成功率、语义正确率、grammar首编译/后续缓存成本和latency。精确fullmatch保留原始空白，不strip掩盖违规。合法JSON不代表事实正确，截断/不支持Schema关键词都需单独报告。不要给IFEval/原榜单额外施加改变任务的约束而仍称官方协议。

## 工具调用

Qwen3-8B可用独立tool实验：启动时 `--profile 8g_bf16 --tools`（4卡换4g），本包对应Hermes tool parser；然后 `python3 scripts/tool_demo.py`。工具示例仅本地UTC时间，参数先校验白名单，再执行并用对应tool_call_id回传，最终再请求assistant答案。模型不直接执行函数。

R1蒸馏未配置原生tools；较新latest配置有自己的parser，但需要其独立硬件/模型验收。未知工具、无效参数不执行，不从普通文本JSON猜一个真实工具调用。
