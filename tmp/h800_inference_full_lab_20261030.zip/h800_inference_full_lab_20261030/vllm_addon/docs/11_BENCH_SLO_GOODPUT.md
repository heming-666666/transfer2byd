# 11 · 官方性能、SLO与goodput

真实启动并验收目标profile后，再调用benchmark；--profile只是记录声明，不自动起服务。工具会自动使用该profile的模型tokenizer，不能错拿另一个模型计算输入长度。

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/benchmark.py \
  --profile "${CARDS}g_baseline" --name steady --input-len 1024 --output-len 256 \
  --requests 128 --rate 4 --max-concurrency 32
```

实际 `vllm bench serve --backend openai-chat`，JSON指标和manifest在data/results/benchmarks。内置示例goodput阈值TTFT2000ms/TPOT100ms，**不包含通用wrapper的E2E阈值**；需要更多SLO先查本版bench --help并修改明确参数。

统一联合SLO工具（标准库）：

```bash
python3 ../shared/scripts/slo_bench.py --client-config config/client.json \
  --slo ../shared/fixtures/slo.example.json --mode open --rate 4 --arrival poisson \
  --requests 128 --concurrency 32 --max-tokens 256 \
  --output "../shared/results/vllm_${CARDS}g_slo_rate4"
```

4卡先确认当前engine为4g，再改结果名。闭环对照改 `--mode closed --concurrency 16`。输出目录不能存在，重跑换名字。测短聊天256/128、长prefill4096/128、长decode256/1024、共享/不共享prefix各组，速率1/2/4/8/16和并发1/4/16/32分开扫描。

request goodput=同时成功并满足所有TTFT/TPOT/E2E SLO请求数/完整窗口；失败和客户端drop计入分母。delta近似TTFT、usage平均TPOT不是严格token ITL；缺usage不伪造值。窗口包含drain，预热单独记录。

联合95%与两项各自p95不同。容量选择满足目标联合达标率与失败门槛的最高offered rate，同时报告每卡goodput、实际输入输出、冷/热cache、网络位置、GPU/CPU和功耗。详见 [共享SLO定义](../../shared/docs/07_SLO_METHOD.md)。性能随机token不测模型能力，能力见12；正式成绩关Profiler。
