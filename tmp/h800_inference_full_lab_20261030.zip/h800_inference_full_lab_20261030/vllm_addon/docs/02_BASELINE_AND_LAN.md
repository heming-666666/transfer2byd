# 02 · 4/8卡服务、API Key、内网与会话

配置：

```bash
python3 scripts/configure.py --lan-ip 10.0.0.12 --model-root ../shared/models
python3 scripts/run.py list
```

替换真实内网IP。权重 `lab` 为DeepSeek-R1-Distill-Qwen-32B，放 `../shared/models/DeepSeek-R1-Distill-Qwen-32B/`。完整config/tokenizer/索引/shard均保留，先 `check_model.py --model lab`。允许下载时：

```bash
TASK_MODEL_REV=REPLACE_WITH_REAL_40_HEX_COMMIT
./environments/vllm0320/.venv/bin/python3 scripts/download_model.py --model lab --revision "$TASK_MODEL_REV"
python3 scripts/check_model.py --model lab
```

Key在config/secrets.json生成并保留，client.json只含public Key；私有engine Key不发给客户端。端口：public8000（0.0.0.0），engine8100/P8110/D8210/proxy8310（127.0.0.1）。SGLang端口/Key不同。

终端A：

```bash
CARDS=8
python3 scripts/run.py engine --profile "${CARDS}g_baseline" --dry-run
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_baseline"
```

终端B：

```bash
python3 scripts/wait_ready.py
./environments/vllm0320/.venv/bin/python3 scripts/run.py gateway --mode integrated
```

终端C：

```bash
python3 scripts/smoke_test.py --with-generation
python3 scripts/chat.py --message '用三句话解释 KV Cache。'
python3 scripts/chat.py
```

4卡改CARDS4并停旧引擎后重起。之后切换实验只 `run.py stop engine`，保持integrated网关，再启动单个新profile。切换PD或回切时stop all再按对应章节起。

另一台内网机器按同目录结构复制scripts/chat.py、client_lib.py、common.py、smoke_test.py和config/client.json，Python标准库即可；无需GPU/权重/推理venv。云安全组/ACL/路由要允许客户端→8000。客户端运行同样smoke/chat；会话保存在**客户端本机** `data/conversations/<id>/conversation.json`和turns.jsonl；`--resume`指定此conversation.json恢复。

必须验收缺失/错误Key401、正确models别名、非流式最终正文、流式[DONE]、第二轮真实历史、另一台机器调用。R1思考消耗输出预算，空content或length截断不能称功能正常。`/health`只说明网关存活，不说明模型ready。

对话是UTF-8 JSON messages，服务端套权重自带chat template；不手工拼特殊token再发messages。reasoning与content分开保存，下一轮默认只放最终assistant正文。tools调用ID单独保留。路径与文件说明可在本目录config模板、scripts/common.py查到。
