# 06 · Attention backend与CUDA Graph

Qwen3-8B同模型：8/4g `attn_flash_attn`、`attn_triton_attn`、`attn_flashinfer`，对应 `FLASH_ATTN/TRITON_ATTN/FLASHINFER`（vLLM枚举，不是SGLang小写fa3）。FLASH_ATTN内部实际FA版本由硬件/依赖选择，需日志与kernel确认。

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_attn_flash_attn"
```

保持KV dtype/maxlen、输入输出与并发固定，先smoke再bench。GQA和MLA专用backend不能互相保证支持，head dim/quant/硬件也有限制。缺kernel应补离线资产或记录不支持，不静默换backend再将结果记原名。

8/4g `graphs_off/on` 用同Qwen3-8B；off有 `--enforce-eager`，on不加此flag，由0.32默认编译/graph策略决定实际捕获模式。要调FULL/PIECEWISE/size bucket，先核对 `compilation-config` 的0.32字段，另建明确配置；不要把SGLang的graph参数用于vLLM。

比较启动wall、JIT、capture/instantiate、graph额外显存、每步CPU launch/replay、稳态goodput。graph on不能仅由flag缺失断言，要有启动日志/trace；部分batch/形状会fallback。

精细SM/kernel/CPU/graph准备实验见10和shared08。用Nsight node粒度看图内kernel次数；graph粒度只显示整体graph活动，不能声称没有kernel。性能正式轮关Profiler。
