# 03 · TP、DP、PP、PCP、DCP与SP

| 实验 | 8卡 | 4卡 |
|---|---|---|
| baseline/TP | `8g_tp`：TP8 | `4g_tp`：TP4 |
| DP | `8g_dp`：TP2×DP4 | `4g_dp`：TP2×DP2 |
| 纯DP小模型 | `8g_replicas`：TP1×DP8 | `4g_replicas`：TP1×DP4 |
| PP | `8g_pp`：TP4×PP2 | `4g_pp`：TP2×PP2 |
| PrefillCP | `8g_pcp`：TP4×PCP2 | `4g_pcp`：TP2×PCP2 |
| DecodeCP | `8g_dcp`：TP8内DCP2 | `4g_dcp`：TP4内DCP2 |

vLLM0.32总GPU=`TP×PP×PCP×DP`。DCP复用现有rank，不再乘；PCP1时TP可被DCP整除，PCP>1时DCP∈{1,PCP,TP×PCP}。本包validator执行这些约束；与SGLang CP/AttentionDP的公式不同。

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_pp"
```

按02单配置切换，另测dp/pcp/dcp。baseline、tp、dp、pp为同DeepSeek32B；pcp/dcp为DeepSeek-V2-Lite-Chat MLA；replicas为Qwen3-8B。跨模型吞吐不能直接当同模型并行优化，PCP对照要复制同MLA配置pcp1并相应调整GPU/TP，记录改变了什么。

输入256/2048/4096，输出128/1024，并发1/4/16；长CP先确认maxlen/KV内存，再升32K并测8K/16K输入。看TTFT/TPOT、GPU权重/KV、stage bubble、collective、尾等待和goodput，不只总tokens/s。

SP：此vLLM版本没有可泛用的 `--sp-size`；旧编译SP pass已变化，不杜撰flag。本包使用公共等价性实验：

```bash
CARDS=8
./environments/vllm0320/.venv/bin/torchrun --standalone --nproc_per_node="$CARDS" \
  ../shared/scripts/sp_microbench.py --tokens 8192 --hidden 2048 \
  --output "../shared/results/vllm_sp_micro_${CARDS}g.json"
```

比较AllReduce+LN与ReduceScatter+LN+AllGather数值/通信；它是数学微基准，不声称vLLM服务启用了该SP。通过条件：数值allclose、框架配置真实加载与回归、无unsupported组合伪装PASS。
