# 07 · 权重量化与KV量化

8/4g `bf16`、`weight_fp8`、`weight_awq`：同Qwen3-8B架构，在线FP8与独立官方AWQ权重。记录加载峰值/稳态显存、量化时间、actual kernel、latency/goodput及质量；AWQ checkpoint改变不等于单改dtype。`awq_marlin`是Hopper W4A16路径，不等价Blackwell原生FP4。

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_weight_fp8"
```

KV：`8g/4g_kv_fp8_uncalibrated`只设置 `--kv-cache-dtype fp8_e4m3`，标记质量变化；没有正确校准scale可能为1.0。**vLLM0.32固定源码已不提供旧 `--calculate-kv-scales` CLI，本包不使用。**

正式校准按照固定版本 [quantized_kvcache.md](https://github.com/vllm-project/vllm/blob/v0.32.0/docs/features/quantization/quantized_kvcache.md) 的llm-compressor方案，在单独工具venv、固定校准集和recipe下生成新checkpoint，保存到 `shared/models/<model>-kvfp8-<calib>/`，另加models条目与profile。不同架构的Attention模块target名不同，不能照抄LlamaAttention到Qwen3后就算已校准；先核验匹配层与导出的scale。

SGLang的quantization-param-path JSON不通用给vLLM；vLLM校准checkpoint也不自动适配SGLang所有格式。per-head scale支持与backend依官方文档核对。

实验分固定KV token容量与固定显存预算两组，避免系统把省的字节用于更大池而误解显存没有下降。GQA/MLA/V4KV布局不同，公式不能混用。长上下文、多个并发、数学/指令质量集均需回归；短问答通过不保证KV量化无退化。质量预算先定义再看结果，失败/截断不删除。
