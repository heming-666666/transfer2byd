# 09 · vLLM投机解码与新方法

| 方法 | profile（8g/4g均有） | 关键配置 |
|---|---|---|
| 无投机 | `bf16`（Qwen3-8B） | 对照 |
| ngram | `ngram` | method=ngram，tokens5，lookup3–5 |
| EAGLE3 | `eagle3` | Qwen3-8B+AngelSlim/Qwen3-8B_eagle3，tokens4 |
| DFlash基线 | `dflash_base` | Qwen3-4B |
| DFlash | `dflash` | Qwen3-4B+z-lab/Qwen3-4B-DFlash-b16，tokens15 |

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_ngram"
```

配对模型均完整下载并固定revision；不能拿8B draft验证R1-32B。NGRAM无需额外权重，重复代码/文本可能更有收益；不重复生成与高并发也要测。EAGLE3/DFLASH需核对draft TP与backend支持，失败时如实记录后在独立更小TP布局探索。

vLLM用 `--speculative-config` JSON；SGLang的speculative-algorithm CLI不能通用。新方法源码在v0.32 speculative.py；ngram_gpu、DSpark等可另建实验，先固定模型实现与支持backend。

MTP只用于有匹配多token头的模型：如原始V4在其支持配方里可研究 `{"method":"mtp","num_speculative_tokens":3}`。V4.1模型在固定源码中拒绝通用method=mtp，需走DSpark；不能为通过启动强行把model_type改成旧DeepSeek。DSpark目标/头/词表/shape依具体模型，不提供一个泛用draft名字保证所有新模型运行。

指标：draft提出/接受数、平均接受长度（是否含bonus明确）、draft/verify耗时、target调用数、显存、无Profiler速度比、联合goodput。来自 `/metrics`的名称与定义按本机版本保存原文，不把缺失当0。

temperature0先比较相同数据的输出/任务正确率，temperature>0核对拒绝采样/分布等价条件。相同seed不保证并行浮点路径逐字一致；更快或接受率高也不代表质量正确。不要用dummy模型/模拟接受率做正式结果。DFlash/DSpark新路径与PP、PD、graph等组合逐项查支持，不能一口气全开。
