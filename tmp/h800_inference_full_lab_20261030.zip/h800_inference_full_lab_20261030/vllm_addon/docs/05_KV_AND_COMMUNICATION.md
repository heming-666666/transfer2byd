# 05 · 通信、NVLink、KV块与分配

两个框架共同的原理/工具独立放shared：

- [NCCL/NVLink/P2P](../../shared/docs/01_COMMUNICATION.md)
- [KV块、refcount、COW与真实指标](../../shared/docs/02_KV_ALLOCATION.md)
- [KV形状传输、真实PD分解](../../shared/docs/03_KV_TRANSFER.md)

vLLM本章profile：8/4g `kv_pool_low/high`（每rank显式KV2/4GiB）、`radix/no_radix`（prefix caching开/关；名称是跨框架标签，vLLM并非Radix树实现）。

```bash
CARDS=8
./environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_kv_pool_low"
```

另测high、共享/不共享前缀。显式 `--kv-cache-memory-bytes`覆盖自动由gpu-memory-utilization推导KV预算，记录日志实际容量；不把这一数值误当整个GPU进程内存上限。block size如要调16/32，先查当前attention backend的支持值，并在新profile/launcher增加一个明确参数，不假定所有kernel通用。

采原始metrics：

```bash
python3 ../shared/scripts/collect_metrics.py --framework vllm --target engine \
  --samples 10 --interval 1 --output "../shared/results/vllm_metrics_${CARDS}g"
```

观察prefix hit、cache usage、waiting/running、preemption/recompute、失败。请求结束后活跃引用应下降，但prefix cache与CUDA allocator可保留，nvidia-smi不归零不等于泄漏。冷缓存和热缓存性能分开，报告warmup。

合成KV send/recv仅NCCL，真实vLLM PD是NIXL connector；探针uint8仅字节缩小，没有FP8scale/量化正确性。NVLink活跃必须有拓扑/计数器证据，不从设备型号推断。
