# H800 推理部署与实验包：SGLang 主线、vLLM 独立补充

版本核对日期：2026-10-30；R2修订：2026-10-31。默认 **8 张 H800**，同时提供 **4 张 H800** 配置。面向 Linux x86_64、root 云主机、内网客户端、外网受限环境。主线不用 Docker。

目标是先让同一内网的其他机器通过 API Key 调用多轮聊天，再逐项理解并行、KV、通信、调度、量化、约束解码、投机解码、性能与质量评测。

## 阅读顺序

| 顺序 | 入口 | 用途 |
|---|---|---|
| 1 | [01_START_8GPU_4GPU.md](01_START_8GPU_4GPU.md) | 两种卡数的主线、验收与资源划分 |
| 2 | [02_DIRECTORY_LAYOUT.md](02_DIRECTORY_LAYOUT.md) | 文件存放、迁移、备份、结果命名 |
| 3 | [sglang_lab/00_README.md](sglang_lab/00_README.md) | SGLang 完整有序指南；从 01 开始 |
| 4 | [vllm_addon/00_README.md](vllm_addon/00_README.md) | vLLM 独立入口，含基础启动与全部补充实验 |
| 5 | [shared/00_README.md](shared/00_README.md) | 两框架共用的通信、KV、评测、Profiler 工具 |
| 6 | [03_EXPERIMENT_MATRIX.md](03_EXPERIMENT_MATRIX.md) | 所有 4/8 卡 profile、状态及结果字段 |
| 7 | [04_FIRST_COMPLETE_RUN.md](04_FIRST_COMPLETE_RUN.md) | 从服务验收到SLO/能耗/归因的一轮完整路线 |
| 8 | [89_REVISION_NOTES.md](89_REVISION_NOTES.md) | R2新增脚本、测量语义与修正 |
| 9 | [98_AGENT_RUNBOOK.md](98_AGENT_RUNBOOK.md) | 可交给执行代理/同事的逐步执行与验收规则 |
| 10 | [99_SOURCES_AND_VERSION_NOTES.md](99_SOURCES_AND_VERSION_NOTES.md) | 固定源码、版本差异、适配边界 |

## 首先采用的方案

- **SGLang 0.5.22 + DeepSeek-R1-Distill-Qwen-32B**：8 卡 TP8 / 4 卡 TP4，8K 上下文、关闭 CUDA Graph，先打通真实服务。R1 是蒸馏推理模型，输出预算需覆盖思考和最终正文。
- 用 **Qwen3-8B** 做 attention、graph、SP、约束输出等小模型对照；用 **Qwen3-30B-A3B-FP8** 做 MoE/EP/CP。它们是机制实验模型，不冒充 DeepSeek。
- 比较新的 DeepSeek 分支：原始 **DeepSeek-V4-Flash** 的官方 H100 TP8/Marlin 配方作为 H800 条件迁移实验。**V4.1-Flash-1017 不能在本包中宣称 4/8×H800 + stock SGLang 已验证支持**，见 SGLang 28；默认有启动拦截。
- vLLM 固定 **0.32.0**，独立 Python 环境、独立端口、独立配置；可以共用只读权重。

“正常可用”由一组可重复验收来判定：环境与校验清单通过 → CUDA/NCCL 真实探针通过 → 引擎就绪 → 错误/缺失 Key 返回 401 → 正确 Key 得到流式和非流式正文 → 客户端第二轮带历史得到回复 → 另一内网机器通过同样检查。

## 交付边界与验收状态

ZIP 包含指南、源码、配置模板、原理模拟和 CPU 测试；**不包含数百 GB 权重、CUDA 驱动、离线 wheel、工具商业安装包或预编译 Perfetto UI**。按 02/模型指南备齐后才能构建环境。所有可部署用户态文件都放在项目子目录；已有的宿主机内核、驱动、glibc 和网络条件仍必须满足。Python venv 不会替你安装 NVIDIA 驱动。

本交付环境没有用户的 H800，不能据此承诺任意云镜像、任意新模型、任意实验组合必然一次成功。已运行的 CPU 检查与尚未运行的 GPU/PD/内网/评分分别记在 [90_VALIDATION_REPORT.md](90_VALIDATION_REPORT.md)。遇到缺文件、版本不符或不支持配置时，脚本报错停止，避免静默换版本或假造成功。

建议先完成 SGLang 01–07，再跑 8 卡主线实验；4 卡作为资源对照。不要一次同时打开 EP、CP、量化、PD 和投机后排查。

R2补充了统一功能验收、同机时间标记、显存/功率采样与覆盖率约束的能耗计算、allocator微实验、两框架捕获期profiler入口，以及SGLang PD分轮profiling修正。按各框架新完整执行章操作；不会用CPU测试或人工张量实验充当H800实测。
