# 01 · 默认 8 卡，4 卡作为对应实验

以下路径是统一示例，可整体换到容量足够的数据盘：`/data/llm/h800_inference_full_lab_20261030`。不要放到根分区剩余空间很小的位置。解压后保留整个根目录。

## 卡数与资源配置

| 实验 | 8 卡 | 4 卡 | 解释 |
|---|---|---|---|
| 主线 TP | TP8，GPU 0–7 | TP4，GPU 0–3 | 同一 DeepSeek 32B 检查功能 |
| 整模型 DP | TP2×DP4 | TP2×DP2 | 各副本有独立 KV 与完整权重分片 |
| 小模型纯 DP | TP1×DP8 | TP1×DP4 | Qwen3-8B，观察吞吐与复制内存 |
| PP | TP4×PP2 | TP2×PP2 | 仍为 8/4 个 rank；观察 pipeline bubble |
| SGLang CP | TP8 内 CP2 | TP4 内 CP2 | CP 在 TP 组内，不再乘卡数 |
| vLLM PCP | TP4×PCP2 | TP2×PCP2 | PCP 扩展 world size；与 SGLang 公式不同 |
| DCP | TP 组内 DCP2 | TP 组内 DCP2 | 不额外乘卡数；须满足版本整除关系 |
| EP | TP8 内 EP8 | TP4 内 EP4 | SGLang；MoE 专家分布维度 |
| PD | P4 + D4 | P2 + D2 | 两个引擎分别加载权重，不共用同一份 GPU 权重 |
| SP / 通信 | world=8 | world=4 | SGLang Qwen3 原生 SP + 两框架公共微基准 |

GPU 编号是进程可见的物理序号，不是云平台账单卡号。若不是连续空闲卡，先根据 `nvidia-smi topo -m` 选组，再同时修改 profile 的 `gpus`，不能只改 `CUDA_VISIBLE_DEVICES` 后让嵌套启动器重写。

## 第一次执行

按 [SGLang 00](sglang_lab/00_README.md) 顺序执行 01–07；环境缺离线文件时先完成 02 的准备阶段。主线命令结构如下：

```bash
LAB_ROOT=/data/llm/h800_inference_full_lab_20261030
cd "$LAB_ROOT/sglang_lab"
CARDS=8
python3 scripts/configure.py --lan-ip 10.0.0.12
bash scripts/bootstrap_offline.sh
./environments/sglang0522/.venv/bin/python3 scripts/runtime_check.py --cards "$CARDS"
```

`10.0.0.12` 必须替换为服务器真实可达内网地址。首次模型准备参见 04；随后在终端 A 启动：

```bash
cd "$LAB_ROOT/sglang_lab"
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_baseline"
```

终端 B：

```bash
cd "$LAB_ROOT/sglang_lab"
./environments/sglang0522/.venv/bin/python3 scripts/wait_ready.py
./environments/sglang0522/.venv/bin/python3 scripts/run.py gateway
```

终端 C：

```bash
cd "$LAB_ROOT/sglang_lab"
python3 scripts/smoke_test.py --with-generation
python3 scripts/chat.py --message '用三句话解释 KV Cache。'
```

另一台机器按照 06 复制最小客户端，执行相同的 smoke/chat。只测 `/health` 不能通过验收。4 卡时停止原引擎，设 `CARDS=4`，再跑 `4g_baseline`；不能在已有 8 卡服务上重叠启动。

## 公平比较 8 卡和 4 卡

保持模型 commit、上下文、精度、采样、实际输入/输出 token、SLO 不变。分别进行固定到达率（同一业务流量）和容量扫描（各自最大达标流量）两种比较。记录总吞吐、goodput、每卡 goodput、p95 延迟、功耗（若可读）。4 卡实验在一台 8 卡主机上只暴露 0–3，剩余卡不参与；同时记录宿主机其他任务，防止 CPU、内存带宽及 I/O 干扰。

R1 32B 的 TP8 不一定比 TP4 快；小模型通信可能主导。结论必须来自实际曲线，不能只按卡数线性外推。
