# 03 · 4/8 卡实验索引

默认8卡。以下配置经过CPU维度与命令生成检查，GPU状态均为NOT_RUN。cards是一个引擎实例所选卡数（TP/PP等会启动多个worker）；8g PD的一条P/D各4卡，二者合计8卡。

机器可读：[experiments.csv](docs/experiments.csv)、[experiments.json](docs/experiments.json)。每项先dry-run，再真实验收。

## R2工具实验（复用已有4/8卡profile）

| 实验 | 入口 | 4卡/8卡设置 | 实机状态 |
|---|---|---|---|
| public API/两轮记忆 | 总04、accept_service.py | 连接实际4g/8g服务；本机与远端分别做 | NOT_RUN |
| 显存/功率/能耗与SLO | 公共11、SGLang31、vLLM15 | 显式GPU IDs；同机采样/发压 | NOT_RUN |
| SGLang启动Graph捕获 | 公共12、SGLang31 | 4g/8g_graphs_on + capture-profiler | NOT_RUN |
| vLLM捕获/memory事件 | 公共12、vLLM15 | 4g/8g_graphs_on + capture/memory-profiler | NOT_RUN |
| allocator生命周期 | 公共12、memory_probe.py | 先空闲单GPU微实验，再看实际TP4/8各rank | NOT_RUN |

以上是工具/启动选项，不额外新增profile，不把单GPU人工buffer实验记作4/8卡真实模型成绩。

## sglang_lab

| Profile | 实例卡数 | TP/DP/PP | CP/PCP/DCP | EP | 模型 | 条件 |
|---|---:|---|---|---|---|---|
| `8g_baseline` | 8 | 8/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_tp` | 8 | 8/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_dp` | 8 | 2/4/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_replicas` | 8 | 1/8/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_pp` | 8 | 4/1/2 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_attention_dp` | 8 | 8/1/1 | 1/1/1 | 8 | moe | target CUDA acceptance required |
| `8g_cp` | 8 | 8/1/1 | 2/1/1 | 8 | moe | target CUDA acceptance required |
| `8g_dcp` | 8 | 8/1/1 | 1/1/2 | 1 | mla | target CUDA acceptance required |
| `8g_sp_off` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_sp_on` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_ep_off` | 8 | 8/1/1 | 1/1/1 | 1 | moe | target CUDA acceptance required |
| `8g_ep_on` | 8 | 8/1/1 | 1/1/1 | 8 | moe | target CUDA acceptance required |
| `8g_ep_deepep` | 8 | 8/1/1 | 1/1/1 | 8 | moe | target CUDA acceptance required |
| `8g_bf16` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_weight_fp8` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_weight_awq` | 8 | 8/1/1 | 1/1/1 | 1 | awq | target CUDA acceptance required |
| `8g_kv_fp8` | 8 | 8/1/1 | 1/1/1 | 1 | dense | needs KV scale file |
| `8g_kv_fp8_uncalibrated` | 8 | 8/1/1 | 1/1/1 | 1 | dense | experimental |
| `8g_experts_top8` | 8 | 8/1/1 | 1/1/1 | 8 | moe | target CUDA acceptance required |
| `8g_experts_top4` | 8 | 8/1/1 | 1/1/1 | 8 | moe | target CUDA acceptance required |
| `8g_attn_triton` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_attn_fa3` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_attn_flashinfer` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_graphs_off` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_graphs_on` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_no_radix` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_radix` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_overlap_off` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_ngram` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_eagle3` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_dflash_base` | 8 | 8/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `8g_dflash` | 8 | 8/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `8g_profile` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_pd_mooncake_prefill` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_pd_mooncake_decode` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_pd_nixl_prefill` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_pd_nixl_decode` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_latest` | 8 | 8/1/1 | 1/1/1 | 1 | latest | 固定版本 Cookbook 未提供 H800/H100 的 V4.1 保证配方；须先核验源码/硬件，不能直接作为主线启动 |
| `8g_modern` | 8 | 8/1/1 | 1/1/1 | 1 | modern | experimental |
| `4g_baseline` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_tp` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_dp` | 4 | 2/2/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_replicas` | 4 | 1/4/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_pp` | 4 | 2/1/2 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_attention_dp` | 4 | 4/1/1 | 1/1/1 | 4 | moe | target CUDA acceptance required |
| `4g_cp` | 4 | 4/1/1 | 2/1/1 | 4 | moe | target CUDA acceptance required |
| `4g_dcp` | 4 | 4/1/1 | 1/1/2 | 1 | mla | target CUDA acceptance required |
| `4g_sp_off` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_sp_on` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_ep_off` | 4 | 4/1/1 | 1/1/1 | 1 | moe | target CUDA acceptance required |
| `4g_ep_on` | 4 | 4/1/1 | 1/1/1 | 4 | moe | target CUDA acceptance required |
| `4g_ep_deepep` | 4 | 4/1/1 | 1/1/1 | 4 | moe | target CUDA acceptance required |
| `4g_bf16` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_weight_fp8` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_weight_awq` | 4 | 4/1/1 | 1/1/1 | 1 | awq | target CUDA acceptance required |
| `4g_kv_fp8` | 4 | 4/1/1 | 1/1/1 | 1 | dense | needs KV scale file |
| `4g_kv_fp8_uncalibrated` | 4 | 4/1/1 | 1/1/1 | 1 | dense | experimental |
| `4g_experts_top8` | 4 | 4/1/1 | 1/1/1 | 4 | moe | target CUDA acceptance required |
| `4g_experts_top4` | 4 | 4/1/1 | 1/1/1 | 4 | moe | target CUDA acceptance required |
| `4g_attn_triton` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_attn_fa3` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_attn_flashinfer` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_graphs_off` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_graphs_on` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_no_radix` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_radix` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_overlap_off` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_ngram` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_eagle3` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_dflash_base` | 4 | 4/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `4g_dflash` | 4 | 4/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `4g_profile` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_pd_mooncake_prefill` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_pd_mooncake_decode` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_pd_nixl_prefill` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_pd_nixl_decode` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_latest` | 4 | 4/1/1 | 1/1/1 | 1 | latest | 固定版本 Cookbook 未提供 H800/H100 的 V4.1 保证配方；须先核验源码/硬件，不能直接作为主线启动 |
| `4g_modern` | 4 | 4/1/1 | 1/1/1 | 1 | modern | experimental |
| `8g_kv_pool_32768` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_kv_pool_65536` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_chunk_1024` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_chunk_4096` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_lpm` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_kv_pool_32768` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_kv_pool_65536` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_chunk_1024` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_chunk_4096` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_lpm` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_modern_mtp` | 8 | 8/1/1 | 1/1/1 | 1 | modern | experimental |
| `8g_dspark` | 8 | 8/1/1 | 1/1/1 | 1 | dspark_target | experimental |
| `4g_modern_mtp` | 4 | 4/1/1 | 1/1/1 | 1 | modern | experimental |
| `4g_dspark` | 4 | 4/1/1 | 1/1/1 | 1 | dspark_target | experimental |
## vllm_addon

| Profile | 实例卡数 | TP/DP/PP | CP/PCP/DCP | EP | 模型 | 条件 |
|---|---:|---|---|---|---|---|
| `lab_tp2` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `lab_tp1_dp8` | 8 | 1/8/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `lab_tp2_dp4` | 8 | 2/4/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `lab_tp4_dp2` | 8 | 4/2/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `lab_tp8` | 8 | 8/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `latest_tp8` | 8 | 8/1/1 | 1/1/1 | 1 | latest | target CUDA acceptance required |
| `pd_p4` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `pd_d4` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `moe_tp8` | 8 | 8/1/1 | 1/1/1 | 1 | moe_lab | target CUDA acceptance required |
| `moe_dp8_ep` | 8 | 1/8/1 | 1/1/1 | enabled | moe_lab | target CUDA acceptance required |
| `8g_baseline` | 8 | 8/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_tp` | 8 | 8/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_dp` | 8 | 2/4/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_replicas` | 8 | 1/8/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_pp` | 8 | 4/1/2 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_pcp` | 8 | 4/1/1 | 1/2/1 | 1 | mla | target CUDA acceptance required |
| `8g_dcp` | 8 | 8/1/1 | 1/1/2 | 1 | mla | target CUDA acceptance required |
| `8g_ep_off` | 8 | 8/1/1 | 1/1/1 | 1 | moe | target CUDA acceptance required |
| `8g_ep_on` | 8 | 8/1/1 | 1/1/1 | enabled | moe | target CUDA acceptance required |
| `8g_bf16` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_radix` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_no_radix` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_graphs_off` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_graphs_on` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_profile` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_kv_pool_low` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_kv_pool_high` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_weight_fp8` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_weight_awq` | 8 | 8/1/1 | 1/1/1 | 1 | awq | target CUDA acceptance required |
| `8g_attn_flash_attn` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_attn_triton_attn` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_attn_flashinfer` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_ngram` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_eagle3` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_dflash_base` | 8 | 8/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `8g_dflash` | 8 | 8/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `8g_experts_top8` | 8 | 8/1/1 | 1/1/1 | enabled | moe | target CUDA acceptance required |
| `8g_experts_top4` | 8 | 8/1/1 | 1/1/1 | enabled | moe | target CUDA acceptance required |
| `8g_pd_prefill` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_pd_decode` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_baseline` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_tp` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_dp` | 4 | 2/2/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_replicas` | 4 | 1/4/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_pp` | 4 | 2/1/2 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_pcp` | 4 | 2/1/1 | 1/2/1 | 1 | mla | target CUDA acceptance required |
| `4g_dcp` | 4 | 4/1/1 | 1/1/2 | 1 | mla | target CUDA acceptance required |
| `4g_ep_off` | 4 | 4/1/1 | 1/1/1 | 1 | moe | target CUDA acceptance required |
| `4g_ep_on` | 4 | 4/1/1 | 1/1/1 | enabled | moe | target CUDA acceptance required |
| `4g_bf16` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_radix` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_no_radix` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_graphs_off` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_graphs_on` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_profile` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_kv_pool_low` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_kv_pool_high` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_weight_fp8` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_weight_awq` | 4 | 4/1/1 | 1/1/1 | 1 | awq | target CUDA acceptance required |
| `4g_attn_flash_attn` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_attn_triton_attn` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_attn_flashinfer` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_ngram` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_eagle3` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_dflash_base` | 4 | 4/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `4g_dflash` | 4 | 4/1/1 | 1/1/1 | 1 | dflash_target | target CUDA acceptance required |
| `4g_experts_top8` | 4 | 4/1/1 | 1/1/1 | enabled | moe | target CUDA acceptance required |
| `4g_experts_top4` | 4 | 4/1/1 | 1/1/1 | enabled | moe | target CUDA acceptance required |
| `4g_pd_prefill` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_pd_decode` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_kv_fp8_uncalibrated` | 8 | 8/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `4g_kv_fp8_uncalibrated` | 4 | 4/1/1 | 1/1/1 | 1 | dense | target CUDA acceptance required |
| `8g_pd_profile_prefill` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `8g_pd_profile_decode` | 4 | 4/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_pd_profile_prefill` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
| `4g_pd_profile_decode` | 2 | 2/1/1 | 1/1/1 | 1 | lab | target CUDA acceptance required |
