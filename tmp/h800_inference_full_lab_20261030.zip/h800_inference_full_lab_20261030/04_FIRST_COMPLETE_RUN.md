# 04 · 第一轮完整执行：先验收，再测容量，再归因

R2补充日期：2026-10-31。源码固定版本沿用2026-10-30核对记录。本章把已有章节串成一条可重复路线，不跳过原生环境、权重和GPU检查。

## 先完成必需条件

| 阶段 | SGLang | vLLM独立路线 | 通过标准 |
|---|---|---|---|
| 环境、权重、Key | 本框架01–04 | 本框架01–02 | 离线资产校验、runtime_check、权重分片完整 |
| GPU/通信 | 本框架01、公共01 | 本框架02、公共01 | 4/8 rank真实CUDA/NCCL测试；保存拓扑和日志 |
| 基础服务 | 本框架05–07 | 本框架02 | 引擎和公共网关就绪；两终端持续运行 |
| 本机与内网验收 | 下述acceptance | 下述acceptance | 两台机器各有独立的PASS证据 |
| 容量与能耗 | [SGLang31](sglang_lab/docs/31_COMPLETE_RUN.md) | [vLLM15](vllm_addon/docs/15_COMPLETE_RUN.md) | 无Profiler的正式SLO结果、采样覆盖率 |
| kernel/CPU/SM | SGLang26/30、公共08 | vLLM10、公共08 | 独立短窗口trace；不把profiling轮次作正式成绩 |

**初始模型仍是DeepSeek-R1-Distill-Qwen-32B**；跑通服务后，切到Qwen3-8B做可控机制实验。两者结果分别命名，不将小模型的吞吐当DeepSeek吞吐。4卡TP4和8卡TP8使用同一检查顺序。

## 统一功能验收

在总根目录执行，先选择实际运行的框架配置。SGLang：

```bash
python3 shared/scripts/accept_service.py --client-config sglang_lab/config/client.json \
  --max-tokens 4096 --timeout 600 --output shared/results/accept_sglang_server_trial01
```

vLLM：

```bash
python3 shared/scripts/accept_service.py --client-config vllm_addon/config/client.json \
  --max-tokens 4096 --timeout 600 --output shared/results/accept_vllm_server_trial01
```

输出目录必须不存在；再次运行改为trial02。脚本检查：无Key401、错Key401、模型别名、非流式最终正文、流式最终正文及`[DONE]`、第二轮携带三条历史并正确复述随机校验码。最终正文必须非空且`finish_reason=stop`；只输出reasoning或达到长度上限不能通过功能验收。生成失败先看token预算/模板/parser/模型状态，不能删断言假装通过。随机码记忆只是小规模功能检查，不能替代模型能力基准。

结果包含 `acceptance.json`、`conversation.json`；第二个文件保存客户端自己发出的user/assistant正文，不重放私有思考。报告不保存API Key。原有交互客户端仍负责长期会话ID和逐轮记录；本工具只保存这一轮验收。

另一内网机器按各框架客户端章节复制最小客户端，或复制整个包的指南/标准库脚本部分。复制**public client配置**，把base_url改为实际服务端内网IP，不能复制engine/admin密钥。再运行同一命令，输出目录改为 `accept_sglang_remote_trial01` / `accept_vllm_remote_trial01`。这一步的PASS证明那台客户端到网关可达；服务器上的PASS不能替代它。

## 三组结果分别回答什么

1. **功能验收**回答API和对话是否按协议工作。失败先修复，暂不调EP/CP/量化。
2. **无Profiler压测**回答固定模型/长度/并发/到达率下能否满足联合SLO。用率阶梯和至少三次重复求容量，再测另一卡数。固定prompt哈希、输出预算、模型revision、graph状态、prefix缓存冷暖状态。
3. **短窗口profiling**回答瓶颈在哪里。分别抓steady-state、startup graph capture；PD分轮抓P/D PyTorch Profiler。每张卡、每个rank、每种kernel保留原始trace或report。

CPU测试日志只证明CPU/HTTP测试，GPU微实验只证明其人工工作负载，源代码中的参数存在只证明该版本的接口。实际吞吐、SM数量、传输带宽、能力分数都应从本机原始结果取得。

## 推荐的两天练习顺序

第一轮：8卡基线服务与内网验收 → Qwen3 graph-off固定负载 → 开环率阶梯 → graph-on单变量对照 → 单轮Nsight/PyTorch归因。第二轮：4卡对应配置 → TP/DP/PP对照 → KV与prefix缓存 → PD → EP/量化/投机。每个实验先恢复其对应基线，再改变一组参数。新模型与多项优化组合放在单变量实验之后。

完成后按 [98_AGENT_RUNBOOK.md](98_AGENT_RUNBOOK.md) 的证据规则更新状态；本包没有预填H800实测成绩。
