# 02 · 目录、文件所有权与迁移

统一根目录建议 `/data/llm/h800_inference_full_lab_20261030`。表内路径均相对该根目录。

| 路径 | 放什么 | 迁移/备份规则 |
|---|---|---|
| `00_README.md`、`01_*.md`、`98_*.md` | 总入口、顺序与执行约束 | 与所有脚本一起保存 |
| `sglang_lab/docs/` | SGLang 编号指南 | 每个附加实验独立一章 |
| `vllm_addon/docs/` | vLLM 独立补充指南 | 不依赖读 SGLang 指南 |
| `shared/models/<checkpoint>/` | 完整模型快照、tokenizer、编码文件、下载 revision | 大文件单独迁移，两个框架只读共用 |
| `sglang_lab/config/` | 模型表、profile 表、设置模板 | `settings.json` 本机配置；`secrets.json/client.json/*.env` 私密，权限 600 |
| `vllm_addon/config/` | vLLM 独立配置与密钥 | 与 SGLang Key、端口分开 |
| `<framework>/environments/python/assets/` | portable CPython 原始归档与 SHA256 | 原始资产必须保存，用于重新搭建 |
| `<framework>/environments/<version>/wheelhouse/` | 目标 Linux/Python/CUDA 的全部 wheel | 不把 Windows wheel 混入；保留完整依赖闭包 |
| `<framework>/environments/<version>/.venv/` | 重新安装得到的项目内环境 | 移动目录后用 lock/wheelhouse 重建，不能保证拷贝 venv 后可执行 |
| `<framework>/environments/<version>/cache/` | HF、Torch、Triton、CUDA、FlashInfer、临时编译文件 | 不混用两个框架/不同 Torch 版本；先预热再断外网验证 |
| `<framework>/environments/toolkit/` | 可选用户态 CUDA toolkit/nvcc、本地系统库 | 只用安装器的 toolkit/解压选项，不装驱动 |
| `<framework>/data/logs/` | 引擎/网关运行日志 | 按实验名与时间戳区分；密钥不写日志 |
| `<framework>/data/runtime/` | 进程登记、实际启动计划 | 不当作可迁移服务状态；禁止手改 PID |
| `<framework>/data/conversations/<id>/` | 客户端完整会话与 turns.jsonl | 在**运行客户端的那台机器**产生；原始正文不等于网关审计 |
| `<framework>/data/results/` | 官方 benchmark、格式实验结果 | 单次运行独立目录，包含 manifest |
| `<framework>/data/reports/` | 硬件预检、验收表与故障记录 | 保留未通过项，不能用模板代替已执行证据 |
| `shared/datasets/<task>/` | 固定 revision 的评测数据与哈希清单 | 与 `nltk/` 一起迁移；运行阶段禁止临时下载 |
| `shared/environments/` | EvalScope、lm-eval、Nsight、Perfetto UI 的独立资产 | 与推理 venv 隔离；Nsight/UI 按文档另行准备 |
| `shared/results/`、`shared/traces/` | 公共测试与原始 trace | 按 `框架_卡数_实验_UTC时间` 命名；不同工具文件不覆盖 |
| `shared/results/<trial>/acceptance/` | 一轮功能验收与conversation.json | 本机/远端各自保存，不含Key |
| `shared/results/<trial>/resources/` | metadata.json与逐GPU samples.jsonl | 功率/显存/利用率及同机时钟，不覆盖缺测 |
| `shared/results/<trial>/slo/`、`energy.json` | 逐请求、汇总、覆盖率和能耗 | 与resources使用同机时钟；不同trial禁止混合 |
| `shared/environments/memory_probe/<venv-hash>/` | 显存微实验的Torch/CUDA/临时cache | 按Python执行路径隔离，避免两框架Torch缓存混用 |
| `tests/`、`references/upstream/` | CPU 检查及固定源码证据 | 只能证明相应检查，不能证明 GPU 实机性能 |

`config/settings.example.json` 的 `model_root=../shared/models` 相对**各框架项目根目录**解析，不相对当前 shell。配置支持显式绝对路径；若搬迁后绝对路径过期，重新 `configure.py --model-root ../shared/models`。

## 建议结果目录

`shared/results/sglang_8g_graphs_on_20261030T120000Z/` 下至少保存：`manifest.json`、`requests.jsonl`、`summary.json`、`metrics/*.prom`、`gpu.csv`、`traces/`、`notes.md`。manifest 写入模型与数据 commit、配置文件 SHA256、框架/Torch/CUDA/driver 版本、GPU UUID/拓扑、输入输出长度、SLO、随机种子、成功/失败数。Key 只保存在私密配置，不出现在 manifest。

脚本不会自动删除权重和会话，不会 `pkill python`、重装系统 Python 或改防火墙。日志/trace 很大时先归档到此根目录的 `archives/`，核对后再人工选择清理，不使用全局通配符清理命令。

## “文件齐全就能重建”的具体含义

重建依赖：Python 归档 + wheelhouse + lock + SHA manifest + 权重快照 + 所需本地 kernel/toolkit 资产 + 同等 ABI 的宿主机。`bootstrap_offline.sh` 校验资产后在子目录创建 venv，`pip --no-index` 安装，缺一项直接失败。宿主机驱动、GPU 虚拟化能力、RDMA/硬件计数器权限和内网 ACL 不是普通文件目录能替代的条件，预检会独立记录。
