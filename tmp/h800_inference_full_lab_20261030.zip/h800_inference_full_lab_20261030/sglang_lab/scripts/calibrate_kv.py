"""Qwen3 dense FP8 KV range calibration from real HF post-RoPE DynamicCache; no invented scales.
Writes SGLang's TP-rank/layer scalar JSON for separate TP4 and TP8. Not vLLM checkpoint format.
"""
import argparse,hashlib,json,os
from pathlib import Path
from common import ROOT,model_path,settings,native_environment,write_json
from validate_scales import validate_scale_file
def shard_scales(maxima,tp,fp8_max,margin):
    result={str(r):{} for r in range(tp)}
    for layer,heads in enumerate(maxima):
        nh=len(heads)
        if nh>=tp and nh%tp:raise ValueError('KV heads cannot be evenly sharded by TP')
        if tp>nh and tp%nh:raise ValueError('KV-head replication ratio is not integral')
        for rank in range(tp):
            subset=heads[rank*(nh//tp):(rank+1)*(nh//tp)] if nh>=tp else [heads[rank//(tp//nh)]]
            result[str(rank)][str(layer)]=max(subset)*margin/fp8_max
    return result
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--corpus',type=Path,required=True,help='JSONL each row has text; use representative calibration data, never evaluation test answers')
    p.add_argument('--samples',type=int,default=128);p.add_argument('--max-length',type=int,default=2048);p.add_argument('--tp-sizes',type=int,nargs='+',default=[4,8]);p.add_argument('--margin',type=float,default=1.1)
    p.add_argument('--output',type=Path,default=ROOT/'config/kv_scales');a=p.parse_args()
    if min(a.samples,a.max_length)<1 or a.margin<1:p.error('samples/length positive, margin>=1')
    c=settings();os.environ.update(native_environment(c));source=model_path('dense',c)
    texts=[json.loads(l)['text'] for l in a.corpus.read_text().splitlines() if l.strip()]
    if len(texts)<a.samples:p.error('corpus样本少于--samples；smoke需显式samples3，正式至少128–512代表样本')
    if a.output.exists():p.error('输出目录已存在，使用新目录避免覆盖校准证据')
    import torch
    from transformers import AutoModelForCausalLM,AutoTokenizer
    model=AutoModelForCausalLM.from_pretrained(source,local_files_only=True,dtype=torch.bfloat16)
    if model.config.model_type!='qwen3':p.error('本校准器仅dense Qwen3；不套MoE/MLA/V4')
    model=model.to('cuda:0').eval();tokenizer=AutoTokenizer.from_pretrained(source,local_files_only=True)
    n=model.config.num_hidden_layers;nh=model.config.num_key_value_heads;maxima=[[0.0]*nh for _ in range(n)];lengths=[]
    with torch.inference_mode():
        for i,text in enumerate(texts[:a.samples]):
            rendered=tokenizer.apply_chat_template([{'role':'user','content':text}],tokenize=False,add_generation_prompt=True,enable_thinking=False)
            ids=tokenizer(rendered,return_tensors='pt',truncation=True,max_length=a.max_length,add_special_tokens=False).to('cuda:0')
            output=model.model(**ids,use_cache=True,return_dict=True);cache=output.past_key_values
            if not hasattr(cache,'layers') or len(cache.layers)!=n:raise RuntimeError('Unexpected Transformers cache API/shape')
            for layer,entry in enumerate(cache.layers):
                k,v=entry.keys,entry.values
                if k.ndim!=4 or k.shape[1]!=nh or v.shape[1]!=nh:raise RuntimeError('Unexpected full-model KV head layout')
                if not torch.isfinite(k).all() or not torch.isfinite(v).all():raise RuntimeError('Non-finite calibration KV')
                ranges=torch.maximum(k.abs().amax(dim=(0,2,3)).float(),v.abs().amax(dim=(0,2,3)).float()).cpu().tolist()
                maxima[layer]=[max(x,y) for x,y in zip(maxima[layer],ranges)]
            lengths.append(int(ids['input_ids'].shape[-1]));del output,cache,ids
            print('calibrated',i+1,'/',a.samples,flush=True)
    if any(x<=0 for layer in maxima for x in layer):raise RuntimeError('Zero/unobserved calibration head range')
    a.output.mkdir(parents=True);fp8_max=float(torch.finfo(torch.float8_e4m3fn).max)
    for tp in a.tp_sizes:
        scales=dict(model_type=model.config.model_type,kv_cache=dict(dtype='float8_e4m3fn',scaling_factor=shard_scales(maxima,tp,fp8_max,a.margin)))
        f=a.output/f'tp{tp}.json';write_json(f,scales);validate_scale_file(f,model.config.to_dict(),tp)
    write_json(a.output/'manifest.json',dict(model=str(source),corpus=str(a.corpus.resolve()),corpus_sha256=hashlib.sha256(a.corpus.read_bytes()).hexdigest(),samples=a.samples,
      input_lengths=lengths,max_length=a.max_length,margin=a.margin,fp8_finfo_max=fp8_max,tp_sizes=a.tp_sizes,
      scope='SMOKE_CALIBRATION_NOT_QUALITY_GUARANTEE' if a.samples<128 else 'RANGE_CALIBRATION_REQUIRES_HELD_OUT_QUALITY_EVAL',
      note='Real post-RoPE/QK-normalized K/V maxima; one shared K/V scalar per TP rank/layer. Calibration does not prove all future inputs fit range.'))
    print('output:',a.output)
if __name__=='__main__':main()
