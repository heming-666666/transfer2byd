"""Run inside the pinned image with torchrun --standalone --nproc-per-node=8."""
import os
from datetime import timedelta
import torch
import torch.distributed as dist

local_rank = int(os.environ["LOCAL_RANK"])
torch.cuda.set_device(local_rank)
dist.init_process_group("nccl", timeout=timedelta(seconds=120))
x = torch.tensor([dist.get_rank() + 1.0], device=f"cuda:{local_rank}")
dist.all_reduce(x)
torch.cuda.synchronize()
world = dist.get_world_size()
expected = world * (world + 1) / 2
assert x.item() == expected, (x.item(), expected)
print({"rank": dist.get_rank(), "gpu": torch.cuda.get_device_name(local_rank),
       "capability": torch.cuda.get_device_capability(local_rank),
       "torch": torch.__version__, "torch_cuda": torch.version.cuda,
       "all_reduce": x.item(), "expected": expected}, flush=True)
dist.destroy_process_group()
