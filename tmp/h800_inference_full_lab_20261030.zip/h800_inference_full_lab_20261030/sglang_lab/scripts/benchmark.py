"""Pinned official SGLang HTTP benchmark. Run after real model/gateway acceptance."""
import argparse,json,os,re,shlex,subprocess
from datetime import datetime,timezone
from pathlib import Path
from common import ROOT,settings,profiles,model_path,native_python,native_environment,write_json
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--profile',default='8g_baseline');p.add_argument('--name',default='run')
    p.add_argument('--input-len',type=int,default=1024);p.add_argument('--output-len',type=int,default=256);p.add_argument('--requests',type=int,default=128)
    p.add_argument('--rate',default='4');p.add_argument('--max-concurrency',type=int);p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    cfg=settings();pro=profiles()[a.profile]
    if not re.fullmatch(r'[A-Za-z0-9_.-]+',a.name):p.error('name 仅字母/数字/点/下划线/短横线')
    out=ROOT/'data/results/benchmarks'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')+'_'+a.name);out.mkdir(parents=True)
    cmd=[str(native_python(cfg)),'-m','sglang.benchmark.serving','--backend','sglang-oai-chat',
      '--base-url',f"http://127.0.0.1:{cfg['public_port']}",'--model',cfg['model_alias'],
      '--tokenizer',str(model_path(pro['model'],cfg)),'--dataset-name','random',
      '--random-input-len',str(a.input_len),'--random-output-len',str(a.output_len),
      '--random-range-ratio','1','--num-prompts',str(a.requests),'--request-rate',a.rate,
      '--seed','42','--output-file',str(out/'metrics.jsonl'),'--output-details']
    if a.max_concurrency:cmd+=['--max-concurrency',str(a.max_concurrency)]
    manifest=dict(profile=pro,declared_profile=a.profile,command=cmd,status='DRY_RUN' if a.dry_run else 'PENDING',
      warning='随机 token 性能负载，不评分模型能力；请求长度包含 API chat template 开销，需按实际 usage 复核')
    write_json(out/'manifest.json',manifest);print(shlex.join(cmd));print('output:',out)
    if a.dry_run:return
    with (out/'console.log').open('w') as f:r=subprocess.run(cmd,env=native_environment(cfg,public=True),stdout=f,stderr=subprocess.STDOUT)
    manifest.update(returncode=r.returncode,status='COMMAND_EXITED_ZERO' if r.returncode==0 else 'FAILED');write_json(out/'manifest.json',manifest)
    print((out/'console.log').read_text()[-12000:]);raise SystemExit(r.returncode)
if __name__=='__main__':main()
