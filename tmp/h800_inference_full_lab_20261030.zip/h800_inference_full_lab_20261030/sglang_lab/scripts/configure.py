"""Initialize once; later calls preserve credentials and unrelated settings."""
import argparse
import ipaddress
import secrets as secret_module
from pathlib import Path
from common import ROOT, read_json, write_json, absolute

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--lan-ip")
    p.add_argument("--model-root")
    p.add_argument("--docker-image")
    args = p.parse_args()
    config_path = ROOT / "config/settings.json"
    cfg = read_json(config_path if config_path.exists() else ROOT / "config/settings.example.json")
    if args.lan_ip:
        ipaddress.IPv4Address(args.lan_ip)
        cfg["lan_ip"] = args.lan_ip
    if args.model_root:
        cfg["model_root"] = str(absolute(args.model_root))
    if args.docker_image:
        cfg["docker_image"] = args.docker_image
    for key in ["public_port", "engine_port", "prefill_port", "decode_port", "pd_proxy_port"]:
        if not 1024 <= int(cfg[key]) <= 65535:
            p.error(f"invalid port {key}")
    if len({cfg[k] for k in cfg if k.endswith('_port')}) != 6:
        p.error("ports must be distinct")
    for folder in ["data/logs", "data/results", "data/conversations", "data/runtime", "data/reports"]:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    absolute(cfg.get("cache_root", "environments/sglang0522/cache")).mkdir(parents=True, exist_ok=True)
    absolute(cfg["model_root"]).mkdir(parents=True, exist_ok=True)
    secret_path = ROOT / "config/secrets.json"
    auth = read_json(secret_path) if secret_path.exists() else {
        "public_api_key": "sk-local-" + secret_module.token_urlsafe(32),
        "engine_api_key": "internal-" + secret_module.token_urlsafe(32),
        "admin_api_key": "admin-" + secret_module.token_urlsafe(32)}
    write_json(config_path, cfg)
    auth.setdefault("admin_api_key", "admin-" + secret_module.token_urlsafe(32))
    write_json(secret_path, auth, private=True)
    engine_env = ROOT / "config/engine.env"
    engine_env.touch(mode=0o600, exist_ok=True)
    engine_env.write_text("VLLM_API_KEY=" + auth["engine_api_key"] + "\nOPENAI_API_KEY=" + auth["engine_api_key"] + "\n", encoding="utf-8")
    engine_env.chmod(0o600)
    client_env = ROOT / "config/client.env"
    client_env.touch(mode=0o600, exist_ok=True)
    client_env.write_text("OPENAI_API_KEY=" + auth["public_api_key"] + "\n", encoding="utf-8")
    client_env.chmod(0o600)
    write_json(ROOT / "config/client.json", {
        "base_url": f"http://{cfg['lan_ip']}:{cfg['public_port']}/v1",
        "api_key": auth["public_api_key"], "model": cfg["model_alias"]}, private=True)
    print("配置完成；密钥未打印。")
    print("server settings: config/settings.json")
    print("client connection: config/client.json (仅复制给获准使用的人)")
    print("model root:", absolute(cfg["model_root"]))
    if cfg["lan_ip"] == "SET_SERVER_LAN_IP":
        print("待设置 LAN IP：python3 scripts/configure.py --lan-ip <服务器内网IPv4>")

if __name__ == "__main__":
    main()
