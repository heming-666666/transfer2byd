"""Wait for authenticated local engine/router readiness; gateway liveness is insufficient."""
import argparse,time,urllib.request,urllib.error
from common import settings,secrets
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--target',choices=['engine','prefill','decode','router'],default='engine');p.add_argument('--timeout',type=float,default=1800)
    a=p.parse_args();c=settings();port=c['pd_proxy_port' if a.target=='router' else a.target+'_port']
    req=urllib.request.Request(f'http://127.0.0.1:{port}/health',headers={'Authorization':'Bearer '+secrets()['engine_api_key']})
    end=time.monotonic()+a.timeout
    while time.monotonic()<end:
        try:
            with urllib.request.urlopen(req,timeout=4) as r:
                if r.status==200:print('READY',a.target,port);return
        except (OSError,urllib.error.HTTPError):pass
        time.sleep(3)
    raise SystemExit('未就绪：检查 data/logs；不要把 /health 网关存活当作模型加载成功')
if __name__=='__main__':main()
