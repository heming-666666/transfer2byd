"""Pinned Rust SGLang router; private worker key stays out of argv."""
import importlib.metadata as m
from common import settings,secrets
if m.version('sglang-router')!='0.3.2':raise SystemExit('需要 sglang-router==0.3.2')
from sglang_router.launch_router import parse_router_args,launch_router
c=settings()
a=parse_router_args(['--pd-disaggregation','--prefill',f"http://127.0.0.1:{c['prefill_port']}",str(c['bootstrap_port']),
                     '--decode',f"http://127.0.0.1:{c['decode_port']}",'--host','127.0.0.1','--port',str(c['pd_proxy_port'])])
a.api_key=secrets()['engine_api_key']
launch_router(a)
