"""Preparation machine only: collect a portable CPython and ALL resolved wheels."""
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--python-archive', type=Path, required=True,
                   help='官方 python-build-standalone CPython3.12 x86_64 Linux GNU install_only tar.gz')
    p.add_argument('--python-sha256', required=True, help='从官方校验清单取得的真实 SHA256，不接受随意编造')
    p.add_argument('--use-existing-wheels', action='store_true', help='仅封装已从网页/镜像站备齐的 wheel，不发起下载')
    a=p.parse_args()
    temp_root=ROOT/"environments/preparation_tmp"; temp_root.mkdir(parents=True,exist_ok=True)
    os.environ.update(TMPDIR=str(temp_root),PIP_CONFIG_FILE=os.devnull,PIP_CACHE_DIR=str(ROOT/"environments/preparation_cache"))
    if platform.system()!='Linux' or platform.machine()!='x86_64' or sys.version_info[:2]!=(3,12):
        raise SystemExit('准备过程要求 Linux x86_64 + CPython3.12；不在 Windows 解析 Linux CUDA 依赖。可在匹配的 Linux/WSL 环境准备。')
    source=a.python_archive.resolve()
    if digest(source)!=a.python_sha256.lower():
        raise SystemExit('Python archive 官方校验值不匹配')
    assets=ROOT/'environments/python/assets'; assets.mkdir(parents=True,exist_ok=True)
    archive=assets/'cpython-install-only.tar.gz'
    if source!=archive.resolve():
        shutil.copyfile(source,archive)
    (assets/'archive.sha256').write_text(digest(archive)+'  environments/python/assets/cpython-install-only.tar.gz\n')
    wheels=ROOT/'environments/sglang0522/wheelhouse'; wheels.mkdir(parents=True,exist_ok=True)
    if not a.use_existing_wheels:
        subprocess.run([sys.executable,'-m','pip','download','--pre','--no-cache-dir','--only-binary=:all:',
            '--dest',str(wheels),'--extra-index-url','https://download.pytorch.org/whl/cu130',
            '--extra-index-url','https://flashinfer.ai/whl',
            '--extra-index-url','https://flashinfer.ai/whl/cu130',
            '-r',str(ROOT/'environments/sglang0522/requirements.in')],check=True)
    if not list(wheels.glob('*.whl')):
        raise SystemExit('wheelhouse 为空')
    # This checks dependency closure without installing into the preparation machine.
    report=ROOT/'environments/sglang0522/resolution.json'
    subprocess.run([sys.executable,'-m','pip','install','--no-cache-dir','--dry-run','--ignore-installed','--no-index',
                    '--pre','--only-binary=:all:','--find-links',str(wheels),'--report',str(report),
                    '-r',str(ROOT/'environments/sglang0522/requirements.in')],check=True)
    selected=json.loads(report.read_text())['install']
    versions={x['metadata']['name'].lower().replace('_','-'):x['metadata']['version'] for x in selected}
    if versions.get('sglang')!='0.5.22' or versions.get('torch','').split('+')[0]!='2.14.1':
        raise SystemExit('固定版本未满足，不得忽略依赖冲突')
    if 'nixl-cu13' not in versions:raise SystemExit('缺少 CUDA13 NIXL 实现')
    lock=ROOT/'environments/sglang0522/requirements.lock'
    lock.write_text(''.join(name+'=='+version+'\n' for name,version in sorted(versions.items())))
    artifacts=[archive,ROOT/'environments/sglang0522/requirements.in',ROOT/'environments/sglang0522/requirements.kernel.in',lock,report,*sorted(wheels.glob('*.whl'))]
    manifest={'architecture':'x86_64','os':'Linux','python':'3.12',
              'framework':'sglang==0.5.22','nixl':'1.5.0','cuda':'cu130','resolved_versions':versions,'files':[]}
    for path in artifacts:
        manifest['files'].append({'path':path.relative_to(ROOT).as_posix(),
                                  'bytes':path.stat().st_size,'sha256':digest(path)})
    (ROOT/'environments/OFFLINE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('离线依赖已解析并封装；将整个 environments 目录与项目一起转移。')
    print('最终可用性仍须在 H800 上执行 bootstrap + CUDA/NCCL + 真实模型验收。')

if __name__=='__main__':
    main()
