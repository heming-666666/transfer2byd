"""Strict external scalar KV-scale validation; fail instead of silently defaulting to 1.0."""
import argparse,json,math
from pathlib import Path
def validate_scale_file(path,model_config,tp):
    d=json.loads(Path(path).read_text());n=model_config['num_hidden_layers']
    if d.get('model_type')!=model_config['model_type']:raise ValueError('KV scales model_type mismatch')
    cache=d.get('kv_cache',{})
    if cache.get('dtype')!='float8_e4m3fn':raise ValueError('KV scales must be float8_e4m3fn')
    maps=cache.get('scaling_factor',{})
    if set(maps)!={str(i) for i in range(tp)}:raise ValueError('KV scales TP ranks mismatch')
    for values in maps.values():
        if set(values)!={str(i) for i in range(n)}:raise ValueError('KV scales layer keys mismatch')
        if any(not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 for v in values.values()):raise ValueError('KV scales must be positive finite scalars')
    return d
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--scales',type=Path,required=True);p.add_argument('--model',type=Path,required=True);p.add_argument('--tp',type=int,required=True);a=p.parse_args()
    validate_scale_file(a.scales,json.loads((a.model/'config.json').read_text()),a.tp);print('KV scales structure PASS; quality still requires evaluation')
if __name__=='__main__':main()
