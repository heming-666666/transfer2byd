"""Test auth, route restrictions, models and optionally real generation."""
import argparse
import json
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
from common import ROOT, write_json
from client_lib import load_client, request, chat_once

def status(url, key=None):
    headers = {} if key is None else {"Authorization": "Bearer " + key}
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(urllib.request.Request(url, headers=headers), timeout=10) as r:
            return r.status
    except urllib.error.HTTPError as exc:
        return exc.code

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path)
    p.add_argument("--chat", "--with-generation", dest="chat", action="store_true")
    p.add_argument("--out", type=Path, default=ROOT / "data/results/smoke/latest.json")
    a = p.parse_args()
    cfg = load_client(a.config)
    root = cfg["base_url"].rsplit("/v1", 1)[0]
    checks = [
        {"check": "gateway_alive", "actual": status(root + "/health"), "expected": 200},
        {"check": "missing_key_rejected", "actual": status(cfg["base_url"] + "/models"), "expected": 401},
        {"check": "wrong_key_rejected", "actual": status(cfg["base_url"] + "/models", "wrong-key"), "expected": 401},
        {"check": "unexposed_metrics", "actual": status(root + "/metrics", cfg["api_key"]), "expected": 404},
        {"check": "unexposed_invocations", "actual": status(root + "/invocations", cfg["api_key"]), "expected": 404}]
    with request(cfg, "/models") as r:
        data = json.load(r)
    ids = [item["id"] for item in data["data"]]
    checks.append({"check": "served_alias", "actual": cfg["model"] in ids, "expected": True})
    if a.chat:
        for stream in [False, True]:
            result = chat_once(cfg, [{"role": "user", "content": "请用一句中文说明 KV Cache 的作用。"}], max_tokens=4096, stream=stream)
            checks.append({"check": "generation_stream_" + str(stream),
                           "actual": bool(result["content"]), "expected": True,
                           "finish_reason": result["finish_reason"], "usage": result["usage"],
                           "metrics": result["metrics"]})
    passed = all(c["actual"] == c["expected"] for c in checks)
    report = {"time_utc": datetime.now(timezone.utc).isoformat(), "base_url": cfg["base_url"],
              "passed": passed, "checks": checks, "generation_tested": a.chat}
    write_json(a.out, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if passed else 2)

if __name__ == "__main__":
    main()
