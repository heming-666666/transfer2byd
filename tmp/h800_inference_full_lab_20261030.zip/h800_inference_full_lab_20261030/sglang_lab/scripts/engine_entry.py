"""Private keys enter ServerArgs in memory, never in command-line arguments."""
import importlib.metadata as metadata, os, sys
from common import secrets
if metadata.version('sglang')!='0.5.22':raise SystemExit('只验收 sglang==0.5.22；不要自动升级')
from sglang.srt.plugins import load_plugins
from sglang.srt.server_args import prepare_server_args
from sglang.launch_server import run_server
from sglang.srt.utils import kill_process_tree
load_plugins()
args=prepare_server_args(sys.argv[1:]);auth=secrets()
args.api_key=auth['engine_api_key'];args.admin_api_key=auth['admin_api_key']
try:run_server(args)
finally:kill_process_tree(os.getpid(),include_parent=False)
