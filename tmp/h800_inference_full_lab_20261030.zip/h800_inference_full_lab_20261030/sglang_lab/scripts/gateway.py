"""Small LAN-lab gateway: exact route allowlist, bearer auth, unbuffered streaming.

Uses only Python's standard library. For high-concurrency/public deployments,
replace this educational gateway with a maintained reverse proxy/API gateway.
"""
from __future__ import annotations
import argparse
import hmac
import http.client
import json
import threading
import time
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
from common import ROOT, settings, secrets

ALLOWED = {("GET", "/v1/models"), ("POST", "/v1/chat/completions")}
AUDIT_LOCK = threading.Lock()

class GatewayServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class GatewayHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_):
        pass  # Never log Authorization headers or request bodies.

    def reply(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

    def audit(self, record):
        cfg = self.server.cfg
        stamp = datetime.now(timezone.utc)
        path = self.server.audit_dir / (stamp.strftime("%Y-%m-%d") + ".jsonl")
        path.parent.mkdir(parents=True, exist_ok=True)
        with AUDIT_LOCK, path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"time_utc": stamp.isoformat(), **record}, ensure_ascii=False) + "\n")

    def do_GET(self):
        self.handle_api()

    def do_POST(self):
        self.handle_api()

    def handle_api(self):
        cfg = self.server.cfg
        started = time.perf_counter()
        rid = uuid.uuid4().hex
        path = urlsplit(self.path).path
        if self.command == "GET" and self.path == "/health":
            self.reply(200, {"status": "gateway_running", "mode": self.server.mode,
                             "note": "这是网关存活状态；不代表 GPU 已就绪"})
            return
        if (self.command, path) not in ALLOWED or self.path != path:
            self.reply(404, {"error": "endpoint_not_exposed"})
            return
        expected = "Bearer " + self.server.auth["public_api_key"]
        if not hmac.compare_digest(self.headers.get("Authorization", "").encode("utf-8"), expected.encode("utf-8")):
            self.reply(401, {"error": "invalid_api_key"})
            self.audit({"request_id": rid, "path": path, "status": 401})
            return
        body = None
        if self.command == "POST":
            if self.headers.get("Transfer-Encoding"):
                self.reply(400, {"error": "send_json_with_content_length"})
                return
            try:
                length = int(self.headers.get("Content-Length", "-1"))
                if length < 0:
                    self.reply(411, {"error": "content_length_required"})
                    return
                if length > cfg["max_request_bytes"]:
                    self.reply(413, {"error": "request_too_large"})
                    return
                self.connection.settimeout(30)
                body = self.rfile.read(length)
                if len(body) != length:
                    raise ValueError("incomplete body")
                data = json.loads(body)
                if not isinstance(data, dict) or data.get("model") != cfg["model_alias"]:
                    self.reply(400, {"error": "model_must_be_" + cfg["model_alias"]})
                    return
                if any(k in data for k in ("kv_transfer_params","bootstrap_host","bootstrap_port","bootstrap_room","return_routed_experts")):
                    self.reply(400, {"error": "kv_transfer_params_are_internal"})
                    return
            except (ValueError, TimeoutError):
                self.reply(400, {"error": "invalid_json_or_body"})
                return
        if self.server.mode == "pd":
            port = cfg["decode_port"] if path == "/v1/models" else cfg["pd_proxy_port"]
        else:
            port = cfg["engine_port"]
        conn = http.client.HTTPConnection("127.0.0.1", port,
                                          timeout=cfg["upstream_timeout_seconds"])
        headers_sent, status, sent, complete = False, 502, 0, False
        try:
            conn.request(self.command, path, body=body, headers={
                "Authorization": "Bearer " + self.server.auth["engine_api_key"],
                "Content-Type": "application/json", "X-Request-Id": rid})
            resp = conn.getresponse()
            status = resp.status
            self.send_response(status)
            self.send_header("Content-Type", resp.getheader("Content-Type", "application/json"))
            self.send_header("X-Request-Id", rid)
            self.send_header("Transfer-Encoding", "chunked")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.end_headers()
            headers_sent = True
            while True:
                chunk = resp.read1(16384)
                if not chunk:
                    break
                self.wfile.write(f"{len(chunk):x}\r\n".encode() + chunk + b"\r\n")
                self.wfile.flush()
                sent += len(chunk)
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
            complete = True
        except (OSError, http.client.HTTPException):
            if not headers_sent:
                self.reply(502, {"error": "upstream_unavailable", "request_id": rid,
                                 "hint": "检查引擎就绪状态以及 data/logs 中的日志"})
        finally:
            conn.close()
            self.close_connection = True
            self.audit({"request_id": rid, "path": path, "status": status,
                        "duration_ms": round((time.perf_counter() - started) * 1000, 2),
                        "bytes_sent": sent, "complete": complete, "upstream_port": port})

def make_server(cfg, auth, mode="integrated", audit_dir=None):
    server = GatewayServer((cfg["public_host"], cfg["public_port"]), GatewayHandler)
    server.cfg, server.auth, server.mode = cfg, auth, mode
    server.audit_dir = audit_dir or ROOT / "data/logs/gateway"
    return server

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--mode", choices=["integrated", "pd"], default="integrated")
    a = p.parse_args()
    server = make_server(settings(), secrets(), a.mode)
    print(f"网关启动：0.0.0.0:{server.server_port}，mode={a.mode}；密钥与正文不写审计日志。", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
