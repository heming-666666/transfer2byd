"""Persistent multi-turn CLI. Conversation files are saved on the client machine."""
import argparse
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from common import ROOT, read_json, write_json
from client_lib import load_client, chat_once

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path)
    p.add_argument("--message")
    p.add_argument("--resume", type=Path, help="先前会话的 conversation.json")
    p.add_argument("--history-dir", type=Path, default=ROOT / "data/conversations")
    p.add_argument("--max-tokens", type=int, default=2048)
    p.add_argument("--temperature", type=float, default=0.6)
    p.add_argument("--no-stream", action="store_true")
    p.add_argument("--show-reasoning", action="store_true")
    a = p.parse_args()
    cfg = load_client(a.config)
    if a.resume:
        session = read_json(a.resume)
        directory = a.resume.resolve().parent
    else:
        sid = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_") + uuid.uuid4().hex[:8]
        directory = a.history_dir / sid
        session = {"session_id": sid, "model": cfg["model"], "messages": []}
    directory.mkdir(parents=True, exist_ok=True)
    state_file = directory / "conversation.json"
    print("会话路径：", state_file)
    while True:
        try:
            text = a.message if a.message is not None else input("\n你（/exit 退出）：").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if text == "/exit":
            break
        if not text:
            if a.message is not None:
                break
            continue
        messages = session["messages"] + [{"role": "user", "content": text}]
        try:
            print("模型：", end="", flush=True)
            result = chat_once(cfg, messages, a.max_tokens, not a.no_stream, a.temperature,
                on_content=lambda s: print(s, end="", flush=True),
                on_reasoning=(lambda s: print(s, end="", file=sys.stderr, flush=True)) if a.show_reasoning else None)
            if a.no_stream:
                print(result["content"], end="")
            print()
            if not result["content"]:
                print("本次没有正文；可能输出预算耗尽在推理阶段。增加 --max-tokens 后再试。")
            else:
                session["messages"] = messages + [{"role": "assistant", "content": result["content"]}]
                write_json(state_file, session, private=True)
            with (directory / "turns.jsonl").open("a", encoding="utf-8") as f:
                f.write(json.dumps({"time_utc": datetime.now(timezone.utc).isoformat(), "user": text, **result}, ensure_ascii=False) + "\n")
            (directory / "turns.jsonl").chmod(0o600)
            print("finish_reason:", result["finish_reason"], "usage:", result["usage"])
        except (RuntimeError, OSError, ValueError) as exc:
            print("请求失败：", exc)
            if a.message is not None:
                raise SystemExit(2)
        if a.message is not None:
            break

if __name__ == "__main__":
    main()
