"""Run with the project venv on the H800 host. No network or global changes."""
import argparse,importlib.metadata as m,json,os,platform,subprocess
from pathlib import Path
from common import ROOT,native_environment,settings,write_json
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cards',type=int,choices=[4,8],default=8)
    p.add_argument('--with-nixl',action='store_true',help='Additional PD capability gate; not required for the integrated model baseline');a=p.parse_args()
    import torch
    from sglang.srt.server_args import prepare_server_args
    from run import engine_args,profiles
    c=settings();env=native_environment(c)
    info={'platform':platform.platform(),'torch':torch.__version__,'cuda':torch.version.cuda,
      'sglang':m.version('sglang'),'router':m.version('sglang-router'),'nixl':m.version('nixl'),
      'gpu_count':torch.cuda.device_count(),'devices':[],'status':'STARTED'}
    if torch.cuda.device_count()<a.cards:raise SystemExit('可见 GPU 不足')
    if not torch.cuda.is_available():raise SystemExit('CUDA 不可用')
    for i in range(a.cards):
        d=torch.cuda.get_device_properties(i);info['devices'].append({'index':i,'name':d.name,'memory_bytes':d.total_memory,'capability':[d.major,d.minor]})
        if d.major<9:raise SystemExit('此实验方案针对 Hopper H800/sm90；当前 GPU 不符')
        with torch.cuda.device(i):
            x=torch.randn(1024,1024,device='cuda',dtype=torch.bfloat16);y=x@x;torch.cuda.synchronize();assert torch.isfinite(y).all()
    prepare_server_args(engine_args(c,profiles()[f'{a.cards}g_baseline']))
    import sglang_router.sglang_router_rs
    info['nixl_agent_constructed']='NOT_REQUESTED'
    if a.with_nixl:
        import nixl
        agent=nixl.nixl_agent('lab_runtime_probe');info['nixl_agent_constructed']=True
    info['status']='CUDA_MATMUL_AND_IMPORT_PASS_NOT_MODEL_ACCEPTANCE'
    write_json(ROOT/'data/reports/runtime_check.json',info);print(json.dumps(info,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
