#!/usr/bin/env bash
# Linux x86_64. Install only inside this project, with no network fallback.
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$TASK_ROOT"
mkdir -p environments/bootstrap-tmp environments/bootstrap-cache
export TMPDIR="$TASK_ROOT/environments/bootstrap-tmp"
export PIP_CACHE_DIR="$TASK_ROOT/environments/bootstrap-cache"
if [[ ! -f environments/OFFLINE_MANIFEST.json ]]; then
  echo "缺少 environments/OFFLINE_MANIFEST.json。先按 02 准备/封装离线依赖。" >&2
  exit 2
fi
TASK_ARCHIVE="environments/python/assets/cpython-install-only.tar.gz"
if [[ ! -f "$TASK_ARCHIVE" ]]; then
  echo "缺少 $TASK_ARCHIVE" >&2
  exit 2
fi
# CPython archive checksum is also checked before extraction.
if [[ ! -f environments/python/assets/archive.sha256 ]]; then
  echo "缺少 Python archive 校验文件" >&2
  exit 2
fi
sha256sum --check environments/python/assets/archive.sha256
mkdir -p environments/python/cpython
if [[ ! -x environments/python/cpython/bin/python3 ]]; then
  tar --extract --file "$TASK_ARCHIVE" --directory environments/python/cpython --strip-components=1 --no-same-owner
fi
exec environments/python/cpython/bin/python3 scripts/bootstrap_env.py "$@"
