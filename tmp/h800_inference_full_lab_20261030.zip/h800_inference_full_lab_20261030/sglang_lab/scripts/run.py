"""SGLang v0.5.22 project-local launcher. --dry-run never imports torch."""
from __future__ import annotations
import argparse, hashlib, json, os, shlex, signal, time
from pathlib import Path
from common import ROOT, settings, profiles, models, model_path, native_python, native_environment, read_json, write_json
from check_model import inspect_model
BUNDLE=hashlib.sha256(str(ROOT).encode()).hexdigest()[:16]

def validate_profile(p):
    dims=['tp','dp','pp','attn_dp','cp','dcp','ep','moe_dp']
    if any(not isinstance(p.get(k,1),int) or p.get(k,1)<1 for k in dims):
        raise ValueError('并行维度必须为正整数')
    g=p['gpus']
    if len(set(g))!=len(g) or any(not isinstance(x,int) or x<0 for x in g):
        raise ValueError('GPU 编号无效/重复')
    if p['tp']*p['dp']*p['pp']!=len(g):
        raise ValueError('整模型 GPU 数必须等于 TP×DP×PP；Attention DP/CP/EP 不额外相乘')
    ad,cp=p.get('attn_dp',1),p.get('cp',1)
    if p['tp']%(ad*cp): raise ValueError('TP 必须可被 AttentionDP×CP 整除')
    if (p['tp']//(ad*cp))%p.get('dcp',1): raise ValueError('DCP 必须整除 Attention TP')
    if p['tp']%(p.get('ep',1)*p.get('moe_dp',1)): raise ValueError('EP×MoEDP 必须整除 TP')
    if p.get('ep',1)>1 and models()[p['model']]['kind']!='moe': raise ValueError('EP 必须使用 MoE 模型')
    if p.get('layernorm_sp'):
        if p['model']!='dense' or ad!=1 or p['pp']!=1 or p['tp']<2 or p.get('speculative'):
            raise ValueError('LayerNorm SP 仅本包 Qwen3 dense 纯 TP，且不能混合 PP/AttentionDP/投机')
    if p.get('allocation_policy')=='prefill_complete' and (p['tp']!=1 or cp!=1):
        raise ValueError('prefill_complete 仅 TP1/CP1；P4+D4 不得直接套用')
    return p

def engine_args(cfg,p,eager=False):
    validate_profile(p)
    m=models()[p['model']];role=p.get('role','engine')
    args=['--model-path',str(model_path(p['model'],cfg)), '--served-model-name',cfg['model_alias'],
          '--host','127.0.0.1','--port',str(cfg[role+'_port']),
          '--tp-size',str(p['tp']),'--dp-size',str(p['dp']),'--pp-size',str(p['pp']),
          '--attn-dp-size',str(p.get('attn_dp',1)),'--attn-cp-size',str(p.get('cp',1)),
          '--dcp-size',str(p.get('dcp',1)),'--ep-size',str(p.get('ep',1)),
          '--moe-dp-size',str(p.get('moe_dp',1)),
          '--context-length',str(p['context_length']),'--max-running-requests',str(p['max_running_requests']),
          '--chunked-prefill-size',str(p['chunked_prefill_size']),
          '--mem-fraction-static',str(cfg['mem_fraction_static']),
          '--attention-backend',p.get('attention_backend','triton'),'--grammar-backend','xgrammar',
          '--cuda-graph-backend-decode','disabled' if eager or not p.get('graphs') else 'full',
          '--cuda-graph-backend-prefill','disabled','--enable-metrics']
    if p.get('attention_backend') is None:
        idx=args.index('--attention-backend');del args[idx:idx+2]
    if p.get('max_total_tokens'):args+=['--max-total-tokens',str(p['max_total_tokens'])]
    if p.get('schedule_policy'):args+=['--schedule-policy',p['schedule_policy']]
    if p.get('graphs') and not eager: args+=['--cuda-graph-max-bs-decode','32']
    if p.get('capture_profiler'):
        if eager or not p.get('graphs'):raise ValueError('capture-profiler 需要开启 graph，不能与 eager/graphs_off 混用')
        args+=['--enable-profile-cuda-graph']
    if m.get('reasoning_parser'): args+=['--reasoning-parser',m['reasoning_parser']]
    if m.get('tool_call_parser'): args+=['--tool-call-parser',m['tool_call_parser']]
    if m.get('trust_remote_code'): args+=['--trust-remote-code']
    if p.get('prefill_cp'): args+=['--enable-prefill-cp','--cp-strategy','zigzag']
    for flag,key in [('enable-layernorm-sp','layernorm_sp'),('disable-radix-cache','disable_radix'),
                     ('disable-overlap-schedule','disable_overlap'),('enable-return-routed-experts','capture_experts')]:
        if p.get(key): args+=['--'+flag]
    for flag,key in [('quantization','quantization'),('kv-cache-dtype','kv_cache_dtype'),
                     ('moe-a2a-backend','moe_a2a_backend'),('moe-runner-backend','moe_runner_backend')]:
        if p.get(key):args+=['--'+flag,str(p[key])]
    if p.get('requires_kv_scales'):
        scale_path=cfg.get('kv_scale_paths',{}).get(str(p['tp'])) or cfg.get('kv_scale_path')
        if not scale_path: raise ValueError('FP8 KV 校准配置缺失；设置 kv_scale_path，或明确选择 uncalibrated 实验')
        from common import absolute
        args+=['--quantization-param-path',str(absolute(scale_path))]
    if p.get('model_override'):args+=['--json-model-override-args',json.dumps(p['model_override'])]
    if p.get('speculative'):
        method=p['speculative'];args+=['--speculative-algorithm',method]
        if p.get('draft'):args+=['--speculative-draft-model-path',str(model_path(p['draft'],cfg))]
        if method=='EAGLE3':args+=['--speculative-num-steps','3','--speculative-eagle-topk','1','--speculative-num-draft-tokens','4']
        if method=='DFLASH':args+=['--speculative-num-draft-tokens','16']
        if method=='EAGLE':args+=['--speculative-num-steps','1','--speculative-eagle-topk','1','--speculative-num-draft-tokens','2']
        if method=='DSPARK':args+=['--speculative-dspark-block-size','5']
    if role in ('prefill','decode'):
        args+=['--disaggregation-mode',role,'--disaggregation-transfer-backend',p['transfer_backend'],
               '--disaggregation-bootstrap-port',str(cfg['bootstrap_port'] if role=='prefill' else cfg['bootstrap_port']+1),
               '--disaggregation-decode-allocation-policy',p.get('allocation_policy','early')]
        if p.get('kv_checksum'):args+=['--disaggregation-enable-kv-checksum']
    if p['model'] in ('latest','modern'):args+=['--language-model-only']
    return args

def engine_env(cfg,p):
    env=native_environment(cfg)
    env['CUDA_VISIBLE_DEVICES']=','.join(map(str,p['gpus']))
    env.update(p.get('env',{}))
    if p.get('capture_profiler'):
        env['SGLANG_ENABLE_CUDA_GRAPH_CAPTURE_TRACE']='1'
        env.pop('SGLANG_GRAPH_BATCH_CAPTURE',None)
    if p.get('role'):
        if p['transfer_backend']=='mooncake': env.update(MOONCAKE_PROTOCOL='tcp',MC_FORCE_TCP='1')
        elif p['transfer_backend']=='nixl':env['SGLANG_DISAGGREGATION_NIXL_BACKEND']='UCX'
    if p['model']=='latest':env['SGLANG_ENABLE_DSV41_ENGRAM_HOST_TABLE']='1'
    return env

def process_start(pid):
    try:
        fields = ROOT.__class__(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return None if fields[0] in ("Z", "X") else fields[19]
    except (OSError, IndexError):
        return None

def is_running(record):
    return bool(record.get("bundle") == BUNDLE and record.get("start_ticks") is not None
                and process_start(record.get("proc_pid", record["pid"])) == record.get("start_ticks"))

def native_records():
    folder = ROOT / "data/runtime/processes"
    folder.mkdir(parents=True, exist_ok=True)
    records = []
    for file in folder.glob("*.json"):
        try:
            row = read_json(file)
            if is_running(row):
                records.append((file, row))
        except (OSError, ValueError, KeyError):
            pass
    return records

def register_native(role, profile_name, gpus, cmd):
    for _, row in native_records():
        if row["role"] == role or set(row.get("gpus", [])).intersection(gpus):
            raise SystemExit("本包进程尚在运行或 GPU 重叠：" + row["role"] + "；先执行 run.py stop")
    if os.getpgrp() != os.getpid():
        os.setsid()
    pid = os.getpid()
    proc_stat = (ROOT.__class__("/proc/self/stat").read_text())
    proc_pid = int(proc_stat.split("(", 1)[0].strip())
    start_ticks = proc_stat.rsplit(")", 1)[1].split()[19]
    write_json(ROOT / f"data/runtime/processes/{role}.json", {
        "bundle": BUNDLE, "pid": pid, "proc_pid": proc_pid, "pgid": os.getpgrp(), "start_ticks": start_ticks,
        "pid_namespace": os.stat("/proc/self/ns/pid").st_ino,
        "role": role, "profile": profile_name, "gpus": gpus, "command": cmd})

def stop_native(target):
    for file, row in native_records():
        if target != "all" and row["role"] != target:
            continue
        if row.get("pid_namespace") != os.stat("/proc/self/ns/pid").st_ino:
            raise SystemExit("进程处于另一个 PID namespace；拒绝用当前命名空间的 PID 停止。请到原运行环境处理。")
        if row["pgid"] != row["pid"] or os.getpgid(row["pid"]) != row["pgid"]:
            raise SystemExit("进程组身份不符，停止操作已拒绝；请人工检查 " + str(file))
        os.killpg(row["pgid"], signal.SIGTERM)
        deadline = time.monotonic() + 45
        while is_running(row) and time.monotonic() < deadline:
            time.sleep(0.2)
        if is_running(row):
            raise SystemExit("仍未退出，保留状态供排查；不自动杀其他进程。" + str(file))
        file.unlink(missing_ok=True)
        print("已停止", row["role"])


def main():
    ap=argparse.ArgumentParser(description=__doc__);sp=ap.add_subparsers(dest='action',required=True)
    en=sp.add_parser('engine');en.add_argument('--profile',default='8g_baseline');en.add_argument('--eager',action='store_true')
    en.add_argument('--capture-profiler',action='store_true',help='profile startup decode CUDA graph capture; graph-on profiles only')
    en.add_argument('--dry-run',action='store_true');en.add_argument('--allow-experimental',action='store_true')
    rt=sp.add_parser('pd-router');rt.add_argument('--dry-run',action='store_true')
    gw=sp.add_parser('gateway');gw.add_argument('--mode',choices=['integrated','pd'],default='integrated')
    sp.add_parser('list');sp.add_parser('status');st=sp.add_parser('stop');st.add_argument('target',choices=['engine','prefill','decode','router','gateway','all'])
    a=ap.parse_args();cfg=settings()
    if a.action=='list':
        for name,p in profiles().items():validate_profile(p);print(name,json.dumps(p,ensure_ascii=False))
        return
    if a.action=='status':
        for _,row in native_records():print(json.dumps(row,ensure_ascii=False))
        return
    if a.action=='stop':return stop_native(a.target)
    p=None
    if a.action=='engine':
        p=profiles().get(a.profile)
        if p is None:ap.error('未知 profile；run.py list')
        if a.capture_profiler:p=dict(p,capture_profiler=True)
        try:args=engine_args(cfg,p,a.eager)
        except ValueError as e:ap.error(str(e))
        cmd=[str(native_python(cfg)),str(ROOT/'scripts/engine_entry.py'),*args]
        if a.dry_run:
            print(json.dumps({'profile':a.profile,'gpus':p['gpus'],'quality_change':p.get('quality_change',False),'experimental':p.get('experimental',False),'command':cmd},ensure_ascii=False,indent=2));return
        if p.get('blocked_reason'):ap.error(p['blocked_reason'])
        if p.get('experimental') and not a.allow_experimental:ap.error('此配置为条件实验；先读模型/硬件限制，再加 --allow-experimental')
        for k in [p['model']]+([p['draft']] if p.get('draft') else []):
            report=inspect_model(model_path(k,cfg),k)
            if not report['files_check_ok']:raise SystemExit(json.dumps(report,ensure_ascii=False,indent=2))
        import subprocess
        visible=subprocess.check_output(['nvidia-smi','--query-gpu=index','--format=csv,noheader'],text=True)
        if not set(p['gpus']).issubset({int(x.strip()) for x in visible.splitlines()}):ap.error('所需 GPU 不存在')
        env=engine_env(cfg,p)
        if p.get('requires_kv_scales') and not Path(args[args.index('--quantization-param-path')+1]).is_file():ap.error('KV scales 文件不存在')
        if p.get('requires_kv_scales'):
            from validate_scales import validate_scale_file
            validate_scale_file(args[args.index('--quantization-param-path')+1],read_json(model_path(p['model'],cfg)/'config.json'),p['tp'])
        role=p.get('role','engine')
    elif a.action=='pd-router':
        role='router';cmd=[str(native_python(cfg)),str(ROOT/'scripts/router_entry.py')]
        if a.dry_run:print(shlex.join(cmd));return
        env=native_environment(cfg)
    else:
        role='gateway';cmd=[str(native_python(cfg)),str(ROOT/'scripts/gateway.py'),'--mode',a.mode];env=native_environment(cfg)
    for key,val in env.items():
        if ('SIMULATE' in key or key in ('SGLANG_SPECULATIVE_EAGLE_SIMULATE_ACC_LEN',)) and val not in ('','0'):
            ap.error('拒绝在功能/性能实验中使用模拟接受率环境变量：'+key)
    register_native(role,getattr(a,'profile',a.action),p['gpus'] if p else [],cmd)
    write_json(ROOT/f'data/runtime/{role}.plan.json',{'command':cmd,'profile':p,'status':'STARTING','note':'命令无密钥；真实就绪由 wait_ready + smoke_test 判定'})
    os.execve(cmd[0],cmd,env)

if __name__=="__main__": main()
