"""Supported-model protocol demo: the only executable tool returns local UTC time."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from common import ROOT, write_json
from client_lib import load_client, request

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',type=Path)
    a=p.parse_args()
    cfg=load_client(a.config)
    messages=[{'role':'user','content':'请实际调用 get_local_time 工具，然后告诉我工具返回的 UTC 时间。'}]
    tools=[{'type':'function','function':{'name':'get_local_time',
        'description':'返回运行客户端的机器当前 UTC 时间，不访问网络。',
        'parameters':{'type':'object','properties':{},'required':[],'additionalProperties':False}}}]
    payload={'model':cfg['model'],'messages':messages,'tools':tools,'tool_choice':'auto',
             'max_tokens':4096,'stream':False}
    with request(cfg,'/chat/completions',payload) as r:
        first=json.load(r)
    message=first['choices'][0]['message']
    calls=message.get('tool_calls') or []
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    path=ROOT/f'data/results/tools/{stamp}.json'
    if not calls:
        write_json(path,{'passed':False,'error':'no_tool_call','response':first})
        raise SystemExit('没有返回 tool_calls，已记录失败。确认当前模型的工具parser已启用（vLLM还需--tools）及输出预算足够。')
    messages.append(message)  # Preserve the model's returned reasoning/protocol fields.
    for call in calls:
        function=call['function']
        if function['name']!='get_local_time' or json.loads(function['arguments'])!={}:
            write_json(path,{'passed':False,'error':'tool_not_allowlisted_or_bad_arguments','response':first})
            raise SystemExit('工具名/参数不在允许范围，未执行。')
        output={'utc_time':datetime.now(timezone.utc).isoformat(),'source':'client_local_clock'}
        messages.append({'role':'tool','tool_call_id':call['id'],'content':json.dumps(output)})
    with request(cfg,'/chat/completions',{**payload,'messages':messages,'tool_choice':'none'}) as r:
        final=json.load(r)
    text=final['choices'][0]['message'].get('content') or ''
    passed=bool(text)
    write_json(path,{'passed':passed,'first':first,'tool_roundtrip_messages':messages,'final':final})
    print(text)
    print('结果:',path)
    if not passed:
        raise SystemExit(2)

if __name__=='__main__':
    main()
