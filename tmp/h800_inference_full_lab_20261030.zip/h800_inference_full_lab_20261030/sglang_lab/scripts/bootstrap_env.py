"""Validate all offline artifacts; build a fresh project-local venv without indexes."""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(8*1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--rebuild', action='store_true', help='只重建本包 environments/sglang0522/.venv，不动模型和数据')
    a = p.parse_args()
    manifest_path = ROOT / 'environments/OFFLINE_MANIFEST.json'
    data = json.loads(manifest_path.read_text())
    if platform.system() != 'Linux' or platform.machine() != data['architecture']:
        raise SystemExit('OS/架构不匹配：不能把 Windows/其他架构的 wheel 用于 H800 Linux 主机')
    if sys.version_info[:2] != (3,12):
        raise SystemExit('本包离线环境固定 CPython 3.12')
    for item in data['files']:
        path = (ROOT / item['path']).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file():
            raise SystemExit('缺少或非法路径: ' + item['path'])
        if path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
            raise SystemExit('文件校验不通过: ' + item['path'])
    expected_wheels={x['path'] for x in data['files'] if x['path'].endswith('.whl')}
    actual_wheels={x.relative_to(ROOT).as_posix() for x in (ROOT/'environments/sglang0522/wheelhouse').glob('*.whl')}
    if expected_wheels!=actual_wheels:
        raise SystemExit('wheelhouse 与 manifest 不完全一致；有新增/缺失 wheel，请重新封装')
    env_dir = ROOT / 'environments/sglang0522/.venv'
    python = env_dir / 'bin/python3'
    if env_dir.exists() and not a.rebuild:
        print('独立环境已存在。若项目移动过或需要重建，执行 bash scripts/bootstrap_offline.sh --rebuild')
        print('仍将验证 pip 依赖和安装版本。')
    else:
        subprocess.run([sys.executable, '-m', 'venv', '--clear', str(env_dir)], check=True)
        env = dict(os.environ, PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1', PIP_CONFIG_FILE=os.devnull)
        subprocess.run([str(python), '-m', 'pip', 'install', '--no-cache-dir', '--no-index', '--only-binary=:all:',
                        '--pre', '--find-links', str(ROOT / 'environments/sglang0522/wheelhouse'),
                        '-r', str(ROOT / 'environments/sglang0522/requirements.lock')], env=env, check=True)
    subprocess.run([str(python), '-m', 'pip', 'check'], check=True)
    actual = json.loads(subprocess.check_output([str(python), '-c',
        'import importlib.metadata as m,json; print(json.dumps({k:m.version(k) for k in ("sglang","torch","sglang-router","nixl-cu13")}))'], text=True))
    for name,expected in {'sglang':'0.5.22','torch':'2.14.1','sglang-router':'0.3.2','nixl-cu13':'1.5.0'}.items():
        if actual[name].split('+')[0]!=expected:raise SystemExit('安装版本不匹配: '+str(actual))
    freeze = subprocess.check_output([str(python), '-m', 'pip', 'freeze'], text=True)
    (ROOT / 'environments/sglang0522/installed.freeze.txt').write_text(freeze)
    print('项目内环境已安装并检查:', env_dir)
    print('source environments/sglang0522/.venv/bin/activate')
    print('下一步运行 02 中的真实 CUDA/NCCL 探针。')

if __name__ == '__main__':
    main()
