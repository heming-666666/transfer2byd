"""Compare prompt instruction, JSON object mode and schema-constrained decoding."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from common import ROOT, read_json, write_json
from client_lib import load_client, chat_once

def validate_answer(value):
    return (isinstance(value, dict) and set(value) == {"answer", "topic"}
            and isinstance(value["answer"], str) and value["topic"] in ["infra", "other"])

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path)
    p.add_argument("--mode", choices=["prompt", "json_object", "json_schema"], default="json_schema")
    p.add_argument("--max-tokens", type=int, default=4096)
    a = p.parse_args()
    schema = read_json(ROOT / "config/answer.schema.json")
    extra = {}
    if a.mode == "json_object":
        extra["response_format"] = {"type": "json_object"}
    if a.mode == "json_schema":
        extra["response_format"] = {"type": "json_schema", "json_schema": {
            "name": "infra_answer", "strict": True, "schema": schema}}
    result = chat_once(load_client(a.config), [{"role": "user", "content":
        '请解释 KV Cache，只返回 JSON 对象，恰有 answer 字符串和 topic 字段；topic 只能是 infra 或 other。'}],
        max_tokens=a.max_tokens, stream=False, extra=extra)
    try:
        parsed = json.loads(result["content"])
        valid, parse_error = validate_answer(parsed), None
    except ValueError as exc:
        parsed, valid, parse_error = None, False, str(exc)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
    out = ROOT / f"data/results/structured/{stamp}_{a.mode}.json"
    report = {"mode": a.mode, "schema_valid": valid, "parse_error": parse_error,
              "parsed": parsed, "result": result,
              "note": "格式正确不代表回答事实正确。该校验器只针对本例的两字段 schema。"}
    write_json(out, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("结果:", out)
    if not valid or result["finish_reason"] == "length":
        raise SystemExit(2)

if __name__ == "__main__":
    main()
