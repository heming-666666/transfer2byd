"""Optional network download. Manual/offline placement is documented in 04_MODEL_FILES.md."""
import argparse
import os
from common import ROOT, settings, models, absolute, native_python, model_path

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--model", choices=list(models()), required=True)
    p.add_argument("--revision", required=True, help="完整 HF commit SHA；在网页 Files and versions 的提交处复制")
    a = p.parse_args()
    if len(a.revision) != 40 or any(c not in "0123456789abcdef" for c in a.revision.lower()):
        p.error("revision 应为完整 40 位 commit SHA")
    cfg = settings()
    meta = models()[a.model]
    script = 'from huggingface_hub import snapshot_download; import sys,json; from pathlib import Path; snapshot_download(repo_id=sys.argv[1], revision=sys.argv[2], local_dir=sys.argv[3]); (Path(sys.argv[3])/"MODEL_REVISION.json").write_text(json.dumps({"repo_id":sys.argv[1],"revision":sys.argv[2]},indent=2)+"\\n")'
    cmd = ["docker", "run", "--rm", "--network", "host",
           "--mount", f"type=bind,src={absolute(cfg['model_root'])},dst=/models",
           "--entrypoint", "python3", cfg["docker_image"], "-c", script,
           meta["repo_id"], a.revision, "/models/" + meta["directory"]]
    if cfg.get("runtime", "native") == "native":
        cmd = [str(native_python(cfg)), "-c", script, meta["repo_id"], a.revision,
               str(model_path(a.model, cfg))]
    print(f"将下载约 {meta['estimated_download_gb']} GB 到 {absolute(cfg['model_root']) / meta['directory']}", flush=True)
    print("只有当前环境允许终端下载时才执行；模型下载不需要 GPU。", flush=True)
    os.execvp(cmd[0], cmd)

if __name__ == "__main__":
    main()
