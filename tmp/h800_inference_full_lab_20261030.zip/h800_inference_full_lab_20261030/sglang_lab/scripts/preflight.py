"""Read-only hardware/network inventory. Does not change drivers or firewall."""
import argparse
import json
import platform
import shutil
import subprocess
import sys
import resource
from datetime import datetime, timezone
from pathlib import Path
from common import ROOT

def run(cmd):
    try:
        r = subprocess.run(cmd, text=True, capture_output=True, timeout=25)
        return {"command": cmd, "returncode": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"command": cmd, "error": str(exc)}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", default=str(ROOT / "data/reports/preflight.json"))
    a = p.parse_args()
    cmds = [["nvidia-smi", "--query-gpu=index,name,uuid,memory.total,driver_version", "--format=csv"],
            ["nvidia-smi", "topo", "-m"], ["free", "-h"], ["df", "-h", str(ROOT)],
            ["ip", "-br", "addr"], ["ip", "route"], ["ss", "-ltn"],
            ["ldd", "--version"], ["uname", "-m"],
            ["docker", "version"], ["docker", "info", "--format", "{{json .Runtimes}}"]]
    result = {"time_utc": datetime.now(timezone.utc).isoformat(), "python": sys.version,
              "platform": platform.platform(), "checks": [run(c) for c in cmds],
              "status": "INVENTORY_ONLY: 按文档人工确认 GPU/显存/驱动/拓扑/路由；本脚本不宣告 GPU 验收通过。"}
    result["memlock_limit_bytes"] = resource.getrlimit(resource.RLIMIT_MEMLOCK)
    result["cgroup_memory"] = {}
    for name in ["/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.current",
                 "/sys/fs/cgroup/memory/memory.limit_in_bytes"]:
        try:
            result["cgroup_memory"][name] = Path(name).read_text().strip()
        except OSError:
            pass
    path = Path(a.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for row in result["checks"]:
        print(" ".join(row["command"]))
        print((row.get("stdout") or row.get("stderr") or row.get("error", "")).strip())
    print("已保存:", path)

if __name__ == "__main__":
    main()
