"""HTTP and SSE helpers, shared by chat and verification clients."""
import json
import time
import urllib.error
import urllib.request
from pathlib import Path
from common import ROOT, read_json

def load_client(path=None):
    cfg = read_json(path or ROOT / "config/client.json")
    if "SET_SERVER_LAN_IP" in cfg["base_url"]:
        raise SystemExit("先配置 LAN IP：python3 scripts/configure.py --lan-ip <服务器内网IP>")
    return cfg

def request(cfg, path, data=None, key=None, timeout=600):
    headers = {"Authorization": "Bearer " + (cfg["api_key"] if key is None else key)}
    body = None
    if data is not None:
        body = json.dumps(data, ensure_ascii=False).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(cfg["base_url"].rstrip("/") + path, body, headers=headers)
    try:
        return urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        detail = exc.read(8192).decode(errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {detail}") from exc

def chat_once(cfg, messages, max_tokens=2048, stream=True, temperature=0.6,
              extra=None, on_content=None, on_reasoning=None):
    payload = {"model": cfg["model"], "messages": messages, "max_tokens": max_tokens,
               "temperature": temperature, "stream": stream}
    if stream:
        payload["stream_options"] = {"include_usage": True}
    payload.update(extra or {})
    t0 = time.perf_counter()
    content, reasoning, usage = [], [], None
    finish, first_any, first_content, done = None, None, None, False
    text_delta_times = []
    with request(cfg, "/chat/completions", payload) as resp:
        request_id = resp.headers.get("X-Request-Id")
        if not stream:
            result = json.load(resp)
            choice = result["choices"][0]
            msg = choice["message"]
            content = [msg.get("content") or ""]
            reasoning = [msg.get("reasoning") or msg.get("reasoning_content") or ""]
            finish, usage, done = choice.get("finish_reason"), result.get("usage"), True
        else:
            for line in resp:
                text = line.decode("utf-8").strip()
                if not text.startswith("data:"):
                    continue
                event = text[5:].strip()
                if event == "[DONE]":
                    done = True
                    break
                result = json.loads(event)
                if "error" in result:
                    raise RuntimeError(str(result["error"]))
                usage = result.get("usage") or usage
                for choice in result.get("choices", []):
                    delta = choice.get("delta", {})
                    c = delta.get("content") or ""
                    r = delta.get("reasoning") or delta.get("reasoning_content") or ""
                    now = (time.perf_counter() - t0) * 1000
                    if c or r:
                        text_delta_times.append(now)
                    if (c or r) and first_any is None:
                        first_any = now
                    if c:
                        if first_content is None:
                            first_content = now
                        content.append(c)
                        if on_content:
                            on_content(c)
                    if r:
                        reasoning.append(r)
                        if on_reasoning:
                            on_reasoning(r)
                    finish = choice.get("finish_reason") or finish
    if not done:
        raise RuntimeError("SSE 未收到 [DONE]，不能把截断连接当作完整回答")
    return {"content": "".join(content), "reasoning": "".join(reasoning),
            "finish_reason": finish, "usage": usage, "request_id": request_id,
            "metrics": {"e2e_ms": round((time.perf_counter() - t0) * 1000, 3),
                        "first_text_delta_ms": first_any, "first_content_delta_ms": first_content,
                        "last_text_delta_ms": text_delta_times[-1] if text_delta_times else None,
                        "text_delta_times_ms": text_delta_times,
                        "note": "SSE delta 延迟不是严格的逐 token ITL；推理正文首字也可能晚于推理首字。"}}
