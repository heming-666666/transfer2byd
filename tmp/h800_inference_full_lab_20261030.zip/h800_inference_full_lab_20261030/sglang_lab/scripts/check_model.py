"""File/shard preflight only; GPU load and output correctness are separate gates."""
import argparse,json
from pathlib import Path
from common import models,model_path

def inspect_model(path,key):
    p=Path(path);errors=[];warnings=[];files=[]
    if not (p/'config.json').is_file():errors.append('缺少 config.json')
    index=p/'model.safetensors.index.json'
    if index.is_file():
        try:files=[p/x for x in set(json.loads(index.read_text())['weight_map'].values())]
        except (ValueError,KeyError):errors.append('分片索引无效')
    else:files=list(p.glob('*.safetensors'))+list(p.glob('pytorch_model*.bin'))
    if not files:errors.append('缺少权重或分片索引')
    total=0
    for f in files:
        if not f.is_file():errors.append('缺少 shard '+f.name)
        elif f.stat().st_size<1024:errors.append('权重过小，可能是 Git LFS 指针 '+f.name)
        else:total+=f.stat().st_size
    if key not in ('eagle3_draft','dflash_draft'):
        for name in ['tokenizer_config.json','tokenizer.json']:
            if not (p/name).is_file():errors.append('缺少 '+name)
    if key in ('latest','modern') and not (p/'encoding/encoding.py').is_file():warnings.append('检查模型官方 tokenizer 的 encoding/ 是否需要完整保留')
    if list(p.rglob('*.incomplete')):warnings.append('存在未完成下载文件')
    return dict(path=str(p),files_check_ok=not errors,checkpoint_bytes=total,checkpoint_GB=round(total/1e9,3),errors=errors,warnings=warnings,
                limitation='仅存在性/明显指针检查，不代替校验和、显存容量、架构和 CUDA 验收')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--model',choices=list(models()),required=True);ap.add_argument('--path',type=Path)
    a=ap.parse_args();r=inspect_model(a.path or model_path(a.model),a.model);print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0 if r['files_check_ok'] else 2)
if __name__=='__main__':main()
