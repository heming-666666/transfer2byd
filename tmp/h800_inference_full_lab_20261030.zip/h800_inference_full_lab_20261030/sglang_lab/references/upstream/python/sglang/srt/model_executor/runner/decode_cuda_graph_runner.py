# Copyright 2023-2026 SGLang Team
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""DecodeCudaGraphRunner — runs DECODE / TARGET_VERIFY / DLLM_EXTEND under
a pluggable backend.

Backend selection comes from cuda_graph_config.decode:
  - "full"      — default, FullCudaGraphBackend: one
                      torch.cuda.CUDAGraph per shape.
  - "breakable" — experimental, BreakableCudaGraphBackend:
                      segmented capture (no torch.compile).
  - "tc_piecewise"     — not implemented for decode; logs a one-shot warning
                      and falls back to "full".
"""

from __future__ import annotations

import contextlib
import dataclasses
import inspect
import logging
import os
from types import SimpleNamespace
from typing import TYPE_CHECKING, Callable, Optional, Union, cast

import torch
import tqdm
from torch.profiler import ProfilerActivity, profile

from sglang.srt.compilation import torch_compile_decoration
from sglang.srt.compilation.torch_compile_decoration import set_torch_compile_config
from sglang.srt.distributed.parallel_state import graph_capture
from sglang.srt.dllm.config import DllmConfig
from sglang.srt.environ import envs
from sglang.srt.layers.attention.base_attn_backend import (
    AttentionBackend,
    SharedReadEnds,
)
from sglang.srt.layers.attention.dsa.utils import is_dsa_enable_prefill_cp
from sglang.srt.layers.attention.graph_variants import (
    AttentionGraphVariants,
    create_attention_graph_variants,
    create_dsv41_candidate_graph_variants,
)
from sglang.srt.layers.cp.utils import is_mla_cp_enabled
from sglang.srt.layers.dp_attention import (
    DpPaddingMode,
    set_dp_buffer_len,
    set_is_extend_in_batch,
)
from sglang.srt.layers.logits_processor import LogitsProcessorOutput
from sglang.srt.model_executor.cuda_graph_buffer_registry import (
    CudaGraphBufferRegistry,
    GraphSlot,
    PaddingPolicy,
    build_decode_registry,
)
from sglang.srt.model_executor.forward_batch_info import (
    CaptureHiddenMode,
    ForwardBatch,
    ForwardMode,
    PPProxyTensors,
    _dp_tp_moe_masks_pad_rows,
    compute_local_num_token_non_padded,
    enable_num_token_non_padded,
    get_required_capture_hidden_mode,
)
from sglang.srt.model_executor.forward_context import ForwardContext, forward_context
from sglang.srt.model_executor.runner.base_cuda_graph_runner import (
    BaseCudaGraphRunner,
    freeze_gc,
    get_batch_sizes_to_capture,
)
from sglang.srt.model_executor.runner.flashinfer_autotune import (
    maybe_flashinfer_autotune_speculative_draft,
)
from sglang.srt.model_executor.runner.metadata_glue_graph import MetadataGlueGraph
from sglang.srt.model_executor.runner.shape_key import ShapeKey
from sglang.srt.model_executor.runner_backend.breakable_cuda_graph_backend import (
    BreakableCudaGraphBackend,
)
from sglang.srt.model_executor.runner_backend.utils import resolve_decode_backend
from sglang.srt.model_executor.runner_backend_utils import CUDA_GRAPH_CAPTURE_FAILED_MSG
from sglang.srt.model_executor.runner_utils.buffers import DecodeInputBuffers
from sglang.srt.model_executor.runner_utils.capture_mode import (
    _set_capture_attention_variant,
    _set_capture_lora_variant,
    model_capture_mode,
)
from sglang.srt.model_executor.runner_utils.deepep_adapter import (
    DeepEPCudaGraphRunnerAdapter,
)
from sglang.srt.model_executor.runner_utils.pool import (
    get_or_create_global_graph_capture_stream,
)
from sglang.srt.model_executor.runner_utils.shared_read_event import make_external_event
from sglang.srt.multiplex.pdmux_context import get_current_stream_idx, get_stream_groups
from sglang.srt.runtime_context import get_exec, get_flags, get_parallel, get_spec
from sglang.srt.speculative.ragged_verify import resolve_ragged_verify_layout
from sglang.srt.utils import (
    empty_context,
    get_available_gpu_memory,
    require_attn_tp_gather,
    require_mlp_tp_gather,
)
from sglang.srt.utils.device_timer import device_timer_ctx
from sglang.srt.utils.profile_utils import (
    export_cuda_graph_capture_trace,
    graph_capture_profile_dir,
)

try:
    from kt_kernel import KTMoEWrapper

    KTRANSFORMERS_AVAILABLE = True
except ImportError:
    KTRANSFORMERS_AVAILABLE = False

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from sglang.srt.model_executor.model_runner import ModelRunner
    from sglang.srt.speculative.spec_info import SpeculativeAlgorithm


def ragged_verify_compact_graphs_enabled(spec_algorithm: SpeculativeAlgorithm) -> bool:
    if not spec_algorithm.supports_ragged_verify():
        return False
    from sglang.srt.speculative.ragged_verify import ragged_verify_compact_enabled

    return ragged_verify_compact_enabled()


def build_replay_fb_view(
    forward_batch: ForwardBatch,
    buffers: DecodeInputBuffers,
    bs: int,
    raw_bs: int,
    num_tokens: int,
    global_num_tokens_cpu: Optional[list[int]],
    seq_len_fill_value: int,
    capture_forward_mode: ForwardMode,
    is_encoder_decoder: bool,
) -> SimpleNamespace:
    """Construct a ForwardBatch-like view for backend replay-side init.

    Combines the original forward_batch (for unpadded / per-iter
    fields like spec_info, out_cache_loc, and the runtime
    actual_forward_mode) with the padded capture-time buffers from
    buffers (for req_pool_indices, seq_lens, seq_lens_cpu,
    positions, encoder_lens).

    forward_mode is the capture-time mode (used by backends for
    bucket / dispatch decisions); actual_forward_mode is the
    runtime mode (may be IDLE while the captured graph targets DECODE
    — DSV4's replay metadata prep uses this for IDLE substitution).

    Subsumes the _replay_forward_batch side channel that DSV4 used to
    read out-of-band before the init_forward_metadata 3-method ABC.
    """
    return SimpleNamespace(
        batch_size=bs,
        forward_mode=capture_forward_mode,
        actual_forward_mode=forward_batch.forward_mode,
        input_ids=buffers.input_ids[:num_tokens],
        positions=buffers.positions[:num_tokens],
        req_pool_indices=buffers.req_pool_indices[:bs],
        seq_lens=buffers.seq_lens[:bs],
        seq_lens_sum=(
            None
            if forward_batch.seq_lens_sum is None
            else forward_batch.seq_lens_sum + (bs - raw_bs) * seq_len_fill_value
        ),
        # Propagate mirror absence: the pinned buffer is not refreshed when the
        # batch has no CPU mirror; a stale non-None tensor defeats None-guards.
        seq_lens_cpu=(
            None if forward_batch.seq_lens_cpu is None else buffers.seq_lens_cpu[:bs]
        ),
        num_padding=bs - raw_bs,
        encoder_lens=buffers.encoder_lens[:bs] if is_encoder_decoder else None,
        out_cache_loc=getattr(forward_batch, "out_cache_loc", None),
        out_cache_loc_virtual=forward_batch.out_cache_loc_virtual,
        kv_loc_plan=forward_batch.kv_loc_plan,
        kv_loc_cols=forward_batch.kv_loc_cols,
        origin_out_cache_loc=getattr(forward_batch, "origin_out_cache_loc", None),
        out_cache_loc_dsv4=getattr(forward_batch, "out_cache_loc_dsv4", None),
        max_seq_len_override=forward_batch.max_seq_len_override,
        # The mamba-track registry slot (VIRTUAL ids) is the v2p translate SOURCE
        # for the backend, which copies the result into its own static buffer and
        # reads THAT in the decode track-save — this slot is never mutated. None
        # when mamba-track is disabled, slice to [:bs] like every other buffer
        mamba_track_indices=(
            None
            if buffers.mamba_track_indices is None
            else buffers.mamba_track_indices[:bs]
        ),
        spec_info=forward_batch.spec_info,
        lora_ids=(
            None
            if forward_batch.lora_ids is None
            else forward_batch.lora_ids + [None] * (bs - len(forward_batch.lora_ids))
        ),
        can_run_decode_cuda_graph=forward_batch.can_run_decode_cuda_graph,
        global_num_tokens_cpu=global_num_tokens_cpu,
        dp_padding_mode=DpPaddingMode.get_default_mode_in_cuda_graph(),
    )


class DecodeCudaGraphRunner(BaseCudaGraphRunner):
    """Decode-phase CUDA graph runner.

    Owns: static input buffers (DecodeInputBuffers), capture-bs list,
    attention backend, two-batch-overlap plugin, DeepEP adapter, and the
    pluggable self.backend that handles the actual capture/replay.
    """

    dllm_input_preparation = None
    dllm_attention = None

    def __init__(
        self,
        model_runner: ModelRunner,
        *,
        attn_backend=None,
        speculative_num_steps: Optional[int] = None,
        speculative_num_draft_tokens: Optional[int] = None,
        record_nolora_graph: bool = False,
    ):
        super().__init__(model_runner)
        self.record_nolora_graph = record_nolora_graph

        # In-graph metadata prep: shared buffers -> in-graph private data
        self.in_graph_metadata_prep_done: Optional[torch.cuda.Event] = None

        # --- core state ------------------------------------------------
        self.enable_torch_compile = get_flags().capture.enable_torch_compile
        self.disable_padding = get_exec().graph.disable_cuda_graph_padding
        self.is_encoder_decoder = model_runner.model_config.is_encoder_decoder
        self.require_mlp_tp_gather, self.require_attn_tp_gather = (
            self.decode_graph_gather_requirements(model_runner)
        )
        # Composite predicates derive from the instance values so the dp-local
        # draft exemption above stays consistent (require_gathered_buffer ==
        # mlp_tp_gather or attn_tp_gather; require_mlp_sync adds dp attention).
        self.require_gathered_buffer = (
            self.require_mlp_tp_gather or self.require_attn_tp_gather
        )
        self.require_mlp_sync = (
            get_parallel().attn_dp_enabled or self.require_gathered_buffer
        )
        self.enable_two_batch_overlap = get_exec().overlap.enable_two_batch_overlap
        self.use_ngram_embedding = model_runner.ngram_embedding_manager.enabled
        self.speculative_algorithm = get_spec().speculative_algorithm
        self.enable_profile_cuda_graph = get_exec().graph.enable_profile_cuda_graph

        # True if the DSA or MLA prefill-CP flavor is active. These flavors
        # feed a zigzag-split rank-local layout into the runner; MHA-arch
        # prefill CP (Qwen3/Qwen2 MoE via PR #18233) keeps an
        # attn_tp-replicated layout and is intentionally excluded so the
        # attn_tp-local num_token_non_padded adjustment still runs for it.
        self.enable_prefill_cp = is_dsa_enable_prefill_cp() or is_mla_cp_enabled()

        self.deepep_adapter = DeepEPCudaGraphRunnerAdapter()

        self.dllm_config = DllmConfig.from_server_args(model_runner.server_args)
        self.is_dllm = self.dllm_config is not None
        self.dllm_input_preparation = None
        if self.is_dllm and self.dllm_config.capture_input_preparation:
            from sglang.srt.dllm.algorithm import get_algorithm_cls

            self.dllm_input_preparation = get_algorithm_cls(
                self.dllm_config.algorithm
            ).prepare_graph_inputs
        self.dllm_uses_input_embeds = (
            self.is_dllm and self.dllm_config.requires_separate_context_encoding
        )
        self.attn_backend = attn_backend or model_runner.attn_backend
        self.speculative_num_steps = (
            get_spec().speculative_num_steps
            if speculative_num_steps is None
            else speculative_num_steps
        )
        self.speculative_num_draft_tokens = (
            get_spec().speculative_num_draft_tokens
            if speculative_num_draft_tokens is None
            else speculative_num_draft_tokens
        )

        # --- capture mode + tokens-per-bs ------------------------------
        self.capture_forward_mode = ForwardMode.DECODE
        self.capture_hidden_mode = self.return_hidden_states_mode
        # Static capture width.
        self.captured_req_width = model_runner.decode_num_tokens_per_req(
            num_draft_tokens=self.speculative_num_draft_tokens
        )
        if model_runner.spec_algorithm.is_speculative():
            if self.model_runner.is_draft_worker:
                # Draft workers can use TARGET_VERIFY mode.
                if not self.model_runner.spec_algorithm.supports_target_verify_for_draft():
                    raise RuntimeError("This should not happen")
            self.capture_forward_mode = ForwardMode.TARGET_VERIFY
        elif self.is_dllm:
            self.capture_forward_mode = ForwardMode.DLLM_EXTEND

        self.dllm_attention = self.attn_backend.dllm_attention
        self.attention_graph_variants: Optional[AttentionGraphVariants] = (
            self.dllm_attention.graph_variants(self.captured_req_width)
            if self.dllm_attention is not None and self.is_dllm
            else create_attention_graph_variants(model_runner.model_config.hf_config)
            or create_dsv41_candidate_graph_variants(
                model_runner, self.capture_forward_mode, self.captured_req_width
            )
        )

        if (
            self.dllm_attention is not None
            and self.attention_graph_variants is not None
        ):
            self._resolve_attention_variant = self.attention_graph_variants.select

        # --- bucket sizes ---------------------------------------------
        self.capture_bs, self.compile_bs = get_batch_sizes_to_capture(
            model_runner,
            self.captured_req_width,
            gathered_buffer_required=self.require_gathered_buffer,
        )
        if self.dllm_uses_input_embeds:
            max_requests = min(
                self.dllm_config.max_running_requests, max(self.capture_bs)
            )
            self.capture_bs = sorted(
                {bs for bs in self.capture_bs if bs <= max_requests} | {max_requests}
            )
            self.compile_bs = [bs for bs in self.compile_bs if bs <= max_requests]
        self.max_bs = max(self.capture_bs)
        if KTRANSFORMERS_AVAILABLE:
            KTMoEWrapper.set_capture_batch_sizes(self.capture_bs)

        self.ragged_verify_mode = (
            ragged_verify_compact_graphs_enabled(self.model_runner.spec_algorithm)
            and (self.capture_forward_mode == ForwardMode.TARGET_VERIFY)
            and not self.model_runner.is_draft_worker
        )
        self.capture_num_tokens: Optional[list[int]] = (
            self._build_ragged_verify_token_buckets()
            if self.ragged_verify_mode
            else None
        )
        self._ragged_graph_size = 0
        # Per-tier capture layouts; their verify_lens / qo_indptr tensors are
        # baked into the captured graphs and refreshed in place each replay.
        self._captured_ragged_layouts: dict[int, object] = {}
        if self.ragged_verify_mode and (
            self.enable_two_batch_overlap
            or model_runner.lora_manager is not None
            or self.disable_padding
        ):
            raise ValueError(
                "Compact ragged verify does not support two-batch-overlap, "
                "LoRA, or disable-cuda-graph-padding (bs pads to the captured "
                "tier); disable SGLANG_RAGGED_VERIFY_MODE or the conflicting "
                "feature."
            )

        # Attention backend
        self.max_num_token = (
            max(self.capture_num_tokens)
            if self.capture_num_tokens is not None
            else self.max_bs * self.captured_req_width
        )
        self.attn_backend.init_cuda_graph_state(self.max_bs, self.max_num_token)

        # Init PDMux if needed
        self.maybe_init_pdmux()
        self.seq_len_fill_value = (
            self.attn_backend.get_cuda_graph_seq_len_fill_value()
            if self.dllm_config is None
            else self.dllm_config.block_size
        )

        # Non-zero encoder length ensures cross-attention kernels are captured in the graph.
        self.encoder_len_fill_value = (
            getattr(model_runner.model_config.hf_config, "max_source_positions", 0)
            if self.is_encoder_decoder
            else 0
        )

        if self.enable_torch_compile:
            set_torch_compile_config()

        if self.model_runner.lora_manager is not None:
            # Phase 2 of LoRA CUDA graph init: dense LoRA batch metadata.
            # Phase 1 (MoE buffers) was handled earlier in ModelRunner via
            # lora_manager.init_cuda_graph_moe_buffers().
            self.model_runner.lora_manager.init_cuda_graph_batch_info(
                max_bs_in_cuda_graph=self.max_bs,
                num_tokens_per_req=self.captured_req_width,
            )

        enable_mamba_track = (
            get_exec().mamba.enable_mamba_extra_buffer
            and self.model_runner.spec_algorithm.is_none()
        )

        if self.require_gathered_buffer:
            assert self.require_mlp_tp_gather or self.require_attn_tp_gather

        # --- buffers ---------------------------------------------------
        logits_buffer_rows = self._next_token_logits_buffer_capacity_rows(
            self.max_num_token
        )
        self.buffers: DecodeInputBuffers = DecodeInputBuffers.create(
            device=self.device,
            max_bs=self.max_bs,
            max_num_token=self.max_num_token,
            hidden_size=self.model_runner.model_config.hidden_size,
            next_token_logits_buffer=self.model_runner.graph_shared_output.get_logits_buffer(
                self.model_runner.model_config.vocab_size, rows=logits_buffer_rows
            ),
            dtype=self.model_runner.model_config.dtype,
            num_dp_ranks=self.num_dp_ranks,
            pp_size=self.pp_size,
            is_encoder_decoder=self.is_encoder_decoder,
            require_mlp_tp_gather=self.require_mlp_tp_gather,
            seq_len_fill_value=self.seq_len_fill_value,
            encoder_len_fill_value=self.encoder_len_fill_value,
            num_tokens_per_req=self.captured_req_width,
            cache_loc_dtype=self._cache_loc_dtype(),
            enable_mamba_track=enable_mamba_track,
            ne_token_table=(
                model_runner.ngram_embedding_manager.table
                if self.use_ngram_embedding
                else None
            ),
            hc_hidden_size=getattr(
                self.model_runner.model_config, "hc_hidden_size", None
            ),
            pp_proxy_topk_size=self.model_runner.get_pp_proxy_topk_size(),
            pp_proxy_residual_num_blocks=(
                self.model_runner.get_pp_proxy_residual_num_blocks()
            ),
            pp_proxy_dspark_hidden_size=(
                self.model_runner.get_pp_proxy_dspark_hidden_size()
            ),
            aux_hidden_states_width=self.model_runner.get_aux_hidden_states_width(),
        )
        self.buffers.share_buffers()
        # FB-shared slot registry adopting DecodeInputBuffers storage (same
        # physical tensors, stable data_ptr for capture vs replay). Provides
        # the unified fill_from / slot access surface for capture/replay.
        self.buffer_registry: CudaGraphBufferRegistry = build_decode_registry(
            device=self.device,
            max_bs=self.max_bs,
            max_num_token=self.max_num_token,
            seq_len_fill_value=self.seq_len_fill_value,
            cache_loc_dtype=self._cache_loc_dtype(),
            enable_mamba_track=enable_mamba_track,
            is_encoder_decoder=self.is_encoder_decoder,
            encoder_len_fill_value=self.encoder_len_fill_value,
            enable_num_token_non_padded=enable_num_token_non_padded(),
            require_gathered_buffer=self.require_gathered_buffer,
            enable_prefill_cp=self.enable_prefill_cp,
            require_mlp_tp_gather=self.require_mlp_tp_gather,
            attn_tp_sharded_fn=self.model_runner.attn_tp_sequence_sharded,
            num_dp_ranks=self.num_dp_ranks,
            source=self.buffers,
        )
        if self.dllm_input_preparation is not None:
            width = self.buffers.input_embeds.shape[-1]
            self.buffer_registry.register_slot(
                GraphSlot(
                    "dllm_input_preparation_state",
                    lambda bs, tokens: (tokens, width),
                    self.buffers.input_embeds.dtype,
                    axis="tokens",
                    padding_policy=PaddingPolicy.ZERO,
                )
            )

        # Captures the per-replay attention-metadata prep into a small CUDA
        # graph; see metadata_glue_graph.py for the correctness contract.
        # Force-off for DFlash-family spec: verify installs host-fed fast
        # plans (sync-free begin_forward that recomputes plan inputs on the
        # host every replay), and capturing one freezes the capture-time
        # plan — drafts go stale and accept length collapses to ~1.
        enable_metadata_glue = envs.SGLANG_ENABLE_METADATA_GLUE_GRAPH.get()
        if enable_metadata_glue and model_runner.spec_algorithm.is_dflash_family():
            logger.warning(
                "SGLANG_ENABLE_METADATA_GLUE_GRAPH is incompatible with "
                "DFlash-family speculative decoding (host-fed fast verify "
                "plans must re-run on the host every replay); disabling the "
                "metadata glue graph."
            )
            enable_metadata_glue = False
        self._metadata_glue = (
            MetadataGlueGraph(self.device) if enable_metadata_glue else None
        )

        # --- backend ---------------------------------------------------
        self.backend = resolve_decode_backend(self)

        # --- capture --------------------------------------------------
        try:
            with model_capture_mode():
                self.capture()
        except RuntimeError as e:
            raise Exception(
                f"Capture cuda graph failed: {e}\n{CUDA_GRAPH_CAPTURE_FAILED_MSG}"
            )

    def _next_token_logits_buffer_capacity_rows(self, max_num_tokens: int) -> int:
        """Rows reserved for the largest shared logits output."""
        return max_num_tokens

    def _record_in_graph_metadata_prep_done(self):
        # Purely a marker at this point in the graph; where the shared reads
        # actually end is the attn backend's call.
        if not self.device_module.is_current_stream_capturing():
            # Warmup shares this body. Breakable capture still plants: it opens
            # segment 1 on context entry and every segment re-arms the node.
            # Routed through device_module so XPU (torch.xpu) is picked up
            # instead of hitting torch.cuda dummy stubs on non-CUDA builds.
            return
        if self.in_graph_metadata_prep_done is None:
            self.in_graph_metadata_prep_done = make_external_event(self.device_module)
        event = self.in_graph_metadata_prep_done
        if event is not None:
            # Stays None without external-event support, so the read-end
            # resolution below never hands out an unrecorded event.
            event.record()

    def _replay_attn_backend(self) -> AttentionBackend:
        # Under pdmux each stream replays on its own group member.
        if self.enable_pdmux:
            return self.model_runner.decode_attn_backend_group[get_current_stream_idx()]
        return self.attn_backend

    def _resolve_shared_read_ends(self, attn_backend, forward_mode) -> SharedReadEnds:
        declared = attn_backend.shared_read_ends(forward_mode)
        if (
            declared is SharedReadEnds.IN_REPLAY
            and self.in_graph_metadata_prep_done is None
        ):
            # no in-graph marker (e.g. HIP): only a post-replay event covers its reads
            return SharedReadEnds.POST_REPLAY
        return declared

    def _publish_read_done(self, in_graph: bool):
        """Hand the scheduler's WAR barrier the event marking this phase's
        shared-buffer reads as done."""
        if in_graph:
            # Reads end at the in-graph marker: wire it through, don't re-record.
            self.model_runner.shared_read_done_event = self.in_graph_metadata_prep_done
        else:
            read_done = self.device_module.Event()
            read_done.record()
            self.model_runner.shared_read_done_event = read_done

    def _build_ragged_verify_token_buckets(self) -> list[int]:
        buckets = sorted({bs * self.captured_req_width for bs in self.capture_bs})
        assert buckets and buckets[0] > 0, f"{buckets=}"
        return buckets

    def _autotune_buffers(self):
        """Reuse these static decode buffers (sized to max_bs) for the warmup
        flashinfer-autotune dummy forward instead of allocating a throwaway set
        — see BaseRunner._autotune_buffers / BaseRunner._dummy_run.

        The dummy forward derives its shape from max_bs and must match these
        buffers exactly; _dummy_run asserts that. Every autotune-reachable
        decode shape (plain decode, spec target-verify) matches. DLLM would not
        (its buffers hold block_size tokens/bs while the dummy run derives 1),
        but DLLM does not use a flashinfer MoE backend, so autotune never runs
        for it and this is never reached there.
        """
        return self.buffers, self.max_bs

    def maybe_init_pdmux(self):
        if self.enable_pdmux:
            self.stream_groups = get_stream_groups()
            for attn_backend in self.model_runner.decode_attn_backend_group:
                attn_backend.init_cuda_graph_state(self.max_bs, self.max_num_token)

    def _cache_loc_dtype(self):
        return torch.int64

    def _make_graph_key(
        self, size, stream_idx=None, variant_label=None, attention_variant=None
    ):
        return ShapeKey(
            size=size,
            stream_idx=stream_idx,
            variant_label=variant_label,
            attention_variant=attention_variant,
        )

    def _capture_graph_size(self, *, bs: int, num_tokens: int) -> int:
        return num_tokens if self.ragged_verify_mode else bs

    def _global_num_tokens_for_graph(self, num_tokens: int) -> Optional[list[int]]:
        if self.require_mlp_tp_gather:
            return [num_tokens] * self.num_dp_ranks
        if self.require_attn_tp_gather:
            return [num_tokens]
        return None

    def _resolve_attention_variant(
        self, forward_batch: ForwardBatch, capture_batch_size: int
    ) -> Optional[str]:
        variants = self.attention_graph_variants
        if variants is None:
            return None
        return variants.select(forward_batch)

    def _resolve_lora_variant(self, forward_batch: ForwardBatch):
        if not self.record_nolora_graph:
            return None
        if forward_batch.lora_ids is not None and any(
            uid is not None for uid in forward_batch.lora_ids
        ):
            return "lora"
        return "nolora"

    @classmethod
    def decode_graph_gather_requirements(cls, model_runner) -> tuple[bool, bool]:
        """(mlp_tp_gather, attn_tp_gather) needed by this runner's decode graphs.

        Startup sizing (logits rows, reduction workspaces) asks the runner class
        so it aligns capture buckets exactly as the runner itself will."""
        return (
            require_mlp_tp_gather() and not cls._forward_is_dp_local(model_runner),
            require_attn_tp_gather(),
        )

    @staticmethod
    def _forward_is_dp_local(model_runner) -> bool:
        """The DSpark dense draft runs attn-TP-local (draft_tp_context): each
        DP rank drafts independently with no cross-DP collective, so its
        hand-built batches carry no dp-global metadata and must key graphs by
        local batch size. Everything else keeps the dp-global padding path."""
        if not model_runner.is_draft_worker:
            return False
        if not model_runner.spec_algorithm.is_dspark():
            return False
        from sglang.srt.speculative.dspark_components.dspark_config import (
            draft_is_deepseek_v4,
        )

        return not draft_is_deepseek_v4()

    def _ragged_capture_slots(self, num_tokens: int) -> int:
        if envs.SGLANG_TEST_RAGGED_VERIFY_FORCE_UNIFORM_CAPTURE.get():
            return num_tokens // self.captured_req_width
        return min(num_tokens, self.max_bs)

    def _capture_ragged_verify_layout(self, num_tokens: int):
        if not self.ragged_verify_mode:
            return None
        if envs.SGLANG_TEST_RAGGED_VERIFY_FORCE_UNIFORM_CAPTURE.get():
            return None
        layout = self._captured_ragged_layouts.get(num_tokens)
        if layout is not None:
            return layout
        from sglang.srt.speculative.ragged_verify import (
            RaggedVerifyLayout,
            build_capture_verify_lens,
        )

        verify_lens_cpu = build_capture_verify_lens(
            num_tokens=num_tokens,
            num_slots=self._ragged_capture_slots(num_tokens),
            num_draft_tokens=self.captured_req_width,
        )
        layout = RaggedVerifyLayout.from_verify_lens(
            verify_lens_cpu=verify_lens_cpu,
            device=self.device,
            grid=self.capture_num_tokens,
        )
        self._captured_ragged_layouts[num_tokens] = layout
        return layout

    def _stage_ragged_verify_layout(self, ragged_layout, graph_size_key: int) -> None:
        # Without this refresh every replay reuses the capture-time synthetic
        # verify_lens / qo_indptr and mis-slices the packed q rows.
        cap_layout = self._captured_ragged_layouts.get(graph_size_key)
        if cap_layout is None:
            return
        live = ragged_layout
        if live.bs != cap_layout.bs or live.cap is None:
            live = live.padded_to_bucket(
                padded_bs=cap_layout.bs, cap=self.captured_req_width
            )
        cap_layout.verify_lens.copy_(live.verify_lens)
        cap_layout.qo_indptr_device.copy_(live.qo_indptr_device)

    @staticmethod
    def _max_dp_batch_size(forward_batch: ForwardBatch) -> int:
        request_counts = forward_batch.original_global_num_tokens_cpu
        if request_counts is None:
            raise RuntimeError(
                "DP CUDA graph replay requires raw per-rank request counts"
            )
        return max(request_counts)

    def can_run_graph(self, forward_batch: ForwardBatch):
        # Disable for token embedding overrides (dynamic per-request)
        if forward_batch.replace_embeds is not None:
            return False

        ragged_layout = (
            resolve_ragged_verify_layout(forward_batch)
            if self.ragged_verify_mode
            else None
        )
        if ragged_layout is not None:
            return self._can_run_ragged_verify_graph(forward_batch, ragged_layout)
        if self.ragged_verify_mode and forward_batch.forward_mode.is_target_verify():
            return False

        # Uniform-width replay invariant: the batch's actual per-request width
        # must match this runner's capture width; anything else falls back to
        # eager. (Unset widths pass: not every path fills the field yet.)
        spec_info = forward_batch.spec_info
        if (
            spec_info is not None
            and spec_info.num_tokens_per_req > 0
            and spec_info.num_tokens_per_req != self.captured_req_width
        ):
            return False

        if self.require_mlp_tp_gather:
            cuda_graph_bs = self._max_dp_batch_size(forward_batch)
        else:
            cuda_graph_bs = forward_batch.batch_size

        graph_key = self._make_graph_key(
            cuda_graph_bs,
            stream_idx=get_current_stream_idx() if self.enable_pdmux else None,
            variant_label=self._resolve_lora_variant(forward_batch),
            attention_variant=(
                self._resolve_attention_variant(forward_batch, cuda_graph_bs)
                if self.disable_padding
                else None
            ),
        )

        is_bs_supported = (
            self.backend.can_run(forward_batch, graph_key)
            if self.disable_padding
            else cuda_graph_bs <= self.max_bs
        )

        if self.require_mlp_sync:
            is_bs_supported = (
                is_bs_supported and forward_batch.can_run_decode_cuda_graph
            )

        # NOTE: cuda graph cannot handle mixed batch (encoder_len = 0)
        # If mixed batch cannot be supported, then encoder_lens can be removed in cuda graph
        # because the full_text_row_masked_out_mask tensor will always be ones
        is_encoder_lens_supported = (
            torch.all(forward_batch.encoder_lens > 0)
            if self.is_encoder_decoder
            else True
        )

        is_tbo_supported = (
            forward_batch.can_run_tbo if self.enable_two_batch_overlap else True
        )

        is_ngram_supported = (
            (
                forward_batch.batch_size * self.captured_req_width
                == forward_batch.input_ids.numel()
            )
            if self.model_runner.spec_algorithm.is_ngram()
            else True
        )

        return (
            is_bs_supported
            and is_encoder_lens_supported
            and is_tbo_supported
            and is_ngram_supported
        )

    def _can_run_ragged_verify_graph(self, forward_batch: ForwardBatch, ragged_layout):
        if not self.attn_backend.supports_ragged_verify_graph:
            return False

        admission_tokens = ragged_layout.graph_num_tokens
        is_tokens_supported = admission_tokens <= self.capture_num_tokens[
            -1
        ] and forward_batch.batch_size <= self._ragged_capture_slots(admission_tokens)

        is_dp_supported = (
            forward_batch.can_run_decode_cuda_graph if self.require_mlp_sync else True
        )

        is_encoder_lens_supported = (
            torch.all(forward_batch.encoder_lens > 0)
            if self.is_encoder_decoder
            else True
        )

        capture_hidden_mode_matches = (
            forward_batch.capture_hidden_mode <= self.capture_hidden_mode
        )

        return (
            is_tokens_supported
            and is_dp_supported
            and is_encoder_lens_supported
            and capture_hidden_mode_matches
        )

    def _graph_batch_capture_active(self) -> bool:
        """Whether the per-batch-size capture-trace feature is active.

        Gated by SGLANG_GRAPH_BATCH_CAPTURE. The original single-trace export
        (SGLANG_ENABLE_CUDA_GRAPH_CAPTURE_TRACE) takes precedence: when both are
        set we fall back to the original behavior.
        """
        return (
            envs.SGLANG_GRAPH_BATCH_CAPTURE.get()
            and not envs.SGLANG_ENABLE_CUDA_GRAPH_CAPTURE_TRACE.get()
        )

    def _set_profile_trace_tag(
        self,
        bs: int,
        stream_idx: Optional[int],
        variant_label: Optional[str],
        attention_variant: Optional[str],
    ) -> None:
        """Name the trace for one capture. bs alone is not unique: the capture
        loop multiplies it by the lora and attention variants (DSA captures
        dense + sparse per bs). Absent variants are omitted so single-variant
        runners keep the historical `bs_<n>` stem.
        """
        if getattr(self, "_profiler", None) is None:
            return
        parts = [f"bs_{bs}"]
        if attention_variant is not None:
            parts.append(attention_variant)
        if variant_label is not None:
            parts.append(variant_label)
        if stream_idx is not None:
            parts.append(f"stream_{stream_idx}")
        self._profile_trace_tag = "_".join(parts)

    def _profile_runner_name(self) -> str:
        """Runner name used in capture-trace filenames. DSPARK / DFLASH draft
        workers capture their verify graphs with this base class too, at the
        same shapes as the target, so the name alone would collide; prefix it.
        Draft-specific subclasses (EAGLEDraft*, Uno*, ...) are already unique.
        """
        name = type(self).__name__
        if type(self) is DecodeCudaGraphRunner and self.model_runner.is_draft_worker:
            return f"Draft{name}"
        return name

    def _init_profile_context_and_memory_record(self):
        if self._graph_batch_capture_active():
            # SGLANG_GRAPH_BATCH_CAPTURE: the profiler is stepped once per
            # captured shape (see FullCudaGraphBackend.capture_one), so
            # on_trace_ready writes one chrome trace per shape.
            rank = get_parallel().tp_rank
            runner_name = self._profile_runner_name()
            trace_dir = graph_capture_profile_dir()
            os.makedirs(trace_dir, exist_ok=True)

            self._profile_trace_tag = None

            def on_trace_ready(prof):
                tag = self._profile_trace_tag
                if tag is None:
                    # Reachable only if a subclass overrides _capture_one_stream
                    # without tagging; exporting would collide every flush on
                    # one name.
                    logger.warning(
                        "%s: capture trace flushed with no shape tag; skipping "
                        "export. A subclass likely overrides _capture_one_stream "
                        "without calling _set_profile_trace_tag.",
                        runner_name,
                    )
                    return
                trace_file = os.path.join(
                    trace_dir, f"{runner_name}_{tag}_rank{rank}.json.gz"
                )
                prof.export_chrome_trace(trace_file)
                logger.info(f"Saved trace for {tag} to {trace_file}")

            profile_context = profile(
                activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
                # Schedule: wait=2 (skip 2 dummy runs), warmup=0, active=1
                # (capture run); repeat=0 repeats the cycle so each captured
                # shape gets its own trace.
                schedule=torch.profiler.schedule(wait=2, warmup=0, active=1, repeat=0),
                record_shapes=True,
                with_stack=True,
                with_flops=True,
                profile_memory=True,
                on_trace_ready=on_trace_ready,
            )
        else:
            # a single unscheduled pass over the whole
            # capture. The combined trace (if any) is exported in
            # _post_process_after_profile via export_cuda_graph_capture_trace,
            # gated by SGLANG_ENABLE_CUDA_GRAPH_CAPTURE_TRACE.
            profile_context = profile(
                activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
                record_shapes=True,
            )
        torch.cuda.memory._record_memory_history()
        return profile_context

    def _post_process_after_profile(self, prof_context):
        torch.cuda.memory._dump_snapshot("cuda_graph_runner_memory_usage.pickle")
        torch.cuda.memory._record_memory_history(enabled=None)
        log_message = (
            "Sorted by CUDA Time:\n"
            + prof_context.key_averages(group_by_input_shape=True).table(
                sort_by="cuda_time_total", row_limit=10
            )
            + "\n\nSorted by CPU Time:\n"
            + prof_context.key_averages(group_by_input_shape=True).table(
                sort_by="cpu_time_total", row_limit=10
            )
            + "\n\nMemory Usage is saved to cuda_graph_runner_memory_usage.pickle\n"
        )
        logger.info(log_message)

        # single-trace export for the whole capture pass; no-op unless
        # SGLANG_ENABLE_CUDA_GRAPH_CAPTURE_TRACE is set. In per-bs mode
        # (SGLANG_GRAPH_BATCH_CAPTURE) that env is unset, so this stays a no-op
        # and the per-bs on_trace_ready handles export instead.
        export_cuda_graph_capture_trace(
            prof_context,
            runner_name=self._profile_runner_name(),
        )

    def capture_prepare(
        self,
        size: int,
        stream_idx: Optional[int] = None,
        num_tokens: Optional[int] = None,
    ):
        """Build the dummy decode ForwardBatch for capture at size (=bs),
        populate static input buffers, choose the active attn backend, and
        optionally build pp_proxy_tensors.

        num_tokens defaults to the uniform bs * num_tokens_per_req; ragged
        verify capture passes the decoupled (slots, tier tokens) pair.

        Returns (forward_batch, attn_backend, pp_proxy_tensors);
        pp_proxy_tensors is None unless pp_size > 1.
        """
        bs = size
        buffers: DecodeInputBuffers = self.buffers
        if num_tokens is None:
            num_tokens = bs * self.captured_req_width

        # Registry-owned FB-shared slots come through the registry (which
        # shares physical storage with self.buffers via source=...); the rest
        # still come off buffers directly.
        registry = self.buffer_registry

        def _slot(name):
            return registry.get_slot(name).slice_for(bs, num_tokens)

        input_ids = _slot("input_ids")
        req_pool_indices = _slot("req_pool_indices")
        seq_lens = _slot("seq_lens")
        seq_lens_cpu = _slot("seq_lens_cpu")
        out_cache_loc = _slot("out_cache_loc")
        positions = _slot("positions")
        encoder_lens = (
            _slot("encoder_lens") if registry.has_slot("encoder_lens") else None
        )
        mrope_positions = _slot("mrope_positions")
        next_token_logits_buffer = buffers.next_token_logits_buffer[:num_tokens]
        aux_hidden_states_buffer = (
            buffers.aux_hidden_states[:num_tokens]
            if buffers.aux_hidden_states is not None
            else None
        )
        rids_int = buffers.rids_int[:bs] if buffers.rids_int is not None else None
        bootstrap_room_ids_int = (
            buffers.bootstrap_room_ids_int[:bs]
            if buffers.bootstrap_room_ids_int is not None
            else None
        )

        # Localize the count when this bucket is attn-TP sharded (SP on).
        attn_tp_sharded = self.model_runner.attn_tp_sequence_sharded(num_tokens)
        if buffers.num_token_non_padded is not None:
            buffers.num_token_non_padded[...] = num_tokens
            if not self.enable_prefill_cp and attn_tp_sharded:
                local = compute_local_num_token_non_padded(
                    global_num_token_non_padded=buffers.num_token_non_padded,
                    num_tokens_per_dp=num_tokens,
                    sharded=True,
                )
                buffers.num_token_non_padded.copy_(local)

        pp_proxy_tensors = None
        # pipeline parallelism
        if self.pp_size > 1:
            pp_proxy_tensors = PPProxyTensors(
                {k: v[:num_tokens] for k, v in buffers.pp_proxy_tensors.items()}
            )

        global_num_tokens_cpu = self._global_num_tokens_for_graph(num_tokens)

        if global_num_tokens_cpu is not None:
            global_dp_buffer_len = sum(global_num_tokens_cpu)
            num_tokens_tensor = torch.tensor(
                global_num_tokens_cpu, dtype=torch.int32, device=input_ids.device
            )
            buffers.global_num_tokens_gpu.copy_(num_tokens_tensor)
            buffers.global_num_tokens_for_logprob_gpu.copy_(num_tokens_tensor)
        else:
            global_dp_buffer_len = None

        spec_info = self.get_spec_info(num_tokens)
        self.capture_hidden_mode = get_required_capture_hidden_mode(
            self.capture_hidden_mode,
            spec_info,
        )

        if self.model_runner.lora_manager is not None:
            # It is safe to capture CUDA graph using empty LoRA id, as the LoRA kernels will always be launched whenever
            # `--enable-lora` is set to True (and return immediately if the LoRA id is empty for perf optimization).
            lora_ids = [None] * bs
        else:
            lora_ids = None

        # mamba state tracking (registry-owned when enabled)
        mamba_track_indices = (
            _slot("mamba_track_indices")
            if registry.has_slot("mamba_track_indices")
            else None
        )
        mamba_track_mask = (
            _slot("mamba_track_mask") if registry.has_slot("mamba_track_mask") else None
        )

        if stream_idx is None:
            attn_backend = self.attn_backend
        else:
            assert self.enable_pdmux
            attn_backend = self.model_runner.decode_attn_backend_group[stream_idx]

        forward_batch = ForwardBatch(
            forward_mode=self.capture_forward_mode,
            batch_size=bs,
            input_ids=input_ids,
            req_pool_indices=req_pool_indices,
            seq_lens=seq_lens,
            seq_lens_cpu=seq_lens_cpu,
            next_token_logits_buffer=next_token_logits_buffer,
            aux_hidden_states_buffer=aux_hidden_states_buffer,
            orig_seq_lens=seq_lens,
            out_cache_loc=out_cache_loc,
            seq_lens_sum=seq_lens.sum().item(),
            mamba_track_indices=mamba_track_indices,
            mamba_track_mask=mamba_track_mask,
            mamba_track_seqlens=None,
            encoder_lens=encoder_lens,
            return_logprob=False,
            positions=positions,
            global_num_tokens_gpu=buffers.global_num_tokens_gpu,
            global_num_tokens_for_logprob_gpu=buffers.global_num_tokens_for_logprob_gpu,
            dp_padding_mode=DpPaddingMode.get_default_mode_in_cuda_graph(),
            global_dp_buffer_len=global_dp_buffer_len,
            global_num_tokens_cpu=global_num_tokens_cpu,
            can_run_decode_cuda_graph=True,
            mrope_positions=mrope_positions,
            spec_algorithm=self.model_runner.spec_algorithm,
            spec_info=spec_info,
            capture_hidden_mode=self.capture_hidden_mode,
            # Maintained only under expert parallelism; None elsewhere so routing
            # does not mask every row against a never-filled zero count.
            num_token_non_padded=(
                buffers.num_token_non_padded if enable_num_token_non_padded() else None
            ),
            attn_tp_sequence_sharded=attn_tp_sharded,
            global_forward_mode=self.capture_forward_mode,
            lora_ids=lora_ids,
            rids_int=rids_int,
            bootstrap_room_ids_int=bootstrap_room_ids_int,
        )
        self.model_runner.kv_index_translator.bind_runner_slots(forward_batch)

        # Trip the coordinator so the hisparse code path is captured into the
        # graph; backends read it from self.model_runner.hisparse_coordinator.
        forward_batch.hisparse_coordinator = self.model_runner.hisparse_coordinator
        if forward_batch.hisparse_coordinator is not None:
            forward_batch.hisparse_coordinator.num_real_reqs.fill_(bs)

        if buffers.ngram_embedding_info is not None:
            forward_batch.ngram_embedding_info = buffers.ngram_embedding_info.slice(bs)

        return forward_batch, attn_backend, pp_proxy_tensors

    def capture(self) -> None:
        # Warm up + autotune kernels once before capture (run-once across the
        # decode + prefill runners; see BaseRunner.warmup).
        self.warmup()
        # warmup() may disable torch.compile for a model whose _can_torch_compile
        # is False; recompute the compile bucket so capture matches.
        if self.enable_torch_compile and not (get_flags().capture.enable_torch_compile):
            self.enable_torch_compile = False
            _, self.compile_bs = get_batch_sizes_to_capture(
                self.model_runner,
                self.captured_req_width,
                gathered_buffer_required=self.require_gathered_buffer,
            )
        profile_context = empty_context()
        # Holds the active torch profiler during capture so the backend can
        # advance its schedule (profiler.step()) per batch size. Only the
        # scheduled per-bs profiler (SGLANG_GRAPH_BATCH_CAPTURE) needs stepping;
        # the original unscheduled pass leaves this None.
        self._profiler = None
        if self.enable_profile_cuda_graph:
            profile_context = self._init_profile_context_and_memory_record()
            if self._graph_batch_capture_active():
                self._profiler = profile_context

        # share_buffers() coalesces seq_lens / seq_lens_cpu through the process-
        # wide pool, so they may alias a buffer seeded by an earlier runner (the
        # eager registry fills them with 0). The capture-time attention-metadata
        # plan reads these as the per-request KV length, and the prefill wrapper
        # (DLLM_EXTEND) asserts kv_len >= qo_len, so restore the fill value the
        # captured graph needs before capturing.
        self.buffers.seq_lens.fill_(self.seq_len_fill_value)
        self.buffers.seq_lens_cpu.fill_(self.seq_len_fill_value)
        # Capture runs real forwards, so a mid-serving recapture would index --
        # and write KV -- through the previous batch's live values. Replay is
        # already covered by the registry's padding policy.
        self.buffers.reset_index_buffers()

        # Trigger CUDA graph capture for specific shapes.
        # Capture the large shapes first so that the smaller shapes
        # can reuse the memory pool allocated for the large shapes.
        with freeze_gc(get_exec().graph.enable_cudagraph_gc):
            if not self.enable_pdmux:
                with (
                    graph_capture(
                        stream=get_or_create_global_graph_capture_stream()
                    ) as graph_capture_context,
                    profile_context as prof,
                ):
                    self.stream = graph_capture_context.stream
                    with self.backend.capture_session(self.stream):
                        self._capture_one_stream()
            else:
                for i, sg in enumerate(self.stream_groups):
                    with (
                        graph_capture(stream=sg[1]) as graph_capture_context,
                        profile_context as prof,
                    ):
                        self.stream = graph_capture_context.stream
                        with self.backend.capture_session(self.stream):
                            self._capture_one_stream(i)

        if self.enable_profile_cuda_graph:
            self._post_process_after_profile(prof)
        self._profiler = None

    def _capture_one_stream(self, stream_idx: Optional[int] = None) -> None:
        avail_mem = get_available_gpu_memory(
            self.model_runner.device,
            self.model_runner.gpu_id,
            empty_cache=False,
        )
        # Reverse so cuda graphs share memory better.
        capture_range = (
            tqdm.tqdm(list(reversed(self.capture_bs)))
            if get_parallel().tp_rank == 0
            else reversed(self.capture_bs)
        )
        lora_variants = (
            [("lora", True), ("nolora", False)]
            if self.record_nolora_graph
            else [(None, None)]
        )
        variants = self.attention_graph_variants
        for bs in capture_range:
            attention_variants = (
                variants.capture_labels if variants is not None else (None,)
            )
            if get_parallel().tp_rank == 0:
                avail_mem = get_available_gpu_memory(
                    self.model_runner.device,
                    self.model_runner.gpu_id,
                    empty_cache=False,
                )
                capture_range.set_description(
                    f"Capturing batches ({bs=} {avail_mem=:.2f} GB)"
                )

            for variant_label, _variant_has_lora in lora_variants:
                _set_capture_lora_variant(variant_label)
                for attention_variant in attention_variants:
                    _set_capture_attention_variant(attention_variant)
                    self._set_profile_trace_tag(
                        bs, stream_idx, variant_label, attention_variant
                    )
                    with torch_compile_decoration.patch_model(
                        self.model_runner.model,
                        bs in self.compile_bs,
                        num_tokens=bs * self.captured_req_width,
                        tp_group=get_parallel().tp_group,
                    ) as forward:
                        self.capture_one_shape(
                            bs,
                            forward,
                            stream_idx,
                            variant_label,
                            attention_variant,
                        )
        _set_capture_attention_variant(None)

    def capture_one_shape(
        self,
        size: int,
        forward: Callable,
        stream_idx: Optional[int] = None,
        variant_label: Optional[str] = None,
        attention_variant: Optional[str] = None,
    ):
        num_tokens = size * self.captured_req_width
        bs = self._ragged_capture_slots(num_tokens) if self.ragged_verify_mode else size

        # Sanity-check: --debug-cuda-graph requires breakable backend.
        if get_exec().graph.debug_cuda_graph:
            assert isinstance(self.backend, BreakableCudaGraphBackend), (
                "Breakable CUDA graph is required for --debug-cuda-graph"
            )

        forward_batch, attn_backend, pp_proxy_tensors = self.capture_prepare(
            bs, stream_idx=stream_idx, num_tokens=num_tokens
        )

        # All setup hooks below read get_attn_backend() (TboForwardBatchPreparer,
        # DeepEP adapter, …) so they must run inside the same ForwardContext
        # that wraps the warmup/capture forward.
        with forward_context(ForwardContext(attn_backend=attn_backend)):
            self.tbo_plugin.capture_one_batch_size(forward_batch, num_tokens=num_tokens)

            if forward_batch.lora_ids is not None:
                self.model_runner.lora_manager.prepare_lora_batch(forward_batch)

            attn_backend.init_forward_metadata_out_graph(forward_batch, in_capture=True)

            def run_once():
                # Graph-recordable metadata-prep hook. The unified memory pool
                # records ZERO translate nodes here: all its read/write translates
                # run eagerly in `init_forward_metadata_out_graph` (replay-prep), so
                # the captured graph reads already-physical locs. Base no-op for triton.
                attn_backend.init_forward_metadata_in_graph(forward_batch)
                self._record_in_graph_metadata_prep_done()

                # No invalidate_loc_cache() here: the unified pool translates its
                # locs in `init_forward_metadata_out_graph`, so no cache to invalidate.

                forward_batch.dp_local_start_pos = forward_batch.dp_local_num_tokens = (
                    None
                )
                set_dp_buffer_len(
                    forward_batch.global_dp_buffer_len,
                    num_tokens,
                    forward_batch.dp_padding_mode.is_max_len(),
                    forward_batch.global_num_tokens_cpu,
                )
                set_is_extend_in_batch(False)

                kwargs = {}
                if (
                    self.pp_size > 1
                    and "pp_proxy_tensors" in inspect.signature(forward).parameters
                ):
                    kwargs["pp_proxy_tensors"] = PPProxyTensors(
                        {k: v.clone() for k, v in pp_proxy_tensors.tensors.items()}
                    )
                if (
                    (
                        self.dllm_uses_input_embeds
                        or (
                            self.model_runner.spec_algorithm.is_dflash_family()
                            and self.model_runner.is_draft_worker
                        )
                    )
                    and "input_embeds" in inspect.signature(forward).parameters
                    and not hasattr(self.model_runner.model, "forward_embed")
                ):
                    if self.dllm_input_preparation is None:
                        kwargs["input_embeds"] = self.buffers.input_embeds[:num_tokens]
                    else:
                        state = self.buffer_registry.get_slot(
                            "dllm_input_preparation_state"
                        ).buffer[:num_tokens]
                        kwargs["input_embeds"] = self.dllm_input_preparation(
                            self.model_runner.model, forward_batch.input_ids, state
                        )

                out = forward(
                    forward_batch.input_ids,
                    forward_batch.positions,
                    forward_batch,
                    **kwargs,
                )
                for capture_hook in self.model_runner.capture_tail_hooks:
                    capture_hook(self, out, forward_batch, num_tokens)
                return out

            self.deepep_adapter.capture(is_extend_in_batch=False)
            canary_ctx = (
                c.with_active_single_forward_manager(0)
                if (c := self.model_runner.canary_manager) is not None
                else contextlib.nullcontext()
            )

            with canary_ctx:
                shape_key = self._make_graph_key(
                    self._capture_graph_size(bs=bs, num_tokens=num_tokens),
                    stream_idx,
                    variant_label,
                    attention_variant,
                )
                # Adaptive runners may own a different backend than model_runner.
                post_warmup_hook = getattr(
                    attn_backend,
                    "on_after_cuda_graph_warmup",
                    None,
                )
                maybe_flashinfer_autotune_speculative_draft(
                    self,
                    run_once,
                    post_warmup_hook=post_warmup_hook,
                    run_lm_head=True,
                )
                self.backend.capture_one(
                    shape_key,
                    run_once,
                    capture_inputs=None,
                    post_warmup_hook=post_warmup_hook,
                )

    def _set_dp_real_num_tokens(self, raw_num_token: int) -> None:
        # An idle DP rank replays a fabricated batch whose count may not reach
        # the slot, leaving the previous replay's value; the model masks DP pad
        # rows by this count, so write the real one on every replay.
        buf = self.buffers.num_token_non_padded
        if buf is not None and _dp_tp_moe_masks_pad_rows():
            buf.fill_(raw_num_token)

    def _validate_capture_hidden_mode(self, forward_batch: ForwardBatch) -> None:
        if self.capture_hidden_mode < forward_batch.capture_hidden_mode:
            raise RuntimeError(
                "The runtime hidden-state mode exceeds the fixed CUDA graph "
                f"capture mode ({self.capture_hidden_mode.name})."
            )

    def load_batch(
        self,
        forward_batch: ForwardBatch,
        pp_proxy_tensors: Optional[PPProxyTensors] = None,
    ):
        if (
            self.dllm_uses_input_embeds
            and self.dllm_input_preparation is None
            and forward_batch.input_embeds is None
        ):
            raise ValueError(
                "Diffusion graph replay requires prepared input embeddings"
            )
        ragged_layout = (
            resolve_ragged_verify_layout(forward_batch)
            if self.ragged_verify_mode
            else None
        )
        is_ragged = ragged_layout is not None

        self.deepep_adapter.replay()

        if not forward_batch.needs_forward_metadata_init():
            if self.dllm_input_preparation is not None:
                slot = self.buffer_registry.get_slot("dllm_input_preparation_state")
                source = forward_batch.dllm_input_preparation_state
                padded_tokens = self.bs * self.captured_req_width
                slot.buffer[: self.raw_num_token].copy_(source)
                slot.reset_padding(self.raw_num_token, padded_tokens)
                self.buffers.input_ids[self.raw_num_token : padded_tokens].zero_()
            # Pre-planned (plan-stream load_batch already ran).
            # In speculative decoding, these two fields are still needed.
            graph_size_key = (
                self._ragged_graph_size
                if is_ragged
                else self._capture_graph_size(
                    bs=self.bs, num_tokens=self.bs * self.captured_req_width
                )
            )
            if is_ragged:
                assert self.raw_num_token == ragged_layout.graph_num_tokens, (
                    f"stale ragged raw_num_token {self.raw_num_token} != "
                    f"{ragged_layout.graph_num_tokens}"
                )
                self._stage_ragged_verify_layout(ragged_layout, graph_size_key)
            self._set_dp_real_num_tokens(self.raw_num_token)
            self.buffers.input_ids[: self.raw_num_token].copy_(forward_batch.input_ids)
            self.buffers.positions[: self.raw_num_token].copy_(forward_batch.positions)
            if (
                pp_proxy_tensors is not None
                and self.buffers.pp_proxy_tensors is not None
            ):
                # PP + spec verify: the pre-planned load ran without the proxy
                # (eagle_prepare_for_verify has no access to it), so the
                # graph's proxy input buffers must be refreshed here -- the
                # captured graph reads these rows (mirrors fill_from's
                # side-slot copy).
                for k, v in pp_proxy_tensors.tensors.items():
                    buf = self.buffers.pp_proxy_tensors.get(k)
                    if buf is not None:  # skip markers like __msg_type__
                        buf[: v.shape[0]].copy_(v)
            if (
                not is_ragged
                and (
                    self.dllm_uses_input_embeds
                    or (
                        self.model_runner.spec_algorithm.is_dflash_family()
                        and self.model_runner.is_draft_worker
                    )
                )
                and forward_batch.input_embeds is not None
            ):
                self.buffers.input_embeds[: self.raw_num_token].copy_(
                    forward_batch.input_embeds
                )
            variant_label = self._resolve_lora_variant(forward_batch)
            attention_variant = self._resolve_attention_variant(forward_batch, self.bs)
            stream_idx = get_current_stream_idx() if self.enable_pdmux else None
            self._replay_graph_key = self._make_graph_key(
                graph_size_key, stream_idx, variant_label, attention_variant
            )
            return

        buffers = self.buffers
        self._validate_capture_hidden_mode(forward_batch)

        raw_bs = forward_batch.batch_size

        if is_ragged:
            raw_num_token = ragged_layout.graph_num_tokens
            graph_size_key = self._ragged_graph_num_tokens(raw_num_token)
            assert graph_size_key == ragged_layout.graph_num_tokens, (
                f"ragged verify tier mismatch: runner tier {graph_size_key} != "
                f"layout graph_num_tokens {ragged_layout.graph_num_tokens}"
            )
            bs = self._ragged_capture_slots(graph_size_key)
            assert bs >= raw_bs, (
                f"ragged capture slots {bs} (tier {graph_size_key}) < raw_bs "
                f"{raw_bs}; the planner must reject this batch before replay"
            )
            padded_num_tokens = graph_size_key
            self._stage_ragged_verify_layout(ragged_layout, graph_size_key)
        else:
            raw_num_token = raw_bs * self.captured_req_width
            if self.require_mlp_tp_gather:
                max_batch_size = self._max_dp_batch_size(forward_batch)
                bs = self._pad_to_bucket(max_batch_size, self.capture_bs)
            else:
                bs = self._pad_to_bucket(raw_bs, self.capture_bs)
            padded_num_tokens = bs * self.captured_req_width
            graph_size_key = self._capture_graph_size(
                bs=bs, num_tokens=padded_num_tokens
            )

        self.buffer_registry.fill_from(
            forward_batch,
            raw_bs=raw_bs,
            padded_bs=bs,
            raw_num_tokens=raw_num_token,
            padded_num_tokens=padded_num_tokens,
            pp_proxy_tensors=pp_proxy_tensors,
        )

        if (
            not is_ragged
            and (
                self.dllm_uses_input_embeds
                or (
                    self.model_runner.spec_algorithm.is_dflash_family()
                    and self.model_runner.is_draft_worker
                )
            )
            and forward_batch.input_embeds is not None
        ):
            buffers.input_embeds[:raw_num_token].copy_(forward_batch.input_embeds)
        # Padded tokens aren't read, so skip zeroing. Ragged input_ids arrive
        # from the planner already padded to the tier, invalid slots zeroed.
        self._set_dp_real_num_tokens(raw_num_token)
        if self.enable_two_batch_overlap:
            self.tbo_plugin.replay_prepare(
                forward_mode=self.capture_forward_mode,
                bs=bs,
                num_token_non_padded=len(forward_batch.input_ids),
                spec_info=forward_batch.spec_info,
            )
        if (
            not is_ragged
            and forward_batch.forward_mode.is_idle()
            and forward_batch.spec_info is not None
        ):
            forward_batch.spec_info.custom_mask = buffers.custom_mask

        attn_backend = self._replay_attn_backend()
        fb_view = build_replay_fb_view(
            forward_batch=forward_batch,
            buffers=buffers,
            bs=bs,
            raw_bs=raw_bs,
            num_tokens=padded_num_tokens,
            global_num_tokens_cpu=self._global_num_tokens_for_graph(padded_num_tokens),
            seq_len_fill_value=self.seq_len_fill_value,
            capture_forward_mode=self.capture_forward_mode,
            is_encoder_decoder=self.is_encoder_decoder,
        )
        if (
            self.model_runner.lora_manager is not None
            and self.model_runner.lora_manager.attn_dp_enabled
        ):
            self.model_runner.lora_manager.prepare_lora_batch(
                cast(ForwardBatch, fb_view)
            )
        # Glue-graph fast path: pointer-stable prep (static buffers + pool
        # tensors only) is captured per key; guards keep every python-visible
        # branch inside the backends constant for that key.
        if (
            self._metadata_glue is not None
            and not self._metadata_glue.disabled
            and raw_bs == bs
            and not self.enable_two_batch_overlap
            and not self.enable_pdmux
            and self.model_runner.lora_manager is None
        ):
            # actual_forward_mode belongs in the key even though the captured
            # graph always targets capture_forward_mode: DSV4's replay prep
            # substitutes seq_lens / seq_lens_cpu / seq_lens_sum /
            # req_pool_indices / out_cache_loc when the runtime mode is IDLE,
            # so IDLE and active DECODE are different python branches and must
            # not share a captured graph.
            self._metadata_glue.run(
                attn_backend,
                fb_view,
                (
                    bs,
                    str(self.capture_forward_mode),
                    str(fb_view.actual_forward_mode),
                ),
            )
        else:
            attn_backend.init_forward_metadata_out_graph(fb_view)

        self.raw_bs = raw_bs
        self.raw_num_token = raw_num_token
        self.bs = bs
        if is_ragged:
            self._ragged_graph_size = graph_size_key

        if self.model_runner.hisparse_coordinator is not None:
            self.model_runner.hisparse_coordinator.num_real_reqs.fill_(raw_bs)

        variant_label = self._resolve_lora_variant(forward_batch)
        attention_variant = self._resolve_attention_variant(forward_batch, bs)
        stream_idx = get_current_stream_idx() if self.enable_pdmux else None
        self._replay_graph_key = self._make_graph_key(
            graph_size_key, stream_idx, variant_label, attention_variant
        )

    def _ragged_graph_num_tokens(self, total_verify_tokens: int) -> int:
        from sglang.srt.speculative.ragged_verify import round_up_grid

        return round_up_grid(total_verify_tokens, self.capture_num_tokens)

    def execute(
        self,
        forward_batch: ForwardBatch,
        pp_proxy_tensors: Optional[PPProxyTensors] = None,
    ) -> Union[LogitsProcessorOutput, PPProxyTensors]:
        timer_ctx = device_timer_ctx(
            self.model_runner.device_timer, forward_batch.forward_mode.name.lower()
        )
        shared_read_ends = self._resolve_shared_read_ends(
            self._replay_attn_backend(), forward_batch.forward_mode
        )
        with timer_ctx, self.backend.replay_session():
            self.load_batch(forward_batch, pp_proxy_tensors)
            if envs.SGLANG_LOG_DECODE_GRAPH_KEY.get():
                logger.info(
                    "Decode graph replay: worker=%s key_size=%s (%s) mode=%s raw_bs=%d%s",
                    "draft" if self.model_runner.is_draft_worker else "target",
                    self._replay_graph_key.size,
                    "num_tokens" if self.ragged_verify_mode else "bs",
                    forward_batch.forward_mode.name,
                    forward_batch.batch_size,
                    (
                        f" slots={self._ragged_capture_slots(self._replay_graph_key.size)}"
                        if self.ragged_verify_mode
                        else ""
                    ),
                )
            if shared_read_ends is SharedReadEnds.PRE_REPLAY:
                self._publish_read_done(in_graph=False)

            output = self.backend.replay(self._replay_graph_key, forward_batch)

            if shared_read_ends is SharedReadEnds.IN_REPLAY:
                self._publish_read_done(in_graph=True)

            if shared_read_ends is SharedReadEnds.POST_REPLAY:
                self._publish_read_done(in_graph=False)

            output = self._process_output_after_replay(output, forward_batch)

        if isinstance(output, LogitsProcessorOutput):
            if self.is_dllm:
                next_token_logits = None
                full_logits = (
                    output.full_logits[: self.raw_num_token]
                    if output.full_logits is not None
                    else None
                )
            else:
                full_logits = None
                next_token_logits = (
                    output.next_token_logits[: self.raw_num_token]
                    if output.next_token_logits is not None
                    else None
                )

            # Preserve extension fields produced by the eager output processor.
            return dataclasses.replace(
                output,
                next_token_logits=next_token_logits,
                full_logits=full_logits,
                hidden_states=(
                    output.hidden_states[: self.raw_num_token]
                    if output.hidden_states is not None
                    else None
                ),
            )
        else:
            assert isinstance(output, PPProxyTensors)
            # Slice in token rows, not request rows: under speculative verify
            # each request carries captured_req_width tokens (identical for
            # plain decode, where captured_req_width == 1).
            return PPProxyTensors(
                {
                    k: v[: self.bs * self.captured_req_width]
                    for k, v in output.tensors.items()
                }
            )

    def _process_output_after_replay(self, output, forward_batch: ForwardBatch):
        """Optional eager tail executed after graph replay and inside its timer."""
        return output

    def get_spec_info(self, num_tokens: int):
        spec_info = None
        if (
            self.model_runner.spec_algorithm.is_eagle()
            or self.model_runner.spec_algorithm.is_standalone()
        ):
            from sglang.srt.speculative.eagle_info import EagleVerifyInput

            if self.model_runner.is_draft_worker:
                raise RuntimeError("This should not happen.")
            else:
                capture_mode = (
                    CaptureHiddenMode.NULL
                    if self.model_runner.spec_algorithm.is_standalone()
                    else CaptureHiddenMode.FULL
                )
                spec_info = EagleVerifyInput(
                    draft_token=None,
                    custom_mask=self.buffers.custom_mask,
                    positions=None,
                    retrieve_index=None,
                    retrieve_next_token=None,
                    retrieve_next_sibling=None,
                    retrieve_cum_len=None,
                    spec_steps=self.speculative_num_steps,
                    topk=get_spec().speculative_eagle_topk,
                    draft_token_num=self.speculative_num_draft_tokens,
                    capture_hidden_mode=capture_mode,
                    seq_lens_sum=None,
                    seq_lens_cpu=None,
                )
                # MTP models (e.g. deepseek_nextn) read spec_info.hidden_states
                spec_info.hidden_states = torch.zeros(
                    (num_tokens, self.model_runner.model_config.hidden_size),
                    dtype=self.model_runner.dtype,
                    device=self.model_runner.device,
                )
        elif self.model_runner.spec_algorithm.is_dflash_family():
            from sglang.srt.speculative.dflash_info import DFlashVerifyInput
            from sglang.srt.speculative.dflash_utils import (
                resolve_dflash_verify_mask_policy,
            )

            # Avoid enabling custom-mask modes during graph capture for backends that
            # can express DFLASH verify via their built-in causal path.
            _, build_custom_mask = resolve_dflash_verify_mask_policy(
                self.model_runner.attn_backend
            )
            spec_info = DFlashVerifyInput(
                draft_token=None,
                positions=None,
                draft_token_num=self.captured_req_width,
                custom_mask=(
                    None
                    if (self.model_runner.is_draft_worker or not build_custom_mask)
                    else self.buffers.custom_mask
                ),
                capture_hidden_mode=(
                    CaptureHiddenMode.NULL
                    if self.model_runner.is_draft_worker
                    else CaptureHiddenMode.FULL
                ),
                ragged_verify_layout=self._capture_ragged_verify_layout(num_tokens),
            )

        elif self.model_runner.spec_algorithm.is_ngram():
            from sglang.srt.speculative.ngram_info import NgramVerifyInput

            spec_info = NgramVerifyInput(
                draft_token=None,
                custom_mask=self.buffers.custom_mask,
                positions=None,
                retrieve_index=None,
                retrieve_next_token=None,
                retrieve_next_sibling=None,
                draft_token_num=self.captured_req_width,
            )
            spec_info.capture_hidden_mode = CaptureHiddenMode.NULL

        return spec_info

