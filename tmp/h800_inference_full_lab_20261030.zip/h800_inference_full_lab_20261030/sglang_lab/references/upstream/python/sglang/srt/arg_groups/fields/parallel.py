"""Config fields of the ``parallel`` namespace."""

from __future__ import annotations

import argparse
from typing import Optional

import msgspec

from sglang.srt.arg_groups.arg_utils import (
    A,
    Arg,
    Derived,
)


class Parallel(msgspec.Struct):
    """Namespace ``parallel``."""

    _NS_PATH = "parallel"

    # -------------------------------------------------------------------------
    # Distributed topology and parallelism (TP, PP, DP, CP)
    # -------------------------------------------------------------------------
    nccl_port: A[
        Optional[int],
        "The port for NCCL distributed environment setup. Defaults to a random port.",
    ] = None
    dist_timeout: A[
        Optional[int], "Set timeout for torch.distributed initialization."
    ] = None
    dist_init_addr: A[
        Optional[str],
        Arg(
            help="The host address for initializing distributed backend (e.g., `192.168.0.2:25000`).",
            aliases=["--nccl-init-addr"],
        ),
    ] = None
    gated_launch_port: A[
        Optional[int],
        "The port of the gated launch control server. When set, every rank blocks right after the distributed environment is initialized, before any sizable GPU allocation, until `POST /gate/activate` is sent to this port on the host of the first rank. This lets an external orchestrator defer the memory hungry part of startup to a safe window. Defaults to None, which disables the gate.",
    ] = None
    nnodes: A[int, "The number of nodes."] = 1
    node_rank: A[int, "The node rank."] = 0
    tp_size: A[
        int,
        Arg(
            help="The tensor parallelism size.",
            aliases=["--tensor-parallel-size"],
        ),
    ] = 1
    dcp_size: A[
        int,
        Arg(
            help="The decode context parallelism size.",
            aliases=["--decode-context-parallel-size"],
        ),
    ] = 1
    pp_size: A[
        int,
        Arg(
            help="The pipeline parallelism size.",
            aliases=["--pipeline-parallel-size"],
        ),
    ] = 1
    pp_max_micro_batch_size: A[
        Optional[int], "The maximum micro batch size in pipeline parallelism."
    ] = None
    pp_async_batch_depth: A[
        int,
        "The async batch depth of pipeline parallelism.",
    ] = 0
    dp_size: A[
        int,
        Arg(
            help="The number of data-parallel replicas of the model.",
            aliases=["--data-parallel-size"],
            resolvable=True,
        ),
    ] = 1
    attn_dp_size: A[
        int,
        Arg(
            help="The attention data parallelism size: the number of "
            "data-parallel attention groups inside the TP group, one scheduler "
            "each, while the FFN stays tensor parallel.",
            aliases=["--attention-data-parallel-size"],
            resolvable=True,
        ),
    ] = 1
    load_balance_method: A[
        str,
        Arg(
            help="The load balancing strategy for data parallelism.",
            choices=[
                "auto",
                "round_robin",
                "follow_bootstrap_room",
                "total_requests",
                "total_tokens",
            ],
        ),
    ] = "auto"
    attn_cp_size: A[
        int,
        Arg(
            help="The attention context parallelism size.",
            aliases=["--attention-context-parallel-size"],
            resolvable=True,
        ),
    ] = 1
    moe_dp_size: A[
        int,
        Arg(
            help="The moe data parallelism size.",
            aliases=["--moe-data-parallel-size"],
        ),
    ] = 1
    dwdp_size: A[
        int,
        Arg(
            help="DWDP (Distributed Weight Data Parallelism) group size. "
            "When > 1, MoE prefill uses weight prefetch instead of token all-to-all. "
            "Must equal tp_size. Only supported with --disaggregation-mode null or prefill.",
        ),
    ] = 1
    dcp_comm_backend: A[
        Optional[str],
        Arg(
            help="Communication backend for the decode context-parallel (DCP) "
            "attention reduction: 'ag_rs' (AllGather + ReduceScatter), 'a2a' "
            "(one All-to-All exchange of output+LSE, then a local LSE combine), "
            "or 'fi_a2a' (FlashInfer MNNVL All-to-All kernel; requires "
            "Blackwell and a DCP group within one MNNVL domain). Unset resolves "
            "to 'fi_a2a' where supported, else 'a2a' on CUDA/ROCm/XPU, else 'ag_rs'.",
            choices=["ag_rs", "a2a", "fi_a2a"],
            resolvable=True,
        ),
    ] = None
    dcp_replicate_q_proj: A[
        Optional[bool],
        Arg(
            help="For MLA decode context parallelism with the a2a/fi_a2a "
            "backend: replicate the Q projection so each DCP rank computes the "
            "full-head query locally (redundant projection compute), eliminating "
            "the per-layer head-dim all-gather of Q. Trades a small amount of "
            "extra GEMM for one fewer collective per layer. Use "
            "--no-dcp-replicate-q-proj to disable the model-specific default.",
            action=argparse.BooleanOptionalAction,
            resolvable=True,
        ),
    ] = None
    enable_prefill_cp: A[
        bool,
        "Enable context parallelism for the prefill phase. Select the layout with --cp-strategy.",
    ] = False
    cp_strategy: A[
        Optional[str],
        Arg(
            help="Sharding strategy for prefill CP. 'zigzag' assigns each rank one early and one late sequence block; 'interleave' assigns token indices modulo the CP size.",
            choices=("zigzag", "interleave"),
        ),
    ] = None
    enable_cp_tp_group_sharing: A[
        bool,
        Arg(
            help="(Derived) CP-TP group sharing: prefill CP for hybrid "
            "linear-attention models where the CP group is the TP group; the "
            "residual stream, attention and indexer are CP-sharded while MoE "
            "and linear attention keep TP. Resolved from the model architecture.",
            no_cli=True,
            resolvable=True,
        ),
    ] = False
    # Split DSA GPU KV/indexer cache layers across CP ranks.
    enable_dsa_cache_layer_split: A[
        bool,
        "Split DSA (DeepSeek Sparse Attention) GPU KV/indexer cache layers across context-parallel ranks to reduce per-rank KV memory. Currently only supported with the mooncake transfer backend (mooncake / mooncake_tcp); mori/nixl support will be added later by the community.",
    ] = False
    enable_cp_decode_attn_tp: A[
        bool,
        "Enable attention tensor-parallel weight slicing during decode under context parallel (cp_size>1). Slices the replicated attention linears to the local CP partition, eliminating redundant decode GEMMs.",
    ] = False
    enable_kv_cache_sharding: A[
        bool,
        "Shard at-rest KV cache storage at page granularity across the group "
        "that currently replicates it (attention-CP ranks for GQA models "
        "under prefill CP; attention-TP ranks for MLA models), multiplying "
        "the group's unique KV capacity. Prefill workers of PD "
        "disaggregation only.",
    ] = False
    # Deprecated spelling of `attn_dp_size`: `--dp-size N --enable-dp-attention`
    # resolves to `attn_dp_size = N`, `dp_size = 1`. TODO: remove after 2026-12-31.
    enable_dp_attention: A[bool, Arg(no_cli=True, resolvable=True)] = False
    enable_dp_attention_local_control_broadcast: A[
        bool,
        "With DP-attention, send control messages to every DP group leader and broadcast within attn_tp_group instead of the full tp_group. Eliminates a costly all-ranks gloo sync on every scheduler iteration.",
    ] = False
    enable_dp_lm_head: A[
        bool,
        Arg(
            help="Enable vocabulary parallel across the attention TP group to avoid all-gather across DP groups, optimizing performance under DP attention.",
            resolvable=True,
        ),
    ] = False
    enable_tp_lm_head_all_to_all: A[
        Optional[bool],
        Arg(
            help="Use all-to-all instead of TP all-gather followed by DP scatter "
            "for the TP-sharded LM head under DP attention. By default this is "
            "enabled only on decode-only PD nodes with pure DP attention "
            "(tp_size == attn_dp_size > 1 and attn_cp_size == 1), and disabled on "
            "prefill-only and colocated nodes. Pass "
            "--no-enable-tp-lm-head-all-to-all to opt out. The path is "
            "incompatible with --enable-dp-lm-head; batches without an equal "
            "padded row count fall back to the existing all-gather path.",
            action=argparse.BooleanOptionalAction,
            resolvable=True,
        ),
    ] = None
    enable_attn_tp_input_scattered: A[
        bool,
        Arg(
            help="Allow input of attention to be scattered when only using tensor parallelism, to reduce the computational load of operations such as qkv latent.",
            resolvable=True,
        ),
    ] = False
    enable_shared_experts_attn_tp: A[
        bool,
        "Shard shared expert weights across the attention TP group when using an expert-parallel all-to-all backend.",
    ] = False
    shared_experts_tp_size: A[
        Optional[int],
        "Shared-expert TP size for Kimi-K3 with an expert-parallel all-to-all "
        "backend. Must divide attention TP size. Overrides "
        "--enable-shared-experts-attn-tp when set; 1 replicates the weights.",
    ] = None
    enable_dense_mlp_attn_tp: A[
        bool,
        "Shard dense MLP weights across the attention TP group under DP attention.",
    ] = False
    enable_layernorm_sp: A[
        bool,
        "Enable Megatron-style sequence parallelism (arXiv:2205.05198) for the "
        "LayerNorm/residual regions under pure tensor parallelism: the row-parallel "
        "all-reduce becomes reduce-scatter + all-gather, so LayerNorm runs on "
        "sequence-sharded activations with no extra communication volume. "
        "Prefill only; Qwen3 dense; requires tp_size > 1 and NVLink/NVSwitch.",
    ] = False
    disable_attn_tp_gather: A[
        bool,
        "Disable scheduler-side attn_tp_gather (the upstream SP path "
        "that pads num_tokens to attn_tp_size and pre-allocates a gathered "
        "buffer). Use for models that manage SP scatter/gather at the "
        "model level (e.g., perform their own all_gather/reduce_scatter "
        "inside attention) and do not consume the upstream gathered_buffer. "
        "Without this, the cuda graph runner pads num_tokens to attn_tp_size, "
        "which can cause kernel autotuners to select wrong-sized variants "
        "at small batches.",
    ] = False
    enable_p2p_check: A[
        bool,
        "Enable P2P check for GPU access, otherwise the p2p access is allowed by default.",
    ] = False

    # -------------------------------------------------------------------------
    # Expert parallelism
    # -------------------------------------------------------------------------
    ep_size: A[
        int,
        Arg(
            help="The expert parallelism size.",
            aliases=["--expert-parallel-size", "--ep"],
            resolvable=True,
        ),
    ] = 1
    moe_dense_tp_size: A[
        Optional[int],
        Arg(
            help="TP size for MoE dense MLP layers. This flag is useful when, with large TP size, there are errors caused by weights in MLP layers having dimension smaller than the min dimension GEMM supports.",
            resolvable=True,
        ),
    ] = None
    ep_join_rank_offset: A[
        int,
        Arg(
            help=(
                "Global rank offset of an elastic EP joining group. Scale "
                "joiners must set this to the current effective EP size."
            ),
            cli_name="--elastic-ep-join-rank-offset",
        ),
    ] = 0
    elastic_ep_initial_size: A[
        Optional[int],
        "EP size used to define the immutable per-rank expert storage layout. "
        "Scale joiners must use the primary deployment's launch-time EP size.",
    ] = None
    max_ep_size: A[
        Optional[int],
        "Maximum EP size the server can scale to at runtime. Pre-allocates active-rank state and backend buffers to this size. Defaults to the launch-time world size.",
    ] = None

    # Derived fields are computed at publication and are not stored in ServerArgs.
    attn_tp_size = Derived(
        fn="sglang.srt.runtime_context.attn_tp_size_of",
        doc="Attention tensor-parallel width: `tp_size` divided by the "
        "attention-DP and attention-CP dimensions.",
    )
    attn_dp_enabled = Derived(
        fn="sglang.srt.runtime_context.attn_dp_enabled_of",
        doc="Whether attention runs data parallel: `attn_dp_size` is wider "
        "than one, or this process is an elastic EP scale joiner, which joins "
        "an attention-DP deployment with a group of its own that may be one "
        "rank wide.",
    )
    num_dp_ranks = Derived(
        fn="sglang.srt.runtime_context.num_dp_ranks_of",
        doc="How many data-parallel ranks the deployment serves with, one "
        "scheduler each: `dp_size * attn_dp_size`. Elastic EP scale-up widens "
        "it as ranks join.",
    )
    attn_dcp_size = Derived(
        fn="sglang.srt.runtime_context.attn_dcp_size_of",
        doc="Decode context-parallel width inside the attention TP group.",
    )
    moe_ep_size = Derived(
        fn="sglang.srt.runtime_context.moe_ep_size_of",
        doc="MoE expert-parallel width, normalised from the configured value.",
    )
    moe_tp_size = Derived(
        fn="sglang.srt.runtime_context.moe_tp_size_of",
        doc="MoE tensor-parallel width: what is left of `tp_size` after the "
        "expert and MoE-DP dimensions.",
    )
    dcp_enabled = Derived(
        fn="sglang.srt.runtime_context.dcp_enabled_of",
        doc="Whether decode context parallelism is in play: `dcp_size` is "
        "wider than one rank, which is exactly when the group gets built.",
    )

    # Runtime fields: publish sets ranks; distributed initialization sets groups.
    tp_rank = Derived(doc="This process's place in the tensor-parallel group.")
    pp_rank = Derived(doc="This process's place in the pipeline group.")
    moe_ep_rank = Derived(doc="This process's place in the expert-parallel group.")
    moe_dp_rank = Derived(doc=("This process's place in the MoE data-parallel group."))
    moe_tp_rank = Derived(
        doc=("This process's place in the MoE tensor-parallel group.")
    )
    attn_tp_rank = Derived(
        doc=("This process's place in the attention tensor-parallel group.")
    )
    attn_cp_rank = Derived(
        doc=("This process's place in the attention context-parallel group.")
    )
    dcp_rank = Derived(
        doc=("This process's place in the decode context-parallel group.")
    )
    attn_dcp_rank = Derived(
        doc=(
            "Decode context-parallel rank inside the attention TP group, "
            "zero where decode context parallelism is off."
        )
    )
    attn_dp_rank = Derived(
        doc=(
            "This process's index in the attention-DP group, computed from "
            "`tp_rank` when `initialize_dp_attention` runs."
        )
    )
    dp_rank = Derived(
        doc=(
            "Which data-parallel replica this process serves, as the data "
            "parallel controller numbered them at spawn. `None` when there "
            "is no controller: unlike the other ranks it is a position in "
            "no group, which is why the spawn states it."
        )
    )
    launch_world_rank = Derived(
        doc=(
            "This process's rank in the WORLD group as built. A scale-up "
            "does not renumber it."
        )
    )
    launch_world_size = Derived(
        fn="sglang.srt.runtime_context.launch_world_size_of",
        doc="Width the WORLD group was built at -- what a scale-up leaves "
        "behind rather than updates.",
    )
    max_world_size = Derived(
        fn="sglang.srt.runtime_context.max_world_size_of",
        doc="Ranks the WORLD group has room for: `--max-ep-size` when set, "
        "otherwise the launch width.",
    )
    world_group = Derived(doc="The WORLD group.")
    tp_group = Derived(doc="The tensor-parallel group.")
    pp_group = Derived(doc="The pipeline group.")
    moe_ep_group = Derived(doc="The expert-parallel group.")
    moe_dp_group = Derived(doc="The MoE data-parallel group.")
    moe_tp_group = Derived(doc="The MoE tensor-parallel group.")
    attn_tp_group = Derived(doc="The attention tensor-parallel group.")
    attn_cp_group = Derived(doc="The attention context-parallel group.")
    shared_experts_tp_group = Derived(doc=("The shared-expert tensor-parallel group."))
    dcp_group = Derived(doc="The decode context-parallel group.")
