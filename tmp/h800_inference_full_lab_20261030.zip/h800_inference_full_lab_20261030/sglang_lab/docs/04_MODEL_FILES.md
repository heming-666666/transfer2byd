# 04 · 模型选择与完整快照

先部署 `lab`。每个模型独立子目录，两个框架只读共用 `shared/models/`；选择模型名不等于已下载。

| key | checkpoint | 主要实验 | 说明 |
|---|---|---|---|
| `lab` | DeepSeek-R1-Distill-Qwen-32B | 主线TP/DP/PP/PD与内网聊天 | Dense蒸馏，不是671B完整R1；约66GB下载 |
| `dense` | Qwen/Qwen3-8B | SP、backend、graph、约束、EAGLE3 | 小模型降低调试成本 |
| `moe` | Qwen/Qwen3-30B-A3B-FP8 | EP、AttentionDP、prefillCP、专家捕获 | 约30B总参数，不是只存3B；FP8权重 |
| `mla` | DeepSeek-V2-Lite-Chat | MLA/DCP对照 | 需完整且可信的remote code；不自动配BF16 DeepEP快路径 |
| `awq` | Qwen/Qwen3-8B-AWQ | 同架构权重量化 | 与dense比较，要记录量化checkpoint本身的差异 |
| `eagle3_draft` | AngelSlim/Qwen3-8B_eagle3 | 匹配Qwen3-8B目标 | 不与R1-32B混配 |
| `dflash_target`/`dflash_draft` | Qwen3-4B / z-lab/Qwen3-4B-DFlash-b16 | DFlash | target/draft/tokenizer必须一致配对 |
| `modern` | 原始DeepSeek-V4-Flash | 条件新模型实验 | H100 TP8 Marlin配方迁移到H800，须实测 |
| `dspark_target` | DeepSeek-V4-Flash-0731 | 条件DSpark | 别混用原始Flash与0731；官方该H100单元仍有未验证标记 |
| `latest` | DeepSeek-V4.1-Flash-1017 | 前沿适配学习 | H800固定主线不保证，默认拦截，见28 |

## 下载或人工搬入

在模型网页 Files and versions 的commit处复制**完整40位SHA**，执行：

```bash
TASK_MODEL_REV=REPLACE_WITH_REAL_40_HEX_COMMIT
./environments/sglang0522/.venv/bin/python3 scripts/download_model.py --model lab --revision "$TASK_MODEL_REV"
python3 scripts/check_model.py --model lab
```

下载脚本是允许联网的准备动作，不用于运行阶段。人工快照也可以；必须保持 `config/models.json` 的目录名。额外保存 `MODEL_REVISION.txt`（repo、完整commit、来源URL、日期）、文件SHA256清单。`check_model` 检查config、tokenizer、单文件或分片权重、索引引用和明显LFS指针；不替代完整哈希或实际加载。

目录应包含 `config.json`、`tokenizer_config.json`、`tokenizer.json`、generation配置（若有）、完整权重与索引，以及模型要求的 `encoding/`、自定义Python文件和其他资源。draft可能只有 `pytorch_model.bin`，不强制要求带独立tokenizer。对remote code应核对来源和revision；它会运行Python代码，不应取来历不明的实现。

显存计划区分：权重、KV、激活/临时buffer、通信与graph池。MoE激活13B不代表只需加载13B权重；PD两侧各有模型权重。4卡能容纳某权重也不代表该backend/graph/上下文组合有余量。`estimated_download_gb`仅用于磁盘规划，真实字节以快照和索引为准。

下一步：[05 启动与验收](05_BASELINE_SERVICE.md)。
