# 15 · KV Cache FP8与校准

前提：01–07的真实聊天验收通过；先准备本章需要的权重。默认8卡，4卡改变量。所有启动都使用05的单profile切换方法；输出放 `data/results/` 或 `shared/results/`。

| 卡数 | Profile |
|---|---|
| 8 | `8g_bf16`, `8g_kv_fp8`, `8g_kv_fp8_uncalibrated` |
| 4 | `4g_bf16`, `4g_kv_fp8`, `4g_kv_fp8_uncalibrated` |



KV量化与权重量化独立。GQA近似KV字节为 `2×layers×cached_tokens×kv_heads×head_dim×bytes_per_element`，再按实际Attention分片/复制计算；MLA、V4压缩/稀疏KV不能照搬此公式。FP8主要降低KV存储字节，不保证速度提高。

需要自己产生真实scale时，完整脚本、3条流程验收、正式语料、TP4/TP8分别导出与配置见 [公共10校准实验](../../shared/docs/10_KV_CALIBRATION.md)。

`kv_fp8` 要求设置真实 `settings.json:kv_scale_path`，指向按此模型/此SGLang版本校准得到、格式匹配的JSON；路径不存在会失败。**不附送虚构scale文件**。没有校准资产可明确选择下列有质量风险的机制实验：

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine \
  --profile "${CARDS}g_kv_fp8_uncalibrated" --allow-experimental
```

`--kv-cache-dtype fp8_e4m3` 未给正确scale时可能使用默认1.0，不能当校准完成。即使短问答没错，长上下文检索和多轮仍可能退化。SGLang的 `--quantization-param-path` JSON不是vLLM llm-compressor checkpoint的通用替代品；不能直接互拷。

实验分两组：固定 `max_total_tokens` 比较同容量的显存/性能；固定静态显存预算比较能缓存的token数量。否则“显存没变”可能只是系统将节省空间重新用作更大KV池。

测试1K/4K/8K输入、输出256/1024，多并发、needle检索/原数据能力集。记录scale来源、dtype、backend、容量、KV命中、失败/截断、质量变化。通过条件是数值可用且业务质量门槛满足；仅引擎启动不算量化验收。校准模型在27的相同样本集上复测，原BF16作为对照。
