# 14 · 权重精度：BF16、在线FP8与AWQ

前提：01–07的真实聊天验收通过；先准备本章需要的权重。默认8卡，4卡改变量。所有启动都使用05的单profile切换方法；输出放 `data/results/` 或 `shared/results/`。

| 卡数 | Profile |
|---|---|
| 8 | `8g_bf16`, `8g_weight_fp8`, `8g_weight_awq` |
| 4 | `4g_bf16`, `4g_weight_fp8`, `4g_weight_awq` |



三项均为Qwen3-8B架构：BF16原模型、同原模型在线FP8、独立官方AWQ checkpoint。AWQ是checkpoint级差异，不是仅改变运行dtype。

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_weight_fp8"
```

分别切换三个profile，记录加载峰值/稳态显存、加载/量化时间、矩阵kernel、TTFT/TPOT、吞吐、正式任务分数。在线FP8不一定能减少加载阶段内存峰值，首次量化成本需与服务稳态分开。

AWQ使用 `--quantization awq_marlin`，从其config读取量化格式。Hopper支持的W4A16 Marlin意味着低位权重解包后以高精度激活计算，不等价于Blackwell原生FP4乘法。NVFP4/MXFP4等不能仅因“4bit”就跨硬件通用。

通过：相同数据/提示质量测评在预设容忍范围内；范围由业务事先设定（如准确率绝对下降不超过1个百分点），不能测后移动标准。先跑tiny smoke确认流程，再跑27正式数据；只看几条中文回答不是量化质量保证。

做校准型量化时，准备独立工具venv、固定量化工具版本/recipe/校准集revision，把新checkpoint存 `shared/models/<原名>-<量化方案>-<校准版本>/`；原始权重不覆盖。KV量化另见15。
