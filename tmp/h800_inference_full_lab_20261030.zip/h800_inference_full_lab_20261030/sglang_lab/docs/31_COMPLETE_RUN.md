# 31 · SGLang完整练习：8/4卡验收、SLO、能耗、启动与运行归因

所有命令在 `sglang_lab/` 执行。先按01–07备齐环境、权重、Key并完成DeepSeek基线聊天；本章选Qwen3-8B做单变量机制对照。依赖仍是本框架0.5.22原生venv，不安装到系统Python；普通HTTP/采样脚本用标准库。

## 1. 启动无Profiler基线

先结束本包正在运行的旧服务，不能和另一组GPU实验重叠：

```bash
python3 scripts/run.py status
python3 scripts/run.py stop all
```

终端A选卡数，前台保留引擎：

```bash
CARDS=8
python3 scripts/run.py engine --profile "${CARDS}g_graphs_off" --dry-run
python3 scripts/run.py engine --profile "${CARDS}g_graphs_off"
```

4卡只改`CARDS=4`。终端B先等待真实引擎就绪，再前台运行网关，命令沿用05章，不能把进程存在当ready。所有终端先进入同一 `sglang_lab/`。网关单独终端：

```bash
python3 scripts/wait_ready.py --target engine
python3 scripts/run.py gateway
```

终端C验收Qwen3非思考正文及多轮：

```bash
python3 ../shared/scripts/accept_service.py --client-config config/client.json \
  --max-tokens 256 --extra-json ../shared/fixtures/qwen3_nonthinking.json \
  --output ../shared/results/sglang_8g_qwen3_graphoff_trial01/acceptance
```

4卡将目录名的8g改为4g。目录名只做标识，不改变实际卡数；以profile和实际GPU UUID为准。基础DeepSeek验收使用04总指南中的4096预算，不把Qwen3的nonthinking选项套给R1。

## 2. 先做闭环可控测量

闭环固定并发数，能帮助排除客户端发压能力问题。下面仅是轻量起点，不代表H800容量或承诺SLO：

```bash
python3 ../shared/scripts/slo_bench.py --client-config config/client.json \
  --mode closed --requests 64 --concurrency 4 --max-tokens 256 --warmup 4 \
  --extra-json ../shared/fixtures/qwen3_nonthinking.json \
  --output ../shared/results/sglang_8g_qwen3_graphoff_trial01/closed
```

检查failed是否为0、是否有reasoning-only、usage是否完整、输出长度和`length_capped_successes`。小样本/默认三个短prompt只验证工具链；正式曲线换成固定revision/哈希、有足够样本和长度分布的数据。`slo.example.json`是练习目标，先复制到本轮配置再修改数值，不能把示例门槛当平台SLA。

## 3. 同机采资源，再开环发压

终端D先启动采样；选择与本轮profile一致的物理GPU集合：

```bash
CARDS=8
case "$CARDS" in
  8) H800_GPU_IDS=0,1,2,3,4,5,6,7 ;;
  4) H800_GPU_IDS=0,1,2,3 ;;
  *) exit 2 ;;
esac
python3 ../shared/scripts/resource_monitor.py --gpus "$H800_GPU_IDS" --interval 1 --duration 300 \
  --output "../shared/results/sglang_${CARDS}g_qwen3_graphoff_trial01/resources"
```

终端C看见采样目录输出后再压测。下面从2req/s起步；requests=128时恒定到达约63.5秒，再加drain。采样300秒若不足以覆盖全部drain，延长采样后用新trial重跑。长timeout不保证一定在300秒以内结束。

```bash
CARDS=8
python3 ../shared/scripts/slo_bench.py --client-config config/client.json \
  --mode open --arrival constant --rate 2 --requests 128 --concurrency 16 \
  --max-tokens 256 --warmup 4 --timeout 180 \
  --extra-json ../shared/fixtures/qwen3_nonthinking.json \
  --output "../shared/results/sglang_${CARDS}g_qwen3_graphoff_trial01/slo"
```

等压测完成，再等采样自然结束，或在D按Ctrl+C保存尾部。**先停止压测再停止采样**；最后一个功率点应晚于最后一个finish。完成汇总：

```bash
CARDS=8
python3 ../shared/scripts/energy_report.py \
  --resources "../shared/results/sglang_${CARDS}g_qwen3_graphoff_trial01/resources" \
  --slo-summary "../shared/results/sglang_${CARDS}g_qwen3_graphoff_trial01/slo/summary.json" \
  --max-gap 2.5 --min-coverage 0.99 \
  --output "../shared/results/sglang_${CARDS}g_qwen3_graphoff_trial01/energy.json"
```

覆盖率不足返回非零，并保留结果供排查；不补零、不跨主机猜时间差。详细公式和字段见 [公共11](../../shared/docs/11_RESOURCES_ENERGY_CLOCKS.md)。采样/发压都在GPU主机；另一台内网机器先单独验收与测远端延迟。

## 4. 找容量与做4卡对照

固定同一组输入/输出长度、max_tokens、SLO、prefix缓存冷暖条件，按2/4/8/16…req/s增大offered rate；每个速率使用新trial目录。接近拐点改用更细步长；每点至少3轮，记录均值/范围或置信区间。看联合SLO比例和goodput是否同时满足目标，failed/客户端限流丢弃仍计分母。不能只按各项p95都过线就声称95%请求联合达标。

恢复基线并改为4卡完整重跑；不能仅修改结果目录名称。比较总GPU焦耳和J/token、吞吐、TTFT/TPOT/E2E、联合SLO、截断和失败。固定工作负载下的4/8卡比较与各自最大容量比较分开写。

## 5. 分开测Graph准备与稳定运行

在A/B终端按正常退出流程停止旧服务，或用本包stop；先保存结果。独立启动捕获轮次：

```bash
python3 scripts/run.py stop all
CARDS=8
python3 scripts/run.py engine --profile "${CARDS}g_graphs_on" --capture-profiler
```

启动阶段自动采decode capture，不等HTTP ready以后才开。原始每rank trace位于 `data/traces/graph_capture_profile/`，kernel CPU/CUDA汇总在引擎日志；固定名snapshot的多rank复写限制见 [公共12](../../shared/docs/12_MEMORY_AND_CAPTURE.md)。这轮有Profiler，不能作为graph-on正式吞吐成绩。

再停止并不带capture-profiler启动graphs_on；启动网关，按上面相同负载重复闭环/开环/能耗，目录改为`graphon`。Graph开关若改变KV可用容量，记录引擎实际容量，并做固定容量对照。

短窗口steady-state：另启 `8g_profile/4g_profile`，网关ready后：

```bash
python3 ../shared/scripts/profile_capture.py --framework sglang --target engine \
  --action capture --requests 6 --max-tokens 128
```

PyTorch profiler看CPU算子、CUDA launch、stream/kernel关联；精确kernel数/耗时、CPU API墙钟与重叠、SM硬件计数器分别按30/公共08进行Nsight采集。GPU utilization百分比不能换算成“多少SM”。PD的P/D PyTorch采集按26章**分两轮**，不能把不同轮次硬拼成同一请求的同步时间线。

## 6. 每轮验收记录

保存模型revision、完整profile、实际启动命令、依赖lock哈希、GPU UUID/拓扑、driver、cold/warm状态、prompt哈希、SLO配置、原始结果和解释。API Key只在私密配置。`requests.jsonl`记录每个失败；`summary.json`的token throughput仅使用成功请求usage。没有usage时不假算token/s或J/token；查看 `token_usage_complete`。

一次只改变TP/DP/PP/CP/SP/EP/量化/投机/PD中的一类；本章的测量脚本可复用到原有各章profile。完成主线后再加复杂组合，避免把模型换了、卡数换了、缓存条件换了仍算同一对照。
