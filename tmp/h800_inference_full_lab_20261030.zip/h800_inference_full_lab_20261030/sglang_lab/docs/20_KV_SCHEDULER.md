# 20 · KV池、Radix、chunked prefill与调度

| 机制 | 8/4卡profile后缀 | 含义 |
|---|---|---|
| KV容量 | `kv_pool_32768` / `kv_pool_65536` | `--max-total-tokens`，是KV池容量预算，不是每请求max_tokens |
| 前缀缓存 | `radix` / `no_radix` | Radix共享前缀 vs关闭 |
| prefill分块 | `chunk_1024` / `chunk_4096` | chunked_prefill_size；不等价vLLM整个batch token预算 |
| 队列策略 | `bf16` / `lpm` | 默认策略 vs long-prefix-match |
| CPU/GPU overlap | `bf16` / `overlap_off` | 调度重叠关闭对照 |

例如启动 `8g_kv_pool_32768`，4卡改前缀4g：

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_kv_pool_32768"
```

先单变量实验，再组合。固定同一批长system前缀请求，比较首批冷缓存与后续热缓存；再使用不同前缀集合，观察命中优势是否消失。固定prefix的benchmark可能夸大业务收益，必须标注。

KV压力测试逐步提高并发和输入长度，记录实际KV可用token、cache usage、waiting/running、retraction/eviction、OOM与失败数。框架预先分配KV池时 `nvidia-smi`显存可能不随每个请求下降/增长，不能据此断言没有释放KV。block/token/page分配、活跃请求持有、prefix cache保留和CUDA allocator reserve是不同层。

原理模拟与真实指标映射见 [公共02](../../shared/docs/02_KV_ALLOCATION.md)。SGLang Radix树与vLLM block/hash前缀缓存内部结构不同，CPU模拟只说明refcount/COW，不冒充任一源码实现。

通过：无内存泄漏趋势、请求释放后活跃token/请求数回落（cache可保留前缀），饱和时正确排队/报错并纳入SLO失败。不要为得到漂亮数字忽略重试与retraction。
