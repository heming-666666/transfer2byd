# 18 · Attention backend对照

本章用同一Qwen3-8B、同一dtype、同一8K上下文、关闭graph、相同负载比较，不把模型架构改变当kernel优化。

| 卡数 | Triton | FA3 | FlashInfer |
|---|---|---|---|
| 8 | `8g_attn_triton` | `8g_attn_fa3` | `8g_attn_flashinfer` |
| 4 | `4g_attn_triton` | `4g_attn_fa3` | `4g_attn_flashinfer` |

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_attn_fa3"
```

按05逐项切换，先真实smoke再官方benchmark。输入/输出矩阵：128/128、2048/128、128/1024、4096/512，并发1/8/16。记录首次编译时间和稳态时间，分别测prefill/decode kernel、显存、失败数、质量smoke与27正式子集。

日志必须显示实际选用backend；不支持KV dtype、head dim、MLA、稀疏attention或GPU架构时可能拒绝或走专用路径。不能拿GQA的FA3开关去保证DeepSeekV4专用attention。FA4可在本机 `sglang serve --help` 与依赖/hardware要求满足后复制profile探索；H800不能套Blackwell-only路径。

通过：三项都正确生成、没有缺kernel联网下载、结果文件保存；性能不一定都有收益。数值差异导致temperature0结果不同也可能发生，先确认同prompt、同tokenizer、同长度，再用质量集判断，不能直接判定某backend“无损”或“错误”。
