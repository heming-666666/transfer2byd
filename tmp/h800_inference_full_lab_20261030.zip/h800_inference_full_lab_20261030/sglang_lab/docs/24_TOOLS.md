# 24 · 工具调用与应用端约束

工具调用并不等于模型能执行程序。服务器输出工具名/参数，**客户端应用负责校验、执行和回传结果**。本包示例只有本地UTC时间函数，没有shell或网络执行。

先用Qwen3-8B `8g_bf16/4g_bf16`，其配置启用 `qwen25` tool parser，随后：

```bash
python3 scripts/tool_demo.py
```

流程：发送tools定义 → 收到assistant `tool_calls` → 校验工具白名单、参数类型、调用ID → 执行本地函数 → 将原assistant tool_calls与对应tool结果加入messages → 请求最终assistant答案。

检查原始响应是否有tools字段、finish_reason、arguments JSON。模型选择直接回答而非调用工具是合法auto行为，不应在应用里强行执行一个未请求的工具。要测“强制调用”，先验证当前模型/parser支持指定tool_choice格式，另存实验请求，不改变基线。

R1蒸馏32B没有本包保证的原生工具协议，不把它的普通文本JSON当成已解析tool_calls。若parser或模型不支持，使用23的Schema输出设计明确应用协议；两者测量口径分开。

通过：无未知工具被执行、参数验证正常、tool_call_id正确关联、第二轮最终答案有正文。客户端应限制工具次数和超时；函数返回值要控制大小，超大tool结果同样占上下文。
