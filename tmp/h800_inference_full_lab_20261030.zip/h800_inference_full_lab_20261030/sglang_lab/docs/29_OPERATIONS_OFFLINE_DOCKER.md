# 29 · 生命周期、离线再验收与可选Docker

## 查看与停止

```bash
python3 scripts/run.py status
python3 scripts/run.py stop engine
python3 scripts/run.py stop all
```

只停止本包登记的进程组，检查PID namespace与启动时间防止PID复用。不自动kill其他Python、清空显存或删除权重。终端可Ctrl+C正常退出；残留时保留状态和日志排查。

## 冷/热与离线测试

1. 冷启动记录权重/JIT/capture各阶段时间；热启动明确保留哪些cache。
2. 完成各可选kernel预热后，将允许的对外下载路径断开/在平台已有网络策略下运行；保留客户端到public端口的内网可达性。
3. 仍能重新启动引擎、实际生成、流式/非流式/多轮、PD（若部署PD）；客户端不应访问HuggingFace或公网UI。
4. 用 `ss -tpn` / 有权限时的进程网络审计检查是否仍尝试外网。HF offline变量不等于所有kernel库都停止外连；缺资产要补齐，不忽略异常。

迁移时保留原始Python归档/wheels/lock/manifests，重建venv，重新configure路径，别复制旧进程PID状态。缓存按GPU/驱动/Torch版本分开。数据盘剩余空间不足会导致JIT、trace和日志失败，定期只读检查。

## Docker只是可选替代

此包SGLang launcher主线是native，**没有假装提供一个可用的 `run.py --backend docker` 开关**。若平台允许Docker+NVIDIA runtime，可先验证 `docker version`、`docker info`与GPU容器探针，准备官方固定版本镜像及其digest，保存tar到 `environments/images/`，目标机 `docker load`。

建议运行官方 `lmsysorg/sglang:v0.5.22` 的基础模型命令，并显式挂载本地权重只读、缓存到项目子目录；Key不要写argv，用本包engine_entry等价入口在容器内读取私密文件。启动前核对容器内sglang/router/torch版本、所有私有端口绑定和PD依赖。`latest/dev`可变标签不能当复现依据。

容器内绝对路径与本机settings不同，需要独立容器settings，不能直接拿本机 `/data/...`路径当容器存在。Docker不能用时继续native，不改宿主机Docker daemon、驱动或网络策略来强求容器路线。

## 常见失败

| 现象 | 优先核对 |
|---|---|
| 无匹配wheel/解析失败 | Linux/Python3.12/架构、prerelease、索引、完整闭包 |
| libcuda/driver错误 | 宿主机驱动能力与GPU挂载；venv不能修复内核驱动 |
| 缺nvcc/头文件 | 项目toolkit、匹配版本、预编译kernel/cache |
| OOM | 权重/activation/KV/graph分别记录，先关graph/减running/context/pool |
| NCCL挂起 | P2P/拓扑、rank组、IPC/共享内存、网卡绑定、已有占用 |
| API200但无正文 | reasoning截断、parser/template、finish_reason、PD传输失败 |
| 服务器能用客户端不通 | 真实内网IP、监听0.0.0.0、安全组/ACL/路由、端口 |
| profiler/counter拒绝 | CUPTI冲突、平台计数器权限、vGPU限制；不要伪造SM数据 |

完整状态填入 `data/reports/deployment_status.json`（从template复制后逐项填写），每条附真实日志路径。
