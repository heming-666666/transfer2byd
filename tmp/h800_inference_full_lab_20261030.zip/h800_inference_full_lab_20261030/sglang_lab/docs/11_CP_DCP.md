# 11 · Prefill CP与Decode CP

前提：01–07的真实聊天验收通过；先准备本章需要的权重。默认8卡，4卡改变量。所有启动都使用05的单profile切换方法；输出放 `data/results/` 或 `shared/results/`。

| 卡数 | Profile |
|---|---|
| 8 | `8g_cp`, `8g_dcp` |
| 4 | `4g_cp`, `4g_dcp` |



SGLang的 `--attn-cp-size` 在TP组内分长上下文；`attn_tp=TP/(attnDP×CP)`。DCP在AttentionTP内部继续划分，不扩展卡数。

本包prefillCP使用上游CI出现的Qwen3-30B-A3B-FP8、FA3、zigzag、EP，与简单Dense基线不同。8卡TP8/CP2/EP8，4卡TP4/CP2/EP4。DecodeCP使用DeepSeek-V2-Lite-Chat MLA。

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_cp"
```

切换后另跑 `"${CARDS}g_dcp"`。对prefillCP创建同模型同FA3/EP但cp=1、prefill_cp=false的配置作单变量对照；对DCP创建同MLA模型但dcp=1作对照。不要把cp与dcp两个不同模型结果直接比较。

短上下文可能通信成本更大；先测2K/4K输入，再在确认显存后把context_length提高到32768、输入8K/16K。长上下文实验同时检查prompt+output+模板不超过模型/配置上限。关注TTFT、KV每rank占用、ring/collective、尾延迟，不只看总tokens/s。

通过：rank组满足整除关系、实际长输入成功、同任务质量/答案无明显退化。精确rank通信见30。CP、稀疏attention和MLA各有实现限制；模型不支持不能靠增加一个flag解决。
