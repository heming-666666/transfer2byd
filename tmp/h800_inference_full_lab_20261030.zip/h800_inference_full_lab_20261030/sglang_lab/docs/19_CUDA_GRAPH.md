# 19 · CUDA Graph关闭、捕获与replay

8卡 `8g_graphs_off/on`；4卡 `4g_graphs_off/on`；同Qwen3-8B。off使用 `--cuda-graph-backend-decode disabled` 和prefill disabled；on使用decode full、max-bs32，prefill仍disabled。**这是decode图对照，不声称prefill也开图**。

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_graphs_on"
```

分阶段记录：权重加载 → kernel/JIT warmup → graph capture → graph instantiate/upload（若有）→ 首次请求 → 稳态replay。graph扩大可能增加启动时间和显存池；不能将加载、JIT和图准备统一叫“CUDA Graph开销”。

| 实验 | 对照变量 | 指标 |
|---|---|---|
| 开/关 | 同模型同负载 | CPU launch数量、replay CPU时长、kernel时间、goodput |
| capture最大batch | 复制on改max-bs8/16/32 | 启动时间、graph池峰值、padding/fallback |
| 短/长输出 | 输出128/1024 | launch开销占比与摊销 |
| prefill图 | 仅在模型/backend明确支持时单独配置 | prefill bucket、回退、捕获内存；不混进上述decode对照 |

PyTorch/Perfetto看replay阶段；**启动前挂Nsight**才能完整看到捕获准备。`cudaGraphInstantiate*`的CPU API elapsed与capture上下文壁钟分开；多个rank准备可能重叠，不能把8个rank相加当用户等待时间。

精确执行命令与SM/kernel/CPU统计见 [公共08](../../shared/docs/08_NSIGHT_SM_KERNEL.md)。较小的固定GEMM/通信/graph示例 `gpu_stages.py` 用于认识时间线；真实模型必须再采自己的engine trace。

通过：开关均正常生成，SLO和质量回归正常，报告启动与稳态各自结果。Profiler会扰动capture/launch；最终吞吐使用无Profiler的一轮。
