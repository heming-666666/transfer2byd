# 03 · 配置、API Key、监听地址与端口

在 `sglang_lab/`：

```bash
python3 scripts/configure.py --lan-ip 10.0.0.12 --model-root ../shared/models
python3 scripts/run.py list
```

把示例内网IP换成实际IP。`configure` 再次执行保留已有密钥，不自动轮换。生成：

| 文件 | 用途 |
|---|---|
| `config/settings.json` | 当前机路径、端口、别名、静态内存比例等 |
| `config/secrets.json` | public/engine/admin 三种Key，权限600 |
| `config/client.json` | 内网 base_url、public Key、模型别名；只发给允许调用的人 |
| `config/client.env` | 需要官方SDK时读取public Key |
| `config/engine.env` | 内部兼容环境变量文件；本包SGLang入口主要在内存注入Key |

| 组件 | 默认地址 | 对内网开放 |
|---|---|---|
| 鉴权网关 | `0.0.0.0:9000` | 是，公开 `/v1/models` 与 `/v1/chat/completions` |
| integrated引擎 | `127.0.0.1:9100` | 否 |
| prefill | `127.0.0.1:9110` | 否 |
| decode | `127.0.0.1:9210` | 否 |
| PD router | `127.0.0.1:9310` | 否 |
| P bootstrap | 8998（引擎内部使用） | 不作为客户端端口开放；PD实现可能监听不同接口，需核对实际 `ss -ltnp` |

公网/内网网关只使用 public Key；对接引擎时换成 engine Key；Profiler管理端点使用 admin Key。后两者不复制给客户端。管理端点、原生 `/generate`、KV bootstrap注入字段、专家捕获字段不从公共网关转发。

`engine_entry.py` 在 `prepare_server_args` 后、`run_server` 前向 ServerArgs 写Key；`router_entry.py` 在对象中设置worker Key。`--dry-run`、`ps`与启动manifest没有明文Key。私密文件仍应仅由授权用户读取。

内网API默认HTTP用于此受控实验；需要传输加密时在明确的内部TLS入口配置证书。API Key不是加密机制。网关为学习/小规模内网的标准库线程服务，做大规模压测时必须测量网关自身CPU瓶颈，不能把网关瓶颈当GPU容量。

下一步：[04 模型文件](04_MODEL_FILES.md)。
