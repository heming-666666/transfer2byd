# 21 · 官方性能benchmark与负载矩阵

先启动并验收实际profile；`benchmark.py --profile`只是记录声明，**不会替你启动**该配置。人工核对 `data/runtime/engine.plan.json`，PD核对P/D计划。

```bash
CARDS=8
python3 scripts/benchmark.py --profile "${CARDS}g_baseline" --name smoke \
  --input-len 256 --output-len 64 --requests 8 --rate 1 --dry-run
./environments/sglang0522/.venv/bin/python3 scripts/benchmark.py \
  --profile "${CARDS}g_baseline" --name steady \
  --input-len 1024 --output-len 256 --requests 128 --rate 4 --max-concurrency 32
```

实际调用 `python -m sglang.benchmark.serving --backend sglang-oai-chat`，本地tokenizer、随机数据、固定seed42、工具默认ignore_eos=true以固定输出上限、输出details。该版本CLI提供反向 `--disable-ignore-eos`，本包不传一个不存在的 `--ignore-eos`。Key由环境注入。结果在 `data/results/benchmarks/<UTC>_<name>/metrics.jsonl`、`console.log`、`manifest.json`。

| 组 | 输入/输出token目标 | 关注 |
|---|---|---|
| 短聊天 | 256/128 | HTTP/CPU/launch占比 |
| 长prefill | 4096/128 | TTFT、chunk/CP/PD、传输 |
| 长decode | 256/1024 | TPOT、graph、spec、KV |
| 混合 | 固定JSONL业务提示分布 | 队列和尾延迟；不把均匀随机当真实业务 |
| prefix | 冷/热/不共享前缀 | Radix收益与路由 |

每组先预热，再扫速率1/2/4/8/16，或另扫闭环并发1/4/8/16/32。每点至少128–512条、重复3次，正式容量测量需要更长稳态窗口。保存模型commit、maxlen、实际输入输出、cache状态、并发上限与失败。

指标：成功请求rps、总/输出tokens/s、TTFT、TPOT、ITL、E2E的p50/p95/p99、失败率、KV使用、GPU功耗与CPU。不同工具逐token计数方式可能不同；本包HTTP通用工具明确只测delta近似。`ignore-eos`适合性能固定长度，不适合能力评分。

随机token数据测试服务能力，不能说明知识/代码/推理能力；模型能力见27。通过：结果文件完整、成功数与请求数核对、无未披露重试或掉请求；是否达到目标由22的SLO判定。
