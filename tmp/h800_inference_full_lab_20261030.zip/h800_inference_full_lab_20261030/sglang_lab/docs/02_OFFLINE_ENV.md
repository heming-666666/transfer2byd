# 02 · 无 Docker 的离线环境与完整资产

SGLang 固定0.5.22、CPython3.12、CUDA13 lane。准备机必须 Linux x86_64/Python3.12，并尽量与目标 glibc 相同；不要在 Windows 上解析 Linux GPU 依赖。准备机可以就是当前服务器的允许下载阶段，也可以是一台能访问依赖源的中转 Linux。

## 必须准备的文件

| 位置（相对 sglang_lab） | 内容 |
|---|---|
| `environments/python/assets/cpython-install-only.tar.gz` | 官方 python-build-standalone CPython3.12、x86_64 Linux GNU `install_only` 归档 |
| `environments/python/assets/archive.sha256` | 与官方发布清单核对的真实 SHA256 |
| `environments/sglang0522/requirements.in` | 本包固定主依赖入口 |
| `environments/sglang0522/wheelhouse/*.whl` | 所有传递依赖、GPU后端、router的 Linux wheel |
| `environments/sglang0522/requirements.lock`、`resolution.json` | 实际解析的全部版本与 pip 安装计划 |
| `environments/OFFLINE_MANIFEST.json` | 全资产大小、SHA256、版本清单 |

Python 官方归档见 [astral-sh/python-build-standalone releases](https://github.com/astral-sh/python-build-standalone/releases)。选择3.12而不是最新3.14，选GNU而非musl。下载归档并从官方校验清单获得对应SHA；不要把随机值或仅归档自己算出的值当官方校验。

## 准备阶段

进入本项目，使用准备机现有**3.12** Python。下面两个变量由实际下载资产填入，不是可原样执行的占位值：

```bash
TASK_PY_ARCHIVE=/absolute/downloads/cpython-3.12-linux-x86_64-install_only.tar.gz
TASK_PY_SHA256=REPLACE_WITH_OFFICIAL_SHA256
python3.12 scripts/prepare_offline_env.py \
  --python-archive "$TASK_PY_ARCHIVE" --python-sha256 "$TASK_PY_SHA256"
```

脚本 `pip download --pre --only-binary=:all:` 收集完整依赖，再用 `--no-index --dry-run --ignore-installed` 验证闭包。需要 PyPI、PyTorch cu130 索引、FlashInfer whl/cu130 索引及其实际文件CDN。**GitHub可达不代表这些域都可达**。

如果终端不能下载而网页/镜像/内部制品库能取得文件，先将完整 wheel 放入同一 `wheelhouse/`，再执行：

```bash
python3.12 scripts/prepare_offline_env.py \
  --python-archive "$TASK_PY_ARCHIVE" --python-sha256 "$TASK_PY_SHA256" \
  --use-existing-wheels
```

解析缺包、无匹配 wheel、ABI 不合时必须补齐或在匹配 Linux 上构建 wheel，不能 `pip --no-deps` 绕过。本包主环境包含 `nixl==1.5.0` 与 `nixl-cu13==1.5.0`，以当前 meta wheel 依赖闭包安装；它可能同时包含Cu12后端，由NIXL按Torch CUDA选择。旧Docker注释里的单独 `--no-deps` 不作为本包默认安装方式。

## 目标机只用本地文件构建

将整个项目和准备完成的 `environments/` 转到目标路径，执行：

```bash
bash scripts/bootstrap_offline.sh
./environments/sglang0522/.venv/bin/python3 -m pip check
./environments/sglang0522/.venv/bin/python3 scripts/runtime_check.py --cards 8
```

`bootstrap` 在解压Python前核对归档，在安装前校验所有manifest文件和wheel集合，只创建 `environments/python/cpython/` 与 `environments/sglang0522/.venv/`。移动项目后重建：

```bash
bash scripts/bootstrap_offline.sh --rebuild
```

已安装版本记录为 `installed.freeze.txt`。不得把 vLLM venv 作为 SGLang venv，也不要在系统 Python 上全局 `pip install`。

## 离线 kernel/JIT 的额外条件

wheel齐全不等于运行时kernel一定齐全。先用Triton attention、关闭graph打通模型；然后逐个预热 FA3、FlashInfer、DeepGEMM、DeepEP、spec。需要 `nvcc`、头文件或库时，将匹配 CUDA toolkit **仅用户态文件**装/解压到 `environments/toolkit/cuda-13.0/`；设置此会话 `CUDA_HOME`、`PATH`、本项目 `local_library_dir`，不要装驱动。安装器的具体选项先运行该官方版本 `--help`，只选择toolkit。

所有运行缓存由 `native_environment()` 定向到项目子目录；把经过目标GPU/版本预热的缓存和工具链一并封存。离线时某个可选 backend 缺kernel应明确失败；恢复已验收baseline继续服务，补齐资产后再试。无法在没有H800、没有驱动的制作环境替你生成对应GPU二进制。

下一步：[03 配置与Key](03_CONFIG_AND_KEYS.md)。
