# 16 · 专家激活数、路由分布与负载

前提：01–07的真实聊天验收通过；先准备本章需要的权重。默认8卡，4卡改变量。所有启动都使用05的单profile切换方法；输出放 `data/results/` 或 `shared/results/`。

| 卡数 | Profile |
|---|---|
| 8 | `8g_experts_top8`, `8g_experts_top4` |
| 4 | `4g_experts_top8`, `4g_experts_top4` |



本包Qwen3-30B-A3B-FP8默认每token top8专家。top4实验通过 `--json-model-override-args '{"num_experts_per_tok":4}'` 运行时覆盖，不编辑原checkpoint。

改变top-k改变模型计算与输出分布，属于质量/成本研究，**不属于无损基础设施优化**。EP大小改变专家放置，top-k改变每token参与专家数，二者不能混淆。

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_experts_top8"
```

另一终端采路由（只访问本机私有 `/generate`，不经公共网关）：

```bash
python3 ../shared/scripts/expert_capture.py --layers 48 --experts 128 --topk 8 \
  --output "../shared/results/experts_top8_${CARDS}g.json"
```

切换top4后 `--topk 4` 再采集，文件另存。脚本按base64 little-endian int32、`tokens×layers×topK` 解码并校验长度；如果实际模型config/override与默认不同，先更新layers/topK/experts，形状不符时不硬猜。负ID视为非专家层占位。

报告每层专家token直方图、CV、max/mean和无分配专家；这只是当前提示的路由频率，不是全业务专家利用率或通信耗时。增加数学/代码/中文等不同提示，保存prompt集合与采样设置。

同时在27固定样本上比较top8/top4质量、在21/22比较延迟/goodput、在30观察dispatch/combine。激活更少不保证端到端更快；路由偏斜、padding和all-to-all可能抵消收益。通过：路由形状和值域正确，质量/性能均报告，无伪称“等价”。
