# 22 · SLO、联合达标与goodput

先定义业务目标再测。示例：TTFT≤2000ms、平均TPOT≤100ms、E2E≤60000ms；目标联合达标率≥95%。它们是实验参数，不是此模型/硬件的性能承诺。

请求goodput：**同时成功且满足全部SLO的请求数 ÷ 测量窗口秒数**。失败、超时、客户端过载丢弃均进入请求分母。分别p95达标不保证同一请求联合95%达标。

复制并编辑 `../shared/fixtures/slo.example.json`，保留原模板；例如另存 `config/slo.chat.json`。`clock=send`从实际HTTP发送算TTFT/E2E；`clock=arrival`另外计入客户端计划到达后的排队延迟。两者不能混报。

```bash
CARDS=8
python3 ../shared/scripts/slo_bench.py --client-config config/client.json \
  --slo ../shared/fixtures/slo.example.json --mode open --arrival poisson \
  --rate 4 --requests 128 --concurrency 32 --max-tokens 256 \
  --output "../shared/results/sglang_${CARDS}g_slo_rate4"
```

闭环对照：

```bash
python3 ../shared/scripts/slo_bench.py --client-config config/client.json \
  --mode closed --concurrency 16 --requests 128 --max-tokens 256 \
  --output "../shared/results/sglang_closed_c16"
```

输出目录必须不存在；重复运行换名。Qwen3非思考对照可加 `--extra-json ../shared/fixtures/qwen3_nonthinking.json`，不要加到R1。4卡用同样SLO/负载，对照结果命名4g，且当前引擎必须真实为4g。

## 指标口径

- `requests.jsonl`：计划到达、实际发送、客户端延迟、usage、finish、错误、SLO逐请求判断。
- `summary.json`：联合成功数、goodput rps、成功rps、输出token吞吐、联合达标请求的输出token/s、p50/95/99。
- TTFT为第一个非空reasoning/content HTTP delta；不是最终正文首字，也不是严格GPU首token时间。
- TPOT≈`(最后文本delta时间−首次文本delta时间)/(completion_tokens−1)`。没有usage时无法计算，启用TPOT SLO的请求判不达标；不能用字符数代token。
- 测量窗口从第一个计划到达到最后完成，**包括drain**。预热显式单独进行；未偷偷扣尾部请求。
- 开环保持到达计划，达到客户端inflight上限会记录 `CLIENT_INFLIGHT_LIMIT_DROP`；这说明负载发生端限制，不能直接当GPU最大容量。闭环是完成再发，可能降低表面过载。

容量扫描选择“达到目标联合达标率且失败门槛满足的最高offered rate”；同时画offered rate→goodput/TTFT95/TPOT95/失败率。最终数字用无Profiler轮次；不要把profile开销造成的慢当稳态性能。

更严谨的定义、例子和CPU测试见 [公共07](../../shared/docs/07_SLO_METHOD.md)。
