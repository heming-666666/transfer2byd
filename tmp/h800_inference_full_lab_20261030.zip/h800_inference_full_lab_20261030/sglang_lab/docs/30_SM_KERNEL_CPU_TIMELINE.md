# 30 · 哪些时刻用了多少SM、哪些kernel、CPU提交与graph准备

这是观察“模型为什么快/慢”的深度实验。先完成26，再读 [公共08完整命令与指标](../../shared/docs/08_NSIGHT_SM_KERNEL.md)。

直接记录自定义kernel的SM ID/CTA时间段见 [公共09探针](../../shared/docs/09_SM_CTA_PROBE.md)，包含1卡编译、4/8卡执行和Perfetto输出；探针不是模型kernel的SM实测。

| 你要回答的问题 | 可直接使用的证据 | 不能混淆 |
|---|---|---|
| GPU有多少SM | Torch device properties、NCU launch__sm_count | 设备容量不是某kernel实际活跃SM |
| 某时段SM多忙 | NCU/CUPTI SM active/occupancy/PM sampling | 百分比×SM总数不是瞬时激活SM的实测整数 |
| 启动了多少kernel | Nsys node-level CUDA trace、CUPTI kernel记录 | 一次graph launch可对应多个kernel节点 |
| 哪些kernel耗时 | 每device/rank/stream/name的次数、总/平均/尾部时间 | 多stream区间重叠，sum不等于E2E |
| CPU提交通信耗时 | PyTorch c10d范围、NVTX、nccl调用、CUDA API与关联flow | API壁钟可能含锁/等待，不等于CPU busy或网络传输 |
| GPU通信耗时 | NCCL GPU kernel及stream，P/D传输日志/指标 | NCCL TP通信不代表Mooncake/NIXL KV传输 |
| 等待浪费多少 | CPU同步调用、GPU gap、跨rank尾部等待 | 要核对相关性，不能把空洞全归因CPU |
| graph准备多久 | 启动期warmup/capture/instantiate/upload与rank时间线 | 稳态开启Profiler往往已错过准备阶段 |

先做一个易读的4/8卡示例：

```bash
CARDS=8
./environments/sglang0522/.venv/bin/torchrun --standalone --nproc_per_node="$CARDS" \
  ../shared/scripts/gpu_stages.py --cards "$CARDS" --matrix 2048 --iterations 10 \
  --output "../shared/results/sglang_${CARDS}g_gpu_stages"
```

每rank生成Chrome trace和JSON：CPU异步NCCL提交壁钟、Work.wait主机返回时间、显式device同步等待、默认stream事件区间、graph warmup/对象/capture壁钟、replay提交与GPUstream区间。**这些区间是测量边界，不把它们直接命名为纯nccl wire time或纯instantiate。**

随后用Nsight Systems从真实 `graphs_on` 引擎启动前采集，得到node级kernel与API。选择短窗口和少量请求，统计各rank；再用Nsight Compute在已定位的非NCCL目标kernel/独立复现上采SM/occupancy。NCCL kernel在replay计数器时可能死锁，先用单GPU/离线kernel复现；不要对8卡在线服务无过滤 `ncu --set full`。

最终报告按“启动准备、prefill、decode、TP/EP通信、PD传输、CPU调度/提交、同步等待”列出证据文件、时间范围和统计单位。报告为实测数值保留空字段；没有硬件计数器权限时写 `UNAVAILABLE_COUNTER_PERMISSION`，而不是从显存或utilization猜SM数。
