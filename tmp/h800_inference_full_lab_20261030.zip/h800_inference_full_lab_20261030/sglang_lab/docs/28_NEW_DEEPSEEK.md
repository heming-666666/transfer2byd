# 28 · 更新DeepSeek模型：可尝试分支与H800限制

主线R1蒸馏用于稳定练习，不宣称它是最新DeepSeek。2026-10-30检索到V4/V4.1系列，但“框架release提到优化”和“此H800组合有可复用验证配方”不同。

## 原始V4-Flash：较新且有Hopper参考配方

固定源码Cookbook中的原始 `deepseek-ai/DeepSeek-V4-Flash`，H100 TP8 + Marlin W4A16为upstream verified；不是0731，也不是NVFP4 Blackwell kernel。本包 `8g_modern` 采用自动模型attention选择、Marlin、不启投机；先打通后再 `8g_modern_mtp`。

```bash
python3 scripts/check_model.py --model modern
python3 scripts/run.py engine --profile 8g_modern --dry-run
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine \
  --profile 8g_modern --allow-experimental
```

H800虽同属Hopper仍须核对容量、kernel、NVLink、SM90能力和模型编码依赖。4卡 `4g_modern`只是明确有条件的容量/适配探索，**没有本包4×H800通过保证**；不能为了满足4卡表格就假造可用性。若实际模型加载超过显存或架构拒绝，保留错误，继续4卡小模型实验。

## V4-Flash-0731 / DSpark

使用 `dspark_target` 完整checkpoint，不与原始Flash互换。`8g_dspark`使用Marlin、DSPARK、block-size5，4g为探索。固定Cookbook中该H100单元存在 `verified:false`；因此应先无投机验证checkpoint，再开DSpark，记录实际兼容情况。不能将论坛H100成功个例当本H800保证。

## V4.1-Flash-1017

固定release已有V4.1优化描述，但同commit Cookbook仍写preview `dev-dsv41`、硬件表H200/B200/B300/GB300/MI355X，无H800/H100。权重约511GB还包括很大的Engram查表部分；CPU offload会引入RAM/NUMA/页表/带宽条件，不只是GPU总显存计算。

本包 `4g_latest/8g_latest` 可dry-run供研究，但真实启动会被 `blocked_reason` 拦截。不要通过强加Blackwell `flashinfer_mxfp4`、复用vLLM `--engram-config` 或删掉兼容检查，声称SGLang已验证H800正常。

若后续官方提供明确H800配方：另建环境子目录，固定commit/镜像digest和依赖，复制新profile、更新相应attention/MoE/Engram配置，记录来源；移除拦截前先完成模型与kernel最小探针。SGLang Engram环境变量与vLLM配置并非互通。Docker可用时preview镜像也只能解决用户态依赖，不能给H800增加硬件指令。

通过标准与主线一致：真实加载、最终正文、工具/格式（若声称支持）、多轮与内网、质量和性能；新模型未适配成功仍可完成其他4/8卡学习实验，状态如实记录。
