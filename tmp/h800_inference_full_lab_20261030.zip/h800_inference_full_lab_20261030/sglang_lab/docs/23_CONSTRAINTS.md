# 23 · 提示、JSON、Schema、正则与EBNF

先切换到 `8g_bf16`/`4g_bf16`（Qwen3-8B）并验收。默认xgrammar grammar backend。结构约束与模型思考可能交互，优先用足够输出预算和模型支持的非思考配置做实验。

```bash
python3 scripts/structured_output.py --mode prompt
python3 scripts/structured_output.py --mode json_object
python3 scripts/structured_output.py --mode json_schema
python3 ../shared/scripts/constraints.py --framework sglang --client-config config/client.json \
  --mode regex --output ../shared/results/sglang_regex.json
python3 ../shared/scripts/constraints.py --framework sglang --client-config config/client.json \
  --mode grammar --output ../shared/results/sglang_grammar.json
```

Schema为对象，恰好 `answer:string` 与 `topic:enum[infra,other]`，required且additionalProperties=false；应用端仍验证字段与枚举。regex实验要求完整匹配YES/NO；EBNF `root ::= "YES" | "NO"`。

| 模式 | 约束在哪 | 验收 |
|---|---|---|
| prompt | 语言指令 | 可能失败，统计实际格式成功率 |
| json_object | JSON语法 | 可解析不代表字段/枚举正确 |
| json_schema | 受支持Schema子集 | 应用端再次验证Schema |
| regex | SGLang顶层 `regex` | `re.fullmatch`，保留原始空白 |
| EBNF | SGLang顶层 `ebnf` | 用规定语法/解析器验收 |
| tool | 工具参数Schema | 必须先校验再执行白名单函数 |

官方OpenAI SDK调用时，把非标准参数放 `extra_body={'regex':...}`；HTTP直发JSON时就是顶层字段。vLLM的对应字段是 `structured_outputs.regex/grammar`，不能直接照搬。

重复每项100条、加入诱导输出额外字段/无效枚举/超长正文的提示，记录格式失败、业务语义失败、解码速度、首请求grammar编译与后续缓存成本。约束只保证受支持语法范围；不支持的Schema关键词会报错或不生效，先用小Schema验证。输出截断、正文为空、工具参数JSON无效均是失败，不删掉失败样本。

语义实验：让模型判断正确topic或回答数学问题，另作正确性评分；合法JSON里也能放错误答案。不得为了模型能力榜单给选择题施加与官方协议不同的额外答案约束后仍声称原榜单可比。
