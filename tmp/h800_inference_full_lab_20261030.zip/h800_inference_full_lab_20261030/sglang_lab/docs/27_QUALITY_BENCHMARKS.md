# 27 · 常见模型能力benchmark：离线数据与可复现评分

性能benchmark测服务速度；本章测模型输出是否正确。主工具EvalScope1.14.1 API生成式评测，补充lm-evaluation-harness0.4.13。两者各自venv，不装进推理venv。

完整依赖/数据准备按 [公共06](../../shared/docs/06_QUALITY_DATASETS.md)。必须先准备真实数据commit和哈希；运行阶段不允许临时下载。

| 任务 | 能力 | 指标/可比性注意 |
|---|---|---|
| GSM8K | 数学应用题 | 数值准确率；本包默认0-shot，官方工具默认可能4-shot |
| MATH-500 | 较难数学 | 最终答案等价，固定抽取规则/输出预算 |
| MMLU-Pro | 多学科推理选择题 | 本包API生成选项；与likelihood MMLU不等价 |
| IFEval | 可验证指令遵循 | prompt/inst strict/loose；不额外施加语法改变原题要求 |
| CEval | 中文学科知识 | 子科目与聚合方式记录；数据布局/名称按工具注册核验 |
| HumanEval/MBPP/LiveCodeBench | 代码 | 生成可走本API，执行评分只在隔离VM/sandbox；root不直接执行 |
| LongBench/RULER | 长上下文 | 单独准备对应工具/模板/长度，严禁把超长截断后仍算原协议 |
| MT-Bench/AlpacaEval | 主观回答比较 | 需要固定judge与费用/网络；不可离线时标未执行，不代造judge分数 |

已准备评测环境和数据后，从 `sglang_lab/`：

```bash
../shared/environments/evalscope1141/.venv/bin/python3 ../shared/scripts/evalscope_run.py \
  --client-config config/client.json --dataset-config ../shared/fixtures/datasets.json \
  --tasks gsm8k ifeval --limit 10 --max-tokens 4096 --concurrency 4 \
  --output ../shared/results/sglang_quality_smoke
```

10条只是流程验收。正式评测改 `--limit 0`、新输出目录，记录完整样本数、失败/截断/空正文、fewshot和思考模式。R1长思考可能要更大输出预算与更长context_length；改变这两项后对照组也相应记录，避免从length截断误判量化/投机错误。

另一个工具对照：

```bash
../shared/environments/lmeval0413/.venv/bin/python3 ../shared/scripts/lm_eval_run.py \
  --client-config config/client.json --task gsm8k --limit 10 \
  --output ../shared/results/sglang_lmeval_gsm8k_smoke
```

lm-eval聊天接口仅适合generate任务；classicMMLU/HellaSwag等常需prompt logprobs，不能通过chat API命令就称原协议测通。需要该类任务时走本机私有completions/logprobs能力探针或独立本地hf/vllm backend，见公共06。

本包原创3条smoke也可作快速回归：`python3 ../shared/scripts/quality_smoke.py --client-config config/client.json --output ../shared/results/sglang_tiny.json`。其得分不命名GSM8K或MMLU。

通过：工具退出成功、无未披露错误、样本数匹配、实际评分文件/逐样本回答可追溯。没有H800实测分数时保持NOT_RUN，不给虚构“应达到XX分”。量化/专家top-k/投机/backend对照必须使用相同任务协议。
