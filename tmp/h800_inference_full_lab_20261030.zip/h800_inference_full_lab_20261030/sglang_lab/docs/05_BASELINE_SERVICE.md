# 05 · 模型服务启动、就绪与验收

前提：01–04通过；所选GPU空闲；配置内网IP正确；manifest已封装安装；`lab`权重完整。默认8卡，4卡把变量改为4。

终端A（前台运行，首次不要加后台守护）：

```bash
CARDS=8
python3 scripts/run.py engine --profile "${CARDS}g_baseline" --dry-run
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_baseline"
```

实际引擎、GPU、profile写入 `data/runtime/engine.plan.json`，进程身份写入 `data/runtime/processes/`。图关闭，最大上下文8192，最大running请求16，chunked prefill2048，静态内存比例0.80。首次JIT/权重加载可能耗时，等待真实ready。

终端B：

```bash
./environments/sglang0522/.venv/bin/python3 scripts/wait_ready.py --target engine --timeout 1800
./environments/sglang0522/.venv/bin/python3 scripts/run.py gateway --mode integrated
```

终端C：

```bash
python3 scripts/smoke_test.py --with-generation
python3 scripts/chat.py --message '用三句话解释 TP 与 DP 的区别。'
python3 scripts/chat.py
```

`chat`交互中先问“我用8张H800”，再问“我刚才说有多少张卡”；观察客户端发送的messages与历史，不要求服务端自动保存上下文。`max_tokens`同时覆盖reasoning和最终内容。R1若只输出reasoning、`finish_reason=length`且正文空，增大输出预算/减少问题长度，不能把HTTP200计为功能通过。

| 验收 | 必需证据 |
|---|---|
| 错误/缺失Key | 401 |
| `/v1/models` | 正确别名 `deepseek-local` |
| 非流式 | 有最终content，不只有reasoning |
| 流式 | UTF-8正确、最终正文、[DONE]、用量（版本支持时） |
| 多轮 | 第二轮真实携带历史并得到相关回答 |
| 另一台内网机器 | 以上同样通过，不只服务器自测 |

## 所有后续集成实验的切换方法

网关可保持运行，只停旧integrated引擎；在终端A启动新的profile，终端C等ready后跑smoke/bench。同一时刻只有一个integrated profile。

```bash
python3 scripts/run.py stop engine
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_graphs_on"
```

下一终端继续：

```bash
python3 scripts/wait_ready.py
python3 scripts/smoke_test.py --with-generation
```

从PD切回integrated时先 `run.py stop all`，按本章重新起引擎和integrated网关。日志可在启动命令末尾重定向到 `data/logs/<case>.log 2>&1`；目录由configure创建。进程停止只针对本包保存的PID namespace/启动时间/进程组，不使用全局pkill。
