# 26 · PyTorch Profiler、每rank trace与Perfetto

先无Profiler完成基线和稳定吞吐；Profiler用于短窗口归因。启动 `8g_profile/4g_profile`（Qwen3-8B、graph关闭），完成ready与网关后：

```bash
python3 ../shared/scripts/profile_capture.py --framework sglang --target engine \
  --action capture --requests 6 --max-tokens 128
```

脚本访问本机admin保护的 `/start_profile`，设置CPU/GPU、stack、shapes及服务器绝对输出目录，发几条请求，finally调用 `/stop_profile`。trace写到 `data/traces/engine/`（多rank文件名由框架决定）；不能只分析rank0。

PD时按固定版本官方要求，**P/D分两轮采集**。两侧引擎和router均正常运行；第一轮只对P开启profiler，经公共网关发请求后停止P；确认停止后，第二轮只采D。本包 `capture` 动作会自动完成start→公共请求→finally stop：

```bash
# 已启动PD服务；一次只执行一个，等前一个结束后执行后一个
python3 ../shared/scripts/profile_capture.py --framework sglang --target prefill \
  --action capture --requests 6 --max-tokens 128
python3 ../shared/scripts/profile_capture.py --framework sglang --target decode \
  --action capture --requests 6 --max-tokens 128
```

两个轮次不能当作同一次请求的同步P/D时间线；若要关联真实KV发送/接收，另做Nsight/传输日志采集并核对request ID和时钟。`profile_capture.py` 的 `capture` 动作本身不会阻止另一终端开启profiler，操作者必须确保串行。不能假设router trace能显示两侧GPU活动。官方 `--profile-prefill-url` / `--profile-decode-url` 也互斥，依据见固定快照 `references/upstream/docs/docs/developer_guide/benchmark_and_profiling.mdx`。

```bash
python3 ../shared/scripts/trace_summary.py data/traces/engine/ACTUAL_TRACE.json.gz \
  --top 30 --output data/results/trace_summary.json
```

`ACTUAL_TRACE`换成实际文件。汇总按category/name输出调用次数和dur总和；多stream/多GPU、嵌套CPU区间会重叠，dur总和不是E2E或self CPU time。Perfetto看CPU线程、CUDA runtime、GPU stream、关联flow和空洞，再用Nsight做硬件计数器。

内网可视化的完整离线构建、浏览器打开方法见 [公共05](../../shared/docs/05_PERFETTO_OFFLINE.md)。不能只写“访问ui.perfetto.dev”就假设受限环境可用，也不能只拷贝index.html。

启动阶段的CUDA Graph准备、SM与kernel深度分析见30/公共08；服务启动后才开启PyTorch Profiler通常已经错过capture阶段。最终性能成绩必须再运行无Profiler基准。
