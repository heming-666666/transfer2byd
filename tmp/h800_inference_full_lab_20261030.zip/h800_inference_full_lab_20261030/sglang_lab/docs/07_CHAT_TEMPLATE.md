# 07 · 对话格式、编码、reasoning与模板

公共请求使用OpenAI式 `messages=[{role,content},...]`，`model`固定别名，UTF-8 JSON。让服务端使用权重自带tokenizer/chat template。**不要先手工拼特殊token再发送messages**，否则可能重复套模板、重复BOS/EOS或错开assistant提示。

| 项目 | 规则 |
|---|---|
| roles | `system/user/assistant/tool`按模型能力使用；R1按其模型卡提示风格，不强行套工具协议 |
| reasoning | 单独显示/记录 `reasoning`或`reasoning_content`；客户端下一轮默认只加入最终assistant正文 |
| Qwen3 thinking | 用模型支持的 `chat_template_kwargs.enable_thinking` 做对照；不要把它强加给R1 |
| tokenizer | 和目标权重同commit；draft也必须兼容相同token ID |
| 工具轮次 | 保存原assistant tool_calls与每个tool_call_id，下一轮tool消息要对应 |
| 约束输出 | 提示约束、JSON语法、Schema约束、应用语义验证分别判断，见23 |

检查本地模板，不触发联网：

```python
from transformers import AutoTokenizer
from pathlib import Path
p = Path('../shared/models/DeepSeek-R1-Distill-Qwen-32B').resolve()
t = AutoTokenizer.from_pretrained(p, local_files_only=True)
messages = [{'role':'user','content':'用一句话解释KV Cache。'}]
rendered = t.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
ids = t.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
print(repr(rendered))
print('prompt_tokens=', len(ids), 'bos=', t.bos_token_id, 'eos=', t.eos_token_id)
```

用项目venv运行此片段；不把含敏感业务正文的模板dump发到公共日志。将prompt token数与实际usage对照：chat template、BOS、tools、system都会增加token。性能随机文本长度与最终chat prompt长度可能不同，需记录实际用量。

约束JSON实验建议切到 `8g_bf16`/`4g_bf16` 的Qwen3-8B，再按23操作，避免R1长reasoning在很小token预算下被截断。应用层校验是最终成功条件，HTTP200不保证结构或事实正确。
