# 25 · 投机解码：NGRAM、EAGLE3、MTP、DFlash与DSpark

这里的“投机编码”对应推理中的**投机解码（speculative decoding）**。draft提出多个token，target验证并接受前缀；省掉的target步数必须抵过draft、验证、同步、KV与调度成本。

| 方法 | 本包配对/入口 | 4/8卡配置与限制 |
|---|---|---|
| NGRAM | Qwen3-8B，无额外模型 | `4g_ngram/8g_ngram`；CUDA、无AttentionDP，运行时会调整overlap/混合prefill |
| EAGLE3 | Qwen3-8B + AngelSlim/Qwen3-8B_eagle3 | `4g_eagle3/8g_eagle3`；steps3/topk1/draft tokens4 |
| DFlash | Qwen3-4B + z-lab/Qwen3-4B-DFlash-b16 | `4g_dflash/8g_dflash`；验证窗口16；与 `dflash_base` 比较 |
| MTP | 原始DeepSeek-V4-Flash的内置next-token head | `8g_modern_mtp`（4g仅条件探索）；SGLang算法参数EAGLE，1/1/2 |
| DSpark | DeepSeek-V4-Flash-0731内置/匹配head | `8g_dspark`（4g条件探索）；block-size5；H100/H800配方未在此包实测，不能保证 |
| 前沿 | UNO、adaptive draft window、block verification、LiLiCorr | 需要特定adapter/head/算法支持；不编造未发布checkpoint地址 |

## 可先运行的小模型实验

准备dense+eagle3_draft，或dflash_target+dflash_draft的完整匹配快照。启动：

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_ngram"
```

按05分别切换bf16→ngram→eagle3（同target），dflash_base→dflash（另一个同target）。不要把8B/4B的性能当相同目标对照。4卡改变量即可。投机模型的TP兼容性也须检查；若某draft不支持TP8，先记录不支持，再在独立较小TP×DP布局实验，不在报告里仍写TP8。

每项先27同一小样本质量回归，再21/22扫并发1/4/16、输出256/1024；NGRAM增加重复文本/代码拷贝与不重复负载各一组。保存真实 `/metrics` 中spec/draft/accept相关指标及版本定义，计算draft接受数/提出数、平均接受长度、target验证次数、draft/verify耗时、端到端speedup、额外显存。

平均接受长度可能**包含bonus token**，不能与单纯接受draft比例混称；高接受率也不保证加速，高batch时target已很高效，draft可能使吞吐下降。报告p95与goodput，不只单请求tokens/s。

## 正确性与采样

先temperature0，保持tokenizer、target精度、backend与停止条件。比较最终正文、finish、任务分数；并行浮点数值可能使个别token不同，不直接用相同seed作为分布等价证明。温度>0需核对rejection sampling/verification条件、进行多样本统计与任务质量验证；不要人为放宽accept阈值后继续宣称无损。

本包拒绝非零SIMULATE类环境变量；不使用dummy权重、固定接受长度或fake backend充当正确性/性能结果。NGRAM/DFlash与PP、AttentionDP等限制按固定版本执行；后续混合组合先查源码。

MTP/DSpark新DeepSeek的完整硬件门槛见28。V4.1在vLLM的 `method=mtp`会被拒绝，应按其DSpark机制配置，不能用通用MTP参数绕过模型检查。
