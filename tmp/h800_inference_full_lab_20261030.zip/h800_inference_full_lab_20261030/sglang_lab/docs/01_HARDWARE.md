# 01 · 硬件、驱动、内存与内网预检

目标：确认“8 张 H800”具体意味着什么。云主机可能有 PCIe/SXM 差异、cgroup 内存限制、受限计数器、缺失 RDMA 或不同 GPU 可见顺序。

在 `sglang_lab/` 执行：

```bash
python3 scripts/preflight.py
nvidia-smi topo -m
nvidia-smi nvlink --status
```

结果：`data/reports/preflight.json`。`docker` 不存在只影响可选路线，不影响原生路线。保存 GPU UUID、每卡真实显存、驱动、系统架构、glibc、RAM/cgroup、memlock、端口和路由。

| 检查 | 通过条件 | 不通过时 |
|---|---|---|
| OS/架构 | Linux x86_64，满足 wheel 的 manylinux/glibc 要求（本方案通常至少 glibc2.28） | 换匹配系统镜像；不能靠升级 venv 改 glibc |
| 驱动 | 可加载 CUDA13 用户态运行时；CUDA13 通常要求 R580 或更新驱动分支 | 平台提供匹配驱动；不要在虚拟云容器里自行替换宿主机内核驱动 |
| GPU | 8 卡主线可见0–7；4卡可见0–3；sm90/H800 | 先核对云平台挂载；不要从商品名猜显存 |
| GPU空闲 | 所选卡没有其他占用显存/长任务 | 不杀其他租户/作业；选择空闲组 |
| RAM | 至少能容纳权重加载峰值、进程、页缓存；看 cgroup 而不只看 `free` | 先小模型，减少进程/预加载；大 Engram 模型另算 |
| NVLink/P2P | `topo` 明确 NV# 链接；Torch P2P 实测通过 | P2P 可经 PCIe；不存在 NVLink 时不能宣称 NVLink 性能 |
| 网络 | 客户端到服务器内网 IP、目标 public port 可达 | 同网关不代表安全组/ACL/路由允许，检查云侧规则 |
| `/dev/shm`/memlock | 能满足多进程 NCCL/注册内存需求 | 先记录限制，再使用平台允许的配置；不自动改系统 |

`nvidia-smi` 显示的 CUDA Version 是驱动能力上限提示，不是本 venv 的 `torch.version.cuda`。二者都记录。

完成环境安装后再执行真实 GPU 验收：

```bash
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/runtime_check.py --cards "$CARDS"
./environments/sglang0522/.venv/bin/torchrun --standalone --nproc_per_node="$CARDS" scripts/gpu_probe.py
./environments/sglang0522/.venv/bin/python3 ../shared/scripts/topology.py --cards "$CARDS" --output data/reports/topology.json
```

4 卡改 `CARDS=4`。NCCL 探针必须所有 rank 完成且数值正确；runtime_check 只通过 import/matmul 仍未证明模型能加载。若 `import nixl` 因动态库或计数器权限失败，先保留完整错误；不能通过卸掉依赖把它记为通过。

下一步：[02 离线环境](02_OFFLINE_ENV.md)。
