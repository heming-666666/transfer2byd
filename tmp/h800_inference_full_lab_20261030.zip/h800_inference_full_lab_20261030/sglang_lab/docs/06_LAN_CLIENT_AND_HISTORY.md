# 06 · 同内网的另一台机器调用与会话记录

服务端只需开放public9000，客户端不接触GPU、engine/admin Key、PD端口。云安全组/ACL必须允许客户端来源到服务器TCP9000；同网关不等于端口一定可达。

在客户端建立一个独立目录，例如 `/data/llm-client/sglang/`，按原相对结构复制：

- `scripts/chat.py`、`scripts/client_lib.py`、`scripts/common.py`、`scripts/smoke_test.py`
- `config/client.json`（服务端configure生成，只含public Key）
- 创建 `data/conversations/`、`data/results/`。普通客户端只需Python标准库，无需Torch/模型。

在客户端此目录：

```bash
python3 scripts/smoke_test.py --with-generation
python3 scripts/chat.py --message '你好，请解释一下 KV Cache。'
python3 scripts/chat.py
```

使用服务端返回的会话ID恢复，使用 `chat.py --resume data/conversations/<session>/conversation.json`，参数见 `--help`；记录路径是客户端自己的 `data/conversations/<session>/conversation.json` 与 `turns.jsonl`，不会自动回传服务器文件系统。

## 使用OpenAI兼容协议（stdlib示例，不需要安装SDK）

```python
import json, urllib.request
from pathlib import Path
c = json.loads(Path('config/client.json').read_text())
messages = [{'role': 'user', 'content': '我有8张H800，请记住这个数量。'}]
def ask(history):
    q = urllib.request.Request(
        c['base_url'].rstrip('/') + '/chat/completions',
        json.dumps({'model': c['model'], 'messages': history,
                    'max_tokens': 4096, 'temperature': 0.6, 'stream': False}).encode(),
        {'Authorization': 'Bearer ' + c['api_key'], 'Content-Type': 'application/json'})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(q, timeout=600) as f:
        return json.load(f)['choices'][0]['message']
m = ask(messages)
assert m.get('content'), '最终正文为空；检查输出预算与reasoning'
messages.append({'role': 'assistant', 'content': m['content']})
messages.append({'role': 'user', 'content': '我刚才说有多少张卡？'})
print(ask(messages)['content'])
```

`messages`是会话历史，`max_tokens`是本次输出预算，服务端最大上下文还要容纳模板和输入。超出时选择应用侧截断/摘要策略并记录；不要悄悄丢掉system或工具调用ID。

流式SSE必须按UTF-8事件读取并等 `[DONE]`；断开连接不等于成功。标准SDK在客户端自己子目录建venv、准备openai wheel即可；本包脚本不依赖SDK。Key读取文件/环境，避免写进源代码、shell历史、工单和会话正文。
