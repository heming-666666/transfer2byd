# SGLang · 按编号部署与实验

默认 8 卡；把命令中的 `CARDS=8` 改为 `4` 即可读取对应 profile。每个新实验都先完成基础真实聊天验收。

| 顺序 | 文件 | 内容 |
|---|---|---|
| 01 | [01_HARDWARE.md](docs/01_HARDWARE.md) | 宿主机、4/8 卡与网络预检 |
| 02 | [02_OFFLINE_ENV.md](docs/02_OFFLINE_ENV.md) | 原生离线环境、完整资产闭包 |
| 03 | [03_CONFIG_AND_KEYS.md](docs/03_CONFIG_AND_KEYS.md) | 配置、Key、端口 |
| 04 | [04_MODEL_FILES.md](docs/04_MODEL_FILES.md) | 模型选择、commit、完整权重 |
| 05 | [05_BASELINE_SERVICE.md](docs/05_BASELINE_SERVICE.md) | 启动、就绪、真实功能验收 |
| 06 | [06_LAN_CLIENT_AND_HISTORY.md](docs/06_LAN_CLIENT_AND_HISTORY.md) | 另一台内网机器、多轮会话 |
| 07 | [07_CHAT_TEMPLATE.md](docs/07_CHAT_TEMPLATE.md) | messages、tokenizer、reasoning |
| 08 | [08_TP.md](docs/08_TP.md) | 张量并行 |
| 09 | [09_DP.md](docs/09_DP.md) | 整模型 DP 与 Attention DP |
| 10 | [10_PP.md](docs/10_PP.md) | 流水线并行 |
| 11 | [11_CP_DCP.md](docs/11_CP_DCP.md) | 上下文并行 |
| 12 | [12_SP.md](docs/12_SP.md) | Qwen3 LayerNorm SP 与等价性 |
| 13 | [13_EP.md](docs/13_EP.md) | 专家并行、DeepEP |
| 14 | [14_WEIGHT_QUANT.md](docs/14_WEIGHT_QUANT.md) | BF16/FP8/AWQ |
| 15 | [15_KV_QUANT.md](docs/15_KV_QUANT.md) | KV FP8 与校准 |
| 16 | [16_EXPERT_ACTIVATION.md](docs/16_EXPERT_ACTIVATION.md) | 专家 top-k、路由捕获 |
| 17 | [17_PD.md](docs/17_PD.md) | P4D4/P2D2、Mooncake/NIXL |
| 18 | [18_ATTENTION_BACKENDS.md](docs/18_ATTENTION_BACKENDS.md) | Triton/FA3/FlashInfer |
| 19 | [19_CUDA_GRAPH.md](docs/19_CUDA_GRAPH.md) | 关闭/捕获/replay/准备成本 |
| 20 | [20_KV_SCHEDULER.md](docs/20_KV_SCHEDULER.md) | KV pool、Radix、调度和 chunk |
| 21 | [21_PERFORMANCE_BENCH.md](docs/21_PERFORMANCE_BENCH.md) | 官方 benchmark 与负载矩阵 |
| 22 | [22_SLO_GOODPUT.md](docs/22_SLO_GOODPUT.md) | 联合 SLO、开放/闭环、容量曲线 |
| 23 | [23_CONSTRAINTS.md](docs/23_CONSTRAINTS.md) | JSON Schema、regex、EBNF |
| 24 | [24_TOOLS.md](docs/24_TOOLS.md) | 工具调用与应用端执行 |
| 25 | [25_SPECULATIVE.md](docs/25_SPECULATIVE.md) | NGRAM/EAGLE3/MTP/DFlash/DSpark |
| 26 | [26_PROFILER_PERFETTO.md](docs/26_PROFILER_PERFETTO.md) | PyTorch trace 与内网 Perfetto |
| 27 | [27_QUALITY_BENCHMARKS.md](docs/27_QUALITY_BENCHMARKS.md) | GSM8K/MMLU-Pro/IFEval 等 |
| 28 | [28_NEW_DEEPSEEK.md](docs/28_NEW_DEEPSEEK.md) | V4/V4.1 的 H800 条件边界 |
| 29 | [29_OPERATIONS_OFFLINE_DOCKER.md](docs/29_OPERATIONS_OFFLINE_DOCKER.md) | 生命周期、迁移、离线再验收 |
| 30 | [30_SM_KERNEL_CPU_TIMELINE.md](docs/30_SM_KERNEL_CPU_TIMELINE.md) | SM、kernel、CPU 提交、通信与 graph准备 |
| 31 | [31_COMPLETE_RUN.md](docs/31_COMPLETE_RUN.md) | 一轮8/4卡验收、SLO/能耗、Graph与运行期归因 |
