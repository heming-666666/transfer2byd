# 99 · 版本、官方来源与已发现的差异

核对日期 2026-10-30；不自动跟随 `main/latest/dev`。链接所对应的新版本可能继续变化，执行时以包内固定版本及本机 `--help` 为准。

R2（2026-10-31）额外核对同一固定commit的decode CUDA Graph runner，补存到SGLang `references/upstream/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py`，用于确认capture snapshot固定文件名和每rank trace边界。新增设备功率与allocator说明分别参考 [NVIDIA-SMI](https://docs.nvidia.com/deploy/nvidia-smi/index.html)、[NVIDIA查询说明](https://nvidia.custhelp.com/app/answers/detail/a_id/3751/~/useful-nvidia-smi-queries)、[PyTorch内存快照](https://docs.pytorch.org/docs/stable/torch_cuda_memory)。公开文档会更新；实际执行保存本机driver/Torch版本及查询字段。它们不构成用户H800的测量结果。

| 内容 | 固定点/官方来源 | 本包如何使用 |
|---|---|---|
| SGLang | [v0.5.22 release](https://github.com/sgl-project/sglang/releases/tag/v0.5.22)，commit `baa9befa381511cd4d56f83980951e5a45fffc6d` | 主框架 |
| 实际参数 | [arg_groups/fields](https://github.com/sgl-project/sglang/tree/v0.5.22/python/sglang/srt/arg_groups/fields) | 随包保存选择性 Apache-2.0 源码快照；静态检查 profile flags |
| 依赖 | [pyproject.toml](https://github.com/sgl-project/sglang/blob/v0.5.22/python/pyproject.toml) | Torch2.14.1、FlashInfer0.7.1、kernel0.4.9；解析完整依赖闭包 |
| SGLang router | [gateway pyproject](https://github.com/sgl-project/sglang/blob/v0.5.22/sgl-model-gateway/bindings/python/pyproject.toml) | `sglang-router==0.3.2`，真实 Rust router |
| PD | [disaggregation fields](https://github.com/sgl-project/sglang/blob/v0.5.22/python/sglang/srt/arg_groups/fields/disagg.py) | Mooncake TCP 主线，NIXL/UCX 条件对照；P/D checksum |
| V4 方案 | [固定 Cookbook config](https://github.com/sgl-project/sglang/blob/v0.5.22/docs/src/snippets/configs/deepseek-ai/deepseek-v4.jsx) | 原始 V4-Flash H100 TP8 Marlin 有 upstream verified；H800 仍需实测 |
| V4.1 限制 | [固定 Cookbook](https://github.com/sgl-project/sglang/blob/v0.5.22/docs/cookbook/autoregressive/DeepSeek/DeepSeek-V4_1.mdx) | 文档仍写 preview 且硬件表无 H800，与 release 新增优化描述存在不一致，不能据此保证 H800 |
| SGLang benchmark | [serving.py](https://github.com/sgl-project/sglang/blob/v0.5.22/python/sglang/benchmark/serving.py) | `sglang.benchmark.serving`、`sglang-oai-chat`、输出 JSONL |
| vLLM | [v0.32.0](https://github.com/vllm-project/vllm/releases/tag/v0.32.0) | 独立补充环境；不能共用 SGLang venv |
| vLLM 并行 | [parallel.py](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/config/parallel.py) | PCP 扩展 rank，DCP 复用 rank |
| vLLM FP8 KV | [固定 quantized_kvcache 文档](https://github.com/vllm-project/vllm/blob/v0.32.0/docs/features/quantization/quantized_kvcache.md) | 旧 `--calculate-kv-scales` 已不能照抄；默认1.0与数据集校准分开 |
| NIXL | [NVIDIA NIXL 1.5.0 PyPI](https://pypi.org/project/nixl/1.5.0/) | meta wheel 支持 CUDA 后端自动选择；显式纳入 `nixl-cu13==1.5.0`。旧 Docker 注释与现行包说明不完全一致，以实际 wheel metadata/运行 import 为准 |
| 投机 | [SGLang spec fields](https://github.com/sgl-project/sglang/blob/v0.5.22/python/sglang/srt/arg_groups/fields/spec.py)、[vLLM speculative.py](https://github.com/vllm-project/vllm/blob/v0.32.0/vllm/config/speculative.py) | NGRAM/EAGLE3/MTP/DFlash/DSpark，按目标和 draft 配对 |
| 能力工具 | [EvalScope v1.14.1](https://github.com/modelscope/evalscope/tree/v1.14.1)、[lm-eval v0.4.13](https://github.com/EleutherAI/lm-evaluation-harness/tree/v0.4.13) | API 生成式评测与离线数据准备 |
| Perfetto | [官方 UI build](https://perfetto.dev/docs/contributing/build-instructions) | 准备机编译 `ui/out/dist`，整体搬入内网 |
| Nsight Systems | [UserGuide](https://docs.nvidia.com/nsight-systems/UserGuide/)、[AnalysisGuide](https://docs.nvidia.com/nsight-systems/AnalysisGuide/) | graph/node 时间线、API/kernel/内存统计 |
| Nsight Compute | [ProfilingGuide](https://docs.nvidia.com/nsight-compute/ProfilingGuide/index.html)、[ComputeTriage](https://docs.nvidia.com/nsight-compute/ComputeTriage/) | SM/occupancy、waves、内存与计算管线计数器 |
| CUPTI | [官方指标说明](https://docs.nvidia.com/cupti/main/main.html) | SM active 是时间与空间平均，不能直接还原瞬时 SM 个数 |

## 明确避免的过期写法

- SGLang 0.5.22：`--disable-cuda-graph`、`--sampling-backend` 对应字段已是 `no_cli=True`，不作为公开 CLI 使用。本包用 `--cuda-graph-backend-decode/prefill disabled`；采样 backend 由该版本解析。
- SGLang `--dp-size` 是整模型 DP；Attention DP 用 `--attn-dp-size`，不再混用旧 `--enable-dp-attention`。
- SGLang `deepseek-r1` 与 vLLM `deepseek_r1` 的 parser 名不同。结构化输出的 regex/grammar 字段也不同。
- vLLM 没有本包可泛用的 `--sp-size`。SP 使用公共等价性实验，或 SGLang Qwen3 专用开关。
- H800 不自动等价于 Blackwell MXFP4 硬件 kernel。权重存储格式、反量化计算方式与硬件原生 FP4 是三个不同概念。

源码快照保留原版权，SGLang/vLLM 组件按各自 Apache-2.0 文件标注；权重、数据集、Nsight 和其他二进制需分别遵守提供方许可。包内指南和自写脚本用于本实验；不把上游成绩当成本机成绩。
