# 90 · 验证报告与实机待验收项

记录时间：2026-10-31T05:04:03.213638+00:00；R2修订日期2026-10-31。固定版本：SGLang0.5.22、vLLM0.32.0；默认8卡，含4卡对照。

## 已执行

| 检查 | 结果 | 证据 |
|---|---|---|
| SGLang CPU集成 | 26项PASS | `tests/reports/sglang_cpu.log` |
| vLLM CPU集成 | 22项PASS | `tests/reports/vllm_cpu.log` |
| 公共CPU/HTTP集成 | 16项PASS | `tests/reports/shared_cpu.log` |
| R2验收/时钟/能耗CPU集成 | 27项PASS | `tests/reports/measurement_cpu.log` |
| 代码、shell、文档、参数与配置 | PASS | `tests/reports/static_validation.json` |
| 源码来源与固定版本 | 已核对/保留快照 | 两框架 `references/SOURCE_INDEX.json`、总 `references.json` |
| 文件/ZIP完整性 | SHA256清单与ZIP CRC检查 | `PACKAGE_MANIFEST.sha256`、外部ZIP的`.sha256` |

合计 **91项CPU测试通过**。覆盖真实本地mock HTTP的鉴权/路由/Unicode SSE/usage/多轮存储、文档所用smoke参数、私密Key隔离、进程组身份保护、4/8卡资源约束、联合SLO与开环丢弃分母、KV refcount/COW/OOM、Nsight SQLite并集、SM区间扫描、校准TP映射与错误scale拒绝、两框架捕获期profiler及vLLM memory配置。

R2另验证六项public验收/多轮校验码、reasoning-only与缺DONE不通过、缺usage时token指标为null、非法SLO/协议覆盖拒绝、同机时钟/跨主机拒绝、恒定及斜坡功率的裁剪积分、缺测/长gap/NaN/UUID变化/时间重复的处理，以及能耗CLI不覆盖原结果。功率数据均是测试临时目录里的CPU fixture，**不是H800采样**。

静态检查包含所有预置profiles的dry-run、固定SGLang源码中公开CLI字段、两框架官方benchmark实际parser参数、Markdown本地链接、bash代码块和Python代码块语法、bootstrap shell语法。实际数量见JSON；dry-run不分配GPU、不加载权重。

CPU执行环境：Python `3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]`，`Linux-6.18.57-x86_64-with-glibc2.39`。不以此推断用户云镜像ABI相同。

## 尚未执行：不能写成通过

| 项目 | 状态 | 目标机下一步 |
|---|---|---|
| 原生依赖下载/完整解析/安装 | NOT_RUN（ZIP未附大体积依赖资产） | 各框架01/02准备wheelhouse、lock、manifest并bootstrap |
| H800 CUDA/NCCL/NVLink | NOT_RUN | 硬件预检、runtime_check、4/8-rank gpu_probe |
| 真实权重加载与输出 | NOT_RUN | 先lab baseline，再smoke真实最终正文 |
| 另一台内网机器调用 | NOT_RUN | 复制最小客户端和public配置，再401/流式/多轮验收 |
| 真实P/D KV通信 | NOT_RUN | P4D4/P2D2，非零传输证据、checksum/错误策略、最终正文 |
| FP8/AWQ/校准质量 | NOT_RUN | 真K/V范围采集、保留集能力与长上下文回归 |
| CUDA扩展SM探针编译与执行 | NOT_RUN | 本地toolkit编译；单卡先验收，再4/8卡 |
| 真实nvidia-smi资源/功率/能耗 | NOT_RUN | 依据总04、SGLang31或vLLM15同机执行并检查coverage |
| allocator微实验/Graph显存快照 | NOT_RUN | 公共12；检查版本、rank命名与真实产物，不把人工buffer当模型 |
| Nsight SM计数器/kernel/CPU实测 | NOT_RUN | 权限探针，短窗口采集，原始report/trace |
| goodput容量曲线/模型能力分数 | NOT_RUN | 固定SLO/数据revision、无Profiler正式测量 |

因此，这是一套有源码核对、可执行检查与明确验收门槛的部署实验包；**不是已经在你的H800上跑完的结果**。固定主机驱动、完整资产和模型兼容条件满足后，按顺序执行；遇到不支持组合会报错或明确标条件实验。新DeepSeek V4.1的H800限制有启动拦截，不通过删除检查制造“可用”结论。

## 复跑CPU检查

在总根目录：

```bash
python3 sglang_lab/tests/test_cpu.py
python3 vllm_addon/tests/test_cpu.py
python3 tests/test_shared.py
python3 tests/test_measurement.py
python3 tests/validate_bundle.py
```

实机结果写各框架 `data/reports/deployment_status.json`，逐项记录命令、退出码、时间、原始日志路径和观察。模板中的NOT_RUN不能仅靠修改文字变成PASS。
