# 03 · KV张量传输与真实PD

先做两GPU的**合成KV形状**传输，再在真实PD中采证据。两GPU探针只占2卡，不冒充8/4卡整模型PD；可分别在8卡的P/D代表卡0与4、4卡的0与2上运行。

从总根目录：

```bash
CUDA_VISIBLE_DEVICES=0,4 sglang_lab/environments/sglang0522/.venv/bin/torchrun \
  --standalone --nproc_per_node=2 shared/scripts/kv_transfer.py \
  --tokens 4096 --layers 8 --kv-heads 8 --head-dim 128 --dtype bf16 \
  --output shared/results/kv_transfer_0_to_4_bf16.json
```

4卡将visible设0,2。dtype改uint8可研究字节减少的传输效果；**uint8没有量化scale与真实量化kernel，不叫FP8正确性验证**。再扫tokens256/4096/16384、不同卡对，记录bytes、每次ms、十进制GB/s，先逐元素验证payload没有错。

本探针为NCCL send/recv；真实SGLang PD用Mooncake/NIXL，vLLM用NixlConnector。它只能给拓扑下的基础搬运参照，不能替代真实connector控制面、页表映射、注册内存与布局兼容测试。

## 真实PD应记录的分解

| 阶段 | 记录 |
|---|---|
| bootstrap/握手 | worker地址、room/id、版本和重试，不记录Key |
| D预分配/排队 | 能否接收、free slots、队列时间 |
| P prefilling | 输入token、prefill compute、准备发送的页/字节 |
| KV send/recv | backend、实际bytes/pages、传输耗时与失败、checksum |
| D消费 | KV就绪后首次decode、是否发生重新prefill/fallback |
| E2E | TTFT、TPOT、最终正文、错误/超时及goodput |

同checkpoint不一定代表KV布局兼容：模型架构、dtype/scale、TP/CP、page/block size、layer布局、connector版本都要核对。P4D4与P2D2先用相同TP对称布局；异构分片实验另建配置，不从同机成功推断跨机TP异构也支持。

SGLang提供KV checksum选项，本包P/D均启用；vLLM不杜撰一个同名通用checksumflag，用真实connector日志/指标、输出回归和故障注入确认。跨节点RDMA需单独注册内存、网卡/GID/ACL测试；通信参数不能只靠NCCL变量覆盖所有库。

通过必须有**非零真实传输证据 + 正确最终生成**。停止P后请求仍成功可能是缓存命中、重算或路由变化，要查原因，不能自动认为PD无故障。
