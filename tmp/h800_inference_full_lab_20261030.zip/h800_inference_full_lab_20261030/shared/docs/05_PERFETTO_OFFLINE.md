# 05 · 受限内网的Perfetto UI

在线 `ui.perfetto.dev` 不作为唯一入口。准备机编译官方静态UI，整体搬入 `shared/environments/perfetto-ui/`，在**看trace的客户端机器本地**服务。

## 准备机（可下载阶段）

在总根目录，选择真实完整Perfetto commit并记录：

```bash
mkdir -p shared/environments/perfetto-src
git clone https://github.com/google/perfetto.git shared/environments/perfetto-src/repo
cd shared/environments/perfetto-src/repo
TASK_PERFETTO_REV=REPLACE_WITH_REAL_COMMIT
git checkout "$TASK_PERFETTO_REV"
tools/install-build-deps --ui
ui/build
```

需要该commit官方构建依赖，网络可能涉及GitHub之外的工具链/CDN。构建后完整 `ui/out/dist/` 为交付资产；先在准备机断开外部网络验证可打开trace。不同commit如输出路径变化，以构建日志为准，不只复制HTML。

回到总根目录：

```bash
mkdir -p shared/environments/perfetto-ui
cp -a shared/environments/perfetto-src/repo/ui/out/dist/. shared/environments/perfetto-ui/
python3 shared/scripts/cache_manifest.py --root shared/environments/perfetto-ui \
  --manifest shared/environments/perfetto-ui.MANIFEST.json
```

如果准备机是Windows，优先在匹配Linux/WSL完成官方流程。目标查看端只要有浏览器和本地HTTP服务，不需要CUDA。

## 内网客户端

复制完整UI文件夹、manifest、serve脚本和trace，保留路径或在命令中指定实际位置：

```bash
python3 shared/scripts/cache_manifest.py --root shared/environments/perfetto-ui \
  --manifest shared/environments/perfetto-ui.MANIFEST.json --verify
python3 shared/scripts/serve_perfetto.py --directory shared/environments/perfetto-ui --port 10000
```

浏览器打开 `http://127.0.0.1:10000`，从本地打开trace。服务加COOP/COEP隔离响应头以支持SharedArrayBuffer；不用直接 `file://` 打开。若UI仍访问外部WASM/资源，说明构建/复制不完整或该commit需额外资产，按DevTools网络请求补齐并重做离线验证，不当成功。

观察：CPU线程/stack、GPU stream、prefill/decode、NCCL、CUDA Graph replay、关联flow、等待空洞。Perfetto展示活动，不会凭JSON生成SM硬件计数器。大trace先缩短采样窗口或分rank；原始数据别删除。
