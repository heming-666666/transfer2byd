# 06 · 能力评测环境、数据与协议

推理与评测相互独立。以下从总根目录执行；使用已准备的portable CPython3.12，不修改系统Python。评测可放另一台能访问内网API的机器，前提是一起搬走shared目录和客户端配置，并按本项目根布局运行。

## 准备工具依赖

```bash
TASK_PY=sglang_lab/environments/python/cpython/bin/python3
"$TASK_PY" shared/scripts/prepare_tool_env.py --tool evalscope --mode prepare
"$TASK_PY" shared/scripts/prepare_tool_env.py --tool lm_eval --mode prepare
```

准备机允许从源码构建纯Python依赖wheel（如langdetect），最终目标安装仍仅用wheel。本机Linux/CPython3.12/ABI须匹配；解析或构建失败先补依赖，不在目标机临时联网。目标安装：

```bash
"$TASK_PY" shared/scripts/prepare_tool_env.py --tool evalscope --mode install
"$TASK_PY" shared/scripts/prepare_tool_env.py --tool lm_eval --mode install
```

结果分别是 `shared/environments/evalscope1141/.venv` 与 `lmeval0413/.venv`。两个目录都有wheelhouse、lock、resolution、MANIFEST；重复项目移动后 `--rebuild`。

## 数据准备与固定revision

复制 `shared/fixtures/datasets.example.json` 为 `datasets.json`。把所选任务的revision替换为真实完整HF dataset commit，保留repo_id与目录名；默认占位值会被拒绝。

```bash
cp shared/fixtures/datasets.example.json shared/fixtures/datasets.json
shared/environments/evalscope1141/.venv/bin/python3 shared/scripts/prepare_datasets.py \
  --config shared/fixtures/datasets.json --tasks gsm8k ifeval mmlu_pro math_500
```

下载整个数据集快照到 `shared/datasets/<task>/`，写入 `LAB_DATASET_MANIFEST.json`。IFEval同时下载NLTK的punkt、punkt_tab、tagger资源到 `shared/datasets/nltk/`。这些下载域也可能受限，提前搬入。运行前：

```bash
shared/environments/evalscope1141/.venv/bin/python3 shared/scripts/prepare_datasets.py \
  --config shared/fixtures/datasets.json --tasks gsm8k ifeval --verify-only
```

EvalScope用 `dataset_args.<task>.local_path` 加载本地目录。若特定数据集repo文件布局不被该任务adapter识别，**先用10条流程验收定位**，按该固定adapter的subset/split要求整理到新目录并记录转换和SHA；不能自动换一个内容不明的同名数据集。

## 生成式评测

```bash
shared/environments/evalscope1141/.venv/bin/python3 shared/scripts/evalscope_run.py \
  --client-config sglang_lab/config/client.json --dataset-config shared/fixtures/datasets.json \
  --tasks gsm8k ifeval --limit 10 --max-tokens 4096 --output shared/results/ability_smoke
```

vLLM只换client-config为 `vllm_addon/config/client.json`，结果换新目录。正式改limit0；本包wrapper默认为0-shot（不同于某工具默认4-shot），要复现外部榜单必须匹配其fewshot、提示、抽取、重复次数、思考预算。更改 `datasets.json:few_shot_num` 后记录其配置哈希。

IFEval报告prompt_level_strict/loose、inst_level_strict/loose，优先严格prompt级指标；MMLU-Pro API是生成选项协议。数学得分需最终答案和原始reasoning保留。错误不静默跳过；空内容、超时、context/输出截断单独计数。

## lm-eval与经典likelihood任务

聊天路由 `lm_eval_run.py` 只用于gsm8k/ifeval等generation任务。准备阶段可加 `--online-prepare --limit 1`，在内网API已启动时实际跑一次，暖好该工具自己的HF任务缓存；EvalScope的local_path快照不等于Harness缓存。冻结缓存：

```bash
python3 shared/scripts/cache_manifest.py --root shared/environments/lmeval0413/cache \
  --manifest shared/environments/lmeval0413/DATA_CACHE_MANIFEST.json
```

再搬入内网、verify、去掉online-prepare，确保真正离线。记录任务yaml版本与缓存文件哈希；若要指定上游revision，复制固定任务yaml到独立自定义任务目录并明确写dataset_kwargs.revision，正式分数标明协议变化。

经典MMLU/HellaSwag通常需要prompt logprobs。先测服务器私有completions能力：

```bash
python3 shared/scripts/completions_probe.py --framework sglang --output shared/results/sglang_prompt_logprobs.json
shared/environments/lmeval0413/.venv/bin/python3 shared/scripts/lm_likelihood_run.py \
  --framework sglang --tokenizer shared/models/Qwen3-8B \
  --probe-report shared/results/sglang_prompt_logprobs.json \
  --task mmlu --fewshot 0 --limit 10 --output shared/results/sglang_mmlu_likelihood_smoke
```

当前实际模型必须就是该tokenizer对应checkpoint。vLLM换framework并使用它的实际模型tokenizer；先按online-prepare流程暖该任务数据，再离线执行。本探针只确认echo+部分prompt logprobs，仍要核对token IDs、BOS/EOS与continuation对齐。未通过不得给MMLU likelihood分数，公共网关保持不开放completions。

## 代码、长上下文与judge实验

| 基准 | 推荐流程 | 本包边界 |
|---|---|---|
| HumanEval/MBPP | 固定题库生成samples → 隔离VM/正式sandbox执行tests → pass@k | root服务机不执行生成代码；Docker不可用也不能直接去掉隔离 |
| LiveCodeBench | 固定时间切片、语言、官方评分器/隔离 | 标注日期避免训练污染可比性问题 |
| LongBench/RULER | 固定长度、needle位置、tokenizer与官方模板 | 显式增加maxlen/KV预算；记录被截断条数，不把短版称原榜单 |
| MT-Bench/AlpacaEval | 固定judge版本/提示/顺序/温度 | 不能联网judge时NOT_RUN；不用自我打分冒充第三方judge |
| AIME/GPQA | 官方数据授权、固定提示、输出预算、重复次数 | 单次pass@1与多次consensus/pass@k必须分开 |

以上高级协议不声称已完整集成对应官方执行器；本包可复用API生成、隔离数据和结果目录。主线已提供EvalScope数学/指令/知识及Harness generation/likelihood入口。新增评分器时另建 `shared/environments/<tool>-<version>/` 和编号MD，保持同样manifest及离线流程。

## 结果必要字段

checkpoint/tokenizer commit、框架/precision/quant、TP/DP/PP/CP/EP、chat template或raw prompt、fewshot、temperature/top_p/seed、maxlen/max_tokens、reasoning模式、数据revision/哈希、任务代码版本、样本总数、正确/错误/失败/截断、均值与置信区间（有重复时）、每题预测路径。没有这些字段，不宣称与网上榜单可比。
