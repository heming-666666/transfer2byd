# 07 · Goodput与SLO测量口径

每个请求i记录成功标志和延迟。联合达标 `G_i=success_i AND TTFT_i<=T1 AND TPOT_i<=T2 AND E2E_i<=T3`。请求goodput=`sum(G_i)/window_seconds`，联合达标率=`sum(G_i)/all_offered_requests`。

例：100条中90条同时达标、5条慢、5条失败，完整窗口20秒，goodput=4.5rps，联合达标率90%。不能先删5条失败再说94.7%达标。另一个例子：TTFT最慢的5条和TPOT最慢的5条互不重叠，两项各自p95达标也可能联合仅90%达标；CPU测试专门覆盖这点。

| 名称 | 本包定义 |
|---|---|
| 到达 | 开环预先规划的Poisson/constant时间 |
| 发送 | 真正执行HTTP发送的时间 |
| client_queue | send−planned arrival；不等于服务器队列 |
| TTFT | 首个非空reasoning或content HTTP delta−send（可选择加client_queue） |
| TPOT估计 | (last nonempty delta−first nonempty delta)/(usage completion_tokens−1) |
| E2E | HTTP完成−send（可选择加client_queue） |
| ITL | 严格逐token间隔需能观测逐token；SSE chunk gap不自动叫ITL |
| window | 第一个计划到达到最后完成，含drain，预热另做 |
| percentile | nearest-rank；失败不加入“成功请求延迟”的分位数，但计入联合达标率分母 |

只有1个输出token时平均TPOT定义0；无usage时TPOT未知，若设了TPOT SLO则不达标。R2默认要求非空最终content，只有reasoning的请求不计成功；length finish在固定长度性能实验可作为请求结束，并单列length_capped_successes，但功能验收要求stop，能力评测须计截断并检查最终答案。若任意成功请求缺usage，token_usage_complete=false，成功输出token总数与token/s写null，不把未知token当0。

开放环会继续按offered rate发请求，达到客户端inflight上限记录drop；这可避免无穷队列，但drop属于客户端限制，要增大合理客户端能力或降低速率另测。闭环用固定并发、完成再发，不能直接拿完成rps当业务到达率容量上限。不能只用闭环掩盖排队延迟。

4卡/8卡都使用同一prompt集、SLO、时间窗口定义。先固定同一业务rate比较延迟，再各自扫描最大满足目标rate。每点保存requests.jsonl/summary、错误数、实际usage、当前profile/版本/网络位置；同机与另一台内网客户端的网络开销分开报告。

“达标输出token/s”是通过联合SLO的请求输出token数/窗口，不能替代request goodput；“答案正确且SLO达标”的语义goodput还需要逐请求质量标签，当前工具不自动判断答案对错。

SGLang官方bench和vLLM官方 `--goodput` 的内置口径以各自版本为准，不把不同定义直接合并；统一客户端用于同口径比较，官方工具用于更接近框架原生token指标。无Profiler测成绩，短Profiler窗口只用于解释原因。

R2结果还包含同机perf_counter_ns时钟锚点、measurement_window、逐请求绝对单调时间、prompt/extra配置SHA256。`--extra-json`不能覆盖model/messages/max_tokens/stream/stream_options/n，避免悄悄改变协议或请求计数；SLO必须有至少一个有限正阈值，未知字段/NaN/无效比例直接报错。对齐功率与能耗的方法见 [11_RESOURCES_ENERGY_CLOCKS.md](11_RESOURCES_ENERGY_CLOCKS.md)。
