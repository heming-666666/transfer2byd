# 09 · 自定义CUDA探针：记录block在哪个SM、哪些时段重叠

这是新增的可控原理实验，回答“自己的kernel里，block被放到哪些SM，在记录区间内同时有多少SM承载这些block”。它不替代真实attention/GEMM/NCCL kernel的Nsight分析。

CUDA源码在 `scripts/sm_probe.cu`；通过PTX `%smid`读开始/结束SM ID，通过 `%globaltimer`读GPU设备内全局时间标记，导出每CTA的4列记录。SM编号可能不连续，代码不假设0到SM总数减1。SMID可因抢占改变；开始/结束不同的block排除并记录，开始/结束相同仍不能排除中间迁移返回。globaltimer是工具诊断寄存器、名义纳秒单位，目标相关行为和分辨率需核对；不用于跨GPU直接对齐。

官方依据：[PTX特殊寄存器](https://docs.nvidia.com/cuda/parallel-thread-execution/index.html)。本包源码未在H800编译或运行，状态为NOT_RUN，必须在目标toolkit上完成编译与数值/区间检查。

## 前提

本地匹配CUDA13 toolkit/nvcc、C++编译器、ninja、Torch venv；先停止占卡推理服务。编译资产与缓存仅放 `shared/environments/sm-probe/`，不会替你安装驱动。设置CUDA_HOME到项目内已准备toolkit，并将其bin加入当前shell PATH；例如：

```bash
LAB_ROOT=/data/llm/h800_inference_full_lab_20261030
cd "$LAB_ROOT"
export CUDA_HOME="$LAB_ROOT/sglang_lab/environments/toolkit/cuda-13.0"
export PATH="$CUDA_HOME/bin:$PATH"
```

先单卡编译和验收，避免8进程同时首次编译增加排查难度：

```bash
CUDA_VISIBLE_DEVICES=0 sglang_lab/environments/sglang0522/.venv/bin/python3 \
  shared/scripts/sm_probe.py --cards 1 --blocks 512 --threads 128 --iterations 20000 \
  --output shared/results/sm_probe_build_1g
```

再运行8卡（只是8个独立GPU上的相同probe，不初始化NCCL，不声称模型TP）：

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
sglang_lab/environments/sglang0522/.venv/bin/torchrun --standalone --nproc_per_node=8 \
  shared/scripts/sm_probe.py --cards 8 --blocks 512 --threads 128 --iterations 20000 \
  --output shared/results/sm_probe_8g
```

4卡使用visible0,1,2,3、nproc4、cards4、新输出名。也可换vLLM venv；脚本自动按Torch/CUDA/Python版本创建独立extension build目录，不共用不兼容.so。

## 输出与实验矩阵

每rank有raw JSON、summary JSON和Chrome trace。summary按每SM的CTA区间refcount做事件扫描，计算记录到的distinct SM、最大同时承载记录CTA的SM数、时间平均数；trace每条SM一个lane，每个block一个区间，可在离线Perfetto打开。各rank以本设备最早标记为零点，不能拿各文件零点推跨GPU同步。

扫blocks=8/32/128/512、threads=32/128/256、iterations=2000/20000；改变grid时观察触及SM数与waves、时间分布。线程数/寄存器/占用会影响调度；不保证512个block一定让所有SM都被记录。

这些是**自定义诊断kernel的标记区间**，不包括其未标记prologue/epilogue，也不是每周期warp occupancy。现有供应商attention/kernel不插桩时没有这些记录，不能将此探针数据写进模型的SM使用表。与同kernel的NCU LaunchStats/SM Active对照，解释计数口径差异。
