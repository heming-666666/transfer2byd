# 10 · 真实KV校准：SGLang Qwen3-8B，分别导出TP4/TP8

这项补齐“scale从哪里来”的实验。不是填一组1.0：脚本在真实BF16模型上执行校准文本，读取HF DynamicCache中post-RoPE/QK-normalized的K/V，按每层每KV head统计实际绝对最大值，再按TP4/TP8分片生成对应rank/layer标量scale JSON。K/V共用该rank/layer最大范围，符合SGLang此JSON接口。

范围法校准是一个可解释基线，不保证所有未来输入都不溢出；正式质量仍需保留集测评。当前脚本只支持 **dense Qwen3**，不套用MoE/MLA/V4，不伪称NVFP4校准。

## 准备与3条流程验收

进入sglang_lab，先停止本包占卡服务，确认Qwen3-8B完整。需要一张空闲H800加载完整8B模型及校准cache，宿主RAM容纳CPU加载峰值；不启动TP服务的同时抢同一GPU。

```bash
python3 scripts/run.py stop all
CUDA_VISIBLE_DEVICES=0 ./environments/sglang0522/.venv/bin/python3 scripts/calibrate_kv.py \
  --corpus ../shared/fixtures/calibration.smoke.jsonl --samples 3 --max-length 1024 \
  --tp-sizes 4 8 --margin 1.1 --output config/kv_scales_smoke
python3 scripts/validate_scales.py --model ../shared/models/Qwen3-8B \
  --tp 8 --scales config/kv_scales_smoke/tp8.json
```

输出tp4.json、tp8.json、manifest，记录真实max、margin、输入长度、语料SHA与FP8 finfo最大值。仅3条时scope明确为SMOKE，不能当生产校准。输出目录已存在会拒绝覆盖。

正式语料使用至少128–512条有代表性的**校准**文本JSONL（每行`text`），来自独立训练/业务回放集合，固定revision/哈希；不要用最终测试集答案调scale。max-length匹配业务，另输出 `config/kv_scales_formal/`；记录截断策略与分布覆盖。

## 设置两种TP的scale路径

分别存路径，不能8卡直接误用TP4文件：

```bash
python3 - <<'PY'
import json
from pathlib import Path
p=Path('config/settings.json')
c=json.loads(p.read_text())
c['kv_scale_paths']={'4':'config/kv_scales_smoke/tp4.json',
                     '8':'config/kv_scales_smoke/tp8.json'}
p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
PY
CARDS=8
./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile "${CARDS}g_kv_fp8"
```

4卡改CARDS4，launcher按TP选择相应文件。实际服务按原主线另起网关并验收，分别与同卡数BF16、未校准FP8比较。正式scale替换配置路径为formal目录，smoke资产不覆盖。

本包在启动前严格检查model_type、dtype、TP ranks、全部layer keys、正有限scalar。上游legacy loader对某些JSON错误会记录warning并回退1.0，所以本包不能只看“文件存在/打印loaded”；严格校验后还要查无fallback warning，并以长上下文/能力保留集检验。

## 正确解读

脚本以 `torch.finfo(torch.float8_e4m3fn).max`确定目标范围，不把FNUZ或其他FP8格式的最大值硬写成相同数字。TP4每rank可能包含2个KV head、TP8每rank1个；文件的rank含义必须匹配实际attention分片。本实验限定纯TP、PP1/AttentionDP1/CP1/DCP1；更复杂布局另校准映射。

SGLang JSON只给它的标量scale接口使用，**不是vLLM checkpoint**。vLLM0.32推荐llm-compressor生成带scale和对应量化metadata的独立checkpoint；按vLLM07固定recipe/校准集/工具env，并核验该架构Attention target匹配与导出的scale，不把这个JSON改个文件名就当vLLM校准完成。

对比表：BF16、FP8默认1.0、FP8校准，分别记录KV token容量、显存、TTFT/TPOT/goodput、GSM8K/IFEval子集与长上下文检索、失败/截断。若校准反而退化，保留实际结果并查输入分布、分片映射和backend；不能选择性只报性能。
