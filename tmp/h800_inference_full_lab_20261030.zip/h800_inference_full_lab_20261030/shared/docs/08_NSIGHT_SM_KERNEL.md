# 08 · SM、kernel、CPU提交、通信与CUDA Graph准备时间

目标是把“为什么慢”拆成有时间边界和证据的量，而非靠GPU utilization猜。以下同时用于SGLang和vLLM；默认8卡，4卡改CARDS和可见GPU。**硬件计数器、trace、原生服务是不同能力，分别验收。**

## 1. 指标能回答什么

| 问题 | 工具/字段 | 限制 |
|---|---|---|
| 设备SM总数 | Torch `multi_processor_count` / NCU `launch__sm_count` | 容量，不是活跃数；不写死H800一定132SM |
| 时段SM活跃 | Nsys GPU Metrics的SM Active、NCU PM sampling | 空间/时间平均，有采样间隔；其他进程也可能贡献 |
| kernel SM行为 | NCU LaunchStats、Occupancy、per-instance计数（若支持） | grid与waves只是容量/调度信息；不能单靠grid推出实际SM分布 |
| kernel数与耗时 | Nsys `cuda_gpu_kern_sum` / 原始kernel表 | graph须node粒度；次数区分launch和distinct name |
| CPU提交 | NVTX/PyTorch c10d范围、CUDA API elapsed、CPU sampling | elapsed含锁/阻塞，CPU busy需CPU采样/线程调度证据 |
| 通信GPU耗时 | NCCL kernel时长与stream依赖 | 时间含等待/协议，不是纯链路wire time |
| CPU→GPU排队 | 正确process/context的correlation flow | 起点选API开始/结束会改变定义；并发甚至可能“GPU先于API返回” |
| graph准备 | warmup、begin/end capture、instantiate、upload、first replay | 多rank可能并发，不能sum当startup wall |

SM Active 50%可能是所有SM在窗口一半时间活跃，也可能是一半SM始终活跃。乘SM总数只能得到**时间平均的等效活跃SM估计**，不能声称某一瞬间确切用了N个SM。要数某次kernel是否触及某个SM，须工具明确提供对应SM实例计数或专门插桩；没有就写未测得。

## 2. 所有工具放子目录

准备Nsight Systems/Compute的官方Linux安装包和校验清单，固定实际版本与SHA到 `shared/environments/TOOLS_MANIFEST.json`。选择支持目标driver/CUDA13的版本。ZIP未包含这些二进制。

可选Deb包仅解压，不安装到系统：

```bash
mkdir -p shared/environments/nsight-systems/extracted shared/environments/nsight-compute/extracted
TASK_NSYS_DEB=/absolute/prepared/nsight-systems-cli-linux.deb
TASK_NCU_DEB=/absolute/prepared/nsight-compute-linux.deb
dpkg-deb --extract "$TASK_NSYS_DEB" shared/environments/nsight-systems/extracted
dpkg-deb --extract "$TASK_NCU_DEB" shared/environments/nsight-compute/extracted
rg --files shared/environments/nsight-systems | rg '/nsys$'
rg --files shared/environments/nsight-compute | rg '/ncu$'
```

设置TASK_NSYS/TASK_NCU为上面找到的**真实可执行路径**，先 `--version`、`--help` 和动态库检查。若分发包为tar或.run，按其官方仅解压/目标目录选项操作；不猜测安装器选项，不修改全局驱动。

```bash
TASK_NSYS=/absolute/project/shared/environments/nsight-systems/extracted/ACTUAL_PATH/bin/nsys
TASK_NCU=/absolute/project/shared/environments/nsight-compute/extracted/ACTUAL_PATH/ncu
"$TASK_NSYS" --version
"$TASK_NCU" --version
"$TASK_NSYS" profile --gpu-metrics-devices=help
"$TASK_NCU" --query-metrics --query-metrics-mode all
```

root在云容器里也不一定有物理GPU计数器权限。`ERR_NVGPUCTRPERM`/vGPU不支持/计数器忙需要平台提供能力；本包不自动改宿主机模块参数或关闭全局监控。先保留可用CUDA活动时间线，SM计数项标UNAVAILABLE。

## 3. 先认识可控4/8卡时间线

从总根目录，停止本包推理服务让GPU空闲：

```bash
CARDS=8
TASK_TORCHRUN=sglang_lab/environments/sglang0522/.venv/bin/torchrun
"$TASK_TORCHRUN" --standalone --nproc_per_node="$CARDS" shared/scripts/gpu_stages.py \
  --cards "$CARDS" --matrix 2048 --iterations 10 --output "shared/results/stages_${CARDS}g"
```

产生每rank JSON与Chrome trace。先看 `comm_submit::all_reduce`（CPU提交）、`comm_work_wait`、device sync、`graph_capture_wall`、`graph_replay_submit`；它们的名字直接对应实际测量边界。CUDA event测默认stream区间，可能含依赖等待和CPU发起间隙，不冒称纯kernel执行时间。

然后换一轮Nsight采集，**关内置PyTorch Profiler**：

```bash
mkdir -p shared/traces/nsys
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 "$TASK_NSYS" profile \
  --trace=cuda,nvtx,osrt --sample=none --cuda-graph-trace=node \
  --gpu-metrics-devices=cuda-visible --gpu-metrics-frequency=10000 \
  --output shared/traces/nsys/stages_8g \
  "$TASK_TORCHRUN" --standalone --nproc_per_node=8 shared/scripts/gpu_stages.py \
  --cards 8 --no-torch-profiler --output shared/results/stages_nsys_8g
```

4卡对应visible0,1,2,3、nproc4、cards4和新输出名。若仅GPU Metrics失败，去掉两个gpu-metrics选项重采活动trace；注明缺计数器，不说已测SM。Nsight GPU Metrics采样是设备级，需要保证没有其他任务干扰；不要同时启动多个工具订阅同设备计数器。

## 4. 真实SGLang/vLLM引擎

从engine启动前包住启动命令，才能看到JIT、捕获、instantiate。示例在 `sglang_lab/`，先 `run.py stop all`：

```bash
"$TASK_NSYS" profile --trace=cuda,nvtx,osrt --sample=none \
  --cuda-graph-trace=node --trace-fork-before-exec=true --duration=90 --kill=none \
  --output ../shared/traces/nsys/sglang_graph_startup_8g \
  ./environments/sglang0522/.venv/bin/python3 scripts/run.py engine --profile 8g_graphs_on
```

另一终端wait_ready、启动网关并发6条短请求，完成后 `run.py stop engine`。`--kill=none`防止采样结束自动杀应用；launcher保留的进程组用于停止本包。首次编译超过90s时此窗口会错过capture，先预热、增大明确duration或分阶段重新采，不把空trace当无开销。

vLLM在 `vllm_addon/` 用完全同样的Nsight选项，末尾换成本地 `environments/vllm0320/.venv/bin/python3 scripts/run.py engine --profile 8g_graphs_on`，输出名换vllm。4卡两框架都换4g profile。PyTorch Profiler端点此轮不要开启；P/D分别包住各自启动，输出分开。

低扰动稳态可选graph粒度 `--cuda-graph-trace=graph`；需要图内kernel次数/耗时用node，代价更高。二者结果不要当同一采集开销。Nsight 版本必须在 `profile --help` 支持这些选项，否则用该版本等价参数并记录差异。

## 5. 导出kernel、API统计与原始事件

从总根目录（REPORT换实际文件）：

```bash
TASK_REPORT=shared/traces/nsys/sglang_graph_startup_8g.nsys-rep
"$TASK_NSYS" stats --report cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum \
  --format csv --output shared/traces/nsys/summary "$TASK_REPORT"
"$TASK_NSYS" export --type sqlite --output shared/traces/nsys/engine.sqlite "$TASK_REPORT"
python3 shared/scripts/nsys_sqlite.py shared/traces/nsys/engine.sqlite \
  --output shared/results/kernel_api_summary.json \
  --events shared/results/kernel_events.jsonl
```

输出kernel按device/globalPid/name汇总次数、total/mean/min/max；events逐条保留start/end ns、device、context、stream、correlationId，能按具体prefill/decode时间窗口过滤。脚本从实际SQLite schema找name字段，不硬编码旧表列；未知schema会报错。

每device计算kernel活动区间**并集**，区别kernel总dur。并集只覆盖kernel，不含memcpy；不能称完整GPU利用率。进程中可见device序号需用UUID/PCI映射确认，尤其PD分组。CPU API runtime/driver可能嵌套，分别报告，不直接加和。

UI中按kernel关联flow查看对应host API/NVTX；correlationId必须结合进程/上下文，8个进程可能有同号ID，脚本故意不做不可靠的跨进程猜测join。CPU通信提交总时间需选c10d/nccl范围，GPU通信选NCCL kernel，等待选同步/调度线程；三者各报告口径。

CUDA Graph查 `cudaStreamBeginCapture*`、`cudaStreamEndCapture*`、`cudaGraphInstantiate*`、`cudaGraphUpload*`、`cudaGraphLaunch*`（也可能为cuDriver对应API）。把warmup、capture wall、instantiate CPU wall、upload、首次replay分栏。某版本lazy初始化或把instantiation放在endcapture中，要由真实API trace确认，不能将Python上下文整段都叫instantiate。

## 6. Nsight Compute：单kernel的SM/occupancy

先在Nsight定位重kernel，再用无NCCL、无内置Profiler的小复现：

```bash
CUDA_VISIBLE_DEVICES=0 "$TASK_NCU" --target-processes all --clock-control none \
  --kernel-name 'regex:.*(gemm|Gemm|GEMM).*' --launch-skip 5 --launch-count 1 \
  --section LaunchStats --section Occupancy --section SpeedOfLight \
  --export shared/traces/ncu_gemm \
  sglang_lab/environments/sglang0522/.venv/bin/python3 shared/scripts/ncu_probe.py --matrix 4096
```

如果kernel名未匹配，用Nsys实际名字调整regex；没有匹配不能说计数器零。用 `ncu --list-sections`确认section名。重点读：

| 指标 | 含义 |
|---|---|
| launch__sm_count | 对此launch可用SM容量 |
| launch__grid_size / launch__block_size | block与thread规模 |
| launch__waves_per_multiprocessor | 估计wave数与尾波；不是实际触及SM数 |
| sm__cycles_active.avg.pct_of_peak_sustained_elapsed | SM active时间/空间平均 |
| sm__warps_active.avg.pct_of_peak_sustained_active | achieved occupancy，与SM active不同 |
| sm__throughput / dram__throughput | 计算/内存吞吐；使用本机query出的完整suffix |

如H800与该NCU版本支持PM sampling，可在同一小复现上单独一轮：

```bash
CUDA_VISIBLE_DEVICES=0 "$TASK_NCU" --clock-control none \
  --kernel-name 'regex:.*(gemm|Gemm|GEMM).*' --launch-skip 5 --launch-count 1 \
  --metrics 'pmsampling:sm__cycles_active.avg.pct_of_peak_sustained_elapsed' \
  --pm-sampling-interval 10000 --export shared/traces/ncu_sm_timeline \
  sglang_lab/environments/sglang0522/.venv/bin/python3 shared/scripts/ncu_probe.py --matrix 8192
"$TASK_NCU" --import shared/traces/ncu_sm_timeline.ncu-rep \
  --page raw --csv --print-metric-instances details > shared/results/ncu_sm_samples.csv
```

先 `--query-metrics-collection pmsampling`确认支持；interval单位依架构为cycles或ns，以工具报告为准。PM instance correlation是采样时间戳，不一定是SM ID；只有明确标识SM实例的计数才能按SM计数。没有该metric时保留query输出并选受支持项，不编造数据。

NCU通常串行化/重放kernel，改变cache和时间；不能用它的E2E作为生产吞吐。对NCCL、graph中含collective、多进程相互等待的在线模型无过滤profile可能挂起；先用Nsys分析全8/4卡，再对独立kernel/可控rank复现采counter。单GPU复现结论只覆盖该kernel/形状，不冒充全模型每rank实测。

## 7. 最终记录表

每个框架、4/8卡、开/关graph分别记录：启动wall、warmup、capture/instantiate/upload、每阶段kernel launch数/unique names/top10耗时、每device活动并集、CPU提交/同步wall、NCCL GPU时长、PD实际传输、SM active/occupancy采样范围与权限状态、无Profiler goodput。每项附原始report/trace、rank/UUID、时间窗口、单位、重叠处理和版本。

保留UNKNOWN/UNAVAILABLE/NOT_RUN；不从显存、GPU util或一个平均百分比伪造精确“此时用了多少个SM”。
