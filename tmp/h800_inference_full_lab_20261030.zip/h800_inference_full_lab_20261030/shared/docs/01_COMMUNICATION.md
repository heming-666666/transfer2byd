# 01 · 通信、NVLink、NCCL与带宽

本章从总项目根目录执行。先停止占用所选GPU的本包推理服务。默认8卡，4卡只改CARDS与CUDA可见列表。使用已安装且通过CUDA探针的任一框架venv；以下示例为SGLang。

```bash
CARDS=8
TASK_PY=sglang_lab/environments/sglang0522/.venv/bin/python3
TASK_TORCHRUN=sglang_lab/environments/sglang0522/.venv/bin/torchrun
"$TASK_PY" shared/scripts/topology.py --cards "$CARDS" --output "shared/results/topology_${CARDS}g.json"
"$TASK_TORCHRUN" --standalone --nproc_per_node="$CARDS" shared/scripts/collectives.py \
  --op all_reduce --mib 64 --warmup 5 --iterations 30 --output "shared/results/allreduce_${CARDS}g_64mib.json"
```

将op分别改 `all_gather`、`reduce_scatter`、`all_to_all`；4/8卡各测1/16/64/256MiB。脚本先检查rank输入对应的输出值，再计时；报告最慢rank平均耗时。all-reduce计时包含重置input的copy，因此不是纯wire-only NCCL延迟。

| 指标 | 定义 |
|---|---|
| `input_GBps` | 每rank输入字节/迭代秒数/1e9；输入归一化算法速率 |
| output bytes | all-gather输出为world倍，reduce-scatter为world分之一 |
| bus bandwidth | 需按具体collective/算法定义额外换算；本脚本不冒用统一公式 |
| NVLink实际流量 | 需要硬件计数器/受支持Nsight指标；NCCL用时不能反推每条链路流量 |
| 同步拖尾 | 看所有rank的等待、最慢rank及拓扑，不只rank0耗时 |

启用一次通信诊断（日志也放子目录）：

```bash
mkdir -p shared/results/nccl_debug
NCCL_DEBUG=INFO NCCL_DEBUG_SUBSYS=INIT,GRAPH,COLL \
NCCL_DEBUG_FILE="$PWD/shared/results/nccl_debug/nccl.%h.%p.log" \
"$TASK_TORCHRUN" --standalone --nproc_per_node="$CARDS" shared/scripts/collectives.py \
  --op all_reduce --mib 16 --output "shared/results/nccl_debug/run_${CARDS}g.json"
```

可做单变量 `NCCL_P2P_DISABLE=1` 对照观察退回路径，实验后使用新shell/取消该变量；不要把禁用P2P当永久推荐。`NCCL_IB_DISABLE`控制IB通道，不能替代NVLink开关。网卡名称通过本机 `ip -br addr` 查，不假设都叫eth0。

更标准带宽可选构建官方 [NVIDIA/nccl-tests](https://github.com/NVIDIA/nccl-tests)，固定commit，源码/构建产物放 `shared/environments/nccl-tests/`。本地toolkit与NCCL开发头文件/库路径准备好再 `make CUDA_HOME=... NCCL_HOME=...`，不在root下系统安装。`all_reduce_perf -b 8 -e 256M -f 2 -g 8`（4卡-g4）需要正确lib/ABI与设备；记录algbw/busbw及其工具定义，不能和本脚本input_GBps混为一列。

通过：结果数值检查通过，无NCCL错误，原始topo/UUID/驱动/通信日志齐全。硬件P2P可达不证明NVLink，H800营销峰值也不代表本云机实际拓扑。
