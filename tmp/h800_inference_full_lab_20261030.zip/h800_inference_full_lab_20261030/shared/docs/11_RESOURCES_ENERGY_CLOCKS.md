# 11 · GPU资源、功率、能耗与压测时间对齐

采样器与能耗工具仅用Python标准库和宿主机已有的`nvidia-smi`。用于SGLang与vLLM，支持显式4/8物理GPU index。先读本章，再运行各框架的完整执行章。

## 观测值和含义

| 原始字段 | 能回答 | 不能直接推断 |
|---|---|---|
| memory.used / memory.total | 设备报告的显存占用/容量 | 该模型的权重/KV/NCCL分别占多少 |
| utilization.gpu | 设备采样周期内kernel活动比例 | 某时刻正在使用多少个SM、occupancy、tensor core利用率 |
| power.draw | 驱动报告的设备功率W | 单个kernel的能耗、CPU/NIC/整机插座功耗 |
| query_seconds | 调用nvidia-smi的主机墙钟时间 | GPU运算耗时或CPU实际运行时间 |
| perf_ns | 查询前后时间中点 | 硬件功率传感器精确采样时刻 |

NVIDIA说明GPU utilization是采样周期内的活动比例；功率字段可能是硬件/驱动平均后的值，采得更快不等于提高硬件刷新率。因此默认每秒采一次，先做持续几十秒以上的稳定负载。不要用1秒采样解释几十微秒kernel。来源：[NVIDIA-SMI文档](https://docs.nvidia.com/deploy/nvidia-smi/index.html)、[NVIDIA查询说明](https://nvidia.custhelp.com/app/answers/detail/a_id/3751/~/useful-nvidia-smi-queries)。SM与kernel用公共08/09的方法另测。

## 同机时钟约束

`slo_bench.py` 新增 `clock`、`measurement_window` 和逐请求 `*_perf_ns`。`resource_monitor.py` 使用同一种`perf_counter_ns`，同时保存UTC锚点、hostname、Linux boot_id和time namespace。能耗工具要求这些身份全部匹配；远端客户端的单调时钟不能直接与GPU主机对齐。NTP时间看起来相同也不能让两台机器的`perf_counter_ns`可比较。

**能耗实验在GPU主机本机发压并采样**，仍经过公开网关。另一台内网机器单独做可达性/端到端SLO实验。跨主机请求→GPU功率归因需要额外时钟校准及误差界限，本包不自动猜测偏移。UTC用于人读和粗查，计算使用同机单调时钟，避免NTP校时产生负测量窗口。

## 命令与文件

以下均在总根目录。终端A先开始，终端B等A打印采样目录后再发压；保证采样结束晚于压测结束。示例模型服务必须已经就绪。

```bash
# 终端A：8卡；4卡改成 --gpus 0,1,2,3
python3 shared/scripts/resource_monitor.py --gpus 0,1,2,3,4,5,6,7 \
  --interval 1 --duration 300 --output shared/results/energy_trial01/resources
```

```bash
# 终端B：SGLang例子；vLLM改client-config，保持同机
python3 shared/scripts/slo_bench.py --client-config sglang_lab/config/client.json \
  --mode open --arrival constant --rate 2 --requests 128 --concurrency 16 \
  --max-tokens 256 --warmup 4 --timeout 180 \
  --output shared/results/energy_trial01/slo
```

上例不强制任何模型关闭思考；如果使用R1，256输出预算可能只够思考，默认不把只有reasoning的请求计成功。机制实验建议按各框架完整执行章使用Qwen3-8B和nonthinking配置。请求成功但`finish_reason=length`会单列 `length_capped_successes`，这不代表回答完整或能力正确。

```bash
# A结束后，或B结束后在A按Ctrl+C并确认metadata已写完，再汇总
python3 shared/scripts/energy_report.py --resources shared/results/energy_trial01/resources \
  --slo-summary shared/results/energy_trial01/slo/summary.json \
  --max-gap 2.5 --min-coverage 0.99 --output shared/results/energy_trial01/energy.json
```

| 文件 | 内容 |
|---|---|
| `resources/metadata.json` | GPU列表、精确命令、时钟锚点、采样状态、失败次数 |
| `resources/samples.jsonl` | 每轮query耗时、中点时间、每卡UUID/显存/利用率/功率；失败保留error |
| `slo/requests.jsonl` | 逐请求planned/send/finish、联合SLO、失败/丢弃 |
| `slo/summary.json` | 联合goodput、完整含drain窗口、负载参数与prompt/extra哈希 |
| `energy.json` | 逐卡覆盖率、已观测焦耳、全窗口焦耳或null、J/token或null |

首轮nvidia-smi失败时采样器返回非零并留下FAILED_FIRST_QUERY；不会改成虚构GPU数据。中途失败与`N/A`保留缺测。结果路径存在时拒绝覆盖。`SIGTERM`/Ctrl+C会保存已完成采样；主机强断电或SIGKILL不能保证尾部完整。

## 计算口径

对每卡相邻的有效功率点，在线性插值后以梯形积分，仅累计落入SLO起止窗口的部分：`J += (W_left + W_right)/2 × seconds`。不跨缺失样本、不跨超过max-gap的间隔、不向首尾外推、不把缺测当0W。重复或倒退时间、UUID映射变化直接报错。

`total_observed_gpu_energy_j` 始终只是已覆盖区间累计。只有每卡覆盖整个窗口，`full_window_gpu_energy_j`才非null；达到min-coverage仅说明通过使用者选定的覆盖门槛，并不填补缺口。`observed_gpu_joules_per_successful_output_token` 只有所有卡覆盖率过门槛、成功请求usage完整、成功输出token总数>0才给值；它仍是observed energy的比值。正式比较要求接近100%覆盖，报告覆盖率，且输入输出长度分布一致。

总功率包括选中GPU上的其他进程；做能耗对照前确认无无关负载。它包括设备空闲底耗；本包不自动减idle，也不把warmup计入SLO窗口。可另外运行相同采样时长的idle对照，报告其功率和方差；不要随意把一轮idle常量当每个微秒的真实底耗。

4/8卡既比较goodput，也比较总GPU焦耳、J/token、p95/p99、联合SLO比例、长度截断比例。不同模型、不同量化质量、不同token长度不能只按J/token排名。所有真实读数待本机执行，本指南不附示例H800成绩。
