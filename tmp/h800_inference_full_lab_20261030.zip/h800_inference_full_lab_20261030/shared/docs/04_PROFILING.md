# 04 · Profiler的层次与短窗口分析

| 层 | 工具 | 回答 |
|---|---|---|
| 请求 | 官方bench、slo_bench | 客户端感受到的TTFT/TPOT/E2E/goodput |
| 调度/算子 | PyTorch Profiler | CPU op、shape、stack、CUDA活动、空洞 |
| 时间线 | Perfetto / Nsight Systems | rank/stream/CPU提交与GPU事件关系 |
| kernel硬件 | Nsight Compute | SM/occupancy、DRAM、Tensor pipeline、warp stalls |

SGLang与vLLM分别使用各自指南启用Profiler；公共入口从总根目录：

```bash
python3 shared/scripts/profile_capture.py --framework sglang --action capture --requests 6 --max-tokens 128
python3 shared/scripts/profile_capture.py --framework vllm --action capture --requests 6 --max-tokens 128
```

只对当前已启动且有Profiler配置的框架执行对应一条，不要求两框架同时占GPU。SGLang输出在其data/traces，vLLM输出为启动profiler-config指定的cache/traces。P/D用target分开起停。

vLLM P/D先使用额外 `8g_pd_profile_prefill/decode` 或4g对应配置启用profiler；SGLang P/D由本包环境指定profile输出目录。公共gpu_stages还输出每rank operators.json，保留PyTorch实际count、self/total CPU和device时间（微秒），CPU self与嵌套total不可直接加和。

文件可能是Chrome JSON或JSON.gz：

```bash
python3 shared/scripts/trace_summary.py shared/traces/ACTUAL_TRACE.json.gz \
  --top 30 --output shared/results/trace_summary.json
```

总dur仅按category/name聚合，包含重叠与嵌套；不假装为selfCPU、wall或GPU利用率。先对齐同一rank的CPU和CUDA flow，再看跨rank的通信等待。独立trace本地时钟未必对齐，合并前核对基准时间；不要随意将文件时间戳直接堆叠比较。

SLO/吞吐正式测试关闭所有Profiler；保存开Profiler与无Profiler两轮，量化其扰动。PyTorch Profiler、Nsight Systems和Nsight Compute通常争用CUPTI/计数器，分轮使用。内置 `gpu_stages.py` 外挂Nsight时必须加 `--no-torch-profiler`。

启动准备问题必须从engine启动前采集；模型已经ready后调用 `/start_profile` 主要捕获服务稳态。更细的CPU提交/同步/graph准备字段与SQL统计见08。
