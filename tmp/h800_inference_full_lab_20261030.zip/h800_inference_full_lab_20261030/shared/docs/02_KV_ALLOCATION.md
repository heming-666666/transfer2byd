# 02 · KV分配、共享、COW与真实框架观测

先运行标准库CPU模拟：

```bash
python3 shared/scripts/kv_allocator.py --blocks 8 --block-size 4
```

创建a=[1,2,3] → fork b共享部分块 → b追加触发copy-on-write → a保持原值 → 分别release → 所有ref归零。输出每步pages/refcounts/sequence table、物理slots和逻辑token。它是教学模拟，不是SGLang/vLLM的精确内部实现或GPU性能测量。

| 层次 | SGLang观察 | vLLM观察 |
|---|---|---|
| 池预分配 | startup KV token容量、mem-fraction、max-total-tokens | startup GPU/CPU blocks、kv_cache_memory_bytes、utilization |
| 活跃持有 | running/waiting、请求token使用 | running/waiting、cache usage/blocks |
| 前缀缓存 | Radix命中/可逐出节点 | prefix hash/block命中 |
| 释放/回收 | request结束后活跃持有下降，前缀可仍缓存 | ref下降/可复用块；不要求CUDA reserved归零 |
| 压力/回退 | eviction/retraction、排队与失败 | preemption/recompute、排队与失败 |

固定GQA BF16与KV FP8分别估算payload容量，再与框架日志对照。GQA公式依层数/KV heads/head_dim/token数与分片；KV heads少于TP可能复制，不能简单一律除TP。MLA与V4压缩KV采用不同布局/索引/scalebuffer，先读实际模型config和框架KVspec。

SGLang使用 `8g/4g_kv_pool_32768/65536`，vLLM使用 `8g/4g_kv_pool_low/high`（每rank2/4GiB显式KV预算）。两者单位不同，不把32768tokens与2GiB说成自动等价。

实验：冷唯一前缀 → 热共享前缀 → 请求结束 → 不同新前缀造成逐出 → 并发压力。每段前后采原始metrics与GPU显存；计算活跃/缓存/已预留分别是多少。`nvidia-smi`显示reserved显存不释放是常见池行为，不足以单独判内存泄漏。

通过：请求结果正确、块不会被仍在使用的请求重用，模拟COW测试通过；真实框架需按日志/metrics证明复用/命中与回收。模拟数值不能填进真实GPU结果表。
