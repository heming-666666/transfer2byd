# 12 · 显存归因、allocator快照与CUDA Graph捕获阶段

目标是区分模型权重、KV容量、临时张量、通信缓冲、CUDA Graph及allocator保留量。先做单变量对照，再解释真实引擎；设备显存总占用不能直接拆成这些类别。

## 指标边界

| 指标 | 范围 | 注意 |
|---|---|---|
| torch.memory_allocated | 当前进程PyTorch allocator中的活跃分配 | 不覆盖所有直接CUDA/NCCL分配 |
| torch.memory_reserved | 当前进程allocator管理的segment | 包含可复用空闲块；不能与allocated相加 |
| max_memory_allocated/reserved | 自reset以来峰值 | 多个阶段累积，不能当某个kernel独立峰值 |
| nvidia-smi memory.used | 设备报告的显存使用 | 可能含别的进程、context、非Torch内存等 |
| Profiler memory事件 | 对应算子/分配事件 | 不等于完整设备显存账本 |
| allocator snapshot | PyTorch allocator块状态和记录的历史 | NCCL/direct CUDA分配通常不可见；仅可信文件可加载 |

PyTorch官方明确指出快照只能看到其allocator管理的分配，NCCL是外部分配的常见来源；Graph使用私有内存池。不能把 `NVML设备用量 − 当前rank的reserved` 直接命名为“NCCL大小”：其他rank、进程、context、其他pool和采样时差都混在残差中。来源：[PyTorch 2.14内存快照](https://docs.pytorch.org/docs/stable/torch_cuda_memory)、[CUDA allocator与Graph](https://docs.pytorch.org/docs/stable/notes/cuda)。

## 可执行微实验：先理解allocated和reserved

这是单卡人工buffer+矩阵乘实验；**没有加载模型，不声称真实模型权重/KV占比**。先停止其他实验或选择空闲GPU，使用已完成runtime检查的框架venv。在总根目录：

```bash
CUDA_VISIBLE_DEVICES=0 sglang_lab/environments/sglang0522/.venv/bin/python \
  shared/scripts/memory_probe.py --device 0 --weight-mib 64 --kv-mib 32 \
  --matrix 1024 --replays 20 --output shared/results/memory_probe_trial01
```

vLLM独立使用自己的Torch；两条命令都在总根目录：

```bash
CUDA_VISIBLE_DEVICES=0 vllm_addon/environments/vllm0320/.venv/bin/python \
  shared/scripts/memory_probe.py --device 0 --weight-mib 64 --kv-mib 32 \
  --matrix 1024 --replays 20 --output shared/results/memory_probe_vllm_trial01
```

`--device`是CUDA_VISIBLE_DEVICES过滤后的逻辑编号。对4/8卡无需同时启动4/8份：先单卡理解allocator，再到真实TP4/TP8引擎逐rank观察。人工buffer尺寸是实验参数，不是模型压缩率。

输出 `phases.json` 和8个编号`.pickle`：context→weight-like buffer→KV-like及matmul预热→graph capture→replay→释放KV-like→empty_cache但graph存活→释放graph/全部buffer。比较相邻阶段allocated/reserved/峰值/设备free；不会保证释放后每一个数字回到0，context与库可能保留内存。Graph捕获时间是包围捕获与同步的主机墙钟；replay同时记录主机提交循环墙钟和CUDA event窗口，不能互相相加解释E2E。buffer变化、graph生命周期和图输出固定地址需要一起看。

脚本在parse_args后才import Torch，因此CPU端可以检查`--help`；缺CUDA就失败，不写模拟GPU测量。使用的私有snapshot API在执行前检查，实际Torch版本写结果。仅打开本机可信pickle，保存路径都在项目子目录。离线查看器资产需另行固定和保存；Perfetto可以查看trace，不能直接当PyTorch allocator快照可视化器。

## SGLang：启动捕获阶段

在 `sglang_lab/`，先停止本包旧服务，再在单独终端执行：

```bash
python3 scripts/run.py engine --profile 8g_graphs_on --capture-profiler --dry-run
python3 scripts/run.py engine --profile 8g_graphs_on --capture-profiler
```

4卡使用 `4g_graphs_on`；不能加`--eager`或选择graphs_off。本包新入口对应固定0.5.22的真实 `--enable-profile-cuda-graph`，并设置 `SGLANG_ENABLE_CUDA_GRAPH_CAPTURE_TRACE=1`；输出根沿用项目内 `SGLANG_TORCH_PROFILER_DIR`，每rank合并trace在 `data/traces/graph_capture_profile/`。官方还提供 `SGLANG_GRAPH_BATCH_CAPTURE=1` 的逐batch形式，两者同时设置时合并trace优先；本包入口明确选合并形式。

固定源码会发出CPU/CUDA kernel汇总与 `cuda_graph_runner_memory_usage.pickle`。本次直接核对 `references/upstream/python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py` 的 `_post_process_after_profile`：snapshot使用**当前工作目录下固定文件名**，没有rank后缀。多rank可能复写同一文件；这个文件不能作为全rank独立快照证据，也不保证并发写后的pickle可读。启动前就在 `sglang_lab/`；采集结束先核查产物，再归档到本轮 `data/traces/`，不覆盖下一轮文件。需要可靠的allocator生命周期实验先用上面的单进程微实验；实际多rank快照需要单独适配上游落盘命名并验证，不能假定本包已完成该框架改造。每rankChrome trace有单独命名，按实际文件逐rank分析。

只采decode Graph runner；编译、权重加载、整个HTTP ready的时间需另留外层启动计时和日志。SGLang steady-state用26章的 `/start_profile`，不能在ready以后才开启profiler却宣称测到了启动capture。

## vLLM：捕获与memory事件

回到总根目录，显式调用vLLM自己的入口：

```bash
python3 vllm_addon/scripts/run.py engine --profile 8g_graphs_on --capture-profiler --memory-profiler --dry-run
python3 vllm_addon/scripts/run.py engine --profile 8g_graphs_on --capture-profiler --memory-profiler
```

4卡改profile前缀。固定0.32.0的 `capture_torch_profiler` 采rank0捕获，产物在本框架 `environments/vllm0320/cache/traces/capture_traces/`；不能宣称它自动采到全部rank。新 `--memory-profiler` 设置 `torch_profiler_with_memory=true` 和 `torch_profiler_record_shapes=true`；这是Profiler事件，不承诺自动产生完整allocator snapshot。已有 `/start_profile` `/stop_profile` 控制steady-state采集。若只测steady-state memory，可启动 `8g_profile/4g_profile --memory-profiler` 再用公共profile_capture。

## 真实引擎的对照表

| 实验 | 固定 | 单独改变 | 保存证据 |
|---|---|---|---|
| TP8 vs TP4 | 模型revision、dtype、context、负载 | TP和对应GPU数 | 每rank峰值、设备总量、吞吐/延迟 |
| Graph off vs on | 模型/TP/KV容量与负载 | graph状态/捕获batch集合 | ready时间、capture trace、steady-state trace、显存差 |
| KV容量 | 模型/TP/dtype/请求长度 | 引擎公开KV容量参数 | 实际KV token/block数、OOM/排队/抢占、显存 |
| KV量化 | 模型/TP/长度、校准集 | KV dtype及真实scale | 容量、质量回归、goodput、量化kernel |
| PD | 模型/总卡数、负载 | 同池vsP/D划分 | 两池显存、非零传输字节/等待、最终正文 |

SGLang的mem-fraction-static可能同时影响权重+KV静态池，vLLM的gpu-memory-utilization也不是纯KV比例。不要仅用配置比例推算真实KV字节；保存引擎实际分配日志，再与设备采样对照。Graph开关改变可用KV或最大并发时，先记录这一变化，再分别做“固定KV容量”和“各自最大容量”两类比较。
