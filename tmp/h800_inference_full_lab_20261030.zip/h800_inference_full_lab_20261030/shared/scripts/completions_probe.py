"""Check private prompt-logprob capability before likelihood benchmarks; never widen public gateway."""
import argparse,json,math
from pathlib import Path
from lab_http import ROOT,read,http,save
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--framework',choices=['sglang','vllm'],required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    folder=ROOT/('sglang_lab' if a.framework=='sglang' else 'vllm_addon');c=read(folder/'config/settings.json');auth=read(folder/'config/secrets.json')
    prompt='The capital of France is Paris.'
    body=dict(model=c['model_alias'],prompt=prompt,max_tokens=1,temperature=0,logprobs=1,echo=True)
    with http(f"http://127.0.0.1:{c['engine_port']}/v1/completions",auth['engine_api_key'],body) as f:r=json.load(f)
    choice=r['choices'][0];lp=choice.get('logprobs') or {};values=lp.get('token_logprobs') or []
    ok=len(values)>2 and sum(isinstance(v,(int,float)) and math.isfinite(v) for v in values)>=2 and choice.get('text','').startswith(prompt)
    a.output.parent.mkdir(parents=True,exist_ok=True);save(a.output,dict(prompt=prompt,response=r,capability_probe_pass=ok,
      note='Basic echo/prompt-logprobs gate only; validate tokenizer IDs/alignment and task sample outputs before formal likelihood scores'))
    print('capability_probe_pass:',ok,'output:',a.output)
    if not ok:raise SystemExit('当前engine未通过prompt logprobs探针；不要把chat API生成选项称为likelihood MMLU')
if __name__=='__main__':main()
