"""lm-evaluation-harness chat API route for generation tasks, not likelihood MMLU."""
import argparse,os,subprocess,sys
from pathlib import Path
from lab_http import ROOT,client_config
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--client-config',type=Path,required=True)
    p.add_argument('--task',choices=['gsm8k','ifeval'],default='gsm8k');p.add_argument('--limit',type=int,default=10)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--online-prepare',action='store_true');a=p.parse_args()
    c=client_config(a.client_config);cache=ROOT/'shared/environments/lmeval0413/cache'
    for f in ['huggingface','datasets','tmp','xdg']:(cache/f).mkdir(parents=True,exist_ok=True)
    env=dict(os.environ,OPENAI_API_KEY=c['api_key'],HF_HOME=str(cache/'huggingface'),HF_DATASETS_CACHE=str(cache/'datasets'),
      NLTK_DATA=str(ROOT/'shared/datasets/nltk'),TMPDIR=str(cache/'tmp'),XDG_CACHE_HOME=str(cache/'xdg'))
    if not a.online_prepare:env.update(HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    else:
        for key in ['HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TRANSFORMERS_OFFLINE']:env.pop(key,None)
    args=[sys.executable,'-m','lm_eval','--model','local-chat-completions','--model_args',
      f"model={c['model']},base_url={c['base_url'].rstrip('/')}/chat/completions,tokenized_requests=False,tokenizer_backend=None,num_concurrent=4,max_retries=2",'--apply_chat_template',
      '--tasks',a.task,'--num_fewshot','0','--gen_kwargs','temperature=0,max_gen_toks=4096','--output_path',str(a.output),'--log_samples']
    if a.limit:args+=['--limit',str(a.limit)]
    print('lm-eval generation task:',a.task,'offline:',not a.online_prepare,'output:',a.output,flush=True)
    raise SystemExit(subprocess.run(args,env=env).returncode)
if __name__=='__main__':main()
