"""Prepare / install isolated evaluation tool environments. Build source wheels only on preparation host."""
import argparse,hashlib,json,os,platform,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
TOOLS={'evalscope':'evalscope1141','lm_eval':'lmeval0413'}
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
    return h.hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--tool',choices=list(TOOLS),required=True);p.add_argument('--mode',choices=['prepare','install'],required=True);p.add_argument('--rebuild',action='store_true');a=p.parse_args()
    if platform.system()!='Linux' or platform.machine()!='x86_64' or sys.version_info[:2]!=(3,12):p.error('需 Linux x86_64 CPython3.12；使用项目 portable Python')
    folder=ROOT/'shared/environments'/TOOLS[a.tool];wheels=folder/'wheelhouse';wheels.mkdir(parents=True,exist_ok=True);req=folder/'requirements.in'
    env=dict(os.environ,PIP_CACHE_DIR=str(folder/'cache/pip'),TMPDIR=str(folder/'cache/tmp'),PIP_CONFIG_FILE=os.devnull,PIP_DISABLE_PIP_VERSION_CHECK='1')
    Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
    if a.mode=='prepare':
        subprocess.run([sys.executable,'-m','pip','wheel','--pre','--wheel-dir',str(wheels),'-r',str(req)],env=env,check=True)
        report=folder/'resolution.json'
        subprocess.run([sys.executable,'-m','pip','install','--dry-run','--ignore-installed','--no-index','--only-binary=:all:',
          '--find-links',str(wheels),'--report',str(report),'-r',str(req)],env=env,check=True)
        resolved=json.loads(report.read_text())['install'];lock=folder/'requirements.lock'
        lock.write_text(''.join(x['metadata']['name']+'=='+x['metadata']['version']+'\n' for x in resolved))
        files=[req,lock,report,*sorted(wheels.glob('*.whl'))]
        manifest={'tool':a.tool,'python':'3.12','files':[{'path':str(f.relative_to(folder)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]}
        (folder/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n');print('PREPARED',folder);return
    manifest=json.loads((folder/'MANIFEST.json').read_text())
    for row in manifest['files']:
        f=(folder/row['path']).resolve()
        if not f.is_relative_to(folder) or not f.is_file() or f.stat().st_size!=row['bytes'] or sha(f)!=row['sha256']:raise SystemExit('校验失败 '+row['path'])
    if {f.name for f in wheels.glob('*.whl')}!={Path(x['path']).name for x in manifest['files'] if x['path'].endswith('.whl')}:raise SystemExit('wheelhouse 集合变化，重新 prepare')
    venv=folder/'.venv';py=venv/'bin/python3'
    if not py.exists() or a.rebuild:subprocess.run([sys.executable,'-m','venv','--clear',str(venv)],check=True)
    subprocess.run([str(py),'-m','pip','install','--no-index','--only-binary=:all:','--find-links',str(wheels),'-r',str(folder/'requirements.lock')],env=env,check=True)
    subprocess.run([str(py),'-m','pip','check'],env=env,check=True);print('INSTALLED',venv)
if __name__=='__main__':main()
