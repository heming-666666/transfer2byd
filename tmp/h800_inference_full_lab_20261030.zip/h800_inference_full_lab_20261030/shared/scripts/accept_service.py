"""Public-endpoint acceptance: 401, model alias, final text, streaming and remembered two-turn code."""
import argparse
import json
import math
import secrets
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from lab_http import ROOT, chat, client_config, output_dir, read, save, validate_extra
from measurement_clock import anchor


def request(url, key, payload=None, timeout=180):
    headers = {'Content-Type': 'application/json'}
    if key is not None:
        headers['Authorization'] = 'Bearer ' + key
    data = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode() if payload is not None else None
    req = urllib.request.Request(url, data, headers)
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=timeout) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read(8192)


def check_service(c, max_tokens, extra, timeout):
    validate_extra(extra)
    checks = []
    history = []
    base = c['base_url'].rstrip('/')
    nonce = secrets.token_hex(4).upper()
    clock = anchor()

    def run(name, action):
        try:
            detail = action()
            checks.append(dict(name=name, passed=True, detail=detail))
            return True
        except Exception as e:
            # A backend may echo request headers in errors. Redact configured public key.
            checks.append(dict(name=name, passed=False, error=str(e).replace(c['api_key'], '[REDACTED]')[:2000]))
            return False

    def unauthorized(key):
        status, _ = request(base+'/models', key, timeout=timeout)
        if status != 401:
            raise ValueError('expected HTTP 401, got '+str(status))
        return dict(http_status=status)

    def models():
        status, body = request(base+'/models', c['api_key'], timeout=timeout)
        if status != 200:
            raise ValueError('models HTTP '+str(status))
        names = [x['id'] for x in json.loads(body)['data']]
        if c['model'] not in names:
            raise ValueError('configured model alias absent')
        return dict(model=c['model'])

    def nonstream():
        payload = dict(model=c['model'], messages=[dict(role='user', content='请用一句简短中文说明 KV Cache 的作用。')],
                       max_tokens=max_tokens, temperature=0, stream=False)
        payload.update(extra)
        status, body = request(base+'/chat/completions', c['api_key'], payload, timeout)
        if status != 200:
            raise ValueError('nonstream HTTP '+str(status))
        choice = json.loads(body)['choices'][0]
        content = choice['message'].get('content')
        if not isinstance(content, str) or not content.strip() or choice.get('finish_reason') != 'stop':
            raise ValueError('nonstream needs final text and finish_reason=stop; check thinking/token budget/parser')
        return dict(final_characters=len(content), finish_reason=choice['finish_reason'])

    def stream_first():
        history.append(dict(role='user', content=f'记住校验码 {nonce}。请只回复“已记住”。'))
        r = chat(c, history, max_tokens, extra, timeout)
        if not r['content'].strip() or r['finish_reason'] != 'stop':
            raise ValueError('stream needs final text and stop; reasoning-only/length is insufficient for acceptance')
        history.append(dict(role='assistant', content=r['content']))
        return dict(final_characters=len(r['content']), finish_reason=r['finish_reason'], delta_count=len(r['delta_times_ms']))

    def stream_second():
        history.append(dict(role='user', content='上一轮的校验码是什么？只输出校验码。'))
        r = chat(c, history, max_tokens, extra, timeout)
        if r['finish_reason'] != 'stop' or nonce not in r['content'].upper():
            raise ValueError('two-turn code recall failed; inspect conversation, template, budget and model behavior')
        history.append(dict(role='assistant', content=r['content']))
        return dict(history_messages_sent=3, remembered_code=True, finish_reason=r['finish_reason'])

    run('missing_key_401', lambda: unauthorized(None))
    run('wrong_key_401', lambda: unauthorized('invalid-' + secrets.token_hex(16)))
    model_ok = run('models_alias', models)
    if model_ok:
        run('nonstream_final_text', nonstream)
        if run('stream_final_text_and_done', stream_first):
            run('two_turn_history_and_code', stream_second)
    report = dict(schema_version=1, clock=clock, base_url=base, model=c['model'], max_tokens=max_tokens,
                  passed=len(checks) == 6 and all(x['passed'] for x in checks), checks=checks,
                  scope='public API function and simple code recall; not model quality, throughput or GPU health certification')
    return report, history


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--client-config', type=Path, required=True)
    p.add_argument('--max-tokens', type=int, default=2048)
    p.add_argument('--timeout', type=float, default=300)
    p.add_argument('--extra-json', type=Path)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    if a.max_tokens < 1 or not math.isfinite(a.timeout) or a.timeout <= 0:
        p.error('max-tokens/timeout 须为有限正数')
    c = client_config(a.client_config)
    extra = read(a.extra_json) if a.extra_json else {}
    try:
        validate_extra(extra)
    except ValueError as e:
        p.error(str(e))
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    out = output_dir(a.output or ROOT/'shared/results/acceptance'/stamp)
    report, history = check_service(c, a.max_tokens, extra, a.timeout)
    save(out/'acceptance.json', report)
    save(out/'conversation.json', dict(messages=history, note='client replayed user/assistant content only; no API key or private reasoning'))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print('output:', out)
    if not report['passed']:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
