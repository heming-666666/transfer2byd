"""CPU teaching simulator: paged KV blocks, refcounts, fork and copy-on-write.
Not a measurement or exact implementation of SGLang/vLLM caches.
"""
import argparse,json
class Pool:
    def __init__(self,blocks=8,block_size=4):
        if min(blocks,block_size)<1:raise ValueError('positive capacity required')
        self.capacity=blocks;self.block_size=block_size;self.pages={};self.refs={};self.sequences={}
    def new_page(self,values=()):
        free=next((i for i in range(self.capacity) if i not in self.pages),None)
        if free is None:raise MemoryError('no free KV blocks')
        self.pages[free]=list(values);self.refs[free]=1;return free
    def create(self,name):
        if name in self.sequences:raise ValueError('duplicate sequence')
        self.sequences[name]=[]
    def fork(self,source,target):
        if target in self.sequences:raise ValueError('duplicate target')
        self.sequences[target]=list(self.sequences[source])
        for b in self.sequences[target]:self.refs[b]+=1
    def append(self,name,tokens):
        blocks=self.sequences[name]
        for token in tokens:
            if not blocks or len(self.pages[blocks[-1]])==self.block_size:blocks.append(self.new_page())
            elif self.refs[blocks[-1]]>1:
                old=blocks[-1];fresh=self.new_page(self.pages[old]);self.refs[old]-=1;blocks[-1]=fresh
            self.pages[blocks[-1]].append(token)
            self.check()
    def tokens(self,name):return [v for b in self.sequences[name] for v in self.pages[b]]
    def release(self,name):
        for b in self.sequences.pop(name):
            self.refs[b]-=1
            if not self.refs[b]:del self.refs[b];del self.pages[b]
        self.check()
    def check(self):
        actual={b:sum(s.count(b) for s in self.sequences.values()) for b in self.pages}
        assert actual==self.refs and all(0<len(v)<=self.block_size for v in self.pages.values())
    def state(self):return dict(capacity=self.capacity,block_size=self.block_size,pages=self.pages,refs=self.refs,sequences=self.sequences,
      physical_token_slots=len(self.pages)*self.block_size,logical_tokens=sum(len(self.tokens(s)) for s in self.sequences))
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--blocks',type=int,default=8);ap.add_argument('--block-size',type=int,default=4);a=ap.parse_args()
    p=Pool(a.blocks,a.block_size);p.create('a');p.append('a',[1,2,3]);p.fork('a','b');print('shared',json.dumps(p.state()))
    p.append('b',[4,5]);assert p.tokens('a')==[1,2,3];print('copy_on_write',json.dumps(p.state()))
    p.release('a');p.release('b');assert not p.pages;print('PASS: all pages released')
if __name__=='__main__':main()
