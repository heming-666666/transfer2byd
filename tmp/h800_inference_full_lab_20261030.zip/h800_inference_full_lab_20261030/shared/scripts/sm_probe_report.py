"""Analyze this probe's recorded CTA intervals; not arbitrary vendor kernels or full GPU occupancy."""
import argparse,collections,json
from pathlib import Path
def report(rows,capacity):
    changes=collections.defaultdict(collections.Counter);ids=set();migrated=[];valid=[]
    for index,(begin_sm,end_sm,start,stop) in enumerate(rows):
        if stop<start:raise ValueError('globaltimer moved backwards')
        if begin_sm!=end_sm:migrated.append(index);continue
        ids.add(begin_sm);valid.append((index,begin_sm,start,stop))
        changes[start][begin_sm]+=1;changes[stop][begin_sm]-=1
    live=collections.Counter();previous=None;segments=[]
    for t in sorted(changes):
        if previous is not None and t>previous:segments.append(dict(start_ns=previous,end_ns=t,active_recorded_SM_count=sum(v>0 for v in live.values())))
        live.update(changes[t]);assert all(v>=0 for v in live.values());previous=t
    assert not any(live.values())
    duration=sum(s['end_ns']-s['start_ns'] for s in segments)
    active_area=sum((s['end_ns']-s['start_ns'])*s['active_recorded_SM_count'] for s in segments)
    return dict(device_SM_capacity=capacity,blocks=len(rows),valid_blocks=len(valid),migrated_blocks=migrated,
      distinct_recorded_SM_ids=sorted(ids),distinct_recorded_SM_count=len(ids),max_concurrent_recorded_SM_count=max((s['active_recorded_SM_count'] for s in segments),default=0),
      time_average_recorded_SM_count=active_area/duration if duration else None,segments=segments,
      limitation='Only this probe and its marker-delimited intervals. Start/end SM equality cannot rule out unseen migration out and back. No claim about arbitrary kernels, per-cycle activity or warp occupancy.')
def chrome_trace(rows,rank):
    valid=[r for r in rows if r[0]==r[1]];base=min((r[2] for r in valid),default=0);events=[]
    for sm in sorted({r[0] for r in valid}):events.append(dict(ph='M',name='thread_name',pid=rank,tid=sm,args={'name':f'SM {sm}'}))
    for i,(sm,sm2,start,stop) in enumerate(rows):
        if sm!=sm2:continue
        events.append(dict(ph='X',cat='probe_cta_interval',name=f'block {i}',pid=rank,tid=sm,ts=(start-base)/1000,dur=(stop-start)/1000))
    return dict(traceEvents=events,displayTimeUnit='ns')
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('raw',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    data=json.loads(a.raw.read_text());r=report(data['rows'],data['device_SM_capacity']);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');print('output:',a.output)
if __name__=='__main__':main()
