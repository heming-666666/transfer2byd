"""Pinned EvalScope generative API evaluation using verified local datasets."""
import argparse,json,os,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
from lab_http import ROOT,client_config,read,save
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--client-config',type=Path,required=True);p.add_argument('--dataset-config',type=Path,required=True)
    p.add_argument('--tasks',nargs='+',default=['gsm8k']);p.add_argument('--limit',type=int,default=10,help='0 means full dataset; default 10 is process smoke only')
    p.add_argument('--max-tokens',type=int,default=4096);p.add_argument('--concurrency',type=int,default=4);p.add_argument('--output',type=Path)
    p.add_argument('--dry-run',action='store_true');a=p.parse_args();c=client_config(a.client_config);ds=read(a.dataset_config)
    if a.limit<0:p.error('limit>=0')
    code_tasks={'humaneval','mbpp','livecodebench','apps'}
    if code_tasks.intersection(a.tasks):p.error('代码执行评测需隔离 VM/sandbox；此 root API 入口只运行非执行任务')
    for t in a.tasks:
        if t not in ds:p.error('任务未在 dataset-config 中定义 '+t)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ');out=a.output or ROOT/'shared/results/quality'/stamp
    task=dict(model=c['model'],api_url=c['base_url'],eval_type='openai_api',datasets=a.tasks,
      dataset_hub='huggingface',dataset_args={t:dict(local_path=str(ROOT/'shared/datasets'/ds[t]['directory']),few_shot_num=ds[t].get('few_shot_num',0),few_shot_random=False) for t in a.tasks},
      generation_config=dict(temperature=0,max_tokens=a.max_tokens),eval_batch_size=a.concurrency,work_dir=str(out),ignore_errors=False)
    if a.limit:task['limit']=a.limit
    manifest=dict(tool='evalscope==1.14.1',task_without_key=task,datasets={t:ds[t] for t in a.tasks},
      scope='SMOKE_ONLY_NOT_FULL_BENCHMARK' if a.limit else 'FULL_DATASET',status='DRY_RUN' if a.dry_run else 'STARTED')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))
    if a.dry_run:return
    out.mkdir(parents=True,exist_ok=False);save(out/'lab_manifest.json',manifest)
    cache=ROOT/'shared/environments/evalscope1141/cache'
    os.environ.update(HF_HOME=str(cache/'huggingface'),HF_DATASETS_CACHE=str(cache/'datasets'),HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',
      TRANSFORMERS_OFFLINE='1',NLTK_DATA=str(ROOT/'shared/datasets/nltk'),MODELSCOPE_CACHE=str(cache/'modelscope'),
      XDG_CACHE_HOME=str(cache/'xdg'),TMPDIR=str(cache/'tmp'))
    Path(os.environ['TMPDIR']).mkdir(parents=True,exist_ok=True)
    subprocess.run([sys.executable,str(ROOT/'shared/scripts/prepare_datasets.py'),'--config',str(a.dataset_config),'--tasks',*a.tasks,'--verify-only'],check=True)
    import importlib.metadata as m
    if m.version('evalscope')!='1.14.1':raise SystemExit('EvalScope 版本不符')
    from evalscope.config import TaskConfig
    from evalscope.run import run_task
    try:
        # Pydantic SecretStr masks key in serialized tool config; never write a plain task dict with key.
        run_task(task_cfg=TaskConfig(**task,api_key=c['api_key']))
        manifest['status']='TOOL_FINISHED_REVIEW_ERROR_AND_TRUNCATION_COUNTS'
    except Exception:
        manifest['status']='FAILED';raise
    finally:save(out/'lab_manifest.json',manifest)
if __name__=='__main__':main()
