"""Serve a prepared Perfetto ui/out/dist offline, on client loopback, with isolation headers."""
import argparse,functools,http.server
from pathlib import Path
class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cross-Origin-Opener-Policy','same-origin');self.send_header('Cross-Origin-Embedder-Policy','require-corp');super().end_headers()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',type=Path,required=True);p.add_argument('--port',type=int,default=10000);a=p.parse_args()
    if not (a.directory/'index.html').is_file():p.error('先准备完整 Perfetto ui/out/dist，不能只复制 index.html')
    s=http.server.ThreadingHTTPServer(('127.0.0.1',a.port),functools.partial(Handler,directory=str(a.directory.resolve())))
    print(f'Offline Perfetto: http://127.0.0.1:{a.port}');s.serve_forever()
if __name__=='__main__':main()
