"""Read Nsight exported SQLite: kernel counts/durations, CUDA API walls, per-device busy interval union.
Does not infer SM counts, NCCL wire time, CPU busy time or ambiguous multi-process correlation joins.
"""
import argparse,collections,json,sqlite3
from pathlib import Path
def union_ns(spans):
    total=0;left=right=None
    for a,b in sorted(spans):
        if b<a:raise ValueError('negative interval')
        if left is None:left,right=a,b
        elif a<=right:right=max(right,b)
        else:total+=right-left;left,right=a,b
    return total+(right-left if left is not None else 0)
def analyze(path,events_path=None):
    db=sqlite3.connect(f'file:{Path(path).resolve()}?mode=ro',uri=True);db.row_factory=sqlite3.Row
    tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")};strings={}
    if 'StringIds' in tables:
        try:strings={x[0]:x[1] for x in db.execute('SELECT id,value FROM StringIds')}
        except sqlite3.Error:pass
    result={'tables':sorted(tables),'kernel_groups':[],'cuda_api_groups':[],'device_kernel_interval_union':[]}
    kt=next((x for x in ['CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL'] if x in tables),None)
    if not kt:raise ValueError('无 kernel activity 表；确认 --trace=cuda / --cuda-graph-trace=node 及 export schema')
    cols={r[1] for r in db.execute('PRAGMA table_info('+kt+')')};result['kernel_columns']=sorted(cols)
    namecol=next((c for c in ['demangledName','shortName','name'] if c in cols),None)
    if not {'start','end'}.issubset(cols):raise ValueError('未知 timestamp schema')
    stats=collections.defaultdict(lambda:dict(calls=0,total_ns=0,min_ns=None,max_ns=0));spans=collections.defaultdict(list)
    event_file=None
    if events_path:
        events_path=Path(events_path);events_path.parent.mkdir(parents=True,exist_ok=True);event_file=events_path.open('w')
    for r in db.execute('SELECT * FROM '+kt):
        dev=r['deviceId'] if 'deviceId' in cols else 'unknown';pid=r['globalPid'] if 'globalPid' in cols else 'unknown'
        name=r[namecol] if namecol else 'unknown';name=str(strings.get(name,name));dur=r['end']-r['start'];k=(dev,pid,name);s=stats[k]
        s['calls']+=1;s['total_ns']+=dur;s['min_ns']=min(s['min_ns'],dur) if s['min_ns'] is not None else dur;s['max_ns']=max(s['max_ns'],dur)
        spans[dev].append((r['start'],r['end']))
        if event_file:
            event=dict(device=dev,global_pid=pid,name=name,start_ns=r['start'],end_ns=r['end'],duration_ns=dur)
            for field in ['contextId','streamId','correlationId']:
                if field in cols:event[field]=r[field]
            event_file.write(json.dumps(event,ensure_ascii=False)+'\n')
    if event_file:event_file.close()
    result['kernel_groups']=[dict(device=k[0],global_pid=k[1],name=k[2],**v,mean_ns=v['total_ns']/v['calls']) for k,v in sorted(stats.items(),key=lambda kv:kv[1]['total_ns'],reverse=True)]
    for dev,iv in spans.items():
        elapsed=max(x[1] for x in iv)-min(x[0] for x in iv);busy=union_ns(iv)
        result['device_kernel_interval_union'].append(dict(device=dev,kernel_calls=len(iv),distinct_names=len({k[2] for k in stats if k[0]==dev}),
          kernel_busy_union_ns=busy,first_to_last_kernel_ns=elapsed,busy_ratio_in_first_to_last=busy/elapsed if elapsed else None))
    for table in ['CUPTI_ACTIVITY_KIND_RUNTIME','CUPTI_ACTIVITY_KIND_DRIVER']:
        if table not in tables:continue
        columns={r[1] for r in db.execute('PRAGMA table_info('+table+')')};nc=next((x for x in ['nameId','name'] if x in columns),None)
        if not nc or not {'start','end'}.issubset(columns):continue
        agg=collections.defaultdict(lambda:[0,0])
        for row in db.execute('SELECT * FROM '+table):
            name=str(strings.get(row[nc],row[nc]));agg[name][0]+=1;agg[name][1]+=row['end']-row['start']
        result['cuda_api_groups'] +=[dict(table=table,name=k,calls=v[0],total_host_wall_ns=v[1]) for k,v in sorted(agg.items(),key=lambda kv:kv[1][1],reverse=True)]
    result['notes']=['All timestamps/durations are ns in this Nsight schema.','Kernel duration sums overlap across streams/GPUs; union is computed per device only.',
      'CUDA API elapsed time may include blocking/waiting; runtime and driver tables can nest and must not be added together.',
      'No active SM count can be derived from this activity database. Correlation IDs require process-aware joins; use Nsight UI flow arrows for CPU→GPU attribution.']
    db.close();return result
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('sqlite',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--events',type=Path,help='Optional per-kernel time/device/stream JSONL for exact timeline filtering');a=p.parse_args();r=analyze(a.sqlite,a.events)
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
    print('kernel launches:',sum(x['calls'] for x in r['kernel_groups']),'distinct device/process/name groups:',len(r['kernel_groups']),'output:',a.output)
if __name__=='__main__':main()
