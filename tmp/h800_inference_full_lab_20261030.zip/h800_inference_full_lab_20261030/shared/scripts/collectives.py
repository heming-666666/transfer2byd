"""torchrun NCCL microbench: rank-correctness first, then per-rank algorithm bandwidth."""
import argparse,json,os,time
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--op',choices=['all_reduce','all_gather','reduce_scatter','all_to_all'],default='all_reduce')
    p.add_argument('--mib',type=int,default=64);p.add_argument('--warmup',type=int,default=5);p.add_argument('--iterations',type=int,default=30);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    import torch,torch.distributed as d
    local=int(os.environ['LOCAL_RANK']);torch.cuda.set_device(local);d.init_process_group('nccl');rank=d.get_rank();w=d.get_world_size()
    count=max(w,(a.mib*1024**2//4//w)*w)
    x=torch.full((count,),rank+1,dtype=torch.float32,device='cuda')
    if a.op=='all_reduce':out=x.clone()
    elif a.op=='all_gather':out=torch.empty(count*w,device='cuda')
    elif a.op=='reduce_scatter':out=torch.empty(count//w,device='cuda')
    else:out=torch.empty_like(x)
    def run():
        if a.op=='all_reduce':out.copy_(x);d.all_reduce(out)
        elif a.op=='all_gather':d.all_gather_into_tensor(out,x)
        elif a.op=='reduce_scatter':d.reduce_scatter_tensor(out,x)
        else:d.all_to_all_single(out,x)
    run();torch.cuda.synchronize()
    if a.op in ('all_reduce','reduce_scatter'):assert torch.all(out==w*(w+1)//2)
    else:assert all(torch.all(chunk==i+1) for i,chunk in enumerate(out.chunk(w)))
    for _ in range(a.warmup):run()
    torch.cuda.synchronize();d.barrier();t=time.perf_counter()
    for _ in range(a.iterations):run()
    torch.cuda.synchronize();elapsed=(time.perf_counter()-t)/a.iterations
    times=torch.tensor([elapsed],device='cuda',dtype=torch.float64);d.all_reduce(times,op=d.ReduceOp.MAX);elapsed=times.item()
    if rank==0:
        # Count per-rank input payload; gather output is world times larger. No universal busbw formula applied.
        result=dict(op=a.op,world_size=w,input_bytes_per_rank=x.numel()*x.element_size(),output_bytes_per_rank=out.numel()*out.element_size(),
          slowest_rank_mean_ms=elapsed*1000,input_GBps=(x.numel()*4)/elapsed/1e9,verified=True,
          note='wall includes all_reduce reset copy_; report is input-normalized algorithm rate, not measured NVLink bus bandwidth')
        a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    d.destroy_process_group()
if __name__=='__main__':main()
