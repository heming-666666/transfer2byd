"""Sequence-parallel LayerNorm equality: AllReduce+LN vs ReduceScatter+LN+AllGather."""
import argparse,json,os,time
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--tokens',type=int,default=8192);p.add_argument('--hidden',type=int,default=2048)
    p.add_argument('--iterations',type=int,default=20);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    import torch,torch.distributed as d,torch.nn.functional as F
    torch.cuda.set_device(int(os.environ['LOCAL_RANK']));d.init_process_group('nccl');r=d.get_rank();w=d.get_world_size()
    if a.tokens%w:raise SystemExit('tokens 必须整除 world_size')
    torch.manual_seed(42);x=torch.randn(a.tokens,a.hidden,device='cuda')*(r+1)
    full=torch.empty_like(x);shard=torch.empty(a.tokens//w,a.hidden,device='cuda');gathered=torch.empty_like(x)
    def baseline():full.copy_(x);d.all_reduce(full);return F.layer_norm(full,(a.hidden,))
    def sp():d.reduce_scatter_tensor(shard,x);y=F.layer_norm(shard,(a.hidden,));d.all_gather_into_tensor(gathered,y);return gathered
    y0=baseline();y1=sp();torch.cuda.synchronize();err=(y0-y1).abs().max().item();assert torch.allclose(y0,y1,atol=1e-5,rtol=1e-4)
    result=dict(world_size=w,max_abs_error=err,full_activation_bytes=full.numel()*4,sharded_activation_bytes=shard.numel()*4,
      note='Teaching microbench allocates all buffers to compare; its total allocated memory is not expected to shrink by world_size')
    for name,fn in [('allreduce_ln',baseline),('rs_ln_ag',sp)]:
        for _ in range(3):fn()
        torch.cuda.synchronize();d.barrier();t=time.perf_counter()
        for _ in range(a.iterations):fn()
        torch.cuda.synchronize();v=torch.tensor([(time.perf_counter()-t)/a.iterations*1000],device='cuda');d.all_reduce(v,op=d.ReduceOp.MAX);result[name+'_ms']=v.item()
    if r==0:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    d.destroy_process_group()
if __name__=='__main__':main()
