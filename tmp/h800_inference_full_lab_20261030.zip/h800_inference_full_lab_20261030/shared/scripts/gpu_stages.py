"""4/8-rank timing experiment: CPU submit, NCCL wait, matmul, CUDA Graph capture/replay.
Times are named by measured boundaries. CPU wall time of a CUDA API is not CPU busy time.
"""
import argparse,contextlib,json,os,time
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cards',type=int,choices=[4,8],default=8)
    p.add_argument('--matrix',type=int,default=2048);p.add_argument('--iterations',type=int,default=10);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--no-torch-profiler',action='store_true',help='Use when Nsight owns CUPTI; do not run both profilers together');a=p.parse_args()
    import torch,torch.distributed as d
    from torch.profiler import profile,ProfilerActivity,record_function
    local=int(os.environ['LOCAL_RANK']);torch.cuda.set_device(local);d.init_process_group('nccl');rank=d.get_rank()
    if d.get_world_size()!=a.cards:p.error('torchrun world_size 必须与 --cards 相同')
    a.output.mkdir(parents=True,exist_ok=True)
    x=torch.randn(a.matrix,a.matrix,device='cuda',dtype=torch.bfloat16);y=torch.randn_like(x);z=torch.empty_like(x)
    for _ in range(5):torch.mm(x,y,out=z)
    torch.cuda.synchronize();d.barrier();rows=[]
    prof_context=contextlib.nullcontext() if a.no_torch_profiler else profile(activities=[ProfilerActivity.CPU,ProfilerActivity.CUDA],record_shapes=True,with_stack=True)
    with prof_context as prof:
        for i in range(a.iterations):
            v=torch.ones(1024*1024,device='cuda',dtype=torch.float32);torch.cuda.synchronize()
            begin=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True);begin.record()
            with record_function('comm_submit::all_reduce'),torch.cuda.nvtx.range('comm_submit::all_reduce'):
                t=time.perf_counter();work=d.all_reduce(v,async_op=True);submit=(time.perf_counter()-t)*1000
            t=time.perf_counter()
            with record_function('comm_work_wait'),torch.cuda.nvtx.range('comm_work_wait'):work.wait()
            host_wait=(time.perf_counter()-t)*1000;end.record();t=time.perf_counter();torch.cuda.synchronize();sync=(time.perf_counter()-t)*1000
            assert torch.all(v==a.cards)
            rows.append(dict(iteration=i,cpu_submit_wall_ms=submit,work_wait_host_wall_ms=host_wait,
                explicit_device_sync_wall_ms=sync,gpu_stream_elapsed_ms=begin.elapsed_time(end)))
        # Warm up on a side stream before capture; capture contains fixed-address GEMM only.
        side=torch.cuda.Stream();side.wait_stream(torch.cuda.current_stream());t=time.perf_counter()
        with torch.cuda.stream(side):
            for _ in range(3):torch.mm(x,y,out=z)
        torch.cuda.current_stream().wait_stream(side);torch.cuda.synchronize();warmup=(time.perf_counter()-t)*1000
        t=time.perf_counter();graph=torch.cuda.CUDAGraph();object_ms=(time.perf_counter()-t)*1000
        with record_function('graph_capture_wall'),torch.cuda.nvtx.range('graph_capture_wall'):
            t=time.perf_counter()
            with torch.cuda.graph(graph,stream=side):torch.mm(x,y,out=z)
            capture=(time.perf_counter()-t)*1000
        replays=[]
        for i in range(a.iterations):
            start=torch.cuda.Event(enable_timing=True);stop=torch.cuda.Event(enable_timing=True);start.record()
            t=time.perf_counter()
            with record_function('graph_replay_submit'),torch.cuda.nvtx.range('graph_replay_submit'):graph.replay()
            cpu_ms=(time.perf_counter()-t)*1000;stop.record();torch.cuda.synchronize();replays.append(dict(i=i,cpu_submit_wall_ms=cpu_ms,gpu_stream_ms=start.elapsed_time(stop)))
    if prof is not None:
        prof.export_chrome_trace(str(a.output/f'rank{rank}.trace.json'))
        averages=[dict(name=e.key,count=e.count,self_cpu_time_us=e.self_cpu_time_total,cpu_total_time_us=e.cpu_time_total,
          self_device_time_us=getattr(e,'self_device_time_total',None),device_total_time_us=getattr(e,'device_time_total',None),input_shapes=e.input_shapes)
          for e in prof.key_averages(group_by_input_shape=True)]
        (a.output/f'rank{rank}.operators.json').write_text(json.dumps(averages,indent=2)+'\n')
    prop=torch.cuda.get_device_properties(local)
    result=dict(rank=rank,world_size=a.cards,device=prop.name,device_SM_count=prop.multi_processor_count,
      nccl=rows,graph=dict(warmup_wall_ms=warmup,object_construction_wall_ms=object_ms,capture_context_wall_ms=capture,replays=replays),
      note='capture_context includes Python/CUDA capture/instantiation work as implemented by PyTorch; use Nsight API trace to isolate cudaGraphInstantiate. SM capacity is not measured active SM count.')
    (a.output/f'rank{rank}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'rank':rank,'output':str(a.output)},indent=2))
    d.destroy_process_group()
if __name__=='__main__':main()
