"""Control private profiler endpoints and generate a short workload; public gateway stays restricted."""
import argparse,json
from pathlib import Path
from lab_http import ROOT,read,http,chat,save
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--framework',choices=['sglang','vllm'],required=True)
    p.add_argument('--target',choices=['engine','prefill','decode'],default='engine');p.add_argument('--action',choices=['start','stop','capture'],default='capture')
    p.add_argument('--requests',type=int,default=6);p.add_argument('--max-tokens',type=int,default=128);a=p.parse_args()
    folder=ROOT/('sglang_lab' if a.framework=='sglang' else 'vllm_addon');c=read(folder/'config/settings.json');auth=read(folder/'config/secrets.json')
    url=f"http://127.0.0.1:{c[a.target+'_port']}";key=auth['admin_api_key'] if a.framework=='sglang' else auth['engine_api_key']
    trace=(folder/'data/traces'/a.target).resolve();trace.mkdir(parents=True,exist_ok=True)
    payload={'output_dir':str(trace),'activities':['CPU','GPU'],'with_stack':True,'record_shapes':True} if a.framework=='sglang' else {}
    if a.action in ('start','capture'):
        with http(url+'/start_profile',key,payload) as f:print(f.read().decode(errors='replace'))
    if a.action=='capture':
        public=read(folder/'config/client.json')
        try:
            for _ in range(a.requests):chat(public,[{'role':'user','content':'请解释 KV Cache、TP 和通信开销。'}],a.max_tokens)
        finally:
            with http(url+'/stop_profile',key,{}) as f:print(f.read().decode(errors='replace'))
    elif a.action=='stop':
        with http(url+'/stop_profile',key,{}) as f:print(f.read().decode(errors='replace'))
    print('SGLang trace target:',trace,'; vLLM uses configured torch_profiler_dir in cache/traces')
if __name__=='__main__':main()
