"""Download pinned dataset snapshots + NLTK assets into shared/; no model API required."""
import argparse,hashlib,json,os,re
from pathlib import Path
from lab_http import ROOT,read,save
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
    return h.hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',type=Path,required=True);p.add_argument('--tasks',nargs='+',default=['gsm8k','ifeval']);p.add_argument('--verify-only',action='store_true');a=p.parse_args()
    cfg=read(a.config);base=ROOT/'shared/datasets';cache=ROOT/'shared/environments/evalscope1141/cache'
    os.environ.update(HF_HOME=str(cache/'huggingface'),HF_DATASETS_CACHE=str(cache/'datasets'),NLTK_DATA=str(base/'nltk'))
    for task in a.tasks:
        m=cfg[task];rev=m['revision']
        if not re.fullmatch('[0-9a-fA-F]{40}',rev):p.error('请将 '+task+' revision 改为数据集真实完整 commit SHA')
        dest=(base/m['directory']).resolve()
        if not dest.is_relative_to(base):p.error('dataset directory 不能越出 shared/datasets')
        manifest_path=dest/'LAB_DATASET_MANIFEST.json'
        if a.verify_only:
            manifest=read(manifest_path)
            if manifest['revision']!=rev:raise SystemExit('数据集 revision 与 manifest 不同')
            for row in manifest['files']:
                f=(dest/row['path']).resolve()
                if not f.is_relative_to(dest) or not f.is_file() or digest(f)!=row['sha256']:raise SystemExit('数据缺失/损坏 '+str(f))
            print('VERIFIED',task);continue
        from huggingface_hub import snapshot_download
        snapshot_download(repo_id=m['repo_id'],repo_type='dataset',revision=rev,local_dir=dest)
        files=[f for f in dest.rglob('*') if f.is_file() and '.cache' not in f.relative_to(dest).parts and f.name!='LAB_DATASET_MANIFEST.json']
        save(manifest_path,dict(task=task,repo_id=m['repo_id'],revision=rev,files=[dict(path=f.relative_to(dest).as_posix(),bytes=f.stat().st_size,sha256=digest(f)) for f in sorted(files)]));print('PREPARED',task,dest)
    if not a.verify_only and 'ifeval' in a.tasks:
        import nltk
        for resource in ['punkt','punkt_tab','averaged_perceptron_tagger_eng']:
            if not nltk.download(resource,download_dir=str(base/'nltk'),quiet=True):raise SystemExit('NLTK resource download failed '+resource)
if __name__=='__main__':main()
