"""Freeze/verify local cache or asset bytes, independently of mutable upstream aliases."""
import argparse,hashlib,json
from pathlib import Path
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
    return h.hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--verify',action='store_true');a=p.parse_args();root=a.root.resolve()
    if a.verify:
        rows=json.loads(a.manifest.read_text())['files']
        for row in rows:
            f=(root/row['path']).resolve()
            if not f.is_relative_to(root) or not f.is_file() or f.stat().st_size!=row['bytes'] or digest(f)!=row['sha256']:raise SystemExit('校验失败 '+row['path'])
        print('VERIFIED',len(rows),'files');return
    files=[f for f in root.rglob('*') if f.is_file() and f.resolve()!=a.manifest.resolve()]
    a.manifest.parent.mkdir(parents=True,exist_ok=True)
    a.manifest.write_text(json.dumps({'files':[dict(path=f.relative_to(root).as_posix(),bytes=f.stat().st_size,sha256=digest(f)) for f in sorted(files)]},indent=2)+'\n');print('FROZEN',len(files),'files')
if __name__=='__main__':main()
