"""Summarize Chrome/PyTorch JSON traces (including .gz); overlapping durations are not wall time."""
import argparse,collections,gzip,json
from pathlib import Path
def summarize(trace,top=25):
    events=trace.get('traceEvents',[]) if isinstance(trace,dict) else trace
    stats=collections.defaultdict(lambda:{'count':0,'sum_duration_us':0.0})
    for e in events:
        if e.get('ph')!='X' or not isinstance(e.get('dur'),(float,int)):continue
        k=(str(e.get('cat','')),str(e.get('name','')));stats[k]['count']+=1;stats[k]['sum_duration_us']+=e['dur']
    return [dict(category=k[0],name=k[1],**v) for k,v in sorted(stats.items(),key=lambda kv:kv[1]['sum_duration_us'],reverse=True)[:top]]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('trace',type=Path);p.add_argument('--top',type=int,default=25);p.add_argument('--output',type=Path);a=p.parse_args()
    with (gzip.open(a.trace,'rt') if a.trace.suffix=='.gz' else a.trace.open()) as f:data=json.load(f)
    result=dict(trace=str(a.trace),top_events=summarize(data,a.top),note='sum duration includes overlap/nested ops; this is not self CPU time, GPU utilization or end-to-end latency')
    s=json.dumps(result,ensure_ascii=False,indent=2);print(s)
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(s+'\n')
if __name__=='__main__':main()
