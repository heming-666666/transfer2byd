"""Read-only GPU/SM/P2P/NVLink inventory. P2P reachability is not NVLink evidence."""
import argparse,json,subprocess
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cards',type=int,choices=[4,8],default=8);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    import torch
    if torch.cuda.device_count()<a.cards:p.error('GPU 不足')
    devices=[]
    for i in range(a.cards):
        d=torch.cuda.get_device_properties(i);devices.append(dict(local_index=i,name=d.name,SM_count=d.multi_processor_count,capability=[d.major,d.minor],memory_bytes=d.total_memory))
    cmds=[['nvidia-smi','topo','-m'],['nvidia-smi','nvlink','--status']];raw=[]
    for cmd in cmds:
        r=subprocess.run(cmd,text=True,capture_output=True);raw.append(dict(command=cmd,stdout=r.stdout,stderr=r.stderr,returncode=r.returncode))
    report=dict(devices=devices,peer_access=[[torch.cuda.can_device_access_peer(i,j) if i!=j else True for j in range(a.cards)] for i in range(a.cards)],
      raw=raw,note='SM_count is device capacity, not active SMs of a kernel; P2P may use PCIe; use topo/NVLink status as transport evidence')
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
