"""Sample selected physical GPUs with nvidia-smi; no CUDA/PyTorch dependency or fake fallback."""
import argparse
import csv
import io
import json
import math
import signal
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from lab_http import ROOT, output_dir, save
from measurement_clock import anchor, utc_at

FIELDS = 'index,uuid,memory.used,memory.total,utilization.gpu,power.draw'


def parse_gpus(text):
    ids = [int(x.strip()) for x in text.split(',')]
    if not ids or any(x < 0 for x in ids) or len(set(ids)) != len(ids):
        raise ValueError('gpus 必须为不重复的物理 GPU index，例如 0,1,2,3')
    return ids


def number(value):
    try:
        n = float(value.strip())
        return n if math.isfinite(n) and n >= 0 else None
    except ValueError:
        return None


def parse_query(text, expected):
    rows = []
    for row in csv.reader(io.StringIO(text)):
        if not row:
            continue
        if len(row) != 6:
            raise ValueError('nvidia-smi 返回字段数不符')
        idx = int(row[0].strip())
        if not row[1].strip().startswith('GPU-'):
            raise ValueError('需要完整 GPU UUID；本实验不接受 MIG 实例')
        rows.append(dict(index=idx, uuid=row[1].strip(), memory_used_mib=number(row[2]),
                         memory_total_mib=number(row[3]), utilization_gpu_percent=number(row[4]),
                         power_watts=number(row[5])))
    if sorted(r['index'] for r in rows) != sorted(expected) or len({r['uuid'] for r in rows}) != len(expected):
        raise ValueError('请求的 GPU 和 nvidia-smi 实际返回不一致')
    return rows


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gpus', default='0,1,2,3,4,5,6,7')
    p.add_argument('--interval', type=float, default=1.0)
    p.add_argument('--duration', type=float, default=300.0)
    p.add_argument('--query-timeout', type=float, default=10.0)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    try:
        ids = parse_gpus(a.gpus)
    except ValueError as e:
        p.error(str(e))
    if any(not math.isfinite(x) or x <= 0 for x in [a.interval, a.duration, a.query_timeout]) or a.interval < .2:
        p.error('interval 至少 0.2 秒；duration/query-timeout 须为有限正数')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    out = output_dir(a.output or ROOT / 'shared/results/resources' / stamp)
    clock = anchor()
    cmd = ['nvidia-smi', '-i', ','.join(map(str, ids)), '--query-gpu=' + FIELDS, '--format=csv,noheader,nounits']
    meta = dict(schema_version=1, clock=clock, gpu_indices=ids, requested_interval_seconds=a.interval,
                requested_duration_seconds=a.duration, command=cmd, status='RUNNING',
                caveat='driver-sampled device totals; query midpoint approximates observation time; not per-kernel SM or energy counters')
    save(out / 'metadata.json', meta)
    print('采样目录：', out, flush=True)
    errors = 0
    seq = 0
    started = time.perf_counter()
    status = 'COMPLETED'

    def interrupted(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    try:
        with (out / 'samples.jsonl').open('w', encoding='utf-8', buffering=1) as f:
            while True:
                before = time.perf_counter_ns()
                sample = dict(seq=seq, gpus=[])
                try:
                    r = subprocess.run(cmd, capture_output=True, text=True, timeout=a.query_timeout, check=True)
                    sample['gpus'] = parse_query(r.stdout, ids)
                except (OSError, ValueError, subprocess.SubprocessError) as e:
                    sample['error'] = str(e)[:2000]
                    errors += 1
                after = time.perf_counter_ns()
                middle = (before + after) // 2
                sample.update(perf_ns=middle, utc_estimate=utc_at(clock, middle), query_seconds=(after-before)/1e9)
                f.write(json.dumps(sample, ensure_ascii=False, allow_nan=False) + '\n')
                seq += 1
                if errors == seq:
                    status = 'FAILED_FIRST_QUERY'
                    break
                if time.perf_counter() - started >= a.duration:
                    break
                # The first and final observations bracket the requested duration when queries succeed.
                deadline = min(started + seq * a.interval, started + a.duration)
                time.sleep(max(0, deadline-time.perf_counter()))
    except KeyboardInterrupt:
        status = 'STOPPED_BY_SIGNAL'
    finally:
        meta.update(status=status, queries=seq, failed_queries=errors, ended_perf_ns=time.perf_counter_ns())
        save(out / 'metadata.json', meta)
        print(json.dumps(dict(output=str(out), status=status, queries=seq, failed_queries=errors), ensure_ascii=False))
    if status == 'FAILED_FIRST_QUERY':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
