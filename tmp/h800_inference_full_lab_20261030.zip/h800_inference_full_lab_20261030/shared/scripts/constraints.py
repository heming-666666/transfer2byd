"""Prompt/JSON Schema/regex/EBNF comparison with application-side validation."""
import argparse,json,re
from pathlib import Path
from lab_http import ROOT,client_config,chat,save
SCHEMA={'type':'object','properties':{'answer':{'type':'string'},'topic':{'type':'string','enum':['infra','other']}},'required':['answer','topic'],'additionalProperties':False}
def valid(value):return isinstance(value,dict) and set(value)=={'answer','topic'} and isinstance(value['answer'],str) and value['topic'] in ('infra','other')
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--framework',choices=['sglang','vllm'],required=True);p.add_argument('--client-config',type=Path,required=True)
    p.add_argument('--mode',choices=['prompt','json_object','json_schema','regex','grammar'],default='json_schema');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    c=client_config(a.client_config);extra={};prompt='解释 KV Cache，仅输出 JSON，且恰好包含 answer 字符串、topic 字符串；topic 必须是 infra 或 other。'
    regex='(YES|NO)';grammar='root ::= "YES" | "NO"'
    if a.mode=='json_object':extra={'response_format':{'type':'json_object'}}
    if a.mode=='json_schema':extra={'response_format':{'type':'json_schema','json_schema':{'name':'answer','strict':True,'schema':SCHEMA}}}
    if a.mode in ('regex','grammar'):
        prompt='TP 是一种模型并行方法吗？只能输出 YES 或 NO。'
        extra=({'regex':regex} if a.mode=='regex' else {'ebnf':grammar}) if a.framework=='sglang' else {'structured_outputs':{a.mode:regex if a.mode=='regex' else grammar}}
    r=chat(c,[{'role':'user','content':prompt}],max_tokens=1024,extra=extra)
    error=None
    try:ok=bool(re.fullmatch(regex,r['content'])) if a.mode in ('regex','grammar') else valid(json.loads(r['content']))
    except ValueError as e:ok=False;error=str(e)
    # Exact-format checks retain whitespace; stripping could conceal grammar failures.
    result=dict(mode=a.mode,framework=a.framework,valid=ok,parse_error=error,response=r,
      warning='valid syntax does not establish truth; reasoning/length truncation can still fail application validation')
    a.output.parent.mkdir(parents=True,exist_ok=True);save(a.output,result);print(json.dumps(result,ensure_ascii=False,indent=2))
    if not ok:raise SystemExit(2)
if __name__=='__main__':main()
