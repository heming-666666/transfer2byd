"""Private local-completions likelihood path for classic MMLU/HellaSwag. Requires a passed probe."""
import argparse,os,subprocess,sys
from pathlib import Path
from lab_http import ROOT,read
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--framework',choices=['sglang','vllm'],required=True)
    p.add_argument('--tokenizer',type=Path,required=True);p.add_argument('--probe-report',type=Path,required=True)
    p.add_argument('--task',choices=['mmlu','hellaswag'],default='mmlu');p.add_argument('--limit',type=int,default=10)
    p.add_argument('--max-length',type=int,default=8192);p.add_argument('--fewshot',type=int,default=0)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--online-prepare',action='store_true');a=p.parse_args()
    if not read(a.probe_report).get('capability_probe_pass'):p.error('prompt logprobs探针未通过')
    if not (a.tokenizer/'tokenizer_config.json').is_file():p.error('需本地匹配tokenizer目录')
    folder=ROOT/('sglang_lab' if a.framework=='sglang' else 'vllm_addon');c=read(folder/'config/settings.json');auth=read(folder/'config/secrets.json');cache=ROOT/'shared/environments/lmeval0413/cache'
    for name in ['tmp','xdg','datasets','huggingface']:(cache/name).mkdir(parents=True,exist_ok=True)
    env=dict(os.environ,OPENAI_API_KEY=auth['engine_api_key'],HF_HOME=str(cache/'huggingface'),HF_DATASETS_CACHE=str(cache/'datasets'),TMPDIR=str(cache/'tmp'),XDG_CACHE_HOME=str(cache/'xdg'))
    env['NO_PROXY']=','.join(x for x in [env.get('NO_PROXY',env.get('no_proxy','')),'127.0.0.1','localhost'] if x);env['no_proxy']=env['NO_PROXY']
    if not a.online_prepare:env.update(HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    else:
        for key in ['HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TRANSFORMERS_OFFLINE']:env.pop(key,None)
    model_args=f"model={c['model_alias']},base_url=http://127.0.0.1:{c['engine_port']}/v1/completions,tokenizer={a.tokenizer.resolve()},tokenizer_backend=huggingface,tokenized_requests=True,num_concurrent=4,max_retries=2,max_length={a.max_length}"
    cmd=[sys.executable,'-m','lm_eval','--model','local-completions','--model_args',model_args,'--tasks',a.task,'--num_fewshot',str(a.fewshot),'--output_path',str(a.output),'--log_samples']
    if a.limit:cmd+=['--limit',str(a.limit)]
    print('private likelihood task:',a.task,'fewshot:',a.fewshot,'offline:',not a.online_prepare,flush=True)
    raise SystemExit(subprocess.run(cmd,env=env).returncode)
if __name__=='__main__':main()
