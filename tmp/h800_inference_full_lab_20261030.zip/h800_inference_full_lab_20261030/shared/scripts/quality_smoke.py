"""Tiny original fixtures for functional regression; not GSM8K/MMLU/IFEval scores."""
import argparse,json
from pathlib import Path
from lab_http import ROOT,client_config,chat,save
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--client-config',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--max-tokens',type=int,default=4096);p.add_argument('--extra-json',type=Path);a=p.parse_args();c=client_config(a.client_config)
    extra=json.loads(a.extra_json.read_text()) if a.extra_json else {};rows=[]
    for l in (ROOT/'shared/fixtures/quality_smoke.jsonl').read_text().splitlines():
        item=json.loads(l);r=chat(c,[{'role':'user','content':item['prompt']}],a.max_tokens,extra)
        rows.append(dict(id=item['id'],passed=r['content'].strip()==item['exact'],expected=item['exact'],response=r))
    result=dict(scope='ORIGINAL_FUNCTIONAL_SMOKE_NOT_PUBLIC_BENCHMARK',passed=all(x['passed'] for x in rows),rows=rows)
    a.output.parent.mkdir(parents=True,exist_ok=True);save(a.output,result);print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['passed']:raise SystemExit(2)
if __name__=='__main__':main()
