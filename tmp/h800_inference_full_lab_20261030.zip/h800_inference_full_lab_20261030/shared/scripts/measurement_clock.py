"""Same-host measurement anchors. Monotonic clocks must never be joined across hosts."""
import socket
import time
from datetime import datetime, timezone
from pathlib import Path


def clock_identity():
    def value(path, link=False):
        try:
            return Path(path).stat().st_ino if link else Path(path).read_text().strip()
        except OSError:
            return None
    return dict(hostname=socket.gethostname(), boot_id=value('/proc/sys/kernel/random/boot_id'),
                time_namespace=value('/proc/self/ns/time', True), clock='perf_counter_ns')


def anchor():
    before = time.perf_counter_ns()
    wall = time.time_ns()
    after = time.perf_counter_ns()
    return dict(identity=clock_identity(), perf_ns=(before + after) // 2,
                unix_ns=wall, uncertainty_ns=(after - before) // 2)


def utc_at(clock, perf_ns):
    unix_ns = clock['unix_ns'] + perf_ns - clock['perf_ns']
    return datetime.fromtimestamp(unix_ns / 1e9, timezone.utc).isoformat()


def require_same_clock(a, b):
    keys = ('hostname', 'boot_id', 'time_namespace', 'clock')
    if any(a.get(k) is None or b.get(k) is None or a[k] != b[k] for k in keys):
        raise ValueError('拒绝跨主机/重启/时间命名空间或未知时钟对齐；请在 GPU 主机上运行压测与采样')


def measurement_window(clock, start_ns, end_ns):
    if end_ns <= start_ns:
        raise ValueError('measurement window must be positive')
    return dict(start_perf_ns=start_ns, end_perf_ns=end_ns,
                start_utc_estimate=utc_at(clock, start_ns), end_utc_estimate=utc_at(clock, end_ns),
                seconds=(end_ns - start_ns) / 1e9)
