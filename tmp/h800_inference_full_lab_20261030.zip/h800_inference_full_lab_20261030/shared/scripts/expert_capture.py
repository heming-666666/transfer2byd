"""Decode SGLang native routed_experts base64 int32; report per-layer expert imbalance."""
import argparse,array,base64,collections,json,math,sys
from pathlib import Path
from lab_http import ROOT,read,http,save
def decode(raw,layers,topk):
    b=base64.b64decode(raw,validate=True)
    if len(b)%4:raise ValueError('routed_experts payload is not int32 aligned')
    ids=array.array('i');ids.frombytes(b)
    if sys.byteorder!='little':ids.byteswap()
    if len(ids)%(layers*topk):raise ValueError('tokens×layers×topk shape mismatch; verify actual config/overrides')
    tokens=len(ids)//(layers*topk);counts=[collections.Counter() for _ in range(layers)]
    for t in range(tokens):
        for l in range(layers):counts[l].update(x for x in ids[(t*layers+l)*topk:(t*layers+l+1)*topk] if x>=0)
    return tokens,counts
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--layers',type=int,default=48);p.add_argument('--topk',type=int,default=8);p.add_argument('--experts',type=int,default=128);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    c=read(ROOT/'sglang_lab/config/settings.json');auth=read(ROOT/'sglang_lab/config/secrets.json')
    payload={'text':'Explain expert routing in Mixture of Experts.','sampling_params':{'temperature':0,'max_new_tokens':64},'return_routed_experts':True}
    with http(f"http://127.0.0.1:{c['engine_port']}/generate",auth['engine_api_key'],payload) as f:r=json.load(f)
    raw=r.get('meta_info',{}).get('routed_experts')
    if not isinstance(raw,str):raise SystemExit('未返回 base64 routed_experts；需 enable-return-routed-experts，确认版本/模型实际层数')
    nt,counts=decode(raw,a.layers,a.topk);rows=[]
    for i,cnt in enumerate(counts):
        vals=[cnt[j] for j in range(a.experts)];mean=sum(vals)/a.experts
        if any(k>=a.experts for k in cnt):raise SystemExit('expert ID 超出范围')
        rows.append(dict(layer=i,counts=vals,mean=mean,max_to_mean=max(vals)/mean if mean else None,
          coefficient_of_variation=(sum((x-mean)**2 for x in vals)/a.experts)**0.5/mean if mean else None))
    a.output.parent.mkdir(parents=True,exist_ok=True);save(a.output,dict(tokens=nt,layers=a.layers,topk=a.topk,rows=rows,
      note='route frequencies on this prompt, not all-to-all time or universal expert utilization'));print('output:',a.output)
if __name__=='__main__':main()
