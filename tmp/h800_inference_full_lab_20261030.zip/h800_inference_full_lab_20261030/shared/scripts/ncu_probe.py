"""Single-GPU fixed GEMM for safe Nsight Compute kernel/SM study; no NCCL or profiler conflict."""
import argparse,json
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--matrix',type=int,default=4096);p.add_argument('--iterations',type=int,default=12);p.add_argument('--output',type=Path);a=p.parse_args()
    import torch
    torch.cuda.set_device(0);d=torch.cuda.get_device_properties(0)
    x=torch.randn(a.matrix,a.matrix,device='cuda',dtype=torch.bfloat16);y=torch.randn_like(x);z=torch.empty_like(x)
    with torch.cuda.nvtx.range('gemm_probe'):
        for _ in range(a.iterations):torch.mm(x,y,out=z)
    torch.cuda.synchronize();assert torch.isfinite(z).all()
    result=dict(device=d.name,device_SM_count=d.multi_processor_count,matrix=a.matrix,iterations=a.iterations,
                note='Single GPU reproduction for metrics; not full model TP/EP activity or an active-SM count')
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
