"""Standard-library OpenAI-compatible HTTP/SSE client. No secret in reports."""
import json,os,time,urllib.request,urllib.error,urllib.parse
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def read(p):return json.loads(Path(p).read_text())
def client_config(path):
    c=read(path)
    if 'SET_SERVER_LAN_IP' in c['base_url']:raise ValueError('client.json 尚未设置实际内网 IP')
    host=urllib.parse.urlparse(c['base_url']).hostname or ''
    no_proxy=','.join(x for x in [os.environ.get('NO_PROXY',os.environ.get('no_proxy','')),'127.0.0.1','localhost',host] if x)
    os.environ['NO_PROXY']=no_proxy;os.environ['no_proxy']=no_proxy
    return c
def http(url,key,data=None,timeout=600):
    body=None if data is None else json.dumps(data,ensure_ascii=False).encode()
    q=urllib.request.Request(url,body,{'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    try:return urllib.request.build_opener(urllib.request.ProxyHandler({})).open(q,timeout=timeout)
    except urllib.error.HTTPError as e:raise RuntimeError('HTTP '+str(e.code)+': '+e.read(1024).decode(errors='replace')) from e
def chat(c,messages,max_tokens=256,extra=None,timeout=600):
    validate_extra(extra)
    p=dict(model=c['model'],messages=messages,max_tokens=max_tokens,temperature=0,stream=True,stream_options={'include_usage':True})
    p.update(extra or {})
    start=time.perf_counter();times=[];content=[];reasoning=[];usage=None;finish=None;done=False
    with http(c['base_url'].rstrip('/')+'/chat/completions',c['api_key'],p,timeout) as f:
        rid=f.headers.get('X-Request-Id')
        for line in f:
            s=line.decode('utf-8').strip()
            if not s.startswith('data:'):continue
            s=s[5:].strip()
            if s=='[DONE]':done=True;break
            e=json.loads(s)
            if 'error' in e:raise RuntimeError(str(e['error']))
            usage=e.get('usage') or usage
            for ch in e.get('choices',[]):
                d=ch.get('delta',{});c0=d.get('content') or '';r=d.get('reasoning') or d.get('reasoning_content') or ''
                if c0 or r:times.append((time.perf_counter()-start)*1000)
                if c0:content.append(c0)
                if r:reasoning.append(r)
                finish=ch.get('finish_reason') or finish
    if not done:raise RuntimeError('SSE missing [DONE]')
    return dict(content=''.join(content),reasoning=''.join(reasoning),usage=usage,finish_reason=finish,request_id=rid,
                e2e_ms=(time.perf_counter()-start)*1000,first_ms=times[0] if times else None,last_ms=times[-1] if times else None,
                delta_times_ms=times)
def output_dir(path):
    p=Path(path);p.mkdir(parents=True,exist_ok=False);return p
def validate_extra(extra):
    if extra is None:return
    if not isinstance(extra,dict):raise ValueError('extra-json 必须是 JSON object')
    forbidden={'model','messages','max_tokens','max_completion_tokens','stream','stream_options','n'}&extra.keys()
    if forbidden:raise ValueError('extra-json 不得覆盖客户端协议/计数参数：'+', '.join(sorted(forbidden)))
    json.dumps(extra,allow_nan=False)
def save(p,obj):Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
