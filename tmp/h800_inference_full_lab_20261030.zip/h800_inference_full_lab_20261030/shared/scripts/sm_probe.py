"""Optional own-kernel SM/CTA timeline. Requires local CUDA toolkit/nvcc/C++ compiler; 1/4/8 GPUs."""
import argparse,json,os,shutil,sys
from pathlib import Path
from sm_probe_report import report,chrome_trace
ROOT=Path(__file__).resolve().parents[2]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cards',type=int,choices=[1,4,8],default=8)
    p.add_argument('--blocks',type=int,default=512);p.add_argument('--threads',type=int,default=128);p.add_argument('--iterations',type=int,default=20000)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    world=int(os.environ.get('WORLD_SIZE','1'));rank=int(os.environ.get('LOCAL_RANK','0'))
    if world!=a.cards:p.error('WORLD_SIZE与cards不符：4/8卡用torchrun，单卡用cards1')
    cache=ROOT/'shared/environments/sm-probe';(cache/'tmp').mkdir(parents=True,exist_ok=True)
    os.environ.update(TORCH_EXTENSIONS_DIR=str(cache),TORCH_CUDA_ARCH_LIST='9.0',TMPDIR=str(cache/'tmp'),MAX_JOBS='2')
    import torch
    from torch.utils.cpp_extension import load_inline,CUDA_HOME
    tag=f"torch-{torch.__version__}_cuda-{torch.version.cuda}_py{sys.version_info.major}{sys.version_info.minor}".replace("+","_")
    build=cache/tag/"build";build.mkdir(parents=True,exist_ok=True)
    if not CUDA_HOME or not (Path(CUDA_HOME)/'bin/nvcc').exists():p.error('需先准备项目内CUDA13 toolkit/nvcc，并设置CUDA_HOME；不会联网/系统安装')
    if not shutil.which(os.environ.get('CXX','c++')):p.error('缺匹配C++编译器')
    torch.cuda.set_device(rank);prop=torch.cuda.get_device_properties(rank)
    if prop.major!=9:p.error('本探针明确编译sm90；当前GPU不是Hopper')
    cuda=(Path(__file__).with_name('sm_probe.cu')).read_text()
    mod=load_inline(name='h800_lab_sm_probe',cpp_sources='torch::Tensor lab_sm_probe(int64_t blocks, int64_t threads, int64_t iterations);',
      cuda_sources=cuda,functions=['lab_sm_probe'],build_directory=str(build),extra_cuda_cflags=['-O2','-lineinfo'],verbose=rank==0)
    a.output.mkdir(parents=True,exist_ok=True)
    with torch.cuda.nvtx.range('own_kernel_sm_probe'):rows=mod.lab_sm_probe(a.blocks,a.threads,a.iterations).cpu().tolist()
    data=dict(rank=rank,world_size=world,device=prop.name,device_SM_capacity=prop.multi_processor_count,CUDA_VISIBLE_DEVICES=os.environ.get('CUDA_VISIBLE_DEVICES'),rows=rows)
    (a.output/f'rank{rank}.raw.json').write_text(json.dumps(data,indent=2)+'\n')
    summary=report(rows,prop.multi_processor_count);(a.output/f'rank{rank}.summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (a.output/f'rank{rank}.trace.json').write_text(json.dumps(chrome_trace(rows,rank))+'\n')
    print('rank',rank,'distinct SM',summary['distinct_recorded_SM_count'],'max recorded concurrency',summary['max_concurrent_recorded_SM_count'],'output',a.output)
if __name__=='__main__':main()
