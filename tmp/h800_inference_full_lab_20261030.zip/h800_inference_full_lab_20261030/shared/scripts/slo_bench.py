"""Request goodput: count requests meeting ALL SLOs / full measurement window.
HTTP first text delta approximates TTFT; chunk gaps are never called token ITL.
"""
import argparse,concurrent.futures as cf,hashlib,json,math,random,threading,time
from datetime import datetime,timezone
from pathlib import Path
from lab_http import ROOT,client_config,read,chat,save,output_dir,validate_extra
from measurement_clock import anchor,measurement_window

def validate_slo(slo):
    if not isinstance(slo,dict):raise ValueError('SLO 必须是 JSON object')
    names=('ttft_ms','tpot_ms','e2e_ms')
    if not any(k in slo for k in names):raise ValueError('SLO 不能没有延迟目标')
    for k in names:
        if k in slo and (isinstance(slo[k],bool) or not isinstance(slo[k],(int,float)) or not math.isfinite(slo[k]) or slo[k]<=0):
            raise ValueError('SLO 阈值须为有限正数：'+k)
    ratio=slo.get('target_joint_ratio',.95)
    if isinstance(ratio,bool) or not isinstance(ratio,(int,float)) or not math.isfinite(ratio) or not 0<=ratio<=1:
        raise ValueError('target_joint_ratio 须在 [0,1] 内')
    if slo.get('clock','send') not in ('send','arrival'):raise ValueError('clock 仅 send/arrival')
    if set(slo)-set(names)-{'target_joint_ratio','clock','note'}:raise ValueError('SLO 包含未知字段；拒绝忽略拼写错误')
    return slo

def percentile(values,p):
    x=sorted(v for v in values if v is not None and math.isfinite(v))
    return x[max(0,math.ceil(len(x)*p/100)-1)] if x else None
def evaluate_slo(row,slo):
    validate_slo(slo)
    if not row.get('success'):return False
    names={'ttft_ms':'ttft_ms','tpot_ms':'tpot_ms','e2e_ms':'e2e_ms'}
    if not any(k in slo for k in names):raise ValueError('SLO 不能没有延迟目标')
    return all(isinstance(row.get(k),(int,float)) and math.isfinite(row[k]) and row[k]>=0 and row[k]<=slo[k] for k in names if k in slo)
def summarize(rows,duration,slo):
    validate_slo(slo)
    if not math.isfinite(duration) or duration<=0:raise ValueError('measurement window must be positive')
    ok=[r for r in rows if r.get('success')];joint=[r for r in rows if evaluate_slo(r,slo)]
    def tokens_known(items):return all(isinstance(r.get('output_tokens'),int) and not isinstance(r['output_tokens'],bool) and r['output_tokens']>=0 for r in items)
    known=tokens_known(ok);joint_known=tokens_known(joint)
    return dict(requests=len(rows),success=len(ok),failed=len(rows)-len(ok),joint_slo_pass=len(joint),
      joint_slo_ratio=len(joint)/len(rows) if rows else 0,measurement_seconds=duration,
      request_goodput_rps=len(joint)/duration,successful_rps=len(ok)/duration,
      output_token_throughput=sum(r['output_tokens'] for r in ok)/duration if known else None,
      successful_output_tokens=sum(r['output_tokens'] for r in ok) if known else None,
      token_usage_complete=known,
      length_capped_successes=sum(bool(r.get('length_capped')) for r in ok),
      joint_good_output_tokens_per_second=sum(r['output_tokens'] for r in joint)/duration if joint_known else None,
      percentiles={k:{'p50':percentile([r.get(k) for r in ok],50),'p95':percentile([r.get(k) for r in ok],95),
          'p99':percentile([r.get(k) for r in ok],99)} for k in ['ttft_ms','tpot_ms','e2e_ms','client_queue_ms']},
      slo=slo,target_met=(len(joint)/len(rows)>=slo.get('target_joint_ratio',0.95)) if rows else False,
      measurement='first planned arrival to last finish, including drain; no unreported warmup/drain subtraction',
      caveat='first HTTP text delta and usage-based mean TPOT are approximations; chunk gaps are not exact ITL')
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--client-config',type=Path,required=True)
    p.add_argument('--slo',type=Path,default=ROOT/'shared/fixtures/slo.example.json');p.add_argument('--prompts',type=Path,default=ROOT/'shared/fixtures/prompts.jsonl')
    p.add_argument('--mode',choices=['open','closed'],default='open');p.add_argument('--rate',type=float,default=2)
    p.add_argument('--arrival',choices=['poisson','constant'],default='poisson');p.add_argument('--requests',type=int,default=128)
    p.add_argument('--concurrency',type=int,default=16);p.add_argument('--max-tokens',type=int,default=256)
    p.add_argument('--warmup',type=int,default=4);p.add_argument('--timeout',type=float,default=180);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--output',type=Path);p.add_argument('--extra-json',type=Path)
    a=p.parse_args()
    if min(a.requests,a.concurrency,a.max_tokens)<1 or a.warmup<0 or not math.isfinite(a.rate) or a.rate<=0 or not math.isfinite(a.timeout) or a.timeout<=0:
        p.error('请求数/并发/长度/速率/timeout须为有限正数，warmup非负')
    c=client_config(a.client_config);slo=read(a.slo)
    try:validate_slo(slo)
    except ValueError as e:p.error(str(e))
    prompts=[json.loads(l)['prompt'] for l in a.prompts.read_text().splitlines() if l.strip()]
    if not prompts or any(not isinstance(x,str) or not x.strip() for x in prompts):p.error('prompts 必须含非空字符串 prompt')
    extra=read(a.extra_json) if a.extra_json else {}
    try:validate_extra(extra)
    except ValueError as e:p.error(str(e))
    # Non-thinking Qwen is selected by caller with --extra-json, never forced onto R1.
    for i in range(a.warmup):chat(c,[{'role':'user','content':prompts[i%len(prompts)]}],a.max_tokens,extra,a.timeout)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    out=output_dir(a.output or ROOT/'shared/results/slo'/stamp);rows=[];lock=threading.Lock();sem=threading.BoundedSemaphore(a.concurrency)
    def execute(i,planned):
        sent=time.perf_counter();queue=max(0,(sent-planned)*1000)
        row=dict(id=i,planned_seconds=planned-start,send_seconds=sent-start,client_queue_ms=queue,success=False,
                 planned_perf_ns=round(planned*1e9),send_perf_ns=round(sent*1e9))
        try:
            r=chat(c,[{'role':'user','content':prompts[i%len(prompts)]}],a.max_tokens,extra,a.timeout)
            n=(r.get('usage') or {}).get('completion_tokens')
            if isinstance(n,bool) or not isinstance(n,int) or n<0:n=None
            tp=(r['last_ms']-r['first_ms'])/(n-1) if isinstance(n,int) and n>1 and r['first_ms'] is not None else 0.0 if n==1 else None
            penalty=queue if slo.get('clock','send')=='arrival' else 0
            row.update(success=bool(r['content'] and r['finish_reason'] in ('stop','length')),output_tokens=n,
              final_content_present=bool(r['content']),reasoning_present=bool(r['reasoning']),length_capped=r['finish_reason']=='length',
              ttft_ms=r['first_ms']+penalty if r['first_ms'] is not None else None,tpot_ms=tp,e2e_ms=r['e2e_ms']+penalty,
              ttft_from_send_ms=r['first_ms'],e2e_from_send_ms=r['e2e_ms'],finish_reason=r['finish_reason'],request_id=r['request_id'],delta_count=len(r['delta_times_ms']))
        except Exception as e:row['error']=str(e)[:2000]
        finally:
            row['finish_perf_ns']=time.perf_counter_ns();row['finish_seconds']=row['finish_perf_ns']/1e9-start
            with lock:rows.append(row)
    clock=anchor();start=time.perf_counter()
    if a.mode=='closed':
        counter=iter(range(a.requests));counter_lock=threading.Lock()
        def worker():
            while True:
                with counter_lock:i=next(counter,None)
                if i is None:return
                execute(i,time.perf_counter())
        with cf.ThreadPoolExecutor(a.concurrency) as ex:
            futures=[ex.submit(worker) for _ in range(a.concurrency)]
            for f in futures:f.result()
    else:
        rng=random.Random(a.seed);planned=start
        def wrapped(i,t):
            try:execute(i,t)
            finally:sem.release()
        with cf.ThreadPoolExecutor(a.concurrency) as ex:
            futures=[]
            for i in range(a.requests):
                if i:planned+=rng.expovariate(a.rate) if a.arrival=='poisson' else 1/a.rate
                while time.perf_counter()<planned:time.sleep(max(0,min(0.02,planned-time.perf_counter())))
                if sem.acquire(blocking=False):futures.append(ex.submit(wrapped,i,planned))
                else:
                    finish=time.perf_counter_ns()
                    with lock:rows.append(dict(id=i,success=False,error='CLIENT_INFLIGHT_LIMIT_DROP',planned_seconds=planned-start,
                        planned_perf_ns=round(planned*1e9),finish_perf_ns=finish,finish_seconds=finish/1e9-start))
            for f in futures:f.result()
    window=measurement_window(clock,min(r['planned_perf_ns'] for r in rows),max(r['finish_perf_ns'] for r in rows))
    duration=window['seconds'];rows.sort(key=lambda r:r['id'])
    for r in rows:r['slo_pass']=evaluate_slo(r,slo)
    (out/'requests.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,allow_nan=False)+'\n' for r in rows))
    result=summarize(rows,duration,slo);result.update(mode=a.mode,arrival=a.arrival,offered_rate=a.rate if a.mode=='open' else None,
      concurrency_limit=a.concurrency,model=c['model'],base_url=c['base_url'],seed=a.seed,clock=clock,measurement_window=window,
      workload=dict(requests=a.requests,max_tokens=a.max_tokens,warmup=a.warmup,timeout=a.timeout,
          prompts_sha256=hashlib.sha256(a.prompts.read_bytes()).hexdigest(),
          extra_json_sha256=hashlib.sha256(a.extra_json.read_bytes()).hexdigest() if a.extra_json else None),
      success_definition='nonempty final content and stop/length; length-capped replies counted separately; no semantic accuracy claim')
    save(out/'summary.json',result);print(json.dumps(result,ensure_ascii=False,indent=2));print('output:',out)
if __name__=='__main__':main()
