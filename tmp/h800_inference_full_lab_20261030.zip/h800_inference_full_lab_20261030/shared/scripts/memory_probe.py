"""Single-GPU allocator microexperiment; synthetic buffers, not real model memory attribution."""
import argparse
import gc
import hashlib
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from lab_http import ROOT, output_dir, save


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--device', type=int, default=0, help='logical CUDA device after CUDA_VISIBLE_DEVICES')
    p.add_argument('--weight-mib', type=int, default=64, help='synthetic weight-like uint8 buffer, not a checkpoint')
    p.add_argument('--kv-mib', type=int, default=32, help='synthetic KV-like buffer, not an engine KV pool')
    p.add_argument('--matrix', type=int, default=1024)
    p.add_argument('--replays', type=int, default=20)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    if a.device < 0 or min(a.weight_mib, a.kv_mib, a.matrix, a.replays) < 1:
        p.error('device 非负；其余计数为正整数')
    cache = ROOT/'shared/environments/memory_probe'/hashlib.sha256(sys.executable.encode()).hexdigest()[:12]
    for name, sub in [('CUDA_CACHE_PATH','cuda'),('TORCH_HOME','torch'),('TRITON_CACHE_DIR','triton'),
                      ('TORCHINDUCTOR_CACHE_DIR','inductor'),('TMPDIR','tmp'),('XDG_CACHE_HOME','xdg')]:
        target = cache/sub
        target.mkdir(parents=True, exist_ok=True)
        os.environ[name] = str(target)
    # Parse --help without importing torch or touching a GPU.
    import torch
    if not torch.cuda.is_available():
        raise SystemExit('CUDA unavailable; 未生成模拟的 GPU 结果')
    memory = torch.cuda.memory
    if not all(hasattr(memory, x) for x in ['_record_memory_history', '_dump_snapshot']):
        raise SystemExit('当前 PyTorch 不提供本包所需 snapshot API；按固定 venv 执行')
    torch.cuda.set_device(a.device)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    folder = output_dir(a.output or ROOT/'shared/results/memory'/stamp)
    report = dict(kind='synthetic_allocator_microexperiment', torch_version=torch.__version__,
                  cache_root=str(cache),
                  device=a.device, device_name=torch.cuda.get_device_name(a.device), phases=[], status='RUNNING',
                  caveat='memory_allocated/reserved are this process PyTorch allocator counters; synthetic buffers do not measure model weights/KV/NCCL')

    def phase(name):
        torch.cuda.synchronize()
        free, total = torch.cuda.mem_get_info()
        row = dict(phase=name, allocated_bytes=torch.cuda.memory_allocated(), reserved_bytes=torch.cuda.memory_reserved(),
                   max_allocated_bytes=torch.cuda.max_memory_allocated(), max_reserved_bytes=torch.cuda.max_memory_reserved(),
                   device_free_bytes=free, device_total_bytes=total)
        report['phases'].append(row)
        memory._dump_snapshot(str(folder/(name+'.pickle')))
        save(folder/'phases.json', report)

    memory._record_memory_history(max_entries=100000)
    try:
        torch.cuda.reset_peak_memory_stats()
        phase('01_context')
        weights = torch.empty(a.weight_mib*1024*1024, device='cuda', dtype=torch.uint8).fill_(1)
        phase('02_weight_like_buffer')
        kv = torch.empty(a.kv_mib*1024*1024, device='cuda', dtype=torch.uint8).fill_(2)
        x = torch.randn((a.matrix, a.matrix), device='cuda', dtype=torch.bfloat16)
        y = torch.randn_like(x)
        result = torch.empty_like(x)
        warmup = torch.cuda.Stream()
        warmup.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(warmup):
            for _ in range(3):
                torch.mm(x, y, out=result)
        torch.cuda.current_stream().wait_stream(warmup)
        phase('03_kv_like_and_matmul_warmup')
        graph = torch.cuda.CUDAGraph()
        begin = time.perf_counter_ns()
        with torch.cuda.graph(graph):
            torch.mm(x, y, out=result)
        torch.cuda.synchronize()
        report['graph_capture_host_wall_ms'] = (time.perf_counter_ns()-begin)/1e6
        phase('04_graph_captured')
        t0, t1 = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        t0.record()
        begin = time.perf_counter_ns()
        for _ in range(a.replays):
            graph.replay()
        report['replay_loop_host_wall_ms'] = (time.perf_counter_ns()-begin)/1e6
        t1.record()
        t1.synchronize()
        report['replay_cuda_event_ms'] = t0.elapsed_time(t1)
        report['replays'] = a.replays
        phase('05_replayed')
        kv = None
        gc.collect()
        phase('06_kv_like_freed_before_empty_cache')
        torch.cuda.empty_cache()
        phase('07_empty_cache_graph_alive')
        graph.reset()
        graph = weights = x = y = result = warmup = None
        gc.collect()
        torch.cuda.empty_cache()
        phase('08_buffers_and_graph_released')
        report['status'] = 'COMPLETED'
    except Exception as e:
        report.update(status='FAILED', error=str(e))
        raise
    finally:
        memory._record_memory_history(enabled=None)
        save(folder/'phases.json', report)
        print('output:', folder)


if __name__ == '__main__':
    main()
