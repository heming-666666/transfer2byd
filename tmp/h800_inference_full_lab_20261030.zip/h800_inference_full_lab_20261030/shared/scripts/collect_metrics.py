"""Timestamped private Prometheus snapshots and nvidia-smi; no assumed metric names."""
import argparse,datetime,json,subprocess,time
from pathlib import Path
from lab_http import ROOT,read,http,output_dir,save
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--framework',choices=['sglang','vllm'],required=True)
    p.add_argument('--target',choices=['engine','prefill','decode'],default='engine');p.add_argument('--samples',type=int,default=10);p.add_argument('--interval',type=float,default=1);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    folder=ROOT/('sglang_lab' if a.framework=='sglang' else 'vllm_addon');c=read(folder/'config/settings.json');auth=read(folder/'config/secrets.json');out=output_dir(a.output);records=[]
    for i in range(a.samples):
        row={'sample':i,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        try:
            with http(f"http://127.0.0.1:{c[a.target+'_port']}/metrics",auth['engine_api_key']) as f:(out/f'{i:04d}.prom').write_bytes(f.read())
            row['metrics']='OK'
        except Exception as e:row['metrics_error']=str(e)
        q=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,name,memory.used,memory.total,utilization.gpu,power.draw','--format=csv,noheader,nounits'],capture_output=True,text=True)
        row.update(gpu_csv=q.stdout,gpu_returncode=q.returncode);records.append(row)
        if i<a.samples-1:time.sleep(max(0,a.interval))
    save(out/'samples.json',records);print('output:',out)
    if any(r.get('metrics_error') for r in records):raise SystemExit('有指标端点采集失败，查看 samples.json')
if __name__=='__main__':main()
