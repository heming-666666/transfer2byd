#include <torch/extension.h>
#include <c10/cuda/CUDAStream.h>
#include <cuda_runtime.h>

__device__ __forceinline__ unsigned int lab_smid() {
  unsigned int result;
  asm volatile("mov.u32 %0, %smid;" : "=r"(result));
  return result;
}
__device__ __forceinline__ unsigned long long lab_globaltimer() {
  unsigned long long result;
  asm volatile("mov.u64 %0, %globaltimer;" : "=l"(result));
  return result;
}
__global__ void lab_sm_probe_kernel(long long* rows, float* sink, int iterations) {
  const int row = blockIdx.x;
  if (threadIdx.x == 0) {
    rows[row * 4] = lab_smid();
    rows[row * 4 + 2] = static_cast<long long>(lab_globaltimer());
  }
  __syncthreads();
  volatile float value = 1.0f + static_cast<float>(threadIdx.x) * 0.00001f;
  for (int i = 0; i < iterations; ++i) value = value * 1.0000001f + 0.0000001f;
  sink[row * blockDim.x + threadIdx.x] = value;
  __syncthreads();
  if (threadIdx.x == 0) {
    rows[row * 4 + 3] = static_cast<long long>(lab_globaltimer());
    rows[row * 4 + 1] = lab_smid();
  }
}
torch::Tensor lab_sm_probe(int64_t blocks, int64_t threads, int64_t iterations) {
  TORCH_CHECK(blocks > 0 && blocks < 1000000, "invalid blocks");
  TORCH_CHECK(threads > 0 && threads <= 1024, "invalid threads");
  TORCH_CHECK(iterations > 0 && iterations < 10000000, "invalid iterations");
  auto rows = torch::empty({blocks, 4}, torch::TensorOptions().dtype(torch::kInt64).device(torch::kCUDA));
  auto sink = torch::empty({blocks * threads}, torch::TensorOptions().dtype(torch::kFloat32).device(torch::kCUDA));
  auto stream = c10::cuda::getCurrentCUDAStream();
  lab_sm_probe_kernel<<<static_cast<unsigned int>(blocks), static_cast<unsigned int>(threads), 0, stream.stream()>>>(
      reinterpret_cast<long long*>(rows.data_ptr<int64_t>()), sink.data_ptr<float>(), static_cast<int>(iterations));
  auto status = cudaGetLastError();
  TORCH_CHECK(status == cudaSuccess, cudaGetErrorString(status));
  return rows;
}
