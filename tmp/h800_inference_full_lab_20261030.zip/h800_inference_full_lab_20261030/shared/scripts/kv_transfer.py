"""2-rank synthetic KV-shaped transfer. This is NCCL send/recv, not Mooncake/NIXL."""
import argparse,json,os,time
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--tokens',type=int,default=4096);p.add_argument('--layers',type=int,default=8)
    p.add_argument('--kv-heads',type=int,default=8);p.add_argument('--head-dim',type=int,default=128);p.add_argument('--dtype',choices=['bf16','uint8'],default='bf16')
    p.add_argument('--iterations',type=int,default=20);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    import torch,torch.distributed as d
    torch.cuda.set_device(int(os.environ['LOCAL_RANK']));d.init_process_group('nccl');r=d.get_rank()
    if d.get_world_size()!=2:raise SystemExit('此传输探针要求 --nproc_per_node=2')
    dt=torch.bfloat16 if a.dtype=='bf16' else torch.uint8
    shape=(2,a.layers,a.tokens,a.kv_heads,a.head_dim);x=torch.full(shape,7 if r==0 else 0,device='cuda',dtype=dt)
    def transfer():
        if r==0:d.send(x,1)
        else:d.recv(x,0)
    transfer();torch.cuda.synchronize();ok=torch.tensor([int(r==0 or torch.all(x==7))],device='cuda');d.all_reduce(ok,op=d.ReduceOp.MIN);assert ok.item()==1
    d.barrier();t=time.perf_counter()
    for _ in range(a.iterations):transfer()
    torch.cuda.synchronize();duration=(time.perf_counter()-t)/a.iterations
    duration_t=torch.tensor([duration],device='cuda',dtype=torch.float64);d.all_reduce(duration_t,op=d.ReduceOp.MAX)
    if r==0:
        seconds=duration_t.item();size=x.numel()*x.element_size();result=dict(shape=shape,dtype=a.dtype,bytes=size,ms=seconds*1000,GBps=size/seconds/1e9,
          checked_every_element=True,note='uint8 is byte-volume simulation only; no quantization scale/kernel or real model KV layout')
        a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    d.destroy_process_group()
if __name__=='__main__':main()
