"""Clip trapezoidal GPU-power integrals to an SLO window; reject missing/cross-host clocks."""
import argparse
import json
import math
from pathlib import Path
from lab_http import read, save
from measurement_clock import require_same_clock


def integrate(points, start_ns, end_ns, max_gap_seconds):
    """Points are (perf_ns, watts-or-None), including missing-query sentinels."""
    if end_ns <= start_ns or not math.isfinite(max_gap_seconds) or max_gap_seconds <= 0:
        raise ValueError('invalid integration window or max gap')
    if any(b[0] <= a[0] for a, b in zip(points, points[1:])):
        raise ValueError('sample timestamps must strictly increase; duplicate points are not averaged')
    energy = 0.0
    covered_ns = 0
    segments = 0
    for (t0, w0), (t1, w1) in zip(points, points[1:]):
        if any(x is None or not math.isfinite(x) or x < 0 for x in (w0, w1)) or (t1-t0)/1e9 > max_gap_seconds:
            continue
        left, right = max(t0, start_ns), min(t1, end_ns)
        if right <= left:
            continue
        wl = w0 + (w1-w0)*(left-t0)/(t1-t0)
        wr = w0 + (w1-w0)*(right-t0)/(t1-t0)
        energy += (wl+wr)/2 * (right-left)/1e9
        covered_ns += right-left
        segments += 1
    return dict(observed_energy_j=energy, covered_seconds=covered_ns/1e9,
                coverage_ratio=covered_ns/(end_ns-start_ns), integrated_segments=segments)


def analyze(metadata, samples, slo, max_gap_seconds=2.5, min_coverage=.99):
    if not math.isfinite(min_coverage) or not 0 < min_coverage <= 1:
        raise ValueError('min_coverage must be in (0,1]')
    require_same_clock(metadata['clock']['identity'], slo['clock']['identity'])
    window = slo['measurement_window']
    start, end = window['start_perf_ns'], window['end_perf_ns']
    indices = metadata['gpu_indices']
    if not indices or len(set(indices)) != len(indices):
        raise ValueError('invalid GPU indices')
    by_gpu = {idx: [] for idx in indices}
    uuids = {}
    for sample in samples:
        rows = {r['index']: r for r in sample['gpus']}
        if len(rows) != len(sample['gpus']) or set(rows)-set(indices):
            raise ValueError('duplicate or unexpected GPU in sample')
        for idx in indices:
            row = rows.get(idx)
            if row:
                if idx in uuids and uuids[idx] != row['uuid']:
                    raise ValueError('GPU index/UUID mapping changed during sampling')
                uuids[idx] = row['uuid']
            by_gpu[idx].append((sample['perf_ns'], row['power_watts'] if row else None))
    gpu_results = [dict(index=idx, uuid=uuids.get(idx), **integrate(points, start, end, max_gap_seconds))
                   for idx, points in by_gpu.items()]
    accepted = all(r['coverage_ratio'] >= min_coverage for r in gpu_results)
    full = all(r['coverage_ratio'] >= 1-1e-12 for r in gpu_results)
    observed = sum(r['observed_energy_j'] for r in gpu_results)
    tokens = slo.get('successful_output_tokens')
    usage_complete = slo.get('token_usage_complete', False)
    return dict(schema_version=1, measurement_window=window, clock_identity=metadata['clock']['identity'],
                gpu_results=gpu_results, max_gap_seconds=max_gap_seconds, min_coverage=min_coverage,
                coverage_accepted=accepted, total_observed_gpu_energy_j=observed,
                full_window_gpu_energy_j=observed if full else None,
                successful_output_tokens=tokens, token_usage_complete=usage_complete,
                observed_gpu_joules_per_successful_output_token=observed/tokens if accepted and usage_complete and tokens else None,
                request_goodput_rps=slo.get('request_goodput_rps'),
                caveat='sampled device-wide GPU power only; no gap extrapolation, CPU/NIC/wall-plug energy or per-kernel attribution; warmup excluded by SLO window')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--resources', type=Path, required=True)
    p.add_argument('--slo-summary', type=Path, required=True)
    p.add_argument('--max-gap', type=float, default=2.5)
    p.add_argument('--min-coverage', type=float, default=.99)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        p.error('output 已存在，选择新的结果路径')
    try:
        samples = [json.loads(x) for x in (a.resources/'samples.jsonl').read_text().splitlines() if x.strip()]
        result = analyze(read(a.resources/'metadata.json'), samples, read(a.slo_summary), a.max_gap, a.min_coverage)
    except (ValueError, KeyError, OSError) as e:
        p.error(str(e))
    a.output.parent.mkdir(parents=True, exist_ok=True)
    save(a.output, result)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    if not result['coverage_accepted']:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
