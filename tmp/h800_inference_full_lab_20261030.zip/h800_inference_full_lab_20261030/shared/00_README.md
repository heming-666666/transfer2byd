# 公共实验与工具

脚本默认根目录由自身位置推导；不要把脚本单独搬走后仍期望它自动找到所有资产。普通 HTTP 工具仅需 Python 标准库；GPU 工具使用任一已通过检查的推理 venv。评测工具使用自己独立的 venv。

| 顺序 | 指南 | 对应问题 |
|---|---|---|
| 01 | [COMMUNICATION.md](docs/01_COMMUNICATION.md) | NVLink、P2P、NCCL、collective 时间与带宽 |
| 02 | [KV_ALLOCATION.md](docs/02_KV_ALLOCATION.md) | KV block、共享前缀、refcount、COW、容量 |
| 03 | [KV_TRANSFER.md](docs/03_KV_TRANSFER.md) | 模拟张量传输与真实 PD 通信证据 |
| 04 | [PROFILING.md](docs/04_PROFILING.md) | PyTorch Profiler、trace 汇总、各 rank |
| 05 | [PERFETTO_OFFLINE.md](docs/05_PERFETTO_OFFLINE.md) | 受限内网查看 trace |
| 06 | [QUALITY_DATASETS.md](docs/06_QUALITY_DATASETS.md) | 离线依赖、数据版本、正式能力评测 |
| 07 | [SLO_METHOD.md](docs/07_SLO_METHOD.md) | goodput 的分子分母与近似指标 |
| 08 | [NSIGHT_SM_KERNEL.md](docs/08_NSIGHT_SM_KERNEL.md) | SM、kernel 次数/耗时、CPU/NCCL、graph capture |
| 09 | [SM_CTA_PROBE.md](docs/09_SM_CTA_PROBE.md) | 自定义CUDA kernel的SM ID与CTA区间 |
| 10 | [KV_CALIBRATION.md](docs/10_KV_CALIBRATION.md) | 真实K/V范围校准、TP4/TP8 scale文件 |
| 11 | [RESOURCES_ENERGY_CLOCKS.md](docs/11_RESOURCES_ENERGY_CLOCKS.md) | 4/8卡显存/功率采样、同机时钟、能耗覆盖与J/token |
| 12 | [MEMORY_AND_CAPTURE.md](docs/12_MEMORY_AND_CAPTURE.md) | allocator快照、buffer微实验、启动Graph捕获与rank限制 |

`fixtures/` 只含本包自写的小样本与配置模板。它们能验证流程，不代表公开基准数据。`models/` 和 `datasets/` 需要用户按指南填充；默认不含大文件。
