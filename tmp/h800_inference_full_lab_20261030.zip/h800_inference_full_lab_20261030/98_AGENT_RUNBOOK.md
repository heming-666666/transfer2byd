# 98 · 给执行代理或同事的运行手册

完整阅读总入口后，按以下顺序推进。已有用户授权包括本项目内可逆配置、环境构建、权重准备、启动停止本包服务与实验；不因每一条常规命令反复等待确认。若关键信息只能来自实际机器，先运行只读预检，再用结果决定兼容路径。

1. 确认实际数据盘根路径、Linux x86_64、GPU 8/4 张、显存、driver、glibc、cgroup RAM、共享内存、memlock、NVLink/P2P、内网 IP/端口；保存原始输出。不要假设所有 H800 都是相同拓扑。
2. 默认先 SGLang native。按 02 准备匹配 portable CPython3.12、完整 wheel 依赖、lock、哈希与本地编译资产。PyPI/GitHub 可访问不代表所有依赖索引、kernel CDN、NLTK 数据都可访问。不能通过删依赖/忽略解析冲突假装安装成功。
3. 固定模型真实 commit 并完整保存 tokenizer、索引与 shard；先 `lab`，再逐项下载需要的实验模型。不要只下载 `.safetensors`。
4. `configure` 只初次生成密钥；再次执行必须保留 Key。不要在回复、终端命令行、trace 名称或报告中展示 Key。最小客户端只拿 public Key。
5. 完成 CUDA 单卡 matmul、4/8-rank NCCL、模型加载、真实非流式/流式与多轮正文；再从另一台内网机器执行同样验收。失败时记录精确 stderr 和状态，不把网关 `/health` 当模型通过。
6. 每次只切换一个变量。先 stop 本包服务，检查 GPU 空闲，再启动目标 profile；P/D 允许同时启动是因为 GPU 集不重叠。不要杀别人的进程。
7. 默认 8 卡，4 卡都提供对照。SGLang 总卡数 `TP×PP×整模型DP`，CP/AttentionDP/EP 不再乘；vLLM 还须乘 PCP，DCP 不乘。按各框架检查，不互抄公式。
8. PD 必须检查真实输出与非零 KV 传输证据；HTTP200 或 router 存活不足。SGLang P/D PyTorch Profiler按固定版本要求分两轮开启/停止，不同时开；不同轮次不能拼成同步请求时间线。传输日志另行关联；注入失败应报错，不能默默重算掩盖传输失效。
9. 先无 profiler 跑性能，再 profile 短窗口。记录 rank/device/stream。CPU 提交壁钟、GPU kernel 时长、通信等待、并发区间并集分别报告，不能相加伪装总时间。SM 数只能来自实际设备/硬件计数器；不把 occupancy×SM 数当成实测激活 SM 个数。
10. SLO 使用联合谓词，失败/客户端丢弃计入分母；公开测量窗口、TTFT/TPOT 近似来源。能力评测默认小样本只做流程验收；正式分数必须固定任务、数据、prompt、采样，记录截断和错误，不能把 API 生成选择题当 likelihood MMLU 分数。
11. root 云主机上不无隔离地执行模型生成代码。HumanEval/MBPP 等先生成，再在专门隔离 VM/sandbox 评分；不因 Docker 不能用就直接在 root 运行。
12. 新模型/DSpark/DFlash/FP8 KV 等有条件限制。保留源码边界与启动拦截；没有 H800 证据的配置写 `NOT_RUN` 或 `UNSUPPORTED/CONDITIONAL`，不擅自写 PASS。用户要求尝试可以配置条件实验，不等于可以虚报结果。
13. 写回 `data/reports/deployment_status.json`：逐条状态、命令、时间、退出码、原始日志路径、实际观察、仍缺条件。模板是待填项，不是验收记录。
14. R2完整路线见总04、SGLang31或vLLM15。统一accept_service必须检查最终正文/stop和多轮校验码；若只是reasoning或length，先检查模板/预算，不能删断言。SLO统计length与功能验收语义不同，报告需保留截断数及usage完整性。
15. 资源/能耗采样与SLO在同一GPU主机上执行，验证hostname、boot_id、time namespace与单调时钟一致；远端客户端单独验收，不按跨主机perf_counter直接积分。缺测保留、公开coverage，不当0、不外推。GPU设备功率不能冒充整机或单kernel能耗。
16. allocator微实验是人工buffer，不代表模型真实权重/KV。SGLang固定源码的capture snapshot文件名没有rank，存在覆盖风险；vLLM capture_torch_profiler仅rank0。每rank trace与snapshot的支持范围分别说明，不凭单文件宣称全rank结果。

最终交付必须区分：CPU 测试、CUDA 探针、真实模型、内网客户端、PD、性能曲线、能力分数。对未完成项说明具体阻塞条件和下一条诊断命令，避免泛泛地说“应该能用”。
