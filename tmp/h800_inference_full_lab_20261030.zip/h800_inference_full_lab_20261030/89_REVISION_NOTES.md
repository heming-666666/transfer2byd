# 89 · R2修订记录 · 2026-10-31

固定模型/框架源码版本沿用2026-10-30清单；本次增加测量和验收工具，修正profiling使用方法，没有在用户H800上执行GPU实验，也未重新下载整套依赖。

## 新增有序指南

- 总04：把环境/服务验收/无Profiler压测/归因串成可执行路线。
- SGLang31、vLLM15：各自独立的8卡主线和4卡改法、采样/压测/能耗命令、Graph捕获与正式测量分离。
- 公共11：显存/功率采样、同机时钟、能耗积分、缺测覆盖与J/token口径。
- 公共12：allocator快照与人工buffer实验、真实模型显存归因边界、capture输出和rank限制。

## 新脚本与接口

| 脚本/入口 | 行为 |
|---|---|
| `shared/scripts/accept_service.py` | 六项public API/流式/最终正文/多轮记忆验收，保存对话，不保存Key |
| `shared/scripts/measurement_clock.py` | 时钟锚点、UTC估计、同主机/重启/时间namespace检查 |
| `shared/scripts/resource_monitor.py` | 显式4/8物理GPU、UUID/显存/利用率/功率、query耗时、缺测/中断留档 |
| `shared/scripts/energy_report.py` | SLO窗口内梯形积分、覆盖率、无补零或外推、usage完整时J/token |
| `shared/scripts/memory_probe.py` | 单进程人工buffer+matmul+Graph allocator生命周期，项目内cache |
| SGLang `run.py engine --capture-profiler` | Graph-on启动时开启真实上游capture profiler及每rank合并trace |
| vLLM `run.py engine --memory-profiler` | Torch profiler memory/shapes事件，支持与已有capture入口组合 |

## 行为修正

统一SLO增加绝对单调时间、窗口、prompt/extra SHA256与负载参数。拒绝NaN/无阈值/未知SLO字段与非法比例；extra-json不能改stream/model/计数协议。reasoning-only默认不计成功；length截断单列；缺usage的token吞吐/总数为null。旧结果缺clock字段时不能直接用于新能耗报告，按新脚本重跑。

SGLang26修正为P/D分轮PyTorch profiling。直接核对并补存固定commit的decode_cuda_graph_runner源码：capture snapshot确实使用当前目录固定basename，多rank存在覆盖风险。文档明确不能当全rank独立快照。vLLM capture只覆盖rank0，memory事件不等于完整allocator快照。

所有CPU/mock数据只存在于测试临时目录，验证报告不附虚构的H800吞吐、SM或能耗。最新执行数量与静态结果见 [90_VALIDATION_REPORT.md](90_VALIDATION_REPORT.md)，ZIP/清单哈希随R2重建。
