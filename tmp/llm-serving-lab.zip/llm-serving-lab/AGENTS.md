# AGENTS.md：给 GPU 机器上 AI agent 的工作规则

你在一台 8×H800 机器上执行本实验包。研究者是一名做 AI Infra 方向的硕士生，用中文交流。本包的目标是部署 vLLM/SGLang 服务、完成学习型实验，并为论文积累可信的实测数据。

## 1. 先读什么

1. `README.md`：目录结构与执行顺序
2. `docs/01-目录与存放约定.md`：每类文件放在哪里
3. 当前要做的步骤或实验文档。每个文档都写明了前置条件、命令、预期输出和记录要求。

## 2. 必须遵守的规则

1. **不编造。** 没跑的写“未执行”，失败的写“失败”并附上日志路径。不要把文档里的预期值当成实测值，也不要把论文或官方 recipe 里的数字当成本机结果。
2. **先检查再动手。** 每次启动引擎前确认 GPU 空闲：运行 `nvidia-smi`，确认没有其他进程占用显存。启动后用 `scripts/wait_ready.sh` 等待就绪，不要凭感觉 sleep。
3. **所有产物放在 `runtime/` 下。** 不要在包外创建文件（docker 镜像存储除外）。实验结果一律用 `new_run_dir`（`scripts/bench_serve.sh` 会自动创建）或按实验文档指定的目录存放。
4. **每次实验都要留痕。** 在结果目录里写 `notes.md`（用 `experiments/TEMPLATE-实验记录.md`），内容包括：目的、命令（原样复制）、镜像与版本（`collect_env.sh` 自动生成）、关键数字、异常、结论、下一步。
5. **保护密钥。** 不打印、不复制、不提交 `runtime/secrets/` 下的任何内容；日志和笔记里只写 key 的名字。Hugging Face token 同样如此。
6. **不改系统配置。** 驱动、内核参数、防火墙、系统级包、网络与代理设置都不要改。需要改时停下来，说明原因和具体命令，请研究者决定。
7. **下载要克制。** 只下载 `configs/models/` 中列出的模型和实验文档点名的数据集。其他下载先问研究者。
8. **一次只改一个变量。** 对比实验除被测参数外保持完全一致，包括镜像、模型 revision、max-model-len、负载、随机种子。每个配置至少跑 2 次，报告波动。
9. **长任务放后台，并记录状态。** 引擎已经用 `docker run -d` 后台运行。压测和评测用 `nohup ... &` 或 `tmux`，输出写入结果目录。
10. **失败时先自救，再求助。** 按 `docs/99-故障排查.md` 排查。仍然无法解决时，整理出“现象、完整报错、已尝试的方法、日志路径”交给研究者。
11. **文档以实测为准。** 发现文档里的命令、参数或预期在本机不成立时，在对应文档末尾的“本机实测记录”一节追加一行：日期、现象、修正。不要悄悄改动原文。
12. **释放资源。** 实验结束后用 `bash scripts/engine.sh stop-all` 停掉引擎，避免长期占卡。网关可以常驻。

## 3. 任务协议

每完成一步（例如 docs/04 或 E05），在 `runtime/logs/agent/worklog.md` 末尾追加：

```text
## <日期 时间> <步骤编号> <标题>
- 状态: 完成 / 部分完成 / 失败 / 跳过
- 结果目录: runtime/results/...
- 关键数字: ...
- 问题与处理: ...
- 下一步: ...
```

## 4. 常用命令速查

```bash
bash scripts/engine.sh profiles                     # 列出全部启动配置
bash scripts/engine.sh start vllm glm53-flash       # 启动（实例名 vllm-glm53-flash）
bash scripts/wait_ready.sh vllm-glm53-flash         # 等待就绪并记录启动耗时
bash scripts/engine.sh status                       # 查看实例
bash scripts/engine.sh logs vllm-glm53-flash 200    # 查看日志
bash scripts/engine.sh stop vllm-glm53-flash
bash scripts/bench_serve.sh --tool vllm --exp E20 --label c16 --instance vllm-glm53-flash -- <压测参数>
runtime/envs/client/bin/python tools/collect_bench.py runtime/results/E20
```
