# E16 Profiling：PyTorch Profiler 与 Perfetto

## 目的
学会采集和阅读推理引擎的 trace，回答这些问题：

- 一步 decode 里有哪些 kernel，各占多少时间？
- attention、GEMM、MoE、通信各占多少？
- GPU 有没有空闲？CPU 端在做什么？

## 工具
- **vLLM**：启动时加 `--profiler-config`，用 `/start_profile` 和 `/stop_profile` 控制采集（v0.32.0 文档）。trace 文件按 rank 命名，例如 `rank0.<id>.pt.trace.json.gz`，并附带 `rank0.profiler_out.txt` 汇总表。
- **SGLang**：设置环境变量 `SGLANG_TORCH_PROFILER_DIR`。`/start_profile` 支持 `start_step`、`num_steps`、`activities`、`merge_profiles`、`detailed_annotations` 等参数。开启 `detailed_annotations` 后，每一步的标注中会写明这一步是 EXTEND、DECODE 还是 MIXED，以及 batch 大小和 KV 长度。
- **查看**：https://ui.perfetto.dev/ （直接拖入 .json.gz 文件）。
- **分析**：`tools/analyze_torch_trace.py`，输出 kernel 排名、类别占比、SM 覆盖、空闲气泡、CPU 端 API 开销。

## 步骤
### 1. vLLM，Qwen3-8B，decode 为主
```bash
bash scripts/engine.sh start vllm qwen3-8b --name v-prof -- \
  --profiler-config '{"profiler":"torch","torch_profiler_dir":"/traces/E16/vllm-qwen3","torch_profiler_record_shapes":true,"torch_profiler_with_stack":true}'
bash scripts/wait_ready.sh v-prof
# 先发一批请求进入稳态，再采 30 个迭代
curl -s -X POST 127.0.0.1:8000/start_profile -H 'Content-Type: application/json' \
  -d '{"profile_prefix":"decode_bs16","delay_iterations":50,"max_iterations":30}'
bash scripts/bench_serve.sh --tool vllm --exp E16 --label vllm-qwen3-prof --instance v-prof --no-monitor -- \
  --dataset-name random --random-input-len 512 --random-output-len 256 --ignore-eos --num-prompts 32 --max-concurrency 16 --seed 1
curl -s -X POST 127.0.0.1:8000/stop_profile          # 等它返回，写盘可能需要一段时间
ls -la runtime/traces/E16/vllm-qwen3/
```

### 2. 分析
```bash
PY=runtime/envs/client/bin/python
$PY tools/analyze_torch_trace.py runtime/traces/E16/vllm-qwen3/decode_bs16_rank0*.pt.trace.json.gz \
  --sm-count 132 --md runtime/traces/E16/vllm-qwen3/report.md --json runtime/traces/E16/vllm-qwen3/report.json
```

文件名中的前缀以实际生成的为准，用 `ls` 确认。

### 3. SGLang，同一模型，打开详细标注
```bash
bash scripts/engine.sh start sglang qwen3-8b --name s-prof --env SGLANG_TORCH_PROFILER_DIR=/traces/E16/sglang-qwen3
bash scripts/wait_ready.sh s-prof
curl -s -X POST 127.0.0.1:30000/start_profile -H 'Content-Type: application/json' \
  -d '{"output_dir":"/traces/E16/sglang-qwen3","start_step":50,"num_steps":30,"activities":["CPU","GPU"],"detailed_annotations":true}'
bash scripts/bench_serve.sh --tool vllm --exp E16 --label sglang-qwen3-prof --instance s-prof --no-monitor -- \
  --dataset-name random --random-input-len 512 --random-output-len 256 --ignore-eos --num-prompts 32 --max-concurrency 16 --seed 1
ls runtime/traces/E16/sglang-qwen3/
$PY tools/analyze_torch_trace.py runtime/traces/E16/sglang-qwen3/*.trace.json.gz --md runtime/traces/E16/sglang-qwen3/report.md
```

报告的“标注区间”一节会按 `step[DECODE]`、`step[EXTEND]`、`step[MIXED]` 汇总每类步骤的平均耗时。

### 4. 对比实验（每项各采一份 trace）
| 对比 | 看什么 |
|---|---|
| batch 1 与 batch 64 的 decode | GEMM 从“访存受限的瘦长矩阵”变成“计算受限”；SM 覆盖的变化；attention 占比上升 |
| 预填充（`WL_PRE_8K`）与 decode | 预填充以 GEMM 和 attention 为主，GPU 忙碌比例接近 100% |
| eager（`--enforce-eager`）与 CUDA graph | CPU 端 `cudaLaunchKernel` 的次数与耗时、GPU 空闲气泡（与 E12、E17 互相印证） |
| TP1 与 TP8 | 通信 kernel（all-reduce）占比 |
| GLM-5.3-Flash TP8 | 稀疏 MLA、KDA、indexer、MoE 各自的占比（新架构的 kernel 构成） |

GLM-5.3-Flash 的 trace 很大，只采 5 到 10 个迭代（`max_iterations` 或 `num_steps`）。

## 在 Perfetto 里看什么
1. **GPU stream 行**：kernel 是否连续？空隙出现在哪里？
2. **CPU 线程行**：Python 函数调用栈、`cudaLaunchKernel`。CPU 是否领先 GPU？
3. 选中一个 kernel，看 args 中的 grid、block、registers per thread、shared memory、est. achieved occupancy。
4. 用 flow 箭头（CPU launch → GPU kernel）看提交到执行之间的延迟。

## 研究启发
- trace 中反复出现的小 kernel（norm、rope、采样）合起来往往占 10–20%，这就是 kernel 融合的空间。
- decode 小 batch 时 SM 覆盖低：一个 kernel 只启动几十个 block，大部分 SM 闲置。可以做多请求、多模型共享 GPU（MuxServe 2404.02015）或 SM 级别的划分（SGLang 有 `--sm-group-num`、PD 复用 `--enable-pdmux`）。

## 本机实测记录
