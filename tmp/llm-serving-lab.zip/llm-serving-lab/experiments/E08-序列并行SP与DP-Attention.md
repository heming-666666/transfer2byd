# E08 序列并行（SP）、DP-attention、batch overlap

## 要理解的概念
- **Megatron 式序列并行（SP，1909.08053 / 2205.05198）**：
  - 在 TP 的基础上，把 LayerNorm、Dropout 等逐 token 的操作沿序列维度切开。
  - all-reduce 拆成 reduce-scatter + all-gather，通信量不变，但激活显存减少，逐 token 计算不再重复。
  - 训练中很常见。
- **推理引擎中的现状**（重要，避免走弯路）：
  - **vLLM v0.32.0 的发布说明写明，torch.compile 的序列并行与 AsyncTP pass 已被移除**（`PassConfig.enable_sp` 等字段不再存在），只保留“模型级”的 SP。
  - `--enable-hc-sp`（Hyper-Connection 的 SP）目前只支持 Qwen4Exp，不适用于本包的模型。
  - 所以在本包的模型上，SP 的思想主要通过下面两种机制体现。
- **DP-attention**：attention 部分按数据并行（每个 rank 处理不同请求的完整 attention），MoE 部分按 EP 或 TP。
  - 对 MLA 模型，它消除了 KV 在 TP 下的重复存储，与 DCP 目标相同、手段不同。
  - 在 attention 与 MoE 的边界上做 all-gather 或 reduce-scatter，形式上与 SP 相同。
  - SGLang：`--attn-dp-size N`（v0.5.22 起取代 `--enable-dp-attention`），常配合 `--enable-dp-lm-head`。
  - vLLM：DP + `--enable-expert-parallel`（DEP）。
- **batch overlap**：把一个 batch 拆成两个 micro-batch，一个算 attention 时另一个做 MoE 通信，以此隐藏通信。
  - vLLM：`--enable-dbo`（dual batch overlap），阈值由 `--dbo-decode-token-threshold` 和 `--dbo-prefill-token-threshold` 控制。
  - SGLang：`--enable-two-batch-overlap`、`--enable-single-batch-overlap`。

## 设计
| 对比 | 配置 |
|---|---|
| A. DP-attention（SGLang，GLM-5.3-Flash） | TP8+EP8（cookbook 默认）/ TP8 + `--attn-dp-size 8` + EP8 + `--enable-dp-lm-head`。注意：cookbook 说明投机解码不能与 DP-attention 一起用 |
| B. DEP（vLLM，GLM-4.7-Flash 4 卡） | TP4 / DP4+EP |
| C. batch overlap（vLLM，DEP4） | 关闭 / `--enable-dbo` |
| D. 概念验证 | 在 E16 的 trace 中找出 attention 与 MoE 边界上的 all-gather、reduce-scatter 和 all-to-all kernel |

## 步骤
```bash
source experiments/workloads.sh
# A
bash scripts/engine.sh start sglang glm53-flash --name s-glm53-dpattn -- --attn-dp-size 8 --enable-dp-lm-head
bash scripts/wait_ready.sh s-glm53-dpattn 5400
runtime/envs/client/bin/python tools/parse_server_log.py runtime/logs/engines/s-glm53-dpattn.latest.log | grep -iE "kv|max_running"
for wl in LAT THR; do arr="WL_${wl}[@]"; bash scripts/bench_serve.sh --tool vllm --exp E08 --label glm53-dpattn-${wl,,} --instance s-glm53-dpattn -- "${!arr}"; done
bash scripts/engine.sh stop s-glm53-dpattn
# C
bash scripts/engine.sh start vllm glm47-flash --gpus 0,1,2,3 --name v-glm47-dep4-dbo -- --tensor-parallel-size 1 --data-parallel-size 4 --enable-expert-parallel --enable-dbo
```

B 和 C 的对照组参考 E05 的 DEP4。

## 分析
1. DP-attention 开启后，KV token 数增加了多少？低并发的 TPOT 是否变差？（每个 rank 的 batch 更小，MoE 前多了一次 all-gather。）
2. 高并发吞吐如何变化？找出 DP-attention 划算的并发区间。
3. DBO 对 TPOT 和吞吐的影响。用 trace 看通信 kernel 是否和计算 kernel 重叠了（两个 stream 上的时间重叠）。

## 研究启发
- 通信隐藏的上限取决于计算与通信的比例。H800 的 NVLink 带宽较低，通信占比高，batch overlap 的潜在收益比 H100 更大。可以做一个“在低带宽互联上的 MoE 推理优化”方向。
- 相关工作：NanoFlow（2408.12757，单卡内的算子级流水）、MegaScale-Infer（2504.02263，乒乓流水）。

## 本机实测记录
