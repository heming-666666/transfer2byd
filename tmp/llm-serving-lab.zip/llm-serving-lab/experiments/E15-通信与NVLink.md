# E15 通信与 NVLink

## 要理解的概念
- **集合通信与并行方式的对应关系**：
  - TP：all-reduce
  - EP：all-to-all（dispatch / combine）
  - PP：点对点 send/recv
  - DP-attention：all-gather / reduce-scatter
  - PD：跨实例的 KV 传输
- **衡量方式**（与 nccl-tests 相同）：
  - algbw = 数据量 / 时间
  - busbw = algbw × 系数（all-reduce 为 2(n−1)/n，all-gather、reduce-scatter、all-to-all 为 (n−1)/n）
  - busbw 可以直接和硬件链路带宽比较。
- **H800 与 H100 的关键差别**：NVLink 总带宽约为 400 GB/s 对 900 GB/s，即 NVLink 被限速。所以本机上 TP 和 EP 的通信开销比 H100 更显著。这是一个明确的“硬件约束”，可以作为研究的切入点。
- **小消息与大消息**：
  - decode 时 all-reduce 的消息很小（几十 KB 到几 MB），由延迟主导；vLLM 和 SGLang 都有自定义 all-reduce kernel 来降低延迟。
  - 预填充时消息大，由带宽主导。
- **NCCL 的算法与协议**：Ring、Tree、NVLS（NVSwitch 上的 SHARP，需要硬件支持）；LL、LL128、Simple。

## 步骤
### 1. 拓扑
```bash
mkdir -p runtime/results/E15
nvidia-smi topo -m | tee runtime/results/E15/topo.txt
nvidia-smi nvlink -s | tee runtime/results/E15/nvlink-status.txt
```

### 2. 集合通信带宽（需要先停止所有引擎）
```bash
source lab.env
bash scripts/engine.sh stop-all
mkdir -p runtime/results/E15
for n in 2 4 8; do
  docker run --rm --gpus all --ipc=host --network host -e CUDA_VISIBLE_DEVICES=$(seq -s, 0 $((n-1))) \
    -v $PWD:/lab --entrypoint torchrun "$VLLM_IMAGE" --nproc-per-node $n /lab/tools/bench_collectives.py \
    --out /lab/runtime/results/E15/collectives-${n}gpu.json | tee runtime/results/E15/collectives-${n}gpu.txt
done
```

### 3. 看 NCCL 的选择
```bash
docker run --rm --gpus all --ipc=host -e NCCL_DEBUG=INFO -e NCCL_DEBUG_SUBSYS=INIT,GRAPH,TUNING -v $PWD:/lab \
  --entrypoint torchrun "$VLLM_IMAGE" --nproc-per-node 8 /lab/tools/bench_collectives.py --ops all_reduce --max-bytes 67108864 \
  2>&1 | tee runtime/results/E15/nccl-debug.txt
grep -iE "NVLS|Channel|Ring|Tree|algo|proto" runtime/results/E15/nccl-debug.txt | head -40
```

强制指定算法做对比：`-e NCCL_ALGO=Ring`、`-e NCCL_ALGO=Tree`、`-e NCCL_NVLS_ENABLE=0/1`、`-e NCCL_PROTO=LL128`。

### 4. 引擎层面
- **vLLM**：TP8 下对比默认（自定义 all-reduce）与 `--disable-custom-all-reduce`（见 E02）。
- **SGLang**：对比 `--disable-custom-all-reduce`、`--enable-nccl-nvls`、`--enable-symm-mem`（是否可用以日志为准）。
- **DeepSeek-V4.1 的 Engram 查表**：在 SGLang main 分支中有 `peer_read`（直接从持有该行的 GPU 读）与 all-reduce、all-to-all 的对比。v0.5.23 只能用环境变量 `SGLANG_OPT_DSV41_ENGRAM_PEER_SHARDS=1` 打开 peer read。这是一个很好的“通信模式选择”案例，见 E23。

### 5. 训练中观察 NVLink 流量
压测期间，`gpu_monitor.sh` 会记录开始和结束时的 `nvidia-smi nvlink -gt d` 计数。有 DCGM 时，`dcgm.txt` 中有 NVLINK_TX/RX 的时间序列。比较 TP8 与 EP8 在同一负载下的 NVLink 字节数。

## 分析
1. 画出 busbw 随消息大小变化的曲线（all-reduce、all-to-all）。在哪个消息大小达到峰值？峰值与理论链路带宽相差多少？
2. 用 E02 的 decode all-reduce 数据量，在这条曲线上查出对应的通信时间，与 E16 trace 中实际的 all-reduce kernel 耗时对比。
3. all-to-all 的带宽为什么比 all-reduce 低？与 EP 的性能（E05）有什么联系？

## 研究启发
- 在带宽受限的 NVLink（H800）上，哪些并行策略更划算？例如更多 EP、更少 TP，或者通信压缩（SGLang 有 `--enable-quant-communications`）。
- 低精度通信：vLLM v0.32.0 的 FlashInfer 单边 all2all 支持 FP8 combine（DEP8 +4%，见发布说明）。

## 本机实测记录
