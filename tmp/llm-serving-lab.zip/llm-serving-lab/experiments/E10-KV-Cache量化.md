# E10 KV cache 量化

## 要理解的概念
- **KV cache 的大小** = 层数 × KV 头数 × 头维度 × 2(K,V) × token 数 × 字节数。
  - 量化到 FP8，容量翻倍；量化到 FP4，容量变为 4 倍。
  - 长上下文、高并发时，KV 容量往往决定吞吐上限。
- **decode 的 attention 也受带宽限制**：KV 字节数减少，attention 也会变快。
- **精度风险**：K 对量化更敏感，outlier 较多（KIVI 2402.02750、KVQuant 2401.18079）。滑动窗口层也比较敏感，vLLM 提供 `--kv-cache-dtype-skip-layers sliding_window`。
- **vLLM v0.32.0 中与本机相关的新内容**：
  - `--kv-cache-dtype fp8_ds_mla`：SM90 上的 GLM-5.3-Flash 可以使用 FP8 KV，发布说明称最多 +31% 输出吞吐。
  - NVFP4 KV cache 可以在 SM90 上运行（#60620）。
  - 可选的 dtype 还有 `fp8`、`fp8_e4m3`、`fp8_e5m2`、`nvfp4`、各种 per-token-head 格式等（见 `vllm/config/cache.py`）。
- **SGLang**：`--kv-cache-dtype fp8_e4m3|fp8_e5m2|nvfp4|fp4_mx_block16`。cookbook 说明，GLM-5.3-Flash 在 Hopper 上只能用 BF16 KV（FP8 KV + TRT-LLM DSA 只支持 Blackwell）。

## 设计
| 模型 | 对比 |
|---|---|
| Qwen3-8B（vLLM） | `auto`(BF16) / `fp8` / `nvfp4` |
| Qwen3-8B（SGLang） | `auto` / `fp8_e4m3` |
| GLM-5.3-Flash（vLLM） | `auto`(BF16) / `fp8_ds_mla` |

观察：

- KV token 数（启动日志）
- 吞吐：长上下文高并发负载，`--random-input-len 8192 --random-output-len 512 --max-concurrency 128`
- `WL_DEC` 的 TPOT
- 精度：GSM8K，再加一个长上下文检索任务，例如 E22 中 evalscope 的 `needle_haystack` 子集

## 步骤（Qwen3-8B，vLLM）
```bash
PY=runtime/envs/client/bin/python
for kv in auto fp8 nvfp4; do
  bash scripts/engine.sh start vllm qwen3-8b --name v-kv-$kv -- --kv-cache-dtype $kv
  bash scripts/wait_ready.sh v-kv-$kv || { echo "$kv 不支持，记录日志"; bash scripts/engine.sh stop v-kv-$kv; continue; }
  $PY tools/parse_server_log.py runtime/logs/engines/v-kv-$kv.latest.log | grep -E "kv_cache_tokens|concurrency"
  bash scripts/bench_serve.sh --tool vllm --exp E10 --label qwen3-kv$kv-long --instance v-kv-$kv -- \
    --dataset-name random --random-input-len 8192 --random-output-len 512 --ignore-eos --num-prompts 256 --max-concurrency 128 --seed 1
  bash scripts/engine.sh stop v-kv-$kv
done
```

GLM-5.3-Flash：

```bash
bash scripts/engine.sh start vllm glm53-flash --name v-glm53-fp8kv -- --kv-cache-dtype fp8_ds_mla
```

对照组是默认的 `glm53-flash`，两者用同一负载。

## 分析
1. KV token 数是否接近 2 倍（FP8）或 4 倍（FP4）？如果不是，说明还有其他显存开销或块对齐的影响。
2. 吞吐提升主要来自“能放下更多并发”还是“attention 更快”？对比低并发与高并发两种情况。
3. 精度：短任务往往看不出差别，长上下文检索更容易暴露 KV 量化的误差。
4. 对 GLM-5.3-Flash 来说，KDA 状态不受 KV dtype 影响，只有稀疏 MLA 层的 KV 被量化。

## 研究启发
- 在 OPD（在策略蒸馏）中，教师模型给学生回答打分时要持有长 KV，KV 量化对“教师打分保真度”的影响是一个实证问题。参见研究包 `04` 的 I8 与 E3 设计。
- 按层、按头混合精度的 KV（`--kv-cache-dtype-skip-layers` 是一个最简单的版本）。

## 本机实测记录
