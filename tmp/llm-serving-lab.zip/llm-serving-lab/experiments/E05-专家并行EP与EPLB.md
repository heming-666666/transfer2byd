# E05 专家并行（EP）、all-to-all 后端、EPLB

## 要理解的概念
- **MoE 层的两种切法**：
  - **TP-MoE**：每个专家的矩阵按 TP 切到所有卡上，计算后做 all-reduce。
  - **EP**：每张卡持有一部分完整的专家，token 通过 all-to-all 发到专家所在的卡（dispatch），算完再发回（combine）。
- **vLLM 的写法**：`--enable-expert-parallel`，EP 规模 = TP × DP。常见组合是 attention 用 DP、MoE 用 EP（DEP），例如 `--data-parallel-size 8 --enable-expert-parallel`。
- **SGLang 的写法**：`--ep-size N`，GLM-5.3-Flash 的 cookbook 配置就是 TP8 + EP8。
- **all-to-all 后端**（vLLM `--all2all-backend`）：
  - `allgather_reducescatter`（默认，通用）
  - `deepep_high_throughput` / `deepep_low_latency`（需要 DeepEP，主要用于多节点）
  - FlashInfer 的 NVLink 单边 / 双边方案（面向 MNNVL）
- **负载不均**：各专家收到的 token 数不同，EP 下每一步的时间取决于最忙的那张卡。EPLB 通过冗余专家和重新放置来平衡负载。

## 设计
| 对比 | 配置 |
|---|---|
| A. TP-MoE 与 EP | GLM-4.7-Flash 4 卡：TP4 / TP4+EP（vLLM `--enable-expert-parallel`）/ DP4+EP（DEP4） |
| B. 大模型 | GLM-5.3-Flash 8 卡：vLLM TP8 / TP8+EP；SGLang TP8+EP8（cookbook 默认） |
| C. EPLB | GLM-4.7-Flash DEP4：关闭 / 开启 `--enable-eplb --eplb-config '{"window_size":1000,"step_interval":3000,"num_redundant_experts":4,"log_balancedness":true}'` |
| D. all-to-all 后端（可选） | DEP4：`allgather_reducescatter` / `deepep_low_latency`（先确认镜像中有 DeepEP：`python3 -c "import deep_ep"`） |

## 步骤（A，vLLM）
```bash
source experiments/workloads.sh
for cfg in "tp4|--tensor-parallel-size 4" "tp4ep|--tensor-parallel-size 4 --enable-expert-parallel" "dep4|--tensor-parallel-size 1 --data-parallel-size 4 --enable-expert-parallel"; do
  n=${cfg%%|*}; args=${cfg#*|}
  # shellcheck disable=SC2086
  bash scripts/engine.sh start vllm glm47-flash --gpus 0,1,2,3 --name v-glm47-$n -- $args
  bash scripts/wait_ready.sh v-glm47-$n
  for wl in LAT THR; do arr="WL_${wl}[@]"; bash scripts/bench_serve.sh --tool vllm --exp E05 --label glm47-$n-${wl,,} --instance v-glm47-$n -- "${!arr}"; done
  bash scripts/engine.sh stop v-glm47-$n
done
```

EPLB 的均衡度会定期打印在日志中：`grep -i balancedness runtime/logs/engines/<实例>.latest.log`。

## 分析
1. 低并发时，EP 的 all-to-all 延迟可能比 TP-MoE 的 all-reduce 更高；高并发时，EP 能让每个专家处理更大的 batch，GEMM 更高效。找出两者的交叉点。
2. DEP 让 attention 部分没有 TP 通信，但每个 DP rank 的 batch 更小。MLA 模型的 KV 在 TP 下会重复存储（KV 头只有 1 个潜变量头），DP-attention 可以避免这种重复（见 E07、E08）。
3. EPLB 开启后，均衡度从多少提升到多少？吞吐和尾延迟是否改善？冗余专家占用了多少显存？
4. 用 E16 的 trace 找 dispatch/combine kernel 的耗时。

## 研究启发
- 专家负载随负载类型（代码、数学、中文）变化（见 E06）。EPLB 按窗口统计，对突发变化反应慢。可以研究预测式的专家放置。
- 相关工作：MegaScale-Infer（2504.02263，attention 与专家分离部署）；2026 年的 Least-Loaded EP（2601.17111）、TEMPO（2608.13057）。

## 本机实测记录
