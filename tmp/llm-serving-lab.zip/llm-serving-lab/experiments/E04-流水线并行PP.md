# E04 流水线并行（PP）

## 要理解的概念
- **PP 的切分方式**：按层切分，不同 GPU 依次处理不同的层。每个 stage 之间只传一次激活（点对点通信），通信量比 TP 小得多。
- **代价**：
  - 单个请求要依次经过所有 stage，延迟不会下降；
  - 需要多个 micro-batch 填满流水线，否则有气泡（bubble）。
- **推理引擎的做法**：vLLM 和 SGLang 都让不同的 batch 同时处于不同的 stage。并发足够时，吞吐接近 TP；并发低时，GPU 大部分时间在等。
- **适用场景**：跨节点（网络带宽低），或者 TP 不能整除头数时。本机 NVLink 带宽较低，TP4×PP2 与 TP8 的对比很有意义。

## 设计
| 模型 | 对比（相同卡数） |
|---|---|
| Qwen3-8B（2 卡） | TP2 / PP2 |
| Qwen3-8B（4 卡） | TP4 / TP2×PP2 / PP4 |
| GLM-5.3-Flash（8 卡） | TP8 / TP4×PP2（vLLM recipe 的兼容策略中列出了 `multi_node_tp_pp`，单机可以尝试） |

负载：`WL_LAT`、`WL_MID`、`WL_THR`（看并发对 PP 的影响）。

## 步骤
```bash
source experiments/workloads.sh
run() {  # run <名字> <gpus> <引擎参数...>
  local n=$1 g=$2; shift 2
  bash scripts/engine.sh start vllm qwen3-8b --gpus $g --name $n -- "$@"
  bash scripts/wait_ready.sh $n
  for wl in LAT MID THR; do arr="WL_${wl}[@]"; bash scripts/bench_serve.sh --tool vllm --exp E04 --label $n-${wl,,} --instance $n -- "${!arr}"; done
  bash scripts/engine.sh stop $n
}
run v-tp4     0,1,2,3 --tensor-parallel-size 4
run v-tp2pp2  0,1,2,3 --tensor-parallel-size 2 --pipeline-parallel-size 2
run v-pp4     0,1,2,3 --pipeline-parallel-size 4
```

GLM-5.3-Flash：

```bash
bash scripts/engine.sh start vllm glm53-flash --name v-glm53-tp4pp2 -- --tensor-parallel-size 4 --pipeline-parallel-size 2
```

SGLang：参数换成 `--tp-size 2 --pp-size 2`。可选 `--pp-max-micro-batch-size`、`--pp-async-batch-depth`。

## 分析
1. 低并发（`WL_LAT`）时，PP 的 TPOT 应明显差于 TP：一个 token 要依次经过所有 stage，且无法并行。
2. 高并发（`WL_THR`）时，PP 的吞吐会追上来，甚至超过 TP（TP 的 all-reduce 开销在 H800 上更明显）。
3. 用 E16 的 trace 观察 PP 的气泡：每张 GPU 上 kernel 之间的空隙。`analyze_torch_trace.py` 输出的“忙碌比例”会直接反映出来。
4. 启动日志中的 KV token 数：PP 下每张卡只放部分层的 KV，总 KV 容量与 TP 相比如何？

## 研究启发
- 推理中的 PP 气泡与请求长度分布相关。可以研究“异构 stage 切分”和“按负载动态调整 PP 与 TP 比例”。
- 经典参考：GPipe（1811.06965）、Megatron-LM（1909.08053）。

## 本机实测记录
