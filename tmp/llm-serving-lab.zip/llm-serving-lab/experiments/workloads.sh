# shellcheck shell=bash disable=SC2034
# 标准负载定义（给 vllm bench serve 客户端用，即 bench_serve.sh --tool vllm）。
# 用法：source experiments/workloads.sh; bash scripts/bench_serve.sh --tool vllm ... -- "${WL_LAT[@]}"
# 所有负载都固定输入/输出长度（--ignore-eos）和随机种子，保证不同配置之间可比。
# 用 SGLang 客户端（--tool sglang）时，把 --ignore-eos 去掉（它默认忽略 EOS），--seed 保留。

# 延迟点：单并发，看 TTFT 与 TPOT 的“最好情况”
WL_LAT=(--dataset-name random --random-input-len 1024 --random-output-len 256 --ignore-eos
        --num-prompts 16 --max-concurrency 1 --seed 1)
# 中等并发
WL_MID=(--dataset-name random --random-input-len 1024 --random-output-len 256 --ignore-eos
        --num-prompts 128 --max-concurrency 16 --seed 1)
# 吞吐点：高并发，看系统能撑多少
WL_THR=(--dataset-name random --random-input-len 1024 --random-output-len 256 --ignore-eos
        --num-prompts 512 --max-concurrency 64 --seed 1)
# 预填充：长输入、只输出 1 个 token，TTFT 约等于预填充时间
WL_PRE_8K=(--dataset-name random --random-input-len 8192 --random-output-len 1 --ignore-eos
           --num-prompts 16 --max-concurrency 1 --seed 1)
WL_PRE_32K=(--dataset-name random --random-input-len 32768 --random-output-len 1 --ignore-eos
            --num-prompts 8 --max-concurrency 1 --seed 1)
# 解码：短输入、长输出，TPOT 主导
WL_DEC=(--dataset-name random --random-input-len 128 --random-output-len 1024 --ignore-eos
        --num-prompts 64 --max-concurrency 32 --seed 1)
# 共享前缀：5 个 2048-token 前缀被反复使用（前缀缓存、路由策略实验）
WL_PREFIX=(--dataset-name prefix_repetition --prefix-repetition-prefix-len 2048 --prefix-repetition-suffix-len 128
           --prefix-repetition-num-prefixes 5 --prefix-repetition-output-len 128 --num-prompts 200 --max-concurrency 16 --seed 1)
# 真实对话分布（需先 bash scripts/get_datasets.sh sharegpt），按泊松到达，请求率在命令行另加 --request-rate
WL_SHAREGPT=(--dataset-name sharegpt --dataset-path /datasets/sharegpt/ShareGPT_V3_unfiltered_cleaned_split.json
             --num-prompts 500 --seed 1)
