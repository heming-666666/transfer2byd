# E02 张量并行（TP）

## 要理解的概念
- **TP 的切分方式**：每层的 QKV 和 MLP 按列或按行切分，每层需要 2 次 all-reduce（attention 输出后、MLP 输出后）。
- **decode**：小 batch 时受显存带宽限制。TP 让每张卡读的权重变少，单步时间下降，但 all-reduce 的延迟是固定开销。
- **prefill**：受计算限制。TP 把计算分摊到多张卡。
- **H800 的特点**：NVLink 带宽约为 H100 的一半，所以 TP 越大，通信占比越高。这是本机最值得观察的一点。
- **整除约束**：TP 必须能整除注意力头数。
  - Qwen3-8B 有 32 个 Q 头、8 个 KV 头，TP1/2/4/8 都可以。
  - GLM-4.7-Flash 有 20 个头，TP8 不能整除。可以试一下，看报错。

## 设计
| 变量 | 取值 |
|---|---|
| TP | Qwen3-8B：1, 2, 4, 8；GLM-4.7-Flash：1, 2, 4（8 预期报错）；GLM-5.3-Flash：只能 8（与 E04、E05 的布局对比） |
| 负载 | `WL_LAT`、`WL_THR`、`WL_PRE_8K` |
| 固定 | max-model-len、gpu-memory-utilization、镜像 |
| 观察 | TTFT、TPOT、吞吐、KV token 数（启动日志）、通信占比（E16 的 trace） |

## 步骤（vLLM，Qwen3-8B）
```bash
source experiments/workloads.sh; PY=runtime/envs/client/bin/python
declare -A G=([1]=0 [2]=0,1 [4]=0,1,2,3 [8]=0,1,2,3,4,5,6,7)
for tp in 1 2 4 8; do
  bash scripts/engine.sh start vllm qwen3-8b --gpus ${G[$tp]} --name v-tp$tp -- --tensor-parallel-size $tp
  bash scripts/wait_ready.sh v-tp$tp
  for wl in LAT THR PRE_8K; do
    arr="WL_${wl}[@]"
    bash scripts/bench_serve.sh --tool vllm --exp E02 --label vllm-qwen3-tp$tp-${wl,,} --instance v-tp$tp -- "${!arr}"
  done
  $PY tools/parse_server_log.py runtime/logs/engines/v-tp$tp.latest.log | grep -E "kv_cache_tokens|cuda_graph"
  bash scripts/engine.sh stop v-tp$tp
done
$PY tools/collect_bench.py runtime/results/E02 --csv runtime/results/E02/summary.csv
```

SGLang 的做法相同，把 `vllm qwen3-8b` 换成 `sglang qwen3-8b`，参数换成 `-- --tp-size $tp`。

## 补充：自定义 all-reduce 与 NCCL
vLLM 在单机上默认使用自定义 all-reduce kernel（小消息时延迟更低）。在 TP8 下对比：

```bash
bash scripts/engine.sh start vllm qwen3-8b --gpus 0,1,2,3,4,5,6,7 --name v-tp8-nccl -- --tensor-parallel-size 8 --disable-custom-all-reduce
```

用 `WL_LAT` 对比 TPOT。

## 分析
1. 画出 TPOT 随 TP 变化的曲线，与理想的 `TPOT(1)/TP` 对比，偏离部分就是通信与同步开销。
2. 算一下 decode 一步的 all-reduce 数据量：`2 × 层数 × hidden × batch × 2 字节`。Qwen3-8B 为 36 层、hidden 4096。拿这个数字与 E15 测得的 NVLink 带宽对比，估算通信时间的下界。
3. 吞吐：TP 增大后，单卡上的 KV 更多（权重占比变小），能容纳的并发更多。看吞吐是否超线性。
4. 用 E16 的方法对 TP8 采一份 trace，看 all-reduce kernel 占 GPU 时间的比例。

## 研究启发
- 小模型在 TP8 下通信占比很高。是否存在“按负载动态选择 TP”或“attention 用 TP、MLP 用 DP”的空间？可以联系 E08 的 DP-attention。
- 通信与计算重叠的相关工作：Flux、NanoFlow（2408.12757）。

## 本机实测记录
