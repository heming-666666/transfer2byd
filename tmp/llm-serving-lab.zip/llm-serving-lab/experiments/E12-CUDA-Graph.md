# E12 CUDA graph

## 要理解的概念
- **CPU 提交开销**：decode 一步有几百到上千个 kernel。eager 模式下，CPU 每次 launch 约需几微秒；batch 小时，GPU 执行得比 CPU 提交还快，GPU 就会空等。这就是 CPU-bound。
- **CUDA graph**：把一整步的 kernel 序列预先录制下来，运行时一次 `cudaGraphLaunch` 回放。代价是：
  - 只能回放固定的形状，所以要按多个 batch 大小分别捕获，运行时把 batch 填充到最近的捕获大小；
  - 捕获需要时间，并占用额外显存。
- **vLLM 的模式**（`--compilation-config '{"cudagraph_mode": ...}'`，取值来自 `vllm/config/compilation.py`）：
  - `NONE`：等价于 `--enforce-eager`
  - `PIECEWISE`：attention 之外的部分录制成图，attention 保持 eager
  - `FULL`：整步录制，要求 attention 后端支持
  - `FULL_DECODE_ONLY`：只对纯 decode batch 用 FULL，prefill 用 eager
  - `FULL_AND_PIECEWISE`：默认，纯 decode 用 FULL，混合 batch 用 PIECEWISE
  - 相关参数：`--cudagraph-capture-sizes`、`--max-cudagraph-capture-size`；`--cudagraph-metrics` 输出填充统计
- **SGLang 的参数**：
  - `--disable-cuda-graph`
  - `--cuda-graph-max-bs-decode`（最大捕获 batch）
  - `--cuda-graph-backend-decode full|breakable|disabled`
  - `--cuda-graph-backend-prefill breakable|disabled`
  - `--enable-profile-cuda-graph`：对捕获过程做 profiling
  - `--enable-torch-compile`

## 设计
| 框架 | 对比 | 观察 |
|---|---|---|
| vLLM / Qwen3-8B | `--enforce-eager` / `PIECEWISE` / `FULL_DECODE_ONLY` / `FULL_AND_PIECEWISE`（默认） | 启动耗时、捕获耗时与显存（日志）、`WL_LAT` 与 `WL_MID` 的 TPOT |
| vLLM / Qwen3-8B | 默认模式下 `--max-cudagraph-capture-size 8 / 64 / 512` | 并发 16 和 128 时的 TPOT（超过最大捕获大小时退回 eager） |
| SGLang / Qwen3-8B | `--disable-cuda-graph` / 默认 / `--cuda-graph-max-bs-decode 8` | 同上 |
| SGLang / GLM-4.7-Flash | 默认 + `--enable-profile-cuda-graph` | 捕获阶段每个 batch 的耗时与显存 |

## 步骤
```bash
source experiments/workloads.sh; PY=runtime/envs/client/bin/python
declare -A M=([eager]='--enforce-eager' [piecewise]='--compilation-config {"cudagraph_mode":"PIECEWISE"}' \
  [fulldec]='--compilation-config {"cudagraph_mode":"FULL_DECODE_ONLY"}' [default]='--cudagraph-metrics')
for k in eager piecewise fulldec default; do
  # shellcheck disable=SC2086
  bash scripts/engine.sh start vllm qwen3-8b --name v-cg-$k -- ${M[$k]}
  bash scripts/wait_ready.sh v-cg-$k
  $PY tools/parse_server_log.py runtime/logs/engines/v-cg-$k.latest.log | grep -E "cuda_graph|engine_init|torch_compile|ready_after"
  for wl in LAT MID; do arr="WL_${wl}[@]"; bash scripts/bench_serve.sh --tool vllm --exp E12 --label qwen3-cg-$k-${wl,,} --instance v-cg-$k -- "${!arr}"; done
  bash scripts/engine.sh stop v-cg-$k
done
```

上面依赖 JSON 中没有空格才能被正确分词。如果要写带空格的 JSON，就不要用关联数组，直接逐条执行命令。

SGLang 捕获阶段的 profiling：

```bash
bash scripts/engine.sh start sglang glm47-flash --name s-glm47-cgprof \
  --env SGLANG_TORCH_PROFILER_DIR=/traces/E12/glm47-capture --env SGLANG_GRAPH_BATCH_CAPTURE=1 -- --enable-profile-cuda-graph
bash scripts/wait_ready.sh s-glm47-cgprof
ls runtime/traces/E12/glm47-capture/graph_capture_profile/
```

每个 batch 大小一个 trace，可以用 `tools/analyze_torch_trace.py` 分析。日志中还有每个 kernel 的 CPU/CUDA 时间汇总表。

还可以用 vLLM 专门测启动时间的子命令（参数见 `vllm bench startup --help`）：

```bash
docker run --rm --gpus all --ipc=host -v $PWD/runtime/models:/models:ro --entrypoint vllm $VLLM_IMAGE bench startup --help
```

## 分析
1. **eager 与默认的 TPOT 差距**：并发 1 时最大，并发越高越小。为什么？（高并发时每个 kernel 变大，GPU 执行时间盖过了 CPU 提交时间。）
2. **捕获代价**：耗时多少秒、占用多少显存，换来多少 TPOT 收益。
3. **超出捕获范围时 TPOT 的跳变**：配合 `--cudagraph-metrics` 观察填充比例。
4. **E17 用 nsys 直接看 CPU 提交**：eager 模式下 `cudaLaunchKernel` 的总耗时、GPU 空闲气泡；graph 模式下只有 `cudaGraphLaunch`。

## 研究启发
- **动态形状与 CUDA graph 的矛盾**：变长 batch、投机解码的变长草稿（vLLM 的 adaptive verification 要求 attention 后端支持 `AttentionCGSupport.ALWAYS`）、稀疏注意力的变长索引。breakable graph 是一种折中。
- **捕获大小怎么选**：可以根据实际 batch 分布自动选择（参考 recipe 中 DeepSeek B200 那一长串手工 capture sizes）。

## 本机实测记录
