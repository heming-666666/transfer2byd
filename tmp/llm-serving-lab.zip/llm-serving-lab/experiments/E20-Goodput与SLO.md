# E20 goodput 与 SLO

## 要理解的概念
- **吞吐不等于有效吞吐**：一个请求只有在满足 SLO（例如 TTFT ≤ 2s 且 TPOT ≤ 50ms）时才算“有用”。goodput 就是每秒满足 SLO 的请求数（DistServe 2401.09670）。
- **压测的两种模式**：
  - **闭环**：`--max-concurrency` 固定并发，看系统能承受的最大吞吐。
  - **开环**：`--request-rate` 按泊松或 Gamma 分布到达，更接近真实流量；`--burstiness` 小于 1 表示更突发。
- **SLO 的选择**（示例，按场景调整）：

| 场景 | TTFT | TPOT |
|---|---|---|
| 交互聊天 | ≤ 2000 ms | ≤ 50 ms（约 20 token/s，略快于阅读速度） |
| 代码补全 | ≤ 500 ms | ≤ 30 ms |
| 长文档问答 | ≤ 10000 ms | ≤ 100 ms |

- **工具支持**：两个压测客户端都支持 `--goodput ttft:<ms> tpot:<ms> [e2el:<ms>]`。
  - vLLM 结果文件中的字段是 `request_goodput`。
  - SGLang 结果中还有 `slo_attainment` 与按指标拆分的达成率。

## 设计
1. 确定一个配置（例如 Qwen3-8B TP1 或 GLM-5.3-Flash TP8）。
2. **请求率扫描**：从很低开始，逐步增加到系统饱和。每个请求率跑 60–120 秒的请求量，记录吞吐、P50/P99 TTFT、P50/P99 TPOT、goodput。
3. 画两条曲线：“请求率 → P99 TTFT 与 P99 TPOT”和“请求率 → goodput”，goodput 曲线的峰值就是该配置的容量。
4. **用 goodput 曲线比较配置**：例如 E21 的分块预填充大小、E14 的 PD 分离、E18 的投机解码。比较时看“满足 90% SLO 的最大请求率”，而不只是吞吐峰值。
5. **突发性**：在相同平均请求率下，比较 `--burstiness 0.5 / 1 / 2`。

## 步骤（Qwen3-8B，ShareGPT 分布）
```bash
bash scripts/get_datasets.sh sharegpt
source experiments/workloads.sh
bash scripts/engine.sh start vllm qwen3-8b && bash scripts/wait_ready.sh vllm-qwen3-8b
for r in 1 2 4 8 12 16 24 32; do
  bash scripts/bench_serve.sh --tool vllm --exp E20 --label qwen3-sharegpt-rate$r --instance vllm-qwen3-8b -- \
    "${WL_SHAREGPT[@]}" --num-prompts $((r*90)) --request-rate $r --goodput ttft:2000 tpot:50 \
    --percentile-metrics ttft,tpot,itl,e2el --metric-percentiles 50,90,99
done
runtime/envs/client/bin/python tools/collect_bench.py runtime/results/E20 --csv runtime/results/E20/summary.csv
```

用 `summary.csv` 画图（client 环境中有 matplotlib），横轴为请求率，纵轴为 goodput 与 P99 TTFT/TPOT。

突发性对比：固定 `--request-rate 12`，分别加 `--burstiness 0.5`、`1.0`、`2.0`。

## 分析
1. 系统饱和点：吞吐不再增长、延迟急剧上升的请求率。
2. goodput 的峰值通常早于吞吐的峰值。两者之间的差距，就是“为了吞吐牺牲延迟”的部分。
3. 违反 SLO 的主要是 TTFT（排队、预填充被阻塞）还是 TPOT（decode batch 太大、被预填充打断）？这决定了下一步该调哪个参数（E21）。
4. 突发流量下，P99 恶化得更早。

## 研究启发
- **SLO 感知的调度**：按每个请求的 SLO 排序，或者在预期违约时提前拒绝。相关工作：DistServe、Llumnix（2406.03243）、BestServe（2506.05871）、Prefill-decode multiplexing（2504.14489）。
- **思考模型的 SLO 怎么定义**：首个思考 token 的时间与首个答案 token 的时间不同，需要新的指标。这本身就是一个可以写的问题。

## 本机实测记录
