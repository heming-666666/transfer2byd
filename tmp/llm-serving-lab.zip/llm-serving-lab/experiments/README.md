# 实验索引（功能 2）

## 1. 通用约定

- **负载**：用 `experiments/workloads.sh` 中的标准负载（`WL_LAT`、`WL_MID`、`WL_THR`、`WL_PRE_8K`、`WL_PRE_32K`、`WL_DEC`、`WL_PREFIX`、`WL_SHAREGPT`），保证不同实验可以互相比较。
- **压测**：`bash scripts/bench_serve.sh --tool vllm --exp <编号> --label <标签> --instance <实例> -- <负载参数>`。默认两个框架都用 vLLM 客户端压，排除客户端差异。
- **重复**：每个配置至少 2 次，两次差异超过 5% 时加跑第 3 次。
- **记录**：每个结果目录写 `notes.md`（模板 `TEMPLATE-实验记录.md`）。每个实验文档末尾的“本机实测记录”写一行总结。
- **汇总**：`runtime/envs/client/bin/python tools/collect_bench.py runtime/results/<编号> --csv runtime/results/<编号>/summary.csv`
- **停机**：实验结束后执行 `bash scripts/engine.sh stop-all`。

```bash
source experiments/workloads.sh      # 每个新 shell 先执行
PY=runtime/envs/client/bin/python
```

## 2. 实验列表

| 编号 | 主题 | 主要模型 | 框架 | GPU | 估时 |
|---|---|---|---|---|---|
| E01 | 基础调用、采样参数、思考/工具/多模态 | 全部 | 两者 | 按模型 | 0.5 天 |
| E02 | 张量并行 TP | Qwen3-8B、GLM-4.7-Flash、GLM-5.3-Flash | 两者 | 1–8 | 1 天 |
| E03 | 数据并行 DP 与请求路由 | Qwen3-8B、GLM-4.7-Flash | 两者 | 4–8 | 1 天 |
| E04 | 流水线并行 PP | Qwen3-8B、GLM-5.3-Flash | 两者 | 2–8 | 0.5 天 |
| E05 | 专家并行 EP、all-to-all 后端、EPLB | GLM-4.7-Flash、GLM-5.3-Flash | 两者 | 2–8 | 1 天 |
| E06 | 专家激活统计 | GLM-4.7-Flash、GLM-5.3-Flash | SGLang 为主 | 2–8 | 0.5 天 |
| E07 | 上下文并行 PCP/DCP | GLM-4.7-Flash、GLM-5.3-Flash | 两者 | 2–8 | 1 天 |
| E08 | 序列并行 SP、DP-attention、batch overlap | GLM-5.3-Flash、GLM-4.7-Flash | 两者 | 4–8 | 0.5 天 |
| E09 | 权重量化 | Qwen3-8B、GLM-4.7-Flash | 两者 | 1–2 | 0.5 天 |
| E10 | KV cache 量化 | Qwen3-8B、GLM-5.3-Flash | 两者 | 1–8 | 0.5 天 |
| E11 | attention 后端 | Qwen3-8B、GLM-5.3-Flash | 两者 | 1–8 | 0.5 天 |
| E12 | CUDA graph | Qwen3-8B、GLM-4.7-Flash | 两者 | 1–2 | 0.5 天 |
| E13 | KV cache 分配、前缀缓存、KV 卸载 | Qwen3-8B、GLM-5.3-Flash | 两者 | 1–8 | 1 天 |
| E14 | PD 分离与 KV 传输 | Qwen3-8B、GLM-4.7-Flash | 两者 | 2–4 | 1 天 |
| E15 | 通信与 NVLink | — | torch/NCCL | 2–8 | 0.5 天 |
| E16 | PyTorch Profiler 与 Perfetto | Qwen3-8B、GLM-5.3-Flash | 两者 | 1–8 | 1 天 |
| E17 | Nsight：SM、kernel、CPU 提交开销、CUDA graph 捕获 | Qwen3-8B、GLM-4.7-Flash | 两者 | 1–2 | 1 天 |
| E18 | 投机解码（MTP、DSpark、n-gram） | GLM-4.7-Flash、GLM-5.3-Flash、DeepSeek | 两者 | 2–8 | 1 天 |
| E19 | 约束解码与格式输出 | Qwen3-8B | 两者 | 1 | 0.5 天 |
| E20 | goodput 与 SLO | Qwen3-8B、GLM-5.3-Flash | 两者 | 1–8 | 1 天 |
| E21 | 调度参数：分块预填充、批大小、调度策略 | Qwen3-8B、GLM-4.7-Flash | 两者 | 1–2 | 0.5 天 |
| E22 | 模型能力评测 | 全部 | 网关 | 按模型 | 1–2 天 |
| E23 | 新架构特性：Engram、DSpark、KDA、稀疏注意力 | DeepSeek、GLM-5.3-Flash | 两者 | 8 | 1–2 天 |

## 3. 推荐顺序

E01 → E20 → E21 → E13 → E02 → E15 → E04 → E03 → E05 → E06 → E08 → E07 → E11 → E12 → E16 → E17 → E09 → E10 → E18 → E19 → E14 → E23 → E22

## 4. 共用的分析工具

| 工具 | 用途 |
|---|---|
| `tools/collect_bench.py` | 汇总压测结果表 |
| `tools/parse_server_log.py` | 启动指标：权重、KV、CUDA graph 捕获 |
| `tools/metrics_diff.py` | 前后指标差值：命中率、接受率、抢占 |
| `tools/analyze_torch_trace.py` | PyTorch Profiler / Perfetto trace 的 kernel、SM 与 CPU 开销分析 |
| `tools/analyze_nsys.py` | Nsight Systems 报告分析 |
| `tools/bench_collectives.py` | NCCL 带宽 |
| `tools/expert_stats.py` | 专家激活分布 |
| `tools/structured_outputs_test.py` | 约束解码 |
| `tools/smoke_test.py`、`tools/chat_client.py` | 功能验证、交互 |
