# E17 Nsight：SM 用量、kernel 耗时、CPU 提交开销、CUDA graph 捕获时间

本实验回答研究者提出的几个具体问题：

- 什么时候用了多少 SM？
- 用了多少个 kernel，哪些 kernel 占时多少？
- CPU 提交和通信用了多少时间？
- CUDA graph 的准备（捕获）用了多少时间？

## 工具与权限
| 工具 | 回答什么 | 开销 | 权限 |
|---|---|---|---|
| Nsight Systems（nsys） | 全时间线：kernel、CUDA API（CPU 提交）、NCCL、NVTX、内存拷贝；`--cuda-graph-trace=node` 时能看到 graph 内部的每个 kernel | 低 | 时间线不需要特殊权限 |
| nsys GPU metrics（`--gpu-metrics-devices=all`） | 按时间采样 SM 活跃度、SM 占用率、Tensor Core 活跃度、显存带宽、NVLink/PCIe 吞吐 | 低 | 需要 profiling 权限（docs/02） |
| Nsight Compute（ncu） | 单个 kernel 的详细指标：grid/block、每 SM 的 wave 数、实际占用率、SM 吞吐、显存吞吐、瓶颈分析 | 很高（会重放 kernel） | 需要 profiling 权限 |
| DCGM（`dcgmi dmon`） | 整卡的 SM_ACTIVE、SM_OCCUPANCY 时间序列 | 很低 | 需要安装 DCGM |

安装 nsys：`bash scripts/01_install_tools.sh nsys`，或使用系统中已有的 nsys。

## 1. 用 nsys 采集服务（vLLM）
`engine.sh --nsys` 会用 `nsys profile --trace=cuda,nvtx,osrt --cuda-graph-trace=node --capture-range=cudaProfilerApi --capture-range-end=repeat` 包裹引擎命令（vLLM 文档推荐的写法）。采集区间由 `/start_profile` 和 `/stop_profile` 控制，所以要配合 `--profiler-config '{"profiler":"cuda"}'`：

```bash
export PATH=$PWD/runtime/envs/nsight/bin:$PATH
bash scripts/engine.sh start vllm qwen3-8b --name v-nsys --nsys e17-vllm-qwen3 -- --profiler-config '{"profiler":"cuda"}'
bash scripts/wait_ready.sh v-nsys
curl -s -X POST 127.0.0.1:8000/start_profile
bash scripts/bench_serve.sh --tool vllm --exp E17 --label vllm-qwen3-nsys --instance v-nsys --no-monitor -- \
  --dataset-name random --random-input-len 512 --random-output-len 128 --ignore-eos --num-prompts 32 --max-concurrency 16 --seed 1
curl -s -X POST 127.0.0.1:8000/stop_profile
bash scripts/engine.sh stop v-nsys            # 进程退出后，nsys 才会写出 .nsys-rep
ls -la runtime/traces/nsys/
```

SGLang：nsys 的用法相同。采集区间用 `/start_profile` 的 `"activities":["CUDA_PROFILER"]` 触发（SGLang 文档的方法 1）。想看逐层耗时时，加 `--enable-layerwise-nvtx-marker --disable-cuda-graph`（CUDA graph 内的 kernel 不会发出 NVTX 标记）。vLLM 的对应参数是 `--enable-layerwise-nvtx-tracing`，同样不支持 CUDA graph。

## 2. 分析
```bash
PY=runtime/envs/client/bin/python
nsys stats -r cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum,nvtx_sum runtime/traces/nsys/e17-vllm-qwen3*.nsys-rep \
  > runtime/results/E17/nsys-stats.txt
$PY tools/analyze_nsys.py runtime/traces/nsys/e17-vllm-qwen3*.nsys-rep --md runtime/results/E17/nsys-report.md
```

`nsys stats --help-reports` 可以列出当前版本支持的全部报表名。

`analyze_nsys.py` 输出的内容与研究者的问题一一对应：

| 问题 | 报告中的位置 |
|---|---|
| 用了多少个 kernel、哪些占时多少 | 开头的 kernel 总数；“Top kernels”表：次数、总时长、平均耗时、占比、类别 |
| 每个 kernel 用了多少 SM | “Top kernels”的平均 blocks 和估计 SM 列（min(blocks, SM 数)），以及“SM 覆盖”分布 |
| CPU 提交用了多少时间 | “CUDA API”表：`cudaLaunchKernel`、`cuLaunchKernel`、`cudaGraphLaunch` 的次数与总耗时；“启动 API 到 kernel 开始执行”的 p50/p90/p99 |
| 通信用了多少时间 | 类别占比中的“通信”（NCCL 与自定义 all-reduce kernel） |
| GPU 有多少时间在等 | “GPU 忙碌”表：忙碌比例、大气泡数与总时长 |
| 多少时间在 CUDA graph 内执行 | “在 CUDA graph 中执行的 kernel 时间占比” |

## 3. SM 活跃度的时间序列（需要权限）
采集时加 GPU metrics。engine.sh 的 nsys 参数是固定的，所以这一步改为手动执行：

```bash
source lab.env
docker run -d --name lab-v-gpum --gpus all -e CUDA_VISIBLE_DEVICES=0 --ipc=host --network host \
  -v $PWD/runtime/models:/models:ro -v $PWD/runtime/traces:/traces -v $(dirname $(dirname $(readlink -f $(command -v nsys)))):$(dirname $(dirname $(readlink -f $(command -v nsys)))):ro \
  --entrypoint $(readlink -f $(command -v nsys)) "$VLLM_IMAGE" profile --gpu-metrics-devices=all --gpu-metrics-frequency=10000 \
  --trace=cuda,nvtx --cuda-graph-trace=node --delay 120 --duration 60 -o /traces/nsys/e17-gpumetrics \
  vllm serve /models/qwen3-8b --served-model-name qwen3-8b --host 127.0.0.1 --port 8000
```

然后在第 120 秒到第 180 秒之间持续发压测请求。在 nsys GUI 的 GPU Metrics 行中可以看到 SM Active、SM Warp Occupancy、Tensor Active、DRAM Bandwidth 和 NVLink 随时间的变化。用完删除容器：`docker rm -f lab-v-gpum`。

## 4. 单个 kernel 的 SM 用量（ncu，可选，需要权限）
用 SGLang 的单 batch 工具（不经过调度器，适合 ncu）：

```bash
source lab.env
docker run --rm --gpus all -e CUDA_VISIBLE_DEVICES=0 --ipc=host -v $PWD/runtime/models:/models:ro -v $PWD/runtime/traces:/traces \
  --cap-add SYS_ADMIN --entrypoint bash "$SGLANG_IMAGE" -c \
  "which ncu && ncu --target-processes all --kernel-name regex:'gemm|attn|flash' --launch-count 6 \
   --section SpeedOfLight --section Occupancy --section LaunchStats -o /traces/E17-ncu \
   python3 -m sglang.benchmark.one_batch --model-path /models/qwen3-8b --batch-size 16 --input-len 512 --output-len 4 --disable-cuda-graph"
```

如果镜像中没有 ncu，需要在宿主机安装 Nsight Compute，并用与 nsys 相同的方式挂载进容器。LaunchStats 中有 Grid Size、Block Size、Waves Per SM；Occupancy 中有理论与实际占用率。

## 5. CUDA graph 的捕获时间
| 来源 | 方法 |
|---|---|
| 启动日志 | `tools/parse_server_log.py` 输出的 `cuda_graph_capture_s` 与 `cuda_graph_mem_gib` |
| SGLang 捕获阶段 profiling | E12 中的 `--enable-profile-cuda-graph`：每个 batch 大小的捕获 trace、kernel 汇总表、显存快照 |
| nsys 全程采集 | 不用 `--capture-range`，直接采集整个启动过程（`--duration` 设为启动所需时间）。时间线上捕获阶段是密集的 `cudaStreamBeginCapture` / `EndCapture` 与 `cudaGraphInstantiate` 调用，在 CUDA API 表中统计它们的耗时 |

## 6. 对比实验
| 对比 | 预期 |
|---|---|
| eager 与 CUDA graph（Qwen3-8B，并发 1） | eager 的 `cudaLaunchKernel` 次数与每步 kernel 数相当，GPU 忙碌比例低（CPU-bound）；graph 模式下只有少量 `cudaGraphLaunch`，忙碌比例上升 |
| SGLang 重叠调度开 / 关（`--disable-overlap-schedule`） | 关闭后，相邻两步之间出现 CPU 调度造成的 GPU 空隙 |
| GLM-4.7-Flash TP2：MoE kernel | 专家 GEMM 的 grid 很小，SM 覆盖低（每个专家分到的 token 少） |

## 研究启发
- **SM 覆盖不足**是 decode 阶段的普遍现象，可以引出多种研究方向：
  - 让预填充与解码在 SM 层面共享一张卡（SGLang `--enable-pdmux`、Nanoflow）
  - 多模型复用一张卡（MuxServe）
  - 持久化 kernel 或 megakernel（例如 vLLM recipe 中 MI355X 的 `--monokernel`，把 decode 一层压到两次持久化 launch）
- **CPU 开销**：投机解码、结构化输出、复杂采样都会增加 CPU 端工作，CUDA graph 也覆盖不到这些部分。

## 本机实测记录
