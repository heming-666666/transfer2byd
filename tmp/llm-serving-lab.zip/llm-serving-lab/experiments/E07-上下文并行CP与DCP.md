# E07 上下文并行：PCP（预填充）与 DCP（解码）

## 要理解的概念（vLLM 文档 serving/context_parallel_deployment.md）
- **预填充上下文并行（PCP）**：把一个长请求的 token 切成 N 段，分给 N 张卡同时计算。
  - 中等长度时用“部分 Q、完整 KV”：先 all-gather KV，每张卡只算自己那段 Q 的 attention。
  - 超长时用“部分 Q、部分 KV”，即 ring attention（2310.01889）。
  - 目标是降低长输入的 TTFT。
- **解码上下文并行（DCP）**：TP 很大时，如果 KV 头数 H 小于 TP，KV cache 会被重复存储 TP/H 份。DCP 沿序列维度（T）切分 KV，消除重复，换来更多 KV 容量。
  - MLA 模型只有 1 个 KV 潜变量头，TP8 时重复 8 份，所以 DCP 收益最大。
  - DCP 规模的范围是 `[1, TP/H]`，不需要额外的卡。
  - KV 按交错方式存储（参考 Helix Parallelism，2507.07120）。
- **SGLang 的写法**：
  - 预填充 CP：`--attn-cp-size N --enable-prefill-cp --cp-strategy interleave`。GLM-5.3-Flash 在 DSA 层上用交错 CP，KDA 层用按头的 TP。
  - 解码 CP：`--dcp-size`。

## 设计
| 对比 | 配置 | 观察 |
|---|---|---|
| A. DCP 与 KV 容量 | GLM-4.7-Flash（MLA）TP2：`-dcp 1` / `-dcp 2`；GLM-5.3-Flash TP8：DCP 1 / 2 / 4 / 8 | 启动日志中的 KV token 数、`WL_THR` 吞吐、`WL_DEC` TPOT |
| B. PCP 与长输入 TTFT | GLM-4.7-Flash 4 卡：TP4 / TP2 + PCP2（vLLM `--prefill-context-parallel-size 2`） | `WL_PRE_32K` 的 TTFT |
| C. SGLang 预填充 CP | GLM-5.3-Flash：`--attn-cp-size 8 --enable-prefill-cp --cp-strategy interleave --moe-dense-tp-size 8 --ep-size 8`（cookbook 只给了 Blackwell 的命令，H800 上属于探索） | 能否启动；32K/128K 输入的 TTFT |

## 步骤
### A（vLLM，GLM-5.3-Flash）
```bash
source experiments/workloads.sh; PY=runtime/envs/client/bin/python
for d in 1 2 4 8; do
  bash scripts/engine.sh start vllm glm53-flash --name v-glm53-dcp$d -- --decode-context-parallel-size $d
  bash scripts/wait_ready.sh v-glm53-dcp$d 5400
  $PY tools/parse_server_log.py runtime/logs/engines/v-glm53-dcp$d.latest.log | grep -E "kv_cache|concurrency"
  bash scripts/bench_serve.sh --tool vllm --exp E07 --label glm53-dcp$d-thr --instance v-glm53-dcp$d -- \
    --dataset-name random --random-input-len 16384 --random-output-len 512 --ignore-eos --num-prompts 128 --max-concurrency 64 --seed 1
  bash scripts/engine.sh stop v-glm53-dcp$d
done
```

### B（vLLM PCP，GLM-4.7-Flash）
```bash
bash scripts/engine.sh start vllm glm47-flash --gpus 0,1,2,3 --name v-glm47-pcp2 -- --tensor-parallel-size 2 --prefill-context-parallel-size 2 --max-model-len 131072
bash scripts/wait_ready.sh v-glm47-pcp2
bash scripts/bench_serve.sh --tool vllm --exp E07 --label glm47-tp2pcp2-pre32k --instance v-glm47-pcp2 -- "${WL_PRE_32K[@]}"
```

对照组：`--tensor-parallel-size 4 --max-model-len 131072`，同样跑 `WL_PRE_32K`。

注意：PCP 会增加进程总数（world size = TP × PCP），但不会增加 KV 的分片数（vLLM 配置说明）。某些 attention 后端不支持 PCP 或 DCP，报错时记录错误信息。

## 分析
1. DCP 增大时，KV token 数应接近线性增长（重复被消除）。吞吐在高并发长上下文下提升，但每步多了 DCP 通信，单请求的 TPOT 可能变差。
2. PCP 在什么输入长度以上开始有收益？与 TP4 相比，短输入时可能更慢（多了 KV 的 all-gather）。
3. KDA 线性注意力的层不受上下文长度影响。GLM-5.3-Flash 的 KV 主要来自 11 层稀疏 MLA，所以它的 KV 增长比纯 MLA 模型慢得多。可以和 E23 一起分析。

## 研究启发
- 长上下文推理中，PCP、DCP 与 PD 分离如何组合？例如预填充节点用 PCP，解码节点用 DCP。
- KV 按序列切分后，前缀缓存怎样跨卡复用？
- 相关工作：LoongServe（2404.09526，弹性序列并行）、Helix（2507.07120）、Ring Attention（2310.01889）、DeepSpeed-Ulysses（2309.14509）。

## 本机实测记录
