# E11 attention 后端对比

## 要理解的概念
- **同一个 attention 数学，有多种 kernel 实现**：FlashAttention 2/3（2307.08691、2407.08608）、FlashInfer（2501.01005）、Triton、FlexAttention 等。
- **Hopper 上 FA3 和 FlashInfer 的特点**：都使用 wgmma 与 TMA，并做了 warp 特化。prefill 和 decode 的最优 kernel 往往不同。
- **MLA 与稀疏注意力有专用 kernel**：FlashMLA、TileLang 稀疏 MLA、TRT-LLM 稀疏 MLA 等。
- **两个框架的选项**：
  - **vLLM**：`--attention-backend`。v0.32.0 中 Hopper 可用的有 `FLASH_ATTN`、`FLASHINFER`、`TRITON_ATTN`、`FLEX_ATTENTION`；MLA 有 `FLASHMLA`、`TRITON_MLA`、`FLASH_ATTN_MLA`、`CUTLASS_MLA` 等。名称取自 `vllm/v1/attention/backends/registry.py`，是否支持当前模型以启动日志为准。
  - **SGLang**：`--attention-backend fa3|flashinfer|triton|flex_attention|flashmla|...`，并可用 `--prefill-attention-backend` 与 `--decode-attention-backend` 分别指定。DSA 模型用 `--dsa-prefill-backend` 和 `--dsa-decode-backend`。

## 设计
| 模型 | 框架 | 对比 |
|---|---|---|
| Qwen3-8B | vLLM | `FLASH_ATTN` / `FLASHINFER` / `TRITON_ATTN` / `FLEX_ATTENTION` |
| Qwen3-8B | SGLang | `fa3` / `flashinfer` / `triton` |
| GLM-5.3-Flash | SGLang | `--dsa-prefill-backend tilelang`（默认）/ `flashmla_sparse_q8`（cookbook：H200 上仅含预填充的请求快 5.8–12.1%） |
| GLM-4.7-Flash | SGLang | `triton`（cookbook 推荐）/ `flashinfer` / `fa3`（MLA 支持情况以日志为准） |

负载：`WL_PRE_8K`（预填充 kernel）、`WL_DEC`（解码 kernel）、`WL_THR`。

## 步骤
```bash
source experiments/workloads.sh
for be in FLASH_ATTN FLASHINFER TRITON_ATTN FLEX_ATTENTION; do
  bash scripts/engine.sh start vllm qwen3-8b --name v-attn-$be -- --attention-backend $be
  if bash scripts/wait_ready.sh v-attn-$be 1800; then
    grep -iE "attention backend|Using .*backend" runtime/logs/engines/v-attn-$be.latest.log | head -3
    for wl in PRE_8K DEC THR; do arr="WL_${wl}[@]"; bash scripts/bench_serve.sh --tool vllm --exp E11 --label qwen3-$be-${wl,,} --instance v-attn-$be -- "${!arr}"; done
  fi
  bash scripts/engine.sh stop v-attn-$be
done
```

GLM-5.3-Flash（SGLang）：

```bash
bash scripts/engine.sh start sglang glm53-flash --name s-glm53-q8pre -- --dsa-prefill-backend flashmla_sparse_q8
```

对照组是默认 profile。对比 `WL_PRE_32K` 的 TTFT，再用 GSM8K 子集确认精度。

## 分析
1. 分别列出 prefill（TTFT）和 decode（TPOT）的排名。两者的最优后端可能不同。
2. 用 E16 的 trace 找出各后端的 attention kernel 名字和单次耗时，与端到端结果对照。
3. CUDA graph 的兼容性：有些后端不支持 FULL graph，会自动退回 PIECEWISE（日志中有提示），这也会影响 TPOT。

## 研究启发
- 稀疏注意力（DSA、DeepSeek 两级 indexer）的 indexer 本身就有不小的开销。“选 token 的成本”与“省下的 attention 成本”如何平衡？相关工作：NSA（2502.11089）、Quest（2406.10774）、MInference（2407.02490）。

## 本机实测记录
