# 实验记录：<编号> <标题> — <标签>

> 复制到结果目录，命名为 notes.md：`cp experiments/TEMPLATE-实验记录.md runtime/results/<编号>/<时间>-<标签>/notes.md`

## 1. 目的
一句话：要验证什么假设或回答什么问题。

## 2. 配置
- 框架 / 镜像：（见 env/image.txt、env/packages.txt）
- 模型 / revision：
- GPU：
- 启动命令（原样复制 `runtime/logs/engines/<实例>.latest.log` 开头的 `# CMD:` 行）：
- 被测变量与取值：
- 固定不变的条件：

## 3. 负载
- 压测命令（原样复制 bench_cmd.txt）：
- 每个配置重复次数：

## 4. 结果
| 配置 | 吞吐 | TTFT P50/P99 | TPOT P50/P99 | 其他指标 |
|---|---|---|---|---|

（`tools/collect_bench.py` 的表格可以直接粘贴到这里）

## 5. 观察
- 与理论预期一致的地方：
- 与预期不一致 / 意外的地方：
- 异常（报错、OOM、波动大）：

## 6. 结论
- 数据支持的结论（要附上数据）：
- 还不能下结论、需要补的实验：

## 7. 研究启发
这个现象是否指向一个没有被很好解决的问题？对应 `research/从实验到研究问题.md` 中的哪一条？
