# E14 PD 分离与 KV 传输

## 要理解的概念
- **预填充与解码的特性截然不同**：预填充受计算限制，解码受带宽限制。放在同一组 GPU 上时，长预填充会打断解码，TPOT 出现尖刺；分块预填充只能缓解（E21）。
- **PD 分离**（DistServe 2401.09670、Splitwise 2311.18677、Mooncake 2407.00079）：
  - 预填充实例算完提示后，把 KV 传给解码实例；
  - 两边可以独立选择并行方式和规模；
  - 目标是在给定 SLO 下最大化 goodput（E20）。
- **KV 传输**：
  - vLLM 用 NixlConnector：预填充端是 `kv_producer`，解码端是 `kv_consumer`，底层默认走 UCX。
  - SGLang 支持 Mooncake、NIXL 等传输后端；单机实验默认用 NIXL。
  - 前端路由器负责把请求先发给预填充端、再发给解码端，并转发 KV 的元数据。
- **本机的限制**：GLM-5.3-Flash 和 DeepSeek 在 8×80GB 上都只能放一份，放不下两个池。所以用 Qwen3-8B（1P1D）和 GLM-4.7-Flash（2+2 卡）做实验。

## 设计
| 对比 | 配置（GPU 总数相同） |
|---|---|
| A. Qwen3-8B 2 卡 | 共置：DP2（两个独立实例 + 路由器）/ 分离：1P1D（GPU0 预填充、GPU1 解码） |
| B. GLM-4.7-Flash 4 卡 | 共置：TP2×DP2 / 分离：TP2 预填充 + TP2 解码 |
| C. 传输路径 | 1P1D 下，UCX 走 `cuda_ipc`（默认，NVLink）与强制走 TCP（`UCX_TLS=tcp`），对比 KV 传输耗时与带宽 |
| 负载 | 混合长短：`--random-input-len 4096 --random-output-len 256`，加 `--request-rate` 2/4/8/16（泊松到达），并加 `--goodput ttft:2000 tpot:50` |

## 步骤（A，vLLM）
```bash
bash scripts/01_install_tools.sh router
# 分离：两个角色 + 路由器
bash scripts/engine.sh start vllm qwen3-8b-pd-prefill
bash scripts/engine.sh start vllm qwen3-8b-pd-decode
bash scripts/wait_ready.sh vllm-qwen3-8b-pd-prefill && bash scripts/wait_ready.sh vllm-qwen3-8b-pd-decode
bash scripts/router.sh start vllm-pd --port 8100 --prefill http://127.0.0.1:8001 --decode http://127.0.0.1:8002
for r in 2 4 8 16; do
  bash scripts/bench_serve.sh --tool vllm --exp E14 --label qwen3-pd-rate$r --instance vllm-qwen3-8b-pd-decode --base-url http://127.0.0.1:8100 -- \
    --dataset-name random --random-input-len 4096 --random-output-len 256 --ignore-eos --num-prompts $((r*60)) --request-rate $r --seed 1 \
    --goodput ttft:2000 tpot:50
done
grep -h "KV Transfer metrics" runtime/logs/engines/vllm-qwen3-8b-pd-*.latest.log | tail -5   # 传输耗时、带宽
bash scripts/router.sh stop; bash scripts/engine.sh stop vllm-qwen3-8b-pd-prefill; bash scripts/engine.sh stop vllm-qwen3-8b-pd-decode
```

共置对照组：在 GPU0、GPU1 上各起一个 `qwen3-8b` 实例（`--gpus 0 --port 8001 --name v-c0`、`--gpus 1 --port 8002 --name v-c1`），用 `router.sh start vllm-dp --workers ...` 组成 DP2，跑同样的负载。

SGLang：使用 profile `qwen3-8b-pd-prefill/decode`（端口 31000 和 32000，bootstrap 端口 8998），路由器用 `bash scripts/router.sh start sglang-pd --port 8100 --prefill http://127.0.0.1:31000 --bootstrap 8998 --decode http://127.0.0.1:32000`。

**C**：给两个角色都加 `--env UCX_TLS=tcp,self`（vLLM），重新跑 rate=8，比较日志中的 `Avg xfer time (ms)` 和 `Throughput (MB/s)`。

## 分析
1. **低负载**：分离多了一次 KV 传输，TTFT 可能略差；TPOT 应更平稳。
2. **高负载**：共置时，长预填充会打断解码，TPOT 的 P99 恶化；分离时 TPOT 稳定，但预填充端可能成为瓶颈，TTFT 上升。比较两者满足 SLO 的最大请求率（goodput）。
3. **KV 传输**：每个请求的 KV 字节数 ≈ 层数 × KV 头数 × 头维度 × 2 × 输入长度 × 2 字节（Qwen3-8B：36 层、8 个 KV 头、头维度 128）。用这个数除以传输时间得到有效带宽，与 NVLink 和 TCP 对比。
4. **P:D 比例**：1:1 不一定最优。负载以长输入为主时需要更多预填充；以长输出为主时需要更多解码。

## 研究启发
- 小集群上的 PD：卡少时静态划分 P/D 很难最优，可以研究动态角色切换（SGLang 有 `/pd_role_switch` 端点）。
- KV 传输与计算重叠，例如逐层传输。
- 研究者主线 OPD 中，“学生 rollout（解码密集）+ 教师打分（预填充密集）”本质上是一个跨模型的 PD 问题。

## 本机实测记录
