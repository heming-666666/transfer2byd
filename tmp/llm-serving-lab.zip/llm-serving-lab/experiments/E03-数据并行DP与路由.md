# E03 数据并行（DP）与请求路由

## 要理解的概念
- **DP**：多个完整副本，各自处理不同的请求。吞吐理论上线性增长，延迟不变。
- **两种组织方式**：
  - **引擎内 DP**：vLLM 的 `--data-parallel-size`、SGLang 的 `--dp-size`。一个 API 入口，内部负载均衡。
  - **多实例 + 外部路由器**：vllm-router、sglang-router，可以按前缀缓存亲和性路由。
- **MoE 模型的 DP**：即使某个 rank 没有请求，也要做“空跑”，保持专家层的集合通信同步（vLLM DP 文档）。
- **`--max-num-seqs` 的口径**：在 vLLM DP 中，这个值按每个 DP rank 计算。

## 设计
| 对比 | 配置 |
|---|---|
| A. 线性度 | Qwen3-8B：DP1、2、4、8（每个副本 1 卡），负载 `WL_THR` |
| B. 引擎内 DP 与多实例路由 | Qwen3-8B 4 卡：`--data-parallel-size 4`，对比 4 个独立实例 + 路由器 |
| C. 路由策略 | 4 个独立实例，`round_robin` 对比 `cache_aware`（sglang-router）或 `consistent_hash`（vllm-router），负载 `WL_PREFIX` |
| D. MoE 的 DP | GLM-4.7-Flash：TP2×DP2 对比 TP4（4 卡） |

## 步骤
### A/B：引擎内 DP（vLLM）
```bash
source experiments/workloads.sh
for dp in 1 2 4 8; do
  gpus=$(seq -s, 0 $((dp-1)))
  bash scripts/engine.sh start vllm qwen3-8b --gpus $gpus --name v-dp$dp -- --data-parallel-size $dp
  bash scripts/wait_ready.sh v-dp$dp
  bash scripts/bench_serve.sh --tool vllm --exp E03 --label vllm-dp$dp-thr --instance v-dp$dp -- "${WL_THR[@]}" --max-concurrency $((64*dp)) --num-prompts $((512*dp))
  bash scripts/engine.sh stop v-dp$dp
done
```

SGLang：`bash scripts/engine.sh start sglang qwen3-8b --gpus 0,1,2,3 --name s-dp4 -- --dp-size 4`

### C：多实例 + 路由器
```bash
bash scripts/01_install_tools.sh router
for i in 0 1 2 3; do
  bash scripts/engine.sh start sglang qwen3-8b --gpus $i --port $((30001+i)) --name s-w$i -- --nccl-port $((29500+i))
done
for i in 0 1 2 3; do bash scripts/wait_ready.sh s-w$i; done
for pol in round_robin cache_aware; do
  bash scripts/router.sh start sglang-dp --port 8100 --policy $pol --workers http://127.0.0.1:30001 http://127.0.0.1:30002 http://127.0.0.1:30003 http://127.0.0.1:30004
  sleep 5
  for i in 0 1 2 3; do curl -s -X POST 127.0.0.1:$((30001+i))/flush_cache; done   # 清空前缀缓存，保证起点一致
  bash scripts/bench_serve.sh --tool vllm --exp E03 --label route-$pol --instance s-w0 --base-url http://127.0.0.1:8100 -- "${WL_PREFIX[@]}"
  bash scripts/router.sh stop
done
```

`--instance s-w0` 只用来读取模型名和 tokenizer，请求实际发往路由器。每次运行后，用各实例的 `/metrics` 中的 `sglang:cache_hit_rate` 看命中率。

## 分析
- **A**：吞吐是否线性增长？瓶颈在 API 进程还是 GPU？vLLM 可用 `--api-server-count` 扩展 API 进程。
- **B**：两种方式的吞吐与尾延迟差异。
- **C**：缓存感知路由的命中率，以及它对 TTFT 的影响（命中时预填充被跳过）。
- **D**：MoE 模型用 DP 还是 TP 更好，取决于并发度。

## 研究启发
- 缓存感知路由要在负载均衡和缓存命中之间取舍。相关工作有 Preble、SGLang router 的 cache-aware 策略。是否可以把“前缀热度预测”加进去？
- Llumnix（2406.03243）：在多个实例之间做请求迁移。

## 本机实测记录
