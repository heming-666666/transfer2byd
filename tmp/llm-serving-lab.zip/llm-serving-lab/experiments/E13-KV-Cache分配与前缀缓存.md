# E13 KV cache 分配、前缀缓存与 KV 卸载

## 要理解的概念
- **分页 KV（PagedAttention，2309.06180）**：KV 按固定大小的块分配，消除外部碎片；块表把逻辑位置映射到物理块。块大小用 `--block-size` 设置（vLLM）或 `--page-size`（SGLang）。
- **KV 池的大小怎么定**：
  - vLLM：启动时先用最大 batch 做一次 profiling，得到激活峰值，然后 `gpu_memory_utilization × 总显存 − 权重 − 激活峰值 − CUDA graph = KV 池`。日志中的 “Available KV cache memory” 和 “GPU KV cache size” 就是这个结果。
  - SGLang：`mem_fraction_static × 总显存 − 权重 = KV 池`。
- **前缀缓存**：
  - vLLM：按块哈希复用。
  - SGLang：RadixAttention（2312.07104），用基数树组织前缀。
  - 命中的部分跳过预填充。
- **抢占（preemption）**：KV 不够时，把某些请求的 KV 释放掉，之后重算；或者换出到 CPU。vLLM 的指标 `vllm:request_num_preemptions` 记录抢占次数。
- **KV 卸载 / 分层缓存**：
  - vLLM：`--kv-offloading-backend native|lmcache --kv-offloading-size <GiB>`
  - SGLang：HiCache，`--enable-hierarchical-cache --hicache-ratio 2`，主机内存作为二级缓存
- **混合模型（GLM-5.3-Flash）**：
  - 同时有分页 KV 池（稀疏 MLA 层）和 KDA 状态池（每个请求一份固定大小的递归状态）。
  - vLLM 用混合 KV 管理器；SGLang 用 `--mamba-full-memory-ratio` 和 `--max-mamba-cache-size` 分配两个池（见 sglang/docs/22）。
  - 前缀缓存要额外保存 KDA 状态的检查点（vLLM `--enable-mamba-shared-prefix-checkpoint`）。

## 设计
| 对比 | 配置 | 观察 |
|---|---|---|
| A. 显存比例与 KV 容量 | Qwen3-8B vLLM：`--gpu-memory-utilization 0.7 / 0.8 / 0.9 / 0.95` | KV token 数、最大并发、`WL_THR` 吞吐、抢占次数 |
| B. 块大小 | Qwen3-8B vLLM：`--block-size 16 / 32 / 64` | 吞吐、前缀命中粒度 |
| C. 前缀缓存 | Qwen3-8B：开 / 关（vLLM `--no-enable-prefix-caching`，SGLang `--disable-radix-cache`），负载 `WL_PREFIX` | 命中率、TTFT |
| D. 调度策略与命中率 | SGLang：`--schedule-policy fcfs` / `lpm`（最长前缀优先） | 命中率、尾延迟 |
| E. KV 卸载 | Qwen3-8B 把 `--gpu-memory-utilization` 压到 0.5（故意让 GPU 的 KV 不够），对比开 / 关卸载（vLLM `--kv-offloading-backend native --kv-offloading-size 32`；SGLang `--enable-hierarchical-cache --hicache-ratio 2`），负载为多轮复用的 `WL_PREFIX` | 命中率、TTFT、PCIe 流量（gpu.csv） |
| F. 混合模型的两个池 | GLM-5.3-Flash SGLang：`--mamba-full-memory-ratio 0.5 / 0.7 / 0.9` | 日志中两个池的大小、`max_running_requests`、高并发吞吐 |

## 步骤（举例：A 与 C）
```bash
source experiments/workloads.sh; PY=runtime/envs/client/bin/python
for u in 0.7 0.8 0.9 0.95; do
  bash scripts/engine.sh start vllm qwen3-8b --name v-mem$u -- --gpu-memory-utilization $u
  bash scripts/wait_ready.sh v-mem$u
  $PY tools/parse_server_log.py runtime/logs/engines/v-mem$u.latest.log | grep -E "kv_cache|concurrency"
  bash scripts/bench_serve.sh --tool vllm --exp E13 --label qwen3-mem$u-thr --instance v-mem$u -- "${WL_THR[@]}" --max-concurrency 256 --num-prompts 1024
  grep -E "前缀|抢占" runtime/results/E13/*-qwen3-mem$u-thr/metrics-diff.txt
  bash scripts/engine.sh stop v-mem$u
done
for pc in on off; do
  args=(); [[ $pc == off ]] && args=(--no-enable-prefix-caching)
  bash scripts/engine.sh start vllm qwen3-8b --name v-pc-$pc -- "${args[@]}"
  bash scripts/wait_ready.sh v-pc-$pc
  bash scripts/bench_serve.sh --tool vllm --exp E13 --label qwen3-prefix-$pc --instance v-pc-$pc -- "${WL_PREFIX[@]}"
  bash scripts/engine.sh stop v-pc-$pc
done
```

## 分析
1. **A**：KV token 数与显存比例的关系。显存比例过高时，可能在峰值负载下 OOM。
2. **C**：命中率与 TTFT 的关系。共享前缀 2048 token 时，命中能省下多少预填充时间？
3. **E**：卸载命中带来的收益与 PCIe 搬运成本。H800 通过 PCIe Gen5 连接主机，带宽约 64 GB/s 单向，远低于 HBM。
4. **F**：两个池的最优比例取决于平均请求长度。长请求需要更多 KV，短请求多的场景需要更多 KDA 状态槽位。

## 研究启发
- **混合注意力模型的缓存管理**是新问题：KDA 状态不能像 KV 那样按块共享前缀，只能存检查点。已经有专门的论文：Validating Hybrid-State Cache Recovery for GLM-5.3-Flash with vLLM and LMCache（2609.15030）。
- KV 卸载到 SSD 的可预测性：2610.21249。
- KV 放在哪一层存储、何时预取：Mooncake（2407.00079）、LMCache（2510.09665）。

## 本机实测记录
