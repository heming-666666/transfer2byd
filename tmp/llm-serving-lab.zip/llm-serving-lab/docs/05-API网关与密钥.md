# 05 API 网关与密钥（功能 1）

目标：同网段的其他机器像调用 OpenAI 一样调用本机模型，必须带 API key；引擎的管理接口不对外暴露。

## 1. 架构

```text
同网段客户端 ──HTTP──> nginx 网关 (0.0.0.0:9080, 容器 lab-gateway)
                         │ 校验 Authorization: Bearer <key>（keys.map）
                         │ 只放行 /v1/*、/vllm/v1/*、/sglang/v1/*，其余路径返回 404
                         ├──> /v1/*        -> 默认引擎（lab.env 中的 GATEWAY_DEFAULT_UPSTREAM）
                         ├──> /vllm/v1/*   -> vLLM   127.0.0.1:8000
                         └──> /sglang/v1/* -> SGLang 127.0.0.1:30000
```

**为什么不直接用引擎的 `--api-key`**：vLLM 安全文档写明，`--api-key` 只保护 `/v1`、`/v2`、`/inference`、`/cohere` 前缀。下面这些端点仍然不需要鉴权：

- `/metrics`
- `/pause`、`/abort_requests`（可造成拒绝服务）
- `/update_weights`（可改变模型行为）
- `/invocations`（与 `/v1` 等价的推理入口）
- `/tokenize` 等

因此引擎只监听 `127.0.0.1`，由网关统一鉴权并只暴露推理路径。网关同时记录 JSON 访问日志，日志中只有 key 的名字。

## 2. 创建 key、启动网关

```bash
bash scripts/apikey.sh add alice          # 打印一次完整 key，请转交使用者
bash scripts/apikey.sh add benchmark      # 给压测或评测用的 key
bash scripts/apikey.sh list
bash scripts/gateway.sh up
bash scripts/gateway.sh test              # 期望：无 key 401、/metrics 404、有 key 200（引擎未启动时为 502）
```

- **增删 key**：`apikey.sh add/revoke`，网关会自动热加载，无需重启。
- **切换默认引擎**：改 `lab.env` 中的 `GATEWAY_DEFAULT_UPSTREAM`，然后执行 `bash scripts/gateway.sh reload`。
- **访问日志**：`runtime/logs/gateway/access.log`，每行一个 JSON，字段包括 time、key（名字）、uri、status、req_time_s、upstream_time_s。

## 3. 从其他机器调用

先在本机确认 IP（`00_check_machine.sh` 报告的“网络”一节），假设为 `10.0.0.5`。

```bash
# curl
curl http://10.0.0.5:9080/v1/models -H "Authorization: Bearer sk-lab-..."
curl http://10.0.0.5:9080/v1/chat/completions \
  -H "Authorization: Bearer sk-lab-..." -H "Content-Type: application/json" \
  -d '{"model":"glm-5.3-flash","messages":[{"role":"user","content":"你好，介绍一下你自己"}],
       "max_tokens":2048,"chat_template_kwargs":{"reasoning_effort":"low"}}'
```

```python
# Python（openai 库）
from openai import OpenAI
c = OpenAI(base_url="http://10.0.0.5:9080/v1", api_key="sk-lab-...")
r = c.chat.completions.create(model="glm-5.3-flash",
        messages=[{"role": "user", "content": "用一句话解释稀疏注意力"}],
        max_tokens=2048, extra_body={"chat_template_kwargs": {"reasoning_effort": "low"}})
print(r.choices[0].message.content)
```

指定框架：把 `base_url` 换成 `http://10.0.0.5:9080/vllm/v1` 或 `http://10.0.0.5:9080/sglang/v1`。

## 4. 各模型的思考模式开关

不同模型和框架的写法不同，以下来自官方 recipe 和 cookbook。

| 模型 | vLLM | SGLang |
|---|---|---|
| Qwen3-8B | `chat_template_kwargs: {"enable_thinking": false}` 关闭思考 | 同左 |
| GLM-4.7-Flash | 默认开启思考；关闭方式以模型目录 `chat_template.jinja` 中的变量为准（见下方 grep） | 同左 |
| GLM-5.3-Flash | 始终思考，强度用 `chat_template_kwargs: {"reasoning_effort": "low"\|"high"\|"max"}` 或顶层 `reasoning_effort` 控制，默认 `max` | `chat_template_kwargs: {"thinking": false}` 关闭思考 |
| DeepSeek-V4.1-Flash | 默认开启思考、强度 50。`chat_template_kwargs: {"thinking": false}` 关闭；`reasoning_effort` 可取 `low`(25) / `high`(50) / `xhigh`(75) / `max`(100) 或 1–100 的整数；顶层 `reasoning_effort: "none"` 也能关闭 | **默认关闭思考**；传 `reasoning_effort`（`low` / `high` / `xhigh` / `max`）会自动打开 |

确认模板变量的方法：

```bash
grep -oE "enable_thinking|clear_thinking|reasoning_effort|thinking" runtime/models/glm-4.7-flash/chat_template.jinja | sort | uniq -c
```

**常见坑**：思考模型在 `max_tokens` 较小时，可能全部预算都花在思考上，返回空的 `content` 和 `finish_reason=length`。这不是故障：调大 `max_tokens` 或关闭思考即可。

## 5. 防火墙与暴露范围

网关监听 `0.0.0.0:9080`。如果只允许某个网段访问，请研究者或管理员在主机防火墙上限制；agent 不要修改防火墙。

## 6. 没有 docker 时的替代方案

使用引擎自带的 key，并让引擎监听所有地址。保护范围小于网关，只适合可信内网。

```bash
sed -i 's/^ENGINE_HOST=.*/ENGINE_HOST="0.0.0.0"/' lab.env
KEY=$(awk -F'\t' 'NR==1{print $2}' runtime/secrets/api_keys.tsv)
bash scripts/engine.sh start vllm qwen3-8b -- --api-key "$KEY"
bash scripts/engine.sh start sglang qwen3-8b -- --api-key "$KEY" --admin-api-key "$KEY"
```

SGLang 的 `--admin-api-key` 用于保护管理端点。vLLM 的未鉴权端点见第 1 节，不要把这种部署暴露到不可信网络。

## 本机实测记录
