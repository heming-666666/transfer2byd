# llm-serving-lab：8×H800 上部署与研究 DeepSeek-V4.1-Flash / GLM-5.3-Flash

本实验包用于在一台 8×H800 的机器上，分别用 **vLLM** 和 **SGLang** 部署两个开源大模型，并做一系列帮助理解推理系统的实验。最终目的是为后续科研积累实测数据，找到研究问题。

- **功能 1**：部署一个对同网段开放、需要 API key 的 OpenAI 兼容服务。支持对话、流式输出、思考模式、工具调用、JSON 格式输出和图片输入。
- **功能 2**：23 个实验，覆盖 TP/DP/PP/EP/CP/SP、量化、专家激活、attention 后端、CUDA graph、PD 分离与 KV 传输、通信与 NVLink、KV cache 分配、投机解码、约束解码、goodput/SLO、profiling（PyTorch Profiler、Perfetto、Nsight Systems：SM、kernel、CPU 提交开销、CUDA graph 捕获时间）以及模型能力评测。
- **功能 3**：经过核实的论文清单，以及从每个实验引出的研究问题。

> **编写说明（2026-10-31）**：所有版本号、启动参数和模型配置，都对照了官方 recipe/cookbook、发布说明以及 vLLM v0.32.0 和 SGLang v0.5.23 的源码与文档。编写环境没有 GPU，**所有命令都没有在真实硬件上运行过**；脚本只做了语法检查，纯 Python 分析工具用合成数据测试过。凡是官方未在 80GB 级 Hopper 上验证的配置，都标注了“实验性”。第一次在本机跑通后，请按 `AGENTS.md` 的规则记录结果，并更新对应文档。

## 1. 目录结构

```text
llm-serving-lab/
├── README.md                本文件：总入口、阅读顺序、快速开始
├── AGENTS.md / CLAUDE.md    给机器上 AI agent 的工作规则与任务协议
├── lab.env.example          全局配置模板（复制为 lab.env 后修改）
├── docs/                    通用步骤，按编号顺序执行
│   ├── 00-总览与学习路线.md
│   ├── 01-目录与存放约定.md      ← 模型权重、会话记录、日志、结果分别放在哪
│   ├── 02-机器检查.md
│   ├── 03-基础环境安装.md
│   ├── 04-模型下载与校验.md
│   ├── 05-API网关与密钥.md       ← 功能 1：同网段调用、API key
│   ├── 06-客户端与会话记录.md
│   ├── 07-监控指标与日志.md
│   └── 99-故障排查.md
├── vllm/                    vLLM 专用：docs/10–14 部署文档、profiles/ 启动配置
├── sglang/                  SGLang 专用：docs/20–24 部署文档、profiles/ 启动配置
├── experiments/             功能 2：E01–E23 实验文档、记录模板、索引
├── research/                功能 3：论文清单、从实验到研究问题
├── scripts/                 Bash 脚本（初始化、检查、安装、下载、引擎启停、网关、压测、监控）
├── tools/                   Python 工具（客户端、冒烟测试、trace/nsys 分析、通信基准、结果汇总）
├── configs/                 nginx 网关模板、四个模型的固定版本清单（含文件大小与 SHA-256）
└── runtime/                 运行时自动生成（不随包分发）：环境、模型、缓存、日志、结果、trace、会话、密钥
```

`runtime/` 的详细结构见 `docs/01-目录与存放约定.md`。所有环境和产物都放在 `runtime/` 下。模型约 917 GB，可以在 `lab.env` 中把 `MODELS_DIR` 指到大盘。

## 2. 阅读与执行顺序

| 顺序 | 文档 | 产出 |
|---|---|---|
| 1 | `docs/00`、`docs/01` | 了解整体路线和文件放在哪里 |
| 2 | `docs/02` | 机器检查报告（驱动、显存、NVLink、内存、磁盘、Docker） |
| 3 | `docs/03` | 工具和镜像就绪 |
| 4 | `docs/04` | 模型下载并校验通过（先下 Qwen3-8B） |
| 5 | `vllm/docs/10` → `11` | vLLM 跑通小模型 |
| 6 | `docs/05`、`docs/06` | 网关与 API key、客户端与会话记录（功能 1 完成） |
| 7 | `vllm/docs/12`、`13` | 部署 GLM-5.3-Flash、DeepSeek-V4.1-Flash |
| 8 | `sglang/docs/20`–`23` | 在 SGLang 上做同样的部署 |
| 9 | `vllm/docs/14`、`sglang/docs/24` | 两个框架的对外服务与对比 |
| 10 | `docs/07` | 监控指标与日志 |
| 11 | `experiments/README.md` → E01…E23 | 按推荐顺序做实验（功能 2） |
| 12 | `research/` | 读论文，整理研究问题（功能 3） |

## 3. 快速开始（最短路径：Qwen3-8B on vLLM + 网关）

```bash
cd /path/to/llm-serving-lab
bash scripts/init_lab.sh                      # 生成 lab.env 和 runtime/ 目录
bash scripts/00_check_machine.sh              # 只读检查，报告在 runtime/logs/machine/
bash scripts/01_install_tools.sh              # uv + client 环境（runtime/envs/client）
bash scripts/02_pull_images.sh                # vLLM / SGLang / nginx 镜像，并测试 GPU 容器
bash scripts/03_download_models.sh qwen3-8b   # 16 GB
bash scripts/engine.sh start vllm qwen3-8b
bash scripts/wait_ready.sh vllm-qwen3-8b
bash scripts/apikey.sh add me                 # 记下打印出来的 key
bash scripts/gateway.sh up && bash scripts/gateway.sh test
runtime/envs/client/bin/python tools/smoke_test.py --base-url http://127.0.0.1:9080/v1 --api-key <key>
runtime/envs/client/bin/python tools/chat_client.py --api-key <key>
```

同网段的其他机器用 `http://<本机IP>:9080/v1`，带上 `Authorization: Bearer <key>` 即可调用（见 `docs/05`）。

## 4. 模型与硬件的关键事实（已核实）

| 模型 | 结构 | 权重 | 在 8×H800（80GB）上 |
|---|---|---|---|
| `deepseek-ai/DeepSeek-V4.1-Flash-1017`（revision `1bae0e10`） | 40 层；滑动窗口 + 压缩稀疏注意力，两级 indexer；Engram n-gram 记忆（两张表约 183 GiB）；Hyper-Connections；384 专家选 6；DSpark 草稿头；视觉编码器 | MXFP4 专家 + MXFP8，约 510 GB | 只能 TP8，而且 Engram 表必须放主机内存，`max-num-batched-tokens` 限制为 4096（vLLM recipe 中 H100 档的设置） |
| `zai-org/GLM-5.3-Flash`（revision `46a050be`） | 45 层；KDA 线性注意力 + NoPE 稀疏 MLA（DSA）混合；mHC；288 专家选 8；1 个 MTP 层；视觉编码器 | FP8，约 328 GB（最低需要约 386 GB 显存） | 只能放一个 8 卡副本（TP4 放不下）；Hopper 上 KV 默认 BF16，vLLM v0.32.0 起可选 `fp8_ds_mla` |
| `zai-org/GLM-4.7-Flash` | 31B MoE（64 专家选 4），MLA，1 个 MTP 层 | BF16，约 63 GB | 1–2 卡一个副本，最多 8 个副本：DP、PP、EP、PD 实验的主力 |
| `Qwen/Qwen3-8B` | 8B 稠密 GQA | BF16，约 16 GB | 单卡；TP/attention 后端/量化/调度等基础实验 |

- **框架版本**：vLLM v0.32.0（2026-10-18），SGLang v0.5.23（2026-10-30）。
- **驱动要求**：SGLang 从 0.5.20 起只支持 CUDA 13，需要驱动 ≥ 580；vLLM 另提供 `-cu129` 镜像，供旧驱动使用。

## 5. 其他推荐框架（本包未展开）

- **TensorRT-LLM / NVIDIA Dynamo**：NVIDIA 官方方案，Dynamo 把 vLLM、SGLang、TRT-LLM 作为后端，做多节点 PD 分离和 KV 路由。规模扩大到多机时值得了解。
- **TokenSpeed、KTransformers**：GLM-5.3-Flash 模型卡列出的其他部署框架。KTransformers 擅长 CPU/GPU 混合（专家放 CPU），适合研究“显存不够时怎么办”。
- 本包以 vLLM 和 SGLang 为主：两者对这两个模型都有官方 recipe，社区最活跃，源码适合阅读和修改（发论文最常用的基线）。
