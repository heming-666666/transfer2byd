#!/usr/bin/env python3
"""分析 MoE 专家激活分布（SGLang 专家分布记录器的输出）。

数据来源：SGLang 启动参数 --expert-distribution-recorder-mode stat，配合环境变量
SGLANG_EXPERT_DISTRIBUTION_RECORDER_DIR=/results/...，然后依次调用
  POST /start_expert_distribution_record → 发请求 → POST /stop_expert_distribution_record → POST /dump_expert_distribution_record
得到 expert_distribution_recorder_*.pt，其中 "logical_count" 是 [层数, 专家数]（或带前置维度）的 token 计数。

输出：
  - 每层的负载均衡度 balancedness = 平均负载 / 最大负载（1 表示完全均衡；EPLB 用的就是这个指标）
  - 每层最热/最冷专家、Top-k 专家占比、从不被选中的专家数
  - 按 EP 规模（默认 8）把专家平均分到各 rank 后，各 rank 的负载与最大/平均比 —— 估计 EP 下的“拖尾 rank”
  - 可选：热力图 PNG（需要 matplotlib）
需要 torch 读取 .pt（在引擎镜像或安装了 torch 的环境中运行）。

用法:
  python tools/expert_stats.py runtime/results/E06/xxx/expert_distribution_recorder_*.pt --ep 8 --png heat.png
"""
from __future__ import annotations

import argparse
import json
import sys

import torch


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pt")
    ap.add_argument("--ep", type=int, default=8, help="假设的 EP 规模（专家按编号平均切分到各 rank）")
    ap.add_argument("--png")
    ap.add_argument("--json")
    a = ap.parse_args()
    data = torch.load(a.pt, weights_only=True, map_location="cpu")
    if isinstance(data, dict) and "logical_count" in data:
        cnt = data["logical_count"]
    elif isinstance(data, list):
        sys.exit("这是 per_pass/per_token 模式的明细数据；本脚本分析 stat 模式。可把明细里每步的 topk_ids 自行累加。")
    else:
        sys.exit(f"无法识别的数据格式: {type(data)} keys={list(data)[:10] if isinstance(data, dict) else ''}")
    cnt = cnt.float()
    while cnt.dim() > 2:  # [rank/step, layer, expert] -> 求和
        cnt = cnt.sum(0)
    L, E = cnt.shape
    print(f"层数 {L}，专家数 {E}，总计数 {cnt.sum():.0f}")
    per_layer = []
    for l in range(L):
        c = cnt[l]
        if c.sum() == 0:
            continue
        bal = (c.mean() / c.max()).item()
        top8 = (c.topk(min(8, E)).values.sum() / c.sum()).item()
        ranks = c.view(a.ep, E // a.ep).sum(1) if E % a.ep == 0 else None
        rank_ratio = (ranks.max() / ranks.mean()).item() if ranks is not None else None
        per_layer.append({"layer": l, "balancedness": bal, "top8_share": top8, "zero_experts": int((c == 0).sum()),
                          "hottest": int(c.argmax()), "ep_rank_max_over_mean": rank_ratio})
    print(f"{'层':>4} {'均衡度':>8} {'Top8占比':>9} {'零激活专家':>10} {'最热专家':>8} {'EP rank 最大/平均':>16}")
    for r in per_layer:
        rr = f"{r['ep_rank_max_over_mean']:.2f}" if r["ep_rank_max_over_mean"] else "-"
        print(f"{r['layer']:>4} {r['balancedness']:8.3f} {r['top8_share']:9.1%} {r['zero_experts']:10d} {r['hottest']:8d} {rr:>16}")
    if per_layer:
        mb = sum(r["balancedness"] for r in per_layer) / len(per_layer)
        print(f"\n平均均衡度 {mb:.3f}（EP 下每步时间取决于最忙的 rank，均衡度越低，拖尾越严重）")
    if a.png:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.figure(figsize=(min(24, E / 12 + 4), L / 6 + 3))
        plt.imshow((cnt / cnt.sum(1, keepdim=True).clamp(min=1)).numpy(), aspect="auto", cmap="viridis")
        plt.xlabel("expert id"); plt.ylabel("layer"); plt.colorbar(label="share of tokens in layer")
        plt.title("Expert activation share")
        plt.tight_layout(); plt.savefig(a.png, dpi=120)
        print(f"热力图 -> {a.png}")
    if a.json:
        with open(a.json, "w") as f:
            json.dump(per_layer, f, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
