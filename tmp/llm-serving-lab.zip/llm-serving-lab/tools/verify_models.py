#!/usr/bin/env python3
"""按 configs/models/<key>.manifest.json 校验本地模型目录。

默认只比较文件是否齐全、大小是否一致（快）；加 --sha256 时对每个 LFS 文件计算 SHA-256（510 GB 约需 30–60 分钟）。
只依赖 Python 标准库。

用法:
  python tools/verify_models.py qwen3-8b
  python tools/verify_models.py deepseek-v4.1-flash-1017 --sha256
  python tools/verify_models.py --models-dir /data/models glm-5.3-flash
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

LAB_ROOT = Path(__file__).resolve().parent.parent


def default_models_dir() -> Path:
    env = os.environ.get("MODELS_DIR")
    if env:
        return Path(env)
    return LAB_ROOT / "runtime" / "models"


def sha256_of(path: Path, chunk: int = 64 << 20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def verify(key: str, models_dir: Path, check_sha: bool) -> bool:
    man_path = LAB_ROOT / "configs" / "models" / f"{key}.manifest.json"
    man = json.loads(man_path.read_text())
    root = models_dir / key
    if not root.is_dir():
        print(f"[失败] 目录不存在: {root}")
        return False
    missing, wrong_size, bad_hash = [], [], []
    for f in man["files"]:
        p = root / f["path"]
        if not p.exists():
            missing.append(f["path"])
            continue
        if f.get("size") is not None and p.stat().st_size != f["size"]:
            wrong_size.append((f["path"], p.stat().st_size, f["size"]))
            continue
        if check_sha and f.get("sha256"):
            got = sha256_of(p)
            if got != f["sha256"]:
                bad_hash.append(f["path"])
            else:
                print(f"  sha256 ok {f['path']}")
    # safetensors 索引里列出的分片都要存在
    idx = root / "model.safetensors.index.json"
    shard_missing = []
    if idx.exists():
        shards = set(json.loads(idx.read_text())["weight_map"].values())
        shard_missing = sorted(s for s in shards if not (root / s).exists())
    ok = not (missing or wrong_size or bad_hash or shard_missing)
    print(f"模型 {key}  repo={man['repo']}  revision={man['revision'][:12]}  目录={root}")
    print(f"  文件数 {len(man['files'])}，缺失 {len(missing)}，大小不符 {len(wrong_size)}，"
          f"哈希不符 {len(bad_hash)}，索引缺分片 {len(shard_missing)}")
    for m in missing[:20]:
        print(f"  缺失: {m}")
    for p, got, exp in wrong_size[:20]:
        print(f"  大小不符: {p} 本地 {got} 期望 {exp}")
    for p in bad_hash[:20]:
        print(f"  哈希不符: {p}")
    for s in shard_missing[:20]:
        print(f"  索引缺分片: {s}")
    print("  结论:", "通过" if ok else "失败")
    return ok


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("keys", nargs="+")
    ap.add_argument("--models-dir", type=Path, default=default_models_dir())
    ap.add_argument("--sha256", action="store_true", help="计算每个 LFS 文件的 SHA-256（慢）")
    a = ap.parse_args()
    results = [verify(k, a.models_dir, a.sha256) for k in a.keys]
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
