#!/usr/bin/env python3
"""分析 PyTorch Profiler 导出的 Chrome/Perfetto trace（*.pt.trace.json[.gz]、*.trace.json.gz）。

vLLM（--profiler-config torch）和 SGLang（/start_profile）导出的都是这种格式。能回答：
  1. 哪些 kernel 占时最多（按名字、按类别：GEMM / Attention / MoE / 通信 / Norm / 采样 / 拷贝 ...）
  2. 每个 kernel 启动多少个 block，估计占用多少个 SM（min(blocks, SM 数)），按时间加权的 SM 覆盖分布
  3. GPU 忙碌时间、空闲气泡（bubble）有多少、最长的几个在哪里 —— 判断是否 CPU-bound
  4. CPU 端提交开销：cudaLaunchKernel / cuLaunchKernel / cudaGraphLaunch / 同步调用的次数与耗时
  5. 通信（NCCL / 自定义 all-reduce）占 GPU 时间的比例
  6. 用户标注区间（如 SGLang 的 step[DECODE bs=..] 标注、vLLM 的 execute_model）各自耗时
只依赖标准库。trace 很大时（>1GB）建议先用较少请求重新采集。

用法:
  python tools/analyze_torch_trace.py runtime/traces/E16/xxx/rank0.*.pt.trace.json.gz
  python tools/analyze_torch_trace.py trace.json.gz --sm-count 132 --top 40 --json report.json --md report.md
  python tools/analyze_torch_trace.py trace.json.gz --window-ms 1000 2000   # 只分析 [1000ms, 2000ms) 这段
"""
from __future__ import annotations

import argparse
import gzip
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

CATEGORY_RULES: list[tuple[str, re.Pattern]] = [
    ("通信", re.compile(r"nccl|all_?reduce|allgather|all_gather|reduce_?scatter|all_?to_?all|alltoall|cross_device|"
                      r"one_?shot|two_?shot|custom_ar|deep_?ep|dispatch|combine|nvshmem|lamport|symm_?mem|mnnvl", re.I)),
    ("MoE", re.compile(r"moe|expert|grouped_gemm|group_gemm|fused_moe|topk_softmax|routing|mega_?moe|deep_gemm.*m_grouped", re.I)),
    ("Attention", re.compile(r"flash|fmha|attn|attention|mla|paged|decode_kernel|prefill_kernel|sparse_mla|indexer|"
                             r"flashinfer|xqa|kda|gdn|linear_attn|mamba|ssd|sliding", re.I)),
    ("GEMM", re.compile(r"gemm|matmul|cutlass|xmma|cublas|sm90_|sm80_|wgmma|nvjet|deep_gemm|fp8_block|w8a8|scaled_mm|gemv", re.I)),
    ("Norm", re.compile(r"norm|rms|layernorm", re.I)),
    ("RoPE/激活", re.compile(r"rotary|rope|silu|gelu|act_and_mul|swiglu|activation", re.I)),
    ("采样/Logits", re.compile(r"sampl|softmax|argmax|topk|top_k|top_p|gumbel|logit|penalt", re.I)),
    ("KV写入/缓存", re.compile(r"reshape_and_cache|cache_kernel|store_kv|set_kv|kv_buffer|concat_and_cache|copy_blocks", re.I)),
    ("拷贝/填充", re.compile(r"memcpy|memset|copy|fill|cat_|index|gather|scatter|elementwise|vectorized|reduce_kernel", re.I)),
]

LAUNCH_APIS = re.compile(r"^(cudaLaunchKernel|cudaLaunchKernelExC|cuLaunchKernel|cuLaunchKernelEx|cudaLaunchCooperativeKernel)")
GRAPH_APIS = re.compile(r"^(cudaGraphLaunch|cuGraphLaunch)")
SYNC_APIS = re.compile(r"Synchronize|cudaMemcpy(?!Async)|cudaStreamWaitEvent")


def categorize(name: str) -> str:
    for cat, pat in CATEGORY_RULES:
        if pat.search(name):
            return cat
    return "其他"


def short(name: str, n: int = 90) -> str:
    name = re.sub(r"\s+", " ", name)
    return name if len(name) <= n else name[: n - 3] + "..."


def load_events(path: Path) -> list[dict]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", errors="replace") as f:  # type: ignore[operator]
        data = json.load(f)
    if isinstance(data, dict):
        return data.get("traceEvents", [])
    return data


def merge_intervals(iv: list[tuple[float, float]]) -> list[tuple[float, float]]:
    iv.sort()
    out: list[list[float]] = []
    for s, e in iv:
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return [(s, e) for s, e in out]


def blocks_of(args: dict) -> int | None:
    g = args.get("grid")
    if isinstance(g, list) and g:
        b = 1
        for x in g:
            b *= int(x or 1)
        return b
    return None


def analyze(path: Path, sm_count: int, top: int, window: tuple[float, float] | None, gap_us: float) -> dict:
    events = load_events(path)
    kernels, apis, annos, memcpy = [], [], [], []
    for e in events:
        if e.get("ph") != "X" or "dur" not in e:
            continue
        cat = str(e.get("cat", "")).lower()
        if cat == "kernel":
            kernels.append(e)
        elif cat in ("cuda_runtime", "cuda_driver"):
            apis.append(e)
        elif cat in ("gpu_memcpy", "gpu_memset"):
            memcpy.append(e)
        elif cat in ("gpu_user_annotation", "user_annotation"):
            annos.append(e)
    if not kernels:
        return {"file": str(path), "error": "trace 中没有 GPU kernel 事件（是否只采集了 CPU？activities 需包含 CUDA/GPU）"}

    t0 = min(float(k["ts"]) for k in kernels)
    if window:
        lo, hi = t0 + window[0] * 1000, t0 + window[1] * 1000
        sel = lambda ev: lo <= float(ev["ts"]) < hi  # noqa: E731
        kernels = [k for k in kernels if sel(k)]
        apis = [x for x in apis if sel(x)]
        annos = [x for x in annos if sel(x)]
        memcpy = [x for x in memcpy if sel(x)]

    # ---- 按设备统计忙碌与空闲 ----
    per_dev: dict[int, list[tuple[float, float]]] = defaultdict(list)
    for k in kernels + memcpy:
        a = k.get("args") or {}
        dev = a.get("device")
        if dev is None:
            pid = k.get("pid", 0)
            dev = pid if isinstance(pid, int) else (int(pid) if str(pid).isdigit() else 0)
        dev = int(dev)
        s = float(k["ts"])
        per_dev[dev].append((s, s + float(k["dur"])))
    devices = {}
    for dev, iv in sorted(per_dev.items()):
        m = merge_intervals(iv)
        span = m[-1][1] - m[0][0]
        busy = sum(e - s for s, e in m)
        gaps = [(m[i + 1][0] - m[i][1], m[i][1]) for i in range(len(m) - 1)]
        big = sorted((g for g in gaps if g[0] >= gap_us), reverse=True)
        devices[dev] = {
            "span_ms": span / 1e3,
            "busy_ms": busy / 1e3,
            "busy_ratio": busy / span if span > 0 else 0.0,
            "idle_ms": (span - busy) / 1e3,
            f"gaps_ge_{int(gap_us)}us": len(big),
            "gap_time_ge_threshold_ms": sum(g for g, _ in big) / 1e3,
            "top_gaps": [{"gap_us": round(g, 1), "at_ms": round((t - t0) / 1e3, 3)} for g, t in big[:10]],
        }

    # ---- kernel 统计 ----
    total_kernel_us = sum(float(k["dur"]) for k in kernels)
    by_name: dict[str, dict] = {}
    by_cat: dict[str, float] = defaultdict(float)
    sm_buckets = {"<25% SM": 0.0, "25-50% SM": 0.0, "50-100% SM": 0.0, "≥1 波(全部SM)": 0.0, "未知": 0.0}
    for k in kernels:
        name = k.get("name", "?")
        a = k.get("args") or {}
        d = float(k["dur"])
        c = categorize(name)
        by_cat[c] += d
        r = by_name.setdefault(name, {"name": name, "cat": c, "count": 0, "total_us": 0.0, "blocks_x_time": 0.0,
                                      "occ_x_time": 0.0, "occ_time": 0.0, "regs": a.get("registers per thread"),
                                      "smem": a.get("shared memory")})
        r["count"] += 1
        r["total_us"] += d
        b = blocks_of(a)
        if b is not None:
            r["blocks_x_time"] += b * d
            frac = b / sm_count
            key = "<25% SM" if frac < 0.25 else "25-50% SM" if frac < 0.5 else "50-100% SM" if frac < 1 else "≥1 波(全部SM)"
            sm_buckets[key] += d
        else:
            sm_buckets["未知"] += d
        occ = a.get("est. achieved occupancy %")
        if isinstance(occ, (int, float)):
            r["occ_x_time"] += occ * d
            r["occ_time"] += d
    top_k = sorted(by_name.values(), key=lambda r: -r["total_us"])[:top]
    for r in top_k:
        r["avg_us"] = r["total_us"] / r["count"]
        r["pct"] = 100 * r["total_us"] / total_kernel_us
        avg_blocks = r["blocks_x_time"] / r["total_us"] if r["blocks_x_time"] else None
        r["avg_blocks"] = avg_blocks
        r["est_sms"] = min(avg_blocks, sm_count) if avg_blocks else None
        r["avg_occupancy_pct"] = r["occ_x_time"] / r["occ_time"] if r["occ_time"] else None

    # ---- CPU 端 API ----
    api_stats: dict[str, dict] = defaultdict(lambda: {"count": 0, "total_us": 0.0})
    launch_us = graph_us = sync_us = 0.0
    n_launch = n_graph = 0
    for x in apis:
        n = x.get("name", "?")
        d = float(x["dur"])
        api_stats[n]["count"] += 1
        api_stats[n]["total_us"] += d
        if LAUNCH_APIS.search(n):
            launch_us += d; n_launch += 1
        elif GRAPH_APIS.search(n):
            graph_us += d; n_graph += 1
        elif SYNC_APIS.search(n):
            sync_us += d
    top_api = sorted(({"name": k, **v} for k, v in api_stats.items()), key=lambda r: -r["total_us"])[:15]

    # ---- 标注 ----
    anno_stats: dict[str, dict] = defaultdict(lambda: {"count": 0, "total_us": 0.0})
    step_types: dict[str, dict] = defaultdict(lambda: {"count": 0, "total_us": 0.0})
    for x in annos:
        n = x.get("name", "?")
        d = float(x["dur"])
        m = re.match(r"step\[(\w+)", n)
        key = f"step[{m.group(1)}]" if m else n
        anno_stats[key]["count"] += 1
        anno_stats[key]["total_us"] += d
        if m:
            step_types[m.group(1)]["count"] += 1
            step_types[m.group(1)]["total_us"] += d
    top_anno = sorted(({"name": k, **v, "avg_us": v["total_us"] / v["count"]} for k, v in anno_stats.items()),
                      key=lambda r: -r["total_us"])[:20]

    comm_us = by_cat.get("通信", 0.0)
    return {
        "file": str(path),
        "sm_count": sm_count,
        "num_kernels": len(kernels),
        "kernel_time_ms": total_kernel_us / 1e3,
        "devices": devices,
        "category_ms": {k: v / 1e3 for k, v in sorted(by_cat.items(), key=lambda kv: -kv[1])},
        "category_pct": {k: 100 * v / total_kernel_us for k, v in sorted(by_cat.items(), key=lambda kv: -kv[1])},
        "communication_pct_of_kernel_time": 100 * comm_us / total_kernel_us,
        "sm_coverage_pct_of_kernel_time": {k: 100 * v / total_kernel_us for k, v in sm_buckets.items()},
        "top_kernels": top_k,
        "cpu_api": {
            "kernel_launch_calls": n_launch, "kernel_launch_ms": launch_us / 1e3,
            "avg_launch_us": launch_us / n_launch if n_launch else None,
            "graph_launch_calls": n_graph, "graph_launch_ms": graph_us / 1e3,
            "sync_ms": sync_us / 1e3, "top_apis": top_api,
        },
        "annotations": top_anno,
        "step_types": {k: {**v, "avg_us": v["total_us"] / v["count"]} for k, v in step_types.items()},
    }


def to_markdown(r: dict) -> str:
    if "error" in r:
        return f"# {r['file']}\n\n错误: {r['error']}\n"
    L = [f"# Trace 分析: {Path(r['file']).name}", "",
         f"- kernel 数 {r['num_kernels']}，kernel 总时长 {r['kernel_time_ms']:.2f} ms，按 {r['sm_count']} 个 SM 估算",
         f"- 通信 kernel 占 kernel 时间 {r['communication_pct_of_kernel_time']:.1f}%", "",
         "## 各 GPU 忙碌与空闲", "", "| 设备 | 时间跨度 ms | 忙碌 ms | 忙碌比例 | 空闲 ms | 大气泡数 | 大气泡总时长 ms |", "|---|---|---|---|---|---|---|"]
    for dev, d in r["devices"].items():
        gk = [k for k in d if k.startswith("gaps_ge_")][0]
        L.append(f"| {dev} | {d['span_ms']:.2f} | {d['busy_ms']:.2f} | {d['busy_ratio']:.1%} | {d['idle_ms']:.2f} | {d[gk]} | {d['gap_time_ge_threshold_ms']:.2f} |")
    L += ["", "## kernel 类别", "", "| 类别 | 时间 ms | 占比 |", "|---|---|---|"]
    for k, v in r["category_ms"].items():
        L.append(f"| {k} | {v:.2f} | {r['category_pct'][k]:.1f}% |")
    L += ["", "## SM 覆盖（按 kernel 时间加权；grid block 数 / SM 数）", "", "| 区间 | 占 kernel 时间 |", "|---|---|"]
    for k, v in r["sm_coverage_pct_of_kernel_time"].items():
        L.append(f"| {k} | {v:.1f}% |")
    L += ["", "注：block 数 ≥ SM 数只说明能铺满一波；实际同时驻留多少 block 还取决于寄存器/共享内存（看 occupancy）。精确的 SM 活跃度用 DCGM 或 nsys --gpu-metrics-devices。",
          "", "## Top kernels", "", "| # | 类别 | 次数 | 总 ms | 平均 us | 占比 | 平均 blocks | 估计 SM | occupancy% | kernel |", "|---|---|---|---|---|---|---|---|---|---|"]
    for i, k in enumerate(r["top_kernels"], 1):
        ab = f"{k['avg_blocks']:.0f}" if k["avg_blocks"] else "-"
        es = f"{k['est_sms']:.0f}" if k["est_sms"] else "-"
        oc = f"{k['avg_occupancy_pct']:.0f}" if k["avg_occupancy_pct"] else "-"
        L.append(f"| {i} | {k['cat']} | {k['count']} | {k['total_us'] / 1e3:.2f} | {k['avg_us']:.1f} | {k['pct']:.1f}% | {ab} | {es} | {oc} | `{short(k['name'])}` |")
    c = r["cpu_api"]
    al = f"{c['avg_launch_us']:.1f}" if c["avg_launch_us"] else "-"
    L += ["", "## CPU 端提交开销", "",
          f"- 单 kernel 启动 API 调用 {c['kernel_launch_calls']} 次，共 {c['kernel_launch_ms']:.2f} ms，平均 {al} us/次",
          f"- CUDA graph 启动 {c['graph_launch_calls']} 次，共 {c['graph_launch_ms']:.2f} ms",
          f"- 同步类调用共 {c['sync_ms']:.2f} ms", "", "| API | 次数 | 总 ms |", "|---|---|---|"]
    for a in c["top_apis"]:
        L.append(f"| {a['name']} | {a['count']} | {a['total_us'] / 1e3:.2f} |")
    if r["annotations"]:
        L += ["", "## 标注区间", "", "| 名称 | 次数 | 总 ms | 平均 us |", "|---|---|---|---|"]
        for a in r["annotations"]:
            L.append(f"| `{short(a['name'], 70)}` | {a['count']} | {a['total_us'] / 1e3:.2f} | {a['avg_us']:.1f} |")
    for dev, d in r["devices"].items():
        if d["top_gaps"]:
            L += ["", f"## 设备 {dev} 最长的空闲气泡", "", "| 气泡 us | 发生在 ms |", "|---|---|"]
            L += [f"| {g['gap_us']} | {g['at_ms']} |" for g in d["top_gaps"]]
    return "\n".join(L) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("traces", nargs="+", type=Path)
    ap.add_argument("--sm-count", type=int, default=132, help="每张 GPU 的 SM 数（H800/H100 SXM 为 132，以实测为准）")
    ap.add_argument("--top", type=int, default=30)
    ap.add_argument("--gap-us", type=float, default=50.0, help="大于该值的 GPU 空闲才计为气泡")
    ap.add_argument("--window-ms", type=float, nargs=2, metavar=("START", "END"))
    ap.add_argument("--json", type=Path)
    ap.add_argument("--md", type=Path)
    a = ap.parse_args()
    reports = [analyze(p, a.sm_count, a.top, tuple(a.window_ms) if a.window_ms else None, a.gap_us) for p in a.traces]
    md = "\n".join(to_markdown(r) for r in reports)
    print(md)
    if a.md:
        a.md.write_text(md)
    if a.json:
        a.json.write_text(json.dumps(reports, ensure_ascii=False, indent=1, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
