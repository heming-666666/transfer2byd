#!/usr/bin/env python3
"""约束解码（structured outputs）实验：同一组请求分别用 无约束 / choice / regex / json_schema / grammar(EBNF)
发送，统计格式合法率、端到端延迟和输出 token 数，用来理解约束解码的开销与收益。

vLLM 与 SGLang 的请求写法不同：
  vLLM   extra_body={"structured_outputs": {"choice"|"regex"|"json"|"grammar": ...}}，json_schema 也可用 response_format
  SGLang extra_body={"regex": ...} / {"ebnf": ...}，json_schema 用 response_format；choice 用 regex 表达
用 --engine 选择写法。服务端后端（xgrammar / guidance / outlines / llguidance）在启动参数里切换，见 experiments/E19。
依赖 openai 与标准库。

用法:
  python tools/structured_outputs_test.py --engine vllm --base-url http://127.0.0.1:8000/v1 -n 20 --out r.json
  python tools/structured_outputs_test.py --engine sglang --base-url http://127.0.0.1:30000/v1 -n 20 --concurrency 8
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import re
import statistics
import sys
import time

from openai import OpenAI

SCHEMA = {"type": "object",
          "properties": {"name": {"type": "string"}, "age": {"type": "integer", "minimum": 0, "maximum": 150},
                         "skills": {"type": "array", "items": {"type": "string"}, "maxItems": 5},
                         "level": {"type": "string", "enum": ["junior", "senior", "staff"]}},
          "required": ["name", "age", "skills", "level"], "additionalProperties": False}
REGEX = r"[A-Z][a-z]+@[a-z]+\.(com|org|net)"
CHOICES = ["positive", "negative", "neutral"]
EBNF = 'root ::= "SELECT " col " FROM " table ";"\ncol ::= "name" | "age" | "*"\ntable ::= "users" | "orders"'

PROMPTS = {
    "none": "Describe a fictional software engineer as JSON with fields name, age, skills, level.",
    "choice": "Classify the sentiment of: 'The service was slow but the food was great.' Answer one word.",
    "regex": "Invent an email address for a person named Alice.",
    "json_schema": "Describe a fictional software engineer.",
    "grammar": "Write an SQL query that lists all users.",
}


def build(engine: str, kind: str) -> tuple[dict, dict | None]:
    """返回 (extra_body, response_format)"""
    if kind == "none":
        return {}, None
    if kind == "json_schema":
        return {}, {"type": "json_schema", "json_schema": {"name": "engineer", "schema": SCHEMA}}
    if engine == "vllm":
        key = {"choice": "choice", "regex": "regex", "grammar": "grammar"}[kind]
        val = {"choice": CHOICES, "regex": REGEX, "grammar": EBNF}[kind]
        return {"structured_outputs": {key: val}}, None
    # sglang
    if kind == "choice":
        return {"regex": "(" + "|".join(CHOICES) + ")"}, None
    if kind == "regex":
        return {"regex": REGEX}, None
    return {"ebnf": EBNF}, None


def valid(kind: str, text: str) -> bool:
    text = (text or "").strip()
    try:
        if kind in ("none", "json_schema"):
            obj = json.loads(text)
            return all(k in obj for k in SCHEMA["required"]) and isinstance(obj.get("age"), int)
        if kind == "choice":
            return text in CHOICES
        if kind == "regex":
            return re.fullmatch(REGEX, text) is not None
        if kind == "grammar":
            return re.fullmatch(r"SELECT (name|age|\*) FROM (users|orders);", text) is not None
    except (ValueError, TypeError):
        return False
    return False


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--engine", choices=["vllm", "sglang"], required=True)
    ap.add_argument("--base-url", required=True)
    ap.add_argument("--api-key", default=os.environ.get("LAB_API_KEY", "EMPTY"))
    ap.add_argument("--model")
    ap.add_argument("-n", type=int, default=20, help="每种约束的请求数")
    ap.add_argument("--concurrency", type=int, default=4)
    ap.add_argument("--max-tokens", type=int, default=512)
    ap.add_argument("--kinds", default="none,choice,regex,json_schema,grammar")
    ap.add_argument("--extra-body", default='{}', help="附加参数，例如关闭思考")
    ap.add_argument("--out")
    a = ap.parse_args()
    c = OpenAI(base_url=a.base_url, api_key=a.api_key, timeout=600)
    model = a.model or c.models.list().data[0].id
    base_extra = json.loads(a.extra_body)
    summary = {}
    for kind in a.kinds.split(","):
        extra, rf = build(a.engine, kind)
        extra = {**base_extra, **extra}

        def one(_i: int) -> tuple[bool, float, int, str]:
            t = time.perf_counter()
            kw = dict(model=model, messages=[{"role": "user", "content": PROMPTS[kind]}], max_tokens=a.max_tokens,
                      temperature=0.7, extra_body=extra)
            if rf:
                kw["response_format"] = rf
            r = c.chat.completions.create(**kw)
            txt = r.choices[0].message.content or ""
            return valid(kind, txt), time.perf_counter() - t, (r.usage.completion_tokens if r.usage else 0), txt
        with cf.ThreadPoolExecutor(a.concurrency) as ex:
            res = list(ex.map(one, range(a.n)))
        lat = [r[1] for r in res]
        summary[kind] = {"valid_rate": sum(r[0] for r in res) / len(res), "lat_p50_s": statistics.median(lat),
                         "lat_max_s": max(lat), "mean_out_tokens": statistics.mean(r[2] for r in res),
                         "example": res[0][3][:200]}
        s = summary[kind]
        print(f"{kind:12s} 合法率 {s['valid_rate']:.0%}  延迟中位 {s['lat_p50_s']:.2f}s  平均输出 {s['mean_out_tokens']:.0f} tok  例: {s['example'][:80]!r}")
    if a.out:
        with open(a.out, "w") as f:
            json.dump({"engine": a.engine, "model": model, "summary": summary}, f, ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
