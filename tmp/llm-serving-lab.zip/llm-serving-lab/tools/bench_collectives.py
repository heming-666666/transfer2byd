#!/usr/bin/env python3
"""用 torch.distributed（NCCL）测量单机多卡集合通信带宽，理解 TP/EP/PD 背后的通信代价。

测试项：all_reduce、all_gather、reduce_scatter、all_to_all（EP 的 dispatch/combine 本质）、send/recv（PP 与 KV 传输）。
带宽口径与 nccl-tests 一致：
  algbw = 数据量 / 时间
  busbw = algbw × 系数：all_reduce 2(n-1)/n，all_gather 与 reduce_scatter (n-1)/n，all_to_all (n-1)/n，send/recv 1
busbw 可直接与硬件链路带宽比较（H800 的 NVLink 约 400 GB/s 双向，即单向约 200 GB/s；以实测为准）。

运行（在引擎镜像里即可，镜像自带 torch 与 NCCL；需要停止占用 GPU 的服务）：
  docker run --rm --gpus all --ipc=host --network host -v $PWD:/lab --entrypoint torchrun vllm/vllm-openai:v0.32.0 \
      --nproc-per-node 8 /lab/tools/bench_collectives.py --out /lab/runtime/results/E15/collectives-8gpu.json
  只测部分 GPU：-e CUDA_VISIBLE_DEVICES=0,1 并把 --nproc-per-node 改为 2
  看 NCCL 选择的算法与拓扑：加 -e NCCL_DEBUG=INFO -e NCCL_DEBUG_SUBSYS=INIT,GRAPH
"""
from __future__ import annotations

import argparse
import json
import os
import time

import torch
import torch.distributed as dist


def human(n: int) -> str:
    for u in ["B", "KB", "MB", "GB"]:
        if n < 1024:
            return f"{n:.0f}{u}"
        n /= 1024
    return f"{n:.0f}TB"


def bench(op: str, nbytes: int, world: int, rank: int, iters: int, warmup: int, dtype=torch.bfloat16) -> float:
    el = torch.tensor([], dtype=dtype).element_size()
    n = max(world, nbytes // el // world * world)
    dev = torch.device("cuda", torch.cuda.current_device())
    x = torch.ones(n, dtype=dtype, device=dev)
    if op == "all_reduce":
        f = lambda: dist.all_reduce(x)  # noqa: E731
    elif op == "all_gather":
        out = torch.empty(n * world, dtype=dtype, device=dev)
        f = lambda: dist.all_gather_into_tensor(out, x)  # noqa: E731
    elif op == "reduce_scatter":
        out = torch.empty(n // world, dtype=dtype, device=dev)
        f = lambda: dist.reduce_scatter_tensor(out, x)  # noqa: E731
    elif op == "all_to_all":
        out = torch.empty_like(x)
        f = lambda: dist.all_to_all_single(out, x)  # noqa: E731
    elif op == "sendrecv":
        peer = rank ^ 1
        if peer >= world:
            return float("nan")
        buf = torch.empty_like(x)

        def f():
            if rank % 2 == 0:
                dist.send(x, peer); dist.recv(buf, peer)
            else:
                dist.recv(buf, peer); dist.send(x, peer)
    else:
        raise ValueError(op)
    for _ in range(warmup):
        f()
    torch.cuda.synchronize(); dist.barrier()
    t = time.perf_counter()
    for _ in range(iters):
        f()
    torch.cuda.synchronize()
    return (time.perf_counter() - t) / iters


FACTOR = {"all_reduce": lambda n: 2 * (n - 1) / n, "all_gather": lambda n: (n - 1) / n,
          "reduce_scatter": lambda n: (n - 1) / n, "all_to_all": lambda n: (n - 1) / n, "sendrecv": lambda n: 1.0}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ops", default="all_reduce,all_gather,reduce_scatter,all_to_all,sendrecv")
    ap.add_argument("--min-bytes", type=int, default=1 << 10)
    ap.add_argument("--max-bytes", type=int, default=1 << 30)
    ap.add_argument("--iters", type=int, default=20)
    ap.add_argument("--warmup", type=int, default=5)
    ap.add_argument("--out")
    a = ap.parse_args()
    dist.init_process_group("nccl")
    rank, world = dist.get_rank(), dist.get_world_size()
    torch.cuda.set_device(int(os.environ.get("LOCAL_RANK", rank)))
    rows = []
    sizes = []
    s = a.min_bytes
    while s <= a.max_bytes:
        sizes.append(s); s *= 4
    for op in a.ops.split(","):
        if rank == 0:
            print(f"\n== {op}  world={world}\n{'size':>8} {'time_us':>10} {'algbw GB/s':>11} {'busbw GB/s':>11}")
        for nb in sizes:
            t = bench(op, nb, world, rank, a.iters, a.warmup)
            # 统一按“每个 rank 的输入字节数”计算（与 nccl-tests 相同）；sendrecv 是双向各发一次
            data = nb * (2 if op == "sendrecv" else 1)
            algbw = data / t / 1e9 if t == t else float("nan")
            busbw = algbw * FACTOR[op](world)
            if rank == 0:
                print(f"{human(nb):>8} {t * 1e6:10.1f} {algbw:11.2f} {busbw:11.2f}")
                rows.append({"op": op, "bytes": nb, "time_us": t * 1e6, "algbw_GBps": algbw, "busbw_GBps": busbw, "world": world})
    if rank == 0 and a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        with open(a.out, "w") as f:
            json.dump({"device": torch.cuda.get_device_name(), "nccl": ".".join(map(str, torch.cuda.nccl.version())),
                       "torch": torch.__version__, "rows": rows}, f, indent=1)
        print(f"\n结果 -> {a.out}")
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
