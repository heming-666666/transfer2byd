#!/usr/bin/env python3
"""按任务类型批量发送请求（用于专家激活统计、投机解码分类别接受率、思考强度曲线等实验）。

内置四类提示：math（算术与应用题，答案可自动判分）、code（编程题）、zh（中文开放问答）、en（英文开放问答）。
每类按模板与随机数生成不重复的题目，结果写入 JSONL：题目、回答、思考长度、用时、token 用量、（math）是否答对。
依赖 openai 与标准库。

用法:
  python tools/send_prompts.py --base-url http://127.0.0.1:30000/v1 --task math -n 50 --concurrency 8 --out math.jsonl
  python tools/send_prompts.py --task math -n 100 --extra-body '{"chat_template_kwargs":{"thinking":true,"reasoning_effort":25}}' --out e25.jsonl
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import random
import re
import statistics
import sys
import time

from openai import OpenAI

CODE_TASKS = ["反转一个单链表", "判断字符串是否为回文（忽略大小写和非字母字符）", "实现 LRU 缓存", "求最长递增子序列长度",
              "合并 k 个有序数组", "实现快速排序", "二叉树层序遍历", "计算两个大整数字符串的乘积", "用两个栈实现队列",
              "判断括号序列是否合法", "实现前缀树 Trie", "Dijkstra 最短路径"]
ZH_TOPICS = ["春节的习俗", "如何学习一门新语言", "人工智能对就业的影响", "为什么天空是蓝色的", "怎样做一道番茄炒蛋",
             "长城的历史", "如何保持良好睡眠", "介绍一下量子计算", "城市交通拥堵的原因", "推荐几本适合大学生的书"]
EN_TOPICS = ["the causes of the French Revolution", "how vaccines work", "tips for writing a good resume", "the history of the internet",
             "why the ocean is salty", "how to start running", "the pros and cons of remote work", "black holes", "photosynthesis",
             "how a CPU executes instructions"]
LANGS = ["Python", "C++", "Java", "Go", "Rust"]


def make(task: str, rng: random.Random) -> tuple[str, str | None]:
    if task == "math":
        a, b, c = rng.randint(12, 99), rng.randint(12, 99), rng.randint(2, 9)
        kind = rng.choice(["mul", "word", "mix"])
        if kind == "mul":
            return f"What is {a}*{b}? Reply with only the integer.", str(a * b)
        if kind == "word":
            return (f"A shop sells pencils in boxes of {c}. Tom buys {a} boxes and gives away {b} pencils. "
                    f"How many pencils does he have left? Reply with only the integer."), str(a * c - b)
        return f"Compute ({a}+{b})*{c}-{a}. Reply with only the integer.", str((a + b) * c - a)
    if task == "code":
        return f"用 {rng.choice(LANGS)} 写一个函数：{rng.choice(CODE_TASKS)}。给出完整代码和简短说明。", None
    if task == "zh":
        return f"请用 200 字左右介绍：{rng.choice(ZH_TOPICS)}。", None
    if task == "en":
        return f"Explain {rng.choice(EN_TOPICS)} in about 150 words.", None
    raise ValueError(task)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base-url", default=os.environ.get("LAB_BASE_URL", "http://127.0.0.1:8000/v1"))
    ap.add_argument("--api-key", default=os.environ.get("LAB_API_KEY", "EMPTY"))
    ap.add_argument("--model")
    ap.add_argument("--task", choices=["math", "code", "zh", "en"], required=True)
    ap.add_argument("-n", type=int, default=50)
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--temperature", type=float, default=None)
    ap.add_argument("--extra-body", default="{}")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    c = OpenAI(base_url=a.base_url, api_key=a.api_key, timeout=3600)
    model = a.model or c.models.list().data[0].id
    rng = random.Random(a.seed)
    items = [make(a.task, rng) for _ in range(a.n)]
    extra = json.loads(a.extra_body)

    def one(it):
        q, ans = it
        kw = dict(model=model, messages=[{"role": "user", "content": q}], max_tokens=a.max_tokens, extra_body=extra)
        if a.temperature is not None:
            kw["temperature"] = a.temperature
        t = time.perf_counter()
        try:
            r = c.chat.completions.create(**kw)
        except Exception as e:  # noqa: BLE001
            return {"q": q, "error": str(e)}
        m = r.choices[0].message
        rc = getattr(m, "reasoning_content", None) or getattr(m, "reasoning", None) or ""
        txt = m.content or ""
        rec = {"q": q, "reply": txt, "reasoning_chars": len(rc), "seconds": time.perf_counter() - t,
               "finish": r.choices[0].finish_reason, "usage": r.usage.model_dump() if r.usage else None}
        if ans is not None:
            nums = re.findall(r"-?\d+", txt.replace(",", ""))
            rec["expected"] = ans
            rec["correct"] = bool(nums) and nums[-1] == ans
        return rec

    with cf.ThreadPoolExecutor(a.concurrency) as ex:
        recs = list(ex.map(one, items))
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w") as f:
        for r in recs:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    ok = [r for r in recs if "error" not in r]
    comp = [r["usage"]["completion_tokens"] for r in ok if r.get("usage")]
    print(f"任务 {a.task} 模型 {model}: 成功 {len(ok)}/{len(recs)}"
          + (f"，平均输出 {statistics.mean(comp):.0f} tok（中位 {statistics.median(comp):.0f}）" if comp else "")
          + (f"，平均用时 {statistics.mean(r['seconds'] for r in ok):.1f}s" if ok else ""))
    if a.task == "math" and ok:
        print(f"正确率 {sum(r.get('correct', False) for r in ok) / len(ok):.1%}")
    print(f"结果 -> {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
