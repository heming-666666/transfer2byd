#!/usr/bin/env python3
"""命令行多轮对话客户端（OpenAI 兼容接口），每个会话保存为 JSONL。

- 默认连接网关：LAB_BASE_URL（默认 http://127.0.0.1:9080/v1），LAB_API_KEY 为 API key
- 流式输出；思考内容（reasoning_content / reasoning）以灰色单独显示，不计入下一轮历史（可用 /keep-think 改变）
- 会话保存在 runtime/sessions/<日期>/<会话id>.jsonl：每行一条记录（请求参数、回复、用时、token 用量）

用法:
  export LAB_API_KEY=sk-lab-...                 # bash scripts/apikey.sh export-env <名字>
  python tools/chat_client.py                   # 自动取 /v1/models 的第一个模型
  python tools/chat_client.py --model glm-5.3-flash --extra-body '{"chat_template_kwargs":{"reasoning_effort":"low"}}'
  python tools/chat_client.py --base-url http://10.0.0.5:9080/sglang/v1

会话内命令:
  /reset 清空历史   /sys <文本> 设置系统提示   /temp <x> 温度   /max <n> 最大输出 token
  /extra <json> 设置 extra_body   /keep-think 切换是否把思考内容带入历史   /save 打印会话文件位置   /quit 退出
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import time
import uuid
from pathlib import Path

try:
    from openai import OpenAI
except ImportError:  # pragma: no cover
    sys.exit("缺少 openai 包：请用 runtime/envs/client/bin/python 运行（bash scripts/01_install_tools.sh）")

LAB_ROOT = Path(__file__).resolve().parent.parent
GREY, RESET = "\033[90m", "\033[0m"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base-url", default=os.environ.get("LAB_BASE_URL", "http://127.0.0.1:9080/v1"))
    ap.add_argument("--api-key", default=os.environ.get("LAB_API_KEY", "EMPTY"))
    ap.add_argument("--model")
    ap.add_argument("--system", default="")
    ap.add_argument("--temperature", type=float, default=None, help="不设则使用模型 generation_config 的默认值")
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--extra-body", default="{}", help="JSON，例如思考开关 chat_template_kwargs")
    ap.add_argument("--sessions-dir", type=Path, default=Path(os.environ.get("SESSIONS_DIR", LAB_ROOT / "runtime" / "sessions")))
    a = ap.parse_args()

    client = OpenAI(base_url=a.base_url, api_key=a.api_key, timeout=3600)
    model = a.model or client.models.list().data[0].id
    extra = json.loads(a.extra_body)
    sid = dt.datetime.now().strftime("%H%M%S-") + uuid.uuid4().hex[:6]
    sdir = a.sessions_dir / dt.date.today().isoformat()
    sdir.mkdir(parents=True, exist_ok=True)
    spath = sdir / f"{sid}.jsonl"
    history: list[dict] = []
    system, temperature, max_tokens, keep_think = a.system, a.temperature, a.max_tokens, False
    print(f"模型 {model} @ {a.base_url}\n会话文件 {spath}\n输入 /quit 退出，/reset 清空历史")

    def record(obj: dict) -> None:
        with spath.open("a") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")

    record({"type": "session_start", "time": dt.datetime.now().isoformat(), "model": model, "base_url": a.base_url})
    while True:
        try:
            user = input("\n你> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not user:
            continue
        if user.startswith("/"):
            cmd, _, arg = user.partition(" ")
            if cmd == "/quit":
                break
            if cmd == "/reset":
                history.clear(); print("历史已清空"); continue
            if cmd == "/sys":
                system = arg; print("系统提示已设置"); continue
            if cmd == "/temp":
                temperature = float(arg); continue
            if cmd == "/max":
                max_tokens = int(arg); continue
            if cmd == "/extra":
                extra = json.loads(arg or "{}"); print("extra_body =", extra); continue
            if cmd == "/keep-think":
                keep_think = not keep_think; print("思考内容带入历史:", keep_think); continue
            if cmd == "/save":
                print(spath); continue
            print("未知命令"); continue

        history.append({"role": "user", "content": user})
        msgs = ([{"role": "system", "content": system}] if system else []) + history
        params = {"model": model, "messages": msgs, "max_tokens": max_tokens, "stream": True,
                  "stream_options": {"include_usage": True}, "extra_body": extra}
        if temperature is not None:
            params["temperature"] = temperature
        t0 = time.perf_counter(); first = None
        content, reasoning, usage = [], [], None
        print("模型> ", end="", flush=True)
        try:
            for chunk in client.chat.completions.create(**params):
                if chunk.usage:
                    usage = chunk.usage.model_dump()
                if not chunk.choices:
                    continue
                d = chunk.choices[0].delta
                r = getattr(d, "reasoning_content", None) or getattr(d, "reasoning", None)
                if r:
                    first = first or time.perf_counter()
                    reasoning.append(r); print(f"{GREY}{r}{RESET}", end="", flush=True)
                if d.content:
                    first = first or time.perf_counter()
                    content.append(d.content); print(d.content, end="", flush=True)
        except Exception as e:  # noqa: BLE001
            print(f"\n[请求失败] {e}")
            history.pop()
            record({"type": "error", "time": dt.datetime.now().isoformat(), "user": user, "error": str(e)})
            continue
        t1 = time.perf_counter()
        reply = "".join(content)
        history.append({"role": "assistant", "content": reply if not keep_think else ("".join(reasoning) + reply)})
        ttft = (first - t0) if first else None
        print(f"\n{GREY}[TTFT {ttft:.2f}s, 总 {t1 - t0:.2f}s, usage {usage}]{RESET}" if ttft else f"\n[总 {t1 - t0:.2f}s]")
        record({"type": "turn", "time": dt.datetime.now().isoformat(), "model": model, "user": user,
                "reasoning": "".join(reasoning), "reply": reply, "ttft_s": ttft, "total_s": t1 - t0,
                "usage": usage, "params": {k: v for k, v in params.items() if k not in ("messages",)}})
    record({"type": "session_end", "time": dt.datetime.now().isoformat()})
    print(f"会话已保存: {spath}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
