#!/usr/bin/env python3
"""从 vLLM / SGLang 服务日志中提取启动阶段的关键指标。

能回答的问题：
  - 权重加载用了多久、占多少显存
  - KV cache 分到多少显存、能放多少 token、最大并发是多少
  - CUDA graph 捕获用了多久、占多少显存
  - 引擎初始化总耗时（profile + 建 KV cache + warmup）
  - 自动选用了哪些后端（attention / MoE / all-reduce）

日志格式会随版本变化，所以采用“已知正则 + 关键词兜底”：匹配不到的指标会列出含关键词的原始行，人工判读。
只依赖标准库。

用法:
  python tools/parse_server_log.py runtime/logs/engines/vllm-qwen3-8b-tp1.latest.log
  python tools/parse_server_log.py <log> --json out.json
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

NUM = r"([0-9][0-9,]*\.?[0-9]*)"

PATTERNS: dict[str, list[str]] = {
    # vLLM
    "weights_load_s": [rf"Loading weights took {NUM} seconds", rf"Model loading took .*? and {NUM} seconds",
                       # SGLang
                       rf"Load weight end\..*?elapsed[=: ]+{NUM}\s*s"],
    "weights_mem_gib": [rf"Model loading took {NUM} ?GiB", rf"Load weight end\..*?mem usage={NUM} ?GB"],
    "kv_cache_mem_gib": [rf"Available KV cache memory: {NUM} ?GiB", rf"KV Cache is allocated.*?K size: {NUM} ?GB, V size: {NUM} ?GB"],
    "kv_cache_tokens": [rf"GPU KV cache size: {NUM} tokens", rf"KV Cache is allocated\. #tokens: {NUM}",
                        rf"max_total_num_tokens={NUM}"],
    "max_concurrency_x": [rf"Maximum concurrency for {NUM} tokens per request: {NUM}x"],
    "cuda_graph_capture_s": [rf"Graph capturing finished in {NUM} secs?", rf"Capture cuda graph end\. Time elapsed: {NUM} ?s",
                             rf"[Cc]apturing CUDA graphs?.*?took {NUM} ?s"],
    "cuda_graph_mem_gib": [rf"Graph capturing finished in .*?took {NUM} ?GiB", rf"Capture cuda graph end\..*?mem usage={NUM} ?GB"],
    "engine_init_s": [rf"init engine \(profile, create kv cache, warmup model\) took {NUM} seconds"],
    "torch_compile_s": [rf"torch\.compile takes {NUM} ?s in total", rf"Compilation finished in {NUM} ?s"],
    "max_running_requests": [rf"max_running_requests={NUM}"],
    "chunked_prefill_size": [rf"chunked_prefill_size={NUM}"],
    "context_len": [rf"context_len={NUM}", rf"max_model_len={NUM}"],
    "ready_after_s": [rf"\[lab\] READY after {NUM}s"],
}

KEYWORDS = re.compile(
    r"(KV cache|KV Cache|kv_cache|cuda graph|CUDA graph|Graph captur|Capture cuda|took|elapsed|"
    r"backend|Backend|attention|Attention|all.?reduce|AllReduce|MoE|moe_runner|DeepGEMM|FlashInfer|"
    r"tensor_parallel|pipeline_parallel|expert_parallel|data_parallel|NCCL|nccl|Engram|DSpark|speculative|"
    r"WARNING|ERROR|Traceback|out of memory)", re.I)


def to_float(s: str) -> float:
    return float(s.replace(",", ""))


def parse(text: str) -> dict:
    found: dict[str, object] = {}
    for key, pats in PATTERNS.items():
        for p in pats:
            ms = list(re.finditer(p, text))
            if not ms:
                continue
            m = ms[-1]  # 取最后一次出现（多 rank 时各 rank 一般相同）
            groups = [g for g in m.groups() if g is not None]
            if key == "kv_cache_mem_gib" and len(groups) == 2:  # SGLang: K + V
                found[key] = to_float(groups[0]) + to_float(groups[1])
            elif key == "max_concurrency_x" and len(groups) == 2:
                found["max_concurrency_ctx_tokens"] = to_float(groups[0])
                found[key] = to_float(groups[1])
            else:
                found[key] = to_float(groups[-1])
            found.setdefault("_matched_lines", {})[key] = m.group(0)[:200]  # type: ignore[index]
            break
    return found


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("log", type=Path)
    ap.add_argument("--json", type=Path, help="把结果写到 JSON 文件")
    ap.add_argument("--max-lines", type=int, default=80, help="兜底打印的关键词行数上限")
    a = ap.parse_args()
    text = a.log.read_text(errors="replace")
    res = parse(text)
    print(f"# 启动指标: {a.log}")
    for k in PATTERNS:
        v = res.get(k)
        print(f"{k:28s} {v if v is not None else '未匹配'}")
    missing = [k for k in PATTERNS if k not in res]
    if missing:
        print("\n# 未匹配的指标请从下面的原始行判读（关键词过滤）:")
        n = 0
        for line in text.splitlines():
            if KEYWORDS.search(line):
                print("  " + line[:240])
                n += 1
                if n >= a.max_lines:
                    print("  ...（已截断，使用 --max-lines 调整）")
                    break
    if a.json:
        a.json.write_text(json.dumps(res, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
