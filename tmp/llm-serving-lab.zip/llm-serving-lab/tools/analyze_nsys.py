#!/usr/bin/env python3
"""分析 Nsight Systems 报告（.nsys-rep 或导出的 .sqlite）。

与 PyTorch Profiler 相比，nsys 开销更低，并且能看到 CUDA graph 内部的每个 kernel（采集时加 --cuda-graph-trace=node）。
本脚本输出：
  1. kernel 汇总（按名字/类别），每个 kernel 的 grid 大小、寄存器、共享内存，估计占用 SM 数
  2. 每个 GPU 的忙碌比例与空闲气泡
  3. CUDA Runtime/Driver API 耗时（kernel 启动、graph 启动、同步、拷贝）——即 CPU 提交开销
  4. kernel 启动延迟：API 调用开始到 kernel 在 GPU 上开始执行的间隔（排队 + 提交）
  5. 内存拷贝（H2D/D2H/D2D/P2P）字节数与带宽
  6. NVTX 区间（例如 SGLang --enable-layerwise-nvtx-marker、vLLM --enable-layerwise-nvtx-tracing 产生的逐层标注）
依赖：Python 标准库 sqlite3；输入 .nsys-rep 时需要系统中有 nsys 命令（自动执行 nsys export）。
nsys 的 SQLite 表结构随版本略有变化：脚本按列名自省，缺列时跳过对应统计并提示。

用法:
  python tools/analyze_nsys.py report.nsys-rep --sm-count 132 --md report.md
  python tools/analyze_nsys.py report.sqlite --top 40
另外推荐直接看 nsys 自带报表：
  nsys stats -r cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum,cuda_gpu_mem_size_sum,nvtx_sum report.nsys-rep
"""
from __future__ import annotations

import argparse
import json
import shutil
import sqlite3
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyze_torch_trace import categorize, merge_intervals, short  # noqa: E402

COPY_KIND = {1: "H2D", 2: "D2H", 8: "D2D", 10: "P2P"}


def to_sqlite(path: Path) -> Path:
    if path.suffix == ".sqlite":
        return path
    out = path.with_suffix(".sqlite")
    if out.exists():
        return out
    nsys = shutil.which("nsys")
    if not nsys:
        sys.exit("需要 nsys 命令把 .nsys-rep 导出为 sqlite（或手动: nsys export --type sqlite -o x.sqlite x.nsys-rep）")
    subprocess.run([nsys, "export", "--type", "sqlite", "--force-overwrite", "true", "-o", str(out), str(path)], check=True)
    return out


def cols(con: sqlite3.Connection, table: str) -> set[str]:
    try:
        return {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
    except sqlite3.Error:
        return set()


def has_table(con: sqlite3.Connection, table: str) -> bool:
    return con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def analyze(db: Path, sm_override: int | None, top: int, gap_us: float) -> dict:
    con = sqlite3.connect(str(db))
    notes: list[str] = []
    strings = {}
    if has_table(con, "StringIds"):
        strings = dict(con.execute("SELECT id, value FROM StringIds"))

    sm_count = sm_override
    gpus = []
    if has_table(con, "TARGET_INFO_GPU"):
        c = cols(con, "TARGET_INFO_GPU")
        fields = [f for f in ("id", "name", "smCount", "totalMemory", "memoryBandwidth", "clockRate") if f in c]
        for row in con.execute(f"SELECT {', '.join(fields)} FROM TARGET_INFO_GPU"):
            gpus.append(dict(zip(fields, row)))
        if sm_count is None and gpus and gpus[0].get("smCount"):
            sm_count = int(gpus[0]["smCount"])
    if sm_count is None:
        sm_count = 132
        notes.append("报告中没有 SM 数，按 132 估算（可用 --sm-count 指定）")

    report: dict = {"file": str(db), "sm_count": sm_count, "gpus": gpus, "notes": notes}

    # ---- kernels ----
    kt = "CUPTI_ACTIVITY_KIND_KERNEL"
    if not has_table(con, kt):
        report["error"] = "没有 CUPTI_ACTIVITY_KIND_KERNEL 表：采集时需要 --trace=cuda"
        return report
    kc = cols(con, kt)
    name_col = "demangledName" if "demangledName" in kc else ("shortName" if "shortName" in kc else None)
    want = ["start", "end", "deviceId", "streamId", "gridX", "gridY", "gridZ", "blockX", "blockY", "blockZ",
            "registersPerThread", "staticSharedMemory", "dynamicSharedMemory", "correlationId", "graphId"]
    sel = [c for c in want if c in kc]
    if name_col:
        sel.append(name_col)
    rows = [dict(zip(sel, r)) for r in con.execute(f"SELECT {', '.join(sel)} FROM {kt}")]
    for r in rows:
        r["name"] = strings.get(r.get(name_col), str(r.get(name_col))) if name_col else "?"
        r["dur"] = (r["end"] - r["start"]) / 1e3  # ns -> us
        if all(k in r for k in ("gridX", "gridY", "gridZ")):
            r["blocks"] = r["gridX"] * r["gridY"] * r["gridZ"]
    t0 = min(r["start"] for r in rows) if rows else 0
    total_us = sum(r["dur"] for r in rows)
    report["num_kernels"] = len(rows)
    report["kernel_time_ms"] = total_us / 1e3
    if "graphId" in kc:
        in_graph = sum(r["dur"] for r in rows if r.get("graphId"))
        report["kernel_time_in_cuda_graph_pct"] = 100 * in_graph / total_us if total_us else 0

    by_cat: dict[str, float] = defaultdict(float)
    by_name: dict[str, dict] = {}
    buckets = {"<25% SM": 0.0, "25-50% SM": 0.0, "50-100% SM": 0.0, "≥1 波(全部SM)": 0.0, "未知": 0.0}
    per_dev: dict[int, list] = defaultdict(list)
    for r in rows:
        c = categorize(r["name"])
        by_cat[c] += r["dur"]
        e = by_name.setdefault(r["name"], {"name": r["name"], "cat": c, "count": 0, "total_us": 0.0, "bt": 0.0,
                                            "regs": r.get("registersPerThread"),
                                            "smem": (r.get("staticSharedMemory") or 0) + (r.get("dynamicSharedMemory") or 0),
                                            "block": [r.get("blockX"), r.get("blockY"), r.get("blockZ")]})
        e["count"] += 1
        e["total_us"] += r["dur"]
        b = r.get("blocks")
        if b:
            e["bt"] += b * r["dur"]
            f = b / sm_count
            buckets["<25% SM" if f < .25 else "25-50% SM" if f < .5 else "50-100% SM" if f < 1 else "≥1 波(全部SM)"] += r["dur"]
        else:
            buckets["未知"] += r["dur"]
        per_dev[int(r.get("deviceId", 0) or 0)].append((r["start"] / 1e3, r["end"] / 1e3))
    tops = sorted(by_name.values(), key=lambda e: -e["total_us"])[:top]
    for e in tops:
        e["avg_us"] = e["total_us"] / e["count"]
        e["pct"] = 100 * e["total_us"] / total_us
        e["avg_blocks"] = e["bt"] / e["total_us"] if e["bt"] else None
        e["est_sms"] = min(e["avg_blocks"], sm_count) if e["avg_blocks"] else None
    report["category_pct"] = {k: 100 * v / total_us for k, v in sorted(by_cat.items(), key=lambda kv: -kv[1])}
    report["sm_coverage_pct"] = {k: 100 * v / total_us for k, v in buckets.items()}
    report["top_kernels"] = tops

    devs = {}
    for d, iv in sorted(per_dev.items()):
        m = merge_intervals(iv)
        span = m[-1][1] - m[0][0]
        busy = sum(e - s for s, e in m)
        gaps = sorted(((m[i + 1][0] - m[i][1], m[i][1]) for i in range(len(m) - 1)), reverse=True)
        big = [g for g in gaps if g[0] >= gap_us]
        devs[d] = {"span_ms": span / 1e3, "busy_ratio": busy / span if span else 0, "num_gaps_ge_threshold": len(big),
                   "gap_time_ms": sum(g for g, _ in big) / 1e3,
                   "top_gaps": [{"gap_us": round(g, 1), "at_ms": round((t - t0 / 1e3) / 1e3, 3)} for g, t in big[:8]]}
    report["devices"] = devs

    # ---- CUDA API（CPU 端） ----
    api_rows = []
    for t in ("CUPTI_ACTIVITY_KIND_RUNTIME", "CUPTI_ACTIVITY_KIND_DRIVER"):
        if has_table(con, t) and {"start", "end", "nameId"} <= cols(con, t):
            cc = cols(con, t)
            corr = "correlationId" if "correlationId" in cc else "NULL"
            api_rows += [{"start": s, "end": e, "name": strings.get(n, str(n)), "corr": c}
                         for s, e, n, c in con.execute(f"SELECT start, end, nameId, {corr} FROM {t}")]
    if api_rows:
        stat: dict[str, dict] = defaultdict(lambda: {"count": 0, "total_us": 0.0})
        for a in api_rows:
            st = stat[a["name"]]
            st["count"] += 1
            st["total_us"] += (a["end"] - a["start"]) / 1e3
        report["cuda_api_top"] = sorted(({"name": k, **v, "avg_us": v["total_us"] / v["count"]} for k, v in stat.items()),
                                        key=lambda r: -r["total_us"])[:20]
        # 启动延迟：API 开始 -> 对应 kernel 开始
        k_by_corr = {r["correlationId"]: r["start"] for r in rows if r.get("correlationId")}
        lat = [(k_by_corr[a["corr"]] - a["start"]) / 1e3 for a in api_rows
               if a["corr"] in k_by_corr and "aunch" in a["name"]]
        if lat:
            lat.sort()
            q = lambda p: lat[min(len(lat) - 1, int(p * len(lat)))]  # noqa: E731
            report["launch_to_exec_us"] = {"n": len(lat), "p50": q(.5), "p90": q(.9), "p99": q(.99), "max": lat[-1]}
    else:
        notes.append("没有 CUDA API 表：采集时需要 --trace=cuda")

    # ---- 内存拷贝 ----
    mt = "CUPTI_ACTIVITY_KIND_MEMCPY"
    if has_table(con, mt) and {"bytes", "copyKind", "start", "end"} <= cols(con, mt):
        agg: dict[str, dict] = defaultdict(lambda: {"count": 0, "bytes": 0, "time_us": 0.0})
        for b, k, s, e in con.execute(f"SELECT bytes, copyKind, start, end FROM {mt}"):
            g = agg[COPY_KIND.get(k, str(k))]
            g["count"] += 1; g["bytes"] += b; g["time_us"] += (e - s) / 1e3
        report["memcpy"] = {k: {**v, "GBps": v["bytes"] / (v["time_us"] * 1e3) if v["time_us"] else None} for k, v in agg.items()}

    # ---- NVTX ----
    if has_table(con, "NVTX_EVENTS"):
        nc = cols(con, "NVTX_EVENTS")
        if {"start", "end"} <= nc:
            txt = "COALESCE(text, '')" if "text" in nc else "''"
            tid = "textId" if "textId" in nc else "NULL"
            st: dict[str, dict] = defaultdict(lambda: {"count": 0, "total_us": 0.0})
            for s, e, t, ti in con.execute(f"SELECT start, end, {txt}, {tid} FROM NVTX_EVENTS WHERE end IS NOT NULL"):
                name = t or strings.get(ti, "") or "?"
                name = name.split("{")[0][:80]
                st[name]["count"] += 1
                st[name]["total_us"] += (e - s) / 1e3
            report["nvtx_top"] = sorted(({"name": k, **v} for k, v in st.items()), key=lambda r: -r["total_us"])[:25]
    return report


def to_md(r: dict) -> str:
    if "error" in r:
        return f"# {r['file']}\n\n错误: {r['error']}\n"
    L = [f"# nsys 分析: {Path(r['file']).name}", "", f"- GPU: {[g.get('name') for g in r['gpus']]}，SM 数 {r['sm_count']}",
         f"- kernel {r['num_kernels']} 个，总 {r['kernel_time_ms']:.2f} ms"]
    if "kernel_time_in_cuda_graph_pct" in r:
        L.append(f"- 在 CUDA graph 中执行的 kernel 时间占 {r['kernel_time_in_cuda_graph_pct']:.1f}%")
    if "launch_to_exec_us" in r:
        x = r["launch_to_exec_us"]
        L.append(f"- 启动 API 到 kernel 开始执行：p50 {x['p50']:.1f} us，p90 {x['p90']:.1f} us，p99 {x['p99']:.1f} us（n={x['n']}）")
    L += [f"- 提示: {n}" for n in r["notes"]]
    L += ["", "## GPU 忙碌", "", "| 设备 | 跨度 ms | 忙碌比例 | 大气泡数 | 气泡总 ms |", "|---|---|---|---|---|"]
    for d, v in r["devices"].items():
        L.append(f"| {d} | {v['span_ms']:.2f} | {v['busy_ratio']:.1%} | {v['num_gaps_ge_threshold']} | {v['gap_time_ms']:.2f} |")
    L += ["", "## 类别占比", ""] + [f"- {k}: {v:.1f}%" for k, v in r["category_pct"].items()]
    L += ["", "## SM 覆盖（按 kernel 时间加权）", ""] + [f"- {k}: {v:.1f}%" for k, v in r["sm_coverage_pct"].items()]
    L += ["", "## Top kernels", "", "| # | 类别 | 次数 | 总 ms | 平均 us | 占比 | 平均 blocks | 估计 SM | 寄存器/线程 | 共享内存 B | block | kernel |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for i, k in enumerate(r["top_kernels"], 1):
        ab = f"{k['avg_blocks']:.0f}" if k["avg_blocks"] else "-"
        es = f"{k['est_sms']:.0f}" if k["est_sms"] else "-"
        L.append(f"| {i} | {k['cat']} | {k['count']} | {k['total_us'] / 1e3:.2f} | {k['avg_us']:.1f} | {k['pct']:.1f}% | {ab} | {es} | "
                 f"{k['regs']} | {k['smem']} | {k['block']} | `{short(k['name'])}` |")
    if r.get("cuda_api_top"):
        L += ["", "## CUDA API（CPU 端）", "", "| API | 次数 | 总 ms | 平均 us |", "|---|---|---|---|"]
        L += [f"| {a['name']} | {a['count']} | {a['total_us'] / 1e3:.2f} | {a['avg_us']:.1f} |" for a in r["cuda_api_top"]]
    if r.get("memcpy"):
        L += ["", "## 内存拷贝", "", "| 方向 | 次数 | MB | 时间 ms | GB/s |", "|---|---|---|---|---|"]
        for k, v in r["memcpy"].items():
            bw = f"{v['GBps']:.1f}" if v["GBps"] else "-"
            L.append(f"| {k} | {v['count']} | {v['bytes'] / 1e6:.1f} | {v['time_us'] / 1e3:.2f} | {bw} |")
    if r.get("nvtx_top"):
        L += ["", "## NVTX 区间", "", "| 名称 | 次数 | 总 ms |", "|---|---|---|"]
        L += [f"| `{n['name']}` | {n['count']} | {n['total_us'] / 1e3:.2f} |" for n in r["nvtx_top"]]
    return "\n".join(L) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("report", type=Path)
    ap.add_argument("--sm-count", type=int)
    ap.add_argument("--top", type=int, default=30)
    ap.add_argument("--gap-us", type=float, default=50.0)
    ap.add_argument("--md", type=Path)
    ap.add_argument("--json", type=Path)
    a = ap.parse_args()
    r = analyze(to_sqlite(a.report), a.sm_count, a.top, a.gap_us)
    md = to_md(r)
    print(md)
    if a.md:
        a.md.write_text(md)
    if a.json:
        a.json.write_text(json.dumps(r, ensure_ascii=False, indent=1, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
