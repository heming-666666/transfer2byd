#!/usr/bin/env python3
"""比较压测前后两份 Prometheus /metrics 快照，输出计数器增量和派生指标。

派生指标（指标名存在时才计算）：
  - 前缀缓存命中率   vllm:prefix_cache_hits / vllm:prefix_cache_queries
  - 投机解码接受率   vllm:spec_decode_num_accepted_tokens / vllm:spec_decode_num_draft_tokens
  - 平均接受长度     1 + accepted / drafts
  - 抢占次数         vllm:num_preemptions
  - 生成 / 预填充 token 数
SGLang 的指标名以 sglang: 开头（需要启动参数 --enable-metrics），同样列出所有变化的计数器。
直方图（*_bucket/_sum/_count）会给出区间内的平均值。只依赖标准库。

用法: python tools/metrics_diff.py before.prom after.prom
"""
from __future__ import annotations

import re
import sys
from collections import defaultdict

LINE = re.compile(r'^([a-zA-Z_:][a-zA-Z0-9_:]*)(\{[^}]*\})?\s+([-+0-9.eE]+|NaN|\+Inf|-Inf)')


def load(path: str) -> dict[str, float]:
    vals: dict[str, float] = defaultdict(float)
    with open(path, errors="replace") as f:
        for line in f:
            if line.startswith("#"):
                continue
            m = LINE.match(line.strip())
            if not m:
                continue
            name, labels, v = m.group(1), m.group(2) or "", m.group(3)
            try:
                x = float(v)
            except ValueError:
                continue
            # 去掉 model_name / engine 等标签，把同名指标求和（多 DP rank 时合并）
            if "le=" in labels:
                le = re.search(r'le="([^"]+)"', labels)
                name = f"{name}{{le={le.group(1)}}}" if le else name
            vals[name] += x
    return vals


def pick(d: dict[str, float], *cands: str) -> float | None:
    for c in cands:
        for suffix in ("_total", ""):
            if c + suffix in d:
                return d[c + suffix]
    return None


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 1
    before, after = load(sys.argv[1]), load(sys.argv[2])
    delta = {k: after[k] - before.get(k, 0.0) for k in after}

    print("# 派生指标")
    hits = pick(delta, "vllm:prefix_cache_hits", "vllm:gpu_prefix_cache_hits")
    queries = pick(delta, "vllm:prefix_cache_queries", "vllm:gpu_prefix_cache_queries")
    if hits is not None and queries:
        print(f"前缀缓存命中率           {hits / queries:.3f}  ({hits:.0f}/{queries:.0f} tokens)")
    acc = pick(delta, "vllm:spec_decode_num_accepted_tokens")
    draft = pick(delta, "vllm:spec_decode_num_draft_tokens")
    drafts = pick(delta, "vllm:spec_decode_num_drafts")
    if acc is not None and draft:
        print(f"投机解码 token 接受率     {acc / draft:.3f}  ({acc:.0f}/{draft:.0f})")
    if acc is not None and drafts:
        print(f"平均接受长度（含1个目标token） {1 + acc / drafts:.2f}")
    pre = pick(delta, "vllm:num_preemptions")
    if pre is not None:
        print(f"抢占次数                 {pre:.0f}")
    for label, names in [("生成 token 数", ("vllm:generation_tokens", "sglang:generation_tokens")),
                         ("预填充 token 数", ("vllm:prompt_tokens", "sglang:prompt_tokens"))]:
        v = pick(delta, *names)
        if v is not None:
            print(f"{label:24s} {v:.0f}")

    print("\n# 直方图区间均值（sum/count）")
    for k in sorted(delta):
        if k.endswith("_sum"):
            base = k[:-4]
            c = delta.get(base + "_count", 0.0)
            if c > 0:
                print(f"{base:70s} mean={delta[k] / c:.6g}  n={c:.0f}")

    print("\n# 变化的计数器（前 200 个）")
    n = 0
    for k in sorted(delta):
        if "{le=" in k or k.endswith(("_sum", "_count")):
            continue
        if abs(delta[k]) > 0:
            print(f"{k:70s} {delta[k]:.6g}")
            n += 1
            if n >= 200:
                break
    return 0


if __name__ == "__main__":
    sys.exit(main())
