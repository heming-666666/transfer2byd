#!/usr/bin/env python3
"""服务冒烟测试：逐项检查一个 OpenAI 兼容服务的基础功能，输出通过/失败表并保存 JSON 报告。

检查项：
  models        GET /v1/models 能列出模型
  chat          非流式对话，答案正确（17*19=323）
  stream        流式输出，记录首 token 时间
  usage         返回 token 用量
  reasoning     思考内容与正文分离（reasoning_content / reasoning 字段）——需要服务端开启 reasoning parser
  tools         工具调用：返回 tool_calls 且参数是合法 JSON——需要 tool-call parser
  json_schema   response_format=json_schema，输出可解析且字段齐全
  vision        发送一张代码生成的纯红色 PNG，回答应包含“红/red”（--vision 开启；纯文本模型跳过）
  auth          （经网关时）无 key 请求应返回 401
只依赖 openai 与标准库。

用法:
  python tools/smoke_test.py --base-url http://127.0.0.1:9080/v1 --api-key $LAB_API_KEY
  python tools/smoke_test.py --base-url http://127.0.0.1:8000/v1 --no-auth-check --vision \
      --extra-body '{"chat_template_kwargs":{"thinking":false}}' --out runtime/results/E01/smoke.json
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import struct
import sys
import time
import urllib.error
import urllib.request
import zlib

from openai import OpenAI


def red_png(n: int = 64) -> str:
    """生成 n×n 纯红 PNG，返回 data URL（不依赖 PIL）。"""
    raw = b"".join(b"\x00" + b"\xff\x00\x00" * n for _ in range(n))

    def chunk(t: bytes, d: bytes) -> bytes:
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", n, n, 8, 2, 0, 0, 0)) + \
        chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    return "data:image/png;base64," + base64.b64encode(png).decode()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base-url", default=os.environ.get("LAB_BASE_URL", "http://127.0.0.1:9080/v1"))
    ap.add_argument("--api-key", default=os.environ.get("LAB_API_KEY", "EMPTY"))
    ap.add_argument("--model")
    ap.add_argument("--max-tokens", type=int, default=8192, help="思考模型需要较大的预算，否则 content 可能为空")
    ap.add_argument("--extra-body", default="{}")
    ap.add_argument("--vision", action="store_true")
    ap.add_argument("--no-auth-check", action="store_true")
    ap.add_argument("--out")
    a = ap.parse_args()
    extra = json.loads(a.extra_body)
    c = OpenAI(base_url=a.base_url, api_key=a.api_key, timeout=1800)
    results: list[dict] = []

    def run(name: str, fn) -> None:
        t = time.perf_counter()
        try:
            ok, detail = fn()
        except Exception as e:  # noqa: BLE001
            ok, detail = False, f"{type(e).__name__}: {e}"
        results.append({"check": name, "ok": ok, "seconds": round(time.perf_counter() - t, 2), "detail": str(detail)[:300]})
        print(f"[{'通过' if ok else '失败'}] {name:12s} {results[-1]['seconds']:7.2f}s  {str(detail)[:150]}")

    model = a.model
    def t_models():
        nonlocal model
        ids = [m.id for m in c.models.list().data]
        model = model or ids[0]
        return bool(ids), ids
    run("models", t_models)
    msg = [{"role": "user", "content": "What is 17*19? Reply with only the integer."}]

    def t_chat():
        r = c.chat.completions.create(model=model, messages=msg, max_tokens=a.max_tokens, extra_body=extra)
        txt = r.choices[0].message.content or ""
        return "323" in txt, {"content": txt[-120:], "finish": r.choices[0].finish_reason, "usage": r.usage.model_dump() if r.usage else None}
    run("chat", t_chat)

    def t_stream():
        t0 = time.perf_counter(); first = None; n = 0; text = []; usage = None
        for ch in c.chat.completions.create(model=model, messages=msg, max_tokens=a.max_tokens, stream=True,
                                            stream_options={"include_usage": True}, extra_body=extra):
            if ch.usage:
                usage = ch.usage
            if ch.choices:
                d = ch.choices[0].delta
                piece = (d.content or "") + (getattr(d, "reasoning_content", None) or getattr(d, "reasoning", None) or "")
                if piece:
                    first = first or time.perf_counter(); n += 1; text.append(d.content or "")
        return n > 0, {"ttft_s": round(first - t0, 3) if first else None, "chunks": n, "usage": usage.model_dump() if usage else None,
                       "content_tail": "".join(text)[-80:]}
    run("stream", t_stream)

    def t_usage():
        r = c.chat.completions.create(model=model, messages=[{"role": "user", "content": "Say hi."}], max_tokens=a.max_tokens, extra_body=extra)
        u = r.usage
        return bool(u and u.prompt_tokens and u.completion_tokens), u.model_dump() if u else None
    run("usage", t_usage)

    def t_reasoning():
        r = c.chat.completions.create(model=model, messages=[{"role": "user", "content": "Is 391 prime? Think briefly."}],
                                      max_tokens=a.max_tokens, extra_body=extra)
        m = r.choices[0].message
        rc = getattr(m, "reasoning_content", None) or getattr(m, "reasoning", None)
        return rc is not None, {"reasoning_len": len(rc or ""), "content_tail": (m.content or "")[-100:]}
    run("reasoning", t_reasoning)

    tools = [{"type": "function", "function": {"name": "get_weather", "description": "Get the current weather for a city",
              "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}}}]

    def t_tools():
        r = c.chat.completions.create(model=model, messages=[{"role": "user", "content": "What's the weather in Beijing? Use the tool."}],
                                      tools=tools, tool_choice="auto", max_tokens=a.max_tokens, extra_body=extra)
        tc = r.choices[0].message.tool_calls
        if not tc:
            return False, {"finish": r.choices[0].finish_reason, "content_tail": (r.choices[0].message.content or "")[-150:]}
        args = json.loads(tc[0].function.arguments)
        return tc[0].function.name == "get_weather" and "city" in args, {"name": tc[0].function.name, "args": args}
    run("tools", t_tools)

    schema = {"type": "object", "properties": {"city": {"type": "string"}, "population_millions": {"type": "number"}},
              "required": ["city", "population_millions"], "additionalProperties": False}

    def t_json():
        r = c.chat.completions.create(model=model, messages=[{"role": "user", "content": "Give the largest city in Japan and its population in millions as JSON."}],
                                      response_format={"type": "json_schema", "json_schema": {"name": "city", "schema": schema}},
                                      max_tokens=a.max_tokens, extra_body=extra)
        obj = json.loads(r.choices[0].message.content)
        return set(schema["required"]) <= set(obj), obj
    run("json_schema", t_json)

    if a.vision:
        def t_vision():
            r = c.chat.completions.create(model=model, messages=[{"role": "user", "content": [
                {"type": "image_url", "image_url": {"url": red_png()}},
                {"type": "text", "text": "What single color fills this image? Answer with one word."}]}],
                max_tokens=a.max_tokens, extra_body=extra)
            txt = (r.choices[0].message.content or "").lower()
            return ("red" in txt or "红" in txt), txt[-80:]
        run("vision", t_vision)

    if not a.no_auth_check:
        def t_auth():
            req = urllib.request.Request(a.base_url.rstrip("/") + "/models")
            try:
                urllib.request.urlopen(req, timeout=10)
                return False, "无 key 请求成功了（未鉴权）"
            except urllib.error.HTTPError as e:
                return e.code == 401, f"HTTP {e.code}"
        run("auth", t_auth)

    passed = sum(r["ok"] for r in results)
    print(f"\n{passed}/{len(results)} 项通过  模型={model}")
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        with open(a.out, "w") as f:
            json.dump({"base_url": a.base_url, "model": model, "extra_body": extra, "results": results}, f, ensure_ascii=False, indent=1)
        print(f"报告 -> {a.out}")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
