#!/usr/bin/env python3
"""汇总一个实验目录下所有压测结果，输出 Markdown 表格和 CSV。

识别两种结果文件：
  - vLLM  `vllm bench serve --save-result`  生成的 result.json
  - SGLang `sglang.benchmark.serving --output-file` 生成的 result.jsonl（每行一次运行，取最后一行）
每个结果目录的 meta.json 提供标签和时间。只依赖标准库。

用法:
  python tools/collect_bench.py runtime/results/E20
  python tools/collect_bench.py runtime/results/E02 --csv e02.csv --sort label
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

COLUMNS = [
    ("label", "标签"),
    ("tool", "工具"),
    ("max_concurrency", "并发上限"),
    ("request_rate", "请求率"),
    ("completed", "完成数"),
    ("request_throughput", "req/s"),
    ("output_throughput", "输出tok/s"),
    ("total_token_throughput", "总tok/s"),
    ("mean_ttft_ms", "TTFT均值"),
    ("median_ttft_ms", "TTFT中位"),
    ("p99_ttft_ms", "TTFT P99"),
    ("mean_tpot_ms", "TPOT均值"),
    ("median_tpot_ms", "TPOT中位"),
    ("p99_tpot_ms", "TPOT P99"),
    ("p99_itl_ms", "ITL P99"),
    ("request_goodput", "goodput req/s"),
    ("slo_attainment", "SLO达成率"),
    ("accept_length", "接受长度"),
]


def load_result(run_dir: Path) -> dict | None:
    meta = {}
    if (run_dir / "meta.json").exists():
        meta = json.loads((run_dir / "meta.json").read_text())
    row: dict = {"label": meta.get("label", run_dir.name), "run_dir": str(run_dir), "created": meta.get("created", "")}
    vj = run_dir / "result.json"
    sj = run_dir / "result.jsonl"
    data = None
    if vj.exists():
        data = json.loads(vj.read_text())
        row["tool"] = "vllm"
    elif sj.exists():
        lines = [l for l in sj.read_text().splitlines() if l.strip()]
        if lines:
            data = json.loads(lines[-1])
            row["tool"] = "sglang"
    if data is None:
        return None
    for k, _ in COLUMNS:
        if k in ("label", "tool"):
            continue
        if k in data and not isinstance(data[k], (list, dict)):
            row[k] = data[k]
    # 字段别名
    if "max_concurrency" not in row and "max_concurrent_requests" in data:
        row["max_concurrency"] = data["max_concurrent_requests"]
    if "completed" not in row and "ttfts" in data:
        row["completed"] = sum(1 for t in data["ttfts"] if t)
    return row


def fmt(v) -> str:
    if v is None or v == "":
        return "-"
    if isinstance(v, float):
        return f"{v:.3g}" if abs(v) < 100 else f"{v:.0f}"
    return str(v)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("exp_dir", type=Path)
    ap.add_argument("--csv", type=Path)
    ap.add_argument("--sort", default="created", help="排序字段（默认按时间）")
    a = ap.parse_args()
    rows = []
    for d in sorted(p for p in a.exp_dir.rglob("meta.json")):
        r = load_result(d.parent)
        if r:
            rows.append(r)
    if not rows:
        print(f"{a.exp_dir} 下没有找到 result.json / result.jsonl")
        return 1
    rows.sort(key=lambda r: str(r.get(a.sort, "")))
    print("| " + " | ".join(h for _, h in COLUMNS) + " |")
    print("|" + "---|" * len(COLUMNS))
    for r in rows:
        print("| " + " | ".join(fmt(r.get(k)) for k, _ in COLUMNS) + " |")
    if a.csv:
        keys = [k for k, _ in COLUMNS] + ["run_dir", "created"]
        with a.csv.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        print(f"\nCSV -> {a.csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
