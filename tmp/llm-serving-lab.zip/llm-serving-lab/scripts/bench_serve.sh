#!/usr/bin/env bash
# 在线服务压测封装：调用 vLLM 的 `vllm bench serve` 或 SGLang 的 `python -m sglang.benchmark.serving`，
# 自动建结果目录、采样 GPU、抓取 /metrics 前后快照、保存环境信息。
#
# 用法：
#   bash scripts/bench_serve.sh --tool vllm --exp E20 --label c16 --instance vllm-glm53-tp8 -- \
#        --dataset-name random --random-input-len 2048 --random-output-len 512 --num-prompts 160 --max-concurrency 16
#   bash scripts/bench_serve.sh --tool sglang --exp E20 --label c16 --instance sglang-glm53-tp8 -- \
#        --dataset-name random --random-input-len 2048 --random-output-len 512 --num-prompts 160 --max-concurrency 16
# 选项：
#   --tool vllm|sglang     使用哪个压测客户端（与被测引擎无关，两者都能压 OpenAI 兼容接口）
#   --instance <实例名>    被测实例（从 runtime/state 读端口、模型、served name）
#   --via-gateway          经网关压测（会带上第一个 API key），默认直连引擎端口
#   --base-url <URL>       手动指定地址（覆盖 --instance 的端口）
#   --exp/--label          结果目录 runtime/results/<exp>/<时间>-<label>/
#   --no-monitor           不采样 GPU
# -- 之后的参数原样传给压测客户端。
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
TOOL=""; INSTANCE=""; VIA_GW=0; BASE_URL=""; EXP="misc"; LABEL="bench"; MON=1; EXTRA=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --tool) TOOL="$2"; shift 2 ;;
    --instance) INSTANCE="$2"; shift 2 ;;
    --via-gateway) VIA_GW=1; shift ;;
    --base-url) BASE_URL="$2"; shift 2 ;;
    --exp) EXP="$2"; shift 2 ;;
    --label) LABEL="$2"; shift 2 ;;
    --no-monitor) MON=0; shift ;;
    --) shift; EXTRA=("$@"); break ;;
    *) die "未知选项 $1" ;;
  esac
done
[[ "${TOOL}" == "vllm" || "${TOOL}" == "sglang" ]] || die "--tool 必须是 vllm 或 sglang"
[[ -n "${INSTANCE}" ]] || die "需要 --instance"
STATE="${STATE_DIR}/${INSTANCE}.env"; [[ -f "${STATE}" ]] || die "没有实例 ${INSTANCE}"
# shellcheck disable=SC1090
source "${STATE}"
ENGINE_PORT_="${PORT}"
if [[ -z "${BASE_URL}" ]]; then
  if (( VIA_GW )); then
    BASE_URL="http://127.0.0.1:${GATEWAY_PORT}"
    [[ "${FRAMEWORK}" == "${GATEWAY_DEFAULT_UPSTREAM}" ]] || BASE_URL="${BASE_URL}/${FRAMEWORK}"
  else
    BASE_URL="http://127.0.0.1:${ENGINE_PORT_}"
  fi
fi
KEY_ENV=()
(( VIA_GW )) && KEY_ENV=(-e "OPENAI_API_KEY=$(first_api_key)")

RUN="$(new_run_dir "${EXP}" "${LABEL}")"
log "结果目录: ${RUN}"
bash "${LAB_ROOT}/scripts/collect_env.sh" "${INSTANCE}" "${RUN}"
curl -s "http://127.0.0.1:${ENGINE_PORT_}/metrics" > "${RUN}/metrics-before.prom" || true
(( MON )) && bash "${LAB_ROOT}/scripts/gpu_monitor.sh" start "${RUN}"

if [[ "${ENGINE_MODE}" == "docker" ]]; then
  OUT="/results/${RUN#"${RESULTS_DIR}"/}"; TOK="/models/${MODEL_KEY}"
else
  OUT="${RUN}"; TOK="${MODELS_DIR}/${MODEL_KEY}"
  # venv 模式下把容器路径 /datasets/ 换成宿主机路径
  for i in "${!EXTRA[@]}"; do EXTRA[i]="${EXTRA[i]/#\/datasets\//${RUNTIME_DIR}/datasets/}"; done
fi
if [[ "${TOOL}" == "vllm" ]]; then
  CMD=(vllm bench serve --base-url "${BASE_URL}" --model "${SERVED_NAME}" --tokenizer "${TOK}"
       --save-result --save-detailed --result-dir "${OUT}" --result-filename result.json "${EXTRA[@]}")
  IMG="${VLLM_IMAGE}"
else
  CMD=(python3 -m sglang.benchmark.serving --backend sglang-oai --base-url "${BASE_URL}" --model "${SERVED_NAME}"
       --tokenizer "${TOK}" --output-file "${OUT}/result.jsonl" --output-details "${EXTRA[@]}")
  IMG="${SGLANG_IMAGE}"
fi
printf '%q ' "${CMD[@]}" > "${RUN}/bench_cmd.txt"; echo >> "${RUN}/bench_cmd.txt"

set +e
if [[ "${ENGINE_MODE}" == "docker" ]]; then
  docker run --rm --network host --entrypoint "${CMD[0]}" \
    -v "${MODELS_DIR}:/models:ro" -v "${RESULTS_DIR}:/results" -v "${RUNTIME_DIR}/datasets:/datasets:ro" \
    -e HF_HUB_OFFLINE=1 "${KEY_ENV[@]}" "${IMG}" "${CMD[@]:1}" 2>&1 | tee "${RUN}/bench.log"
  rc=${PIPESTATUS[0]}
else
  ( export PATH="${ENVS_DIR}/${TOOL}/bin:${PATH}" HF_HUB_OFFLINE=1
    (( VIA_GW )) && export OPENAI_API_KEY="$(first_api_key)"
    "${CMD[@]}" ) 2>&1 | tee "${RUN}/bench.log"
  rc=${PIPESTATUS[0]}
fi
set -e

(( MON )) && bash "${LAB_ROOT}/scripts/gpu_monitor.sh" stop "${RUN}"
curl -s "http://127.0.0.1:${ENGINE_PORT_}/metrics" > "${RUN}/metrics-after.prom" || true
if [[ -x "${CLIENT_PY}" ]]; then
  "${CLIENT_PY}" "${LAB_ROOT}/tools/metrics_diff.py" "${RUN}/metrics-before.prom" "${RUN}/metrics-after.prom" > "${RUN}/metrics-diff.txt" 2>&1 || true
fi
log "压测结束（退出码 ${rc}）。汇总多次结果: ${CLIENT_PY} tools/collect_bench.py ${RESULTS_DIR}/${EXP}"
exit "${rc}"
