#!/usr/bin/env bash
# 带 API key 校验的 nginx 网关（docker 容器 lab-gateway，host 网络）。
# 用法：
#   bash scripts/gateway.sh up        # 渲染配置并启动
#   bash scripts/gateway.sh reload    # 改了 lab.env 或 key 后热加载
#   bash scripts/gateway.sh down
#   bash scripts/gateway.sh status
#   bash scripts/gateway.sh test      # 本机自测：无 key 应 401，有 key 应 200
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
require_cmd docker
GW_DIR="${RUNTIME_DIR}/gateway"
CONF="${GW_DIR}/nginx.conf"
MAP="${GW_DIR}/keys.map"
NAME="lab-gateway"

render() {
  [[ -f "${MAP}" ]] || bash "${LAB_ROOT}/scripts/apikey.sh" render
  local default="lab_vllm"
  [[ "${GATEWAY_DEFAULT_UPSTREAM}" == "sglang" ]] && default="lab_sglang"
  sed -e "s|@GATEWAY_BIND@|${GATEWAY_BIND}|g" \
      -e "s|@GATEWAY_PORT@|${GATEWAY_PORT}|g" \
      -e "s|@VLLM_UPSTREAM@|${ENGINE_HOST}:${VLLM_PORT}|g" \
      -e "s|@SGLANG_UPSTREAM@|${ENGINE_HOST}:${SGLANG_PORT}|g" \
      -e "s|@DEFAULT_UPSTREAM@|${default}|g" \
      "${LAB_ROOT}/configs/nginx/nginx.conf.template" > "${CONF}"
  docker run --rm -v "${CONF}:/etc/nginx/nginx.conf:ro" -v "${MAP}:/etc/nginx/lab/keys.map:ro" \
    -v "${LOGS_DIR}/gateway:/var/log/lab" "${NGINX_IMAGE}" nginx -t \
    || die "nginx 配置检查失败：${CONF}"
}

case "${1:-}" in
  up)
    render
    docker rm -f "${NAME}" >/dev/null 2>&1 || true
    docker run -d --name "${NAME}" --restart unless-stopped --network host \
      -v "${CONF}:/etc/nginx/nginx.conf:ro" \
      -v "${MAP}:/etc/nginx/lab/keys.map:ro" \
      -v "${LOGS_DIR}/gateway:/var/log/lab" \
      "${NGINX_IMAGE}" >/dev/null
    sleep 1
    log "网关已启动: http://${GATEWAY_BIND}:${GATEWAY_PORT}  （/v1 -> ${GATEWAY_DEFAULT_UPSTREAM}，另有 /vllm/v1 与 /sglang/v1）"
    log "访问日志: ${LOGS_DIR}/gateway/access.log"
    ;;
  reload)
    render
    docker exec "${NAME}" nginx -s reload && log "已热加载"
    ;;
  down)
    docker rm -f "${NAME}" >/dev/null 2>&1 && log "网关已停止" || log "网关未运行"
    ;;
  status)
    docker ps --filter "name=^${NAME}$" --format 'table {{.Names}}\t{{.Status}}\t{{.Image}}'
    curl -s -o /dev/null -w "healthz HTTP %{http_code}\n" "http://127.0.0.1:${GATEWAY_PORT}/healthz" || true
    ;;
  test)
    base="http://127.0.0.1:${GATEWAY_PORT}"
    code="$(curl -s -o /dev/null -w '%{http_code}' "${base}/v1/models")"
    [[ "${code}" == "401" ]] && log "无 key 访问 /v1/models -> 401（正确）" || warn "无 key 访问返回 ${code}，期望 401"
    code="$(curl -s -o /dev/null -w '%{http_code}' "${base}/metrics")"
    [[ "${code}" == "404" ]] && log "访问 /metrics -> 404（正确，未暴露）" || warn "/metrics 返回 ${code}，期望 404"
    key="$(first_api_key)"
    code="$(curl -s -o /dev/null -w '%{http_code}' -H "Authorization: Bearer ${key}" "${base}/v1/models")"
    if [[ "${code}" == "200" ]]; then log "带 key 访问 /v1/models -> 200（正确）";
    elif [[ "${code}" == "502" ]]; then warn "带 key 返回 502：网关正常，但默认引擎（${GATEWAY_DEFAULT_UPSTREAM}）没有运行";
    else warn "带 key 返回 ${code}"; fi
    ;;
  *) die "用法: $0 up|reload|down|status|test" ;;
esac
