#!/usr/bin/env bash
# 统一的推理引擎启停脚本。每种部署方式是一个 profile 文件：vllm/profiles/<名>.sh 或 sglang/profiles/<名>.sh。
#
# 用法：
#   bash scripts/engine.sh start vllm qwen3-8b-tp1                 # 用 profile 启动
#   bash scripts/engine.sh start vllm qwen3-8b-tp1 --port 8001 --gpus 1 --name v-alt --env K=V -- --max-num-seqs 64
#        （-- 之后的参数原样追加到引擎命令行末尾，用于实验扫参；同名参数以后出现的为准）
#   bash scripts/engine.sh stop <实例名>        # 实例名默认是 <框架>-<profile>
#   bash scripts/engine.sh stop-all
#   bash scripts/engine.sh status
#   bash scripts/engine.sh logs <实例名> [行数]
#   bash scripts/engine.sh cmd vllm qwen3-8b-tp1                   # 只打印将要执行的命令，不启动
#   bash scripts/engine.sh start vllm qwen3-8b --nsys e17-qwen -- <参数>   # 在 Nsight Systems 下启动（E17），
#        报告写到 runtime/traces/nsys/<名字>.nsys-rep；采集区间由 /start_profile 与 /stop_profile 控制
#   bash scripts/engine.sh profiles                                # 列出全部 profile
#
# profile 文件可设置的变量（见 vllm/profiles/README.md）：
#   DESC MODEL_KEY SERVED_NAME GPUS PORT IMAGE ENV_VARS=() ARGS=()
# profile 中可用的只读变量：MODEL_PATH TRACE_ROOT RESULT_ROOT（docker 模式下为容器内路径）
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs

usage() { sed -n '2,20p' "${BASH_SOURCE[0]}"; exit 1; }

load_profile() {  # load_profile <fw> <profile>
  local fw="$1" prof="$2"
  local f="${LAB_ROOT}/${fw}/profiles/${prof}.sh"
  [[ -f "${f}" ]] || die "没有 profile: ${f}（bash scripts/engine.sh profiles 查看全部）"
  DESC=""; MODEL_KEY=""; SERVED_NAME=""; GPUS="0"; PORT="$(engine_port "${fw}")"; IMAGE=""
  ENV_VARS=(); ARGS=()
  if [[ "${ENGINE_MODE}" == "docker" ]]; then
    MODEL_ROOT="/models"; TRACE_ROOT="/traces"; RESULT_ROOT="/results"
  else
    MODEL_ROOT="${MODELS_DIR}"; TRACE_ROOT="${TRACES_DIR}"; RESULT_ROOT="${RESULTS_DIR}"
  fi
  # profile 需要在 MODEL_KEY 确定后才能引用 MODEL_PATH，所以分两次 source
  MODEL_PATH="${MODEL_ROOT}/__model_key_not_set__"
  # shellcheck disable=SC1090
  source "${f}"
  MODEL_PATH="${MODEL_ROOT}/${MODEL_KEY}"
  ENV_VARS=(); ARGS=()
  # shellcheck disable=SC1090
  source "${f}"
  [[ -n "${MODEL_KEY}" ]] || die "profile ${prof} 没有设置 MODEL_KEY"
  [[ -n "${SERVED_NAME}" ]] || SERVED_NAME="${MODEL_KEY}"
  if [[ -z "${IMAGE}" ]]; then
    [[ "${fw}" == "vllm" ]] && IMAGE="${VLLM_IMAGE}" || IMAGE="${SGLANG_IMAGE}"
  fi
}

build_cmd() {  # 生成引擎命令（数组 CMD）
  local fw="$1"; shift
  if [[ "${fw}" == "vllm" ]]; then
    CMD=(vllm serve "${MODEL_PATH}" --served-model-name "${SERVED_NAME}" --host "${ENGINE_HOST}" --port "${PORT}" "${ARGS[@]}" "$@")
  else
    CMD=(python3 -m sglang.launch_server --model-path "${MODEL_PATH}" --served-model-name "${SERVED_NAME}" --host "${ENGINE_HOST}" --port "${PORT}" "${ARGS[@]}" "$@")
  fi
}

cmd_start() {
  local fw="$1" prof="$2"; shift 2
  local name="" port_override="" gpus_override="" dry=0 nsys_name=""
  local extra_env=()
  local extra=()
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --name) name="$2"; shift 2 ;;
      --port) port_override="$2"; shift 2 ;;
      --gpus) gpus_override="$2"; shift 2 ;;
      --dry-run) dry=1; shift ;;
      --nsys) nsys_name="$2"; shift 2 ;;
      --env) extra_env+=("$2"); shift 2 ;;
      --) shift; extra=("$@"); break ;;
      *) die "未知选项 $1（引擎参数请放在 -- 之后）" ;;
    esac
  done
  load_profile "${fw}" "${prof}"
  [[ -n "${port_override}" ]] && PORT="${port_override}"
  [[ -n "${gpus_override}" ]] && GPUS="${gpus_override}"
  [[ -n "${name}" ]] || name="${fw}-${prof}"
  ENV_VARS+=("${extra_env[@]}")
  build_cmd "${fw}" "${extra[@]}"
  local nsys_mount=()
  if [[ -n "${nsys_name}" ]]; then
    local nsys_bin
    nsys_bin="$(command -v nsys || true)"
    [[ -n "${nsys_bin}" ]] || nsys_bin="${ENVS_DIR}/nsight/bin/nsys"
    [[ -x "${nsys_bin}" ]] || die "找不到 nsys（bash scripts/01_install_tools.sh nsys）"
    nsys_bin="$(readlink -f "${nsys_bin}")"
    local nsys_root; nsys_root="$(dirname "$(dirname "${nsys_bin}")")"
    local nsys_out
    if [[ "${ENGINE_MODE}" == "docker" ]]; then
      nsys_mount=(-v "${nsys_root}:${nsys_root}:ro"); nsys_out="/traces/nsys/${nsys_name}"
    else
      nsys_out="${TRACES_DIR}/nsys/${nsys_name}"
    fi
    mkdir -p "${TRACES_DIR}/nsys"
    # vLLM 文档推荐：--trace-fork-before-exec=true --cuda-graph-trace=node；用 cudaProfilerApi 控制采集区间
    CMD=("${nsys_bin}" profile --trace=cuda,nvtx,osrt --trace-fork-before-exec=true --cuda-graph-trace=node
         --capture-range=cudaProfilerApi --capture-range-end=repeat --force-overwrite=true -o "${nsys_out}" "${CMD[@]}")
    ENV_VARS+=(VLLM_WORKER_MULTIPROC_METHOD=spawn)
  fi

  local logf="${LOGS_DIR}/engines/${name}-$(ts).log"
  local state="${STATE_DIR}/${name}.env"
  local env_args=() kv
  for kv in "${ENV_VARS[@]}"; do env_args+=(-e "${kv}"); done

  {
    echo "# $(date -Iseconds) ${fw}/${prof} 实例 ${name}"
    echo "# ${DESC}"
    echo "# GPUS=${GPUS} PORT=${PORT} IMAGE=${IMAGE} MODE=${ENGINE_MODE}"
    echo "# ENV: ${ENV_VARS[*]:-}"
    printf '# CMD:'; printf ' %q' "${CMD[@]}"; echo
  } > "${logf}"
  if (( dry )); then cat "${logf}"; rm -f "${logf}"; return; fi

  if [[ ! -d "${MODELS_DIR}/${MODEL_KEY}" ]]; then die "模型目录不存在: ${MODELS_DIR}/${MODEL_KEY}（先下载）"; fi

  if [[ "${ENGINE_MODE}" == "docker" ]]; then
    require_cmd docker
    docker rm -f "lab-${name}" >/dev/null 2>&1 || true
    local entry="${CMD[0]}"
    docker run -d --name "lab-${name}" \
      --gpus all -e CUDA_VISIBLE_DEVICES="${GPUS}" \
      --ipc=host --network host --ulimit memlock=-1 --ulimit stack=67108864 \
      -e HF_HOME=/root/.cache/huggingface -e HF_HUB_OFFLINE=1 \
      -e TRITON_CACHE_DIR=/root/.cache/triton \
      -e VLLM_ENGINE_READY_TIMEOUT_S=3600 \
      -v "${MODELS_DIR}:/models:ro" \
      -v "${CACHE_DIR}/${fw}:/root/.cache" \
      -v "${TRACES_DIR}:/traces" \
      -v "${RESULTS_DIR}:/results" \
      -v "${LAB_ROOT}:/lab:ro" \
      "${nsys_mount[@]}" \
      "${env_args[@]}" \
      --entrypoint "${entry}" "${IMAGE}" "${CMD[@]:1}" >> "${logf}"
    nohup docker logs -f "lab-${name}" >> "${logf}" 2>&1 &
    echo "LOGGER_PID=$!" > "${state}"
  else
    local bin_dir="${ENVS_DIR}/${fw}/bin"
    [[ -x "${bin_dir}/python" ]] || die "venv 模式需要先运行: bash scripts/01_install_tools.sh engines"
    local kv2 envs=()
    for kv2 in "${ENV_VARS[@]}"; do envs+=("${kv2}"); done
    (
      export PATH="${bin_dir}:${PATH}" CUDA_VISIBLE_DEVICES="${GPUS}" HF_HOME HF_HUB_OFFLINE=1 VLLM_ENGINE_READY_TIMEOUT_S=3600
      export TRITON_CACHE_DIR="${CACHE_DIR}/triton" XDG_CACHE_HOME="${CACHE_DIR}/${fw}"
      for kv2 in "${envs[@]}"; do export "${kv2?}"; done
      setsid nohup "${CMD[@]}" >> "${logf}" 2>&1 &
      echo "ENGINE_PID=$!" > "${state}"
    )
  fi
  {
    echo "FRAMEWORK=${fw}"; echo "PROFILE=${prof}"; echo "PORT=${PORT}"; echo "GPUS=${GPUS}"
    echo "LOG=${logf}"; echo "STARTED=$(date +%s)"; echo "SERVED_NAME=${SERVED_NAME}"; echo "MODEL_KEY=${MODEL_KEY}"
  } >> "${state}"
  ln -sf "${logf}" "${LOGS_DIR}/engines/${name}.latest.log"
  log "已启动实例 ${name}（${fw}/${prof}，GPU ${GPUS}，端口 ${PORT}）"
  log "日志: ${logf}"
  log "等待就绪: bash scripts/wait_ready.sh ${name}"
}

cmd_stop() {
  local name="$1" state="${STATE_DIR}/$1.env"
  if [[ -f "${state}" ]]; then
    # shellcheck disable=SC1090
    source "${state}"
  fi
  if [[ "${ENGINE_MODE}" == "docker" ]]; then
    docker stop -t 60 "lab-${name}" >/dev/null 2>&1 || true
    docker rm -f "lab-${name}" >/dev/null 2>&1 || true
    [[ -n "${LOGGER_PID:-}" ]] && kill "${LOGGER_PID}" 2>/dev/null || true
  else
    if [[ -n "${ENGINE_PID:-}" ]]; then
      kill -TERM -- "-${ENGINE_PID}" 2>/dev/null || kill -TERM "${ENGINE_PID}" 2>/dev/null || true
      sleep 10
      kill -KILL -- "-${ENGINE_PID}" 2>/dev/null || true
    fi
  fi
  rm -f "${state}"
  log "已停止 ${name}"
}

cmd_status() {
  local f
  printf '%-34s %-8s %-6s %-18s %-10s %s\n' 实例 框架 端口 GPU 健康 profile
  for f in "${STATE_DIR}"/*.env; do
    [[ -e "${f}" ]] || continue
    local n; n="$(basename "${f}" .env)"
    (
      # shellcheck disable=SC1090
      source "${f}"
      local h
      h="$(curl -s -o /dev/null -m 2 -w '%{http_code}' "http://127.0.0.1:${PORT}/health" || true)"
      printf '%-34s %-8s %-6s %-18s %-10s %s\n' "${n}" "${FRAMEWORK}" "${PORT}" "${GPUS}" "HTTP ${h}" "${PROFILE}"
    )
  done
  if [[ "${ENGINE_MODE}" == "docker" ]] && command -v docker >/dev/null; then
    echo; docker ps --filter "name=^lab-" --format 'table {{.Names}}\t{{.Status}}\t{{.Image}}'
  fi
}

case "${1:-}" in
  start) [[ $# -ge 3 ]] || usage; shift; cmd_start "$@" ;;
  cmd) [[ $# -ge 3 ]] || usage; shift; fw="$1"; prof="$2"; shift 2; cmd_start "${fw}" "${prof}" --dry-run "$@" ;;
  stop) [[ $# -ge 2 ]] || usage; cmd_stop "$2" ;;
  stop-all)
    for f in "${STATE_DIR}"/*.env; do
      if [[ -e "$f" ]]; then cmd_stop "$(basename "$f" .env)"; fi
    done ;;
  status) cmd_status ;;
  logs) [[ $# -ge 2 ]] || usage; tail -n "${3:-100}" "${LOGS_DIR}/engines/$2.latest.log" ;;
  profiles)
    for fw in vllm sglang; do
      for f in "${LAB_ROOT}/${fw}/profiles/"*.sh; do
        d="$(grep -m1 '^DESC=' "$f" | cut -d= -f2- | tr -d '"')"
        printf '%-7s %-40s %s\n' "${fw}" "$(basename "$f" .sh)" "${d}"
      done
    done ;;
  *) usage ;;
esac
