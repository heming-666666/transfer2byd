#!/usr/bin/env bash
# 下载实验用的公开数据集到 runtime/datasets/<名字>/（容器内为 /datasets/<名字>/）。只下载实验文档点名的数据集。
# 用法：bash scripts/get_datasets.sh sharegpt | spec_bench | all
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
require_cmd curl
D="${RUNTIME_DIR}/datasets"
get() {  # get <子目录> <URL>
  mkdir -p "${D}/$1"
  local out="${D}/$1/$(basename "$2")"
  if [[ -s "${out}" ]]; then log "已存在 ${out}"; return; fi
  log "下载 $2"
  curl -fL --retry 3 "$2" -o "${out}.part" && mv "${out}.part" "${out}"
  ls -la "${out}"
}
case "${1:-}" in
  sharegpt)   get sharegpt "https://huggingface.co/datasets/anon8231489123/ShareGPT_Vicuna_unfiltered/resolve/main/ShareGPT_V3_unfiltered_cleaned_split.json" ;;
  spec_bench) get spec_bench "https://raw.githubusercontent.com/hemingkx/Spec-Bench/refs/heads/main/data/spec_bench/question.jsonl" ;;
  all) "$0" sharegpt; "$0" spec_bench ;;
  *) die "用法: $0 sharegpt|spec_bench|all（URL 来自 vLLM benchmark 文档）" ;;
esac
