#!/usr/bin/env bash
# 按 configs/models/<key>.manifest.json 中固定的 revision 下载模型到 MODELS_DIR/<key>/。
# 支持断点续传（再次运行即可）。下载完成后自动做大小校验。
# 用法：
#   bash scripts/03_download_models.sh qwen3-8b
#   bash scripts/03_download_models.sh glm-4.7-flash glm-5.3-flash
#   bash scripts/03_download_models.sh all
# 可用的 key：qwen3-8b(16 GB) glm-4.7-flash(63 GB) glm-5.3-flash(328 GB) deepseek-v4.1-flash-1017(510 GB)
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
[[ -x "${CLIENT_PY}" ]] || die "先运行 bash scripts/01_install_tools.sh 安装 client 环境"
HF="${ENVS_DIR}/client/bin/hf"
[[ -x "${HF}" ]] || die "client 环境里没有 hf 命令（huggingface_hub 版本过旧？）"

ALL_KEYS=(qwen3-8b glm-4.7-flash glm-5.3-flash deepseek-v4.1-flash-1017)
KEYS=("$@")
[[ ${#KEYS[@]} -gt 0 ]] || die "用法: $0 <key>... | all"
[[ "${KEYS[0]}" == "all" ]] && KEYS=("${ALL_KEYS[@]}")

export HF_HOME
[[ -n "${HF_ENDPOINT_OVERRIDE:-}" ]] && export HF_ENDPOINT="${HF_ENDPOINT_OVERRIDE}" && log "使用 HF_ENDPOINT=${HF_ENDPOINT}"
TOKEN_ARGS=()
if [[ -f "${HF_TOKEN_FILE}" ]]; then TOKEN_ARGS=(--token "$(cat "${HF_TOKEN_FILE}")"); fi

for key in "${KEYS[@]}"; do
  man="${LAB_ROOT}/configs/models/${key}.manifest.json"
  [[ -f "${man}" ]] || die "没有 ${man}"
  repo="$("${CLIENT_PY}" -c 'import json,sys;print(json.load(open(sys.argv[1]))["repo"])' "${man}")"
  rev="$("${CLIENT_PY}" -c 'import json,sys;print(json.load(open(sys.argv[1]))["revision"])' "${man}")"
  gb="$("${CLIENT_PY}" -c 'import json,sys;print(round(json.load(open(sys.argv[1]))["total_bytes"]/1e9,1))' "${man}")"
  dest="${MODELS_DIR}/${key}"
  log "下载 ${repo}@${rev:0:12}（约 ${gb} GB）-> ${dest}"
  dlog="${LOGS_DIR}/machine/download-${key}-$(ts).log"
  "${HF}" download "${repo}" --revision "${rev}" --local-dir "${dest}" --max-workers 16 "${TOKEN_ARGS[@]}" 2>&1 | tee "${dlog}"
  "${CLIENT_PY}" "${LAB_ROOT}/tools/verify_models.py" "${key}" || die "${key} 校验失败，重新运行本脚本可续传"
done
log "全部完成。可选的完整哈希校验（慢）: ${CLIENT_PY} tools/verify_models.py <key> --sha256"
