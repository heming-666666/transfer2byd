#!/usr/bin/env bash
# 所有脚本共用的函数：定位实验包、读取 lab.env、日志、结果目录。
# 用法：在脚本开头写  source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

set -euo pipefail

_COMMON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_DEFAULT_LAB_ROOT="$(cd "${_COMMON_DIR}/.." && pwd)"

if [[ ! -f "${_DEFAULT_LAB_ROOT}/lab.env" ]]; then
  echo "[lab] 找不到 ${_DEFAULT_LAB_ROOT}/lab.env，请先运行: bash scripts/init_lab.sh" >&2
  exit 1
fi

LAB_ROOT="${_DEFAULT_LAB_ROOT}"
export LAB_ROOT
# shellcheck disable=SC1091
source "${LAB_ROOT}/lab.env"
LAB_ROOT="${_DEFAULT_LAB_ROOT}"   # 防止 lab.env 误改
RUNTIME_DIR="${RUNTIME_DIR:-${LAB_ROOT}/runtime}"
MODELS_DIR="${MODELS_DIR:-${RUNTIME_DIR}/models}"
HF_HOME="${HF_HOME:-${RUNTIME_DIR}/hf-cache}"
API_KEYS_FILE="${API_KEYS_FILE:-${RUNTIME_DIR}/secrets/api_keys.tsv}"
HF_TOKEN_FILE="${HF_TOKEN_FILE:-${RUNTIME_DIR}/secrets/hf_token}"

export LAB_ROOT RUNTIME_DIR MODELS_DIR HF_HOME API_KEYS_FILE HF_TOKEN_FILE

ENVS_DIR="${RUNTIME_DIR}/envs"
LOGS_DIR="${RUNTIME_DIR}/logs"
RESULTS_DIR="${RUNTIME_DIR}/results"
TRACES_DIR="${RUNTIME_DIR}/traces"
SESSIONS_DIR="${RUNTIME_DIR}/sessions"
CACHE_DIR="${RUNTIME_DIR}/cache"
SECRETS_DIR="${RUNTIME_DIR}/secrets"
STATE_DIR="${RUNTIME_DIR}/state"
CLIENT_PY="${ENVS_DIR}/client/bin/python"
export ENVS_DIR LOGS_DIR RESULTS_DIR TRACES_DIR SESSIONS_DIR CACHE_DIR SECRETS_DIR STATE_DIR CLIENT_PY

ts() { date +%Y%m%d-%H%M%S; }
log() { printf '[lab %s] %s\n' "$(date +%H:%M:%S)" "$*" >&2; }
warn() { printf '[lab %s] 警告: %s\n' "$(date +%H:%M:%S)" "$*" >&2; }
die() { printf '[lab %s] 错误: %s\n' "$(date +%H:%M:%S)" "$*" >&2; exit 1; }

require_cmd() {
  local c
  for c in "$@"; do
    command -v "$c" >/dev/null 2>&1 || die "缺少命令: $c（见 docs/03-基础环境安装.md）"
  done
}

ensure_runtime_dirs() {
  mkdir -p "${ENVS_DIR}" "${LOGS_DIR}"/{engines,gateway,machine,agent} "${RESULTS_DIR}" \
    "${TRACES_DIR}" "${SESSIONS_DIR}" "${CACHE_DIR}"/{vllm,sglang,flashinfer,triton} \
    "${SECRETS_DIR}" "${STATE_DIR}" "${MODELS_DIR}" "${HF_HOME}" "${RUNTIME_DIR}/gateway" \
    "${RUNTIME_DIR}/images" "${RUNTIME_DIR}/datasets"
  chmod 700 "${SECRETS_DIR}"
}

# 新建一次实验运行的结果目录：runtime/results/<实验编号>/<时间>-<标签>/
# 同时写入 meta.json（时间、标签、镜像、驱动、GPU 型号），返回目录路径。
new_run_dir() {
  local exp="$1" label="${2:-run}"
  local dir="${RESULTS_DIR}/${exp}/$(ts)-${label}"
  mkdir -p "${dir}"
  local driver gpu
  driver="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1 || echo unknown)"
  gpu="$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1 || echo unknown)"
  cat > "${dir}/meta.json" <<EOF
{
  "experiment": "${exp}",
  "label": "${label}",
  "created": "$(date -Iseconds)",
  "host": "$(hostname)",
  "engine_mode": "${ENGINE_MODE}",
  "vllm_image": "${VLLM_IMAGE}",
  "sglang_image": "${SGLANG_IMAGE}",
  "driver": "${driver}",
  "gpu": "${gpu}"
}
EOF
  echo "${dir}"
}

# 读取第一个 API key（给本机测试脚本用），不打印到屏幕。
first_api_key() {
  [[ -f "${API_KEYS_FILE}" ]] || die "还没有 API key，先运行: bash scripts/apikey.sh add <名字>"
  awk -F'\t' 'NF>=2 && $1 !~ /^#/ {print $2; exit}' "${API_KEYS_FILE}"
}

engine_port() {
  case "$1" in
    vllm) echo "${VLLM_PORT}" ;;
    sglang) echo "${SGLANG_PORT}" ;;
    *) die "未知框架: $1（只能是 vllm 或 sglang）" ;;
  esac
}
