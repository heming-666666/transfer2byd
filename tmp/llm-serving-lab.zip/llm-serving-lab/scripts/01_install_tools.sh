#!/usr/bin/env bash
# 安装用户级工具，全部放在 runtime/envs/ 下，不需要 root：
#   uv（Python 包管理）、Python 解释器、client 环境（OpenAI 客户端、hf 下载工具、分析脚本依赖）
#   可选：lm-eval、evalscope 评测环境；venv 模式下的 vllm / sglang 引擎环境；Nsight Systems CLI。
# 用法：
#   bash scripts/01_install_tools.sh                 # uv + client
#   bash scripts/01_install_tools.sh eval            # 再装 lm-eval 与 evalscope
#   bash scripts/01_install_tools.sh engines         # venv 模式：装 vllm 与 sglang（docker 模式不需要）
#   bash scripts/01_install_tools.sh router          # vllm-router / sglang-router（数据并行与 PD 实验）
#   bash scripts/01_install_tools.sh nsys            # 用户级安装 Nsight Systems CLI
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
require_cmd curl

export UV_INSTALL_DIR="${ENVS_DIR}/uv"
export UV_PYTHON_INSTALL_DIR="${ENVS_DIR}/python"
export UV_CACHE_DIR="${CACHE_DIR}/uv"
export UV_NO_MODIFY_PATH=1
UV="${UV_INSTALL_DIR}/uv"

install_uv() {
  if [[ -x "${UV}" ]]; then log "uv 已存在: $(${UV} --version)"; return; fi
  log "安装 uv 到 ${UV_INSTALL_DIR}"
  curl -LsSf https://astral.sh/uv/install.sh | sh
  [[ -x "${UV}" ]] || die "uv 安装失败；网络问题请报告给机器主人"
  log "$(${UV} --version)"
}

make_venv() {  # make_venv <名字>
  local name="$1"
  if [[ ! -x "${ENVS_DIR}/${name}/bin/python" ]]; then
    "${UV}" venv --python "${PYTHON_VERSION}" "${ENVS_DIR}/${name}"
  fi
}

freeze() {  # 记录安装结果，便于复现
  local name="$1"
  "${UV}" pip freeze --python "${ENVS_DIR}/${name}/bin/python" > "${ENVS_DIR}/${name}.lock.txt"
  log "已记录 ${ENVS_DIR}/${name}.lock.txt"
}

install_client() {
  make_venv client
  "${UV}" pip install --python "${ENVS_DIR}/client/bin/python" \
    "openai>=1.60" "httpx>=0.27" "huggingface_hub[cli]>=0.34" "pandas>=2.0" "matplotlib>=3.8" "pyyaml>=6" "prometheus-client>=0.20"
  freeze client
  log "client 环境: ${ENVS_DIR}/client/bin/python"
}

install_eval() {
  make_venv lm-eval
  "${UV}" pip install --python "${ENVS_DIR}/lm-eval/bin/python" "lm-eval[api]>=0.4.9"
  freeze lm-eval
  make_venv evalscope
  "${UV}" pip install --python "${ENVS_DIR}/evalscope/bin/python" "evalscope>=1.0"
  freeze evalscope
}

install_engines() {
  # venv 模式才需要。版本与 lab.env 一致。vLLM 用 --torch-backend=auto 按驱动选 CUDA 版本（官方安装文档写法）。
  make_venv vllm
  "${UV}" pip install --python "${ENVS_DIR}/vllm/bin/python" "vllm==${VLLM_VERSION}" --torch-backend=auto
  freeze vllm
  make_venv sglang
  # SGLang 官方安装文档：uv pip install --prerelease=allow sglang（需要 CUDA 13 驱动）
  "${UV}" pip install --python "${ENVS_DIR}/sglang/bin/python" --prerelease=allow "sglang==${SGLANG_VERSION}"
  freeze sglang
  # 路由器（数据并行 / PD 分离实验用）
  "${UV}" pip install --python "${ENVS_DIR}/vllm/bin/python" vllm-router
  "${UV}" pip install --python "${ENVS_DIR}/sglang/bin/python" sglang-router
}

install_router() {
  make_venv router
  "${UV}" pip install --python "${ENVS_DIR}/router/bin/python" vllm-router sglang-router
  freeze router
  ls "${ENVS_DIR}/router/bin/" | grep -E "router" || true
}

install_nsys() {
  if command -v nsys >/dev/null; then log "系统已有 nsys: $(nsys --version)"; return; fi
  local dest="${ENVS_DIR}/nsight"
  if [[ -x "${dest}/bin/nsys" ]]; then log "已安装: ${dest}/bin/nsys"; return; fi
  require_cmd dpkg-deb
  local codename ver
  # shellcheck disable=SC1091
  ver="$(. /etc/os-release; echo "${VERSION_ID}" | tr -d .)"
  codename="ubuntu${ver}"
  local repo="https://developer.download.nvidia.com/devtools/repos/${codename}/amd64"
  log "从 ${repo} 查找 nsight-systems-cli 安装包"
  local fname
  fname="$(curl -fsSL "${repo}/Packages" | awk '/^Package: nsight-systems-cli$/{p=1} p&&/^Filename:/{print $2; p=0}' | sort -V | tail -1)"
  [[ -n "${fname}" ]] || die "没有找到 nsight-systems-cli 安装包；请改用 apt 安装（需要管理员，见 vLLM profiling 文档）"
  mkdir -p "${dest}/pkg"
  curl -fL "${repo}/${fname##*/}" -o "${dest}/pkg/nsys.deb"
  dpkg-deb -x "${dest}/pkg/nsys.deb" "${dest}/root"
  local bin
  bin="$(find "${dest}/root" -type f -name nsys -path '*/bin/*' | head -1)"
  [[ -n "${bin}" ]] || die "解包后没有找到 nsys 可执行文件"
  mkdir -p "${dest}/bin"; ln -sf "${bin}" "${dest}/bin/nsys"
  "${dest}/bin/nsys" --version
  log "使用前执行: export PATH=${dest}/bin:\$PATH"
}

case "${1:-client}" in
  client) install_uv; install_client ;;
  eval) install_uv; install_eval ;;
  engines) install_uv; install_engines ;;
  router) install_uv; install_router ;;
  nsys) install_nsys ;;
  all) install_uv; install_client; install_eval; install_router; install_nsys ;;
  *) die "用法: $0 [client|eval|engines|router|nsys|all]" ;;
esac
log "完成"
