#!/usr/bin/env bash
# 启停请求路由器（数据并行多副本、PD 分离实验用）。路由器运行在宿主机的 runtime/envs/router 环境中（不占 GPU）。
# 安装：bash scripts/01_install_tools.sh router
# 用法：
#   bash scripts/router.sh start vllm-pd   --port 8100 --prefill http://127.0.0.1:8001 --decode http://127.0.0.1:8002
#   bash scripts/router.sh start sglang-pd --port 8100 --prefill http://127.0.0.1:31000 --bootstrap 8998 --decode http://127.0.0.1:32000
#   bash scripts/router.sh start sglang-dp --port 8100 --workers http://127.0.0.1:30001 http://127.0.0.1:30002 [--policy cache_aware]
#   bash scripts/router.sh start vllm-dp   --port 8100 --workers http://127.0.0.1:8001 http://127.0.0.1:8002 [--policy round_robin]
#   bash scripts/router.sh stop
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
RENV="${ENVS_DIR}/router/bin"
PIDF="${STATE_DIR}/router.pid"

start() {
  local kind="$1"; shift
  local port=8100 prefill="" decode="" bootstrap="8998" policy="" workers=()
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --port) port="$2"; shift 2 ;;
      --prefill) prefill="$2"; shift 2 ;;
      --decode) decode="$2"; shift 2 ;;
      --bootstrap) bootstrap="$2"; shift 2 ;;
      --policy) policy="$2"; shift 2 ;;
      --workers) shift; while [[ $# -gt 0 && "$1" != --* ]]; do workers+=("$1"); shift; done ;;
      *) die "未知参数 $1" ;;
    esac
  done
  local cmd=()
  case "${kind}" in
    vllm-pd)
      # 写法来自 vLLM recipes（GLM-5.3-Flash 的 PD 示例）
      cmd=("${RENV}/vllm-router" --policy "${policy:-round_robin}" --vllm-pd-disaggregation
           --prefill "${prefill}" --decode "${decode}" --host "${ENGINE_HOST}" --port "${port}"
           --intra-node-data-parallel-size 1) ;;
    vllm-dp)
      cmd=("${RENV}/vllm-router" --policy "${policy:-round_robin}" --host "${ENGINE_HOST}" --port "${port}" --worker-urls "${workers[@]}") ;;
    sglang-pd)
      # 写法来自 SGLang cookbook（GLM-5.3-Flash PD 示例，去掉了依赖完整 sglang 包的 --mini-lb）
      cmd=("${RENV}/python" -m sglang_router.launch_router --pd-disaggregation
           --prefill "${prefill}" "${bootstrap}" --decode "${decode}" --host "${ENGINE_HOST}" --port "${port}") ;;
    sglang-dp)
      cmd=("${RENV}/python" -m sglang_router.launch_router --worker-urls "${workers[@]}"
           --policy "${policy:-cache_aware}" --host "${ENGINE_HOST}" --port "${port}") ;;
    *) die "kind 只能是 vllm-pd|vllm-dp|sglang-pd|sglang-dp" ;;
  esac
  [[ -x "${cmd[0]}" ]] || die "没有 ${cmd[0]}，先运行: bash scripts/01_install_tools.sh router"
  local logf="${LOGS_DIR}/engines/router-${kind}-$(ts).log"
  printf '# CMD:' > "${logf}"; printf ' %q' "${cmd[@]}" >> "${logf}"; echo >> "${logf}"
  setsid nohup "${cmd[@]}" >> "${logf}" 2>&1 &
  echo "$!" > "${PIDF}"
  log "路由器已启动（${kind}，端口 ${port}），日志 ${logf}"
  log "提示：要经网关访问路由器，把 lab.env 的 VLLM_PORT 或 SGLANG_PORT 临时改成 ${port} 后执行 bash scripts/gateway.sh reload"
}

case "${1:-}" in
  start) shift; start "$@" ;;
  stop) [[ -f "${PIDF}" ]] && { kill -TERM -- "-$(cat "${PIDF}")" 2>/dev/null || kill "$(cat "${PIDF}")" 2>/dev/null || true; rm -f "${PIDF}"; log "路由器已停止"; } || log "路由器未运行" ;;
  *) sed -n '2,12p' "${BASH_SOURCE[0]}"; exit 1 ;;
esac
