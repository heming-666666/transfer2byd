#!/usr/bin/env bash
# 第一次使用：生成 lab.env、创建 runtime/ 下的全部子目录。可重复执行，不会覆盖已有 lab.env。
set -euo pipefail
LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -f "${LAB_DIR}/lab.env" ]]; then
  cp "${LAB_DIR}/lab.env.example" "${LAB_DIR}/lab.env"
  echo "[lab] 已从 lab.env.example 生成 lab.env，请检查其中的 MODELS_DIR、端口和镜像版本。"
else
  echo "[lab] lab.env 已存在，保持不变。"
fi
# shellcheck disable=SC1091
source "${LAB_DIR}/scripts/common.sh"
ensure_runtime_dirs
chmod +x "${LAB_ROOT}"/scripts/*.sh 2>/dev/null || true
log "LAB_ROOT     = ${LAB_ROOT}"
log "RUNTIME_DIR  = ${RUNTIME_DIR}"
log "MODELS_DIR   = ${MODELS_DIR}"
log "ENGINE_MODE  = ${ENGINE_MODE}"
log "目录已就绪。下一步: bash scripts/00_check_machine.sh"
