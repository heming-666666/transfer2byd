#!/usr/bin/env bash
# 把一次实验的环境快照写入结果目录 env/：镜像摘要、引擎内的关键包版本、启动命令、服务日志副本、启动指标。
# 用法：bash scripts/collect_env.sh <实例名> <结果目录>
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
NAME="${1:?实例名}"; DIR="${2:?结果目录}"
OUT="${DIR}/env"; mkdir -p "${OUT}"
STATE="${STATE_DIR}/${NAME}.env"
[[ -f "${STATE}" ]] && cp "${STATE}" "${OUT}/instance.env"
# shellcheck disable=SC1090
[[ -f "${STATE}" ]] && source "${STATE}"
nvidia-smi --query-gpu=index,name,driver_version,memory.total,clocks.max.sm --format=csv > "${OUT}/gpus.csv" 2>&1 || true
if [[ "${ENGINE_MODE}" == "docker" ]] && docker ps --format '{{.Names}}' | grep -qx "lab-${NAME}"; then
  docker inspect --format '{{.Config.Image}} {{.Image}}' "lab-${NAME}" > "${OUT}/image.txt"
  docker exec "lab-${NAME}" python3 -c '
import importlib.metadata as m
for p in ["vllm","sglang","sglang-kernel","torch","flashinfer-python","flashinfer_python","triton","transformers","xgrammar","nixl","deep_gemm","deep-gemm","nvidia-nccl-cu13","nvidia-nccl-cu12"]:
    try: print(p, m.version(p))
    except Exception: pass
import torch; print("torch.cuda", torch.version.cuda, "nccl", torch.cuda.nccl.version())
' > "${OUT}/packages.txt" 2>&1 || true
elif [[ -n "${FRAMEWORK:-}" && -x "${ENVS_DIR}/${FRAMEWORK}/bin/python" ]]; then
  "${ENVS_DIR}/${FRAMEWORK}/bin/python" -m pip list 2>/dev/null | grep -iE "vllm|sglang|torch|flashinfer|triton|transformers|xgrammar|nixl|nccl" > "${OUT}/packages.txt" || true
fi
if [[ -n "${LOG:-}" && -f "${LOG}" ]]; then
  cp "${LOG}" "${OUT}/server.log"
  [[ -x "${CLIENT_PY}" ]] && "${CLIENT_PY}" "${LAB_ROOT}/tools/parse_server_log.py" "${LOG}" --json "${OUT}/startup_metrics.json" > "${OUT}/startup_metrics.txt" 2>&1 || true
fi
cp "${LAB_ROOT}/lab.env" "${OUT}/lab.env.copy" 2>/dev/null || true
log "环境快照 -> ${OUT}"
