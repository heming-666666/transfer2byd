#!/usr/bin/env bash
# 后台采样 GPU 状态到某个结果目录：
#   gpu.csv    nvidia-smi 每 500ms：利用率、显存、功耗、SM 频率、温度、PCIe 吞吐
#   dcgm.txt   若有 dcgmi：SM_ACTIVE(1002) SM_OCCUPANCY(1003) TENSOR_ACTIVE(1004) DRAM_ACTIVE(1005)
#              PCIE_TX/RX(1009/1010) NVLINK_TX/RX(1011/1012)。nvidia-smi 的 "utilization.gpu" 只表示
#              “采样周期内是否有 kernel 在跑”，不是 SM 占用率；要看 SM 用了多少，以 DCGM 或 nsys GPU metrics 为准。
#   nvlink-*.txt  开始/结束时的 NVLink 计数器快照（驱动支持时）
# 用法：
#   bash scripts/gpu_monitor.sh start <结果目录>
#   bash scripts/gpu_monitor.sh stop  <结果目录>
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ACTION="${1:?start|stop}"; DIR="${2:?结果目录}"
mkdir -p "${DIR}"
PIDS="${DIR}/.monitor.pids"

case "${ACTION}" in
  start)
    : > "${PIDS}"
    nvidia-smi --query-gpu=timestamp,index,utilization.gpu,utilization.memory,memory.used,power.draw,clocks.sm,temperature.gpu,pcie.link.gen.current \
      --format=csv -lms 500 > "${DIR}/gpu.csv" 2>/dev/null &
    echo $! >> "${PIDS}"
    if command -v dcgmi >/dev/null; then
      dcgmi dmon -e 1002,1003,1004,1005,1009,1010,1011,1012 -d 500 > "${DIR}/dcgm.txt" 2>&1 &
      echo $! >> "${PIDS}"
    fi
    nvidia-smi nvlink -gt d > "${DIR}/nvlink-start.txt" 2>&1 || true
    log "GPU 采样已开始 -> ${DIR}"
    ;;
  stop)
    nvidia-smi nvlink -gt d > "${DIR}/nvlink-end.txt" 2>&1 || true
    if [[ -f "${PIDS}" ]]; then
      while read -r p; do kill "${p}" 2>/dev/null || true; done < "${PIDS}"
      rm -f "${PIDS}"
    fi
    log "GPU 采样已停止"
    ;;
  *) die "用法: $0 start|stop <结果目录>" ;;
esac
