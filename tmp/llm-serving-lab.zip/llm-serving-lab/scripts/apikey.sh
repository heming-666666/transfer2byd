#!/usr/bin/env bash
# 管理网关的 API key。key 保存在 runtime/secrets/api_keys.tsv（权限 600），格式：<名字>\t<key>\t<创建时间>
# 每次修改都会重新生成 runtime/gateway/keys.map；网关在运行时自动热加载。
# 用法：
#   bash scripts/apikey.sh add alice        # 生成新 key，只在这一次完整打印
#   bash scripts/apikey.sh list             # 只列名字和 key 的前 10 位
#   bash scripts/apikey.sh revoke alice     # 删除
#   bash scripts/apikey.sh export-env alice # 打印 export LAB_API_KEY=...（给本机客户端用，注意不要写进共享文件）
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
umask 077
touch "${API_KEYS_FILE}"; chmod 600 "${API_KEYS_FILE}"
MAP="${RUNTIME_DIR}/gateway/keys.map"

render_map() {
  # nginx map 文件：  "Bearer <key>" "<名字>";
  {
    echo "# 自动生成，请勿手改。来源: ${API_KEYS_FILE}"
    awk -F'\t' 'NF>=2 && $1 !~ /^#/ {printf "\"Bearer %s\" \"%s\";\n", $2, $1}' "${API_KEYS_FILE}"
  } > "${MAP}"
  chmod 644 "${MAP}"
  if command -v docker >/dev/null && docker ps --format '{{.Names}}' 2>/dev/null | grep -qx lab-gateway; then
    docker exec lab-gateway nginx -s reload && log "网关已热加载新 key 列表"
  fi
}

name_ok() { [[ "$1" =~ ^[A-Za-z0-9_.-]{1,40}$ ]] || die "名字只能包含字母数字和 _.-，最长 40"; }

case "${1:-}" in
  add)
    name="${2:-}"; name_ok "${name}"
    if awk -F'\t' -v n="${name}" '$1==n {f=1} END {exit !f}' "${API_KEYS_FILE}"; then die "名字 ${name} 已存在"; fi
    key="sk-lab-$(python3 -c 'import secrets;print(secrets.token_hex(24))')"
    printf '%s\t%s\t%s\n' "${name}" "${key}" "$(date -Iseconds)" >> "${API_KEYS_FILE}"
    render_map
    echo "名字: ${name}"
    echo "key : ${key}"
    echo "（只显示这一次；需要时可用 export-env 再取）"
    ;;
  list)
    awk -F'\t' 'NF>=2 && $1 !~ /^#/ {printf "%-20s %s...  %s\n", $1, substr($2,1,10), $3}' "${API_KEYS_FILE}"
    ;;
  revoke)
    name="${2:-}"; name_ok "${name}"
    tmp="$(mktemp)"; awk -F'\t' -v n="${name}" '$1!=n' "${API_KEYS_FILE}" > "${tmp}"; mv "${tmp}" "${API_KEYS_FILE}"; chmod 600 "${API_KEYS_FILE}"
    render_map; log "已删除 ${name}"
    ;;
  export-env)
    name="${2:-}"; name_ok "${name}"
    key="$(awk -F'\t' -v n="${name}" '$1==n {print $2}' "${API_KEYS_FILE}")"
    [[ -n "${key}" ]] || die "没有 ${name}"
    echo "export LAB_API_KEY=${key}"
    ;;
  render) render_map ;;
  *) die "用法: $0 add|list|revoke|export-env <名字> | render" ;;
esac
