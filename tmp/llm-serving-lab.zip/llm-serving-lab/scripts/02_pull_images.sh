#!/usr/bin/env bash
# 拉取 docker 镜像，并验证 GPU 容器能启动。
# 用法：
#   bash scripts/02_pull_images.sh            # 拉取 vLLM、SGLang、nginx 镜像
#   bash scripts/02_pull_images.sh --test     # 只做 GPU 容器测试
#   bash scripts/02_pull_images.sh --save     # 另外把镜像导出到 runtime/images/（每个 9–16 GB，便于离线复现）
#   bash scripts/02_pull_images.sh --fallback # 额外拉取 DeepSeek 备用镜像 dev-dsv41
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
require_cmd docker

IMAGES=("${VLLM_IMAGE}" "${SGLANG_IMAGE}" "${NGINX_IMAGE}")

test_gpu() {
  log "在 ${VLLM_IMAGE} 中运行 nvidia-smi -L"
  docker run --rm --gpus all --entrypoint nvidia-smi "${VLLM_IMAGE}" -L || die "GPU 容器无法启动：检查 nvidia-container-toolkit（docs/99）"
  log "在 ${SGLANG_IMAGE} 中检查 torch 与 CUDA"
  docker run --rm --gpus all --entrypoint python3 "${SGLANG_IMAGE}" -c \
    'import torch;print("torch",torch.__version__,"cuda",torch.version.cuda,"gpus",torch.cuda.device_count());p=torch.cuda.get_device_properties(0);print(p.name,"SMs",p.multi_processor_count,"mem GiB",round(p.total_memory/2**30,1))' \
    || die "SGLang 镜像中 CUDA 不可用：多半是驱动低于 580（docs/02）"
}

case "${1:-}" in
  --test) test_gpu; exit 0 ;;
  --fallback) IMAGES+=("${SGLANG_DSV41_FALLBACK_IMAGE}") ;;
esac

for img in "${IMAGES[@]}"; do
  log "docker pull ${img}"
  docker pull "${img}"
done
docker image inspect --format '{{.RepoTags}} {{index .RepoDigests 0}} {{.Size}}' "${IMAGES[@]}" \
  | tee "${LOGS_DIR}/machine/images-$(ts).txt"
test_gpu

if [[ "${1:-}" == "--save" ]]; then
  for img in "${IMAGES[@]}"; do
    out="${RUNTIME_DIR}/images/$(echo "${img}" | tr '/:' '__').tar"
    log "导出 ${img} -> ${out}"
    docker save -o "${out}" "${img}"
  done
fi
log "镜像就绪。下一步: bash scripts/03_download_models.sh qwen3-8b"
