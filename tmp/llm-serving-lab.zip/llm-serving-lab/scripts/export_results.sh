#!/usr/bin/env bash
# 把实验结果打包给研究者：results、logs（不含 machine 下的大下载日志可选）、sessions、worklog、各文档“本机实测记录”。
# 排除：模型、环境、缓存、镜像、密钥、trace 原始文件（trace 体积大，默认只带 *.md/*.json 分析报告；加 --with-traces 带原始文件）。
# 用法：bash scripts/export_results.sh [--with-traces] [实验编号 ...]
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
WITH_TRACES=0
if [[ "${1:-}" == "--with-traces" ]]; then WITH_TRACES=1; shift; fi
EXPS=("$@")
OUT="${RUNTIME_DIR}/exports/lab-results-$(hostname)-$(ts).tar.gz"
mkdir -p "${RUNTIME_DIR}/exports"
LIST="$(mktemp)"
cd "${LAB_ROOT}"
if [[ ${#EXPS[@]} -gt 0 ]]; then
  for e in "${EXPS[@]}"; do [[ -d "runtime/results/${e}" ]] && echo "runtime/results/${e}" >> "${LIST}"; done
else
  echo "runtime/results" >> "${LIST}"
fi
for p in runtime/logs/agent runtime/logs/engines runtime/logs/gateway runtime/logs/machine runtime/sessions; do
  [[ -e "$p" ]] && echo "$p" >> "${LIST}"
done
if (( WITH_TRACES )); then echo "runtime/traces" >> "${LIST}"; else
  find runtime/traces -type f \( -name '*.md' -o -name 'report*.json' \) 2>/dev/null >> "${LIST}" || true
fi
# 各文档的实测记录（文档本身就在包内，直接带上被修改过的 md）
find docs vllm sglang experiments -name '*.md' >> "${LIST}"
tar --exclude='runtime/secrets' --exclude='*.safetensors' -czf "${OUT}" -T "${LIST}"
rm -f "${LIST}"
log "已打包: ${OUT}（$(du -h "${OUT}" | cut -f1)）"
