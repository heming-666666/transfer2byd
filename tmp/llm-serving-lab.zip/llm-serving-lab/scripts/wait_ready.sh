#!/usr/bin/env bash
# 等待引擎就绪（/health 返回 200），并把启动耗时写入状态文件与日志末尾。
# 用法：bash scripts/wait_ready.sh <实例名> [超时秒数，默认 3600]
#       bash scripts/wait_ready.sh --port 8000 [超时]
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
if [[ "${1:-}" == "--port" ]]; then
  PORT="$2"; TIMEOUT="${3:-3600}"; NAME="port-${PORT}"; STARTED="$(date +%s)"; LOG=""
else
  NAME="${1:?用法: $0 <实例名> [超时]}"; TIMEOUT="${2:-3600}"
  STATE="${STATE_DIR}/${NAME}.env"
  [[ -f "${STATE}" ]] || die "没有实例 ${NAME}（bash scripts/engine.sh status）"
  # shellcheck disable=SC1090
  source "${STATE}"
fi
URL="http://127.0.0.1:${PORT}/health"
log "等待 ${URL}（最长 ${TIMEOUT}s）"
while true; do
  code="$(curl -s -o /dev/null -m 3 -w '%{http_code}' "${URL}" || true)"
  now="$(date +%s)"; el=$(( now - STARTED ))
  if [[ "${code}" == "200" ]]; then
    log "就绪，启动耗时 ${el}s"
    [[ -n "${STATE:-}" ]] && echo "READY_AFTER_S=${el}" >> "${STATE}"
    [[ -n "${LOG:-}" ]] && echo "# [lab] READY after ${el}s" >> "${LOG}"
    exit 0
  fi
  if [[ -n "${LOG:-}" ]] && grep -qE "Traceback|CUDA out of memory|OutOfMemoryError|RuntimeError: |Engine core initialization failed|ValueError: " "${LOG}" 2>/dev/null; then
    if ! { [[ "${ENGINE_MODE}" == "docker" ]] && docker ps --format '{{.Names}}' | grep -qx "lab-${NAME}"; } && ! [[ "${ENGINE_MODE}" == "venv" ]]; then
      warn "容器已退出，日志中有错误："; grep -nE "Traceback|Error|error" "${LOG}" | tail -20 >&2; exit 1
    fi
  fi
  if (( el > TIMEOUT )); then warn "超时 ${TIMEOUT}s 未就绪；查看日志: bash scripts/engine.sh logs ${NAME} 200"; exit 1; fi
  if (( el % 60 < 5 )); then log "已等待 ${el}s ... 最新日志: $(tail -n 1 "${LOG:-/dev/null}" 2>/dev/null | cut -c1-150)"; fi
  sleep 5
done
