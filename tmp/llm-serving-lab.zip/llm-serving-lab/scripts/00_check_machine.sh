#!/usr/bin/env bash
# 只读检查本机条件，生成报告 runtime/logs/machine/check-<时间>.md。不修改任何系统设置。
# 判定项：驱动版本、GPU 数量与显存、NVLink 拓扑、内存、磁盘、Docker 与 GPU 容器支持、profiling 权限。
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
ensure_runtime_dirs
REPORT="${LOGS_DIR}/machine/check-$(ts).md"
PASS=0; WARN=0; FAIL=0
ok()   { echo "- [通过] $*" >> "${REPORT}"; PASS=$((PASS+1)); }
bad()  { echo "- [失败] $*" >> "${REPORT}"; FAIL=$((FAIL+1)); }
note() { echo "- [注意] $*" >> "${REPORT}"; WARN=$((WARN+1)); }
section() { printf '\n## %s\n\n' "$*" >> "${REPORT}"; }
raw() { echo '```text' >> "${REPORT}"; "$@" >> "${REPORT}" 2>&1 || true; echo '```' >> "${REPORT}"; }

echo "# 机器检查报告 $(date -Iseconds)" > "${REPORT}"
echo "" >> "${REPORT}"
echo "主机: $(hostname)  LAB_ROOT: ${LAB_ROOT}" >> "${REPORT}"

section "系统"
raw uname -a
raw bash -c 'cat /etc/os-release | head -4'
CPU_CORES="$(nproc)"
echo "- CPU 逻辑核数: ${CPU_CORES}" >> "${REPORT}"
raw lscpu
MEM_GB="$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo)"
echo "- 内存: ${MEM_GB} GiB" >> "${REPORT}"
if (( MEM_GB >= 384 )); then ok "内存 ≥ 384 GiB，DeepSeek-V4.1 的 Engram 表（约 183 GiB）可以放到主机内存";
elif (( MEM_GB >= 256 )); then note "内存 ${MEM_GB} GiB：Engram 放主机内存会很紧，DeepSeek 实验前先关闭其他占内存的进程";
else bad "内存 ${MEM_GB} GiB < 256 GiB：DeepSeek-V4.1-Flash 在 8×80GB 上必须把 Engram 放到主机内存，内存不够则无法部署"; fi
raw bash -c 'df -h /dev/shm; echo; ulimit -a | grep -E "locked|open files|stack"'
raw bash -c 'grep -E "HugePages_(Total|Free)|Hugepagesize" /proc/meminfo'

section "磁盘"
mkdir -p "${MODELS_DIR}"
raw df -h "${LAB_ROOT}" "${MODELS_DIR}"
FREE_GB="$(df -BG --output=avail "${MODELS_DIR}" | tail -1 | tr -dc '0-9')"
if (( FREE_GB >= 1200 )); then ok "MODELS_DIR 可用 ${FREE_GB} GB，够放四个模型（约 917 GB）";
elif (( FREE_GB >= 450 )); then note "MODELS_DIR 只有 ${FREE_GB} GB，放不下全部模型；可以先只下载 qwen3-8b、glm-4.7-flash、glm-5.3-flash（约 407 GB）";
else bad "MODELS_DIR 只有 ${FREE_GB} GB，请在 lab.env 中把 MODELS_DIR 改到大盘"; fi

section "GPU 与驱动"
if ! command -v nvidia-smi >/dev/null; then
  bad "找不到 nvidia-smi，无法继续"
else
  raw nvidia-smi
  raw nvidia-smi --query-gpu=index,name,memory.total,pci.bus_id,persistence_mode,mig.mode.current,clocks.max.sm,power.limit --format=csv
  NGPU="$(nvidia-smi -L | wc -l)"
  DRIVER="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1)"
  DRIVER_MAJOR="${DRIVER%%.*}"
  GPU_NAME="$(nvidia-smi --query-gpu=name --format=csv,noheader | head -1)"
  echo "- GPU: ${NGPU} × ${GPU_NAME}，驱动 ${DRIVER}" >> "${REPORT}"
  (( NGPU >= NUM_GPUS )) && ok "GPU 数量 ${NGPU}" || bad "GPU 数量 ${NGPU} < lab.env 中的 NUM_GPUS=${NUM_GPUS}"
  if (( DRIVER_MAJOR >= 580 )); then ok "驱动 ${DRIVER} 支持 CUDA 13：vLLM 默认镜像和 SGLang 都可用";
  else bad "驱动 ${DRIVER} < 580：把 lab.env 的 VLLM_IMAGE 改为 vllm/vllm-openai:v0.32.0-cu129；SGLang 0.5.20 之后只支持 CUDA 13，需要请管理员升级驱动（或确认数据中心卡的 CUDA forward compatibility 可用），见 docs/99"; fi
  if nvidia-smi --query-gpu=mig.mode.current --format=csv,noheader | grep -qi enabled; then bad "有 GPU 开启了 MIG，需要管理员关闭"; else ok "未开启 MIG"; fi
  section "GPU 互联拓扑"
  raw nvidia-smi topo -m
  raw nvidia-smi nvlink -s -i 0
  if nvidia-smi nvlink -s -i 0 2>/dev/null | grep -q "GB/s"; then ok "检测到 NVLink（各链路速率见上；H800 的 NVLink 总带宽约 400 GB/s，H100 约 900 GB/s）";
  else note "没有检测到 NVLink：可能是 PCIe 版 H800。TP 跨卡通信会很慢，实验结论要单独注明"; fi
  section "Profiling 权限"
  if grep -q "RmProfilingAdminOnly: 1" /proc/driver/nvidia/params 2>/dev/null; then
    note "RmProfilingAdminOnly=1：非 root 用户不能用 Nsight Compute / nsys GPU metrics 采样硬件计数器（PyTorch Profiler 和 nsys 时间线不受影响）。需要时请管理员设置 NVreg_RestrictProfilingToAdminUsers=0，或在容器里以 root 运行"
  else ok "未限制 GPU 性能计数器访问（或无法读取该参数）"; fi
fi

section "网络（只读）"
raw bash -c 'ls /sys/class/infiniband 2>/dev/null || echo "无 InfiniBand 设备"'
raw bash -c 'ip -brief addr 2>/dev/null | head -20'
echo "- 同网段其他机器访问网关时使用上面的本机地址 + GATEWAY_PORT=${GATEWAY_PORT}" >> "${REPORT}"

section "容器与工具"
if command -v docker >/dev/null; then
  raw docker --version
  if docker info >/dev/null 2>&1; then
    ok "当前用户可以使用 docker"
    if docker info 2>/dev/null | grep -qiE "nvidia"; then ok "docker 已注册 nvidia runtime"; else note "docker info 中没有 nvidia runtime，GPU 容器可能无法启动；拉取镜像后用 scripts/02_pull_images.sh --test 验证"; fi
  else
    note "docker 已安装但当前用户无权限（需要加入 docker 组或使用 sudo）；或者把 lab.env 的 ENGINE_MODE 改成 venv"
  fi
else
  note "没有 docker：把 lab.env 的 ENGINE_MODE 改成 venv；网关改用引擎自带的 --api-key（见 docs/05 的无 docker 方案）"
fi
for c in python3 curl git tar nsys ncu dcgmi numactl; do
  if command -v "$c" >/dev/null; then echo "- 有 $c: $(command -v "$c")" >> "${REPORT}"; else echo "- 无 $c" >> "${REPORT}"; fi
done

section "汇总"
echo "通过 ${PASS} 项，注意 ${WARN} 项，失败 ${FAIL} 项。" >> "${REPORT}"
log "报告已写入 ${REPORT}"
log "通过 ${PASS}，注意 ${WARN}，失败 ${FAIL}"
(( FAIL == 0 )) || warn "存在失败项，先按报告处理再继续（docs/02-机器检查.md 有逐项说明）"
