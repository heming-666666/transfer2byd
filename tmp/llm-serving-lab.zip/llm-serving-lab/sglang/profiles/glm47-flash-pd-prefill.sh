# shellcheck shell=bash disable=SC2034
DESC="glm47-flash PD 分离：prefill 角色（NIXL 传输），GPU 0,1，端口 31000"
# 来源：SGLang cookbook GLM-5.3-Flash 的 PD 示例与运维说明：同机两个角色要用不同的 --nccl-port；
#   同机 NIXL 需要 UCX_NET_DEVICES=lo 与 UCX_TLS=tcp,cuda_copy,cuda_ipc,self,sm；两个角色保持相同 TP。
#   前端用 scripts/router.sh start sglang-pd --prefill http://127.0.0.1:31000 --bootstrap 8998 --decode http://127.0.0.1:32000
MODEL_KEY="glm-4.7-flash"
SERVED_NAME="glm-4.7-flash"
GPUS="0,1"
PORT=31000
ENV_VARS=(
  UCX_NET_DEVICES=lo
  UCX_TLS=tcp,cuda_copy,cuda_ipc,self,sm
)
ARGS=(
  --tp-size 2
  --context-length 65536
  --mem-fraction-static 0.80
  --disaggregation-mode prefill
  --disaggregation-bootstrap-port 8998
  --disaggregation-transfer-backend nixl
  --nccl-port 29501
  --attention-backend triton
  --reasoning-parser glm45
  --tool-call-parser glm47
  --enable-metrics
)
