# shellcheck shell=bash disable=SC2034
DESC="【实验性】DeepSeek-V4.1-Flash-1017 TP8+EP8，Engram 表放主机内存（SGLang 官方未列出 H100/H800 配置）"
# 依据：SGLang cookbook 的 H200 配置（hw=h200 variant=flash-1017 high-throughput：--tp 8 --ep-size 8 --attention-backend dsv4
#   --moe-runner-backend flashinfer_mxfp4 --cuda-graph-max-bs-decode 64）。H200 有 141 GB，H800 只有 80 GB：
#   权重约 476 GiB，其中 Engram 表约 183 GiB，不放到主机内存时每卡约 60 GiB 权重，KV 几乎没有空间。
#   v0.5.23 没有 --engram-config（只在 main 分支），用旧环境变量 SGLANG_ENABLE_DSV41_ENGRAM_HOST_TABLE=1（默认 shared 布局，
#   需要 --ipc=host，engine.sh 已带）。启动日志应出现 "Engram" 相关行确认生效。
#   v0.5.23 启动失败时，在 profile 里设置 IMAGE="${SGLANG_DSV41_FALLBACK_IMAGE}" 重试，并记录两者差异。
MODEL_KEY="deepseek-v4.1-flash-1017"
SERVED_NAME="deepseek-v4.1-flash"
GPUS="0,1,2,3,4,5,6,7"
ENV_VARS=(
  SGLANG_ENABLE_DSV41_ENGRAM_HOST_TABLE=1
)
ARGS=(
  --trust-remote-code
  --tp-size 8
  --ep-size 8
  --mem-fraction-static 0.85
  --attention-backend dsv4
  --moe-runner-backend flashinfer_mxfp4
  --cuda-graph-max-bs-decode 64
  --max-running-requests 64
  --language-model-only
  --reasoning-parser auto
  --tool-call-parser auto
  --enable-metrics
)
