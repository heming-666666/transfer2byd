# shellcheck shell=bash disable=SC2034
DESC="【实验性】DeepSeek-V4.1-Flash TP8+EP8 + DSpark 投机解码（块大小 5）"
# 依据：cookbook Playground 的 DSpark 选项（--speculative-algorithm DSPARK --speculative-dspark-block-size 5）
MODEL_KEY="deepseek-v4.1-flash-1017"
SERVED_NAME="deepseek-v4.1-flash"
GPUS="0,1,2,3,4,5,6,7"
ENV_VARS=(
  SGLANG_ENABLE_DSV41_ENGRAM_HOST_TABLE=1
)
ARGS=(
  --trust-remote-code
  --tp-size 8
  --ep-size 8
  --mem-fraction-static 0.85
  --attention-backend dsv4
  --moe-runner-backend flashinfer_mxfp4
  --cuda-graph-max-bs-decode 64
  --max-running-requests 32
  --language-model-only
  --speculative-algorithm DSPARK
  --speculative-dspark-block-size 5
  --reasoning-parser auto
  --tool-call-parser auto
  --enable-metrics
)
