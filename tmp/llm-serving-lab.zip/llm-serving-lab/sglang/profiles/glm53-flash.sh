# shellcheck shell=bash disable=SC2034
DESC="GLM-5.3-Flash FP8 高吞吐配置：TP8+EP8，BF16 KV + TileLang DSA，DeepGEMM MoE（SGLang cookbook 的 H100 配置）"
# 来源：sgl-project/sglang docs/src/snippets/configs/zai-org/glm-5.3-flash.jsx，hw=h100 strategy=high-throughput（标记 verified）
#   Hopper 上 FP8 KV + TRT-LLM DSA 不可用；--mem-fraction-static 0.75；KDA 状态池与 KV 池共享显存（--mamba-full-memory-ratio 默认 0.9，见 E13）
MODEL_KEY="glm-5.3-flash"
SERVED_NAME="glm-5.3-flash"
GPUS="0,1,2,3,4,5,6,7"
ARGS=(
  --tp-size 8
  --ep-size 8
  --mem-fraction-static 0.75
  --dsa-prefill-backend tilelang
  --dsa-decode-backend tilelang
  --kv-cache-dtype bfloat16
  --moe-runner-backend deep_gemm
  --reasoning-parser auto
  --tool-call-parser auto
  --enable-metrics
)
