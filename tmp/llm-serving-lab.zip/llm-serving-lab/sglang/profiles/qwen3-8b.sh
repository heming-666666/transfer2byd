# shellcheck shell=bash disable=SC2034
DESC="Qwen3-8B 稠密 GQA 基线，单卡；扫参时在 -- 之后追加参数"
# 解析器名在 SGLang v0.5.23 server_arguments 文档中核对；--enable-metrics 打开 /metrics
MODEL_KEY="qwen3-8b"
SERVED_NAME="qwen3-8b"
GPUS="0"
ARGS=(
  --tp-size 1
  --context-length 32768
  --mem-fraction-static 0.85
  --reasoning-parser qwen3
  --tool-call-parser qwen25
  --enable-metrics
)
