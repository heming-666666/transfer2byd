# shellcheck shell=bash disable=SC2034
DESC="GLM-5.3-Flash 低延迟配置：TP8+EP8 + MTP（EAGLE 5/1/6）"
# 来源：同上 jsx，hw=h100 strategy=low-latency（SGLang 用 --speculative-algorithm EAGLE 承载 MTP）
MODEL_KEY="glm-5.3-flash"
SERVED_NAME="glm-5.3-flash"
GPUS="0,1,2,3,4,5,6,7"
ARGS=(
  --tp-size 8
  --ep-size 8
  --mem-fraction-static 0.70
  --dsa-prefill-backend tilelang
  --dsa-decode-backend tilelang
  --kv-cache-dtype bfloat16
  --moe-runner-backend deep_gemm
  --speculative-algorithm EAGLE
  --speculative-num-steps 5
  --speculative-eagle-topk 1
  --speculative-num-draft-tokens 6
  --reasoning-parser auto
  --tool-call-parser auto
  --enable-metrics
)
