# shellcheck shell=bash disable=SC2034
DESC="GLM-4.7-Flash（31B MoE，MLA，带 MTP），默认 TP2"
# 来源：SGLang cookbook GLM-4.7-Flash（推荐 --attention-backend triton；GLM 全系 --reasoning-parser glm45，4.7 系列 --tool-call-parser glm47）
MODEL_KEY="glm-4.7-flash"
SERVED_NAME="glm-4.7-flash"
GPUS="0,1"
ARGS=(
  --tp-size 2
  --context-length 65536
  --mem-fraction-static 0.85
  --attention-backend triton
  --reasoning-parser glm45
  --tool-call-parser glm47
  --enable-metrics
)
