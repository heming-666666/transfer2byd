# profile 文件格式（vLLM 与 SGLang 通用）

profile 是一个会被 `scripts/engine.sh` source 的 bash 片段，只设置变量：

| 变量 | 必需 | 含义 |
|---|---|---|
| `DESC` | 建议 | 一句话说明，`engine.sh profiles` 会显示 |
| `MODEL_KEY` | 是 | `runtime/models/` 下的目录名，也是 `configs/models/<key>.manifest.json` 的 key |
| `SERVED_NAME` | 否 | API 中的模型名（`/v1/models` 返回的名字），默认等于 MODEL_KEY |
| `GPUS` | 否 | 逗号分隔的 GPU 编号，作为 `CUDA_VISIBLE_DEVICES`，默认 `0` |
| `PORT` | 否 | 默认取 lab.env 的 `VLLM_PORT` / `SGLANG_PORT` |
| `IMAGE` | 否 | 覆盖默认镜像（例如 SGLang 的 DeepSeek 备用镜像） |
| `ENV_VARS=( K=V ... )` | 否 | 传给引擎进程的环境变量 |
| `ARGS=( ... )` | 是 | 引擎参数，不要包含模型路径、`--host`、`--port`、`--served-model-name`（engine.sh 自动加） |

profile 中可以引用的只读变量：

- `MODEL_PATH`：模型目录；docker 模式下为 `/models/<key>`
- `TRACE_ROOT`：trace 输出根目录；docker 模式下为 `/traces`
- `RESULT_ROOT`：结果根目录；docker 模式下为 `/results`

实验扫参时不需要新建 profile，在启动命令的 `--` 之后追加参数即可。argparse 对同名参数取最后一次出现的值：

```bash
bash scripts/engine.sh start vllm qwen3-8b --gpus 0,1,2,3 --name v-tp4 -- --tensor-parallel-size 4
bash scripts/engine.sh cmd vllm qwen3-8b -- --tensor-parallel-size 4    # 只打印命令，用于核对
```

新增 profile 时，在文件头的注释中写明参数来源（官方 recipe、cookbook 或某次实验的结论）。
