# shellcheck shell=bash disable=SC2034
DESC="qwen3-8b PD 分离：decode 角色（NIXL 传输），GPU 1，端口 32000"
# 来源：SGLang cookbook GLM-5.3-Flash 的 PD 示例与运维说明：同机两个角色要用不同的 --nccl-port；
#   同机 NIXL 需要 UCX_NET_DEVICES=lo 与 UCX_TLS=tcp,cuda_copy,cuda_ipc,self,sm；两个角色保持相同 TP。
#   前端用 scripts/router.sh start sglang-pd --prefill http://127.0.0.1:31000 --bootstrap 8998 --decode http://127.0.0.1:32000
MODEL_KEY="qwen3-8b"
SERVED_NAME="qwen3-8b"
GPUS="1"
PORT=32000
ENV_VARS=(
  UCX_NET_DEVICES=lo
  UCX_TLS=tcp,cuda_copy,cuda_ipc,self,sm
)
ARGS=(
  --tp-size 1
  --context-length 32768
  --mem-fraction-static 0.80
  --disaggregation-mode decode
  --disaggregation-transfer-backend nixl
  --nccl-port 29601
  --reasoning-parser qwen3
  --tool-call-parser qwen25
  --enable-metrics
)
