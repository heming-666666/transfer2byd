# 21 SGLang 部署 Qwen3-8B 与 GLM-4.7-Flash

SGLang 默认端口是 30000（`lab.env` 中的 `SGLANG_PORT`），可以和 vLLM 同时运行，但不能占用同一组 GPU。

## 1. Qwen3-8B

```bash
bash scripts/engine.sh start sglang qwen3-8b
bash scripts/wait_ready.sh sglang-qwen3-8b
PY=runtime/envs/client/bin/python
$PY tools/parse_server_log.py runtime/logs/engines/sglang-qwen3-8b.latest.log
$PY tools/smoke_test.py --base-url http://127.0.0.1:30000/v1 --no-auth-check --out runtime/results/E01/smoke-sglang-qwen3-8b.json
curl -s 127.0.0.1:30000/get_server_info | python3 -m json.tool | head -60     # 解析后的全部参数
```

从日志中记录：

- `KV Cache is allocated. #tokens: ...`（KV 池大小）
- `max_total_num_tokens`、`max_running_requests`、`chunked_prefill_size`
- CUDA graph 捕获耗时与显存

## 2. GLM-4.7-Flash（TP2）

```bash
bash scripts/engine.sh start sglang glm47-flash
bash scripts/wait_ready.sh sglang-glm47-flash
$PY tools/smoke_test.py --base-url http://127.0.0.1:30000/v1 --no-auth-check --out runtime/results/E01/smoke-sglang-glm47-flash.json
```

EAGLE/MTP 投机解码（cookbook 写法）：

```bash
bash scripts/engine.sh start sglang glm47-flash --name sglang-glm47-mtp -- \
  --speculative-algorithm EAGLE --speculative-num-steps 3 --speculative-eagle-topk 1 --speculative-num-draft-tokens 4
```

## 3. 与 vLLM 参数的对应关系

| 目的 | SGLang | vLLM |
|---|---|---|
| 张量并行 | `--tp-size` | `--tensor-parallel-size` |
| 数据并行 | `--dp-size` | `--data-parallel-size` |
| 专家并行 | `--ep-size` | `--enable-expert-parallel`（EP 规模 = TP×DP） |
| 流水线并行 | `--pp-size` | `--pipeline-parallel-size` |
| 显存比例 | `--mem-fraction-static`（权重 + KV） | `--gpu-memory-utilization`（全部） |
| 最大上下文 | `--context-length` | `--max-model-len` |
| 并发上限 | `--max-running-requests` | `--max-num-seqs` |
| 分块预填充 | `--chunked-prefill-size` | `--max-num-batched-tokens` |
| 关闭 CUDA graph | `--disable-cuda-graph` | `--enforce-eager` |
| 关闭前缀缓存 | `--disable-radix-cache` | `--no-enable-prefix-caching` |
| KV dtype | `--kv-cache-dtype fp8_e4m3` | `--kv-cache-dtype fp8` |
| 结构化输出后端 | `--grammar-backend xgrammar\|outlines\|llguidance` | `--structured-outputs-config.backend xgrammar\|guidance\|outlines\|lm-format-enforcer` |
| 指标 | `--enable-metrics` | 默认开启 |

## 本机实测记录
