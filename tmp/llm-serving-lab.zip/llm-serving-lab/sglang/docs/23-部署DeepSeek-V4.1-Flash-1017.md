# 23 SGLang 部署 DeepSeek-V4.1-Flash-1017【实验性】

## 1. 现状（2026-10-31 核对）

- **硬件矩阵**：SGLang cookbook 支持的硬件为 H200、B200、B300、GB300、MI355X，**没有 H100 或 H800**。H200 是其中显存最小的（141 GB），cookbook 说它“最紧张”。
- **镜像**：cookbook 写着 NVIDIA 平台要用预览镜像 `lmsysorg/sglang:dev-dsv41`（构建于 2026-09-11）。但 v0.5.22 和 v0.5.23 的源码中已经包含 DeepSeek-V4.1 的实现（`models/deepseek_v4.py`、`deepseek_v41_vit.py`、`deepseek_v4_dspark.py`）。本包先用 v0.5.23，失败时再换回预览镜像。
- **Engram 参数**：cookbook 的 `--engram-config` 只在 main 分支，v0.5.23 中没有。v0.5.23 用旧的环境变量 `SGLANG_ENABLE_DSV41_ENGRAM_HOST_TABLE=1`（默认布局为 shared）。

因此这一步是一次真正的**探索**。不论成功与否，都是有价值的实验记录。

## 2. 显存账

H200 配置为 TP8+EP8、`--mem-fraction-static 0.8`，Engram 表留在 GPU 上，按 TP 切分。

| 项 | H200 | H800 不卸载 Engram | H800 卸载 Engram（profile 默认） |
|---|---|---|---|
| 每卡显存 | 141 GB | 80 GB | 80 GB |
| 每卡权重 | 约 60 GiB | 约 60 GiB | 约 37 GiB |
| 剩余（KV + 激活 + graph） | 宽裕 | 几乎没有 | 有余量 |

## 3. 启动

```bash
free -g
bash scripts/engine.sh start sglang dsv41-flash
bash scripts/wait_ready.sh sglang-dsv41-flash 5400
grep -iE "engram|host table|placement" runtime/logs/engines/sglang-dsv41-flash.latest.log | head    # 确认 Engram 表在主机内存
runtime/envs/client/bin/python tools/parse_server_log.py runtime/logs/engines/sglang-dsv41-flash.latest.log --max-lines 150
```

## 4. 失败时的排查顺序（每一步都要记录）

1. **主机内存不足**（进程被 OOM killer 杀掉）：确认 `free -g` 中的可用量 ≥ 220 GiB。
2. **GPU OOM**：
   - 把 `--mem-fraction-static` 从 0.85 降到 0.80；
   - 把 `--cuda-graph-max-bs-decode` 降到 32；
   - 把 `--max-running-requests` 降到 32。
3. **CUDA graph 捕获失败**：加 `-- --disable-cuda-graph` 先确认模型本身能跑，再逐步恢复。
4. **v0.5.23 不支持**（例如模型类找不到，或某个 kernel 不支持 SM90）：
   - 在 profile 中加一行 `IMAGE="${SGLANG_DSV41_FALLBACK_IMAGE}"`，先执行 `bash scripts/02_pull_images.sh --fallback`，再重试；
   - 记录两个镜像的差异。
5. **都不行**：DeepSeek 只用 vLLM 部署（官方 recipe 在 8×80GB 档有验证）。把 SGLang 的失败原因写进 worklog，这本身就是两个框架的对比结论。

## 5. 使用注意（cookbook）

- **思考默认关闭**（`SGLANG_DEFAULT_THINKING=false`）。请求中带 `reasoning_effort`（`low`/`high`/`xhigh`/`max`）会自动打开。思考内容在 `reasoning_content` 中。
- **工具调用**：需要 `deepseekv41` 解析器；`--tool-call-parser auto` 会自动选择。
- **不要覆盖后端**：cookbook 特别提醒，随意指定 `--attention-backend`、`--moe-runner-backend`、`--fp8-gemm-backend` 会让 32 宽的 UE8M0 块落到 Triton 回退 kernel，导致 decode 很慢。本 profile 照抄 H200 配置中显式写出的两个后端；如果速度异常，先去掉它们。
- **输出不是逐位稳定的**：结果会随 batch 组成变化，`--enable-deterministic-inference` 在这个后端上会被拒绝。
- **DSpark**：profile `dsv41-flash-dspark`。接受率高度依赖负载（数学和代码最高，智能体轨迹最低）；高并发下固定的步开销可能抵消收益（E18）。

## 本机实测记录
