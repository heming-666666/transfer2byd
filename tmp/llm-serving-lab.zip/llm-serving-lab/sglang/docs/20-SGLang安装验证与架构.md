# 20 SGLang 安装验证与架构

## 1. 验证镜像

```bash
source lab.env
docker run --rm --gpus all --entrypoint python3 "$SGLANG_IMAGE" -c "import sglang; print(sglang.__version__)"   # 期望 0.5.23
docker run --rm --gpus all --entrypoint python3 "$SGLANG_IMAGE" -m sglang.check_env > runtime/logs/machine/sglang-check-env.txt
```

## 2. 运行时架构

```text
python -m sglang.launch_server
 ├─ TokenizerManager（HTTP/OpenAI 接口、分词、聊天模板、reasoning/tool 解析）
 ├─ Scheduler（每个 TP 组一个；批调度、RadixAttention 前缀树、KV 池管理）
 │    └─ TpModelWorker / ModelRunner（GPU 执行、CUDA graph、attention 后端）
 └─ DetokenizerManager（增量解码文本）
```

几个关键机制：

- **RadixAttention**：前缀 KV 组织成基数树，不同请求自动共享（`--disable-radix-cache` 可关闭）。
- **重叠调度（overlap scheduler）**：CPU 准备下一批的同时，GPU 执行当前批（`--disable-overlap-schedule` 可关闭，E17 对比 CPU 开销）。
- **分块预填充**：`--chunked-prefill-size` 设置块大小；`--max-prefill-tokens` 限制每批预填充的 token 数。
- **CUDA graph**：
  - decode 用完整 graph，`--cuda-graph-max-bs-decode` 限制捕获的最大 batch。
  - prefill 可用 breakable graph（`--cuda-graph-backend-prefill breakable`），GLM-5.3-Flash 在 v0.5.22 已默认开启。
- **DP attention**：`--attn-dp-size`（v0.5.22 起取代 `--enable-dp-attention`）。attention 按数据并行，MoE 按专家或张量并行，适合 MLA 模型（E08）。
- **显存池**：`--mem-fraction-static` 是权重 + KV 池占显存的比例，剩余部分留给激活和 CUDA graph。这与 vLLM 的 `--gpu-memory-utilization` 含义不同，对比时要注意。

## 3. 源码阅读路线（v0.5.23，已核对路径存在）

| 主题 | 文件 |
|---|---|
| 调度器 | `python/sglang/srt/managers/scheduler.py`、`schedule_policy.py` |
| HTTP 入口、分词 | `python/sglang/srt/entrypoints/http_server.py`、`managers/tokenizer_manager.py` |
| 模型执行 | `python/sglang/srt/model_executor/model_runner.py` |
| CUDA graph | `python/sglang/srt/model_executor/runner/decode_cuda_graph_runner.py`、`prefill_cuda_graph_runner.py` |
| 前缀树与 KV 池 | `python/sglang/srt/mem_cache/radix_cache.py`、`memory_pool.py` |
| attention 后端 | `python/sglang/srt/layers/attention/`（DSA 在 `dsa/` 子目录） |
| MoE 与 EP | `python/sglang/srt/layers/moe/`、`python/sglang/srt/eplb/`（专家分布记录器：`eplb/expert_distribution.py`） |
| PD 分离 | `python/sglang/srt/disaggregation/` |
| 投机解码 | `python/sglang/srt/speculative/` |
| GLM-5.3-Flash | `python/sglang/srt/models/glm5_next.py`、`glm5_next_nextn.py` |
| DeepSeek-V4.1 | `python/sglang/srt/models/deepseek_v4.py`、`deepseek_v41_vit.py`、`deepseek_v4_dspark.py` |

## 4. 常用工具

| 命令 | 用途 |
|---|---|
| `python3 -m sglang.benchmark.serving` | 在线压测（旧路径 `sglang.bench_serving` 仍可用，但已弃用） |
| `python3 -m sglang.benchmark.one_batch` | 单个静态 batch 的 kernel 级延迟，不经过调度器 |
| `python3 -m sglang.benchmark.offline_throughput` | 进程内最大吞吐 |
| `python3 -m sglang.profiler` | 对运行中的服务做实时 profiling |
| HTTP 端点 `/start_profile`、`/stop_profile`、`/flush_cache`、`/get_server_info`、`/start_expert_distribution_record` 等 | 运行时控制 |

## 本机实测记录
