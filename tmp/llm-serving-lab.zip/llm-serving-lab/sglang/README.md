# SGLang 部分

版本：SGLang **v0.5.23**（镜像 `lmsysorg/sglang:v0.5.23`，2026-10-30 发布；只支持 CUDA 13，驱动需 ≥ 580）。

| 文档 | 内容 |
|---|---|
| `docs/20-SGLang安装验证与架构.md` | 镜像验证、运行时架构、源码阅读路线 |
| `docs/21-部署Qwen3-8B与GLM-4.7-Flash.md` | 小模型跑通、常用参数 |
| `docs/22-部署GLM-5.3-Flash.md` | TP8+EP8，DSA/KDA 后端，两个显存池，MTP |
| `docs/23-部署DeepSeek-V4.1-Flash-1017.md` | 【实验性】官方未列出 80GB Hopper 配置，Engram 放主机内存 |
| `docs/24-对外服务与两框架对比.md` | 接入网关、vLLM 与 SGLang 的对照表、同条件对比方法 |

启动方式统一为 `bash scripts/engine.sh start sglang <profile>`，profile 格式见 `profiles/README.md`。
