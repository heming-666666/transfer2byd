# shellcheck shell=bash disable=SC2034
DESC="glm47-flash PD 分离：decode 角色（NixlConnector，kv_consumer），GPU 2,3，端口 8002"
# 来源：vLLM v0.32.0 docs/features/nixl_connector_usage.md（同机示例）。两个角色各自需要不同的 VLLM_NIXL_SIDE_CHANNEL_PORT；
# TP/DP 时每个 worker 用 base_port + dp_rank，所以两个角色的基址相差 10。前端用 scripts/router.sh start vllm-pd。
MODEL_KEY="glm-4.7-flash"
SERVED_NAME="glm-4.7-flash"
GPUS="2,3"
PORT=8002
ENV_VARS=(
  UCX_NET_DEVICES=all
  VLLM_NIXL_SIDE_CHANNEL_PORT=5610
)
ARGS=(
  --tensor-parallel-size 2
  --max-model-len 65536
  --gpu-memory-utilization 0.90
  --kv-transfer-config '{"kv_connector":"NixlConnector","kv_role":"kv_consumer","kv_load_failure_policy":"fail"}'
  --reasoning-parser glm45
  --enable-auto-tool-choice --tool-call-parser glm47
)
