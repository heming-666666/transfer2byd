# shellcheck shell=bash disable=SC2034
DESC="DeepSeek-V4.1-Flash TP8，加载视觉编码器（图文输入），ViT 用数据并行"
# 来源：同上 recipe 的 features.encoder_parallel（--mm-encoder-tp-mode data，与 --language-model-only 互斥）
MODEL_KEY="deepseek-v4.1-flash-1017"
SERVED_NAME="deepseek-v4.1-flash"
GPUS="0,1,2,3,4,5,6,7"
ENV_VARS=(
  VLLM_USE_V2_MODEL_RUNNER=1
  PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
)
ARGS=(
  --tensor-parallel-size 8
  --tokenizer-mode deepseek_v41
  --engram-config '{"cpu_offload":true}'
  --max-num-batched-tokens 4096
  --gpu-memory-utilization 0.92
  --mm-encoder-tp-mode data
  --reasoning-parser deepseek_v41
  --enable-auto-tool-choice --tool-call-parser deepseek_v41
)
