# shellcheck shell=bash disable=SC2034
DESC="GLM-4.7-Flash（31B MoE，64 专家选 4，MLA，带 MTP），默认 TP2；并行/EP/PD/投机解码实验的主力模型"
# 来源：vllm-project/recipes GLM/GLM.md（GLM-4.7 系列用 --tool-call-parser glm47 --reasoning-parser glm45）
# BF16 权重约 58 GiB：单卡能放下但 KV 很少，所以默认用两张卡。
MODEL_KEY="glm-4.7-flash"
SERVED_NAME="glm-4.7-flash"
GPUS="0,1"
ARGS=(
  --tensor-parallel-size 2
  --max-model-len 65536
  --gpu-memory-utilization 0.90
  --reasoning-parser glm45
  --enable-auto-tool-choice --tool-call-parser glm47
)
