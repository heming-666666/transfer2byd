# shellcheck shell=bash disable=SC2034
DESC="GLM-5.3-Flash TP8 + 内置 MTP 投机解码（5 个草稿 token，recipe 默认值）"
# 来源：vllm-project/recipes models/zai-org/GLM-5.3-Flash.yaml features.spec_decoding.modes.mtp
MODEL_KEY="glm-5.3-flash"
SERVED_NAME="glm-5.3-flash"
GPUS="0,1,2,3,4,5,6,7"
ARGS=(
  --tensor-parallel-size 8
  --max-model-len 131072
  --gpu-memory-utilization 0.90
  --no-enable-flashinfer-autotune
  --speculative-config '{"method":"mtp","num_speculative_tokens":5}'
  --reasoning-parser glm47
  --enable-auto-tool-choice --tool-call-parser glm47
)
