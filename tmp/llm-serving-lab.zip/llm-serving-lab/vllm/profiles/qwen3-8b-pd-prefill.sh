# shellcheck shell=bash disable=SC2034
DESC="qwen3-8b PD 分离：prefill 角色（NixlConnector，kv_producer），GPU 0，端口 8001"
# 来源：vLLM v0.32.0 docs/features/nixl_connector_usage.md（同机示例）。两个角色各自需要不同的 VLLM_NIXL_SIDE_CHANNEL_PORT；
# TP/DP 时每个 worker 用 base_port + dp_rank，所以两个角色的基址相差 10。前端用 scripts/router.sh start vllm-pd。
MODEL_KEY="qwen3-8b"
SERVED_NAME="qwen3-8b"
GPUS="0"
PORT=8001
ENV_VARS=(
  UCX_NET_DEVICES=all
  VLLM_NIXL_SIDE_CHANNEL_PORT=5600
)
ARGS=(
  
  --max-model-len 32768
  --gpu-memory-utilization 0.90
  --kv-transfer-config '{"kv_connector":"NixlConnector","kv_role":"kv_producer","kv_load_failure_policy":"fail"}'
  --reasoning-parser qwen3
  --enable-auto-tool-choice --tool-call-parser hermes
)
