# shellcheck shell=bash disable=SC2034
DESC="Qwen3-8B 稠密 GQA 基线，单卡；扫 TP/PP/attention 后端/KV 量化时在 -- 之后追加参数"
# 来源：vLLM 通用用法；解析器名在 vLLM v0.32.0 源码 vllm/reasoning、vllm/tool_parsers 中核对
MODEL_KEY="qwen3-8b"
SERVED_NAME="qwen3-8b"
GPUS="0"
ARGS=(
  --max-model-len 32768
  --gpu-memory-utilization 0.90
  --reasoning-parser qwen3
  --enable-auto-tool-choice --tool-call-parser hermes
)
