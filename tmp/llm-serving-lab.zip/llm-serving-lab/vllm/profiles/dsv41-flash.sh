# shellcheck shell=bash disable=SC2034
DESC="DeepSeek-V4.1-Flash-1017（MXFP4 专家+MXFP8，约 476 GiB），8 卡 TP8，Engram 表放主机内存，纯文本"
# 来源：vllm-project/recipes models/deepseek-ai/DeepSeek-V4.1-Flash.yaml（2026-10-17）
#   8×80GB（H100 档）是能部署它的最小 NVIDIA 节点，必须使用 recipe 中 h100 的覆盖项：
#     Engram 表（约 183 GiB）放到锁页主机内存（UVA 读取），每卡常驻权重降到约 36 GiB；
#     --max-num-batched-tokens 4096（稀疏注意力 indexer 的 logits 缓冲 = batched_tokens × max_model_len × 2B，8192 时 16 GiB 放不下）；
#     V2 model runner 与 expandable_segments 防止 KV 池碎片。
#   --language-model-only：不加载视觉编码器，把显存让给 KV（需要看图时用 dsv41-flash-vision）。
#   未设置 thinking 时默认开启思考、强度 50；max_tokens 太小会出现 content 为空、finish_reason=length。
MODEL_KEY="deepseek-v4.1-flash-1017"
SERVED_NAME="deepseek-v4.1-flash"
GPUS="0,1,2,3,4,5,6,7"
ENV_VARS=(
  VLLM_USE_V2_MODEL_RUNNER=1
  PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
)
ARGS=(
  --tensor-parallel-size 8
  --tokenizer-mode deepseek_v41
  --engram-config '{"cpu_offload":true}'
  --max-num-batched-tokens 4096
  --gpu-memory-utilization 0.92
  --language-model-only
  --reasoning-parser deepseek_v41
  --enable-auto-tool-choice --tool-call-parser deepseek_v41
)
