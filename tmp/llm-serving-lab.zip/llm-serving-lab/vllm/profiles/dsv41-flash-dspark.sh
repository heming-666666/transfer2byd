# shellcheck shell=bash disable=SC2034
DESC="DeepSeek-V4.1-Flash TP8 + DSpark 投机解码（块大小 5，NVIDIA 上开启自适应验证）"
# 来源：同上 recipe 的 features.spec_decoding；DSpark 的草稿专家约多 14B 参数，显存更紧，必要时调低 --max-num-seqs
MODEL_KEY="deepseek-v4.1-flash-1017"
SERVED_NAME="deepseek-v4.1-flash"
GPUS="0,1,2,3,4,5,6,7"
ENV_VARS=(
  VLLM_USE_V2_MODEL_RUNNER=1
  PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
)
ARGS=(
  --tensor-parallel-size 8
  --tokenizer-mode deepseek_v41
  --engram-config '{"cpu_offload":true}'
  --max-num-batched-tokens 4096
  --gpu-memory-utilization 0.92
  --language-model-only
  --speculative-config '{"method":"dspark","num_speculative_tokens":5,"draft_sample_method":"probabilistic","rejection_sample_method":"block","enable_adaptive_verification":true}'
  --reasoning-parser deepseek_v41
  --enable-auto-tool-choice --tool-call-parser deepseek_v41
)
