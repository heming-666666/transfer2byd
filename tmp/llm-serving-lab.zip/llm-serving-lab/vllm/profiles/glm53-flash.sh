# shellcheck shell=bash disable=SC2034
DESC="GLM-5.3-Flash FP8（320B/激活18B，KDA 线性注意力+稀疏 MLA 混合），8 卡 TP8，H800 上 KV 为 BF16"
# 来源：vllm-project/recipes models/zai-org/GLM-5.3-Flash.yaml（2026-10-08 更新）
#   - Hopper 覆盖项：--no-enable-flashinfer-autotune
#   - 最低显存约 386 GB，所以 8×80GB 只能放一个副本（TP4 放不下）
#   - v0.32.0 起 SM90 可用 --kv-cache-dtype fp8_ds_mla（release note：最多 +31% 输出吞吐），在 E10 中对比
# --max-model-len 设为 131072 以控制显存规划；需要更长上下文时在 -- 后覆盖（模型支持 1M）。
MODEL_KEY="glm-5.3-flash"
SERVED_NAME="glm-5.3-flash"
GPUS="0,1,2,3,4,5,6,7"
ARGS=(
  --tensor-parallel-size 8
  --max-model-len 131072
  --gpu-memory-utilization 0.90
  --no-enable-flashinfer-autotune
  --reasoning-parser glm47
  --enable-auto-tool-choice --tool-call-parser glm47
)
