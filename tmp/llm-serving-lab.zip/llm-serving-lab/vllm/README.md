# vLLM 部分

版本：vLLM **v0.32.0**（镜像 `vllm/vllm-openai:v0.32.0`，2026-10-18 发布）。

| 文档 | 内容 |
|---|---|
| `docs/10-vLLM安装验证与架构.md` | 镜像验证、V1 引擎架构、源码阅读路线 |
| `docs/11-部署Qwen3-8B与GLM-4.7-Flash.md` | 小模型跑通、常用参数说明 |
| `docs/12-部署GLM-5.3-Flash.md` | 8 卡 TP8，KV dtype 选择，MTP |
| `docs/13-部署DeepSeek-V4.1-Flash-1017.md` | 8×80GB 下的显存规划（Engram 卸载）、DSpark、视觉 |
| `docs/14-对外服务与参数速查.md` | 接入网关、生产化参数、全部 profile 一览 |

`profiles/` 中每个文件对应一种启动方式，格式见 `profiles/README.md`，启动方法统一为 `bash scripts/engine.sh start vllm <profile>`。
