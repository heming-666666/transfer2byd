# 11 vLLM 部署 Qwen3-8B 与 GLM-4.7-Flash

前置：docs/02–04 完成，`qwen3-8b` 与 `glm-4.7-flash` 已下载并校验。

## 1. Qwen3-8B（单卡）

```bash
bash scripts/engine.sh cmd vllm qwen3-8b          # 先看完整命令
bash scripts/engine.sh start vllm qwen3-8b
bash scripts/wait_ready.sh vllm-qwen3-8b           # 打印启动耗时
runtime/envs/client/bin/python tools/parse_server_log.py runtime/logs/engines/vllm-qwen3-8b.latest.log
```

从日志中读出并记录到 worklog：

- 权重加载耗时与显存（约 15 GiB）
- KV cache 显存与 token 数
- 最大并发倍数（Maximum concurrency）
- CUDA graph 捕获耗时与显存

直连引擎做冒烟测试（尚未经过网关）：

```bash
PY=runtime/envs/client/bin/python
$PY tools/smoke_test.py --base-url http://127.0.0.1:8000/v1 --no-auth-check --out runtime/results/E01/smoke-vllm-qwen3-8b.json
curl -s 127.0.0.1:8000/v1/chat/completions -H 'Content-Type: application/json' -d '{
  "model":"qwen3-8b","messages":[{"role":"user","content":"用一句话解释 KV cache"}],
  "max_tokens":512,"chat_template_kwargs":{"enable_thinking":false}}' | python3 -m json.tool
bash scripts/engine.sh stop vllm-qwen3-8b
```

## 2. GLM-4.7-Flash（默认 TP2）

```bash
bash scripts/engine.sh start vllm glm47-flash
bash scripts/wait_ready.sh vllm-glm47-flash
$PY tools/smoke_test.py --base-url http://127.0.0.1:8000/v1 --no-auth-check --out runtime/results/E01/smoke-vllm-glm47-flash.json
```

试一下单卡（权重约 58 GiB，KV 空间会很少），对比两者的 KV token 数：

```bash
bash scripts/engine.sh stop vllm-glm47-flash
bash scripts/engine.sh start vllm glm47-flash --gpus 0 --name vllm-glm47-tp1 -- --tensor-parallel-size 1 --max-model-len 16384
bash scripts/wait_ready.sh vllm-glm47-tp1
$PY tools/parse_server_log.py runtime/logs/engines/vllm-glm47-tp1.latest.log | head -12
bash scripts/engine.sh stop vllm-glm47-tp1
```

MTP 投机解码（recipe 建议 `num_speculative_tokens` 取 1）：

```bash
bash scripts/engine.sh start vllm glm47-flash --name vllm-glm47-mtp -- --speculative-config '{"method":"mtp","num_speculative_tokens":1}'
```

## 3. 关键参数说明

| 参数 | 作用 | 调整建议 |
|---|---|---|
| `--tensor-parallel-size` | TP 规模 | 必须能整除注意力头数 |
| `--gpu-memory-utilization` | vLLM 可用的显存比例（权重 + 激活 + KV + CUDA graph） | 0.85–0.95；越高 KV 越多，但更容易 OOM |
| `--max-model-len` | 单个请求的最大上下文 | 越小，profiling 阶段预留的激活越少 |
| `--max-num-seqs` | 一步中最多同时运行的请求数 | 决定 decode batch 的上限 |
| `--max-num-batched-tokens` | 每步的 token 预算（分块预填充的块大小） | E21 详细实验 |
| `--enable-prefix-caching` / `--no-enable-prefix-caching` | 前缀缓存，默认开 | 压测想排除缓存影响时关掉 |
| `--enforce-eager` | 关闭 CUDA graph | E12 对比 |
| `--reasoning-parser`、`--tool-call-parser`、`--enable-auto-tool-choice` | 思考与工具调用的解析 | 不加时思考内容和工具调用会以原文出现在 content 中 |

## 本机实测记录
