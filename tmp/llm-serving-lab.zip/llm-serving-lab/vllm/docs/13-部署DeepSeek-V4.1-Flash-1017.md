# 13 vLLM 部署 DeepSeek-V4.1-Flash-1017（8 卡，显存极限）

## 1. 模型要点（来自模型卡、config.json 与 vLLM recipe）

- **规模**：552B 主干参数，另有 196B 的 Engram 记忆。预填充时每 token 激活 8B，解码时每 token 激活 16B。
- **因果编码器-解码器**：40 层分为 20 层编码器和 20 层解码器，解码器的全局 KV 由编码器最后一层的隐状态投影得到。所以预填充只需要跑编码器一半，解码要跑全部。
- **两级稀疏注意力**：
  - 每层有 128 token 的滑动窗口。
  - 部分层带压缩 KV 潜变量（压缩比 1 或 2）；只有第 2、8、14、20 层真正计算自己的压缩 KV，其他层复用。
  - indexer 先选出 2048 个 8-token 块作为候选，再从中选 top-512。
  - 全局 KV 约 890 字节/token。
- **Engram**：第 1、14 层各有一张约 3.84 亿行 × 256 维的哈希表，用 2/3/4-gram 查表，合计约 183 GiB。
- **Hyper-Connections**：残差流有 4 份，用 Sinkhorn 迭代 20 次得到双随机混合矩阵。
- **MoE**：384 个专家选 6，外加 1 个共享专家；图像 token 使用单独的路由偏置。
- **DSpark**：3 级草稿头，每级 128 个专家选 3，一次起草 5 个 token。没有 MTP。
- **权重**：路由专家为 MXFP4，其余为 MXFP8，scale 为 UE8M0。约 510 GB（476 GiB）。

## 2. 8×80GB 的显存账（recipe 中 H100 档的设置）

| 项 | 不卸载 | 卸载 Engram（profile 默认） |
|---|---|---|
| 每卡常驻权重 | 约 60 GiB（476/8） | 约 36 GiB |
| Engram 表 | 每卡约 23 GiB，在 GPU 上 | 约 183 GiB，锁页放在主机内存，通过 UVA 读取，输出不变 |
| indexer logits 缓冲 | `max_num_batched_tokens × max_model_len × 2B` | 4096 × 1M × 2B = 8 GiB（取 8192 时为 16 GiB，放不下） |
| KV 与激活 | 几乎没有空间 | 剩余部分 |

profile `dsv41-flash` 完全照搬 recipe：

- `--engram-config '{"cpu_offload":true}'`
- `--max-num-batched-tokens 4096`
- `--gpu-memory-utilization 0.92`
- 环境变量 `VLLM_USE_V2_MODEL_RUNNER=1`、`PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True`

另外加了 `--language-model-only`，不加载视觉编码器，把显存留给 KV。

## 3. 启动

```bash
free -g                                       # 主机可用内存应 ≥ 250 GiB
bash scripts/engine.sh start vllm dsv41-flash
bash scripts/wait_ready.sh vllm-dsv41-flash 5400
runtime/envs/client/bin/python tools/parse_server_log.py runtime/logs/engines/vllm-dsv41-flash.latest.log
free -g                                       # 对比启动前后，记录 Engram 占用的主机内存
```

recipe 中的验证请求（正确答案为 323）：

```bash
curl -s http://127.0.0.1:8000/v1/chat/completions -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-v4.1-flash","messages":[{"role":"user","content":"What is 17*19? Return only the integer."}],
       "max_tokens":4096}' | python3 -m json.tool
runtime/envs/client/bin/python tools/smoke_test.py --base-url http://127.0.0.1:8000/v1 --no-auth-check --max-tokens 16384 \
  --out runtime/results/E01/smoke-vllm-dsv41.json
```

## 4. 思考与工具调用（recipe 说明）

- **未设置 thinking 时，默认开启思考、强度 50**。小 `max_tokens` 会导致 content 为空。
- **思考强度**：`chat_template_kwargs: {"thinking": true, "reasoning_effort": 25}`。
  - 开源编码器的分档为 low=25、high=50、xhigh=75、max=100；DeepSeek 官方 API 的分档为 low/high/max = 50/75/100，两者不同。
  - 技术报告指出，强度 60–80 能以不到一半的 token 恢复大部分精度。
- **工具调用**以 DSML 标签块输出，工具结果放在 `<tool_result>` 标签中，由 `deepseek_v41` 解析器处理。

## 5. 变体

| 变体 | 命令 | 说明 |
|---|---|---|
| DSpark 投机解码 | `bash scripts/engine.sh start vllm dsv41-flash-dspark` | NVIDIA 上默认开启自适应验证。草稿多约 14B 参数，显存更紧 |
| 图文输入 | `bash scripts/engine.sh start vllm dsv41-flash-vision` | ViT 用数据并行（`--mm-encoder-tp-mode data`） |
| 缩短上下文换 KV | `... -- --max-model-len 262144 --max-num-batched-tokens 8192` | indexer 缓冲 = 8192 × 256K × 2B = 4 GiB，比默认更省（自行实验，需要记录） |
| 不卸载 Engram（对照） | `... -- --engram-config '{"cpu_offload":false}'` | 预期 OOM 或 KV 极少，用来理解显存账（E23） |

## 本机实测记录
