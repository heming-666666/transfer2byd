# 10 vLLM 安装验证与架构

## 1. 验证镜像

```bash
source lab.env
docker run --rm --entrypoint vllm "$VLLM_IMAGE" --version                    # 期望 0.32.0
docker run --rm --gpus all --entrypoint vllm "$VLLM_IMAGE" collect-env > runtime/logs/machine/vllm-collect-env.txt
grep -iE "vllm|torch|cuda|nccl|flashinfer|triton" runtime/logs/machine/vllm-collect-env.txt | head -30
```

`collect-env` 会输出 torch、CUDA、NCCL、FlashInfer、GPU 拓扑等信息。把它保存下来，遇到问题时附上。

## 2. vLLM V1 引擎的进程结构（读日志前先理解）

```text
vllm serve
 ├─ API Server 进程（FastAPI，OpenAI 兼容接口；分词、聊天模板、reasoning/tool 解析）
 │     │  ZMQ
 └─ EngineCore 进程（调度器 Scheduler + KV cache 管理器）
        ├─ Worker 0（GPU 0）：模型执行 GPUModelRunner、CUDA graph、attention 后端
        ├─ Worker 1（GPU 1）
        └─ ...（TP×PP 个 worker；DP>1 时有多个 EngineCore，由 DP Coordinator 协调）
```

几个默认开启的关键机制，后面的实验会逐一拆开：

- **连续批处理（continuous batching）**：每一步重新组 batch，请求随到随走。
- **分块预填充（chunked prefill）**：长提示被切成块，与 decode 混在同一步中，每步的 token 预算由 `--max-num-batched-tokens` 控制（E21）。
- **前缀缓存（prefix caching）**：按 KV 块的哈希复用相同前缀（E13）。
- **PagedAttention**：KV 以固定大小的块分配，块大小由 `--block-size` 控制（E13）。
- **CUDA graph**：默认 `FULL_AND_PIECEWISE` 模式，配合 torch.compile（E12）。
- **混合 KV 管理器**：GLM-5.3-Flash 同时有 KDA 状态和稀疏 MLA 的 KV，由 hybrid KV cache manager 统一管理（E13）。

## 3. 源码阅读路线（v0.32.0，已核对路径存在）

| 主题 | 文件 |
|---|---|
| 调度器（每一步选哪些请求、给多少 token） | `vllm/v1/core/sched/scheduler.py` |
| KV 块分配与前缀缓存 | `vllm/v1/core/kv_cache_manager.py`、`vllm/v1/core/block_pool.py` |
| 引擎主循环 | `vllm/v1/engine/core.py`、`vllm/v1/engine/async_llm.py` |
| 模型执行与 CUDA graph | `vllm/v1/worker/gpu_model_runner.py`、`vllm/v1/worker/gpu/model_runner.py`（V2 runner）、`vllm/compilation/cuda_graph.py` |
| attention 后端 | `vllm/v1/attention/backends/` |
| 并行组与通信 | `vllm/distributed/parallel_state.py`、`vllm/distributed/device_communicators/custom_all_reduce.py` |
| MoE kernel | `vllm/model_executor/layers/fused_moe/` |
| 投机解码 | `vllm/v1/spec_decode/` |
| PD 分离（NIXL） | `vllm/distributed/kv_transfer/kv_connector/v1/nixl/` |
| DeepSeek-V4.1 | `vllm/models/deepseek_v41/`（`attention.py`、`compressor.py`、`sparse_mla.py`、`decoder_replay_layers.py`） |
| GLM-5.3-Flash | `vllm/models/glm5next/`（`sparse_indexer.py` 等） |

阅读方法：在镜像里打开源码，`docker run --rm -it --entrypoint bash $VLLM_IMAGE`，再执行 `python3 -c "import vllm,os;print(os.path.dirname(vllm.__file__))"` 找到源码位置。

## 4. 常用子命令

| 命令 | 用途 |
|---|---|
| `vllm serve` | 启动服务（由 engine.sh 调用） |
| `vllm bench serve` | 在线压测（由 bench_serve.sh 调用） |
| `vllm bench latency` / `vllm bench throughput` | 离线延迟与吞吐（不经过 HTTP） |
| `vllm bench startup` | 测启动耗时，E12 用 |
| `vllm bench sweep` | 参数扫描，每次运行之间会重置缓存 |
| `vllm collect-env` | 环境信息 |

## 本机实测记录
