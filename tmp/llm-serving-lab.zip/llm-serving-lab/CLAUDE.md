@AGENTS.md

Claude Code 在本目录工作时，遵守上面 AGENTS.md 的全部规则。回复使用中文。
